package com.infy.ekart.service.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.entity.DealProduct;
import com.infy.ekart.entity.Product;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.ProductDealRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.service.CustomerProductService;
import com.infy.ekart.service.CustomerProductServiceImpl;

@SpringBootTest
class CustomerProductServiceTest {

	@Mock
	private ProductRepository productRepository;

	@Mock
	private ProductDealRepository productDealRepository;
	
	
	@InjectMocks
	private CustomerProductService productService = new CustomerProductServiceImpl();

	@Test
	 void getAllProductsValid() throws EKartException {
		List<Product> products = new ArrayList<Product>();
		Product product1 = new Product();
		product1.setProductId(1);
		products.add(product1);
		Product product2 = new Product();
		product2.setProductId(2);
		products.add(product2);
		Mockito.when(productRepository.findAll()).thenReturn(products);
		Assertions.assertEquals(products.size(), productService.getAllProducts().size());

	}
	@Test//17/12/20 //correct
	void getAllDealProductslValidTest() throws EKartException {
		List<DealProduct> dealproductList = new ArrayList<DealProduct>();
		DealProduct dealproduct = new DealProduct();
		dealproduct.setDealProductId(100);
		dealproductList.add(dealproduct);
		Mockito.when(productDealRepository.findAll()).thenReturn(dealproductList);
		Assertions.assertNotNull(productService.getAllDealProducts());
	}
	@Test//17/12/20 //correct
	void getAllDealProductsInValidTest() throws EKartException {
		
		Mockito.when(productDealRepository.findAll()).thenReturn(null);
		EKartException eKartException = Assertions.assertThrows(EKartException.class,
				() -> productService.getAllDealProducts());

		Assertions.assertEquals("CustomerProductService.NO_PRODUCTS_TO_DISPLAY", eKartException.getMessage());
		
	}
}
