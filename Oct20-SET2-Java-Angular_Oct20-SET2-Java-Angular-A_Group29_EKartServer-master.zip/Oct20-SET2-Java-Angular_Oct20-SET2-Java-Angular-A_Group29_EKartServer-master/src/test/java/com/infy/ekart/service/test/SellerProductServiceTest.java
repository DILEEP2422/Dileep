package com.infy.ekart.service.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.DealProductDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.SellerDTO;
import com.infy.ekart.entity.DealProduct;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.ProductCategory;
import com.infy.ekart.entity.Seller;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.ProductCategoryRepository;
import com.infy.ekart.repository.ProductDealRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.repository.SellerRepository;
import com.infy.ekart.service.SellerProductService;
import com.infy.ekart.service.SellerProductServiceImpl;

@SpringBootTest
class SellerProductServiceTest {
	

	@Mock
	private ProductCategoryRepository productCategoryRepository;
	
	@Mock
	private ProductRepository productRepository;
	
	@Mock
	private SellerRepository sellerRepository;
	
	@Mock
	private ProductDealRepository productDealRepository;
	
	@InjectMocks
	private SellerProductService sellerProductService = new SellerProductServiceImpl();
	
	// testing addNewProduct() method
	@Test
	void addNewProductValidTest() throws EKartException{
		ProductDTO productDTO=new ProductDTO();
		productDTO.setBrand("Motobot");
		productDTO.setCategory("Electronics - Mobile");
		productDTO.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		productDTO.setDiscount(5.0);
		productDTO.setName("Xpress");
		productDTO.setPrice(16000.0);
		productDTO.setProductId(1001);
		productDTO.setQuantity(150);
		Product product=new Product();
		product.setBrand("Motobot");
		product.setCategory("Electronics - Mobile");
		product.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setDiscount(5.0);
		product.setName("Xpress");
		product.setPrice(16000.0);
		product.setProductId(1001);
		product.setQuantity(150);
		Mockito.when(productRepository.save(Mockito.any())).thenReturn(product);
		Assertions.assertEquals(productDTO.getProductId(), sellerProductService.addNewProduct(productDTO));
	}
	
	
	// testing modifyProductDetails() method
	@Test
	void modifyProductDetailsValidTest() throws EKartException{
		ProductDTO productDTO=new ProductDTO();
		productDTO.setBrand("Motobot");
		productDTO.setCategory("Electronics - Mobile");
		productDTO.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		productDTO.setDiscount(5.0);
		productDTO.setName("Xpress");
		productDTO.setPrice(16000.0);
		productDTO.setProductId(1001);
		productDTO.setQuantity(150);
		
		Product product=new Product();
		product.setBrand("Motobot");
		product.setCategory("Electronics - Mobile");
		product.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setDiscount(5.0);
		product.setName("Xpress");
		product.setPrice(16000.0);
		product.setProductId(1001);
		product.setQuantity(150);
		Mockito.when(productRepository.findById(Mockito.any())).thenReturn(Optional.of(product));
		Assertions.assertEquals(productDTO, sellerProductService.modifyProductDetails(productDTO));
	}

	// testing getProductCategoryList() method
	@Test
	void getProductCategoryListValidTest() throws EKartException{
		List<ProductCategory> productCategories = new ArrayList<ProductCategory>();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setCategory("Electronics - Mobile");
		productCategories.add(productCategory);
		Mockito.when(productCategoryRepository.findAll()).thenReturn(productCategories);
		Assertions.assertNotNull(sellerProductService.getProductCategoryList());
	}
	
	// testing removeProduct() method
	@Test
	void removeProductValidTest() throws EKartException{
		ProductDTO productDTO=new ProductDTO();
		productDTO.setProductId(1);
		
		Seller seller= new Seller();
		seller.setEmailId("john@gmail.com");
		Optional<Seller> optionalSeller=Optional.of(seller);
		
		Mockito.when(sellerRepository.findById(productDTO.getSellerEmailId())).thenReturn(optionalSeller);
		Assertions.assertNotNull(sellerProductService.removeProduct(productDTO));
	}
	
	// testing SELLER_NOT_FOUND exception
	@Test
	void remvoeProductInvalidTest() {
		ProductDTO productDTO=new ProductDTO();
		productDTO.setProductId(1);
		Mockito.when(sellerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(new Seller()));
		EKartException eKartException = Assertions.assertThrows(EKartException.class,
				() -> sellerProductService.removeProduct(productDTO));

		Assertions.assertEquals("Service.SELLER_NOT_FOUND", eKartException.getMessage());
	}
	@Test//17/12/20
	void addProductToDealValidTest() throws EKartException {
		DealProductDTO dealProductDTO =new DealProductDTO();
		dealProductDTO.setSellerEmailId("Jerry@infosys.com");
		dealProductDTO.setDealDiscount(0.4F);
		dealProductDTO.setDealId(100);
		dealProductDTO.setProductId(100);
		dealProductDTO.setStartDateAndTime("");
		dealProductDTO.setEndDateAndTime("");
		DealProduct dealProduct =new DealProduct();
		dealProduct.setDealId(100);
		Mockito.when(productDealRepository.save(Mockito.any())).thenReturn(dealProduct);
		Assertions.assertEquals(dealProduct.getDealId(), sellerProductService.addProductToDeal(dealProductDTO));
		
	}
	@Test//17/12/20
	void addProductToDealInValidTest() throws EKartException {
		DealProductDTO dealProductDTO =new DealProductDTO();
		dealProductDTO.setSellerEmailId("Jerry@infosys.com");
		dealProductDTO.setDealDiscount(0.4F);
		dealProductDTO.setDealId(101);
		dealProductDTO.setProductId(null);
		dealProductDTO.setStartDateAndTime("2020-10-12 10:00:00");
		dealProductDTO.setEndDateAndTime("2020-10-15 10:00:00");
		DealProduct dealProduct =new DealProduct();
		
		Mockito.when(productDealRepository.save(Mockito.any())).thenReturn(dealProduct);
		EKartException eKartException = Assertions.assertThrows(EKartException.class,
				() -> sellerProductService.addProductToDeal(dealProductDTO));

		Assertions.assertEquals("SellerProductService.NO_PRODUCTS_TO_ADD", eKartException.getMessage());
		
	}
	
	@Test//17/12/20
	void getProductsAvailableForDealValidTest() throws EKartException{
		DealProduct product =new DealProduct();
		DealProduct product1 =new DealProduct();
		SellerDTO sellerDTO =new SellerDTO();
	    sellerDTO.setEmailId("Jack@infosys.com");		
	    product.setSellerEmailId("Jack@infosys.com");
	    product.setEndDateAndTime("2020-10-10 10:00:00");
	    product1.setSellerEmailId("Jack@infosys.com");
	    product1.setEndDateAndTime("2020-10-10 10:00:00");
		List<DealProduct> productList =new ArrayList<DealProduct>();
		productList.add(product);
		productList.add(product1);
		Mockito.when(productDealRepository.findAll()).thenReturn(productList);
		Assertions.assertNotNull(sellerProductService.getProductsAvailableForDeal( sellerDTO));
		
	}
	@Test//change by faizal 17/12/20
	void getProductsAvailableForDealInValidTest() throws EKartException{
		SellerDTO sellerDTO =new SellerDTO();
	    sellerDTO.setEmailId("Jack@infosys.com");	
		Mockito.when(productDealRepository.findAll()).thenReturn(null);
		EKartException eKartException = Assertions.assertThrows(EKartException.class,
				() -> sellerProductService.getProductsAvailableForDeal(sellerDTO));

		Assertions.assertEquals("Service.NO_DEAL_FOUND", eKartException.getMessage());
		
		
	}

	
	
}
