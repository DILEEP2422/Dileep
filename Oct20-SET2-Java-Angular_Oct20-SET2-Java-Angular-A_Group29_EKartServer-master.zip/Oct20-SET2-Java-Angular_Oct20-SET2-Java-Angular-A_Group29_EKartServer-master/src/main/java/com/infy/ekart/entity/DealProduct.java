package com.infy.ekart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="EK_DEALS_FOR_TODAY")
public class DealProduct {
	
	@Id
	@Column(name="DEAL_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer dealId;
	
	
	@Column(name="PRODUCT_ID")
	private Integer dealproductId;
	
	@Column(name="DEAL_DISCOUNT")
	private float dealDiscount;
	
	@Column(name="DEAL_STARTS_AT")
	private String startDateAndTime;
	
	@Column(name="DEAL_ENDS_AT")
	private String endDateAndTime;
	
	@Column(name="SELLER_EMAIL_ID")
	private String sellerEmailId;
	
	public Integer getDealId() {
		return dealId;
	}

	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}

	public Integer getDealProductId() {
		return dealproductId;
	}

	public void setDealProductId(Integer productId) {
		this.dealproductId = productId;
	}

	public float getDealDiscount() {
		return dealDiscount;
	}

	public void setDealDiscount(float dealDiscount) {
		this.dealDiscount = dealDiscount;
	}

	public String getStartDateAndTime() {
		return startDateAndTime;
	}

	public void setStartDateAndTime(String startDateAndTime) {
		this.startDateAndTime = startDateAndTime;
	}

	public String getEndDateAndTime() {
		return endDateAndTime;
	}

	public void setEndDateAndTime(String endDateAndTime) {
		this.endDateAndTime = endDateAndTime;
	}

	public String getSellerEmailId() {
		return sellerEmailId;
	}

	public void setSellerEmailId(String sellerEmailId) {
		this.sellerEmailId = sellerEmailId;
	}
}
