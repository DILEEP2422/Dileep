package com.infy.ekart.dto;

public class DealProductDTO 
{    
	
private Integer productId;
	
	private Integer dealId;

	private String startDateAndTime;

	private String endDateAndTime;
	
	private Float dealDiscount;
	
	private String sellerEmailId;
	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getDealId() {
		return dealId;
	}

	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}

	public String getStartDateAndTime() {
		return startDateAndTime;
	}

	public void setStartDateAndTime(String startDateAndTime) {
		this.startDateAndTime = startDateAndTime;
	}

	public String getEndDateAndTime() {
		return endDateAndTime;
	}

	public void setEndDateAndTime(String endDateAndTime) {
		this.endDateAndTime = endDateAndTime;
	}

	public Float getDealDiscount() {
		return dealDiscount;
	}

	public void setDealDiscount(Float dealDiscount) {
		this.dealDiscount = dealDiscount;
	}

	public String getSellerEmailId() {
		return sellerEmailId;
	}

	public void setSellerEmailId(String sellerEmailId) {
		this.sellerEmailId = sellerEmailId;
	}

	
}
