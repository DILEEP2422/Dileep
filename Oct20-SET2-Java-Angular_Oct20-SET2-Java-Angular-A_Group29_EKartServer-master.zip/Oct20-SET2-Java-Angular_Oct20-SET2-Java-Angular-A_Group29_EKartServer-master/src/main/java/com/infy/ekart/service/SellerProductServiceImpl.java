package com.infy.ekart.service;

//infygithub.ad.infosys.com/Java-Angular/Oct20-SET2-Java-Angular_Oct20-SET2-Java-Angular-A_Group29_EKartServer.git
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;



//infygithub.ad.infosys.com/Java-Angular/Oct20-SET2-Java-Angular_Oct20-SET2-Java-Angular-A_Group29_EKartServer.git
import java.util.Iterator;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dto.DealProductDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.SellerDTO;
import com.infy.ekart.entity.DealProduct;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.ProductCategory;
import com.infy.ekart.entity.Seller;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.ProductCategoryRepository;
import com.infy.ekart.repository.ProductDealRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.repository.SellerRepository;

@Service(value = "sellerProductService")
@Transactional
public class SellerProductServiceImpl implements SellerProductService {
	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private SellerRepository sellerRepository;

	@Autowired
	private ProductCategoryRepository productCategoryRepository;
	
	@Autowired
	private ProductDealRepository objProductDealRepository;

	/**
     * @params
     *         productDTO - The new product to be added
     * 
     * @operation 
     * 			Adds a new product
     *          * Saves the product in DB using productRepository 
     * 
     * @returns
     *          Integer - The product id
     */
	@Override
	public Integer addNewProduct(ProductDTO productDTO) throws EKartException {
		Product product = new Product();
		product.setBrand(productDTO.getBrand());
		product.setCategory(productDTO.getCategory());
		product.setDescription(productDTO.getDescription());
		product.setDiscount(productDTO.getDiscount());
		product.setName(productDTO.getName());
		product.setPrice(productDTO.getPrice());
		product.setQuantity(productDTO.getQuantity());

		Product productFromDB = productRepository.save(product);
		return productFromDB.getProductId();
	}

	/**
     * @params
     *         productDTO - The new productDTO
     * 
     * @operation 
     * 		   Modifies the product in DB with the given productDTO
     * 			* Fetches the product from DB using productRepository
     * 			* updates the product with given product
     * 
     * @returns
     *         productDTO - productDTO after modification
     */
	@Override
	public ProductDTO modifyProductDetails(ProductDTO productDTO) throws EKartException {
		Optional<Product> optionalProduct = productRepository.findById(productDTO.getProductId());

		if (optionalProduct.isPresent()) {
			Product product = optionalProduct.get();
			product.setDescription(productDTO.getDescription());
			product.setDiscount(productDTO.getDiscount());
			product.setName(productDTO.getName());
			product.setPrice(productDTO.getPrice());
			product.setQuantity(productDTO.getQuantity());
		}
		return productDTO;
	}

	/**
	 * @params
     *         productDTO - The productDTO in DB
     *         
     * @operation 
     * 		   Deletes the product object from productList
     *         * Fetches the seller by passing sellerId from sellerRepository
     *         * Fetches the product list for the given seller
     *         * Delete the product from product list
     * 	 
     * 
     * @returns
     *         Integer - The productDTO id
     */
	@Override
	public Integer removeProduct(ProductDTO productDTO) throws EKartException {
		Optional<Seller> optionalSeller = sellerRepository.findById(productDTO.getSellerEmailId());
		Seller seller = optionalSeller.orElseThrow(() -> new EKartException("Service.SELLER_NOT_FOUND"));
		List<Product> products = seller.getProduct();
		List<Product> updatedProducts = new ArrayList<>();
		if (products != null && products.isEmpty()) {
			for (Product product : products) {
				if (!productDTO.getProductId().equals(product.getProductId())) {
					updatedProducts.add(product);
				}
			}
		}
		seller.setProduct(updatedProducts);
		return productDTO.getProductId();
	}

	/**
     * @operation 
	 *			Fetches the all product categories from DB using productCategoryRepository
     * 
     * @returns
     *          List<String> - The list of product categories
     */
	@Override
	public List<String> getProductCategoryList() throws EKartException {
		Iterable<ProductCategory> productCategories = productCategoryRepository.findAll();
		List<String> productCategoryNames = new ArrayList<>();
		for (ProductCategory productCategory : productCategories) {
			productCategoryNames.add(productCategory.getCategory());
		}
		return productCategoryNames;
	}

	
	
	/**
     * @params
     *         productDTO - The new product to be added
     * 
     * @operation 
     * 			Adds a new product
     *          * Saves the product in DB using productRepository 
     * 
     * @returns
     *          Integer - The Deal id
     */
	@Override //change
	public Integer addProductToDeal(DealProductDTO objDealProductDTO) throws EKartException 
	{
		DealProduct objDealProduct = new DealProduct();
		if(objDealProductDTO.getProductId()==null) { throw new EKartException("SellerProductService.NO_PRODUCTS_TO_ADD");}
		objDealProduct.setDealDiscount(objDealProductDTO.getDealDiscount());
		objDealProduct.setDealProductId(objDealProductDTO.getProductId());
		objDealProduct.setSellerEmailId(objDealProductDTO.getSellerEmailId());
		objDealProduct.setStartDateAndTime(objDealProductDTO.getStartDateAndTime());
		objDealProduct.setEndDateAndTime(objDealProductDTO.getEndDateAndTime());
		
		DealProduct objAddedDealProduct =  objProductDealRepository.save(objDealProduct);
		
		return objAddedDealProduct.getDealId();
	}
	

	@Override //17/12/20
	public List<DealProduct> getProductsAvailableForDeal(SellerDTO objSellerDetails) throws EKartException 
	{
		ArrayList<DealProduct> objDealProductsForSeller = new ArrayList<DealProduct>();
		Iterable<DealProduct> objAddedDealProduct =  objProductDealRepository.findAll();
		if(objAddedDealProduct==null) {throw new EKartException("Service.NO_DEAL_FOUND");}
		 @SuppressWarnings("rawtypes")
		Iterator objDealProduct = objAddedDealProduct.iterator();
	      
	     while(objDealProduct.hasNext()) 
	     {
	    	 
	    		  DealProduct objDealProductAvailable = (DealProduct) objDealProduct.next();
	 	         if(objDealProductAvailable.getSellerEmailId().equalsIgnoreCase(objSellerDetails.getEmailId()))
	 	         {
	 	        	 DateTimeFormatter objDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	 	        	 LocalDateTime objDealEndDateAndTime = LocalDateTime.parse(objDealProductAvailable.getEndDateAndTime(),objDateTimeFormatter);
	 	        	 LocalDateTime objCurrentTime = LocalDateTime.now();
	 	        	 
	 	        	 if(objDealEndDateAndTime.isAfter(objCurrentTime))
	 	        	 {
	 	        		 objDealProductsForSeller.add(objDealProductAvailable);
	 	        	 }
	 	         }
	    	 
	      }
		
		return objDealProductsForSeller;
	}
  

	
	/**
     * @params
     *         productDTO - The new product to be added
     * 
     * @operation 
     * 			Adds a new product
     *          * Saves the product in DB using productRepository 
     * 
     * @returns
     *          Integer - The Deal id
     */
	
	
	
	
//infygithub.ad.infosys.com/Java-Angular/Oct20-SET2-Java-Angular_Oct20-SET2-Java-Angular-A_Group29_EKartServer.git
	
}
