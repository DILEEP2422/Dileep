// // functional implementation of a modal
// // should not change overtime
// const moveModalToRoot = modal => {
//   document.body.querySelector(".root").append(modal);
// };

// // restructure function
// // will move the modal div outside button and append to body root element
// const restructureModal = buttonWrapper => {
//   let modal = buttonWrapper.querySelector(".cmp-button__modal-container");

//   // remove modal from within the button
//   buttonWrapper.removeChild(modal);
//   // append this to root element
//   moveModalToRoot(modal);
// };

// const toggleModalProperties = modal => {
//   modal.classList.toggle("cmp-button__modal--hidden");
//   document.body.classList.toggle("cmp-button__modal--open");
//   if (modal.hasAttribute("aria-hidden")) {
//     modal.removeAttribute("aria-hidden");
//     modal.setAttribute("aria-modal", "true");
//   } else {
//     modal.setAttribute("aria-hidden", "true");
//     modal.removeAttribute("aria-modal");
//   }
// };

// // handle click event for button
// // this method should link a button click to it's modal pop-up
// const handleClick = buttonWrapper => {
//   let button = buttonWrapper.querySelector(".cmp-button");
//   let cross = buttonWrapper.querySelector(".cmp-button__modal-close>button");

//   let outsideContent = buttonWrapper.querySelector(
//     ".cmp-button__modal-container"
//   );

//   let modalID = buttonWrapper.id
//     .split("cmp-button--")
//     .join("#cmp-button__modal--");

//   let modal = document.querySelector(modalID);

//   // for buttonwrapper
//   // assign a click event to toggle respective modals
//   button.addEventListener("click", function() {
//     toggleModalProperties(modal);
//   });

//   cross.addEventListener("click", function() {
//     toggleModalProperties(modal);
//   });

//   outsideContent.addEventListener("click", function(event) {
//     if (event.target == outsideContent) {
//       toggleModalProperties(modal);
//     }
//   });
// };

// // main function
// (main = function() {
//   document.querySelectorAll(".cmp-button__modal").forEach(buttonWrapper => {
//     handleClick(buttonWrapper);
//     restructureModal(buttonWrapper);
//   });
// })();

// // ES5 code for IE

var moveModalToRoot = function moveModalToRoot(modal) {
  document.body.querySelector(".root").append(modal);
};

var restructureModal = function restructureModal(buttonWrapper) {
  var modal = buttonWrapper.querySelector(".cmp-button__modal-container");

  buttonWrapper.removeChild(modal);

  moveModalToRoot(modal);
};

var toggleModalProperties = function toggleModalProperties(modal) {
  modal.classList.toggle("cmp-button__modal--hidden");
  document.body.classList.toggle("cmp-button__modal--open");

  if (modal.hasAttribute("aria-hidden")) {
    modal.removeAttribute("aria-hidden");
    modal.setAttribute("aria-modal", "true");
  } else {
    modal.setAttribute("aria-hidden", "true");
    modal.removeAttribute("aria-modal");
  }
};

var handleClick = function handleClick(buttonWrapper) {
  var button = buttonWrapper.querySelector(".cmp-button");
  var cross = buttonWrapper.querySelector(".cmp-button__modal-close>button");
  var outsideContent = buttonWrapper.querySelector(
    ".cmp-button__modal-container"
  );
  var modalID = buttonWrapper.id
    .split("cmp-button--")
    .join("#cmp-button__modal--");
  var modal = document.querySelector(modalID);

  button.addEventListener("click", function() {
    toggleModalProperties(modal);
  });
  cross.addEventListener("click", function() {
    toggleModalProperties(modal);
  });
  outsideContent.addEventListener("click", function(event) {
    if (event.target == outsideContent) {
      toggleModalProperties(modal);
    }
  });
};

(main = function main() {
  document
    .querySelectorAll(".cmp-button__modal")
    .forEach(function(buttonWrapper) {
      handleClick(buttonWrapper);
      restructureModal(buttonWrapper);
    });
})();
