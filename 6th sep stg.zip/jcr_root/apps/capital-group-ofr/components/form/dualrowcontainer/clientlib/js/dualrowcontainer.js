$(document).ready(function () {


    var selector=document.querySelector(".container-config");
	var val1=selector.getAttribute("data-properties");
    var idField1=selector.getAttribute("data-element5a");
    var idField2=selector.getAttribute("data-element5b");
    var idField3=selector.getAttribute("data-element5c");
    var idField4=selector.getAttribute("data-element5d");
	var idField5=selector.getAttribute("data-element5e");
    var stylingClasses="cmp-form-options__field cmp-form-options__field--drop-down cmp-form-text__text";



    var firstElement=document.getElementById(idField1);
    var secondElement=document.getElementById(idField2);
    var thirdElement=document.getElementById(idField3);
    var fourthElement=document.getElementById(idField4);
    var fifthElement=document.getElementById(idField5);

    $(firstElement).attr("class","Field1 "+stylingClasses);
    $(secondElement).attr("class","Field2 "+stylingClasses);
    $(thirdElement).attr("class","Field3 "+stylingClasses);
    $(fourthElement).attr("class","Field4 "+stylingClasses);
    $(fifthElement).attr("class","Field5 "+stylingClasses);

    $("#pro-total").parent().parent().css("display","none");
    $("#deposit_total").maskMoney({ prefix:'$',allowEmpty:false});

    $.fn.digits = function(){ 
    return this.each(function(){ 
        $(this).text( $(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") ); 
    })
}
     $(document).on('focus', '[name^="pamtdemo"]', function () {
         $(this).maskMoney({ prefix:'$',allowEmpty:false});

    });

    $(document).on('focus', '[name^="vamtdemo"]', function () {
         $(this).maskMoney({ prefix:'$',allowEmpty:false});

    });







	$(document).on('blur', '[name^="pamtdemo"]', function () {
		$(this).maskMoney({ prefix:'$',allowEmpty:false});
        var firstSum=sumData();
        var secondSum=sumData1();
        var Total=(Number(firstSum)+Number(secondSum)).toFixed(2);
        $('#sum1disp h5').html("SUB-TOTAL : $"+firstSum);
        $('#sum1disp h5').digits();
        $('#totaldisp h5').html("PROCESSING-TOTAL : $"+Total);
        $("#pro-total").val(Total);
        $('#totaldisp h5').digits();
    });

    function sumData() {
        var sum1=0
        var rowCount = $("#accountTable1 > tbody > tr").length;
          $('[name^="pamtdemo"]').each(function () {

            var format = $(this).val().replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '');
            sum1+=Number(format);
            dispSum=(sum1).toFixed(2);
          });
			return dispSum;
        }


	$(document).on('blur', '[name^="vamtdemo"]', function () {
        $(this).maskMoney({ prefix:'$',allowEmpty:false});
        var firstSum=sumData();
        var secondSum=sumData1();
        var Total=(Number(firstSum)+Number(secondSum)).toFixed(2);
         $('#sum1disp h5').html("SUB-TOTAL : $"+firstSum);
        $('#sum1disp h5').digits();
        $('#totaldisp h5').html("PROCESSING-TOTAL : $"+Total);

       	$("#pro-total").val(Total);

        $('#totaldisp h5').digits();

    });

    $(document).on('blur', '[name^="variance_"]', function () {
        $(this).maskMoney({ prefix:'$',allowEmpty:false});
        var firstSum=sumData();
        var secondSum=sumData1();
        var Total=(Number(firstSum)+Number(secondSum)).toFixed(2);
         $('#sum1disp h5').html("SUB-TOTAL : $"+firstSum);
        $('#sum1disp h5').digits();
        $('#totaldisp h5').html("PROCESSING-TOTAL : $"+Total);

       	$("#pro-total").val(Total);

        $('#totaldisp h5').digits();

    });

    function sumData1() {
        var sum1=0
        var rowCount = $("#accountTable2 > tbody > tr").length;
          $('[name^="vamtdemo"]').each(function () {

			var format = $(this).val().replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '');
             if($(this).parent().parent().parent().parent().parent().children().eq(1).children().children().children().children().eq(1).val()=="Allowance-Shortage")
             {
                 sum1-=Number(format);
             }
             else
             {
            	sum1+=Number(format);
             }
            dispSum=(sum1).toFixed(2);

          });
			return dispSum;
        }

    function incrementRow1() {

        var rowCount =$("#accountTable1 > tbody > tr").length;

        for (i = 2; i <= rowCount; i++) {
            $("#accountTable1 > tbody > tr").eq(i - 1).find("td .Field1").attr("id",idField1+""+i);
            $("#accountTable1 > tbody > tr").eq(i - 1).find("td .Field2").attr("id",idField2+""+i);
            $(".funds").eq(i - 1).attr('id', "funds-" + (i));
            $("#accountTable1 > tbody > tr").eq(i - 1).find("td:first-child").text(i);

          if (rowCount > 1) {
            $("#accountTable1 > tbody > tr:first-child > td:last-child #Delete-funds1").removeClass('dlt-display').addClass('Delete-funds1');
          }
        }
      }

     function incrementRow2() {

        var rowCount =$("#accountTable2 > tbody > tr").length;
        for (i = 2; i <= rowCount; i++) {

            $("#accountTable2 > tbody > tr").eq(i - 1).find("td .Field3").attr("id",idField3+""+i);
            $("#accountTable2 > tbody > tr").eq(i - 1).find("td .Field4").attr("id",idField4+""+i);
            $("#accountTable2 > tbody > tr").eq(i - 1).find("td .Field5").attr("id",idField5+""+i);

           $(".funds").eq(i - 1).attr('id', "funds-" + (i));
           $("#accountTable2 > tbody > tr").eq(i - 1).find("td:first-child").text(i);

          if (rowCount > 1) {

            $("#accountTable2 > tbody > tr:first-child > td:last-child #Delete-funds2").removeClass('dlt-display').addClass('Delete-funds1');
          }
        }
      }

      $("#AddFundsBtn1").on('click', function () {
        var cloneTable= $('#text121').clone();
        $(cloneTable).find("td .Field1").val('');
        $(cloneTable).find("td .Field2").val('');
        $(cloneTable).find("td:last-child #Delete-funds1").removeClass('dlt-display').addClass('Delete-funds1');
        $(cloneTable).insertAfter("#accountTable1 > tbody > tr:last-child");
        incrementRow1();
      });

   	 $("#AddFundsBtn2").on('click', function () {
        var cloneTable= $('#text122').clone();
        $(cloneTable).find("td .Field3").val('');
        $(cloneTable).find("td .Field4").val('');
        $(cloneTable).find("td .Field5").val('');
        $(cloneTable).find("td:last-child #Delete-funds2").removeClass('dlt-display').addClass('Delete-funds1');
        $(cloneTable).insertAfter("#accountTable2 > tbody > tr:last-child");
        incrementRow2();
      });


      $(document).on('click', '#Delete-funds1', function () {
        deleteAccountRow1($(this).parent().parent());
      });

	 $(document).on('click', '#Delete-funds2', function () {
        deleteAccountRow2($(this).parent().parent());
      });

      function deleteAccountRow1(parent) {
        $(parent).remove();
        var rowCount = $("#accountTable1 > tbody > tr").length;
        if (rowCount == 1) {
          $("#accountTable1 > tbody > tr:first-child > td:last-child #Delete-funds1").addClass('dlt-display').removeClass('Delete-funds1');
        }
        for (i = 1; i <= rowCount; i++) {
          var count = 1;
          $('#accountTable1 > tbody > tr').each(function () {
            $(this).find('td.sNo').text(count);
            count++;
          })
        }
        var firstSum=sumData();
        var secondSum=sumData1();
        var Total=(Number(firstSum)+Number(secondSum)).toFixed(2);
        $('#sum1disp h5').html("SUB-TOTAL : $"+firstSum);
        $('#sum1disp h5').digits();
        $('#totaldisp h5').html("PROCESSING-TOTAL : $"+Total);

          $("#pro-total").val(Total);
          $('#totaldisp h5').digits();
      }


      function deleteAccountRow2(parent) {
        $(parent).remove();
        var rowCount = $("#accountTable2 > tbody > tr").length;
        if (rowCount == 1) {
          $("#accountTable2 > tbody > tr:first-child > td:last-child #Delete-funds2").addClass('dlt-display').removeClass('Delete-funds1');
        }
        for (i = 1; i <= rowCount; i++) {
          var count = 1;
          $('#accountTable2 > tbody > tr').each(function () {
            $(this).find('td.sNo').text(count);
            count++;
          })
        }
        var firstSum=sumData();
        var secondSum=sumData1();
        var Total=(Number(firstSum)+Number(secondSum)).toFixed(2);
        $('#sum1disp h5').html("SUB-TOTAL : $"+firstSum);
        $('#sum1disp h5').digits();
        $('#totaldisp h5').html("PROCESSING-TOTAL : $"+Total);
		$("#pro-total").val(Total);
        $('#totaldisp h5').digits();
      }
	$(document).on("click", "[name='submit-btn']", function (e) {
		if($("#deposit_total").val()!=undefined)
        {
            var totaldisp1=Number($('#deposit_total').val().replace(/[&\/\\#,+()$~%'":*?<>{}]/g, ''));
            var prototal1=Number($("#pro-total").val());
            if(totaldisp1!=prototal1)
            {
                var check=confirm('The Processing Total does not match the Deposit Total. Are the amounts correct? \n Click OK to SUBMIT FORM \n Click Cancel to GO BACK TO REVIEW');
                if(check==false){
                    e.preventDefault();
                }
            }
        }
	});

 });


