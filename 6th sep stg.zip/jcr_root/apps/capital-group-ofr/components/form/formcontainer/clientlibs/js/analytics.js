"use strict";

function attachFormAnalytics() {
	var inputElementList = document.querySelectorAll(".formcontainer > form input");
	var formName = "";

	for (var i = 0; i < inputElementList.length; i++) {
		if (inputElementList[i].id == "submitAnalytics") {
			formName = inputElementList[i].getAttribute("data-analytics-placement");
			if (formName != null) {
				formName = formName.substring(0, formName.indexOf(":"));
			}
		}
	}

	Analytics.formEngagement.formAnalytics(inputElementList, formName);
}

