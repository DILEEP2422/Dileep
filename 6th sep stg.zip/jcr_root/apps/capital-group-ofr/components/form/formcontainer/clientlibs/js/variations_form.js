$(document).ready(function() {
            if (!String.prototype.includes) {
                String.prototype.includes = function() {
                    'use strict';
                    return String.prototype.indexOf.apply(this, arguments) !== -1;
                };
            }

            $("#ipfields").hide();
            $("#contactpreviousname").parent().parent().css("display", "none");
            $("#contactsnewname").parent().parent().css("display", "none");
            $("#contactname").parent().parent().css("display", "none");

            $('input[name="payroll"]').on('change', function() {
                $("#ipfields").show();
            });

            $("#clear").click(function() {

                location.reload();
            });




            function browserSupportsDateInput() {
                var i = document.createElement("input");
                i.setAttribute("type", "date");
                return i.type !== "text";
            }

            $(document).on('focus', 'input',function () 
            {                
            	if (!browserSupportsDateInput()) {
                	$('input[type=date]').datepicker();
            		}
            });

            $('select[name=REQUESTTYPE]').change(function() {
                // hide all optional elements

                $("select[name=REQUESTTYPE] option:selected").each(function() {
                    if ($(this).val() == "DELETE OGI ID") {
                        $("#contactname").parent().parent().css("display", "block");
                        $("#contactpreviousname").parent().parent().css("display", "none");
                        $("#contactsnewname").parent().parent().css("display", "none");
                    } else if ($(this).val() == "CONTACT NAME CHANGE") {
                        $("#contactname").parent().parent().css("display", "none");
                        $("#contactpreviousname").parent().parent().css("display", "block");
                        $("#contactsnewname").parent().parent().css("display", "block");
                    }
                });
            });

            var arr;
            var arrLength = 0;


            $(document).on("focus", "[name='submit-btn']", function() {
                arr = new Array(arrLength);
                $('#html_form').find($('*:hidden')).each(function() {
                    if ($(this).prop("required")) {
                        $(this).removeAttr('required');
                        arr.push($(this));
                    }
                });

            });

            if (localStorage.getItem("userInitials") !== null && localStorage.getItem("userData") !== null) {
                var userData = localStorage.getItem("userData");
            
            var userInfo = JSON.parse(userData);
            var userLocation = userInfo.userLocation;
            var extension = userInfo.ipPhone;
            if (extension != '' && extension != null && extension != undefined && extension!="(null)" ){
                $("#EXTN").val(extension);
            }
            if (userLocation != '' && userLocation != null && userLocation != undefined) {
                function setSelectedIndex(id, location) {
					if(id.options !=null ){
                    for (var i = 0; i < id.options.length; i++) {
                        if (id.options[i].text == location) {
                            id.options[i].selected = true;
                            return;
                        }

                    }
					}
                }
if(document.getElementById('SITE') != "" && document.getElementById('SITE') != null && document.getElementById('SITE') != undefined){
                setSelectedIndex(document.getElementById('SITE'), String(userLocation));
}
if(document.getElementById('site') != "" && document.getElementById('site') != null && document.getElementById('site') != undefined){
                setSelectedIndex(document.getElementById('site'), String(userLocation));
}
            }
}
            /*-----------------------------------------------------Davast/transcript request---------------------------------------------*/
            $("#APPROVALREASON").parent().parent().css("display", "none");
            $('#APPROVER').on('input', function() {

                if ($(this).val().length > 0) {
                    $("#APPROVALREASON").parent().parent().css("display", "block");
                } else {
                    $("#APPROVALREASON").parent().parent().css("display", "none");

                }
            });
            /*---------------------------------------------------SPECIAL HANDLE REQUEST-----------------------------------------------------------------------------*/

            if ((document.URL).includes("special-handle-request")) {
                $('select[id=REQUESTTYPE]').change(function() {

                    $("select[id=REQUESTTYPE] option:selected").each(function() {
                        if ($(this).val() == "TRAC" || $(this).val() == "Special delivery to foreign address") {
                            $("#AORSITE").prop("selectedIndex", 2);
                        } else {
                            $("#AORSITE").prop("selectedIndex", 0);
                        }
                    });
                });
                $("#ADDITIONAL_COMMENTS").attr("title", "30 lines maximum");
                $("#SPECIAL_INSTRUCTIONS").attr("title", "6 lines maximum");
                $("#COURIER").parent().parent().css("display", "none");
                $("#linegpitems").parent().parent().css("display", "none");
                $("#deliveryhidden").parent().parent().css("display", "none");
                $("#BILLING_NUMBER").parent().parent().css("display", "none");
                $("#SERVICE_REQUESTED").parent().parent().css("display", "none");
                $("#SIGNATURE_REQUIRED").parent().parent().css("display", "none");
                $("#SERVICE_REQUESTED1").parent().parent().css("display", "none");
                $("#COURIER1").parent().parent().css("display", "none");
                $("#SITE_FOR_PICKUP").parent().parent().css("display", "none");
                $("#BILLING_NUMBER1").parent().parent().css("display", "none");



                $('select[name=DELIVERY]').change(function() {

                    $("select[name=DELIVERY] option:selected").each(function() {
                        if ($(this).val() == "Overnight Delivery") {

                            $("#COURIER").parent().parent().css("display", "block");
                            $("#BILLING_NUMBER").parent().parent().css("display", "block");
                            $("#SERVICE_REQUESTED").parent().parent().css("display", "block");

                            $("#SERVICE_REQUESTED1").parent().parent().css("display", "none");
                              $("#SIGNATURE_REQUIRED").parent().parent().css("display", "block");
                            $("#COURIER1").parent().parent().css("display", "none");
                            $("#SITE_FOR_PICKUP").parent().parent().css("display", "none");
                            $("#BILLING_NUMBER1").parent().parent().css("display", "none");


                        } else if ($(this).val() == "Overnight Delivery at AFS Expense") {

                            $("#COURIER").parent().parent().css("display", "block");
                            $("#BILLING_NUMBER").parent().parent().css("display", "none");
                            $("#SERVICE_REQUESTED").parent().parent().css("display", "block");
                            $("#SIGNATURE_REQUIRED").parent().parent().css("display", "block");
                            $("#SERVICE_REQUESTED1").parent().parent().css("display", "none");
                            $("#COURIER1").parent().parent().css("display", "none");
                            $("#SITE_FOR_PICKUP").parent().parent().css("display", "none");
                            $("#BILLING_NUMBER1").parent().parent().css("display", "none");


                        } else if ($(this).val() == "Overnight Delivery Billed to Third Party") {


                            $("#COURIER").parent().parent().css("display", "none");
                            $("#BILLING_NUMBER").parent().parent().css("display", "none");
                            $("#SERVICE_REQUESTED").parent().parent().css("display", "none");
$("#SERVICE_REQUESTED1").parent().parent().css("display", "block");
                            $("#SIGNATURE_REQUIRED").parent().parent().css("display", "block");

                            $("#COURIER1").parent().parent().css("display", "block");
                            $("#SITE_FOR_PICKUP").parent().parent().css("display", "none");
                            $("#BILLING_NUMBER1").parent().parent().css("display", "block");

                        }

                        if ($(this).val() == "Shareholder Pick-up") {


                            $("#COURIER").parent().parent().css("display", "none");
                            $("#BILLING_NUMBER").parent().parent().css("display", "none");
                            $("#SERVICE_REQUESTED").parent().parent().css("display", "none");
                            $("#SIGNATURE_REQUIRED").parent().parent().css("display", "none");
                            $("#SERVICE_REQUESTED1").parent().parent().css("display", "none");
                            $("#COURIER1").parent().parent().css("display", "none");
                            $("#SITE_FOR_PICKUP").parent().parent().css("display", "block");
                            $("#BILLING_NUMBER1").parent().parent().css("display", "none");

                        } else if ($(this).val() == "Regular Mail") {


                            $("#COURIER").parent().parent().css("display", "none");
                            $("#BILLING_NUMBER").parent().parent().css("display", "none");
                            $("#SERVICE_REQUESTED").parent().parent().css("display", "none");
                            $("#SIGNATURE_REQUIRED").parent().parent().css("display", "none");
                            $("#SERVICE_REQUESTED1").parent().parent().css("display", "none");
                            $("#COURIER1").parent().parent().css("display", "none");
                            $("#SITE_FOR_PICKUP").parent().parent().css("display", "none");
                            $("#BILLING_NUMBER1").parent().parent().css("display", "none");


                        }

                    });
                });
            }

            /*-----------------------------------------------------Davast/transcript request---------------------------------------------*/

            if ((document.URL).includes("davast-transcript-request")) {
$("#accordianHidden").parent().parent().css("display", "none");
$("#rushValue").parent().parent().css("display", "none");
                $('#APPROVER').on('input', function() {

                    if ($(this).val().length > 0) {
                        $("#approvalReason").parent().parent().css("display", "block");
                    } else {
                        $("#approvalReason").parent().parent().css("display", "none");

                    }
                });
                
                
                	
				
				$(document).on("click", "[name='submit-btn']", function(e) 
{
					var rush=document.getElementById('rush').checked;
                	var transferredAccounts =document.getElementById('transferredAccounts').checked;
                	var site=$("#SITE").val();
                	var subjectLine="Davast or Transcript Report Request - "+ site+ " - ";
                	var rushValue="";
                	if(rush) {
            			subjectLine += "RUSH - ";
            			rushValue +="<br/>" +"RUSH REQUEST: Y";
            		} else {
            			rushValue += "<br/>" +"RUSH REQUEST: N";
            		}
            		
            		if(transferredAccounts) {
            			subjectLine += "TRANSFERRED - ";
            			rushValue += "<br/>" +"INCLUDE ALL TRANSFERRED ACCOUNTS AND FUNDS: Y"+"<br/>";
            		} else {
            			rushValue += "<br/>" +"INCLUDE ALL TRANSFERRED ACCOUNTS AND FUNDS: N"+"<br/>";
            		}
            		subjectLine+=returnUniqueAccountNumbers();
            		function returnUniqueAccountNumbers() {
            			var accountNumbers = new Array();

            			$("#devastaccountWrapper .accountTable input.accNum").each(function () {
            				if (this.value != "") {
            					accountNumbers.push((this).value);
            				}
            			});
            			
            			var uniqueAccountNumbers = new Array();
            			var numberOfAccounts = accountNumbers.length;
            			
            			for (var i=0; i<numberOfAccounts; i++) {
            				for(var j=i+1; j<numberOfAccounts; j++) {
            					if (accountNumbers[i] === accountNumbers[j]) {
            						j = ++i;
            					}
            				}
            				uniqueAccountNumbers.push(accountNumbers[i]);
            			}
            			
            			uniqueAccountNumbers = uniqueAccountNumbers.sort(function (a, b) {
            				return a-b;
            			});
            			return uniqueAccountNumbers.join(", ");
            		}
            			
            			

                	$("#rushValue").val(rushValue);
                	 $("#mailSubject").val(subjectLine);
	var checkbox1=document.getElementById('recipientdetails-item-6a774bad9a').hasAttribute('data-cmp-expanded');
	var checkbox2=document.getElementById('recipientdetails-item-d45f2ec336').hasAttribute('data-cmp-expanded');
	var checkbox3=document.getElementById('recipientdetails-item-47c0a64bde').hasAttribute('data-cmp-expanded');
	var checkbox4=document.getElementById('recipientdetails-item-24ef62a85b').hasAttribute('data-cmp-expanded');
	
	
	if(!checkbox1 && !checkbox2 && !checkbox3 && !checkbox4) {
		alert('Recipient is Required');
		(e).preventDefault();
        return false;
	}
	else
	{		
		var recipientErrorLines = "";
		var recipientDetails = "RECIPIENT INFO:"
		var recipientIndex = 1;
		window.deliveryCheck=e;
		$('[id^="recipientdetails"]').each(function() 
				{
				
					if($(this).attr('id')=='recipientdetails-item-6a774bad9a' || $(this).attr('id')=='recipientdetails-item-47c0a64bde' )
					{
						var attr = $(this).attr('data-cmp-expanded');
						var closestMail;
						var closestFax;				
						if (typeof attr !== 'undefined' && attr !== false && $(this).attr('id')!='recipientdetails-item-24ef62a85b') 
						{
							
							var recipientLabel = $(this).children().children().children().eq(0).text().trim();//get the label of the checked recipient							
							var mailCheck = $(this).children().eq(1).children().children().children().children().children().eq(0).attr('data-cmp-expanded');
							var faxCheck=$(this).children().eq(1).children().children().children().children().children().eq(1).attr('data-cmp-expanded');
							if(mailCheck != undefined)
							{
								closestMail = true;
							}
							else
							{
								closestMail = false;
							}
							if(faxCheck != undefined)
							{
								closestFax = true;
							}
							else
							{
								closestFax = false;
							}
							
							
							if (closestMail == false && closestFax == false) 
							{
										alert('DELIVERY METHOD(S) is Required');
										(window.deliveryCheck).preventDefault();
										return false;
								recipientErrorLines+=recipientLabel + "- DELIVERY METHOD(S)";
								
							}
							
							
							if (closestMail == true) 
							{ 
								
								var mailFieldValues= $(this).children().eq(1).children().children().children().children().children().eq(0);					
								var mailCompanyName = mailFieldValues.children().eq(1).children().children().children().eq(0).children().children().eq(1).val();
								
								var mailName = mailFieldValues.children().eq(1).children().children().children().eq(1).children().children().eq(1).val();
								
								var mailAddress1 = mailFieldValues.children().eq(1).children().children().children().eq(2).children().children().eq(1).val();
								
								var mailAddress2 = mailFieldValues.children().eq(1).children().children().children().eq(3).children().children().eq(0).val();
								
								var mailCity = mailFieldValues.children().eq(1).children().children().children().eq(4).children().children().eq(1).val();
								
								var mailState = mailFieldValues.children().eq(1).children().children().children().eq(5).children().children().eq(1).val();
								
								var mailZip = mailFieldValues.children().eq(1).children().children().children().eq(6).children().children().eq(1).val();
								
								
								var overNightCheck=mailFieldValues.children().eq(1).children().children().children().eq(7).children().children().attr('data-cmp-expanded');	
								var overNightFieldValues=mailFieldValues.children().eq(1).children().children().children().eq(7).children().children().children().eq(1).children().children().find('input[id="SERVICE"]')[0].checked;
								var mailOvernight ;
								if(overNightCheck != undefined)
								{
									mailOvernight=true;
								}
								else
								{
									mailOvernight = false;
								}
								
								
								var mailOvernightPriority =mailFieldValues.children().eq(1).children().children().children().eq(7).children().children().children().eq(1).children().children().find('input[id="SERVICE"]')[0].checked;
												
								var mailOvernightStandard = mailFieldValues.children().eq(1).children().children().children().eq(7).children().children().children().eq(1).children().children().find('input[id="SERVICE"]')[1].checked;
								
								var mailCarrier = mailFieldValues.children().eq(1).children().children().children().eq(7).children().children().children().eq(1).children().children().children().eq(2).children().children().eq(1).val();
								
								var mailBilling = mailFieldValues.children().eq(1).children().children().children().eq(7).children().children().children().eq(1).children().children().children().eq(3).children().children().eq(1).val();
								
								var mailOvernightSignature = mailFieldValues.children().eq(1).children().children().children().eq(7).children().children().children().eq(1).children().children().find('input[name="SIGNATUREREQUIRED"]')[0].checked;
								
								if(recipientLabel=="BROKER") {
									if (mailCompanyName.trim().length == 0) recipientErrorLines+=( "<br/>- " + recipientLabel + " - MAIL: FIRM NAME");
								}
								
								if (mailName.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: NAME";
								if (mailAddress1.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: ADDRESS";
								if (mailCity.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: CITY";
								if (mailState.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: STATE";
								if (mailZip.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: ZIP";
								if (mailOvernight == true) {
								
									if (!(mailOvernightPriority || mailOvernightStandard)) {
									  recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: SERVICE REQUESTED";
									}
									if (mailCarrier.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: CARRIER";
									if (mailBilling.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: BILLING #";
								}
							
							
								if(true)
								{
									recipientDetails += "<br/>_______________________________________________________________";
									recipientDetails += "<br/>" + recipientIndex.toString() + ". " + recipientLabel + " - MAIL";
									if (mailOvernight == true) 
										recipientDetails += " (OVERNIGHT)" 
									recipientDetails += "<br/>OWNER MAILING ADDRESS:";
									
									if(mailCompanyName.trim().length > 0) {
										recipientDetails += "<br/>" + mailCompanyName;	
									}
									recipientDetails += "<br/>" + mailName;
									recipientDetails += "<br/>" + mailAddress1;
									if ($.trim(mailAddress2).length > 0) 
										recipientDetails += "<br/>" + mailAddress2;
									recipientDetails += "<br/>" + mailCity + " " + mailState + ", " + mailZip;
									
									if (mailOvernight == true) {
										recipientDetails += "<br/><br/>OVERNIGHT DELIVERY OPTIONS:";
										var overNightDeliveryService = "";
										if(mailOvernightPriority) {
											overNightDeliveryService = "PRIORITY"
										} else if (mailOvernightStandard) {
											overNightDeliveryService = "STANDARD"
										}
										
										recipientDetails += "<br/>SERVICE REQUESTED:"+ overNightDeliveryService;
										recipientDetails += "<br/>CARRIER: " + mailCarrier;
										recipientDetails += "<br/>BILLING #: " + mailBilling;
										recipientDetails += "<br/>SIGNATURE REQUIRED: ";
										if (mailOvernightSignature == true) 
											recipientDetails += "Y";
										else 
											recipientDetails += "N";
									}
									recipientDetails += "<br/>";
									recipientIndex++;
									
									
								}
							}
							
							if (closestFax == true) 
							{ 
								var faxFieldValues= $(this).children().eq(1).children().children().children().children().children().eq(1);	
								
								var faxAttn = faxFieldValues.children().eq(1).children().children().children().eq(2).children().children().eq(1).val();
								
								var faxNumber = faxFieldValues.children().eq(1).children().children().children().eq(3).children().children().eq(1).val();
								
								var faxCompany = faxFieldValues.children().eq(1).children().children().children().eq(4).children().children().eq(1).val();
								
								var faxAssocName = faxFieldValues.children().eq(1).children().children().children().eq(6).children().children().eq(1).val();
								
								var faxAssocPhoneNumber = faxFieldValues.children().eq(1).children().children().children().eq(8).children().children().eq(1).val();
								
								var faxAssocExt = faxFieldValues.children().eq(1).children().children().children().eq(9).children().children().eq(1).val();
								
								var faxMessage = faxFieldValues.children().eq(1).children().children().children().eq(10).children().children().eq(1).val();
									
								if (faxAttn.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: ATTN";

								if (faxNumber.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: FAX #";
								
								if(recipientLabel=="BROKER") {
									if (faxNumber.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: FIRM NAME";
								}

								if (faxAssocName.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: ASSOCIATE NAME";
									
								if (faxAssocPhoneNumber.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: ASSOCIATE PHONE #";
									
								if (faxAssocExt.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: ASSOCIATE EXT";
									
								if (true) {
									recipientDetails += "<br/>_______________________________________________________________";
									recipientDetails += "<br/>" + recipientIndex.toString() + ". " + recipientLabel + " - FAX";
									recipientDetails += "<br/>TO:";
									recipientDetails += "<br/>ATTN: " + faxAttn;
									recipientDetails += "<br/>FAX #: " + faxNumber;
									if (faxCompany.trim().length > 0) {
										if(recipientLabel=="BROKER") {
											recipientDetails += "<br/>FIRM NAME: " + faxCompany;
										} else {
											recipientDetails += "<br/>COMPANY NAME: " + faxCompany;
										}
									}
										
									recipientDetails += "<br/><br/>FROM:";
									recipientDetails += "<br/>ASSOCIATE NAME: " + faxAssocName;
									recipientDetails += "<br/>ASSOCIATE PHONE #: " + faxAssocPhoneNumber;
									recipientDetails += "<br/>ASSOCIATE EXT: " + faxAssocExt;
									if (faxMessage.trim().length > 0) {
										recipientDetails += "<br/><br/>FAX MESSAGE:";
										recipientDetails += "<br/>" + faxMessage;
									}
											
									recipientDetails += "<br/>";
									recipientIndex++
								}
							}
						} 
					}
					
					if($(this).attr('id')=='recipientdetails-item-d45f2ec336')
					{
						var attr = $(this).attr('data-cmp-expanded');
						var closestMail;
						var closestFax;
						var recipientErrorLines;
						if (typeof attr !== 'undefined' && attr !== false && $(this).attr('id')!='recipientdetails-item-24ef62a85b') 
						{
							
							var recipientLabel = $(this).children().children().children().eq(0).text().trim();//get the label of the checked recipient	
							var mailCheck=$(this).children().eq(1).children().children().children().children().children().children().children().eq(0).attr('data-cmp-expanded');				
							var faxCheck=$(this).children().eq(1).children().children().children().children().children().children().children().eq(1).attr('data-cmp-expanded');				
							if(mailCheck != undefined)
							{
								closestMail = true;
							}
							else
							{
								closestMail = false;
							}
							if(faxCheck != undefined)
							{
								closestFax = true;
							}
							else
							{
								closestFax = false;
							}
							
							
							if (closestMail == false && closestFax == false) 
							{
								alert('Delivery Method is Required');
								(window.deliveryCheck).preventDefault();
								recipientErrorLines+=recipientLabel + "- DELIVERY METHOD(S)";
								return false;
								
							}
							
							
							if (closestMail == true) 
							{ 	
								
								var mailFieldValues= $(this).children().eq(1).children().children().children().children().children().eq(0).children().children().children().eq(1).children().children();					
								var mailCompanyName = mailFieldValues.children().eq(0).children().children().eq(1).val();
								
								var mailName = mailFieldValues.children().eq(1).children().children().eq(1).val();
								
								var mailAddress1 = mailFieldValues.children().eq(2).children().children().eq(1).val();
								
								var mailAddress2 = mailFieldValues.children().eq(3).children().children().eq(0).val();
								
								var mailCity = mailFieldValues.children().eq(4).children().children().eq(1).val();
								
								var mailState = mailFieldValues.children().eq(5).children().children().eq(1).val();
								
								var mailZip = mailFieldValues.children().eq(6).children().children().eq(1).val();
								
								
								var overNightCheck=mailFieldValues.children().eq(7).children().children().attr('data-cmp-expanded');	
								var overNightFieldValues=mailFieldValues.children().eq(7).children().children().children().eq(1).children().children().find('input[id="SERVICE"]')[0].checked;
								var mailOvernight ;
								if(overNightCheck != undefined)
								{
									mailOvernight=true;
								}
								else
								{
									mailOvernight = false;
								}
								
								
								var mailOvernightPriority =mailFieldValues.children().eq(7).children().children().children().eq(1).children().children().find('input[id="SERVICE"]')[0].checked;
													
								var mailOvernightStandard = mailFieldValues.children().eq(7).children().children().children().eq(1).children().children().find('input[id="SERVICE"]')[1].checked;
								
								var mailCarrier = mailFieldValues.children().eq(7).children().children().children().eq(1).children().children().children().eq(2).children().children().eq(1).val();
								
								var mailBilling = mailFieldValues.children().eq(7).children().children().children().eq(1).children().children().children().eq(3).children().children().eq(1).val();
								
								var mailOvernightSignature = mailFieldValues.children().eq(7).children().children().children().eq(1).children().children().find('input[name="SIGNATUREREQUIRED"]')[0].checked;
								
								if(recipientLabel=="BROKER") {
									if (mailCompanyName.trim().length == 0) recipientErrorLines+=( "<br/>- " + recipientLabel + " - MAIL: FIRM NAME");
								}
								
								if (mailName.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: NAME";
								if (mailAddress1.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: ADDRESS";
								if (mailCity.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: CITY";
								if (mailState.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: STATE";
								if (mailZip.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: ZIP";
								if (mailOvernight == true) {
								
									if (!(mailOvernightPriority || mailOvernightStandard)) {
									  recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: SERVICE REQUESTED";
									}
									if (mailCarrier.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: CARRIER";
									if (mailBilling.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - MAIL: BILLING #";
								}
								if(true)
								{
									recipientDetails += "<br/>_______________________________________________________________";
									recipientDetails += "<br/>" + recipientIndex.toString() + ". " + recipientLabel + " - MAIL";
									if (mailOvernight == true) 
										recipientDetails += " (OVERNIGHT)" 
									recipientDetails += "<br/>OWNER MAILING ADDRESS:";
									
									if(mailCompanyName.trim().length > 0) {
										recipientDetails += "<br/>" + mailCompanyName;	
									}
									recipientDetails += "<br/>" + mailName;
									recipientDetails += "<br/>" + mailAddress1;
									if ($.trim(mailAddress2).length > 0) 
										recipientDetails += "<br/>" + mailAddress2;
									recipientDetails += "<br/>" + mailCity + " " + mailState + ", " + mailZip;
									
									if (mailOvernight == true) {
										recipientDetails += "<br/><br/>OVERNIGHT DELIVERY OPTIONS:";
										var overNightDeliveryService = "";
										if(mailOvernightPriority) {
											overNightDeliveryService = "PRIORITY"
										} else if (mailOvernightStandard) {
											overNightDeliveryService = "STANDARD"
										}
										
										recipientDetails += "<br/>SERVICE REQUESTED:"+ overNightDeliveryService;
										recipientDetails += "<br/>CARRIER: " + mailCarrier;
										recipientDetails += "<br/>BILLING #: " + mailBilling;
										recipientDetails += "<br/>SIGNATURE REQUIRED: ";
										if (mailOvernightSignature == true) 
											recipientDetails += "Y";
										else 
											recipientDetails += "N";
									}
									recipientDetails += "<br/>";
									recipientIndex++;
									
									
								}
							}
							if (closestFax == true) 
							{ 
								
								var faxFieldValues= $(this).children().eq(1).children().children().children().children().children().children().children().eq(1);
								
								var faxAttn = faxFieldValues.children().eq(1).children().children().children().eq(2).children().children().eq(1).val();
								
								var faxNumber = faxFieldValues.children().eq(1).children().children().children().eq(3).children().children().eq(1).val();
								
								var faxCompany = faxFieldValues.children().eq(1).children().children().children().eq(4).children().children().eq(1).val();
								
								var faxAssocName = faxFieldValues.children().eq(1).children().children().children().eq(6).children().children().eq(1).val();
								
								var faxAssocPhoneNumber = faxFieldValues.children().eq(1).children().children().children().eq(8).children().children().eq(1).val();
								
								var faxAssocExt = faxFieldValues.children().eq(1).children().children().children().eq(9).children().children().eq(1).val();
								
								var faxMessage = faxFieldValues.children().eq(1).children().children().children().eq(10).children().children().eq(1).val();
									
								if (faxAttn.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: ATTN";

								if (faxNumber.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: FAX #";
								
								if(recipientLabel=="BROKER") {
									if (faxNumber.trim().length == 0) recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: FIRM NAME";
								}

								if (faxAssocName.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: ASSOCIATE NAME";
									
								if (faxAssocPhoneNumber.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: ASSOCIATE PHONE #";
									
								if (faxAssocExt.trim().length == 0) 
									recipientErrorLines += "<br/>- " + recipientLabel + " - FAX: ASSOCIATE EXT";
									
								if (true) {
									recipientDetails += "<br/>_______________________________________________________________";
									recipientDetails += "<br/>" + recipientIndex.toString() + ". " + recipientLabel + " - FAX";
									recipientDetails += "<br/>TO:";
									recipientDetails += "<br/>ATTN: " + faxAttn;
									recipientDetails += "<br/>FAX #: " + faxNumber;
									if (faxCompany.trim().length > 0) {
										if(recipientLabel=="BROKER") {
											recipientDetails += "<br/>FIRM NAME: " + faxCompany;
										} else {
											recipientDetails += "<br/>COMPANY NAME: " + faxCompany;
										}
									}
										
									recipientDetails += "<br/><br/>FROM:";
									recipientDetails += "<br/>ASSOCIATE NAME: " + faxAssocName;
									recipientDetails += "<br/>ASSOCIATE PHONE #: " + faxAssocPhoneNumber;
									recipientDetails += "<br/>ASSOCIATE EXT: " + faxAssocExt;
									if (faxMessage.trim().length > 0) {
										recipientDetails += "<br/><br/>FAX MESSAGE:";
										recipientDetails += "<br/>" + faxMessage;
									}
											
									recipientDetails += "<br/>";
									recipientIndex++
								}
							} 
						
						} 
					}
					if($(this).attr('id')=='recipientdetails-item-24ef62a85b')
					{ //validate Return To section if checked
							if($("#associate-initials").val().trim().length>0 && $("#mail-stop").val().trim().length>0)
							{							
								recipientDetails += "<br/>_______________________________________________________________";
								recipientDetails += "<br/>" + recipientIndex.toString() + ". RETURN TO:";
								recipientDetails += "<br/>ASSOCIATE INITIALS: " + $("#associate-initials").val().trim();
								recipientDetails += "<br/>MAIL STOP: " + $("#mail-stop").val().trim();
							}
						
					}
					
					$("#accordianHidden").val(recipientDetails);
				});
	}
	
});


            }

            /*---------------------------------------------------WEB RESOLUTION CHECKLIST(**)-----------------------------------------------------------------------------*/

            if ((document.URL).includes("web-resolution-case")) {
                $('input[name="onetimepasscode"]').parent().parent().css("display", "none");
                $("#repidsequence").parent().parent().css("display", "none");
                $("#clientaccrepid").parent().parent().css("display", "none");
                $("#clientaccvisionid").parent().parent().css("display", "none");
                $("#otherquickenturbohr").parent().parent().css("display", "none");
                $("#carrier").parent().parent().css("display", "none");
                $("#deliver").parent().parent().css("display", "none");

                $('select[name=WEBSITE]').change(function() {
                    $("select[name=WEBSITE] option:selected").each(function() {
                        if ($(this).val() == "Investor Website") {
                       
                            $('input[name="onetimepasscode"]').parent().parent().css("display", "block");
                            $("#repidsequence").parent().parent().css("display", "none");
                            $("#clientaccrepid").parent().parent().css("display", "none");
                            $("#clientaccvisionid").parent().parent().css("display", "none");
                            $("#otherquickenturbohr").parent().parent().css("display", "none");
                           

                            $('input[name="onetimepasscode"]').change(function() {
                                    
                        			if ($('input[name="onetimepasscode"]')[0].checked) {
                           				$("#carrier").parent().parent().css("display", "block");
                						$("#deliver").parent().parent().css("display", "block");
                        			}
                                    if (!$('input[name="onetimepasscode"]')[0].checked) {
                                        $("#carrier").parent().parent().css("display", "none");
                						$("#deliver").parent().parent().css("display", "none");
                                        $("#deliver").val('');
                                        $("#carrier").val('');
                                    }                                
                            });


                        } else if ($(this).val() == "Advisor Website") {
                            $('input[name="onetimepasscode"]').parent().parent().css("display", "none");
                            $('input[name="onetimepasscode"]').removeAttr('checked');
                            $("#repidsequence").parent().parent().css("display", "block");
                            $("#clientaccrepid").parent().parent().css("display", "none");
                            $("#clientaccvisionid").parent().parent().css("display", "none");
                            $("#otherquickenturbohr").parent().parent().css("display", "none");
                            $("#carrier").parent().parent().css("display", "none");
                			$("#deliver").parent().parent().css("display", "none");
                            $("#deliver").val('');
                            $("#carrier").val('');

                        } else if ($(this).val() == "Client Accounts" || $(this).val() == "DST Vision") {
                            $('input[name="onetimepasscode"]').parent().parent().css("display", "none");
                            $('input[name="onetimepasscode"]').removeAttr('checked');
                            $("#repidsequence").parent().parent().css("display", "none");
                            $("#clientaccrepid").parent().parent().css("display", "block");
                            $("#clientaccvisionid").parent().parent().css("display", "block");
                            $("#otherquickenturbohr").parent().parent().css("display", "none");
                            $("#carrier").parent().parent().css("display", "none");
                			$("#deliver").parent().parent().css("display", "none");
                            $("#deliver").val('');
                            $("#carrier").val('');

                        } else if ($(this).val() == "Other (e.g., Quicken, Turbo Tax, HR Block)") {
                            $('input[name="onetimepasscode"]').parent().parent().css("display", "none");
                            $('input[name="onetimepasscode"]').removeAttr('checked');
                            $("#repidsequence").parent().parent().css("display", "none");
                            $("#clientaccrepid").parent().parent().css("display", "none");
                            $("#clientaccvisionid").parent().parent().css("display", "none");
                            $("#otherquickenturbohr").parent().parent().css("display", "block");
                            $("#carrier").parent().parent().css("display", "none");
                			$("#deliver").parent().parent().css("display", "none");
                            $("#deliver").val('');
                            $("#carrier").val('');

                        }
                        
                    });
                });

            }

            /*---------------------------------------------------TRAC Web Resolution Checklist-----------------------------------------------------------------------------*/

            if ((document.URL).includes("trac-web-resolution-checklist0")) {

                $("#helpdeskMemberInitials").parent().parent().css("display", "none");

                $('input[name="hidhelpdesk"]').change(function() {
                    $('input[name="hidhelpdesk"]:checked').each(function() {
                        if ($('input[name="hidhelpdesk"]:checked').val() == "Yes") {
                            $("#helpdeskMemberInitials").parent().parent().css("display", "block");
                        } else if ($('input[name="hidhelpdesk"]:checked').val() == "No") {
                            $("#helpdeskMemberInitials").parent().parent().css("display", "none");
                        }

                    });
                });
            }
 /*---------------------------------------------------TRAC/OGI WEB RESOLUTION CHECKLIST-----------------------------------------------------------------------------*/

            if ((document.URL).includes("trac-ogi-web-resolution-checklist")) {

                $("#SSNBODY").parent().parent().css("display", "none");
                $("#REMAININGHIDDENBODY").parent().parent().css("display", "none");
                $("#PAYROLLBODY").parent().parent().css("display", "none");
                $("#OTHERBROWSERBODY").parent().parent().css("display", "none");
                $("#OTHEROPERBODY").parent().parent().css("display", "none");
                $("#VERSIONBODY").parent().parent().css("display", "none");

                $("#sumdisp").css("display", "none");
                $("#accountTable").css("width", "100%");
                $("#accountTable1").css("width", "90%");
                $("#accountTable2").css("width", "100%");

                $("#totaldisp").css("display", "none");
                $("#sum1disp").css("display", "none");
                $("#sum1disp").remove();
                $("#COMPLETETASK").attr("title", "30 lines maximum");
                $("#EXATSTEPS").attr("title", "30 lines maximum");
                $("#CODEANDMESSAGE").attr("title", "30 lines maximum");
                $("#DEPARTMENT-2").attr("title", "30 lines maximum");
                $("#TROUBLESHOOT").attr("title", "30 lines maximum");

                $("#OGIID").attr("maxlength", "12");
                $("#ACCOUNT").mask("000000000000");
                $("#OGIID").parent().parent().css("display", "none");
                $("#ACCOUNT").parent().parent().css("display", "none");
                $("#SSN-1").parent().parent().css("display", "none");
                $('select[name=PAYROLLPROCESS]').parent().parent().css("display", "none");

                $("#accountTable").parent().parent().parent().css("display", "none");

                $("#accountTable1").parent().parent().parent().css("display", "none");

                $("#OTHERBROWSER").parent().parent().css("display", "none");
                $("#OTHEROPERSYSTEM").parent().parent().css("display", "none");




                $('select[name=WEBSITE]').change(function() {
                    $("select[name=WEBSITE] option:selected").each(function() {
                        if ($(this).val() == "OGI Website") {
                            $("#OGIID").parent().parent().css("display", "block");
                            $("#ACCOUNT").parent().parent().css("display", "block");
                            $('select[name=PAYROLLPROCESS]').parent().parent().css("display", "none");
                            $("#SSN-1").parent().parent().css("display", "none");
                            $("#accountTable1").parent().parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "block");

                        } else if ($(this).val() == "TRAC Plan Sponsor Website") {
                            $("#OGIID").parent().parent().css("display", "none");
                            $("#ACCOUNT").parent().parent().css("display", "none");
                            $('select[name=PAYROLLPROCESS]').parent().parent().css("display", "block");
                            $("#SSN-1").parent().parent().css("display", "block");
                            $("#accountTable1").parent().parent().parent().css("display", "block");

                            $("#accountTable").parent().parent().parent().css("display", "none");



                        } else if ($(this).val() == "TRAC Participant Website") {
                            $("#OGIID").parent().parent().css("display", "none");
                            $("#ACCOUNT").parent().parent().css("display", "none");
                            $('select[name=PAYROLLPROCESS]').parent().parent().css("display", "none");
                            $("#SSN-1").parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "none");

                            $("#accountTable1").parent().parent().parent().css("display", "none");


                        }
                    });
                });

                $('select[name=OPERATINGSYSTEM]').change(function() {
                    $("select[name=OPERATINGSYSTEM] option:selected").each(function() {
                        if ($(this).val() == "Other") {
                            $("#OTHEROPERSYSTEM").parent().parent().css("display", "block");

                        } else if ($(this).val() == "MAC OS" || $(this).val() == "Windows")

                        {

                            $("#OTHEROPERSYSTEM").parent().parent().css("display", "none");

                        }

                    });
                });

                $('select[name=BROWSER]').change(function() {
                    $("select[name=BROWSER] option:selected").each(function() {
                        if ($(this).val() == "Other") {
                            $("#OTHERBROWSER").parent().parent().css("display", "block");

                        } else if ($(this).val() == "Firefox" || $(this).val() == "Internet Explorer" || $(this).val() == "Safari" || $(this).val() == "Chrome")

                        {

                            $("#OTHERBROWSER").parent().parent().css("display", "none");

                        }

                    });
                });

                $(document).on("click", "[name='submit-btn']", function() {
                    var remainingbody;
                    if ($("#SSN-1").val().length > 0) {
                        var ssnBody = "<br/>SSN:  XXX-XX- " + $("#SSN-1").val();
                        $("#SSNBODY").val(ssnBody);
                    }
                    if ($("#OGIID").val().length > 0) {
                        remainingbody = "OGI ID #: " + $("#OGIID").val() + "<br/>";

                    }
                    if ($("#ACCOUNT").val().length > 0) {
                        remainingbody += "ACCOUNT #: " + $("#ACCOUNT").val() + "<br/>";
                    }
                    if ($("#PAYROLLPROCESS").val() != null) {
                        var payBody = "<br/>METHOD PAYROLL WAS PROCESSED: " + $("#PAYROLLPROCESS").val();
                        $("#PAYROLLBODY").val(payBody);
                    }
                    if ($("#OTHERBROWSER").val().length > 0) {
                        var otherbrowserBody = "OTHER BROWSER:" + $("#OTHERBROWSER").val();
                        $("#OTHERBROWSERBODY").val(otherbrowserBody);
                    }
                    if ($("#OTHEROPERSYSTEM").val().length > 0) {
                        var otherbrowBody = "OTHER OPERATING SYSTEM:" + $("#OTHEROPERSYSTEM").val();
                        $("#OTHEROPERBODY").val(otherbrowBody);
                    }
                    if ($("#BROWSERVERSION").val().length > 0) {
                        var versionBody = "BROWSER VERSION : " + $("#BROWSERVERSION").val();
                        $("#VERSIONBODY").val(versionBody);
                    }
                    $("#REMAININGHIDDENBODY").val(remainingbody)
                });

            }




            /*------------------------------------------------FD - MULTIFUND RPE Notification / Future Date Request Form -------------------------------------------*/

            if ((document.URL).includes("fd-multifund-rpe-notification-future-date-request-form")) {

                $("#sumdisp").css("display", "none");
                $("#accountTable").css("width", "100%");

                $('input[name="rpaproc"]').parent().parent().parent().css("display", "none");
                $('input[name="loantypeRadio"]').parent().parent().parent().css("display", "none");
                $('input[name="currchecked"]').parent().parent().parent().css("display", "none");
                $("#sep2").parent().css("display", "none");
                $('input[name="currchecked1"]').parent().parent().parent().css("display", "none");
                $("#numdays").parent().parent().css("display", "none");
                $("#calcbtn").css("display", "none");
                $("#sep3").parent().css("display", "none");
                $('select[name=prevdef]').parent().parent().css("display", "none");
                $('select[name=newdef]').parent().parent().css("display", "none");
                $("#sep4").parent().css("display", "none");
                $("#map").parent().css("display", "none");
                $("#planid1").parent().parent().css("display", "none");
                $("#planname1").parent().parent().css("display", "none");
                $('select[name=fsc]').parent().parent().css("display", "none");
                $('select[name=tsc]').parent().parent().css("display", "none");
                $('input[name="liketolike"]').parent().parent().parent().css("display", "none");
                $("#dy1").parent().css("display", "none");
                $("#dy2").parent().css("display", "none");
                $("#exyesn").parent().css("display", "none");
                $('input[name="expyesnoRadio"]').parent().parent().parent().css("display", "none");
                $("#sep5").parent().css("display", "none");
                $("#worktype").parent().parent().css("display", "none");
                $("#effdate").parent().parent().css("display", "none");
                $("#edate").parent().css("display", "none");
                $("#edate2").parent().css("display", "none");
                $("#tradedt").parent().parent().css("display", "none");
                $("#tdate").parent().css("display", "none");

                $("#accountTable").parent().parent().parent().css("display", "none");

                $("#exyesn1").parent().css("display", "none");
                $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "none");

                $("#the").parent().css("display", "none");

                for (var i = 0; i <= 8; ++i) {
                    $('#AddFundsBtn').click();
                }
				$(document).on('change', '[id="liketolike"]', function () {
					
					$(document).on('change', '[id^="from"]', function () {
						if ($("[name='liketolike']")[0].checked) 
						{	
							
							var valueIs=$(this).val();
							var valueFrom=$(this).parent().parent().parent().parent().parent().children().eq(2).children().children().children().children().eq(1);
							valueFrom.val(valueIs)
							
						}
					});
				});

                $('select[name=reqtype]').change(function() {
                    $("select[name=reqtype] option:selected").each(function() {
                        if ($(this).val() == "Money Type Change") {
                            alert('Please provide the contribution formula in the Comments section when adding SHNE, SHM, and/or Purchase Money.');
                            $('input[name="rpaproc"]').parent().parent().parent().css("display", "none");
                            $('input[name="loantypeRadio"]').parent().parent().parent().css("display", "none");
                            $('input[name="currchecked"]').parent().parent().parent().css("display", "none");
                            $("#sep2").parent().css("display", "none");
                            $('input[name="currchecked1"]').parent().parent().parent().css("display", "none");
                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none");
                            $("#sep3").parent().css("display", "none");
                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");
                            $("#sep4").parent().css("display", "none");
                            $("#map").parent().css("display", "none");
                            $("#planid1").parent().parent().css("display", "none")
                            $("#planname1").parent().parent().css("display", "none")
                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="liketolike"]').parent().parent().parent().css("display", "none");
                            $("#dy1").parent().css("display", "none");
                            $("#dy2").parent().css("display", "none");
                            $("#exyesn").parent().css("display", "none");
                            $('input[name="expyesnoRadio"]').parent().parent().parent().css("display", "none");
                            $("#sep5").parent().css("display", "none");
                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("value", "");
                            $("#worktype").prop("disabled", true);
                            $("#effdate").parent().parent().css("display", "none");
                            $("#edate").parent().css("display", "none");
                            $("#edate2").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");
                            $("#tdate").parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "none");

                            $("#exyesn1").parent().css("display", "none");
                            $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "none");
                            $("#the").parent().css("display", "none");

                        } else if ($(this).val() == "Printed Fee Disclosure Order" || $(this).val() == "Vesting Schedule Change" || $(this).val() == "Other") {
                            $('input[name="rpaproc"]').parent().parent().parent().css("display", "none");
                            $('input[name="loantypeRadio"]').parent().parent().parent().css("display", "none");
                            $('input[name="currchecked"]').parent().parent().parent().css("display", "none");
                            $("#sep2").parent().css("display", "none");
                            $('input[name="currchecked1"]').parent().parent().parent().css("display", "none");
                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none");
                            $("#sep3").parent().css("display", "none");
                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");
                            $("#sep4").parent().css("display", "none");
                            $("#map").parent().css("display", "none");
                            $("#planid1").parent().parent().css("display", "none")
                            $("#planname1").parent().parent().css("display", "none")
                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="liketolike"]').parent().parent().parent().css("display", "none");
                            $("#dy1").parent().css("display", "none");
                            $("#dy2").parent().css("display", "none");
                            $("#exyesn").parent().css("display", "none");
                            $('input[name="expyesnoRadio"]').parent().parent().parent().css("display", "none");
                            $("#sep5").parent().css("display", "none");
                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("value", "");
                            $("#worktype").prop("disabled", true);
                            $("#effdate").parent().parent().css("display", "none");
                            $("#edate").parent().css("display", "none");
                            $("#edate2").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");
                            $("#tdate").parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "none");

                            $("#exyesn1").parent().css("display", "none");
                            $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");

                        } else if ($(this).val() == "Investment Option Add - No Mapping" || $(this).val() == "Investment Option Remove - No Mapping") {
                            $('input[name="rpaproc"]').parent().parent().parent().css("display", "none");
                            $('input[name="loantypeRadio"]').parent().parent().parent().css("display", "none");
                            $('input[name="currchecked"]').parent().parent().parent().css("display", "none");
                            $("#sep2").parent().css("display", "none");
                            $('input[name="currchecked1"]').parent().parent().parent().css("display", "none");
                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none");
                            $("#sep3").parent().css("display", "none");
                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");
                            $("#sep4").parent().css("display", "none");
                            $("#map").parent().css("display", "none");
                            $("#planid1").parent().parent().css("display", "none")
                            $("#planname1").parent().parent().css("display", "none")
                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="liketolike"]').parent().parent().parent().css("display", "none");
                            $("#dy1").parent().css("display", "none");
                            $("#dy2").parent().css("display", "none");
                            $("#exyesn").parent().css("display", "none");
                            $('input[name="expyesnoRadio"]').parent().parent().parent().css("display", "none");
                            $("#sep5").parent().css("display", "none");
                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("value", "");
                            $("#worktype").prop("disabled", true);
                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "none");
                            $("#edate2").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");
                            $("#tdate").parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "none");

                            $("#exyesn1").parent().css("display", "none");
                            $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");

                        } else if ($(this).val() == "Investment Option Change - Mapping - Unit Class Change") {
                            $('input[name="rpaproc"]').parent().parent().parent().css("display", "block");
                            $('input[name="loantypeRadio"]').parent().parent().parent().css("display", "none");
                            $('input[name="currchecked"]').parent().parent().parent().css("display", "none");
                            $("#sep2").parent().css("display", "none");
                            $('input[name="currchecked1"]').parent().parent().parent().css("display", "none");
                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none");
                            $("#sep3").parent().css("display", "none");
                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");
                            $("#sep4").parent().css("display", "none");
                            $("#map").parent().css("display", "block");
                            $("#planid1").parent().parent().css("display", "block");
                            $("#planname1").parent().parent().css("display", "block");
                            $('select[name=fsc]').parent().parent().css("display", "block");
                            $('select[name=tsc]').parent().parent().css("display", "block");
                            $('input[name="liketolike"]').parent().parent().parent().css("display", "block");
                            $("#dy1").parent().css("display", "block");
                            $("#dy2").parent().css("display", "block");
                            $("#exyesn").parent().css("display", "block");
                            $('input[name="expyesnoRadio"]').parent().parent().parent().css("display", "block");
                            $("#sep5").parent().css("display", "block");
                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").val("Fin Plan Maint");
                            $("#worktype").focus();
                            $("#worktype").prop("disabled", true);
                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "block");
                            $("#edate2").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "block");
                            $("#tdate").parent().css("display", "block");

                            $("#accountTable").parent().parent().parent().css("display", "block");

                            $("#exyesn1").parent().css("display", "none");
                            $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $('#expyesnoRadio1').removeAttr('checked');

                            $('input[name="expyesnoRadio"]').change(function() {
                                $('input[name="expyesnoRadio"]:checked').each(function() {
                                    if ($(this).val() == "Yes") {
                                        $("#exyesn1").parent().css("display", "none");
                                        $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "none");


                                        $('input[name="expyesnoRadio1"]').prop('checked', false);


                                    } else if ($(this).val() == "No") {
                                        $("#exyesn1").parent().css("display", "block");
                                        $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "block");


                                        $('input[name="expyesnoRadio1"]').prop('checked', false);

                                    }

                                });
                            });



                            /* ------- Adding changes for datepicker ---- */

                            function pastDays(theDate, days) {
                                var day = new Date(theDate).getUTCDay();
                                if (day == 2) {
                                    days = 3;
                                }

                                return new Date(theDate.getTime() - days * 24 * 60 * 60 * 1000);

                            }

                            function minDays(theDate, days) {
                                return new Date(theDate.getTime() - days * 24 * 60 * 60 * 1000);
                            }

                            function maxDays(theDate, days) {
                                return new Date(theDate.getTime() + days * 24 * 60 * 60 * 1000);
                            }

                            var newDate = pastDays(new Date(), 1);
                            var minDate = minDays(new Date(), 5).toISOString().substring(0, 10);
                            var maxDate = maxDays(new Date(), 5).toISOString().substring(0, 10);
                            var finalDate = newDate.toISOString().substring(0, 10);
                            var field = document.querySelector('#effdate');
                            field.value = finalDate;
                            field.setAttribute("min", minDate);
                            field.setAttribute("max", maxDate);


                            function noWeekends(e) {

                                var day = new Date(e.target.value).getUTCDay();
                                if (day == 0 || day == 6) {


                                    e.preventDefault();
                                    this.value = '';


                                }

                            }
                            var dateField = document.querySelector('#tradedt');
                            dateField.addEventListener('input', noWeekends);


                        } else if ($(this).val() == "Investment Option Change - Mapping - Inv Opt Replacement")

                        {

                            $('input[name="rpaproc"]').parent().parent().parent().css("display", "block");
                            $('input[name="loantypeRadio"]').parent().parent().parent().css("display", "none");
                            $('input[name="currchecked"]').parent().parent().parent().css("display", "none");
                            $("#sep2").parent().css("display", "none");
                            $('input[name="currchecked1"]').parent().parent().parent().css("display", "none");
                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none");
                            $("#sep3").parent().css("display", "none");
                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");
                            $("#sep4").parent().css("display", "none");
                            $("#map").parent().css("display", "block");
                            $("#planid1").parent().parent().css("display", "block");
                            $("#planname1").parent().parent().css("display", "block");
                            $('select[name=fsc]').parent().parent().css("display", "block");
                            $('select[name=tsc]').parent().parent().css("display", "block");
                            $('input[name="liketolike"]').parent().parent().parent().css("display", "block");
                            $("#dy1").parent().css("display", "block");
                            $("#dy2").parent().css("display", "block");
                            $("#exyesn").parent().css("display", "none");
                            $('input[name="expyesnoRadio"]').parent().parent().parent().css("display", "none");
                            $("#sep5").parent().css("display", "block");
                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").val("Fin Plan Maint");
                            $("#worktype").focus();
                            $("#worktype").prop("disabled", true);
                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "block");
                            $("#edate2").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "block");
                            $("#tdate").parent().css("display", "block");

                            $("#accountTable").parent().parent().parent().css("display", "block");

                            $("#exyesn1").parent().css("display", "none");
                            $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");


                            /* ------- Adding changes for datepicker ---- */

                            function pastDays(theDate, days) {
                                var day = new Date(theDate).getUTCDay();
                                if (day == 2) {
                                    days = 3;
                                }

                                return new Date(theDate.getTime() - days * 24 * 60 * 60 * 1000);

                            }

                            function minDays(theDate, days) {
                                return new Date(theDate.getTime() - days * 24 * 60 * 60 * 1000);
                            }

                            function maxDays(theDate, days) {
                                return new Date(theDate.getTime() + days * 24 * 60 * 60 * 1000);
                            }

                            var newDate = pastDays(new Date(), 1);
                            var minDate = minDays(new Date(), 5).toISOString().substring(0, 10);
                            var maxDate = maxDays(new Date(), 5).toISOString().substring(0, 10);
                            var finalDate = newDate.toISOString().substring(0, 10);
                            var field = document.querySelector('#effdate');
                            field.value = finalDate;
                            field.setAttribute("min", minDate);
                            field.setAttribute("max", maxDate);


                            function noWeekends(e) {

                                var day = new Date(e.target.value).getUTCDay();
                                if (day == 0 || day == 6) {


                                    e.preventDefault();
                                    this.value = '';


                                }

                            }
                            var dateField = document.querySelector('#tradedt');
                            dateField.addEventListener('input', noWeekends);


                        } else if ($(this).val() == "Default Investment Option Change - No Mapping") {

                            $('input[name="rpaproc"]').parent().parent().parent().css("display", "none");
                            $('input[name="loantypeRadio"]').parent().parent().parent().css("display", "none");
                            $('input[name="currchecked"]').parent().parent().parent().css("display", "none");
                            $("#sep2").parent().css("display", "none");
                            $('input[name="currchecked1"]').parent().parent().parent().css("display", "none");
                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none");
                            $("#sep3").parent().css("display", "none");
                            $('select[name=prevdef]').parent().parent().css("display", "block");
                            $('select[name=newdef]').parent().parent().css("display", "block");
                            $("#sep4").parent().css("display", "block");
                            $("#map").parent().css("display", "none");
                            $("#planid1").parent().parent().css("display", "none")
                            $("#planname1").parent().parent().css("display", "none")
                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="liketolike"]').parent().parent().parent().css("display", "none");
                            $("#dy1").parent().css("display", "none");
                            $("#dy2").parent().css("display", "none");
                            $("#exyesn").parent().css("display", "none");
                            $('input[name="expyesnoRadio"]').parent().parent().parent().css("display", "none");
                            $("#sep5").parent().css("display", "none");
                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").val("Fin Plan Maint");
                            $("#worktype").focus();
                            $("#worktype").prop("disabled", true);
                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "none");
                            $("#edate2").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");
                            $("#tdate").parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "none");

                            $("#exyesn1").parent().css("display", "none");
                            $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");


                        } else if ($(this).val() == "Loan Provision Add / Remove") {
                            $('input[name="rpaproc"]').parent().parent().parent().css("display", "none");
                            $('input[name="loantypeRadio"]').parent().parent().parent().css("display", "block");
                            $('input[name="currchecked"]').parent().parent().parent().css("display", "block");
                            $("#sep2").parent().css("display", "block");
                            $('input[name="currchecked1"]').parent().parent().parent().css("display", "block");
                            $("#numdays").parent().parent().css("display", "block");
                            $("#calcbtn").css("display", "block");
                            $("#sep3").parent().css("display", "none");
                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");
                            $("#sep4").parent().css("display", "none");
                            $("#map").parent().css("display", "none");
                            $("#planid1").parent().parent().css("display", "none")
                            $("#planname1").parent().parent().css("display", "none")
                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="liketolike"]').parent().parent().parent().css("display", "none");
                            $("#dy1").parent().css("display", "none");
                            $("#dy2").parent().css("display", "none");
                            $("#exyesn").parent().css("display", "none");
                            $('input[name="expyesnoRadio"]').parent().parent().parent().css("display", "none");
                            $("#sep5").parent().css("display", "block");
                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").val("Fin Plan Maint");
                            $("#worktype").focus();
                            $("#worktype").prop("disabled", true);
                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "none");
                            $("#edate2").parent().css("display", "block");
                            $("#tradedt").parent().parent().css("display", "none");
                            $("#tdate").parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "none");

                            $("#exyesn1").parent().css("display", "none");
                            $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display", "none");
                            $("#the").parent().css("display", "block");



                            $("#currchecked").click(function(event) {
                                if ($(this).is(":checked")) {
                                    $("#the").parent().css("display", "none");
                                    $("#sep2").parent().css("display", "none");
                                    $('input[name="currchecked1"]').parent().parent().parent().css("display", "none");
                                    $("#numdays").parent().parent().css("display", "none");
                                    $("#calcbtn").css("display", "none");
                                    $("#effdate").prop("value", currDate());

                                    function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

                                        var today = new Date();
                                        var month = today.getMonth() + 1;
                                        if (month < 10) {
                                            month = "0" + month;
                                        }
                                        var day = today.getDate();
                                        if (day < 10) {
                                            day = "0" + day;
                                        }
                                        var year = today.getFullYear();
                                        var dateString = year + "-" + month + "-" + day;
                                        return dateString;
                                    }

                                } else {
                                    $("#the").parent().css("display", "block");
                                    $('input[name="currchecked1"]').parent().parent().parent().css("display", "block");
                                    $("#numdays").parent().parent().css("display", "block");
                                    $("#calcbtn").css("display", "block");
                                    $("#sep2").parent().css("display", "block");

                                    $("#effdate").prop("value", "");
                                }
                            });



                            $("#currchecked1").click(function(event) {
                                if ($(this).is(":checked")) {
                                    $("#the").parent().css("display", "none");


                                    $("#numdays").parent().parent().css("display", "none");
                                    $("#calcbtn").css("display", "none");

                                    alert('Please select the Effective Date.');
                                } else {
                                    $("#the").parent().css("display", "block");

                                    $("#numdays").parent().parent().css("display", "block");
                                    $("#calcbtn").css("display", "block");

                                }
                            });


                        }

                    });
                });
            }



            /*------------------------------------------------SYSTEM ENHANCEMENT REQUEST -------------------------------------------*/

            if ((document.URL).includes("system-enhancement-request")) {

                $("#SYSTEMHIDDEN").parent().parent().css("display", "none");
                $("#DESCRIPTION").attr("title", "30 lines maximum");
                $("#EXPECTEDRESULTS").attr("title", "30 lines maximum");
                $("#OTHERMETHODSATTEMPTED").attr("title", "30 lines maximum");

                $("#Other_text").parent().parent().css("display", "none");


                $('input[name="SHARE-Mail-Mode"]').change(function() {
                    $('input[name="SHARE-Mail-Mode"]').each(function() {
                        if ($("[name='SHARE-Mail-Mode']")[5].checked) {
                            $("#Other_text").parent().parent().css("display", "block");
                        }
                        if (!$("[name='SHARE-Mail-Mode']")[5].checked) {
                            $("#Other_text").parent().parent().css("display", "none");
                        }

                    });
                });
                $(document).on("click", "[name='submit-btn']", function() {
                    var arr = new Array();
                    for (var i = 0; i < 6; ++i) {
                        if ($("[name='SHARE-Mail-Mode']")[i].checked) {
                            if ($("[name='SHARE-Mail-Mode']")[i].value != undefined) {
                                arr.push($("[name='SHARE-Mail-Mode']")[i].value.trim());
                            }
                        }
                    }
                    var impactedSystem = arr.join(",  ");
                    if ($("[name='SHARE-Mail-Mode']")[5].checked) {
                        impactedSystem += "-" + $("#Other_text").val();
                    }
                    $("#SYSTEMHIDDEN").val(impactedSystem);
                    var subjectLine = "System Enhancement Request  - " + $("#SITE").val() + " - " + $("#DEPARTMENT").val() + " -  " + impactedSystem;
                    $("#mailSubject").val(subjectLine);
                });

            }

            /*------------------------------------------------BIRG Referral Form -------------------------------------------*/

            if ((document.URL).includes("birg-referral-form")) {
                $("#originHidden").parent().parent().css("display", "none");
                $("#WorkHidden").parent().parent().css("display", "none");
                $("#Workstream").parent().parent().css("display", "none");
                $('select[name=Dept]').change(function() {
                $("select[name=Dept] option:selected").each(function() {
                    if ($(this).val() == "SHSV") {
                    	$("#Workstream").parent().parent().css("display", "block");	
                    }else{$("#Workstream").parent().parent().css("display", "none");}
                });
                });
                var originationCheckbx = new Array(0);
                $(document).on("click", "[name='submit-btn']", function() {
                    if ($("[name='origination']")[0].checked) {
                        originationCheckbx.push($("[name='origination']")[0].value);
                    }
                    if ($("[name='origination']")[1].checked) {
                        originationCheckbx.push($("[name='origination']")[1].value);
                    }
                    if ($("[name='origination']")[2].checked) {
                        originationCheckbx.push($("[name='origination']")[2].value);
                    }
                    var originationCheckbxVal = originationCheckbx.join(",");
                    $("#originHidden").val(originationCheckbxVal);
                    var work = '';
                    if ($("#Workstream").val() != null) {
                        work = "Associate Workstream: " + $("#Workstream").val() + '<br/><br/>';
                    }
                    $("#WorkHidden").val(work)

                });
            }
            /*---------------------------------------------------Adviser Locator Request -----------------------------------------------------------------------------*/


            if ((document.URL).includes("adviser-locator-request-form")) {
                $("#SPECIALINSTRUCTIONS").attr("title", "30 lines maximum");
                $("#callerBody").parent().parent().css("display", "none");
                $("#addressBody").parent().parent().css("display", "none");
                $("#subjectLineBody").parent().parent().css("display", "none");
                $("#shareholderBody").parent().parent().css("display", "none");
                $("#accountBody").parent().parent().css("display", "none");

                $('input[name=shareholderTypeVerification]').parent().parent().css("display", "none");
                $('input[name=shareholderTypeVerification2]').parent().parent().css("display", "none");
                $("#ACCOUNT").parent().parent().css("display", "none");

                $("#acTypeOtherText").prop("disabled", true);

                $("#sample2").parent().css("display", "none");
                $("#planTypeDetails").parent().parent().css("display", "none");

                $("#L1").parent().css("display", "none");
                $("#L2").parent().css("display", "none");


                $('select[name=SHAREHOLDERTYPE]').change(function() {
                    $("select[name=SHAREHOLDERTYPE] option:selected").each(function() {
                        if ($(this).val() == "ps") {
                            $('input[name=shareholderTypeVerification]').parent().parent().css("display", "block");
                            $('input[name=shareholderTypeVerification2]').parent().parent().css("display", "none");
                            $("#ACCOUNT").parent().parent().css("display", "none");

                        } else if ($(this).val() == "os") {
                            $('input[name=shareholderTypeVerification2]').parent().parent().css("display", "block");
                            $('input[name=shareholderTypeVerification]').parent().parent().css("display", "none");
                            $("#ACCOUNT").parent().parent().css("display", "block");

                        }

                    });
                });

                $('input[name=ACCOUNTTYPES1]').change(function() {
                    $("input[name=ACCOUNTTYPES1]").each(function() {
                        if ($("[name='ACCOUNTTYPES1']")[2].checked) {

                            $("#planTypeDetails").parent().parent().css("display", "block");
                            $("#sample2").parent().css("display", "block");


                        } else {
                            $("#sample2").parent().css("display", "none");
                            $("#planTypeDetails").parent().parent().css("display", "none");

                        }

                    });
                });


                $('input[name=ACCOUNTTYPES1]').change(function() {
                    $("input[name=ACCOUNTTYPES1]").each(function() {
                        if ($("[name='ACCOUNTTYPES1']")[3].checked)

                        {
                            $("#acTypeOtherText").prop("disabled", false);

                        } else {
                            $("#acTypeOtherText").prop("disabled", true);
                        }

                    });
                });


                $("#L1").parent().css("display", "none");
                $("#L2").parent().css("display", "none");
                $('select[name=CALLERPREFERENCE]').change(function() {

                    $("select[name=CALLERPREFERENCE] option:selected").each(function() {
                        if ($(this).val() == "ps") {
                            $("#L1").parent().css("display", "block");
                            $("#L2").parent().css("display", "none");
                        } else if ($(this).val() == "os") {
                            $("#L1").parent().css("display", "none");
                            $("#L2").parent().css("display", "block");
                        }
                    });
                });

                 $(document).on("click", "[name='submit-btn']", function() {
                var cp = "";
				var sp = "";
				var accountVal = "";
				 if ($("#CALLERPREFERENCE").val() == "ps") {
                        cp = "THE ";
					if($("#SHAREHOLDERTYPE").val() == "ps") {
						cp+= "PROSPECTIVE SHAREHOLDER ";
					} else if($("#SHAREHOLDERTYPE").val() == "os") {
						cp+= "ORPHAN SHAREHOLDER ";
					}
					cp+= "WILL CONTACT THE ADVISER.<br/>WE DO NOT PROVIDE THE ADVISER WITH THEIR NAME OR PHONE NUMBER.";
				} else if($("#CALLERPREFERENCE").val() == "os") {
					cp = "THE ADVISER WILL CONTACT THE ";
					if($("#SHAREHOLDERTYPE").val() == "ps") {
						cp+= "PROSPECTIVE SHAREHOLDER ";
					} else if($("#SHAREHOLDERTYPE").val() == "os") {
						cp+= "ORPHAN SHAREHOLDER ";
					}
					cp+= "WE WILL PROVIDE THE ADVISER WITH THEIR NAME AND PHONE NUMBER.";
				}
				$("#callerBody").val(cp);
				 if ($("#ACCOUNT").val().trim().length > 0) {
                        accountVal = "ACCOUNT #: " + $("#ACCOUNT").val() + "<br/><br/>";
                    }
                    if ($("input[name='ACCOUNTTYPES1']")[0].checked) {
                        
                        accountVal += "<br/> MUTUAL FUNDS: Y";
                    }
                    if ($("input[name='ACCOUNTTYPES1']")[1].checked) {
                        
                        accountVal += "<br/> COLLEGEAMERICA: Y";
                    }
                    if ($("input[name='ACCOUNTTYPES1']")[2].checked) {
                        
                        accountVal += "<br/> ER SPONSORED RP: Y";
                        if ($("#planTypeDetails").val().length > 0) {
                            accountVal += "<br/><br/>PLAN TYPE/DETAILS:<br/>" + $("#planTypeDetails").val();
                        }
                    }
                     if ($("input[name='ACCOUNTTYPES1']")[3].checked) {
                        
                         accountVal += "<br/> OTHER: " + $("#acTypeOtherText").val();
                    }
                    
					$("#accountBody").val(accountVal);
					  if ($("#SHAREHOLDERTYPE").val() == "ps") {
                        sp = "PROSPECTIVE SHAREHOLDER: Y<br/>NO EXISTING ACCOUNT";
                    } else if ($("#SHAREHOLDERTYPE").val() == "os") {
                        sp = "ORPHAN SHAREHOLDER: Y<br/>NO ADVISORS ON EXISTING ACCOUNTS";
                    }
					 $("#shareholderBody").val(sp);
						 var address = $("#SALUTATION").val() + ". " + $("#name").val() + "<br/>" + $("#address1").val().trim();
                    if ($("#FORMATTEDADDRESS").val().trim().length > 0) address += "<br/>" + $("#FORMATTEDADDRESS").val().trim();
                    address += "<br/>" + $("#CITY").val().trim() + ", " + $("#STATE").val().trim() + "  " + $("#ZIP").val().trim();
						 $("#addressBody").val(address);


                    var subjectLine = "Adviser Locator Request Form - ";
                    subjectLine += $("#SITE").val() + " - " + $("#name").val();

                    $("#callerBody").val(cp);
                    $("#accountBody").val(accountVal);
                    $("#shareholderBody").val(sp);
                    $("#addressBody").val(address);
                    $("#mailSubject").val(subjectLine);

                });
            }


            /*------------------------------------------------------------COST BASIS REFERRAL----------------------------------------------------------------------------------*/

            if ((document.URL).includes("cost-basis-referral")) {


                $("#mailToArrayHidden").parent().parent().css("display", "none");
                $("#deliveryArrayHidden").parent().parent().css("display", "none");

                $("#rushBodyType").parent().parent().css("display", "none");
                $("#accBodyType").parent().parent().css("display", "none");
                $("#ADDRESS_DELIVERY2").parent().parent().css("display", "none");
                $("#FAX").parent().parent().css("display", "none");
                $("#ATTN").parent().parent().css("display", "none");
                $("#EMAIL").parent().parent().css("display", "none");



                $('input[name=DELIVERY_METHOD]').change(function() {
                    $("input[name=DELIVERY_METHOD]").each(function() {

                        if ($("[name='DELIVERY_METHOD']")[1].checked) {

                            $("#FAX").parent().parent().css("display", "block");
                            $("#ATTN").parent().parent().css("display", "block");
                        }
                        if ($("[name='DELIVERY_METHOD']")[2].checked) {

                            $("#EMAIL").parent().parent().css("display", "block");
                        }
                        if (!$("[name='DELIVERY_METHOD']")[1].checked) {

                            $("#FAX").parent().parent().css("display", "none");
                            $("#ATTN").parent().parent().css("display", "none");
                        }
                        if (!$("[name='DELIVERY_METHOD']")[2].checked) {
                            $("#EMAIL").parent().parent().css("display", "none");
                        }

                    });
                });




                $('input[name=MAIL_TO]').change(function() {
                    $("input[name=MAIL_TO]").each(function() {

                        if ($("[name='MAIL_TO']")[2].checked) {
                            $("#ADDRESS_DELIVERY2").parent().parent().css("display", "block");
                            $("#ADDRESS_DELIVERY").parent().parent().css("display", "none");
                            $("#ADDRESS_DELIVERY").val("");

                        }
                        if (!$("[name='MAIL_TO']")[2].checked) {
                            $("#ADDRESS_DELIVERY2").parent().parent().css("display", "none");
                            $("#ADDRESS_DELIVERY").parent().parent().css("display", "block");
                            $("#ADDRESS_DELIVERY2").val("");
                        }

                    });
                });

                $(document).on("click", "[name='submit-btn']", function() {
                    var mailToArray = new Array(0);
                    var deliveryArray = new Array(0);

                    if ($("#RUSH").prop('checked')) {
                        $("#rushBodyType").val("Y");
                    } else {
                        $("#rushBodyType").val("N");
                    }
                    if ($("#ACCT_NOTE").prop('checked')) {
                        $("#accBodyType").val("Y");
                    } else {
                        $("#accBodyType").val("N");
                    }

                    if ($("[name='MAIL_TO']")[0].checked) {
                        mailToArray.push($("[name='MAIL_TO']")[0].value);
                    }
                    if ($("[name='MAIL_TO']")[1].checked) {
                        mailToArray.push($("[name='MAIL_TO']")[1].value);
                    }
                    if ($("[name='MAIL_TO']")[2].checked) {
                        mailToArray.push($("[name='MAIL_TO']")[2].value);
                    }
                    var mailToArrayVal = mailToArray.join(", ");
                    $("#mailToArrayHidden").val(mailToArrayVal);

                    if ($("[name='DELIVERY_METHOD']")[0].checked) {
                        deliveryArray.push($("[name='DELIVERY_METHOD']")[0].value);
                    }
                    if ($("[name='DELIVERY_METHOD']")[1].checked) {
                        deliveryArray.push($("[name='DELIVERY_METHOD']")[1].value);
                    }
                    if ($("[name='DELIVERY_METHOD']")[2].checked) {
                        deliveryArray.push($("[name='DELIVERY_METHOD']")[2].value);
                    }
                    var deliveryArrayVal = deliveryArray.join(", ");
                    $("#deliveryArrayHidden").val(deliveryArrayVal);



                });

            }

            /*------------------------------------------------------------CALL REVIEW ----------------------------------------------------------------------------------*/

            if ((document.URL).includes("call-review-request")) {

                $("#DATERANGEVAL").parent().parent().css("display", "none");
                $("#callerPhoneNoCheckValBody").parent().parent().css("display", "none");
                $("#accountnoteaddedBody").parent().parent().css("display", "none");
                $("#rushBody").parent().parent().css("display", "none");
                $("#range").parent().css("display", "none");
                $("#startdate").parent().parent().css("display", "none");
                $("#to").parent().css("display", "none");
                $("#enddate").parent().parent().css("display", "none");

                $('select[name=site]').change(function() {
                    $("select[name=site] option:selected").each(function() {
                        if ($(this).val() == "IRV") {
                            alert('You selected IRV. Is that correct?');

                        } else if ($(this).val() == "SNO") {
                            alert('You selected SNO. Is that correct?');

                        } else if ($(this).val() == "IND") {
                            alert('You selected IND. Is that correct?');

                        } else if ($(this).val() == "HRO") {
                            alert('You selected HRO. Is that correct?');

                        }
                    });

                });

                $('input[name=unknown]').change(function() {
                    $("input[name=unknown]").each(function() {

                        if ($("input[name=unknown]:checked").val() == "Unknown") {
                            $("#dateofcall").prop("disabled", true);
                            $("#dateofcall").prop("value", '');
                            $("#range").parent().css("display", "block");
                            $("#startdate").parent().parent().css("display", "block");
                            $("#to").parent().css("display", "block");
                            $("#enddate").parent().parent().css("display", "block");
                        } else if ($("input[name=unknown]:checked").val() == undefined) {
                            $("#dateofcall").prop("disabled", false);
                            $("#range").parent().css("display", "none");
                            $("#startdate").parent().parent().css("display", "none");
                            $("#startdate").prop("value", '');
                            $("#to").parent().css("display", "none");
                            $("#enddate").parent().parent().css("display", "none");
                            $("#enddate").prop("value", '');
                        }


                    });
                });

                $('select[name=siteCall]').change(function() {
                    $("select[name=siteCall] option:selected").each(function() {
                        if ($(this).val() == "IRV") {
                            alert('You selected IRV. Is that correct?');

                        } else if ($(this).val() == "PHO") {
                            alert('You selected PHO. Is that correct?');

                        } else if ($(this).val() == "SNO") {
                            alert('You selected SNO. Is that correct?');

                        } else if ($(this).val() == "IND") {
                            alert('You selected IND. Is that correct?');

                        } else if ($(this).val() == "HRO") {
                            alert('You selected HRO. Is that correct?');

                        } else if ($(this).val() == "Unknown") {
                            alert('You selected Unknown. Is that correct?');

                        }
                    });

                });

                $(document).on("click", "[name='submit-btn']", function() {
                    var subjectLine = "CALL REVIEW - " + $("#site").val();
                    if ($("#unknown").prop('checked')) {
                        setDate($("#DATERANGEVAL").val("DATE OF CALL: Unknown<br/>DATE RANGE: " + setDate($("#startdate").val().trim()) + " TO " + setDate($("#enddate").val().trim())));
                    } else {
                        setDate($("#DATERANGEVAL").val("DATE OF CALL: " + setDate($("#dateofcall").val().trim())));
                    }

                    if ($("#callerPhoneNoCheckVal").prop('checked')) {
                        $("#callerPhoneNoCheckValBody").val("YES");
                    } else {
                        $("#callerPhoneNoCheckValBody").val("NO");
                    }

                    if ($("#accountnoteadded").prop('checked')) {
                        $("#accountnoteaddedBody").val("Y");
                    } else {
                        $("#accountnoteaddedBody").val("N");
                    }

                    if ($("#rush").prop('checked')) {
                        $("#rushBody").val("Y");
                        subjectLine += " - (RUSH)";
                    } else {
                        $("#rushBody").val("N");
                    }
                    if ($("#fundaccount").val().trim().length > 0) {
                        subjectLine += " - " + $("#fundaccount").val().trim();
                    } else {
                        subjectLine += " - ACCOUNT NOT PROVIDED";
                    }
                    $("#mailSubject").val(subjectLine);
					function setDate(val) {
var dateVal = val;
var today = new Date(dateVal);
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); 
var yyyy = today.getFullYear();
today = mm + '/' + dd + '/' + yyyy;
return today;

       }
                });
            }

            /*------------------------------------------------------------TRAC Web resolution ----------------------------------------------------------------------------------*/
            if ((document.URL).includes("trac-web-resolution-checklist")) {

                $("#prdate").parent().parent().css("display", "none");
                $("#prdate2").parent().parent().css("display", "none");
                $("#prdate3").parent().parent().css("display", "none");
                $("#prdate4").parent().parent().css("display", "none");

                $("#batchnum").parent().parent().css("display", "none");
                $("#batchnum2").parent().parent().css("display", "none");
                $("#batchnum3").parent().parent().css("display", "none");
                $("#batchnum4").parent().parent().css("display", "none");

                $("#pramount").parent().parent().css("display", "none");
                $("#pramount2").parent().parent().css("display", "none");
                $("#pramount3").parent().parent().css("display", "none");
                $("#pramount4").parent().parent().css("display", "none");

                $('select[name=funding]').parent().parent().css("display", "none");
                $("#fundcomm").parent().parent().css("display", "none");

                $("#text1").parent().css("display", "none");
                $("#text2").parent().css("display", "none");
                $("#payrolldate").parent().css("display", "none");
                $("#batchnumber").parent().css("display", "none");
                $("#payrollamount").parent().css("display", "none");
                $("#fundingcomments").parent().css("display", "none");
                $("#helpdeskMemberInitials").parent().parent().css("display", "none");

                $('input[name="helpdeskRadio"]').change(function() {
                    $('input[name="helpdeskRadio"]:checked').each(function() {
                        if ($('input[name="helpdeskRadio"]:checked').val() == "Yes") {
                            $("#helpdeskMemberInitials").parent().parent().css("display", "block");
                        } else if ($('input[name="helpdeskRadio"]:checked').val() == "No") {
                            $("#helpdeskMemberInitials").parent().parent().css("display", "none");
                        }

                    });
                });
                $('input[name=inprog]').change(function() {
                    $("input[name=inprog]").each(function() {
                        if($('input[name="inprog"]')[0].checked) {
							$('input[name="inprog"]').val('Yes');
                            $("#prdate").parent().parent().css("display", "block");
                            $("#prdate2").parent().parent().css("display", "block");
                            $("#prdate3").parent().parent().css("display", "block");
                            $("#prdate4").parent().parent().css("display", "block");

                            $("#batchnum").parent().parent().css("display", "block");
                            $("#batchnum2").parent().parent().css("display", "block");
                            $("#batchnum3").parent().parent().css("display", "block");
                            $("#batchnum4").parent().parent().css("display", "block");

                            $("#pramount").parent().parent().css("display", "block");
                            $("#pramount2").parent().parent().css("display", "block");
                            $("#pramount3").parent().parent().css("display", "block");
                            $("#pramount4").parent().parent().css("display", "block");

                            $('select[name=funding]').parent().parent().css("display", "block");
                            $("#payrolldate").parent().css("display", "block");
                            $("#batchnumber").parent().css("display", "block");
                            $("#payrollamount").parent().css("display", "block");

                            $("#text1").parent().css("display", "block");
                            $("#issue").prop("value", "N/A");

                        } else {
                            $('input[name="inprog"]').val('No');
                            $("#prdate").parent().parent().css("display", "none");
                            $("#prdate2").parent().parent().css("display", "none");
                            $("#prdate3").parent().parent().css("display", "none");
                            $("#prdate4").parent().parent().css("display", "none");

                            $("#batchnum").parent().parent().css("display", "none");
                            $("#batchnum2").parent().parent().css("display", "none");
                            $("#batchnum3").parent().parent().css("display", "none");
                            $("#batchnum4").parent().parent().css("display", "none");

                            $("#pramount").parent().parent().css("display", "none");
                            $("#pramount2").parent().parent().css("display", "none");
                            $("#pramount3").parent().parent().css("display", "none");
                            $("#pramount4").parent().parent().css("display", "none");

                            $('select[name=funding]').parent().parent().css("display", "none");
                            $("#fundcomm").parent().parent().css("display", "none");

                            $("#text1").parent().css("display", "none");
                            $("#text2").parent().css("display", "none");
                            $("#payrolldate").parent().css("display", "none");
                            $("#batchnumber").parent().css("display", "none");
                            $("#payrollamount").parent().css("display", "none");
                            $("#fundingcomments").parent().css("display", "none");
                            $("#issue").prop("value", "");


                        }


                    });
                });

                $('select[name=funding]').change(function() {
                    $("select[name=funding] option:selected").each(function() {
                        if ($(this).val() == "Other") {
                            $("#text2").parent().css("display", "block");
                            $("#fundingcomments").parent().css("display", "block");
                            $("#fundcomm").parent().parent().css("display", "block");


                        } else {

                            $("#text2").parent().css("display", "none");
                            $("#fundingcomments").parent().css("display", "none");
                            $("#text2").parent().css("display", "none");
                            $("#fundcomm").parent().parent().css("display", "none");



                        }

                    });
                });
				
				$("#rushHidden").parent().parent().css("display", "none");
				$("#pidHidden").parent().parent().css("display", "none");
				 $(document).on("click", "[name='submit-btn']", function() {
				 
				 if ($("#priority").val() == "RUSH") {
				  $("#rushHidden").val("*RUSH");
				 }
				 
				 if ($("#planId").val() == "") {
				  $("#pidHidden").val("No Plan ID");
				 }
				 else
				 {
				 var pid = $("#planId").val()
				 $("#pidHidden").val(pid);
				 }
				 
				 });
				 
				var ssn = $("#ssn").prev().text();
				var psw = $("#pswID").prev().text();
				var pid = $("#planId").prev().text();
				var website = $("#EEEWebsiteUrl").prev().text();

                $('select[name=site]').change(function() {

                    $("select[name=site] option:selected").each(function() {
					
					if ($(this).val() == "Sponsor" || $(this).val() == "TPA") {
						$("#pswID").attr('required', true);
						$("#pswID").prev().text("*"+psw);
						$("#ssn").prev().text(ssn);
						$("#planId").prev().text(pid);
						$("#EEEWebsiteUrl").prev().text(website);
                     }
                    else if ($(this).val() == "EEE Website"){
						 $("#pswID").attr('required',true);
						 $("#EEEWebsiteUrl").attr('required',true);
						 $("#planId").attr('required',true);
						 $("#ssn").attr('required',true);
						 $("#pswID").prev().text("*"+psw);
						 $("#ssn").prev().text("*"+ssn);
						 $("#planId").prev().text("*"+pid);
						 $("#EEEWebsiteUrl").prev().text("*"+website);
                     }
                     else{
                                                 $("#pswID").attr('required',false);
						 $("#EEEWebsiteUrl").attr('required',false);
						 $("#planId").attr('required',false);
						 $("#ssn").attr('required',false);
						 $("#pswID").prev().text(psw);
						 $("#ssn").prev().text(ssn);
						 $("#planId").prev().text(pid);
						 $("#EEEWebsiteUrl").prev().text(website);
                     }
      });
});

            }



            /*------------------------------------------------FD - RPE Notification / Future Date Request Form -------------------------------------------*/

            if ((document.URL).includes("fd-rpe-notification-future-date-request-form")) {

                $("#sumdisp").css("display", "none");
                $("#accountTable").css("width", "100%");

                $("#participantname").parent().parent().css("display", "none");
                $("#participantssn").parent().parent().css("display", "none");
                $("#holdtypetext").parent().css("display", "none");
                $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                $("#holdtypedate").parent().parent().css("display", "none");

                $("#sep1").parent().css("display", "none");
                $("#the").parent().css("display", "none");
                $("#enter").parent().css("display", "none");



                $("#rmdyesnotext").parent().css("display", "none");
                $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                $("#fedtext").parent().css("display", "none");
                $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                $("#tractext").parent().css("display", "none");
                $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                $("#vestingtext").parent().css("display", "none");
                $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                $("#exptext").parent().css("display", "none");
                $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                $("#noticetext").parent().css("display", "none");
                $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                $('select[name=prevdef]').parent().parent().css("display", "none");
                $('select[name=newdef]').parent().parent().css("display", "none");

                $("#loantypettext").parent().css("display", "none");
                $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                $("#effectiveDatetext").parent().css("display", "none");
                $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                $("#moneytext").parent().css("display", "none");
                $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                $("#effectiveDatetext1").parent().css("display", "none");
                $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                $("#numdays").parent().parent().css("display", "none");
                $("#calcbtn").css("display", "none")

                $("#map").parent().css("display", "none");

                $('select[name=fsc]').parent().parent().css("display", "none");
                $('select[name=tsc]').parent().parent().css("display", "none");
                $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                $("#maxpt").parent().parent().css("display", "none");

                $("#worktype").parent().parent().css("display", "block");
                $("#worktype").prop("disabled", true);
                $("#worktype").prop("value", "");

                $("#effdate").parent().parent().css("display", "none");
                $("#edate").parent().css("display", "none");
                $("#tradedt").parent().parent().css("display", "none");

                $("#accountTable").parent().parent().css("display", "none");
                for (var i = 0; i <= 8; ++i) {
                    $('#AddFundsBtn').click();
                }
				$(document).on('change', '[id="likefund"]', function () 
				{
                    $(document).on('change', '[id^="from"]', function () {
                        if ($("[name='likefund']")[0].checked) 
                        {	                            
                            var valueIs=$(this).val();
                            var valueFrom=$(this).parent().parent().parent().parent().parent().children().eq(2).children().children().children().children().eq(1);
                            valueFrom.val(valueIs)                            
                        }
                    });
                });

                $('select[name=reqtype]').change(function() {
                    $("select[name=reqtype] option:selected").each(function() {
                        if ($(this).val() == "Money Type Change") {
                            $("#effdate").prop("disabled", false);
                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");

                            $("#holdtypedate").parent().parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "block");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "block");

                            $("#tractext").parent().css("display", "block");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "block");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "block");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "block");

                            $("#effectiveDatetext1").parent().css("display", "block");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "block");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")
                            $("#map").parent().css("display", "none");

                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "Non-Fin Plan Maint");

                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "block");
                            $("#tradedt").parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().css("display", "none");

                            $("#sep1").parent().css("display", "block");




                            function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

                                var today = new Date();
                                var month = today.getMonth() + 1;
                                if (month < 10) {
                                    month = "0" + month;
                                }
                                var day = today.getDate();
                                if (day < 10) {
                                    day = "0" + day;
                                }
                                var year = today.getFullYear();
                                var dateString = year + "-" + month + "-" + day;
                                return dateString;
                            }

                            $('input[name=effectiveDateRadio1]').change(function() {
                                $("input[name=effectiveDateRadio1]").each(function() {
                                    if ($("input[name=effectiveDateRadio1]:checked").val() == "today") {
                                        $("#effdate").prop("value", currDate());

                                    } else if ($("input[name=effectiveDateRadio1]:checked").val() == "provided") {
                                        $("#effdate").prop("value", "");
                                        $('#effdate').focus()


                                    }

                                });

                            });

                        } else if ($(this).val() == "Printed Fee Disclosure Order") {

                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");
                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                            $("#holdtypedate").parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "none");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "none");

                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "");

                            $("#effdate").parent().parent().css("display", "none");
                            $("#edate").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().css("display", "none");

                            $("#sep1").parent().css("display", "none");


                        } else if ($(this).val() == "Vesting Schedule Change") {
                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");
                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                            $("#holdtypedate").parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "block");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "block");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "none");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "none");

                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "");

                            $("#effdate").parent().parent().css("display", "none");
                            $("#edate").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().css("display", "none");

                            $("#sep1").parent().css("display", "none");




                        } else if ($(this).val() == "Fund Remove - No Mapping") {
                            $("#effdate").prop("disabled", false);
                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");
                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                            $("#holdtypedate").parent().parent().css("display", "none");


                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "none");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "none");

                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "Fin Plan Maint");

                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().css("display", "none");

                            $("#sep1").parent().css("display", "none");

                        } else if ($(this).val() == "Fund Change - Mapping - SCC") {
                            $("#effdate").prop("disabled", false);
                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");
                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                            $("#holdtypedate").parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "block");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "block");

                            $("#accountTable").parent().parent().css("display", "block");

                            $("#sep1").parent().css("display", "block");




                            $('input[name="expyesno"]').change(function() {
                                $('input[name="expyesno"]:checked').each(function() {
                                    if ($(this).val() == "Yes") {
                                        $("#noticetext").parent().css("display", "none");
                                        $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                                        $('input[name="noticeyesno"]').prop('checked', false);

                                    } else if ($(this).val() == "No") {
                                        $("#noticetext").parent().css("display", "block");
                                        $('input[name="noticeyesno"]').parent().parent().parent().css("display", "block");

                                        $('input[name="noticeyesno"]').prop('checked', false);

                                    }

                                });
                            });




                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "none");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "block");

                            $('select[name=fsc]').parent().parent().css("display", "block");
                            $('select[name=tsc]').parent().parent().css("display", "block");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "block");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "Fin Plan Maint");

                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "block");


                        } else if ($(this).val() == "Fund Change - Mapping - FREP") {
                            $("#effdate").prop("disabled", false);
                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");
                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                            $("#holdtypedate").parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "none");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "block");

                            $('select[name=fsc]').parent().parent().css("display", "block");
                            $('select[name=tsc]').parent().parent().css("display", "block");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "block");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "Fin Plan Maint");

                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "block");
                            $("#accountTable").parent().parent().css("display", "block");

                            $("#sep1").parent().css("display", "block");


                        } else if ($(this).val() == "Default Fund Change - No Mapping") {
                            $("#effdate").prop("disabled", false);
                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");
                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                            $("#holdtypedate").parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "block");
                            $('select[name=newdef]').parent().parent().css("display", "block");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "none");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "none");

                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "Fin Plan Maint");

                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().css("display", "none");

                            $("#sep1").parent().css("display", "none");


                        } else if ($(this).val() == "Loan Provision Add / Remove") {

                            $("#effdate").prop("disabled", false);
                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");
                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                            $("#holdtypedate").parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "block");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "block");


                            $("#effectiveDatetext").parent().css("display", "block");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "block");

                            $("#sep1").parent().css("display", "block");


                            $('input[name="effectiveDateRadio"]').change(function() {
                                $('input[name="effectiveDateRadio"]:checked').each(function() {
                                    if ($(this).val() == "notprovided") {
                                        $("#numdays").parent().parent().css("display", "block");
                                        $("#calcbtn").css("display", "block");

                                        $("#the").parent().css("display", "block");

                                        $("#calcbtn").on('click', function() {
                                            alert("Entry in the 'days to calculate' field is not a number.");
                                        });
                                    } else if ($(this).val() == "provided") {
                                        $("#numdays").parent().parent().css("display", "none");
                                        $("#the").parent().css("display", "none");
                                        $("#calcbtn").css("display", "none");
                                        $("#effdate").prop("value", "");
                                        $('#effdate').focus()
                                    } else if ($(this).val() == "today") {
                                        var currentDate = currDate();
                                        $("#numdays").parent().parent().css("display", "none");
                                        $("#the").parent().css("display", "none");
                                        $("#calcbtn").css("display", "none");
                                        $("#effdate").val(currentDate);
                                    }
                                });
                            });



                            function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

                                var today = new Date();
                                var month = today.getMonth() + 1;
                                if (month < 10) {
                                    month = "0" + month;
                                }
                                var day = today.getDate();
                                if (day < 10) {
                                    day = "0" + day;
                                }
                                var year = today.getFullYear();
                                var dateString = year + "-" + month + "-" + day;
                                return dateString;
                            }

                            $('input[name=effectiveDateRadio1]').change(function() {
                                $("input[name=effectiveDateRadio1]").each(function() {
                                    if ($("input[name=effectiveDateRadio1]:checked").val() == "today") {
                                        $("#effdate").prop("value", currDate());

                                    } else if ($("input[name=effectiveDateRadio1]:checked").val() == "provided") {
                                        $("#effdate").prop("value", "");

                                    }

                                });

                            });




                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "none");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "none");

                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "Fin Plan Maint");

                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "block");
                            $("#tradedt").parent().parent().css("display", "none");


                        } else if ($(this).val() == "Fee Payment Authorization") {

                            $("#effdate").prop("disabled", false);
                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");
                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                            $("#holdtypedate").parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "block");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "block");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "none");

                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                            $("#maxpt").parent().parent().css("display", "block");

                            $("#worktype").parent().parent().css("display", "none");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "");

                            $("#effdate").parent().parent().css("display", "block");
                            $("#edate").parent().css("display", "block");
                            $("#tradedt").parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().css("display", "none");

                            $("#sep1").parent().css("display", "block");


                        } else if ($(this).val() == "Distribution") {

                            $("#participantname").parent().parent().css("display", "block");
                            $("#participantssn").parent().parent().css("display", "block");
                            $("#holdtypetext").parent().css("display", "block");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "block");

                            $("#the").parent().css("display", "none");

                            $('#effdate').prop("disabled", true);

                            $('input[name="holdtype"]').change(function() {
                                $('input[name="holdtype"]:checked').each(function() {
                                    if ($(this).val() == "ACH") {
                                        // DATE FIELD TO BE SET TO CURRENT DATE AND EFFECTIVE DATE TO BE SET TO TEN DAYS LATER
                                        $('#effdate').val('');
                                        var currentDate = currDate();

                                        $("#holdtypedate").val(currentDate);
                                        $("#enter").parent().css("display", "none");

                                        var myDate = new Date(new Date().getTime() + (9 * 24 * 60 * 60 * 1000));
                                        var defdate = myDate.toISOString().substring(0, 10);
                                        var field = document.querySelector('#effdate');
                                        field.value = defdate;

                                    } else if ($(this).val() == "Address Change") {
                                        // TEXT FIELD IS TO BE ADDED TO DATE
                                        $('#effdate').val('');
                                        $("#holdtypedate").prop("value", "");
                                        $('#holdtypedate').focus()
                                        // $("#holdtypedate").val(currDate());
                                        $("#enter").parent().css("display", "block");
                                        $(document).on('blur', '[id="holdtypedate"]', function() {
                                            if ($(this).val() != '') {
                                                var myDate = new Date(new Date($("#holdtypedate").val()).getTime() + (9 * 24 * 60 * 60 * 1000));
                                                var defdate = myDate.toISOString().substring(0, 10);
                                                var field = document.querySelector('#effdate');
                                                field.value = defdate;
                                            }
                                        })


                                    }

                                });
                            });

                            function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

                                var today = new Date();
                                var month = today.getMonth() + 1;
                                if (month < 10) {
                                    month = "0" + month;
                                }
                                var day = today.getDate();
                                if (day < 10) {
                                    day = "0" + day;
                                }
                                var year = today.getFullYear();
                                var dateString = year + "-" + month + "-" + day;
                                return dateString;
                            }




                            $("#holdtypedate").parent().parent().css("display", "block");

                            $("#rmdyesnotext").parent().css("display", "block");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "block");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "none");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "none");

                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "Distribution");

                            $("#effdate").parent().parent().css("display", "block").prop("disable", true);
                            $("#edate").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");

                            $("#sep1").parent().css("display", "none");


                        } else if ($(this).val() == "Other") {

                            $("#participantname").parent().parent().css("display", "none");
                            $("#participantssn").parent().parent().css("display", "none");
                            $("#holdtypetext").parent().css("display", "none");
                            $('input[name="holdtype"]').parent().parent().parent().css("display", "none");
                            $("#holdtypedate").parent().parent().css("display", "none");

                            $("#the").parent().css("display", "none");
                            $("#enter").parent().css("display", "none");

                            $("#rmdyesnotext").parent().css("display", "none");
                            $('input[name="rmdyesno"]').parent().parent().parent().css("display", "none");

                            $("#fedtext").parent().css("display", "none");
                            $('input[name="fedyesno"]').parent().parent().parent().css("display", "none");

                            $("#tractext").parent().css("display", "none");
                            $('input[name="tracyesno"]').parent().parent().parent().css("display", "none");

                            $("#vestingtext").parent().css("display", "none");
                            $('input[name="vestingtracyesno"]').parent().parent().parent().css("display", "none");

                            $("#exptext").parent().css("display", "none");
                            $('input[name="expyesno"]').parent().parent().parent().css("display", "none");

                            $("#noticetext").parent().css("display", "none");
                            $('input[name="noticeyesno"]').parent().parent().parent().css("display", "none");

                            $('select[name=prevdef]').parent().parent().css("display", "none");
                            $('select[name=newdef]').parent().parent().css("display", "none");

                            $("#loantypettext").parent().css("display", "none");
                            $('input[name="loantype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext").parent().css("display", "none");
                            $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display", "none");

                            $("#moneytext").parent().css("display", "none");
                            $('input[name="moneytype"]').parent().parent().parent().css("display", "none");

                            $("#effectiveDatetext1").parent().css("display", "none");
                            $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display", "none");

                            $("#numdays").parent().parent().css("display", "none");
                            $("#calcbtn").css("display", "none")

                            $("#map").parent().css("display", "none");

                            $('select[name=fsc]').parent().parent().css("display", "none");
                            $('select[name=tsc]').parent().parent().css("display", "none");
                            $('input[name="likefund"]').parent().parent().parent().css("display", "none");

                            $("#maxpt").parent().parent().css("display", "none");

                            $("#worktype").parent().parent().css("display", "block");
                            $("#worktype").prop("disabled", true);
                            $("#worktype").prop("value", "");

                            $("#effdate").parent().parent().css("display", "none");
                            $("#edate").parent().css("display", "none");
                            $("#tradedt").parent().parent().css("display", "none");

                            $("#sep1").parent().css("display", "none");




                        }


                    });

                });



                function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy)

                    var today = new Date();
                    var month = today.getMonth() + 1;
                    if (month < 10) {
                        month = "0" + month;
                    }

                    var day = today.getDate();
                    if (day < 10) {
                        day = "0" + day;
                    }

                    var year = today.getFullYear();
                    var dateString = year + "-" + month + "-" + day;
                    return dateString;
                }




            }




            /*---------------------------------------------------RP PHONE-GENERATED RESEARCH / CORRECTION REQUEST-----------------------------------------------------------------------------*/								
			if ((document.URL).includes("rp-phone-generated-research-correction-request")) {
							$("#EXT").attr("title", "Associate's ext - 5 numeric characters");
							$("#RESEARCH").attr("title", "30 Lines maximum");
							$("#ADDITIONALCOMMENTS").attr("title", "30 Lines maximum");
							$("#PLANID").parent().parent().css("display", "none");
							$("#PLANNAME").parent().parent().css("display", "none");
							$("#GROUPPLANNAME").parent().parent().css("display", "none");
							$("#PARTICIPANTNAME").parent().parent().css("display", "none");
							$("#ACCOUNT").parent().parent().css("display", "none");
							$("#SOCIALSECNO").parent().parent().css("display", "none");

							$("#tracShareHidden").parent().parent().css("display", "none");
							$("#RETPLANHidden").parent().parent().css("display", "none");
							$(document).on("click", "[name='submit-btn']", function() {

								var trac= new Array(0);
								if ($("[name='trac_share']")[0].checked)
									{
										trac.push($("[name='trac_share']")[0].value);
									
									}
								if ($("[name='trac_share']")[1].checked)
									{
										trac.push($("[name='trac_share']")[1].value);
									
									}
											var tracForm= trac.join(",  ");
											$("#tracShareHidden").val(tracForm);

								var RETPLAN = new Array(0);

								if ($("[name='RETPLAN_CHECK']")[0].checked)
									{
										RETPLAN.push($("[name='RETPLAN_CHECK']")[0].value);
									
									}
								if ($("[name='RETPLAN_CHECK']")[1].checked)
									{
										RETPLAN.push($("[name='RETPLAN_CHECK']")[1].value);

									}
								if ($("[name='RETPLAN_CHECK']")[2].checked)
									{
										RETPLAN.push($("[name='RETPLAN_CHECK']")[2].value);
									
									}
								if ($("[name='RETPLAN_CHECK']")[3].checked)
									{
										RETPLAN.push($("[name='RETPLAN_CHECK']")[3].value);

									}
											var RETPLANForm= RETPLAN.join(",  ");
											$("#RETPLANHidden").val(RETPLANForm);

								 });

							$('input[name=trac_share]').change(function() {
								$("input[name=trac_share]").each(function() {
									if ($("input[name=trac_share]:checked").length == 2) {
										$("#PLANID").parent().parent().css("display", "block");
										$("#PLANNAME").parent().parent().css("display", "block");
										$("#PARTICIPANTNAME").parent().parent().css("display", "block");
										$("#SOCIALSECNO").parent().parent().css("display", "block");
										$("#GROUPPLANNAME").parent().parent().css("display", "block");
										$("#ACCOUNT").parent().parent().css("display", "block");

									} else if ($("input[name=trac_share]:checked").val() == "SHARE" && $("input[name=system]:checked").val() != "TRAC") {
										$("#PLANID").parent().parent().css("display", "none");
										$("#PLANNAME").parent().parent().css("display", "block");
										$("#PARTICIPANTNAME").parent().parent().css("display", "block");
										$("#SOCIALSECNO").parent().parent().css("display", "block");
										$("#GROUPPLANNAME").parent().parent().css("display", "block");
										$("#ACCOUNT").parent().parent().css("display", "block");

									} else if ($("input[name=trac_share]:checked").val() == "TRAC" && $("input[name=trac_share]:checked").val() != "SHARE") {
										$("#PLANID").parent().parent().css("display", "block");
										$("#PLANNAME").parent().parent().css("display", "block");
										$("#PARTICIPANTNAME").parent().parent().css("display", "block");
										$("#SOCIALSECNO").parent().parent().css("display", "block");
										$("#GROUPPLANNAME").parent().parent().css("display", "none");
										$("#ACCOUNT").parent().parent().css("display", "none");

									} else if ($("input[name=trac_share]:checked").val() == undefined) {
										$("#PLANID").parent().parent().css("display", "none");
										$("#PLANNAME").parent().parent().css("display", "none");
										$("#PARTICIPANTNAME").parent().parent().css("display", "none");
										$("#SOCIALSECNO").parent().parent().css("display", "none");
										$("#GROUPPLANNAME").parent().parent().css("display", "none");
										$("#ACCOUNT").parent().parent().css("display", "none");

									}

								});
							});
						}




            /*------------------------------------------------UFIDX-----------------------------------------------------------------------------------------------------*/

            if ((document.URL).includes("ufidx")) {

				$("#houseIssue").parent().parent().css("display", "none");
                $("#mismatchIssue").parent().parent().css("display", "none");
				$("#houseIssue").val("RKD has received a request to update the financial advisor on an RKD plan to reflect 'House Account'.  Please establish a UFID account based on the following information so that TRAC CD and RPA can be updated.");
				$("#mismatchIssue").val("The following rep profile is set up in DORIS, but RKD is unable to add it to the plan.  Error message [No representatives found...] or [Representative's branch is inactive...] is received.");

                $("#dealer").parent().parent().css("display", "none");
                $("#branch").parent().parent().css("display", "none");
                $("#house").parent().parent().css("display", "none");
                $("#phoneUfid").parent().parent().css("display", "none");
				$("#phoneUfid").mask('0000000000');
                $("#fax").parent().parent().css("display", "none");
                $("#houseaccount1").parent().css("display", "none");
                $("#repid1").parent().css("display", "none");
                $("#house1").parent().css("display", "none");

                $("#ufidmismatch1").parent().css("display", "none");
                $("#dealer2").parent().parent().css("display", "none");
                $("#branch2").parent().parent().css("display", "none");
                $("#repid").parent().parent().css("display", "none");
                $("#repname").parent().parent().css("display", "none");
                $("#fax2").parent().parent().css("display", "none");

                $("#Sep5").parent().css("display", "none");

                $('select[name=ufid]').change(function() {
                    $("select[name=ufid] option:selected").each(function() {
                        if ($(this).val() == "House Account") {

                            $("#houseaccount1").parent().css("display", "block");
                            $("#dealer").parent().parent().css("display", "block");
                            $("#branch").parent().parent().css("display", "block");
                            $("#house1").parent().css("display", "block");
                            $("#phoneUfid").parent().parent().css("display", "block");
                            $("#fax").parent().parent().css("display", "block");
                            $("#house").parent().parent().css("display", "block");

                            $("#repid1").parent().css("display", "block");
                            $("#Sep5").parent().css("display", "block");

                            $("#ufidmismatch1").parent().css("display", "none");
                            $("#dealer2").parent().parent().css("display", "none");
                            $("#branch2").parent().parent().css("display", "none");
                            $("#repid").parent().parent().css("display", "none");
                            $("#repname").parent().parent().css("display", "none");
                            $("#fax2").parent().parent().css("display", "none");


                        } else if ($(this).val() == "UFID Mismatch") {

                            $("#ufidmismatch1").parent().css("display", "block");
                            $("#dealer2").parent().parent().css("display", "block");
                            $("#branch2").parent().parent().css("display", "block");
                            $("#repid").parent().parent().css("display", "block");
                            $("#repname").parent().parent().css("display", "block");
                            $("#fax2").parent().parent().css("display", "block");
                            $("#Sep5").parent().css("display", "block");



                            $("#dealer").parent().parent().css("display", "none");
                            $("#branch").parent().parent().css("display", "none");
                            $("#house").parent().parent().css("display", "none");
                            $("#phoneUfid").parent().parent().css("display", "none");
                            $("#fax").parent().parent().css("display", "none");
                            $("#houseaccount1").parent().css("display", "none");
                            $("#repid1").parent().css("display", "none");
                            $("#house1").parent().css("display", "none");




                        }

                    });
                });
            }


            /*------------------------------------------------G-PURCH BATCH TICKET---------------------------------------------------------------------------------------*/

            if ((document.URL).includes("g-purch-batch-ticket")) {

                $("#accountTable").parent().parent().parent().css("display", "none");

                $("#accountTable").css("width", "60%");

                $("#wireinvestments").parent().css("display", "none");
                $("#file").parent().parent().css("display", "none");



                $('select[name=site2]').change(function() {
                    $("select[name=site2] option:selected").each(function() {
                        if ($(this).val() == "IRV") {
                            alert('You selected IRV. Is that correct?');

                        } else if ($(this).val() == "SNO") {
                            alert('You selected SNO. Is that correct?');

                        } else if ($(this).val() == "IND") {
                            alert('You selected IND. Is that correct?');

                        } else if ($(this).val() == "HRO") {
                            alert('You selected HRO. Is that correct?');

                        }
                    });

                });

                $('select[name=SOURCETYPE]').change(function() {
                    $("select[name=SOURCETYPE] option:selected").each(function() {
                        if ($(this).val() == "Imaged") {
                            alert('You selected Imaged. Is that correct?');

                        } else if ($(this).val() == "Paper") {
                            alert('You selected Paper. Is that correct?');

                        }
                    });

                });
                $('select[name=site]').change(function() {
                    $("select[name=site] option:selected").each(function() {
                        if ($(this).val() == "IRV") {
                            alert('You selected IRV. Is that correct?');

                        } else if ($(this).val() == "SNO") {
                            alert('You selected SNO. Is that correct?');

                        } else if ($(this).val() == "IND") {
                            alert('You selected IND. Is that correct?');

                        } else if ($(this).val() == "HRO") {
                            alert('You selected HRO. Is that correct?');

                        }
                    });

                });
                $('select[name=PAYMENTTYPE]').change(function() {
                    $("select[name=PAYMENTTYPE] option:selected").each(function() {
                        if ($(this).val() == "WIRE") {
                            $("#wireinvestments").parent().css("display", "block");
                            $("#file").parent().parent().css("display", "block");

                            $("#accountTable").parent().parent().parent().css("display", "none");

                        } else if ($(this).val() == "CHECK") {
                            $("#wireinvestments").parent().css("display", "none");
                            $("#file").parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "block");

                        }


                    });

                });
            }

            /*------------------------------------------------RPS Compliance Referral Form--------------------------------------------------------------------------------*/

            if ((document.URL).includes("rps-compliance-referral-form")) {
                $("#PID").attr("title", "30 characters or less");
                $("#ASSOCIATEROLE").attr("title", "30 characters or less");
                $("#PYIM").attr("title", "10 characters or less");
                $("#PLANPARTICIPANTNAME").attr("title", "Maximum 4 lines");
                $("#description").attr("title", "Maximum 30 lines");
                $("#Resolution").attr("title", "Maximum 30 lines");
                $("#Soni").attr("title", "Maximum 30 lines");
                $("#SCENARIODESCRIPTION").attr("title", "Maximum 30 lines");
                $("#ACTIONTAKEN").attr("title", "Maximum 30 lines");
                $("#NOTCURRENTLOAN").attr("title", "Maximum 30 lines");
                $("#LOANCIRCUMSTANCES").attr("title", "Maximum 30 lines");
                $("#PLANDESCOCCURRED").attr("title", "Maximum 30 lines");
                $("#PLANSPONSORSTEPS").attr("title", "Maximum 30 lines");
                $("#PLANADDITIONALQUE").attr("title", "Maximum 30 lines");
                $("#PLANPROPOSESOLUTIONTESTING").attr("title", "Maximum 30 lines");
                $("#PLANPROPOSEDQUES").attr("title", "Maximum 30 lines");
                $("#PLANELECTIONCURRENTPRO").attr("title", "Maximum 30 lines");
                $("#PLANAPPEARDESCRIBELINE").attr("title", "Maximum 30 lines");
                $("#PLANPURPOSEDESCRIBE").attr("title", "Maximum 30 lines");
                $("#PLANDESCRIBELINEREAD").attr("title", "Maximum 30 lines");
                $("#PLANDOCREQUESTIMPACT").attr("title", "Maximum 30 lines");
                $("#PLANDESCWHATOCCURRED").attr("title", "Maximum 30 lines");
                $("#PLANDESCSTEPSTOCORRECT").attr("title", "Maximum 30 lines");
                $("#PLANSPONSORADDQUE").attr("title", "Maximum 30 lines");
                $("#PLANPROPOSESOLUTION").attr("title", "Maximum 30 lines");
                $("#PLANSPONSORADDQUEPROPOSAL").attr("title", "Maximum 30 lines");

                $("#fraud").parent().css("display", "none");
                $("#RPSNotifiedDate").parent().parent().css("display", "none");
                $("#SCENARIODESCRIPTION").parent().parent().css("display", "none");
                $("#ACTIONTAKEN").parent().parent().css("display", "none");

                $("#Soni").parent().css("display", "none");



                $("#loan").parent().css("display", "none");
                $("#SSN").parent().parent().css("display", "none");
                $("#LOANNUMBER").parent().parent().css("display", "none");
                $("#LoanOriginationDate").parent().parent().css("display", "none");
                $("#LoanMaturityDate").parent().parent().css("display", "none");
                $("#DateLoanDefaulted").parent().parent().css("display", "none");
                $("#CurePeriodEndDate").parent().parent().css("display", "none");
                $("#NOTCURRENTLOAN").parent().parent().css("display", "none");
                $("#LOANCIRCUMSTANCES").parent().parent().css("display", "none");
                $("#REFERRALTYPE").find("option[value='Testing']").parent().empty().append('<option value="">Select</option><option value="Account Access/Privacy">Account Access/Privacy</option><option value="Adjustments">Adjustments</option><option value="Bankruptcy, Levy, Garnishments, &amp; Court Orders">Bankruptcy, Levy, Garnishments, &amp; Court Orders</option><option value="Compliance Stop">Compliance Stop</option><option value="Contribution">Contribution</option><option value="Correspondence Review">Correspondence Review</option><option value="Distributions">Distributions</option><option value="Exception Request">Exception Request</option><option value="Fraud/ID Theft">Fraud/ID Theft</option><option value="Loan Default Reversal Request">Loan Default Reversal Request</option><optgroup label="Plan Audit or Plan Year End" value="Plan Audit or Plan Year End"><option value="Testing">Testing</option><option value="Plan Audit or Plan Year End - Other">Other</option></optgroup><optgroup label="Plan Election or Provision" value="Plan Election or Provision"><option value="Describe Line Request">Describe Line Request</option><option value="Plan Document Issue/Question">Plan Document Issue/Question</option></optgroup><option value="Plan Install or Conversion">Plan Install or Conversion</option><option value="Plan Termination">Plan Termination</option><option value="Plan/Participant Maint">Plan/Participant Maint</option><option value="Process Improvement">Process Improvement</option><option value="Tax Withholding or Tax Reporting">Tax Withholding or Tax Reporting</option><option value="Other">Other</option>')

                $("#plantesting").parent().css("display", "none");
                $("#concern").parent().css("display", "none");
                $('input[name=CONCERNTEST]').parent().parent().parent().css("display", "none");
                $('input[name=CONCERNTEST1]').parent().parent().parent().css("display", "none");
                $("#OTHERDESCRIBE").parent().parent().css("display", "none");
                $("#PLANSPONSORSTEPS").parent().parent().css("display", "none");
                $("#PLANDESCOCCURRED").parent().parent().css("display", "none");
                $("#PLANADDITIONALQUE").parent().parent().css("display", "none");
                $("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display", "none");
                $("#PLANPROPOSEDQUES").parent().parent().css("display", "none");



                $("#useof").parent().css("display", "none");
                $("#PLANELECTIONCURRENTPRO").parent().parent().css("display", "none");
                $("#PLANAPPEARDESCRIBELINE").parent().parent().css("display", "none");
                $("#PLANPURPOSEDESCRIBE").parent().parent().css("display", "none");
                $("#PLANDESCRIBELINEREAD").parent().parent().css("display", "none");


                $("#plandocument").parent().css("display", "none");
                $("#PLANDOCREQUESTIMPACT").parent().parent().css("display", "none");
                $("#PLANDESCWHATOCCURRED").parent().parent().css("display", "none");
                $("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display", "none");
                $("#PLANSPONSORADDQUE").parent().parent().css("display", "none");
                $("#PLANPROPOSESOLUTION").parent().parent().css("display", "none");
                $("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display", "none");


                $('input[name=SONI]').change(function() {
                    $("input[name=SONI]:checked").each(function() {
                        if ($("input[name=SONI]:checked").val() == "YES") {
                            $("#Soni").parent().css("display", "block");

                        } else if ($("input[name=SONI]:checked").val() == "NO") {
                            $("#Soni").parent().css("display", "None");

                        }


                    });
                });

                $('select[name=REFERRALTYPE]').change(function() {
                    $("select[name=REFERRALTYPE] option:selected").each(function() {
                        if ($(this).val() == "Fraud/ID Theft") {
                            $("#fraud").parent().css("display", "block");
                            $("#RPSNotifiedDate").parent().parent().css("display", "block");
                            $("#SCENARIODESCRIPTION").parent().parent().css("display", "block");
                            $("#ACTIONTAKEN").parent().parent().css("display", "block");
                            $('input[name=SONI]').parent().parent().parent().css("display", "block");
                            $("#soni").parent().css("display", "block");

                            $("#Resolution").parent().parent().css("display", "block");

                            $('input[name=SONI]').change(function() {
                                $("input[name=SONI]:checked").each(function() {
                                    if ($("input[name=SONI]:checked").val() == "YES") {
                                        $("#Soni").parent().css("display", "block");

                                    } else if ($("input[name=SONI]:checked").val() == "NO") {
                                        $("#Soni").parent().css("display", "None");

                                    }


                                });
                            });
                            $("#description").parent().parent().css("display", "none");
                            $("#loan").parent().css("display", "none");
                            $("#SSN").parent().parent().css("display", "none");
                            $("#LOANNUMBER").parent().parent().css("display", "none");
                            $("#LoanOriginationDate").parent().parent().css("display", "none");
                            $("#LoanMaturityDate").parent().parent().css("display", "none");
                            $("#DateLoanDefaulted").parent().parent().css("display", "none");
                            $("#CurePeriodEndDate").parent().parent().css("display", "none");
                            $("#NOTCURRENTLOAN").parent().parent().css("display", "none");
                            $("#LOANCIRCUMSTANCES").parent().parent().css("display", "none");


                            $("#plantesting").parent().css("display", "none");
                            $("#concern").parent().css("display", "none");
                            $('input[name=CONCERNTEST]').parent().parent().parent().css("display", "none");
                            $('input[name=CONCERNTEST1]').parent().parent().parent().css("display", "none");
                            $("#OTHERDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANSPONSORSTEPS").parent().parent().css("display", "none");
                            $("#PLANDESCOCCURRED").parent().parent().css("display", "none");
                            $("#PLANADDITIONALQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display", "none");
                            $("#PLANPROPOSEDQUES").parent().parent().css("display", "none");



                            $("#useof").parent().css("display", "none");
                            $("#PLANELECTIONCURRENTPRO").parent().parent().css("display", "none");
                            $("#PLANAPPEARDESCRIBELINE").parent().parent().css("display", "none");
                            $("#PLANPURPOSEDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANDESCRIBELINEREAD").parent().parent().css("display", "none");


                            $("#plandocument").parent().css("display", "none");
                            $("#PLANDOCREQUESTIMPACT").parent().parent().css("display", "none");
                            $("#PLANDESCWHATOCCURRED").parent().parent().css("display", "none");
                            $("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTION").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display", "none");

                        } else if ($(this).val() == "Loan Default Reversal Request") {
                            $("#loan").parent().css("display", "block");
                            $("#SSN").parent().parent().css("display", "block");
                            $("#LOANNUMBER").parent().parent().css("display", "block");
                            $("#LoanOriginationDate").parent().parent().css("display", "block");
                            $("#LoanMaturityDate").parent().parent().css("display", "block");
                            $("#DateLoanDefaulted").parent().parent().css("display", "block");
                            $("#CurePeriodEndDate").parent().parent().css("display", "block");
                            $("#NOTCURRENTLOAN").parent().parent().css("display", "block");
                            $("#LOANCIRCUMSTANCES").parent().parent().css("display", "block");
                            $("#Resolution").parent().parent().css("display", "block");
                            $('input[name=SONI]').parent().parent().parent().css("display", "block");
                            $("#soni").parent().css("display", "block");

                            $('input[name=SONI]').change(function() {
                                $("input[name=SONI]:checked").each(function() {
                                    if ($("input[name=SONI]:checked").val() == "YES") {
                                        $("#Soni").parent().css("display", "block");

                                    } else if ($("input[name=SONI]:checked").val() == "NO") {
                                        $("#Soni").parent().css("display", "None");

                                    }


                                });
                            });

                            $("#fraud").parent().css("display", "none");
                            $("#RPSNotifiedDate").parent().parent().css("display", "none");
                            $("#SCENARIODESCRIPTION").parent().parent().css("display", "none");
                            $("#ACTIONTAKEN").parent().parent().css("display", "none");
                            $("#description").parent().parent().css("display", "none");

                            $("#plantesting").parent().css("display", "none");
                            $("#concern").parent().css("display", "none");
                            $('input[name=CONCERNTEST]').parent().parent().parent().css("display", "none");
                            $('input[name=CONCERNTEST1]').parent().parent().parent().css("display", "none");
                            $("#OTHERDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANSPONSORSTEPS").parent().parent().css("display", "none");
                            $("#PLANDESCOCCURRED").parent().parent().css("display", "none");
                            $("#PLANADDITIONALQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display", "none");
                            $("#PLANPROPOSEDQUES").parent().parent().css("display", "none");



                            $("#useof").parent().css("display", "none");
                            $("#PLANELECTIONCURRENTPRO").parent().parent().css("display", "none");
                            $("#PLANAPPEARDESCRIBELINE").parent().parent().css("display", "none");
                            $("#PLANPURPOSEDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANDESCRIBELINEREAD").parent().parent().css("display", "none");


                            $("#plandocument").parent().css("display", "none");
                            $("#PLANDOCREQUESTIMPACT").parent().parent().css("display", "none");
                            $("#PLANDESCWHATOCCURRED").parent().parent().css("display", "none");
                            $("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTION").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display", "none");
                        } else if ($(this).val() == "Testing") {
                            $("#plantesting").parent().css("display", "block");
                            $("#concern").parent().css("display", "block");
                            $('input[name=CONCERNTEST]').parent().parent().parent().css("display", "block");
                            $('input[name=CONCERNTEST1]').parent().parent().parent().css("display", "block");

                            $("#PLANSPONSORSTEPS").parent().parent().css("display", "block");
                            $("#PLANDESCOCCURRED").parent().parent().css("display", "block");
                            $("#PLANADDITIONALQUE").parent().parent().css("display", "block");
                            $("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display", "block");
                            $("#PLANPROPOSEDQUES").parent().parent().css("display", "block");
                            $('input[name=SONI]').parent().parent().parent().css("display", "block");


                            $('input[name=SONI]').change(function() {
                                $("input[name=SONI]:checked").each(function() {
                                    if ($("input[name=SONI]:checked").val() == "YES") {
                                        $("#Soni").parent().css("display", "block");

                                    } else if ($("input[name=SONI]:checked").val() == "NO") {
                                        $("#Soni").parent().css("display", "None");

                                    }


                                });
                            });

                            $('input[name="CONCERNTEST"]').change(function() {
                                $('input[name="CONCERNTEST"]').each(function() {
                                    if ($("[name='CONCERNTEST']")[4].checked) {
                                        $("#OTHERDESCRIBE").parent().parent().css("display", "block");
                                    } else {

                                        $("#OTHERDESCRIBE").parent().parent().css("display", "none");

                                    }



                                });
                            });

                            $("#fraud").parent().css("display", "none");
                            $("#RPSNotifiedDate").parent().parent().css("display", "none");
                            $("#SCENARIODESCRIPTION").parent().parent().css("display", "none");
                            $("#ACTIONTAKEN").parent().parent().css("display", "none");


                            $("#Resolution").parent().parent().css("display", "none");
                            $("#description").parent().parent().css("display", "none");


                            $("#loan").parent().css("display", "none");
                            $("#SSN").parent().parent().css("display", "none");
                            $("#LOANNUMBER").parent().parent().css("display", "none");
                            $("#LoanOriginationDate").parent().parent().css("display", "none");
                            $("#LoanMaturityDate").parent().parent().css("display", "none");
                            $("#DateLoanDefaulted").parent().parent().css("display", "none");
                            $("#CurePeriodEndDate").parent().parent().css("display", "none");
                            $("#NOTCURRENTLOAN").parent().parent().css("display", "none");
                            $("#LOANCIRCUMSTANCES").parent().parent().css("display", "none");


                            $("#useof").parent().css("display", "none");
                            $("#PLANELECTIONCURRENTPRO").parent().parent().css("display", "none");
                            $("#PLANAPPEARDESCRIBELINE").parent().parent().css("display", "none");
                            $("#PLANPURPOSEDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANDESCRIBELINEREAD").parent().parent().css("display", "none");


                            $("#plandocument").parent().css("display", "none");
                            $("#PLANDOCREQUESTIMPACT").parent().parent().css("display", "none");
                            $("#PLANDESCWHATOCCURRED").parent().parent().css("display", "none");
                            $("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTION").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display", "none");

                        } else if ($(this).val() == "Describe Line Request") {
                            $("#useof").parent().css("display", "block");
                            $("#PLANELECTIONCURRENTPRO").parent().parent().css("display", "block");
                            $("#PLANAPPEARDESCRIBELINE").parent().parent().css("display", "block");
                            $("#PLANPURPOSEDESCRIBE").parent().parent().css("display", "block");
                            $("#PLANDESCRIBELINEREAD").parent().parent().css("display", "block");
                            $('input[name=SONI]').parent().parent().parent().css("display", "block");
                            $("#soni").parent().css("display", "block");

                            $('input[name=SONI]').change(function() {
                                $("input[name=SONI]:checked").each(function() {
                                    if ($("input[name=SONI]:checked").val() == "YES") {
                                        $("#Soni").parent().css("display", "block");

                                    } else if ($("input[name=SONI]:checked").val() == "NO") {
                                        $("#Soni").parent().css("display", "None");

                                    }


                                });
                            });

                            $("#fraud").parent().css("display", "none");
                            $("#RPSNotifiedDate").parent().parent().css("display", "none");
                            $("#SCENARIODESCRIPTION").parent().parent().css("display", "none");
                            $("#ACTIONTAKEN").parent().parent().css("display", "none");


                            $("#Resolution").parent().parent().css("display", "none");
                            $("#description").parent().parent().css("display", "none");


                            $("#loan").parent().css("display", "none");
                            $("#SSN").parent().parent().css("display", "none");
                            $("#LOANNUMBER").parent().parent().css("display", "none");
                            $("#LoanOriginationDate").parent().parent().css("display", "none");
                            $("#LoanMaturityDate").parent().parent().css("display", "none");
                            $("#DateLoanDefaulted").parent().parent().css("display", "none");
                            $("#CurePeriodEndDate").parent().parent().css("display", "none");
                            $("#NOTCURRENTLOAN").parent().parent().css("display", "none");
                            $("#LOANCIRCUMSTANCES").parent().parent().css("display", "none")

                            $("#plantesting").parent().css("display", "none");
                            $("#concern").parent().css("display", "none");
                            $('input[name=CONCERNTEST]').parent().parent().parent().css("display", "none");
                            $('input[name=CONCERNTEST1]').parent().parent().parent().css("display", "none");
                            $("#OTHERDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANSPONSORSTEPS").parent().parent().css("display", "none");
                            $("#PLANDESCOCCURRED").parent().parent().css("display", "none");
                            $("#PLANADDITIONALQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display", "none");
                            $("#PLANPROPOSEDQUES").parent().parent().css("display", "none");

                            $("#plandocument").parent().css("display", "none");
                            $("#PLANDOCREQUESTIMPACT").parent().parent().css("display", "none");
                            $("#PLANDESCWHATOCCURRED").parent().parent().css("display", "none");
                            $("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTION").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display", "none");

                        } else if ($(this).val() == "Plan Document Issue/Question") {
                            $("#plandocument").parent().css("display", "block");
                            $("#PLANDOCREQUESTIMPACT").parent().parent().css("display", "block");
                            $("#PLANDESCWHATOCCURRED").parent().parent().css("display", "block");
                            $("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display", "block");
                            $("#PLANSPONSORADDQUE").parent().parent().css("display", "block");
                            $("#PLANPROPOSESOLUTION").parent().parent().css("display", "block");
                            $("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display", "block");
                            $('input[name=SONI]').parent().parent().parent().css("display", "block");
                            $("#soni").parent().css("display", "block");

                            $('input[name=SONI]').change(function() {
                                $("input[name=SONI]:checked").each(function() {
                                    if ($("input[name=SONI]:checked").val() == "YES") {
                                        $("#Soni").parent().css("display", "block");

                                    } else if ($("input[name=SONI]:checked").val() == "NO") {
                                        $("#Soni").parent().css("display", "None");

                                    }


                                });
                            });

                            $("#fraud").parent().css("display", "none");
                            $("#RPSNotifiedDate").parent().parent().css("display", "none");
                            $("#SCENARIODESCRIPTION").parent().parent().css("display", "none");
                            $("#ACTIONTAKEN").parent().parent().css("display", "none");


                            $("#Resolution").parent().parent().css("display", "none");
                            $("#description").parent().parent().css("display", "none");


                            $("#loan").parent().css("display", "none");
                            $("#SSN").parent().parent().css("display", "none");
                            $("#LOANNUMBER").parent().parent().css("display", "none");
                            $("#LoanOriginationDate").parent().parent().css("display", "none");
                            $("#LoanMaturityDate").parent().parent().css("display", "none");
                            $("#DateLoanDefaulted").parent().parent().css("display", "none");
                            $("#CurePeriodEndDate").parent().parent().css("display", "none");
                            $("#NOTCURRENTLOAN").parent().parent().css("display", "none");
                            $("#LOANCIRCUMSTANCES").parent().parent().css("display", "none");


                            $("#plantesting").parent().css("display", "none");
                            $("#concern").parent().css("display", "none");
                            $('input[name=CONCERNTEST]').parent().parent().parent().css("display", "none");
                            $('input[name=CONCERNTEST1]').parent().parent().parent().css("display", "none");
                            $("#OTHERDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANSPONSORSTEPS").parent().parent().css("display", "none");
                            $("#PLANDESCOCCURRED").parent().parent().css("display", "none");
                            $("#PLANADDITIONALQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display", "none");
                            $("#PLANPROPOSEDQUES").parent().parent().css("display", "none");



                            $("#useof").parent().css("display", "none");
                            $("#PLANELECTIONCURRENTPRO").parent().parent().css("display", "none");
                            $("#PLANAPPEARDESCRIBELINE").parent().parent().css("display", "none");
                            $("#PLANPURPOSEDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANDESCRIBELINEREAD").parent().parent().css("display", "none");
                        } else if ($(this).val() == "Account Access/Privacy" || $(this).val() == "Adjustments" || $(this).val() == "Bankruptcy, Levy, Garnishments, & Court Orders" || $(this).val() == "Compliance Stop" || $(this).val() == "Contribution" || $(this).val() == "Correspondence Review" || $(this).val() == "Exception Request" || $(this).val() == "Distributions" || $(this).val() == "Plan Audit or Plan Year End - Other" || $(this).val() == "Plan Install or Conversion" || $(this).val() == "Plan Termination" || $(this).val() == "Plan/Participant Maint" || $(this).val() == "Process Improvement" || $(this).val() == "Tax Withholding or Tax Reporting" || $(this).val() == "Other") {
                            $('input[name=SONI]').parent().parent().parent().css("display", "block");
                            $("#description").parent().parent().css("display", "block");


                            $("#Resolution").parent().parent().css("display", "block");


                            $('input[name=SONI]').change(function() {
                                $("input[name=SONI]:checked").each(function() {
                                    if ($("input[name=SONI]:checked").val() == "YES") {
                                        $("#Soni").parent().css("display", "block");

                                    } else if ($("input[name=SONI]:checked").val() == "NO") {
                                        $("#Soni").parent().css("display", "None");

                                    }


                                });
                            });

                            $("#fraud").parent().css("display", "none");
                            $("#RPSNotifiedDate").parent().parent().css("display", "none");
                            $("#SCENARIODESCRIPTION").parent().parent().css("display", "none");
                            $("#ACTIONTAKEN").parent().parent().css("display", "none");




                            $("#loan").parent().css("display", "none");
                            $("#SSN").parent().parent().css("display", "none");
                            $("#LOANNUMBER").parent().parent().css("display", "none");
                            $("#LoanOriginationDate").parent().parent().css("display", "none");
                            $("#LoanMaturityDate").parent().parent().css("display", "none");
                            $("#DateLoanDefaulted").parent().parent().css("display", "none");
                            $("#CurePeriodEndDate").parent().parent().css("display", "none");
                            $("#NOTCURRENTLOAN").parent().parent().css("display", "none");
                            $("#LOANCIRCUMSTANCES").parent().parent().css("display", "none");


                            $("#plantesting").parent().css("display", "none");
                            $("#concern").parent().css("display", "none");
                            $('input[name=CONCERNTEST]').parent().parent().parent().css("display", "none");
                            $('input[name=CONCERNTEST1]').parent().parent().parent().css("display", "none");
                            $("#OTHERDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANSPONSORSTEPS").parent().parent().css("display", "none");
                            $("#PLANDESCOCCURRED").parent().parent().css("display", "none");
                            $("#PLANADDITIONALQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display", "none");
                            $("#PLANPROPOSEDQUES").parent().parent().css("display", "none");



                            $("#useof").parent().css("display", "none");
                            $("#PLANELECTIONCURRENTPRO").parent().parent().css("display", "none");
                            $("#PLANAPPEARDESCRIBELINE").parent().parent().css("display", "none");
                            $("#PLANPURPOSEDESCRIBE").parent().parent().css("display", "none");
                            $("#PLANDESCRIBELINEREAD").parent().parent().css("display", "none");


                            $("#plandocument").parent().css("display", "none");
                            $("#PLANDOCREQUESTIMPACT").parent().parent().css("display", "none");
                            $("#PLANDESCWHATOCCURRED").parent().parent().css("display", "none");
                            $("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUE").parent().parent().css("display", "none");
                            $("#PLANPROPOSESOLUTION").parent().parent().css("display", "none");
                            $("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display", "none");

                        }


                    });
                });
            }

            /*-----------------------------------------------------Participant Check Stop Payment/Cancellation--------------------------------------------------------*/

            if ((document.URL).includes("participant-check-stop-payment-cancellation")) {

                $("#STOPCANCELHid").parent().css("margin-right", "350px");

                $('select[name=site]').change(function() {
                    $("select[name=site] option:selected").each(function() {
                        if ($(this).val() == "IRV") {
                            alert('You selected IRV. Is that correct?');

                        } else if ($(this).val() == "SNO") {
                            alert('You selected SNO. Is that correct?');

                        } else if ($(this).val() == "IND") {
                            alert('You selected IND. Is that correct?');

                        } else if ($(this).val() == "HRO") {
                            alert('You selected HRO. Is that correct?');

                        }
                    });

                });
            }

            /*-------------------------------------------Request for PSW Research----------------------------------------------------------------------------------------*/

            if ((document.URL).includes("request-for-psw-research")) {

                $("#worktypes").prop("disabled", true);
                $('#worktypes').prop('value', 'PSW Research');
                $('#worktypes').click();
            }


            /*=--------------------------------------------------------------Schedule Adjustment Request Form--------------------------------------------------------------------------------------------*/

            if ((document.URL).includes("rp-schedule-adjustment-form")) {

                $("#start1").prop("disabled", true);
                $("#end1").prop("disabled", true);

                $('input[name=flex2]').parent().parent().parent().css("display", "none");
                $("#type2").parent().parent().css("display", "none");
                $("#flex2").parent().css("display", "none");
                $("#start2").parent().parent().css("display", "none");
                $("#end2").parent().parent().css("display", "none");
                $("#montxt2").parent().css("display", "none");
                $('input[name=montxt2]').parent().parent().parent().css("display", "none");
                $("#addl2").parent().parent().css("display", "none");
                $("#more2").parent().css("display", "none");
                $('input[name=more2]').parent().parent().parent().css("display", "none");
                $("#amt2").parent().css("display", "none");
                $("#hrs2").parent().parent().css("display", "none");
                $("#hr2").parent().css("display", "none");
                $("#mins2").parent().parent().css("display", "none");
                $("#mi2").parent().css("display", "none");

                $("#start2").prop("disabled", true);
                $("#end2").prop("disabled", true);

                $('input[name=flex3]').parent().parent().parent().css("display", "none");
                $("#type3").parent().parent().css("display", "none");
                $("#flex3").parent().css("display", "none");
                $("#start3").parent().parent().css("display", "none");
                $("#end3").parent().parent().css("display", "none");
                $("#montxt3").parent().css("display", "none");
                $('input[name=montxt3]').parent().parent().parent().css("display", "none");
                $("#addl3").parent().parent().css("display", "none");
                $("#more3").parent().css("display", "none");
                $('input[name=more3]').parent().parent().parent().css("display", "none");
                $("#amt3").parent().css("display", "none");
                $("#hrs3").parent().parent().css("display", "none");
                $("#hr3").parent().css("display", "none");
                $("#mins3").parent().parent().css("display", "none");
                $("#mi3").parent().css("display", "none");

                $("#start3").prop("disabled", true);
                $("#end3").prop("disabled", true);

                $('input[name=flex4]').parent().parent().parent().css("display", "none");
                $("#type4").parent().parent().css("display", "none");
                $("#flex4").parent().css("display", "none");
                $("#start4").parent().parent().css("display", "none");
                $("#end4").parent().parent().css("display", "none");
                $("#montxt4").parent().css("display", "none");
                $('input[name=montxt4]').parent().parent().parent().css("display", "none");
                $("#addl4").parent().parent().css("display", "none");
                $("#amt4").parent().css("display", "none");
                $("#hrs4").parent().parent().css("display", "none");
                $("#hr4").parent().css("display", "none");
                $("#mins4").parent().parent().css("display", "none");
                $("#mi4").parent().css("display", "none");

                $("#start4").prop("disabled", true);
                $("#end4").prop("disabled", true);


                $('input[name="more1"]').attr('checked', false);
                $('input[name="more2"]').attr('checked', false);
                $('input[name="more3"]').attr('checked', false);
                $('input[name="more4"]').attr('checked', false);

                $("#Sep7").parent().css("display", "none");
                $("#Sep8").parent().css("display", "none");
                $("#Sep9").parent().css("display", "none");




                $('input[name=flex1]').change(function() {
                    $("input[name=flex1]:checked").each(function() {
                        if ($("input[name=flex1]:checked").val() == "YES") {
                            $("#start1").prop("disabled", true);
                            $("#end1").prop("disabled", true);
                        } else if ($("input[name=flex1]:checked").val() == "NO") {
                            $("#start1").prop("disabled", false);
                            $("#end1").prop("disabled", false);

                        }



                    });
                });

                $('input[name=more1]').change(function() {
                    $("input[name=more1]:checked").each(function() {
                        if ($("input[name=more1]:checked").val() == "YES") {
                            $('input[name=flex2]').parent().parent().parent().css("display", "block");
                            $("#type2").parent().parent().css("display", "block");
                            $("#flex2").parent().css("display", "block");
                            $("#start2").parent().parent().css("display", "block");
                            $("#end2").parent().parent().css("display", "block");
                            $("#montxt2").parent().css("display", "block");
                            $('input[name=montxt2]').parent().parent().parent().css("display", "block");
                            $("#addl2").parent().parent().css("display", "block");
                            $("#more2").parent().css("display", "block");
                            $('input[name=more2]').parent().parent().parent().css("display", "block");

                            $("#amt2").parent().css("display", "block");
                            $("#hrs2").parent().parent().css("display", "block");
                            $("#hr2").parent().css("display", "block");
                            $("#mins2").parent().parent().css("display", "block");
                            $("#mi2").parent().css("display", "block");

                            $('input[name="more2"]').attr('checked', false);
                            $('input[name="more3"]').attr('checked', false);
                            $('input[name="more4"]').attr('checked', false);

                            $("#Sep7").parent().css("display", "block");

                            $('input[name=flex2]').change(function() {
                                $("input[name=flex2]:checked").each(function() {
                                    if ($("input[name=flex2]:checked").val() == "flex2y") {
                                        $("#start2").prop("disabled", true);
                                        $("#end2").prop("disabled", true);
                                    } else if ($("input[name=flex2]:checked").val() == "flex2n") {
                                        $("#start2").prop("disabled", false);
                                        $("#end2").prop("disabled", false);

                                    }


                                });
                            });




                        } else if ($("input[name=more1]:checked").val() == "NO") {
                            $('input[name=flex2]').parent().parent().parent().css("display", "none");
                            $("#type2").parent().parent().css("display", "none");
                            $("#flex2").parent().css("display", "none");
                            $("#start2").parent().parent().css("display", "none");
                            $("#end2").parent().parent().css("display", "none");
                            $("#montxt2").parent().css("display", "none");
                            $('input[name=montxt2]').parent().parent().parent().css("display", "none");
                            $("#addl2").parent().parent().css("display", "none");
                            $("#more2").parent().css("display", "none");
                            $('input[name=more2]').parent().parent().parent().css("display", "none");

                            $("#amt2").parent().css("display", "none");
                            $("#hrs2").parent().parent().css("display", "none");
                            $("#hr2").parent().css("display", "none");
                            $("#mins2").parent().parent().css("display", "none");
                            $("#mi2").parent().css("display", "none");
                            $("#Sep7").parent().css("display", "none");
                            $("#Sep8").parent().css("display", "none");
                            $("#Sep9").parent().css("display", "none");
                        }



                    });
                });

                $('input[name=more2]').change(function() {
                    $("input[name=more2]:checked").each(function() {
                        if ($("input[name=more2]:checked").val() == "YES") {
                            $('input[name=flex3]').parent().parent().parent().css("display", "block");
                            $("#type3").parent().parent().css("display", "block");
                            $("#flex3").parent().css("display", "block");
                            $("#start3").parent().parent().css("display", "block");
                            $("#end3").parent().parent().css("display", "block");
                            $("#montxt3").parent().css("display", "block");
                            $('input[name=montxt3]').parent().parent().parent().css("display", "block");
                            $("#addl3").parent().parent().css("display", "block");
                            $("#more3").parent().css("display", "block");
                            $('input[name=more3]').parent().parent().parent().css("display", "block");

                            $("#amt3").parent().css("display", "block");
                            $("#hrs3").parent().parent().css("display", "block");
                            $("#hr3").parent().css("display", "block");
                            $("#mins3").parent().parent().css("display", "block");
                            $("#mi3").parent().css("display", "block");

                            $("#Sep8").parent().css("display", "block");


                            $('input[name=flex3]').change(function() {
                                $("input[name=flex3]:checked").each(function() {
                                    if ($("input[name=flex3]:checked").val() == "flex3y") {
                                        $("#start3").prop("disabled", true);
                                        $("#end3").prop("disabled", true);
                                    } else if ($("input[name=flex3]:checked").val() == "flex3n") {
                                        $("#start3").prop("disabled", false);
                                        $("#end3").prop("disabled", false);

                                    }


                                });
                            });




                        } else if ($("input[name=more2]:checked").val() == "NO") {
                            $('input[name=flex3]').parent().parent().parent().css("display", "none");
                            $("#type3").parent().parent().css("display", "none");
                            $("#flex3").parent().css("display", "none");
                            $("#start3").parent().parent().css("display", "none");
                            $("#end3").parent().parent().css("display", "none");
                            $("#montxt3").parent().css("display", "none");
                            $('input[name=montxt3]').parent().parent().parent().css("display", "none");
                            $("#addl3").parent().parent().css("display", "none");
                            $("#more3").parent().css("display", "none");
                            $('input[name=more3]').parent().parent().parent().css("display", "none");

                            $("#amt3").parent().css("display", "none");
                            $("#hrs3").parent().parent().css("display", "none");
                            $("#hr3").parent().css("display", "none");
                            $("#mins3").parent().parent().css("display", "none");
                            $("#mi3").parent().css("display", "none");

                            $("#Sep7").parent().css("display", "block");
                            $("#Sep8").parent().css("display", "none");
                            $("#Sep9").parent().css("display", "none");


                        }



                    });
                });


                $('input[name=more3]').change(function() {
                    $("input[name=more3]:checked").each(function() {
                        if ($("input[name=more3]:checked").val() == "YES") {
                            $('input[name=flex4]').parent().parent().parent().css("display", "block");
                            $("#type4").parent().parent().css("display", "block");
                            $("#flex4").parent().css("display", "block");
                            $("#start4").parent().parent().css("display", "block");
                            $("#end4").parent().parent().css("display", "block");
                            $("#montxt4").parent().css("display", "block");
                            $('input[name=montxt4]').parent().parent().parent().css("display", "block");
                            $("#addl4").parent().parent().css("display", "block");

                            $("#amt4").parent().css("display", "block");
                            $("#hrs4").parent().parent().css("display", "block");
                            $("#hr4").parent().css("display", "block");
                            $("#mins4").parent().parent().css("display", "block");
                            $("#mi4").parent().css("display", "block");

                            $("#Sep9").parent().css("display", "block");


                            $('input[name=flex4]').change(function() {
                                $("input[name=flex4]:checked").each(function() {
                                    if ($("input[name=flex4]:checked").val() == "flex4y") {
                                        $("#start4").prop("disabled", true);
                                        $("#end4").prop("disabled", true);
                                    } else if ($("input[name=flex4]:checked").val() == "flex4n") {
                                        $("#start4").prop("disabled", false);
                                        $("#end4").prop("disabled", false);

                                    }


                                });
                            });




                        } else if ($("input[name=more3]:checked").val() == "NO") {
                            $('input[name=flex4]').parent().parent().parent().css("display", "none");
                            $("#type4").parent().parent().css("display", "none");
                            $("#flex4").parent().css("display", "none");
                            $("#start4").parent().parent().css("display", "none");
                            $("#end4").parent().parent().css("display", "none");
                            $("#montxt4").parent().css("display", "none");
                            $('input[name=montxt4]').parent().parent().parent().css("display", "none");
                            $("#addl4").parent().parent().css("display", "none");
                            $("#amt4").parent().css("display", "none");
                            $("#hrs4").parent().parent().css("display", "none");
                            $("#hr4").parent().css("display", "none");
                            $("#mins4").parent().parent().css("display", "none");
                            $("#mi4").parent().css("display", "none");


                            $('input[name="more2"]').attr('checked', false);
                            $('input[name="more3"]').attr('checked', false);
                            $('input[name="more4"]').attr('checked', false);


                            $("#Sep7").parent().css("display", "none");
                            $("#Sep8").parent().css("display", "none");
                            $("#Sep9").parent().css("display", "none");



                        }



                    });
                });

                $('input[name=more2]').change(function() {
                    $("input[name=more2]:checked").each(function() {
                        if ($("input[name=more2]:checked").val() == "YES") {
                            $('input[name=flex3]').parent().parent().parent().css("display", "block");
                            $("#type3").parent().parent().css("display", "block");
                            $("#flex3").parent().css("display", "block");
                            $("#start3").parent().parent().css("display", "block");
                            $("#end3").parent().parent().css("display", "block");
                            $("#montxt3").parent().css("display", "block");
                            $('input[name=montxt3]').parent().parent().parent().css("display", "block");
                            $("#addl3").parent().parent().css("display", "block");
                            $("#more3").parent().css("display", "block");
                            $('input[name=more3]').parent().parent().parent().css("display", "block");

                            $("#amt3").parent().css("display", "block");
                            $("#hrs3").parent().parent().css("display", "block");
                            $("#hr3").parent().css("display", "block");
                            $("#mins3").parent().parent().css("display", "block");
                            $("#mi3").parent().css("display", "block");

                            $('input[name="more3"]').attr('checked', false);
                            $('input[name="more4"]').attr('checked', false);

                            $("#Sep8").parent().css("display", "block");


                            $('input[name=flex3]').change(function() {
                                $("input[name=flex3]:checked").each(function() {
                                    if ($("input[name=flex3]:checked").val() == "flex3y") {
                                        $("#start3").prop("disabled", true);
                                        $("#end3").prop("disabled", true);
                                    } else if ($("input[name=flex3]:checked").val() == "flex3n") {
                                        $("#start3").prop("disabled", false);
                                        $("#end3").prop("disabled", false);

                                    }


                                });
                            });




                        } else if ($("input[name=more2]:checked").val() == "NO") {
                            $('input[name=flex3]').parent().parent().parent().css("display", "none");
                            $("#type3").parent().parent().css("display", "none");
                            $("#flex3").parent().css("display", "none");
                            $("#start3").parent().parent().css("display", "none");
                            $("#end3").parent().parent().css("display", "none");
                            $("#montxt3").parent().css("display", "none");
                            $('input[name=montxt3]').parent().parent().parent().css("display", "none");
                            $("#addl3").parent().parent().css("display", "none");
                            $("#more3").parent().css("display", "none");
                            $('input[name=more3]').parent().parent().parent().css("display", "none");

                            $("#amt3").parent().css("display", "none");
                            $("#hrs3").parent().parent().css("display", "none");
                            $("#hr3").parent().css("display", "none");
                            $("#mins3").parent().parent().css("display", "none");
                            $("#mi3").parent().css("display", "none");

                            $('input[name=flex4]').parent().parent().parent().css("display", "none");
                            $("#type4").parent().parent().css("display", "none");
                            $("#flex4").parent().css("display", "none");
                            $("#start4").parent().parent().css("display", "none");
                            $("#end4").parent().parent().css("display", "none");
                            $("#montxt4").parent().css("display", "none");
                            $('input[name=montxt4]').parent().parent().parent().css("display", "none");
                            $("#addl4").parent().parent().css("display", "none");


                            $("#amt4").parent().css("display", "none");
                            $("#hrs4").parent().parent().css("display", "none");
                            $("#hr4").parent().css("display", "none");
                            $("#mins4").parent().parent().css("display", "none");
                            $("#mi4").parent().css("display", "none");

                            $('input[name="more3"]').attr('checked', false);
                            $('input[name="more4"]').attr('checked', false);


                            $("#Sep7").parent().css("display", "block");
                            $("#Sep8").parent().css("display", "none");
                            $("#Sep9").parent().css("display", "none");


                        }



                    });
                });


                $('input[name=more3]').change(function() {
                    $("input[name=more3]:checked").each(function() {
                        if ($("input[name=more3]:checked").val() == "YES") {
                            $('input[name=flex4]').parent().parent().parent().css("display", "block");
                            $("#type4").parent().parent().css("display", "block");
                            $("#flex4").parent().css("display", "block");
                            $("#start4").parent().parent().css("display", "block");
                            $("#end4").parent().parent().css("display", "block");
                            $("#montxt4").parent().css("display", "block");
                            $('input[name=montxt4]').parent().parent().parent().css("display", "block");
                            $("#addl4").parent().parent().css("display", "block");

                            $("#amt4").parent().css("display", "block");
                            $("#hrs4").parent().parent().css("display", "block");
                            $("#hr4").parent().css("display", "block");
                            $("#mins4").parent().parent().css("display", "block");
                            $("#mi4").parent().css("display", "block");

                            $('input[name="more4"]').attr('checked', false);

                            $("#Sep9").parent().css("display", "block");


                            $('input[name=flex4]').change(function() {
                                $("input[name=flex4]:checked").each(function() {
                                    if ($("input[name=flex4]:checked").val() == "flex4y") {
                                        $("#start4").prop("disabled", true);
                                        $("#end4").prop("disabled", true);
                                    } else if ($("input[name=flex4]:checked").val() == "flex4n") {
                                        $("#start4").prop("disabled", false);
                                        $("#end4").prop("disabled", false);

                                    }


                                });
                            });




                        } else if ($("input[name=more3]:checked").val() == "NO") {
                            $('input[name=flex4]').parent().parent().parent().css("display", "none");
                            $("#type4").parent().parent().css("display", "none");
                            $("#flex4").parent().css("display", "none");
                            $("#start4").parent().parent().css("display", "none");
                            $("#end4").parent().parent().css("display", "none");
                            $("#montxt4").parent().css("display", "none");
                            $('input[name=montxt4]').parent().parent().parent().css("display", "none");
                            $("#addl4").parent().parent().css("display", "none");

                            $("#amt4").parent().css("display", "none");
                            $("#hrs4").parent().parent().css("display", "none");
                            $("#hr4").parent().css("display", "none");
                            $("#mins4").parent().parent().css("display", "none");
                            $("#mi4").parent().css("display", "none");

                            $('input[name="more4"]').attr('checked', false);

                            $("#Sep7").parent().css("display", "block");
                            $("#Sep8").parent().css("display", "block");
                            $("#Sep9").parent().css("display", "none");



                        }



                    });
                });
            }

            /*-----------------------------------------------------------RPS Announcement Communication Request Form-----------------------------------------*/

            if ((document.URL).includes("rps-announcement-communication-request-form")) {

                $("#site").parent().css("display", "none");
                $('input[name=site1]').parent().parent().parent().css("display", "none");
                $("#Other1").parent().parent().css("display", "none");
                $("#txtListContactInitials").parent().parent().css("display", "none");
                $("#txtnonCGEmailAddress").parent().parent().css("display", "none");
                $("#txtAnotherDepartment").parent().parent().css("display", "none");

                $("#npa").parent().css("display", "none");
                $("#newOpp").parent().css("display", "none");
                $("#txtnewOpportunityTitle").parent().parent().css("display", "none");
                $('input[name=newOpportunityIndividualSiteSection]').parent().parent().parent().css("display", "none");
                $("#newOpportunityNonRPSAssociates1").parent().css("display", "none");
                $('input[name=newOpportunityNonRPSAssociates]').parent().parent().parent().css("display", "none");
                $("#hri").parent().parent().css("display", "none");
                $("#newOpportunityInternship1").parent().css("display", "none");
                $('input[name=newOpportunityInternship]').parent().parent().parent().css("display", "none");
                $("#txtNewOpportunityInternshipDuration").parent().parent().css("display", "none");
                $("#intern").parent().css("display", "none");
                $("#rps").parent().css("display", "none");
                $("#txtSkillsAndCompetencies").parent().parent().css("display", "none");
                $("#txtRoleDescription").parent().parent().css("display", "none");
                $("#txtDeadline").parent().parent().css("display", "none");
                $("#txtContactInitials").parent().parent().css("display", "none");
                $("#relaviteComments").parent().parent().css("display", "none");


                $("#filled").parent().css("display", "none");
                $("#txtFilledOpportunityTitle").parent().parent().css("display", "none");
                $("#txtFilledOpportunityEffectiveDate").parent().parent().css("display", "none");
                $("#txtFilledOpportunityAssociateInitials").parent().parent().css("display", "none");
                $("#filledOpportunityScenarios1").parent().css("display", "none");
                $('input[name=filledOpportunityScenarios]').parent().parent().parent().css("display", "none");
                $("#bio").parent().css("display", "none");
                $("#txtFilledOpportunityRelevantInformation").parent().parent().css("display", "none");
                $("#biot").parent().css("display", "none");
                $("#pit").parent().css("display", "none");
                $("#txtCompleteBIO").parent().parent().css("display", "none");
                $("#sample").parent().css("display", "none");


                $("#oppo").parent().css("display", "none");
                $("#txtOpportunityUpdateTitle").parent().parent().css("display", "none");
                $("#txtOpportunityUpdateEffectiveDate").parent().parent().css("display", "none");
                $("#txtOpportunityUpdateAssociateInitials").parent().parent().css("display", "none");
                $("#opportunityUpdatePreviousAnnouncement1").parent().css("display", "none");
                $('input[name=opportunityUpdatePreviousAnnouncement]').parent().parent().parent().css("display", "none");
                $("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display", "none");
                $("#txtOpportunityUpdateRelevantInformation").parent().parent().css("display", "none");
                $("#oppo_label").parent().css("display", "none");

                $("#Sep1").parent().css("display", "none");
                $("#Sep2").parent().css("display", "none");
                $("#Sep3").parent().css("display", "none");
                $("#Sep4").parent().css("display", "none");




                $('input[name=communicationDL]').change(function() {
                    $("input[name=communicationDL]").each(function() {
                        if ($("[name='communicationDL']")[5].checked) {
                            $("#site").parent().css("display", "block");
                            $('input[name=site1]').parent().parent().parent().css("display", "block");
                            $("#Other1").parent().parent().css("display", "block");
                        }
                        if (!$("[name='communicationDL']")[5].checked) {
                            $("#site").parent().css("display", "none");
                            $('input[name=site1]').parent().parent().parent().css("display", "none");
                            $("#Other1").parent().parent().css("display", "none");
                        }
                        if ($("[name='communicationDL']")[1].checked || $("[name='communicationDL']")[2].checked || $("[name='communicationDL']")[3].checked || $("[name='communicationDL']")[4].checked) {
                            $("#site").parent().css("display", "block");
                            $('input[name=site1]').parent().parent().parent().css("display", "block");

                        }
                    });
                });

                $('input[name="site1"]').eq(3).change(function() {
                    if ($("[name='site1']")[3].checked) {
                        $("[name='site1']").eq(0).prop("checked", true);
                        $("[name='site1']").eq(1).prop("checked", true);
                        $("[name='site1']").eq(2).prop("checked", true);

                    }
                    if (!$("[name='site1']")[3].checked) {
                        $("[name='site1']").eq(0).prop("checked", false);
                        $("[name='site1']").eq(1).prop("checked", false);
                        $("[name='site1']").eq(2).prop("checked", false);
                    }

                });
				$('input[name="site1"]').change(function() {

					if($("[name='site1']:checked").length!=4) {
						$("[name='site1']").eq(3).prop("checked", false);
                    }
                     var checkbox1=$("[name='site1']").eq(0).prop("checked");
                     var checkbox2=$("[name='site1']").eq(1).prop("checked");
                     var checkbox3=$("[name='site1']").eq(2).prop("checked");
                     if(checkbox1 && checkbox2 && checkbox3) {
						$("[name='site1']").eq(3).prop("checked", true);
                     }
                 });
                $('input[name="newOpportunityIndividualSiteSection"]').eq(3).change(function() {
                    if ($("[name='newOpportunityIndividualSiteSection']")[3].checked) {
                        $("[name='newOpportunityIndividualSiteSection']").eq(0).prop("checked", true);
                        $("[name='newOpportunityIndividualSiteSection']").eq(1).prop("checked", true);
                        $("[name='newOpportunityIndividualSiteSection']").eq(2).prop("checked", true);

                    }
                    if (!$("[name='newOpportunityIndividualSiteSection']")[3].checked) {
                        $("[name='newOpportunityIndividualSiteSection']").eq(0).prop("checked", false);
                        $("[name='newOpportunityIndividualSiteSection']").eq(1).prop("checked", false);
                        $("[name='newOpportunityIndividualSiteSection']").eq(2).prop("checked", false);
                    }

                });

				$('input[name="newOpportunityIndividualSiteSection"]').change(function() {

					if($("[name='newOpportunityIndividualSiteSection']:checked").length!=4) {
						$("[name='newOpportunityIndividualSiteSection']").eq(3).prop("checked", false);
                    }
                     var checkbox1=$("[name='newOpportunityIndividualSiteSection']").eq(0).prop("checked");
                     var checkbox2=$("[name='newOpportunityIndividualSiteSection']").eq(1).prop("checked");
                     var checkbox3=$("[name='newOpportunityIndividualSiteSection']").eq(2).prop("checked");
                     if(checkbox1 && checkbox2 && checkbox3) {
						$("[name='newOpportunityIndividualSiteSection']").eq(3).prop("checked", true);
                     }
                 });


                $('input[name=outsideRPS]').change(function() {
                    $("input[name=outsideRPS]").each(function() {
                        if ($("input[name=outsideRPS]:checked").val() == "YES") {


                            $("#txtListContactInitials").parent().parent().css("display", "block");
                            $("#txtnonCGEmailAddress").parent().parent().css("display", "block");




                        } else if ($("input[name=outsideRPS]:checked").val() == "NO") {

                            $("#txtListContactInitials").parent().parent().css("display", "none");
                            $("#txtnonCGEmailAddress").parent().parent().css("display", "none");


                        }

                    });
                });



                $('input[name=anotherDepartmentInitials]').change(function() {
                    $("input[name=anotherDepartmentInitials]").each(function() {
                        if ($("input[name=anotherDepartmentInitials]:checked").val() == "YES") {


                            $("#txtAnotherDepartment").parent().parent().css("display", "block");


                        } else if ($("input[name=anotherDepartmentInitials]:checked").val() == "NO") {

                            $("#txtAnotherDepartment").parent().parent().css("display", "none");

                        }

                    });
                });



                $('input[name=TypeOfAnnouncement]').change(function() {
                    $("input[name=TypeOfAnnouncement]").each(function() {
                        if ($("input[name=TypeOfAnnouncement]:checked").val() == "New Opportunity") {

                            $("#npa").parent().css("display", "block");
                            $("#txtnewOpportunityTitle").parent().parent().css("display", "block");
                            $("#newOpp").parent().css("display", "block");
                            $('input[name=newOpportunityIndividualSiteSection]').parent().parent().parent().css("display", "block");
                            $("#newOpportunityNonRPSAssociates1").parent().css("display", "block");
                            $('input[name=newOpportunityNonRPSAssociates]').parent().parent().parent().css("display", "block");
                            $("#Sep1").parent().css("display", "block");


                            $('input[name=newOpportunityNonRPSAssociates]').change(function() {
                                $("input[name=newOpportunityNonRPSAssociates]").each(function() {
                                    if ($("input[name=newOpportunityNonRPSAssociates]:checked").val() == "YES") {

                                        $("#hri").parent().parent().css("display", "block");


                                    } else if ($("input[name=newOpportunityNonRPSAssociates]:checked").val() == "NO") {

                                        $("#hri").parent().parent().css("display", "none");

                                    }

                                });
                            });
                            $("#newOpportunityInternship1").parent().css("display", "block");
                            $('input[name=newOpportunityInternship]').parent().parent().parent().css("display", "block");



                            $('input[name=newOpportunityInternship]').change(function() {
                                $("input[name=newOpportunityInternship]").each(function() {
                                    if ($("input[name=newOpportunityInternship]:checked").val() == "YES") {


                                        $("#txtNewOpportunityInternshipDuration").parent().parent().css("display", "block");
                                        $("#intern").parent().css("display", "block");
                                        $("#rps").parent().css("display", "block");
                                        $("#txtSkillsAndCompetencies").parent().parent().css("display", "block");
                                        $("#txtRoleDescription").parent().parent().css("display", "block");
                                        $("#txtDeadline").parent().parent().css("display", "block");
                                        $("#txtContactInitials").parent().parent().css("display", "block");
                                        $("#relaviteComments").parent().parent().css("display", "block")

                                    } else if ($("input[name=newOpportunityInternship]:checked").val() == "NO") {


                                        $("#txtNewOpportunityInternshipDuration").parent().parent().css("display", "none");
                                        $("#intern").parent().css("display", "none");
                                        $("#rps").parent().css("display", "block");
                                        $("#txtSkillsAndCompetencies").parent().parent().css("display", "block");
                                        $("#txtRoleDescription").parent().parent().css("display", "block");
                                        $("#txtDeadline").parent().parent().css("display", "block");
                                        $("#txtContactInitials").parent().parent().css("display", "block");
                                        $("#relaviteComments").parent().parent().css("display", "block")


                                    }

                                });
                            });
                            $("#rps").parent().css("display", "block");
                            $("#txtSkillsAndCompetencies").parent().parent().css("display", "block");
                            $("#txtRoleDescription").parent().parent().css("display", "block");
                            $("#txtDeadline").parent().parent().css("display", "block");
                            $("#txtContactInitials").parent().parent().css("display", "block");
                            $("#relaviteComments").parent().parent().css("display", "block");
                            $("#filled").parent().css("display", "none");
                            $("#txtFilledOpportunityTitle").parent().parent().css("display", "none");
                            $("#txtFilledOpportunityEffectiveDate").parent().parent().css("display", "none");
                            $("#txtFilledOpportunityAssociateInitials").parent().parent().css("display", "none");
                            $("#filledOpportunityScenarios1").parent().css("display", "none");
                            $('input[name=filledOpportunityScenarios]').parent().parent().parent().css("display", "none");
                            $("#bio").parent().css("display", "none");
                            $("#txtFilledOpportunityRelevantInformation").parent().parent().css("display", "none");
                            $("#biot").parent().css("display", "none");
                            $("#pit").parent().css("display", "none");
                            $("#txtCompleteBIO").parent().parent().css("display", "none");
                            $("#sample").parent().css("display", "none");


                            $("#oppo").parent().css("display", "none");
                            $("#txtOpportunityUpdateTitle").parent().parent().css("display", "none");
                            $("#txtOpportunityUpdateEffectiveDate").parent().parent().css("display", "none");
                            $("#txtOpportunityUpdateAssociateInitials").parent().parent().css("display", "none");
                            $("#opportunityUpdatePreviousAnnouncement1").parent().css("display", "none");
                            $('input[name=opportunityUpdatePreviousAnnouncement]').parent().parent().parent().css("display", "none");
                            $("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display", "none");
                            $("#txtOpportunityUpdateRelevantInformation").parent().parent().css("display", "none");
                            $("#oppo_label").parent().css("display", "none");
                            $("#Sep2").parent().css("display", "none");
                            $("#Sep3").parent().css("display", "none");
                            $("#Sep4").parent().css("display", "none");


                        } else if ($("input[name=TypeOfAnnouncement]:checked").val() == "Filled Opportunity") {
                            $("#filled").parent().css("display", "block");
                            $("#txtFilledOpportunityTitle").parent().parent().css("display", "block");
                            $("#txtFilledOpportunityEffectiveDate").parent().parent().css("display", "block");
                            $("#txtFilledOpportunityAssociateInitials").parent().parent().css("display", "block");
                            $("#filledOpportunityScenarios1").parent().css("display", "block");
                            $('input[name=filledOpportunityScenarios]').parent().parent().parent().css("display", "block");
                            $("#bio").parent().css("display", "block");
                            $("#txtFilledOpportunityRelevantInformation").parent().parent().css("display", "block");
                            $("#Sep2").parent().css("display", "block");
                            $("#Sep3").parent().css("display", "block");


                            $('input[name=filledOpportunityScenarios]').change(function() {
                                $("input[name=filledOpportunityScenarios]").each(function() {
                                    if ($("input[name=filledOpportunityScenarios]:checked").val() == "YES") {
                                        $("#biot").parent().css("display", "block");
                                        $("#pit").parent().css("display", "block");
                                        $("#txtCompleteBIO").parent().parent().css("display", "block");
                                        $("#sample").parent().css("display", "block");
                                        $("#Sep3").parent().css("display", "block");

                                    } else if ($("input[name=filledOpportunityScenarios]:checked").val() == "NO") {
                                        $("#biot").parent().css("display", "none");
                                        $("#pit").parent().css("display", "none");
                                        $("#txtCompleteBIO").parent().parent().css("display", "none");
                                        $("#sample").parent().css("display", "none");
                                        $("#Sep3").parent().css("display", "none");

                                    }

                                });
                            });
                            $("#npa").parent().css("display", "none");
                            $("#newOpp").parent().css("display", "none");
                            $("#txtnewOpportunityTitle").parent().parent().css("display", "none");
                            $('input[name=newOpportunityIndividualSiteSection]').parent().parent().parent().css("display", "none");
                            $("#newOpportunityNonRPSAssociates1").parent().css("display", "none");
                            $('input[name=newOpportunityNonRPSAssociates]').parent().parent().parent().css("display", "none");
                            $("#hri").parent().parent().css("display", "none");
                            $("#newOpportunityInternship1").parent().css("display", "none");
                            $('input[name=newOpportunityInternship]').parent().parent().parent().css("display", "none");
                            $("#txtNewOpportunityInternshipDuration").parent().parent().css("display", "none");
                            $("#intern").parent().css("display", "none");
                            $("#rps").parent().css("display", "none");
                            $("#txtSkillsAndCompetencies").parent().parent().css("display", "none");
                            $("#txtRoleDescription").parent().parent().css("display", "none");
                            $("#txtDeadline").parent().parent().css("display", "none");
                            $("#txtContactInitials").parent().parent().css("display", "none");
                            $("#relaviteComments").parent().parent().css("display", "none");

                            $("#oppo").parent().css("display", "none");
                            $("#txtOpportunityUpdateTitle").parent().parent().css("display", "none");
                            $("#txtOpportunityUpdateEffectiveDate").parent().parent().css("display", "none");
                            $("#txtOpportunityUpdateAssociateInitials").parent().parent().css("display", "none");
                            $("#opportunityUpdatePreviousAnnouncement1").parent().css("display", "none");
                            $('input[name=opportunityUpdatePreviousAnnouncement]').parent().parent().parent().css("display", "none");
                            $("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display", "none");
                            $("#txtOpportunityUpdateRelevantInformation").parent().parent().css("display", "none");
                            $("#oppo_label").parent().css("display", "none");
                            $("#Sep1").parent().css("display", "none");
                            $("#Sep3").parent().css("display", "none");
                            $("#Sep4").parent().css("display", "none");




                        } else if ($("input[name=TypeOfAnnouncement]:checked").val() == "Opportunity Updates ") {
                            $("#oppo").parent().css("display", "block");
                            $("#txtOpportunityUpdateTitle").parent().parent().css("display", "block");
                            $("#txtOpportunityUpdateEffectiveDate").parent().parent().css("display", "block");
                            $("#txtOpportunityUpdateAssociateInitials").parent().parent().css("display", "block");
                            $("#opportunityUpdatePreviousAnnouncement1").parent().css("display", "block");
                            $('input[name=opportunityUpdatePreviousAnnouncement]').parent().parent().parent().css("display", "block");


                            $("#txtOpportunityUpdateRelevantInformation").parent().parent().css("display", "block");
                            $("#oppo_label").parent().css("display", "block");
                            $("#Sep4").parent().css("display", "block");



                            $('input[name=opportunityUpdatePreviousAnnouncement]').change(function() {
                                $("input[name=opportunityUpdatePreviousAnnouncement]").each(function() {
                                    if ($("input[name=opportunityUpdatePreviousAnnouncement]:checked").val() == "YES") {

                                        $("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display", "block");

                                    } else if ($("input[name=opportunityUpdatePreviousAnnouncement]:checked").val() == "NO") {

                                        $("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display", "none");

                                    }

                                });
                            });

                            $("#npa").parent().css("display", "none");
                            $("#newOpp").parent().css("display", "none");
                            $("#txtnewOpportunityTitle").parent().parent().css("display", "none");
                            $('input[name=newOpportunityIndividualSiteSection]').parent().parent().parent().css("display", "none");
                            $("#newOpportunityNonRPSAssociates1").parent().css("display", "none");
                            $('input[name=newOpportunityNonRPSAssociates]').parent().parent().parent().css("display", "none");
                            $("#hri").parent().parent().css("display", "none");
                            $("#newOpportunityInternship1").parent().css("display", "none");
                            $('input[name=newOpportunityInternship]').parent().parent().parent().css("display", "none");
                            $("#txtNewOpportunityInternshipDuration").parent().parent().css("display", "none");
                            $("#intern").parent().css("display", "none");
                            $("#rps").parent().css("display", "none");
                            $("#txtSkillsAndCompetencies").parent().parent().css("display", "none");
                            $("#txtRoleDescription").parent().parent().css("display", "none");
                            $("#txtDeadline").parent().parent().css("display", "none");
                            $("#txtContactInitials").parent().parent().css("display", "none");
                            $("#relaviteComments").parent().parent().css("display", "none");


                            $("#filled").parent().css("display", "none");
                            $("#txtFilledOpportunityTitle").parent().parent().css("display", "none");
                            $("#txtFilledOpportunityEffectiveDate").parent().parent().css("display", "none");
                            $("#txtFilledOpportunityAssociateInitials").parent().parent().css("display", "none");
                            $("#filledOpportunityScenarios1").parent().css("display", "none");
                            $('input[name=filledOpportunityScenarios]').parent().parent().parent().css("display", "none");
                            $("#bio").parent().css("display", "none");
                            $("#txtFilledOpportunityRelevantInformation").parent().parent().css("display", "none");
                            $("#biot").parent().css("display", "none");
                            $("#pit").parent().css("display", "none");
                            $("#txtCompleteBIO").parent().parent().css("display", "none");
                            $("#sample").parent().css("display", "none");

                            $("#Sep1").parent().css("display", "none");
                            $("#Sep2").parent().css("display", "none");
                            $("#Sep3").parent().css("display", "none");



                        }

                    });
                });

            }


            /*----------------------------------------RPS SYSTEM ENHANCEMENT - MANAGER BACKLOG SUBMISSION FORM-----------------------------------------*/

            if ((document.URL).includes("rps-system-enhancement-manager-backlog-submission-form")) {

                $("#currentWorkAroundVal").parent().parent().css("display", "none");
                $("#please").parent().css("display", "none");
                $("#isReqTimeSensitiveVal").parent().parent().css("display", "none");



                $('input[name=currentWorkAround]').change(function() {
                    $("input[name=currentWorkAround]").each(function() {
                        if ($("input[name=currentWorkAround]:checked").val() == "No") {
                            $("#currentWorkAroundVal").parent().parent().css("display", "none");

                        } else if ($("input[name=currentWorkAround]:checked").val() == "Yes") {
                            $("#currentWorkAroundVal").parent().parent().css("display", "block");
                        }

                    });
                });

                $('input[name=Requesttimesensitive]').change(function() {
                    $("input[name=Requesttimesensitive]").each(function() {
                        if ($("input[name=Requesttimesensitive]:checked").val() == "No") {
                            $("#please").parent().css("display", "none");
                            $("#isReqTimeSensitiveVal").parent().parent().css("display", "none");

                        } else if ($("input[name=Requesttimesensitive]:checked").val() == "Yes") {
                            $("#please").parent().css("display", "block");
                            $("#isReqTimeSensitiveVal").parent().parent().css("display", "block");
                        }

                    });
                });

            }


            /*----------------------------------------------------TESTING OR SONI CONTENT RESOURCE REQUEST------------------------------------------------------*/

            if ((document.URL).includes("testing-or-soni-content-resource-request")) {
                $("#content").prop("disabled", true);
                $("#soniarticle").prop("disabled", true);
                $("#numppl").prop("disabled", true);
                $("#blocks").prop("disabled", true);
                $("#sonihrs").prop("disabled", true);
                $("#specdates2").prop("disabled", true);
                $("#usetest").prop("disabled", true);
                $("#soniskill").prop("disabled", true);
                $("#soniother").prop("disabled", true);

                $('input[name=soni]').change(function() {
                    $("input[name=soni]:checked").each(function() {
                        if ($("input[name=soni]:checked").val() == "no") {
                            $("#content").prop("disabled", true);
                            $("#content").val('');
                            $("#soniarticle").prop("disabled", true);
                            $("#soniarticle").val('');
                            $("#numppl").prop("disabled", true);
                            $("#numppl").val('');
                            $("#blocks").prop("disabled", true);
                            $("#blocks").prop("selectedIndex", 0);
                            $("#sonihrs").prop("disabled", true);
                            $("#sonihrs").val('');
                            $("#specdates2").prop("disabled", true);
                            $("#specdates2").val('');
                            $("#usetest").prop("disabled", true);
                            $("#usetest").prop("selectedIndex", 0);
                            $("#soniskill").prop("disabled", true);
                            $("#soniskill").val('');
                            $("#soniother").prop("disabled", true);
                            $("#soniother").val('');

                        } else if ($("input[name=soni]:checked").val() == "yes") {
                            $("#content").prop("disabled", false);
                            $("#soniarticle").prop("disabled", false);
                            $("#numppl").prop("disabled", false);
                            $("#blocks").prop("disabled", false);
                            $("#sonihrs").prop("disabled", false);
                            $("#specdates2").prop("disabled", false);
                            $("#usetest").prop("disabled", false);
                            $("#soniskill").prop("disabled", false);
                            $("#soniother").prop("disabled", false);


                        }



                    });
                });
            }

            /*-----------------------------------------------------------LOAN RE-AMORTIZATION REQUEST--------------------------------------------------------*/

            if ((document.URL).includes("loan-re-amortization-request")) {

				$("#SMHIDDEN").parent().parent().css("display", "none");

                $('input[name=nochg]').change(function() {
                    $("input[name=nochg]").each(function() {
                        if ($("input[name=nochg]:checked").val() == "No Change") {
                            $("#matdate").removeAttr('type');
                            $('#matdate').attr('type', 'text')
                            $("#matdate").prop("value", "No Change");
							$("#matdate").click();
                        }
                        if ($("input[name=nochg]:checked").val() == undefined) {
                            $("#matdate").removeAttr('type');
                            $('#matdate').attr('type', 'date')
                            $("#matdate").prop("value", "");
                        }
                    });

                });




                $("#interest-rate").parent().parent().css("display", "none");


                $('input[name=samerate]').change(function() {
                    $("input[name=samerate]").each(function() {
                        if ($("input[name=samerate]:checked").val() == "No") {
                            $("#interest-rate").parent().parent().css("display", "block");

                        } else if ($("input[name=samerate]:checked").val() == "Yes") {
                            $("#interest-rate").parent().parent().css("display", "none");
                        }

                    });
                });


                $(document).on("click", "[name='submit-btn']", function() {
					var smRate;
                    if ($("input[name=samerate]:checked").val() == "No") {
                        smRate=$("#interest-rate").val();

                    }
                     else if ($("input[name=samerate]:checked").val() == "Yes") {
                        smRate="No Change";

                    }
                    $("#SMHIDDEN").val(smRate);
                });
            }


            /*------------------------------------------------------New Plan Maintenance Form------------------------------------------------------------------*/

            if ((document.URL).includes("plan-maint-form")) {
                $("#addRemoveMoneyTypeNotes").attr("title", "30 lines maximum");
                $("#enrollBooksNotes").attr("title", "30 lines maximum");

                function isBiz(dateValue) {
                    var dobj = new Date(dateValue); // date object

                    var dayindex = dobj.getDay(); // get day of week index

                    // 0 = sunday, 6 = saturday

                    if (dayindex == 0 || dayindex == 6) {
                        return false; // not biz	
                    } else {
                        return true; // yes biz
                    }
                }


                function testDistance(dateValue) {
                    var curr = new Date(); // current date
                    var mscurr = curr.getTime();

                    var seldate = new Date(dateValue); // selected date	
                    var mssel = seldate.getTime();

                    var inst; // holds date instance
                    var daycount = 0; // counts calendar days
                    var nbcount = 0; // counts weekend days
                    var dow;

                    while (mscurr <= mssel) {
                        mscurr += 86400000;
                        daycount++;

                        inst = new Date(mscurr);

                        dow = inst.getDay(); // day of week

                        if (dow == 0 || dow == 6) {
                            nbcount++; // increment non-biz day count				
                        }
                    } // end while

                    var result = daycount - nbcount;

                    return result;
                }

                $('#enrollBooksDeliveryDate').on('change', function() {
                    var prev = $(this).data('val');
                    var dist = testDistance($(this).val());
                    var bool = isBiz($(this).val());

                    if (bool) {
                        if (dist < 8) {

                            var msg = "Delivery Date must be 8 or more business days from current date.  Please choose a different Delivery Date.";
                            alert(msg);
                            $(this).val(prev);

                        }
                    } else {
                        alert("Please select a valid business day.");
                        $(this).val(prev);

                    }
                });

                $("#addMoneyType").parent().parent().css("display", "none");
                $("#removeMoneyType").parent().parent().css("display", "none");
                $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                $("#enrollmentBookReorder").parent().parent().css("display", "none");
                $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                $("#IC").parent().css("display", "none");

                $("#enrollment").parent().css("display", "none");
                $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                $("#shipto").parent().css("display", "none");
                $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                $("#enrollBooksShipCity").parent().parent().css("display", "none");
                $("#enrollBooksShipState").parent().parent().css("display", "none");
                $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                $("#enrollBooksNotes").parent().parent().css("display", "none");
                $("#delivery").parent().css("display", "none");


                $("#vestingSchedule").parent().parent().css("display", "none");
                $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                $("#addFunds").parent().parent().css("display", "none");
                $("#removeFunds").parent().parent().css("display", "none");
                $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                $("#fundChangesNotes").parent().parent().css("display", "none");

                $("#loanReqTypes").parent().parent().css("display", "none");
                $("#loansEffectiveDate").parent().parent().css("display", "none");
                $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                $("#loansPayroleFrequency").parent().parent().css("display", "none");
                $("#loansMortageYears").parent().parent().css("display", "none");
                $("#loanMinAmount").parent().parent().css("display", "none");
                $("#loanMaxAmount").parent().parent().css("display", "none");
                $("#loansAllowed").parent().parent().css("display", "none");
                $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                $("#loanNotes").parent().parent().css("display", "none");


                $("#star").parent().css("display", "none");
                $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                $("#planspon").parent().css("display", "none");
                $("#planSponcorName").parent().parent().css("display", "none");
                $("#planSponcorPhone").parent().parent().css("display", "none");
                $("#planSponcorEmail").parent().parent().css("display", "none");
                $("#addcon").parent().css("display", "none");
                $("#additionaContactName").parent().parent().css("display", "none");
                $("#additionaContactPhone").parent().parent().css("display", "none");
                $("#additionaContactEmail").parent().parent().css("display", "none");
                $("#pspon").parent().css("display", "none");
                $("#planSponsorRemoveName").parent().parent().css("display", "none");
                $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                $("#planContactNotes").parent().parent().css("display", "none");
                $("#addfix").parent().css("display", "none");


                $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                $("#riaServiceProvider").parent().parent().css("display", "none");
                $("#riaRepJointName").parent().parent().css("display", "none");
                $("#riaRepJointID").parent().parent().css("display", "none");
                $("#riaIndividualRepName1").parent().parent().css("display", "none");
                $("#riaIndividualRepId1").parent().parent().css("display", "none");
                $("#riaIndividualRepName2").parent().parent().css("display", "none");
                $("#riaIndividualRepId2").parent().parent().css("display", "none");
                $("#star2").parent().css("display", "none");
                $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                $("#riaNotes").parent().parent().css("display", "none");
                $("#ria").parent().css("display", "none");


                $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                $("#tpaFeesNotes").parent().parent().css("display", "none");
                $("#rkdfee").parent().css("display", "none");



                $("#star3").parent().css("display", "none");
                $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                $("#star4").parent().css("display", "none");
                $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                $("#closePlanNotes").parent().parent().css("display", "none");


                $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                $("#rpainfo").parent().css("display", "none");
                $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                $("#sysfee").parent().css("display", "none");


                $("#star5").parent().css("display", "none");
                $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                $("#aff").parent().css("display", "none");



                $('select[name=requestType]').change(function() {
                    $("select[name=requestType] option:selected").each(function() {
                        if ($(this).val() == "Add/Remove money type") {

                            $("#addMoneyType").parent().parent().css("display", "block");
                            $("#removeMoneyType").parent().parent().css("display", "block");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "block");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "block");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "block");
                            $("#IC").parent().css("display", "block");
                            $("#enrollmentBookReorder").parent().parent().css("display", "block");


                            $('select[name=enrollmentBookReorder]').change(function() {
                                $("select[name=enrollmentBookReorder] option:selected").each(function() {
                                    if ($(this).val() == "YES") {


                                        $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "block");
                                        $("#IC").parent().css("display", "block");
                                        $("#enrollment").parent().css("display", "block");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "block");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "block");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "block");
                                        $("#shipto").parent().css("display", "block");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "block");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "block");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "block");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "block");
                                        $("#enrollBooksShipState").parent().parent().css("display", "block");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "block");
                                        $("#enrollBooksNotes").parent().parent().css("display", "block");
                                        $("#delivery").parent().css("display", "block");

                                    } else if ($(this).val() == "NO" || $(this).val() == "No-Please send pdf of revised kit to IC through Genesys.") {

                                        $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "block");
                                        $("#IC").parent().css("display", "block");
                                        $("#enrollment").parent().css("display", "none");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                                        $("#shipto").parent().css("display", "none");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "none");
                                        $("#enrollBooksShipState").parent().parent().css("display", "none");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                                        $("#enrollBooksNotes").parent().parent().css("display", "none");
                                        $("#delivery").parent().css("display", "none");

                                    }

                                });

                            });


                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");

                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");



                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");

                        } else if ($(this).val() == "Vesting Schedule update")

                        {

                            $("#vestingSchedule").parent().parent().css("display", "block");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "block");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "block");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "block");


                            $('select[name=vestingScheduleEnrolBookReOrder]').change(function() {
                                $("select[name=vestingScheduleEnrolBookReOrder] option:selected").each(function() {
                                    if ($(this).val() == "YES") {


                                        $("#vestingScheduleUpdateNotes").parent().parent().css("display", "block");
                                        $("#enrollment").parent().css("display", "block");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "block");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "block");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "block");
                                        $("#shipto").parent().css("display", "block");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "block");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "block");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "block");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "block");
                                        $("#enrollBooksShipState").parent().parent().css("display", "block");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "block");
                                        $("#enrollBooksNotes").parent().parent().css("display", "block");
                                        $("#delivery").parent().css("display", "block");

                                    } else if ($(this).val() == "NO" || $(this).val() == "No-Please send pdf of revised kit to IC through Genesys.") {

                                        $("#vestingScheduleUpdateNotes").parent().parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "none");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                                        $("#shipto").parent().css("display", "none");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "none");
                                        $("#enrollBooksShipState").parent().parent().css("display", "none");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                                        $("#enrollBooksNotes").parent().parent().css("display", "none");
                                        $("#delivery").parent().css("display", "none");

                                    }

                                });

                            });

                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");

                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");


                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");



                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");


                        } else if ($(this).val() == "Fund changes")

                        {
                            $("#addFunds").parent().parent().css("display", "block");
                            $("#removeFunds").parent().parent().css("display", "block");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "block");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "block");
                            $("#fundChangesNotes").parent().parent().css("display", "block");


                            $('select[name=fundChangesChangeNotice]').change(function() {
                                $("select[name=fundChangesChangeNotice] option:selected").each(function() {
                                    if ($(this).val() == "YES") {

                                        $("#fundChangesNotes").parent().parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "block");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "block");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "block");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "block");
                                        $("#shipto").parent().css("display", "block");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "block");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "block");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "block");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "block");
                                        $("#enrollBooksShipState").parent().parent().css("display", "block");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "block");
                                        $("#enrollBooksNotes").parent().parent().css("display", "block");
                                        $("#delivery").parent().css("display", "block");

                                    } else if ($(this).val() == "No,please send a change notice." || $(this).val() == "No,please send pdf of revised kit to IC through Genesys.") {

                                        $("#fundChangesNotes").parent().parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "none");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                                        $("#shipto").parent().css("display", "none");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "none");
                                        $("#enrollBooksShipState").parent().parent().css("display", "none");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                                        $("#enrollBooksNotes").parent().parent().css("display", "none");
                                        $("#delivery").parent().css("display", "none");

                                    }

                                });

                            });
                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");

                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");


                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");


                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");



                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");


                        } else if ($(this).val() == "Loans")

                        {

                            $("#loanReqTypes").parent().parent().css("display", "block");
                            $("#loansEffectiveDate").parent().parent().css("display", "block");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "block");
                            $("#loansPayroleFrequency").parent().parent().css("display", "block");
                            $("#loansMortageYears").parent().parent().css("display", "block");
                            $("#loanMinAmount").parent().parent().css("display", "block");
                            $("#loanMaxAmount").parent().parent().css("display", "block");
                            $("#loansAllowed").parent().parent().css("display", "block");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "block");
                            $("#loanNotes").parent().parent().css("display", "block");

                            $('select[name=loanChangeNoticeReq]').change(function() {
                                $("select[name=loanChangeNoticeReq] option:selected").each(function() {
                                    if ($(this).val() == "YES") {

                                        $("#loanNotes").parent().parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "block");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "block");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "block");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "block");
                                        $("#shipto").parent().css("display", "block");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "block");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "block");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "block");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "block");
                                        $("#enrollBooksShipState").parent().parent().css("display", "block");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "block");
                                        $("#enrollBooksNotes").parent().parent().css("display", "block");
                                        $("#delivery").parent().css("display", "block");

                                    } else if ($(this).val() == "No,please send a change notice." || $(this).val() == "No,please send pdf of revised kit to IC through Genesys.") {

                                        $("#loanNotes").parent().parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "none");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                                        $("#shipto").parent().css("display", "none");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "none");
                                        $("#enrollBooksShipState").parent().parent().css("display", "none");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                                        $("#enrollBooksNotes").parent().parent().css("display", "none");
                                        $("#delivery").parent().css("display", "none");

                                    }

                                });

                            });


                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");

                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");

                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");



                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");

                        } else if ($(this).val() == "Plan Contacts")

                        {


                            $("#star").parent().css("display", "block");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "block");
                            $("#planspon").parent().css("display", "block");
                            $("#planSponcorName").parent().parent().css("display", "block");
                            $("#planSponcorPhone").parent().parent().css("display", "block");
                            $("#planSponcorEmail").parent().parent().css("display", "block");
                            $("#addcon").parent().css("display", "block");
                            $("#additionaContactName").parent().parent().css("display", "block");
                            $("#additionaContactPhone").parent().parent().css("display", "block");
                            $("#additionaContactEmail").parent().parent().css("display", "block");
                            $("#pspon").parent().css("display", "block");
                            $("#planSponsorRemoveName").parent().parent().css("display", "block");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "block");
                            $("#planContactNotes").parent().parent().css("display", "block");
                            $("#addfix").parent().css("display", "block");


                            $('select[name=planSponcorRemoveEnrollmentBookReorder]').change(function() {
                                $("select[name=planSponcorRemoveEnrollmentBookReorder] option:selected").each(function() {
                                    if ($(this).val() == "YES") {

                                        $("#planContactNotes").parent().parent().css("display", "block");
                                        $("#addfix").parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "block");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "block");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "block");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "block");
                                        $("#shipto").parent().css("display", "block");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "block");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "block");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "block");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "block");
                                        $("#enrollBooksShipState").parent().parent().css("display", "block");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "block");
                                        $("#enrollBooksNotes").parent().parent().css("display", "block");
                                        $("#delivery").parent().css("display", "block");

                                    } else if ($(this).val() == "NO" || $(this).val() == "No-Please send pdf of revised kit to IC through Genesys.") {

                                        $("#planContactNotes").parent().parent().css("display", "block");
                                        $("#addfix").parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "none");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                                        $("#shipto").parent().css("display", "none");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "none");
                                        $("#enrollBooksShipState").parent().parent().css("display", "none");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                                        $("#enrollBooksNotes").parent().parent().css("display", "none");
                                        $("#delivery").parent().css("display", "none");

                                    }

                                });

                            });

                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");

                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");


                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");

                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");



                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");

                        } else if ($(this).val() == "RIA- Adding Service Provider/RIA contact")

                        {

                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "block");
                            $("#riaServiceProvider").parent().parent().css("display", "block");
                            $("#riaRepJointName").parent().parent().css("display", "block");
                            $("#riaRepJointID").parent().parent().css("display", "block");
                            $("#riaIndividualRepName1").parent().parent().css("display", "block");
                            $("#riaIndividualRepId1").parent().parent().css("display", "block");
                            $("#riaIndividualRepName2").parent().parent().css("display", "block");
                            $("#riaIndividualRepId2").parent().parent().css("display", "block");
                            $("#star2").parent().css("display", "block");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "block");
                            $("#riaNotes").parent().parent().css("display", "block");
                            $("#ria").parent().css("display", "block");


                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");

                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");


                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");



                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");


                        } else if ($(this).val() == "TPA Fees")

                        {
                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "block");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "block");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "block");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "block");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "block");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "block");
                            $("#tpaFeesNotes").parent().parent().css("display", "block");
                            $("#rkdfee").parent().css("display", "block");


                            $('select[name=tpaFeesChangeNeeded]').change(function() {
                                $("select[name=tpaFeesChangeNeeded] option:selected").each(function() {
                                    if ($(this).val() == "YES") {

                                        $("#tpaFeesNotes").parent().parent().css("display", "block");
                                        $("#rkdfee").parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "block");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "block");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "block");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "block");
                                        $("#shipto").parent().css("display", "block");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "block");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "block");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "block");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "block");
                                        $("#enrollBooksShipState").parent().parent().css("display", "block");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "block");
                                        $("#enrollBooksNotes").parent().parent().css("display", "block");
                                        $("#delivery").parent().css("display", "block");

                                    } else if ($(this).val() == "No,please send a change notice." || $(this).val() == "No,please send pdf of revised kit to IC through Genesys.") {

                                        $("#tpaFeesNotes").parent().parent().css("display", "block");
                                        $("#rkdfee").parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "none");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                                        $("#shipto").parent().css("display", "none");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "none");
                                        $("#enrollBooksShipState").parent().parent().css("display", "none");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                                        $("#enrollBooksNotes").parent().parent().css("display", "none");
                                        $("#delivery").parent().css("display", "none");

                                    }

                                });

                            });

                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");


                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");


                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");

                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");


                        } else if ($(this).val() == "Close Plan")

                        {

                            $("#star3").parent().css("display", "block");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "block");
                            $("#star4").parent().css("display", "block");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "block");
                            $("#closePlanNotes").parent().parent().css("display", "block");


                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");

                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");


                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");


                        } else if ($(this).val() == "Fiduciary Services")

                        {

                            $("#fiduciaryServiceLevel").parent().parent().css("display", "block");
                            $("#rpainfo").parent().css("display", "block");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "block");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "block");
                            $("#sysfee").parent().css("display", "block");



                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");

                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");


                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");

                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");

                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");


                        } else if ($(this).val() == "Plan Setup Errors")

                        {
                            $("#star5").parent().css("display", "block");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "block");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "block");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "block");



                            $('select[name=planSetupErrorsEnrollmentBooksReorder]').change(function() {
                                $("select[name=planSetupErrorsEnrollmentBooksReorder] option:selected").each(function() {
                                    if ($(this).val() == "YES") {



                                        $("#enrollment").parent().css("display", "block");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "block");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "block");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "block");
                                        $("#shipto").parent().css("display", "block");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "block");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "block");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "block");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "block");
                                        $("#enrollBooksShipState").parent().parent().css("display", "block");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "block");
                                        $("#enrollBooksNotes").parent().parent().css("display", "block");
                                        $("#delivery").parent().css("display", "block");

                                    } else if ($(this).val() == "NO" || $(this).val() == "No-Please send pdf of revised kit to IC through Genesys.") {



                                        $("#enrollment").parent().css("display", "none");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                                        $("#shipto").parent().css("display", "none");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "none");
                                        $("#enrollBooksShipState").parent().parent().css("display", "none");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                                        $("#enrollBooksNotes").parent().parent().css("display", "none");
                                        $("#delivery").parent().css("display", "none");

                                    }

                                });

                            });


                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");


                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");


                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");



                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");

                        } else if ($(this).val() == "Fee Level Recovery")

                        {

                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "block");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "block");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "block");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "block");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "block");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "block");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "block");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "block");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "block");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "block");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "block");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "block");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "block");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "block");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "block");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "block");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "block");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "block");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "block");


                            $('select[name=feelevelrecoveryenrol]').change(function() {
                                $("select[name=feelevelrecoveryenrol] option:selected").each(function() {
                                    if ($(this).val() == "YES") {

                                        $("#feeLevelRecoveryNotes").parent().parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "block");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "block");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "block");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "block");
                                        $("#shipto").parent().css("display", "block");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "block");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "block");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "block");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "block");
                                        $("#enrollBooksShipState").parent().parent().css("display", "block");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "block");
                                        $("#enrollBooksNotes").parent().parent().css("display", "block");
                                        $("#delivery").parent().css("display", "block");

                                    } else if ($(this).val() == "No, please send a change notice." || $(this).val() == "No,please send pdf of revised kit to IC through Genesys.") {

                                        $("#feeLevelRecoveryNotes").parent().parent().css("display", "block");

                                        $("#enrollment").parent().css("display", "none");
                                        $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                                        $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                                        $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                                        $("#shipto").parent().css("display", "none");
                                        $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                                        $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                                        $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                                        $("#enrollBooksShipCity").parent().parent().css("display", "none");
                                        $("#enrollBooksShipState").parent().parent().css("display", "none");
                                        $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                                        $("#enrollBooksNotes").parent().parent().css("display", "none");
                                        $("#delivery").parent().css("display", "none");

                                    }

                                });

                            });

                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");

                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");


                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");



                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $("#addRemoveAfflAddContact").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "none");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "none");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "none");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "none");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "none");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "none");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "none");
                            $("#aff").parent().css("display", "none");

                        } else if ($(this).val() == "Add/Remove Affiliate/Location")

                        {
                            $("#addRemoveAfflAddContact").parent().parent().css("display", "block");
                            $("#addRemoveAfflCompanyName1").parent().parent().css("display", "block");
                            $("#addRemoveAfflCompanyName2").parent().parent().css("display", "block");
                            $("#addRemoveAfflAttn1").parent().parent().css("display", "block");
                            $("#addRemoveAfflAttn2").parent().parent().css("display", "block");
                            $("#addRemoveAfflPhone1").parent().parent().css("display", "block");
                            $("#addRemoveAfflPhone2").parent().parent().css("display", "block");
                            $("#addRemoveAfflAddress1").parent().parent().css("display", "block");
                            $("#addRemoveAfflAddress2").parent().parent().css("display", "block");
                            $("#addRemoveAfflTaxId1").parent().parent().css("display", "block");
                            $("#addRemoveAfflTaxId2").parent().parent().css("display", "block");
                            $("#addRemoveAfflLocationToRemove").parent().parent().css("display", "block");
                            $("#addRemoveAfflNotes").parent().parent().css("display", "block");
                            $("#aff").parent().css("display", "block");




                            $("#addMoneyType").parent().parent().css("display", "none");
                            $("#removeMoneyType").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display", "none");
                            $("#enrollmentBookReorder").parent().parent().css("display", "none");
                            $("#addRemoveMoneyTypeNotes").parent().parent().css("display", "none");
                            $("#IC").parent().css("display", "none");

                            $("#enrollment").parent().css("display", "none");
                            $("#enrollBooksDeliveryDate").parent().parent().css("display", "none");
                            $("#enrollBooksEngBooksNeeded").parent().parent().css("display", "none");
                            $("#enrollBooksSpanBooksNeeded").parent().parent().css("display", "none");
                            $("#shipto").parent().css("display", "none");
                            $("#enrollBooksShipCompanyName").parent().parent().css("display", "none");
                            $("#enrollBooksShipAttn").parent().parent().css("display", "none");
                            $("#enrollBooksShipStreet").parent().parent().css("display", "none");
                            $("#enrollBooksShipCity").parent().parent().css("display", "none");
                            $("#enrollBooksShipState").parent().parent().css("display", "none");
                            $("#enrollBooksShipZipCode").parent().parent().css("display", "none");
                            $("#enrollBooksNotes").parent().parent().css("display", "none");
                            $("#delivery").parent().css("display", "none");


                            $("#vestingSchedule").parent().parent().css("display", "none");
                            $("#effectiveDateForVestingSchedule").parent().parent().css("display", "none");
                            $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display", "none");
                            $("#vestingScheduleUpdateNotes").parent().parent().css("display", "none");

                            $("#addFunds").parent().parent().css("display", "none");
                            $("#removeFunds").parent().parent().css("display", "none");
                            $("#fundChangesEffectiveDate").parent().parent().css("display", "none");
                            $("#fundChangesChangeNotice").parent().parent().css("display", "none");
                            $("#fundChangesNotes").parent().parent().css("display", "none");

                            $("#loanReqTypes").parent().parent().css("display", "none");
                            $("#loansEffectiveDate").parent().parent().css("display", "none");
                            $("#loansGenPurposeYrs").parent().parent().css("display", "none");
                            $("#loansPayroleFrequency").parent().parent().css("display", "none");
                            $("#loansMortageYears").parent().parent().css("display", "none");
                            $("#loanMinAmount").parent().parent().css("display", "none");
                            $("#loanMaxAmount").parent().parent().css("display", "none");
                            $("#loansAllowed").parent().parent().css("display", "none");
                            $("#loanChangeNoticeReq").parent().parent().css("display", "none");
                            $("#loanNotes").parent().parent().css("display", "none");


                            $("#star").parent().css("display", "none");
                            $('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display", "none");
                            $("#planspon").parent().css("display", "none");
                            $("#planSponcorName").parent().parent().css("display", "none");
                            $("#planSponcorPhone").parent().parent().css("display", "none");
                            $("#planSponcorEmail").parent().parent().css("display", "none");
                            $("#addcon").parent().css("display", "none");
                            $("#additionaContactName").parent().parent().css("display", "none");
                            $("#additionaContactPhone").parent().parent().css("display", "none");
                            $("#additionaContactEmail").parent().parent().css("display", "none");
                            $("#pspon").parent().css("display", "none");
                            $("#planSponsorRemoveName").parent().parent().css("display", "none");
                            $("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display", "none");
                            $("#planContactNotes").parent().parent().css("display", "none");
                            $("#addfix").parent().css("display", "none");


                            $("#salesConnectFormDateSubmitted").parent().parent().css("display", "none");
                            $("#riaServiceProvider").parent().parent().css("display", "none");
                            $("#riaRepJointName").parent().parent().css("display", "none");
                            $("#riaRepJointID").parent().parent().css("display", "none");
                            $("#riaIndividualRepName1").parent().parent().css("display", "none");
                            $("#riaIndividualRepId1").parent().parent().css("display", "none");
                            $("#riaIndividualRepName2").parent().parent().css("display", "none");
                            $("#riaIndividualRepId2").parent().parent().css("display", "none");
                            $("#star2").parent().css("display", "none");
                            $('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display", "none");
                            $("#riaNotes").parent().parent().css("display", "none");
                            $("#ria").parent().css("display", "none");


                            $("#tpaFeesEffectiveDate").parent().parent().css("display", "none");
                            $("#tpaFeesLoanFee").parent().parent().css("display", "none");
                            $("#tpaFeesDistributionFee").parent().parent().css("display", "none");
                            $("#tpaFeesChangeNeeded").parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display", "none");
                            $('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display", "none");
                            $("#tpaFeesNotes").parent().parent().css("display", "none");
                            $("#rkdfee").parent().css("display", "none");



                            $("#star3").parent().css("display", "none");
                            $('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display", "none");
                            $("#star4").parent().css("display", "none");
                            $('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display", "none");
                            $("#closePlanNotes").parent().parent().css("display", "none");


                            $("#fiduciaryServiceLevel").parent().parent().css("display", "none");
                            $("#rpainfo").parent().css("display", "none");
                            $('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display", "none");
                            $("#fiduciaryServiceNotes").parent().parent().css("display", "none");
                            $("#sysfee").parent().css("display", "none");


                            $("#star5").parent().css("display", "none");
                            $('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display", "none");
                            $("#planSetupErrorsCorrectiveAction").parent().parent().css("display", "none");
                            $("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display", "none");


                            $('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryDollarAmt").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryBasisPoint").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAProRata").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display", "none");
                            $('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display", "none");
                            $("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display", "none");
                            $("#feelevelrecoveryenrol").parent().parent().css("display", "none");
                            $("#feeLevelRecoveryNotes").parent().parent().css("display", "none");

                        }

                    });

                });
            }

            /*--------------------------------------------IMAGED SOURCES / IMAGING PROFILE CHANGE REQUEST-------------------------------------------------------*/


            if ((document.URL).includes("imaged-sources-imaging-profile-change-request")) {

                $("#MULTIPLE").parent().parent().css("display", "none");
                $("#timeBody").parent().parent().css("display", "none");
                $("#MULSOURCES").parent().parent().css("display", "none");
                $("#ASSO_INITIALS").parent().parent().css("display", "none");
                $("#MULSOURCESUP").parent().parent().css("display", "none");


                $('select[name=REQUESTTYPE]').change(function() {
                    $("select[name=REQUESTTYPE] option:selected").each(function() {
                        if ($(this).val() == "Live Sources for Training" || $(this).val() == "Reinforcement Sources") {

                            $("#MULSOURCES").parent().parent().css("display", "block");
                            $("#ASSO_INITIALS").parent().parent().css("display", "block");
                            $("#MULSOURCESUP").parent().parent().css("display", "none");
                        } else if ($(this).val() == "Temporary Profile Change" || $(this).val() == "Permanent Profile Change") {

                            $("#MULSOURCES").parent().parent().css("display", "none");
                            $("#ASSO_INITIALS").parent().parent().css("display", "block");
                            $("#MULSOURCESUP").parent().parent().css("display", "block");
                        }
                    });
                });

                $(document).on("click", "[name='submit-btn']", function() {
                    var subjectLine;
                    var rtype;
                    var timeBodyTemp = $("#HOURS").val() + " " + $("#AMPM").val();
                    $("#timeBody").val(timeBodyTemp);
                    var mult = $("#MULSOURCES").val();
                    var mult1 = $("#MULSOURCESUP").val();

                    if ($("#MULSOURCES").val() == 'MULSOURCES_YES') {
                        $("#MULTIPLE").val("Do sources need to be placed in multiple folders?: Yes");
                    }
                    if ($("#MULSOURCES").val() == 'MULSOURCES_NO') {
                        $("#MULTIPLE").val("Do sources need to be placed in multiple folders?: No");
                    }
                    if ($("#MULSOURCESUP").val() == 'MULSOURCESUP_YES') {
                        $("#MULTIPLE").val("Do multiple associates need to be updated? Yes");
                    }
                    if ($("#MULSOURCESUP").val() == 'MULSOURCESUP_NO') {
                        $("#MULTIPLE").val("Do multiple associates need to be updated? No");
                    }

                    var requestType = $("#REQUESTTYPE").val();
                    if (requestType == "Live Sources for Training") {
                        rtype = "live work by";
                    }
                    if (requestType == "Reinforcement Sources") {
                        rtype = "reinforcement work by";
                    }
                    if (requestType == "Temporary Profile Change") {
                        rtype = "temporary prof change by";
                    }
                    if (requestType == "Permanent Profile Change") {
                        rtype = "permanent prof change by";
                    }

                    var dateVal = $("#DATE-SOURCE").val().trim();
                    var dateConversionArray = dateVal.split("-");
                    var issueDateFin = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];

                    subjectLine = issueDateFin + " " + rtype + " " + $("#timeBody").val() + " " + $("#SITE").val();

                    if ($("#MULSOURCES").val() == 'MULSOURCES_NO' || $("#MULSOURCESUP").val() == 'MULSOURCESUP_NO') {
                        subjectLine = subjectLine + " " + $("#ASSO_INITIALS").val();
                    } else {
                        subjectLine = subjectLine + " VARIOUS";
                    }

                    $("#mailSubject").val(subjectLine);

                });


            }

 /*------------------------------------------------------------RPS Research/Transaction Request ----------------------------------------------------------------------------------*/

            if ((document.URL).includes("rps-research-transaction-request")) {

                $("#yearHidden").parent().parent().css("display", "none");
                $("#workHidden").parent().parent().css("display", "none");
                $("#initialHidden").parent().parent().css("display", "none");
                $("#marketCloseHidden").parent().parent().css("display", "none");

                $('input[name=plantypeRadio1]').parent().parent().css("display", "none");
                $('input[name=hidhelpdesk]').parent().parent().parent().css("display", "none");
                $('input[name=rush]').parent().parent().parent().css("display", "none");
                $('input[name=planYear]').parent().parent().parent().css("display", "none");
                $('input[name=CBandT_Trustee]').parent().parent().parent().css("display", "none");
                $('input[name=documentRequested]').parent().parent().parent().css("display", "none");

                $('select[name=worktype2]').parent().parent().css("display", "none");
                $('select[name=worktype]').parent().parent().css("display", "none");



                $("#helpDeskInitials").parent().parent().css("display", "none");
                $("#reportpwd").parent().parent().css("display", "none");
                $("#addtionalComment").parent().parent().css("display", "none");
                $("#dollaramount").parent().parent().css("display", "none");
                $("#payrolldate").parent().parent().css("display", "none");
                $("#batchnumber").parent().parent().css("display", "none");

                $("#payrollcomments").parent().parent().css("display", "none");
                $("#planenddate").parent().parent().css("display", "none");

                $("#important").parent().css("display", "none");
                $("#help-desk").parent().css("display", "none");

                $("#report-password").parent().css("display", "none");
                $("#plan-year").parent().css("display", "none");
                $("#cbandt-trustee").parent().css("display", "none");
                $("#documents").parent().css("display", "none");

                $("#comment-text").parent().css("display", "none");
                $("#nigo").parent().css("display", "none");

                $('input[name=hidptype]').change(function() {
                    $("input[name=hidptype]").each(function() {
                        if ($("input[name=hidptype]:checked").val() == "AFO") {
                            $('input[name=plantypeRadio1]').parent().parent().css("display", "block");

                        } else if ($("input[name=hidptype]:checked").val() == "Multifund") {
                            $('input[name=plantypeRadio1]').parent().parent().css("display", "block");

                        } else if ($("input[name=hidptype]:checked").val() == "pptpa") {
                            $('input[name=plantypeRadio1]').parent().parent().css("display", "none");

                        }
                    });
                });


                $('input[name=hiddenresolution]').change(function() {
                    $("input[name=hiddenresolution]").each(function() {
                        if ($("input[name=hiddenresolution]:checked").val() == "Research") {
                            $('#hidhelpdesk').removeAttr('checked');
                            $('#worktype2').prop("selectedIndex", 0);
                            $("#passwd").parent().parent().css("display", "block");
                            $("#situation").parent().parent().css("display", "block");
                            $("#actreq").parent().parent().css("display", "block");

                            $('input[name=plantypeRadio1]').parent().parent().css("display", "none");
                            $('input[name=hidhelpdesk]').parent().parent().parent().css("display", "block");
                            $('input[name=rush]').parent().parent().parent().css("display", "block");
                            $('input[name=planYear]').parent().parent().parent().css("display", "none");
                            $('input[name=CBandT_Trustee]').parent().parent().parent().css("display", "none");
                            $('input[name=documentRequested]').parent().parent().parent().css("display", "none");

                            $('select[name=worktype2]').parent().parent().css("display", "block");
                            $('select[name=worktype]').parent().parent().css("display", "none");



                            $("#helpDeskInitials").parent().parent().css("display", "none");
                            $("#reportpwd").parent().parent().css("display", "none");
                            $("#addtionalComment").parent().parent().css("display", "none");
                            $("#dollaramount").parent().parent().css("display", "none");
                            $("#payrolldate").parent().parent().css("display", "none");
                            $("#batchnumber").parent().parent().css("display", "none");

                            $("#payrollcomments").parent().parent().css("display", "none");
                            $("#planenddate").parent().parent().css("display", "none");

                            $("#important").parent().css("display", "block");
                            $("#help-desk").parent().css("display", "block");

                            $("#report-password").parent().css("display", "none");
                            $("#plan-year").parent().css("display", "none");
                            $("#cbandt-trustee").parent().css("display", "none");
                            $("#documents").parent().css("display", "none");

                            $("#comment-text").parent().css("display", "none");
                            $("#nigo").parent().css("display", "none");

                            $('input[name=hidhelpdesk]').change(function() {
                                $("input[name=hidhelpdesk]").each(function() {


                                    if ($("input[name=hidhelpdesk]:checked").val() == "Yes") {
                                        $("#helpDeskInitials").parent().parent().css("display", "block");

                                    } else {
                                        $("#helpDeskInitials").parent().parent().css("display", "none");

                                    }
                                });
                            });
                            $('select[name=worktype2]').change(function() {
                                $("select[name=worktype2] option:selected").each(function() {


                                    if ($(this).val() == "Audit Report") {
                                        $('input[name=rush]').parent().parent().parent().css("display", "block");
                                        $('input[name=planYear]').parent().parent().parent().css("display", "block");
                                        $('input[name=CBandT_Trustee]').parent().parent().parent().css("display", "block");
                                        $('input[name=documentRequested]').parent().parent().parent().css("display", "block");
                                        $("#reportpwd").parent().parent().css("display", "block");
                                        $("#addtionalComment").parent().parent().css("display", "block");
                                        $("#planenddate").parent().parent().css("display", "block");
                                        $("#report-password").parent().css("display", "block");
                                        $("#plan-year").parent().css("display", "block");
                                        $("#cbandt-trustee").parent().css("display", "block");
                                        $("#documents").parent().css("display", "block");

                                        $("#comment-text").parent().css("display", "block");
                                        $("#passwd").parent().parent().css("display", "none");
                                        $("#situation-3").parent().parent().css("display", "none");
                                        $("#actreq").parent().parent().css("display", "none");
                                        $("#file").parent().parent().parent().css("display", "none");
                                        $("#attachments").parent().css("display", "none");
                                    } else {
                                        $("#file").parent().parent().parent().css("display", "block");
                                        $("#attachments").parent().css("display", "block");
                                        $('input[name=rush]').parent().parent().parent().css("display", "none")
                                        $('input[name=planYear]').parent().parent().parent().css("display", "none")
                                        $('input[name=CBandT_Trustee]').parent().parent().parent().css("display", "none")
                                        $('input[name=documentRequested]').parent().parent().parent().css("display", "none");
                                        $("#reportpwd").parent().parent().css("display", "none");
                                        $("#addtionalComment").parent().parent().css("display", "none");
                                        $("#planenddate").parent().parent().css("display", "none");
                                        $("#report-password").parent().css("display", "none");
                                        $("#plan-year").parent().css("display", "none");
                                        $("#cbandt-trustee").parent().css("display", "none");
                                        $("#documents").parent().css("display", "none");

                                        $("#comment-text").parent().css("display", "none");
                                        $("#passwd").parent().parent().css("display", "block");
                                        $("#situation-3").parent().parent().css("display", "block");
                                        $("#actreq").parent().parent().css("display", "block");


                                    }
                                });
                            });


                        } else if ($("input[name=hiddenresolution]:checked").val() == "Transaction") {
                            $('#worktype').prop("selectedIndex", 0);
                            $("#attachments").parent().css("display", "block");
                            $("#file").parent().parent().parent().css("display", "block");
                            $("#passwd").parent().parent().css("display", "block");
                            $("#situation-3").parent().parent().css("display", "block");                            
                            $("#actreq").parent().parent().css("display", "block");
                            $('input[name=plantypeRadio1]').parent().parent().css("display", "none");
                            $('input[name=hidhelpdesk]').parent().parent().parent().css("display", "none");
                            $('input[name=rush]').parent().parent().parent().css("display", "none");
                            $('input[name=planYear]').parent().parent().parent().css("display", "none");
                            $('input[name=CBandT_Trustee]').parent().parent().parent().css("display", "none");
                            $('input[name=documentRequested]').parent().parent().parent().css("display", "none");

                            $('select[name=worktype2]').parent().parent().css("display", "none");
                            $('select[name=worktype]').parent().parent().css("display", "block");



                            $("#helpDeskInitials").parent().parent().css("display", "none");
                            $("#reportpwd").parent().parent().css("display", "none");
                            $("#addtionalComment").parent().parent().css("display", "none");
                            $("#dollaramount").parent().parent().css("display", "none");
                            $("#payrolldate").parent().parent().css("display", "none");
                            $("#batchnumber").parent().parent().css("display", "none");

                            $("#payrollcomments").parent().parent().css("display", "none");
                            $("#planenddate").parent().parent().css("display", "none");

                            $("#important").parent().css("display", "none");
                            $("#help-desk").parent().css("display", "none");

                            $("#report-password").parent().css("display", "none");
                            $("#plan-year").parent().css("display", "none");
                            $("#cbandt-trustee").parent().css("display", "none");
                            $("#documents").parent().css("display", "none");

                            $("#comment-text").parent().css("display", "none");
                            $("#nigo").parent().css("display", "none");



                        }
                        else if ($("input[name=hiddenresolution]:checked").val() == "NIGO") {
                            $('#worktype').prop("selectedIndex", 0);
                            $("#attachments").parent().css("display", "block");
                            $("#file").parent().parent().parent().css("display", "block");
                            $("#passwd").parent().parent().css("display", "none");
                            $("#situation-3").parent().parent().css("display", "block");
                            $("#actreq").parent().parent().css("display", "block");
                            $('input[name=plantypeRadio1]').parent().parent().css("display", "none");
                            $('input[name=hidhelpdesk]').parent().parent().parent().css("display", "none");
                            $('input[name=rush]').parent().parent().parent().css("display", "none");
                            $('input[name=planYear]').parent().parent().parent().css("display", "none");
                            $('input[name=CBandT_Trustee]').parent().parent().parent().css("display", "none");
                            $('input[name=documentRequested]').parent().parent().parent().css("display", "none");

                            $('select[name=worktype2]').parent().parent().css("display", "none");
                            $('select[name=worktype]').parent().parent().css("display", "none");



                            $("#helpDeskInitials").parent().parent().css("display", "none");
                            $("#reportpwd").parent().parent().css("display", "none");
                            $("#addtionalComment").parent().parent().css("display", "none");
                            $("#dollaramount").parent().parent().css("display", "none");
                            $("#payrolldate").parent().parent().css("display", "none");
                            $("#batchnumber").parent().parent().css("display", "none");

                            $("#payrollcomments").parent().parent().css("display", "none");
                            $("#planenddate").parent().parent().css("display", "none");

                            $("#important").parent().css("display", "none");
                            $("#help-desk").parent().css("display", "none");

                            $("#report-password").parent().css("display", "none");
                            $("#plan-year").parent().css("display", "none");
                            $("#cbandt-trustee").parent().css("display", "none");
                            $("#documents").parent().css("display", "none");

                            $("#comment-text").parent().css("display", "none");
                            $("#nigo").parent().css("display", "block");



                        }

                    });
                });
                $('select[name=worktype]').on('input', function() {
                    $("select[name=worktype] option:selected").each(function() {


                        if ($(this).val() == "Earnings Payroll") {
                            $("#dollaramount").parent().parent().css("display", "block");
                            $("#payrolldate").parent().parent().css("display", "block");
                            $("#batchnumber").parent().parent().css("display", "block");

                            $("#payrollcomments").parent().parent().css("display", "block");
							$("#payrollcomments").val('Code the payroll as Earnings and fund via ACH');
                            $("#situation-3").parent().parent().css("display", "none");
                            $("#actreq").parent().parent().css("display", "none");
                        } else if ($(this).val() == "NIGO") {


                            $("#dollaramount").parent().parent().css("display", "none");
                            $("#payrolldate").parent().parent().css("display", "none");
                            $("#batchnumber").parent().parent().css("display", "none");

                            $("#payrollcomments").parent().parent().css("display", "none");
                            $("#payrollcomments").val('');
                            $("#situation-3").parent().parent().css("display", "block");
                            $("#actreq").parent().parent().css("display", "block");
                            $("#nigo").parent().css("display", "block");

                        } else if ($(this).val() == "Web Walk-Through") {
                            alert("For RUSH Web Walk-Through requests, please contact Client Services and do not complete this form.");
                            $("#dollaramount").parent().parent().css("display", "none");
                            $("#payrolldate").parent().parent().css("display", "none");
                            $("#batchnumber").parent().parent().css("display", "none");

                            $("#payrollcomments").parent().parent().css("display", "none");
                            $("#payrollcomments").val('');
                            $("#situation-3").parent().parent().css("display", "block");
                            $("#actreq").parent().parent().css("display", "block");
                            $("#nigo").parent().css("display", "none");
                        } else {
                            $("#dollaramount").parent().parent().css("display", "none");
                            $("#payrolldate").parent().parent().css("display", "none");
                            $("#batchnumber").parent().parent().css("display", "none");

                            $("#payrollcomments").parent().parent().css("display", "none");
                            $("#payrollcomments").val('');
                            $("#situation-3").parent().parent().css("display", "block");
                            $("#actreq").parent().parent().css("display", "block");
                            $("#nigo").parent().css("display", "none");

                        }

                    });
                });

                 $(document).on("click", "[name='submit-btn']", function() {

                     		if($("[name='hidhelpdesk']")[0].checked){

                                var initialName="<br/><br/>INITIALS OF HELP DESK MEMBER: "+$("#helpDeskInitials").val();
                     			$("#initialHidden").val(initialName);                     		
                            }


							var yearValue="";
							$("#yearHidden").val('');
                            if($("[name='planYear']")[0].checked  && !$("[name='planYear']")[1].checked)
                            {
								yearValue='Calender';

                            }
                            if($("[name='planYear']")[1].checked && $("[name='planYear']")[0].checked)
                            {
                                yearValue='Calender,Fiscal';

                            }
                            if($("[name='planYear']")[1].checked && !$("[name='planYear']")[0].checked)
                            {
                                yearValue='Fiscal';

                            }
                            $("#yearHidden").val(yearValue);


							var marketClose=""
							$("#workHidden").val('');
                            if($("[name='hiddenresolution']")[0].checked){

                                var workValue=$("[name='hiddenresolution']")[0].value;
								$("#workHidden").val(workValue);
                                marketClose="";
                            }

                            if($("[name='hiddenresolution']")[1].checked ){

                                var workValue=$("#worktype").val();
								$("#workHidden").val(workValue);
                                 marketClose="";
                            }
                            if($("[name='hiddenresolution']")[2].checked ){
								marketClose="<br/><br/>RESOLUTION RECEIVED PRIOR TO MARKET CLOSE?: undefined";
                            }
                     		$("#marketCloseHidden").val(marketClose);

                 });



            }



            /*------------------------------------------------------------Share Requirements ----------------------------------------------------------------------------------*/



            function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

                var today = new Date();
                var month = today.getMonth() + 1;
                if (month < 10) {
                    month = "0" + month;
                }
                var day = today.getDate();
                if (day < 10) {
                    day = "0" + day;
                }
                var year = today.getFullYear() - 2000;
                var dateString = month + "/" + day + "/" + year;
                return dateString;
            }

            $("#dateSubmitted").prop("value", currDate());
            $("#dateSubmitted").prop('disabled', true);
            $("#dateSubmitted").css('border', 'none');


            /*------------------------------------------------------------TRAC/OGI request----------------------------------------------------------------------------------*/

            if ((document.URL).includes("trac-ogi-web-resolution-checklist")) {

                $("#OTHEROPEROSHIDDEN").parent().parent().css("display", "none");
                $("#OTHERBROWSERHIDE").parent().parent().css("display", "none");
                $('select[name=OPERATINGSYSTEM]').change(function() {
                    $("select[name=OPERATINGSYSTEM] option:selected").each(function() {


                        if ($(this).val() == "Other") {
                            $("#OTHEROPEROSHIDDEN").parent().parent().css("display", "block");
                        } else {
                            $("#OTHEROPEROSHIDDEN").parent().parent().css("display", "none");
                        }
                    });
                });

                $('select[name=BROWSER]').change(function() {
                    $("select[name=BROWSER] option:selected").each(function() {


                        if ($(this).val() == "Other") {
                            $("#OTHERBROWSERHIDE").parent().parent().css("display", "block");
                        } else {
                            $("#OTHERBROWSERHIDE").parent().parent().css("display", "none");
                        }
                    });
                });

            }

            /*----------------------------------------------------OGI ID REQUEST-----------------------------------------------------------------*/

            if ((document.URL).includes("ogi-id-request")) {

                $("#CALLERHIDDEN").parent().parent().css("display", "none");
                $("#RELATIONSHIPHIDDENBODY").parent().parent().css("display", "none");
                $("#ADDITIONALCOMMENTSHIDDENBODY").parent().parent().css("display", "none");
                $("#CONTACTNAMESECTIONHIDDEN").parent().parent().css("display", "none");
                $("#CONTACTNAME").parent().parent().css("display", "none");
                $("#PREVIOUSNAME").parent().parent().css("display", "none");
                $("#NEWNAME").parent().parent().css("display", "none");

                $('select[name=REQUESTTYPE]').change(function() {
                    $("select[name=REQUESTTYPE] option:selected").each(function() {
                        if ($(this).val() == "DELETE OGI ID") {

                            $("#CONTACTNAME").parent().parent().css("display", "block");


                            $("#PREVIOUSNAME").parent().parent().css("display", "none");
                            $("#NEWNAME").parent().parent().css("display", "none");


                        } else if ($(this).val() == "CONTACT NAME CHANGE") {

                            $("#PREVIOUSNAME").parent().parent().css("display", "block");
                            $("#NEWNAME").parent().parent().css("display", "block");


                            $("#CONTACTNAME").parent().parent().css("display", "none");




                        }

                    });
                });
                $(document).on("click", "[name='submit-btn']", function() {
                    if ($("#CALLER").val().length > 0) {
                        var callerbody = "<br/>CALLER: " + $("#CALLER").val();
                        $("#CALLERHIDDEN").val(callerbody);
                    }
                    if ($("#RELATIONSHIPHIDDEN").val().length > 0) {
                        var relationbody = "RELATIONSHIP: " + $("#RELATIONSHIPHIDDEN").val() + "<br/>";
                        $("#RELATIONSHIPHIDDENBODY").val(relationbody);
                    }
                    if ($("#ADDITIONALCOMMENTSHIDDEN").val().length > 0) {
                        var additionalbody = "ADDITIONAL COMMENTS: " + $("#ADDITIONALCOMMENTSHIDDEN").val();
                        $("#ADDITIONALCOMMENTSHIDDENBODY").val(additionalbody);
                    }
                    if ($("#REQUESTTYPE").val() == "CONTACT NAME CHANGE") {
                        var namebody = "";
                        if ($("#PREVIOUSNAME").val().length > 0) {
                            namebody = "CONTACT'S PREVIOUS NAME: " + $("#PREVIOUSNAME").val() + "<br/>";
                            $("#CONTACTNAMESECTIONHIDDEN").val(namebody);
                        }

                        if ($("#NEWNAME").val().length > 0) {
                            namebody += "CONTACT'S NEW NAME: " + $("#NEWNAME").val() + "<br/>";
                            $("#CONTACTNAMESECTIONHIDDEN").val(namebody);
                        }

                    }
                    if ($("#REQUESTTYPE").val() == "DELETE OGI ID") {
                        if ($("#CONTACTNAME").val().length > 0) {
                            namebody = "CONTACT'S NAME: " + $("#CONTACTNAME").val() + "<br/>";
                            $("#CONTACTNAMESECTIONHIDDEN").val(namebody);
                        }
                    }

                });
            }

            /*----------------------------------------------------------------TRAC2000 BATCH TICKET--------------------------------------------------------*/

            if ((document.URL).includes("trac2000-batch-ticket")) {
				
				

                $("#PLIST").parent().parent().css("display", "none");
                $("#NONDATEBODY").parent().parent().css("display", "none");
                $("#REASONBODY").parent().parent().css("display", "none");
                $("#TMSMBODY").parent().parent().css("display", "none");
                $("#ADDBODY").parent().parent().css("display", "none");
                $("#BATCHHIDDEN").parent().parent().css("display", "none");

                $('[name^="planid_trac"]').attr("maxlength", "10");
                $('[name^="check_trac2"]').attr("maxlength", "15");
				$('#nonCurrentDate').change(function() {
				if($(this).val() != "")
				{
				$("#reason_code").attr('required',true)
				}
				else
				{
				$("#reason_code").attr('required',false)
				}
				});
                $('select[name=site2]').change(function() {
                    $("select[name=site2] option:selected").each(function() {
                        if ($(this).val() == "IRV") {
                            alert('You selected IRV. Is that correct?');

                        } else if ($(this).val() == "SNO") {
                            alert('You selected SNO. Is that correct?');

                        } else if ($(this).val() == "IND") {
                            alert('You selected IND. Is that correct?');

                        } else if ($(this).val() == "HRO") {
                            alert('You selected HRO. Is that correct?');

                        }
                    });

                });


                $('select[name=SOURCETYPE]').change(function() {
                    $("select[name=SOURCETYPE] option:selected").each(function() {
                        if ($(this).val() == "Email") {
                            alert('You selected E-mail. Is that correct?');

                        } else if ($(this).val() == "Imaged") {
                            alert('You selected Imaged. Is that correct?');

                        } else if ($(this).val() == "Paper") {
                            alert('You selected Paper. Is that correct?');

                        }

                    });

                });


                $('select[name=site]').change(function() {
                    $("select[name=site] option:selected").each(function() {
                        if ($(this).val() == "IRV") {
                            alert('You selected IRV. Is that correct?');

                        } else if ($(this).val() == "SNO") {
                            alert('You selected SNO. Is that correct?');

                        } else if ($(this).val() == "IND") {
                            alert('You selected IND. Is that correct?');

                        } else if ($(this).val() == "HRO") {
                            alert('You selected HRO. Is that correct?');

                        }
                    });

                });

                $("#follow").parent().css("display", "none");

                $("#accountTable").parent().parent().parent().css("display", "none");

                $("#file").parent().parent().css("display", "none");



                $("#accountTable").css("width", "60%");

                $('input[name=PAYMENT_TYPES]').change(function() {

                    $("input[name=PAYMENT_TYPES]:checked").each(function() {
                        if ($("input[name=PAYMENT_TYPES]:checked").val() == "ACH") {

                            $("#deposit_total").parent().parent().css("display", "block");
                            $("#follow").parent().css("display", "none");
                            $("#file").parent().parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "none");
                        } else if ($("input[name=PAYMENT_TYPES]:checked").val() == "CHECK") {
                            $("#follow").parent().css("display", "none");

                            $("#accountTable").parent().parent().parent().css("display", "block");
                            $("#file").parent().parent().css("display", "none");

                        } else if ($("input[name=PAYMENT_TYPES]:checked").val() == "WIRE") {
                            $("#follow").parent().css("display", "block");

                            $("#accountTable").parent().parent().parent().css("display", "none");
                            $("#file").parent().parent().css("display", "block");

                        }

                    });
                });

                $("#sumHidden").parent().parent().css("display", "none");
                $("#sumHidden-2").parent().parent().css("display", "none");
                $("#sumHidden-3").parent().parent().css("display", "none");
                $("#checkHidden").parent().parent().css("display", "none");
				$(document).on('change', '[id^="variance_trac"]', function () {
					if ($(this).val()!=null) 
					{   
						var valueFrom=$(this).parent().parent().parent().parent().parent().children().eq(2).children().children().children().children();            
						valueFrom.prop('required',true);			
					}
					else
					{						
						var valueFrom=$(this).parent().parent().parent().parent().parent().children().eq(2).children().children().children().children();
						valueFrom.prop('required',false);			
					}
				});
				$(document).on('click', '[id="AddFundsBtn2"]', function () {
					$('[id^="variance_trac"]').each(function(){
						if ($(this).val()!=null) 
						{   
							var valueFrom=$(this).parent().parent().parent().parent().parent().children().eq(2).children().children().children().children();            
							valueFrom.prop('required',true);			
						}
						else
						{						
							var valueFrom=$(this).parent().parent().parent().parent().parent().children().eq(2).children().children().children().children();
							valueFrom.prop('required',false);			
						}
					});
				});

                $(document).on("click", "[name='submit-btn']", function() {
					
				var deposit = $("#deposit_total").val()
				localStorage.setItem('deposit-trac', deposit );
				var plan = $("#planName").val()
				localStorage.setItem('plan-trac', plan );
				var batch = $("#batchid").val()
				localStorage.setItem('batch-trac', batch );
				var tradeDate = $("#tradeDate").val()
				localStorage.setItem('trade-trac', tradeDate );


                    var emailSum = $("#sumdisp").children().text().substring(8);
                    $("#sumHidden").val(emailSum);

                    var emailSumdisp = $("#sum1disp").children().text().substring(13);
                    $("#sumHidden-2").val(emailSumdisp);

                    var emailTotaldisp = $("#totaldisp").children().text().substring(20);
                    $("#sumHidden-3").val(emailTotaldisp);

                    if ($('input[name="PAYMENT_TYPES"]')[1].checked) {
                        var checkBody = "<br/>TOTAL OF ALL CHECKS     $ " + emailSum;
                        $("#checkHidden").val(checkBody);
                    }
                    $(".Element2a").not(":hidden").each(function() {
                        $(this).prop("required", true);
                    });
                    $(".Element2a").not(":visible").each(function() {
                        $(this).prop("required", false);
                    });
                    $(".Element2b").not(":hidden").each(function() {
                        $(this).prop("required", true);
                    });
                    $(".Element2b").not(":visible").each(function() {
                        $(this).prop("required", false);
                    });
                    var subjectLine = "";
                    var arr = new Array();
                    var brr = new Array();

                    if ($("#nonCurrentDate").val().length > 0) {
                        var nondateBody = "<br/>NON-CURRENT DATE: " + $("#nonCurrentDate").val();
                        $("#NONDATEBODY").val(nondateBody);
                    }
                    if ($("#reason_code").val().length > 0) {
                        var reasonBody = "REASON CODE: " + $("#reason_code").val();
                        $("#REASONBODY").val(reasonBody);
                    }
                    if ($("#tmsm").val().length > 0) {
                        var tmsmBody = "APPROVER: " + $("#tmsm").val();
                        $("#TMSMBODY").val(tmsmBody);
                    }
                    if ($("#batchid").val().length > 0) {
                        var batchBody = "BATCH ID #: " + $("#batchid").val();
                        $("#BATCHHIDDEN").val(batchBody);
                    }
                    if ($("#comment").val().length > 0) {
                        var addBody = "ADDITIONAL COMMENTS: <br/>" + $("#comment").val();
                        $("#ADDBODY").val(addBody);
                    }

                    $('[id^="planid_trac"]').each(function() {
                        arr.push($(this).val());

                    });

                    if (arr.length > 4) {
                        for (var i = 0; i < 4; ++i) {
                            brr[i] = arr[i];
                        }
                        subjectLine += brr.join(", ");
                    } else {
                        subjectLine += arr.join(", ");
                    }

                    subjectLine += "  " + $("#deposit_total").val();
                    $("#PLIST").val(subjectLine);
					
					function browserSupportsDateInputMethod1() {
                            var i = document.createElement("input");
                            i.setAttribute("type", "date");
                            return i.type !== "text";
                        }
					if (browserSupportsDateInputMethod1()) 
					{
						$("#NONDATEBODY").each(function() {
							if ($(this).val() != "") {
								var dateVal = $(this).val();
								var today = new Date(dateVal);
								var dd = String(today.getDate()).padStart(2, '0');
								var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
								var yyyy = today.getFullYear();
								today = mm + '/' + dd + '/' + yyyy;
								var finDate = "NON-CURRENT DATE : " + today;
								$("#NONDATEBODY").val(finDate);

							}
						});
					}
                });
            }
			
			if ((document.URL).includes("TRAC-2000-Alert")) {
	
                function currDate() { 
            
                        var today = new Date();
                        var month = today.getMonth() + 1;
                        if (month < 10) {
                            month = "0" + month;
                        }
                        var day = today.getDate();
                        if (day < 10) {
                            day = "0" + day;
                        }
                        var year = today.getFullYear();
                        var dateString = year + "-" + month + "-" + day;
                        return dateString;
                                    }
                var todayDate = currDate();
                var date = new Date();
                $("#date-t").css('width', '600px')
                $("#date-t").val(date);
                $("#date-t").prop("disabled", true);
                
                if(localStorage.getItem('deposit-trac')!= null)
                {
                $("#deposit-total-t").val(localStorage.getItem('deposit-trac'));
                $("#deposit-total-t").click();
                }
                if(localStorage.getItem('plan-trac')!= null)
                {
                $("#plan-type-t").val(localStorage.getItem('plan-trac'));
                $("#plan-type-t").click();
                }
                if(localStorage.getItem('batch-trac')!= null)
                {
                $("#batch-t").val(localStorage.getItem('batch-trac'));
                $("#batch-t").click();
                }
                if(localStorage.getItem('trade-trac')!= null)
                {
                $("#trade-date-t").val(localStorage.getItem('trade-trac'));
                $("#trade-date-t").click();
                }
                if(localStorage.getItem('trade-trac')== todayDate)
                {
                $("#check-text").parent().css("display", "none");
                }
                
                localStorage.removeItem('deposit-trac');
                localStorage.removeItem('plan-trac');
                localStorage.removeItem('batch-trac');
                localStorage.removeItem('trade-trac');

                }


   /*----------------------------------------------FD rpe notification -------------------------------------------------------------------------*/


    if ((document.URL).includes("fd-rpe-notification-future-date-request-form")) {

                $("#lineDetails").parent().parent().css("display", "none");
        $("#likefund2").parent().parent().css("display", "none");

                $("#subdate").parent().parent().css("display", "none");
                $(document).on("click", "[name='submit-btn']", function() {

                    var subjectLine = " ";
var requestType = $("#reqtype").val();
if(requestType == "Money Type Change") {
var selectedFed = $('input[name="fedyesno"]:checked').val();
var selectedTrac = $('input[name="tracyesno"]:checked').val();
              if(selectedFed.length >0 && selectedTrac.length >0) {
                             subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form- "+ $("#planid").val() + " - " + $("#planname").val()  + " " +  "(Money Type Change)";
              }
} else if(requestType == "Printed Fee Disclosure Order") {

              subjectLine = "Fee Disclosure Booklet Order - " + $("#planid").val() + " - "+ $("#planname").val();
} else if(requestType == "Vesting Schedule Change") {
              subjectLine = "Vesting Schedule Change - " + $("#planid").val() + " - "+ $("#planname").val();
} else if(requestType == "Fund Remove - No Mapping") {
              subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form- "+ $("#planid").val() + " - " + $("#planname").val() + " " + "(Fund Remove, No Mapping)";
} else if(requestType == "Fund Change - Mapping - SCC") {
              subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form- "+ $("#planid").val() + " - " + $("#planname").val() + " " +  "(Fund Change, Mapping- Share Class Change)";
} else if(requestType == "Fund Change - Mapping - FREP") {
              subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form- "+ $("#planid").val() + " - " + $("#planname").val() + " " +  "(Fund Change, Mapping- Fund Replacement)";
} else if(requestType == "Default Fund Change - No Mapping") {
              subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form- "+ $("#planid").val() + " - " + $("#planname").val() + " " +  "(Default Fund Change, No Mapping)";
} else if(requestType == "Loan Provision Add / Remove") {
              if($('input[name="effectiveDateRadio"]:checked').val() == "today") {
                             subjetLine = setDate($("#effdate").val()) + " - Loan Provision Add / Remove - " +  $("#planid").val() + " - "+ $("#planname").val();
              } else {
                             subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form- Loan Provision Add / Remove " +  " - " + $("#planid").val() + " - " + $("#planname").val();
              }             
} else if(requestType == "Fee Payment Authorization") {
              subjectLine = "Fee Payment Authorization - " + $("#planid").val() + " - " + $("#planname").val();
}  else if(requestType == "Distribution") {
              subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form- "+ $("#planid").val() + " - " + $("#planname").val() + "(Distribution)";
} else if(requestType == "Other") {
              subjectLine = "**Other** RPE Notification Request - " + $("#planid").val() + " - " + $("#planname").val();
}
                    $("#mailSubject").val(subjectLine);

                    var likefund = "";


                     if($("input[name=likefund]:checked").val() == undefined && $("#likefund").is(":visible")) {

                                    likefund = "No";


                } 

                               else if($("input[name=likefund]:checked").val() == "Like Fund-to-Like Fund") {

                                likefund = "Yes";

                    } else  {

                        likefund = "No";
                    }

                    $("#likefund").val(likefund);


                    var lineDetails = " ";
                    var to = " ";
					 for (var i = 1; i <= 29; i++) {

                        var fromid = $("select[id=from] option:selected").val();
                         var toid = $("select[id=to] option:selected").val();

                        if (fromid == "" && toid == "") {
                            lineDetails += "LINE " + i + ": - <br/>";
                        } 

                         else if(i === 1){


                                var fromid1 = $("select[id=from] option:selected").val();
                             var toid1 = $("select[id=to] option:selected").val();

                             if(fromid1 = "" && toid1 == "" || fromid1 == undefined || toid1 == undefined) {
    							to = "";
                             } else {

                                 to = fromid1 +" - "+ toid1 ;
								 to = fromid +" - "+ toid ;
                             }
                         lineDetails += "LINE " + i + ": - " + to + "<br/>";

                            }else {

                             var fromid = $("select[id=from"+i+"] option:selected").val();
                         var toid = $("select[id=to"+i+"] option:selected").val();

							
							if(( fromid == null) || ( toid == null) || ( fromid == undefined) || ( toid == undefined) ) {
                    to = " ";
                                lineDetails += "LINE " + i + ": - " + to + "<br/>";
                            }else{ 



                        to = fromid +" - "+ toid ;
                         lineDetails += "LINE " + i + ": - " + to + "<br/>";


                        }
                        }
						
						
                    }
                    $("#lineDetails").val(lineDetails);

                    var exp = $('input[name="expyesno"]:checked').val();
                    if (exp == "Yes") {
                        $("#expyesno").val("Yes");
                    } else {
                        $("#expyesno").val(" ");
                    }
                    var notice = $('input[name="noticeyesno"]:checked').val();
                    if (notice == "undefined") {
                        $("#noticeyesno").val(" ");
                    }
                    var fedyesno = $('input[name="fedyesno"]:checked').val();
                    if (fedyesno == "undefined") {
                        $("#fedyesno").val(" ");
                    }
                    var tracyesno = $('input[name="tracyesno"]:checked').val();
                    if (tracyesno == "undefined") {
                        $("#tracyesno").val(" ");
                    }
                    var vestingtrac = $('input[name="vestingtracyesno"]:checked').val();
                    if (vestingtrac == "undefined") {
                        $("#vestingtracyesno").val(" ");
                    }


var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var year = today.getFullYear().toString().substr(-2);
today = mm + '/' + dd + '/' + year;

$("#subdate").val(today);

                    function setDate(val) {

var dateVal = val;
var today = new Date(dateVal);
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
today = mm + '/' + dd + '/' + yyyy;
                              return today;


                            }
				});
			}

                    /*---------------------------------------cdsc  fees----------------------------------------------------------------------------------------------*/

                    if ((document.URL).includes("cdsc-payment-to-funds-form")) {

                        $('select[name=SITE]').change(function() {
                            $("select[name=SITE] option:selected").each(function() {
                                if ($(this).val() == "IRV") {
                                    alert('You selected IRV. Is that correct?');

                                } else if ($(this).val() == "SNO") {
                                    alert('You selected SNO. Is that correct?');

                                } else if ($(this).val() == "IND") {
                                    alert('You selected IND. Is that correct?');

                                } else if ($(this).val() == "HRO") {
                                    alert('You selected HRO. Is that correct?');

                                }
                            });

                        });

                    }

                    /*-------------------------------------------------RKD MULTI-FUND LARGE TRADE NOTIFICATION FORM-------------------------------------------------*/

                    if ((document.URL).includes("rkd-multi-fund-large-trade-notification-form")) {

                        $("#fund1").parent().parent().css("display", "none");
                        $("#s1").parent().css("display", "none");
                        $("#amount1").parent().parent().css("display", "none");
                        $("#t1").parent().css("display", "none");
                        $('input[name=addl1]').parent().parent().parent().css("display", "none");

                        $("#fund2").parent().parent().css("display", "none");
                        $("#s2").parent().css("display", "none");
                        $("#amount2").parent().parent().css("display", "none");


                        $('input[name=addl]').change(function() {

                            $("input[name=addl]:checked").each(function()

                                {
                                    if ($("input[name=addl]:checked").val() == "no") {

                                        $("#fund1").parent().parent().css("display", "none");
                                        $("#s1").parent().css("display", "none");
                                        $("#amount1").parent().parent().css("display", "none");
                                        $("#t1").parent().css("display", "none");
                                        $('input[name=addl1]').parent().parent().parent().css("display", "none");

                                        $("#fund2").parent().parent().css("display", "none");
                                        $("#s2").parent().css("display", "none");
                                        $("#amount2").parent().parent().css("display", "none");


                                    } else if ($("input[name=addl]:checked").val() == "yes") {

                                        $("#fund1").parent().parent().css("display", "block");
                                        $("#s1").parent().css("display", "block");
                                        $("#amount1").parent().parent().css("display", "block");
                                        $("#t1").parent().css("display", "block");
                                        $('input[name=addl1]').parent().parent().parent().css("display", "block");


                                        $("#fund2").parent().parent().css("display", "none");
                                        $("#s2").parent().css("display", "none");
                                        $("#amount2").parent().parent().css("display", "none");


                                    }


                                });
                        });



                        $('input[name=addl1]').change(function() {
                            $("input[name=addl1]:checked").each(function() {
                                if ($("input[name=addl1]:checked").val() == "no") {

                                    $("#fund1").parent().parent().css("display", "block");
                                    $("#s1").parent().css("display", "block");
                                    $("#amount1").parent().parent().css("display", "block");
                                    $("#t1").parent().css("display", "block");
                                    $('input[name=addl1]').parent().parent().parent().css("display", "block");

                                    $("#fund2").parent().parent().css("display", "none");
                                    $("#s2").parent().css("display", "none");
                                    $("#amount2").parent().parent().css("display", "none");


                                } else if ($("input[name=addl1]:checked").val() == "yes") {

                                    $("#fund1").parent().parent().css("display", "block");
                                    $("#s1").parent().css("display", "block");
                                    $("#amount1").parent().parent().css("display", "block");
                                    $("#t1").parent().css("display", "block");
                                    $('input[name=addl1]').parent().parent().parent().css("display", "block");


                                    $("#fund2").parent().parent().css("display", "block");
                                    $("#s2").parent().css("display", "block");
                                    $("#amount2").parent().parent().css("display", "block");


                                }


                            });
                        });

                    }

                    /*---------------------------------------------------CONP Batch Ticket Investment---------------------------------------------------*/
                    if ((document.URL).includes("conp-batch-ticket")) {

                        $("#CONPBATCHTICKETLINESBODY").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() {
                            var outOfBalance = Number($("#outOfBalanceReadOnly").val());
                            var outOfBalance2;
                            if (outOfBalance < 0) {
                                $('#outOfBalanceReadOnly').prop("disabled", false);
                                $("#outOfBalanceReadOnly").focus();
                                outOfBalance2 = "-$" + $("#outOfBalanceReadOnly").val();
                                $('#outOfBalanceReadOnly').prop("disabled", true);
                            } else {
                                $('#outOfBalanceReadOnly').prop("disabled", false);
                                $("#outOfBalanceReadOnly").focus();
                                outOfBalance2 = "$" + $("#outOfBalanceReadOnly").val();
                                $('#outOfBalanceReadOnly').prop("disabled", true);
                            }
                            var BATCHTICKETLINES = "-------------------------------------------------<br/><br/>" + "Total: " + $("#sumdisp").find('h5').text().substring(7) + '<br/><br/>' + "Fee: " + $("#feeAmount").val() + '<br/><br/>' + "Check(s) Total: " + $("#depositTotal").val() + '<br/><br/>' + "Out of Balance +/-: " + outOfBalance2 + '<br/><br/>';
                            $("#CONPBATCHTICKETLINESBODY").val(BATCHTICKETLINES);
                            var subjectLine = "CONP Batch Titcket - " + $("#sumdisp").find('h5').text().substring(7) + " - Batch #: " + $("#batch").val();
                            $("#mailSubject").val(subjectLine);
                        });
                    }

                    /*---------------------------------------------------Batch Ticket Investment---------------------------------------------------*/
                    if ((document.URL).includes("batch-ticket-investment")) {

                        $("#totalHidden").parent().parent().css("display", "none");
                        $("#CASHEQUIVALENTBody").parent().parent().css("display", "none");
                        $("#BATCHTICKETLINESBODY").parent().parent().css("display", "none");
                        $("#TRADEDATEBODY").parent().parent().css("display", "none");
                        $("#MANUALCHECK").parent().parent().css("display", "none");
                        $("#manualCheckAccount").parent().parent().css("display", "none");
                        $("#man1").parent().css("display", "none");
                        $("#manualCheckFund").parent().parent().css("display", "none");

                        $('#depositTotal').on('blur', function() {
                            if ($("#outOfBalanceReadOnly").val() > 0) {
                                $("#MANUALCHECK").parent().parent().css("display", "block");
                                $("#manualCheckAccount").parent().parent().css("display", "block");
                                $("#man1").parent().css("display", "block");
                                $("#manualCheckFund").parent().parent().css("display", "block");
                                $("#MANUALCHECK").attr('checked', 'true');


                            } else {

                                $("#MANUALCHECK").parent().parent().css("display", "none");
                                $("#manualCheckAccount").parent().parent().css("display", "none");
                                $("#man1").parent().css("display", "none");
                                $("#manualCheckFund").parent().parent().css("display", "none");
                            }

                        });



                        $(document).on('blur', '[name^="amtdemo"]', function() {

                            if ($("#outOfBalanceReadOnly").val() > 0) {
                                $("#MANUALCHECK").parent().parent().css("display", "block");
                                $("#manualCheckAccount").parent().parent().css("display", "block");
                                $("#man1").parent().css("display", "block");
                                $("#manualCheckFund").parent().parent().css("display", "block");
                                $("#MANUALCHECK").attr('checked', 'true');

                            } else {

                                $("#MANUALCHECK").parent().parent().css("display", "none");
                                $("#manualCheckAccount").parent().parent().css("display", "none");
                                $("#man1").parent().css("display", "none");
                                $("#manualCheckFund").parent().parent().css("display", "none");
                            }

                        });

                        $("#APPROVER").parent().parent().css("display", "none");
                        $("#L1").parent().css("display", "none");
                        $('#REASONCODE').on('blur', function() {

                            if ($(this).val().length > 0) {
                                $("#APPROVER").parent().parent().css("display", "block");
                                $("#L1").parent().css("display", "block");
                            } else {
                                $("#APPROVER").parent().parent().css("display", "none");
                                $("#L1").parent().css("display", "none");

                            }
                        });

                        $(document).on("click", "[name='submit-btn']", function() {
                            if ($("#CASHEQUIVALENT").prop('checked')) {
                                $("#CASHEQUIVALENTBody").val("Y");
                            } else {
                                $("#CASHEQUIVALENTBody").val("N");
                            }


                            var outOfBalance = Number($("#outOfBalanceReadOnly").val());
                            var outOfBalance2;
                            if (outOfBalance < 0) {
                                $('#outOfBalanceReadOnly').prop("disabled", false);
                                $("#outOfBalanceReadOnly").focus();
                                outOfBalance2 = "-$" + $("#outOfBalanceReadOnly").val();
                                $('#outOfBalanceReadOnly').prop("disabled", true);

                            } else {
                                $('#outOfBalanceReadOnly').prop("disabled", false);
                                $("#outOfBalanceReadOnly").focus();
                                outOfBalance2 = "$" + $("#outOfBalanceReadOnly").val();
                                $('#outOfBalanceReadOnly').prop("disabled", true);
                            }


                            var totalDisplay = $("#sumdisp").text().trim();
                            var totalArray = totalDisplay.split(":");
                            var finalTotal = "PROCESSING TOTAL:           " + totalArray[1];
                            $("#totalHidden").val(finalTotal);


                            var BATCHTICKETLINES = "FEE:                          " + $("#feeAmount").val() + '<br/>' + "DEPOSIT TOTAL:               " + $("#depositTotal").val() + '<br/>' + "OUT OF BALANCE +/-:          " + outOfBalance2 + '<br/><br/>' + "CASH EQUIVALENT: " + $("#CASHEQUIVALENTBody").val();
                            if ($("#MANUALCHECK").prop('checked')) {
                                BATCHTICKETLINES += "<br/><br/>MANUAL CHECK ISSUED FOR OVERAGE FROM: " + $("#manualCheckAccount").val() + " / " + $("#manualCheckFund").val();
                            }
                            $("#BATCHTICKETLINESBODY").val(BATCHTICKETLINES);

							function browserSupportsDateInputMethod2() {
                            var i = document.createElement("input");
                            i.setAttribute("type", "date");
                            return i.type !== "text";
							}
                            var finDate;
							if (browserSupportsDateInputMethod2()) 
							{
								if ($("#TRADEDATE").val() != "") {
									var dateVal = $("#TRADEDATE").val();
									var dateConversionArray = dateVal.split("-");
									finDate = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
								}
							}
							else
							{
								finDate=$("#TRADEDATE").val() ;
							}
                            var TRADEDATEFIELD = "TRADE DATE: " + finDate;
                            if ($("#REASONCODE").val().length != 0) {
                                TRADEDATEFIELD += "<br/>REASON CODE: " + $("#REASONCODE").val();
                                TRADEDATEFIELD += "<br/>APPROVER: " + $("#APPROVER").val();
                            }
                            $("#TRADEDATEBODY").val(TRADEDATEFIELD);


                            var accountNumbers = new Array();
                            var subjectLine = "Batch Ticket - " + $("#SITE").val() + " - " + $("#sumdisp").find('h5').text().substring(7) + " - ";
                            $("[name='account_batch']").each(function() {
                                if (jQuery.inArray($(this).val(), accountNumbers) == -1) {
                                    accountNumbers.push(Number($(this).val()));

                                }
                            });
                            var uniqueAccountNumbers = new Array();
                            var numberOfAccounts = accountNumbers.length;

                            for (var i = 0; i < numberOfAccounts; i++) {
                                for (var j = i + 1; j < numberOfAccounts; j++)
                                    if (accountNumbers[i] === accountNumbers[j]) {
                                        j = ++i;
                                    }
                                uniqueAccountNumbers.push(accountNumbers[i]);
                            }

                            uniqueAccountNumbers = uniqueAccountNumbers.sort(sortNumber);
                            for (var i = 0; i < uniqueAccountNumbers.length; ++i) {
                                if (i == 0) {
                                    subjectLine += (uniqueAccountNumbers[i]);
                                } else {
                                    subjectLine += ", " + (uniqueAccountNumbers[i]);
                                }
                            }

                            function sortNumber(a, b) {
                                return a - b;
                            }

                            $("#mailSubject").val(subjectLine);
                        });

                    }

                    /*-----------------------------------AFS Gap/Bridge Letter Request Form (non-financial)-----------------*/
                    if ((document.URL).includes("soc1-and-gap-bridge-letter-request")) {
                        $("#mailHiddenVal").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() {
                            var mailHiddenVal = "<br/>Email: " + $("#email").val();
                            $("#mailHiddenVal").val(mailHiddenVal);
                            var subjectLine = "AFS Gap/Bridge Letter Request Form - " + $("#planid-6").val().replace(/\r?\n/g, ', ');
                            $("#mailSubject").val(subjectLine);
                        });
                    }
                    /*---------------------------------------online batch ticket-------------------------------------------------------------------*/

                    if ((document.URL).includes("online-batch-ticket")) {

                        function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

                            var today = new Date();
                            var month = today.getMonth() + 1;
                            if (month < 10) {
                                month = "0" + month;
                            }
                            var day = today.getDate();
                            if (day < 10) {
                                day = "0" + day;
                            }
                            var year = today.getFullYear();
                            var dateString = year + "-" + month + "-" + day;
                            return dateString;
                        }

                        $('input[name=ucd]').change(function() {
                            $("input[name=ucd]").each(function() {
                                if ($("input[name=ucd]:checked").val() == "Use Current Date") {
                                    $("#payroll").prop("value", currDate());

                                } else if ($("input[name=ucd]:checked").val() == undefined) {
                                    $("#payroll").prop("value", "");

                                }

                            });

                        });

                    }

                    



                    /*-----------------------------------------------------------------RPS Phone Message Form------------------------------------------------------------*/

                    if ((document.URL).includes("rkd-phone-message-form")) {


                        $("#to").parent().css("display", "none");
                        $("#wfr").parent().parent().css("display", "none");
                        $("#recipinits").parent().parent().css("display", "block");
                        $("#recipientManager").parent().parent().css("display", "block");

                        $('input[name=thismessage]').change(function() {
                            $("input[name=thismessage]").each(function() {
                                if ($("input[name=thismessage]:checked").val() == "normal") {
                                    $("#to").parent().css("display", "none");
                                    $("#wfr").parent().parent().css("display", "none");
                                    $("#recipinits").parent().parent().css("display", "block");
                                    $("#recipientManager").parent().parent().css("display", "block");
                                    $('#callType').prop("selectedIndex", 0);
                                } else if ($("input[name=thismessage]:checked").val() == "Workflow") {
                                    $("#to").parent().css("display", "block");
                                    $("#wfr").parent().parent().css("display", "block");
                                    $("#recipinits").parent().parent().css("display", "none");
                                    $("#recipientManager").parent().parent().css("display", "none");
                                    $('#callType').prop("selectedIndex", 0);
                                } else if ($("input[name=thismessage]:checked").val() == "websme") {
                                    $("#to").parent().css("display", "none");
                                    $("#wfr").parent().parent().css("display", "none");
                                    $("#recipinits").parent().parent().css("display", "none");
                                    $("#recipientManager").parent().parent().css("display", "none");
                                    $('#callType').prop("value", 'Callback required');

                                } else if ($("input[name=thismessage]:checked").val() == "webPPTPA") {
                                    $("#to").parent().css("display", "none");
                                    $("#wfr").parent().parent().css("display", "none");
                                    $("#recipinits").parent().parent().css("display", "none");
                                    $("#recipientManager").parent().parent().css("display", "none");
                                    $('#callType').prop("selectedIndex", 0);

                                }
                            });
                        });

                    }

                    /*------------------------------------------------------SYSFEE------------------------------------------------------*/
                    if ((document.URL).includes("sysfee-request-form.html")) {

                        $("#hidfeedur").parent().parent().css("display", "none");
                        $("#riaRadioBtnBody").parent().parent().css("display", "none");
                        $("#tpaRadioBtnBody").parent().parent().css("display", "none");
                        $("#hidfeedur").val("N / A");

                        $("#tpa-text").parent().css("display", "none");
                        $("#tpaRadio").parent().parent().parent().css("display", "none");
                        $("#duration-text").parent().css("display", "none");
                        $("#duration").parent().parent().parent().css("display", "none");
                        $("#amount").parent().parent().css("display", "none");
                        $("#abips").parent().parent().css("display", "none");
                        $("#ria-text").parent().css("display", "none");
                        $("#riaRadio").parent().parent().parent().css("display", "none");

                        $('select[id=feetype]').change(function() {
                            $("select[id=feetype] option:selected").each(function() {
                                if ($(this).val() == "TPA") {
                                    $("#tpa-text").parent().css("display", "block");
                                    $("#tpaRadio").parent().parent().parent().css("display", "block");
                                    $("#duration-text").parent().css("display", "block");
                                    $("#duration").parent().parent().parent().css("display", "block");
                                    $("#ria-text").parent().css("display", "none");
                                    $("#riaRadio").parent().parent().parent().css("display", "none");
                                } else if ($(this).val() == "RIA") {
                                    $("#tpa-text").parent().css("display", "none");
                                    $("#tpaRadio").parent().parent().parent().css("display", "none");
                                    $("#duration-text").parent().css("display", "block");
                                    $("#duration").parent().parent().parent().css("display", "block");
                                    $("#ria-text").parent().css("display", "block");
                                    $("#riaRadio").parent().parent().parent().css("display", "block");

                                } else {
                                    $("#tpa-text").parent().css("display", "none");
                                    $("#tpaRadio").parent().parent().parent().css("display", "none");
                                    $("#duration-text").parent().css("display", "none");
                                    $("#duration").parent().parent().parent().css("display", "none");
                                    $("#ria-text").parent().css("display", "none");
                                    $("#riaRadio").parent().parent().parent().css("display", "none");
                                }
                            });
                        });

                        $('input[name=forbRadio]').change(function() {
                            $("input[name=forbRadio]").each(function() {
                                if ($("input[name=forbRadio]:checked").val() == "Annualized Fee Amount") {
                                    $("#amount").parent().parent().css("display", "block");
                                    $("#abips").parent().parent().css("display", "none");
                                }
                                if ($("input[name=forbRadio]:checked").val() == "Annualized Basis Points") {
                                    $("#amount").parent().parent().css("display", "none");
                                    $("#abips").parent().parent().css("display", "block");
                                }
                            });

                        });
                        $(document).on("click", "[name='submit-btn']", function() {

                            var riaRadioBtn;
                            var tpaRadioBtn;

                            if ($("[name='duration']")[0].checked) {
                                $("#hidfeedur").val("One-Time");
                            }
                            if ($("[name='duration']")[1].checked) {
                                $("#hidfeedur").val("Ongoing");
                            }

                            var fptval = $("#feetype").val();

                            if (fptval == "RKD" || fptval == "Other") {
                                $("#hidfeedur").val("One-Time");
                            }
                            if ($("[name='riaRadio']")[0].checked) {
                                riaRadioBtn = "Yes";
                            }
                            if ($("[name='riaRadio']")[1].checked) {
                                riaRadioBtn = "No";
                            }
                            if ($("#riaRadio").val() === undefined) {
                                riaRadioBtn = "No";
                            }

                            if ($("[name='tpaRadio']")[0].checked) {
                                tpaRadioBtn = "Yes";
                            }
                            if ($("[name='tpaRadio']")[1].checked) {
                                tpaRadioBtn = "No";
                            }
                            if ($("#tpaRadio").val() === undefined) {
                                tpaRadioBtn = "No";
                            }
                            $("#riaRadioBtnBody").val(riaRadioBtn);
                            $("#tpaRadioBtnBody").val(tpaRadioBtn);

                        });
                    }

                    /*---------------------------------------------------RKD Batch Ticket Form---------------------------------------------------*/
                    if ((document.URL).includes("online-batch-ticket")) {
$("#amount").removeAttr("maxlength");
                        $("[id='amount']").blur(function() {
                            if (!$.isNumeric($("#amount").val())) {
                                alert("Please check Processing Amounts in Section 3.  A non-numeric value was detected.");
                                $("#amount").focus();
                                $("#amount").val('0.00');
                                return false;
                            }
                        });
                        $("[id='amount2']").blur(function() {
                            if (!$.isNumeric($("#amount2").val())) {
                                alert("Please check Processing Amounts in Section 3.  A non-numeric value was detected.");
                                $("#amount2").focus();
                                $("#amount2").val('0.00');
                            }
                        });

                        $("[id='amount3']").blur(function() {
                            if (!$.isNumeric($("#amount3").val())) {
                                alert("Please check Processing Amounts in Section 3.  A non-numeric value was detected.");
                                $("#amount3").focus();
                                $("#amount3").val('0.00');
                            }
                        });

                        $("[id='amount4']").blur(function() {
                            if (!$.isNumeric($("#amount4").val())) {
                                alert("Please check Processing Amounts in Section 3.  A non-numeric value was detected.");
                                $("#amount4").focus();
                                $("#amount4").val('0.00');
                            }
                        });
                        $("[id='overunder']").blur(function() {
                            if (!$.isNumeric($("#overunder").val())) {
                                alert("Please check Processing Amounts in Section 4.  A non-numeric value was detected.");
                                $("#overunder").focus();
                                $("#overunder").val('0.00');
                            }
                        });
                        $("[id='mancheck']").blur(function() {
                            if (!$.isNumeric($("#mancheck").val())) {
                                alert("Please check Processing Amounts in Section 4.  A non-numeric value was detected.");
                                $("#mancheck").focus();
                                $("#mancheck").val('0.00');
                            }
                        });
                        $("[id='forfetiure']").blur(function() {
                            if (!$.isNumeric($("#forfetiure").val())) {
                                alert("Please check Processing Amounts in Section 4.  A non-numeric value was detected.");
                                $("#forfetiure").focus();
                                $("#forfetiure").val('0.00');
                            }
                        });
                        $("[id='loan']").blur(function() {
                            if (!$.isNumeric($("#loan").val())) {
                                alert("Please check Processing Amounts in Section 4.  A non-numeric value was detected.");
                                $("#loan").focus();
                                $("#loan").val('0.00');
                            }
                        });
                        $("[id='redemption']").blur(function() {
                            if (!$.isNumeric($("#redemption").val())) {
                                alert("Please check Processing Amounts in Section 4.  A non-numeric value was detected.");
                                $("#redemption").focus();
                                $("#redemption").val('0.00');
                            }
                        });
                        $("[id='interest']").blur(function() {
                            if (!$.isNumeric($("#interest").val())) {
                                alert("Please check Processing Amounts in Section 4.  A non-numeric value was detected.");
                                $("#interest").focus();
                                $("#interest").val('0.00');
                            }
                        });
                        $("[id='correction']").blur(function() {
                            if (!$.isNumeric($("#correction").val())) {
                                alert("Please check Processing Amounts in Section 4.  A non-numeric value was detected.");
                                $("#correction").focus();
                                $("#correction").val('0.00');
                            }
                        });


                        $(document).on("click", "[name='submit-btn']", function(e) {
							 if($("[name='conRadio ']")[1].checked && $("#qap").val()==""){
                                alert("QCer's Initials is a required field");
								$("#qap").focus();
								(e).preventDefault();	
                            }
                            if ($("#amount").val() == "") {
                                $("#amount").val(parseFloat("0.00").toFixed(2));
                                $("#amount").click();
                            }

                            if ($("#amount2").val() == "") {
                                $("#amount2").val(parseFloat("0.00").toFixed(2));
                                $("#amount2").click();
                            }

                            if ($("#amount3").val() == "") {
                                $("#amount3").val(parseFloat("0.00").toFixed(2));
                                $("#amount3").click();
                            }

                            if ($("#amount4").val() == "") {
                                $("#amount4").val(parseFloat("0.00").toFixed(2));
                                $("#amount4").click();
                            }

                            if ($("#overunder").val() == "") {
                                $("#overunder").val(parseFloat("0.00").toFixed(2));
                                $("#overunder").click();
                            }

                            if ($("#mancheck").val() == "") {
                                $("#mancheck").val(parseFloat("0.00").toFixed(2));
                                $("#mancheck").click();
                            }

                            if ($("#forfetiure").val() == "") {
                                $("#forfetiure").val(parseFloat("0.00").toFixed(2));
                                $("#forfetiure").click();
                            }

                            if ($("#loan").val() == "") {
                                $("#loan").val(parseFloat("0.00").toFixed(2));
                                $("#loan").click();
                            }

                            if ($("#redemption").val() == "") {
                                $("#redemption").val(parseFloat("0.00").toFixed(2));
                                $("#redemption").click();
                            }

                            if ($("#interest").val() == "") {
                                $("#interest").val(parseFloat("0.00").toFixed(2));
                                $("#interest").click();
                            }

                            if ($("#correction").val() == "") {
                                $("#correction").val(parseFloat("0.00").toFixed(2));
                                $("#correction").click();
                            }

                            if ($("#prototal").val() == "") {
                                $("#prototal").val(parseFloat("0.00").toFixed(2));
                                $("#prototal").click();
                            }
                            if ($("#total").val() == "") {
                                $("#total").val(parseFloat("0.00").toFixed(2));
                                $("#total").click();
                            }
                        });
                    }


                    /* -------- Copy of Cashed check Request ------------*/

                    function deltaDate(input, days, months, years) {
                        return new Date(
                            input.getFullYear() + years,
                            input.getMonth() + months,
                            Math.min(
                                input.getDate() + days,
                                new Date(input.getFullYear() + years, input.getMonth() + months + 1, 0).getDate()
                            )
                        );
                    }

                    function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

                        var today = new Date();
                        var month = today.getMonth() + 1;
                        if (month < 10) {
                            month = "0" + month;
                        }
                        var day = today.getDate();
                        if (day < 10) {
                            day = "0" + day;
                        }
                        var year = today.getFullYear() - 2000;
                        var dateString = month + "/" + day + "/" + year;
                        return dateString;
                    }
                    var date = deltaDate(new Date(), 0, 0, -7).toString();

                    $("#dateSubmitted-2").val(date.substring(4, 10) + "," + date.substring(10, 15));
                    $("#dateSubmitted-1").val(currDate());
                    $("#dateSubmitted-2").prop('disabled', true);
                    $("#text-date").children().css("color", "#8a6d3b").css('font-size', '14px');
                    $("#text-date").parent().css('width', '152px');
                    $("#dateSubmitted-1").prop('disabled', true);
                    $("#dateSubmitted-1").css('border', 'none').css('font-size', '14px').css("padding-left", "0px").css("color", "#8a6d3b");

                    /*---------------------------------------------------IMPLEMENTATION MISC. MAINT. REQUEST---------------------------------------------------*/
                    if ((document.URL).includes("implementation-misc--maint--request")) {

                        $("#hidrushBody").parent().parent().css("display", "none");
                        $("#hidfsBody").parent().parent().css("display", "none");
                        $("#hidpupupdateBody").parent().parent().css("display", "none");
                        $("#hidtpaBody").parent().parent().css("display", "none");
                        $("#hidcbtBody").parent().parent().css("display", "none");
						$("#hidotherBody").parent().parent().css("display", "none");
                        $("#hidcbtOtherBody").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() {
                            if ($("#hidrush").prop('checked')) {
                                $("#hidrushBody").val("Yes");
                            }
                            if (!$("#hidrush").prop('checked')) {
                                $("#hidrushBody").val("No");
                            }

                            if ($("#hidfs").prop('checked')) {
                                $("#hidfsBody").val("Yes");
                            }
                            if (!$("#hidfs").prop('checked')) {
                                $("#hidfsBody").val("No");
                            }

                            if ($("#hidpupupdate").prop('checked')) {
                                $("#hidpupupdateBody").val("Yes");
                            }
                            if (!$("#hidpupupdate").prop('checked')) {
                                $("#hidpupupdateBody").val("No");
                            }

                            if ($("#hidtpa").prop('checked')) {
                                $("#hidtpaBody").val("Yes");
                            }
                            if (!$("#hidtpa").prop('checked')) {
                                $("#hidtpaBody").val("No");
                            }

                            if ($("[name='hidcbt']")[0].checked) {
                                $("#hidcbtBody").val("Yes");
                            }
                            if (!$("[name='hidcbt']")[0].checked) {
                                $("#hidcbtBody").val("No");
                            }

                            if ($("[name='hidcbt']")[1].checked) {
                                $("#hidotherBody").val("Yes");
                            }
                            if (!$("[name='hidcbt']")[1].checked) {
                                $("#hidotherBody").val("No");
                            }
                        });
                    }
                    /*---------------------------------------------------Vision Research Request---------------------------------------------------*/
                    if ((document.URL).includes("vision-research-request")) {
                        $("#REASONHIDDEN1").parent().parent().css("display", "none");
                        $("#REASONHIDDEN2").parent().parent().css("display", "none");
                        $("#REASONHIDDEN3").parent().parent().css("display", "none");
                        $("#REASONHIDDEN4").parent().parent().css("display", "none");
                        $("#REASONHIDDEN5").parent().parent().css("display", "none");
                        $("#REASONHIDDEN6").parent().parent().css("display", "none");
                        $("#PHONEHIDDENBODY").parent().parent().css("display", "none");
                        $("#REMAININGHIDDENBODY").parent().parent().css("display", "none");
                        $("#ADDITIONALCOMMENTSHIDDENBODY").parent().parent().css("display", "none");

                        $(document).on("click", "[name='submit-btn']", function() {
                            var remainingbody;
                            if ($("#PHONEHIDDEN").val().length > 0) {
                                var phonebody = "<br/>PHONE #: " + $("#PHONEHIDDEN").val();
                                $("#PHONEHIDDENBODY").val(phonebody);
                            }
                            if ($("#DEALER").val().length > 0) {
                                remainingbody = "DEALER #: " + $("#DEALER").val() + "<br/>";

                            }
                            if ($("#BRANCH").val().length > 0) {
                                remainingbody += "BRANCH #: " + $("#BRANCH").val() + "<br/>";

                            }
                            if ($("#REPRESENTATIVE").val().length > 0) {
                                remainingbody += "REPRESENTATIVE #:" + $("#REPRESENTATIVE").val() + "<br/>";

                            }
                            if ($("#SAMPLEACCOUNT").val().length > 0) {
                                remainingbody += "SAMPLE ACCOUNT #" + $("#SAMPLEACCOUNT").val() + "<br/>";

                            }
                            if ($("#ADDITIONALCOMMENTSHIDDEN").val().length > 0) {
                                var additionalbody = "ADDITIONAL COMMENTS : " + "<br/>" + $("#ADDITIONALCOMMENTSHIDDEN").val();
                                $("#ADDITIONALCOMMENTSHIDDENBODY").val(additionalbody);
                            }
                            $("#REMAININGHIDDENBODY").val(remainingbody);
                        });



                        $('input[name="reasonforreferral"]').change(function() {
                            $('input[name="reasonforreferral"]').each(function() {
                                if ($("[name='reasonforreferral']")[5].checked) {
                                    $("#ADDITIONALCOMMENTSHIDDEN").prop("required", true);
                                    $("#REASONHIDDEN6").val("Y");
                                }
                                if (!$("[name='reasonforreferral']")[5].checked) {
                                    $("#ADDITIONALCOMMENTSHIDDEN").prop("required", false);
                                    $("#REASONHIDDEN6").val("N");
                                }
                                if ($("[name='reasonforreferral']")[0].checked) {
                                    $("#REASONHIDDEN1").val("Y");
                                }
                                if (!$("[name='reasonforreferral']")[0].checked) {
                                    $("#REASONHIDDEN1").val("N");
                                }
                                if ($("[name='reasonforreferral']")[1].checked) {
                                    $("#REASONHIDDEN2").val("Y");
                                }
                                if (!$("[name='reasonforreferral']")[1].checked) {
                                    $("#REASONHIDDEN2").val("N");
                                }
                                if ($("[name='reasonforreferral']")[2].checked) {
                                    $("#REASONHIDDEN3").val("Y");
                                }
                                if (!$("[name='reasonforreferral']")[2].checked) {
                                    $("#REASONHIDDEN3").val("N");
                                }
                                if ($("[name='reasonforreferral']")[3].checked) {
                                    $("#REASONHIDDEN4").val("Y");
                                }
                                if (!$("[name='reasonforreferral']")[3].checked) {
                                    $("#REASONHIDDEN4").val("N");
                                }
                                if ($("[name='reasonforreferral']")[4].checked) {
                                    $("#REASONHIDDEN5").val("Y");
                                }
                                if (!$("[name='reasonforreferral']")[4].checked) {
                                    $("#REASONHIDDEN5").val("N");
                                }

                            });
                        });

                    }


                    /*---------------------------------------------------Multiple Check Stop/Reissue Request for the Same Plan---------------------------------------------------*/
                    if ((document.URL).includes("multiple-check-stop-reissue-request-for-the-same-plan")) {

                        $('#site').removeAttr('maxlength');
                        $('#planName4').removeAttr('maxlength');
                        $("#PARTICIPANTBODY1").parent().parent().css("display", "none");
                        $("#PARTICIPANTBODY2").parent().parent().css("display", "none");
                        $("#PARTICIPANTBODY3").parent().parent().css("display", "none");
                        $("#PARTICIPANTBODY4").parent().parent().css("display", "none");
                        $("#PARTICIPANTBODY5").parent().parent().css("display", "none");
                        $("#PARTICIPANTBODY6").parent().parent().css("display", "none");
                        $("#PARTICIPANTBODY7").parent().parent().css("display", "none");
                        $("#PARTICIPANTBODY8").parent().parent().css("display", "none");
                        $("#PARTICIPANTBODY9").parent().parent().css("display", "none");
                        $("#PARTICIPANTBODY10").parent().parent().css("display", "none");

                        $(document).on("click", "[name='submit-btn']", function(e) {
                            var remainingbody = "1"
                            var flag = 0;
                            if ($("#pssn").val().trim().length > 0) {
                                remainingbody += "<br/>SSN: xxx-xx-" + $("#pssn").val().trim() + "<br/>";
                                flag += 1;
                            }
                            if ($("#lastName").val().trim().length > 0 || $("#firstName").val().trim().length > 0) {
                                remainingbody += "PARTIC NAME: ";
                                if ($("#firstName").val().length > 0) {
                                    remainingbody += $("#firstName").val().trim();
                                }
                                if ($("#lastName").val().length > 0) {
                                    remainingbody += " " + $("#lastName").val().trim();
                                }
                                remainingbody += "<br/>";
                                flag += 1
                            }
                            if ($("#checkNum").val().trim().length > 0) {
                                remainingbody += "CHECK #: " + $("#checkNum").val().trim() + "<br/>";
                                flag += 1
                            }
                            if ($("#amount").val().trim().length > 0) {
                                remainingbody += "AMOUNT: " + $("#amount").val().trim() + "<br/>";
                                flag += 1
                            }


                            var issueDate;
                            if ($("#issueDate").val().trim().length > 0) {
                                var dateVal = $("#issueDate").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                issueDate = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody += "ISSUE DATE: " + issueDate + "<br/>";
                                flag += 1
                            }

                            if ($("#stopOrVoid").val() != null) {
                                remainingbody += "STOP/VOID: " + $("#stopOrVoid").val() + "<br/>";
                                flag += 1
                            }
                            if ($("#reissueCheck").val() != null) {
                                remainingbody += "REISSUE?: " + $("#reissueCheck").val() + "<br/>";
                                flag += 1
                            }
                            if ($("#specialInstructions").val().trim().length > 0) {
                                remainingbody += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions").val().trim() + "<br/><br/><br/>";
                                flag += 1
                            }
                            if (flag > 0) {

                                if (flag == 8) {
                                    $("#PARTICIPANTBODY1").val(remainingbody);
                                } else {
                                    alert("- Participant and Check Information - Request # 1 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }



                            var remainingbody1 = "2"
                            var flag1 = 0;
                            if ($("#pssn1").val().trim().length > 0) {
                                remainingbody1 += "<br/>SSN: xxx-xx-" + $("#pssn1").val().trim() + "<br/>";
                                flag1 += 1;
                            }
                            if ($("#lastName1").val().trim().length > 0 || $("#firstName1").val().trim().length > 0) {
                                remainingbody1 += "PARTIC NAME: ";

                                if ($("#firstName1").val().length > 0) {
                                    remainingbody1 += $("#firstName1").val().trim();
                                }
                                if ($("#lastName1").val().length > 0) {
                                    remainingbody1 += " " + $("#lastName1").val().trim();
                                }
                                remainingbody1 += "<br/>";
                                flag1 += 1
                            }
                            if ($("#checkNum1").val().trim().length > 0) {
                                remainingbody1 += "CHECK #: " + $("#checkNum1").val().trim() + "<br/>";
                                flag1 += 1
                            }
                            if ($("#amount1").val().trim().length > 0) {
                                remainingbody1 += "AMOUNT: " + $("#amount1").val().trim() + "<br/>";
                                flag1 += 1
                            }

                            var issueDate1;
                            if ($("#issueDate1").val().trim().length > 0) {
                                var dateVal = $("#issueDate1").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                issueDate1 = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody1 += "ISSUE DATE: " + issueDate1 + "<br/>";
                                flag1 += 1
                            }


                            if ($("#stopOrVoid1").val() != null) {
                                remainingbody1 += "STOP/VOID: " + $("#stopOrVoid1").val() + "<br/>";
                                flag1 += 1
                            }
                            if ($("#reissueCheck1").val() != null) {
                                remainingbody1 += "REISSUE?: " + $("#reissueCheck1").val() + "<br/>";
                                flag1 += 1
                            }
                            if ($("#specialInstructions1").val().trim().length > 0) {
                                remainingbody1 += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions1").val().trim() + "<br/><br/><br/>";
                                flag1 += 1
                            }
                            if (flag1 > 0) {

                                if (flag1 == 8) {
                                    $("#PARTICIPANTBODY2").val(remainingbody1);
                                } else {
                                    alert("- Participant and Check Information - Request # 2 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }

                            var remainingbody2 = "3"
                            var flag2 = 0;
                            if ($("#pssn2").val().trim().length > 0) {
                                remainingbody2 += "<br/>SSN: xxx-xx-" + $("#pssn2").val().trim() + "<br/>";
                                flag2 += 1;
                            }
                            if ($("#lastName2").val().trim().length > 0 || $("#firstName2").val().trim().length > 0) {
                                remainingbody2 += "PARTIC NAME: ";
                                if ($("#firstName2").val().length > 0) {
                                    remainingbody2 += $("#firstName2").val().trim();
                                }
                                if ($("#lastName2").val().length > 0) {
                                    remainingbody2 += " " + $("#lastName2").val().trim();
                                }
                                remainingbody2 += "<br/>";
                                flag2 += 1
                            }
                            if ($("#checkNum2").val().trim().length > 0) {
                                remainingbody2 += "CHECK #: " + $("#checkNum2").val().trim() + "<br/>";
                                flag2 += 1
                            }
                            if ($("#amount2").val().trim().length > 0) {
                                remainingbody2 += "AMOUNT: " + $("#amount2").val().trim() + "<br/>";
                                flag2 += 1
                            }
                            if ($("#issueDate2").val().trim().length > 0) {
                                var dateVal = $("#issueDate2").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                var issueDate2 = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody2 += "ISSUE DATE: " + issueDate2 + "<br/>";
                                flag2 += 1
                            }

                            if ($("#stopOrVoid2").val() != null) {
                                remainingbody2 += "STOP/VOID: " + $("#stopOrVoid2").val() + "<br/>";
                                flag2 += 1
                            }
                            if ($("#reissueCheck2").val() != null) {
                                remainingbody2 += "REISSUE?: " + $("#reissueCheck2").val() + "<br/>";
                                flag2 += 1
                            }
                            if ($("#specialInstructions2").val().trim().length > 0) {
                                remainingbody2 += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions2").val().trim() + "<br/><br/><br/>";
                                flag2 += 1
                            }
                            if (flag2 > 0) {

                                if (flag2 == 8) {
                                    $("#PARTICIPANTBODY3").val(remainingbody2);
                                } else {
                                    alert("- Participant and Check Information - Request # 3 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }

                            var remainingbody3 = "4"
                            var flag3 = 0;
                            if ($("#pssn3").val().trim().length > 0) {
                                remainingbody3 += "<br/>SSN: xxx-xx-" + $("#pssn3").val().trim() + "<br/>";
                                flag3 += 1;
                            }
                            if ($("#lastName3").val().trim().length > 0 || $("#firstName3").val().trim().length > 0) {
                                remainingbody3 += "PARTIC NAME: ";

                                if ($("#firstName3").val().length > 0) {
                                    remainingbody3 += $("#firstName3").val().trim();
                                }
                                if ($("#lastName3").val().length > 0) {
                                    remainingbody3 += " " + $("#lastName3").val().trim();
                                }
                                remainingbody3 += "<br/>";
                                flag3 += 1
                            }
                            if ($("#checkNum3").val().trim().length > 0) {
                                remainingbody3 += "CHECK #: " + $("#checkNum3").val().trim() + "<br/>";
                                flag3 += 1
                            }
                            if ($("#amount3").val().trim().length > 0) {
                                remainingbody3 += "AMOUNT: " + $("#amount3").val().trim() + "<br/>";
                                flag3 += 1
                            }
                            if ($("#issueDate3").val().trim().length > 0) {
                                var dateVal = $("#issueDate3").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                var issueDateFin = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody3 += "ISSUE DATE: " + issueDateFin + "<br/>";
                                flag3 += 1
                            }

                            if ($("#stopOrVoid3").val() != null) {
                                remainingbody3 += "STOP/VOID: " + $("#stopOrVoid3").val() + "<br/>";
                                flag3 += 1
                            }
                            if ($("#reissueCheck3").val() != null) {
                                remainingbody3 += "REISSUE?: " + $("#reissueCheck3").val() + "<br/>";
                                flag3 += 1
                            }
                            if ($("#specialInstructions3").val().trim().length > 0) {
                                remainingbody3 += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions3").val().trim() + "<br/><br/><br/>";
                                flag3 += 1
                            }
                            if (flag3 > 0) {

                                if (flag3 == 8) {
                                    $("#PARTICIPANTBODY4").val(remainingbody3);
                                } else {
                                    alert("- Participant and Check Information - Request # 4 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }

                            var remainingbody4 = "5"
                            var flag4 = 0;
                            if ($("#pssn4").val().trim().length > 0) {
                                remainingbody4 += "<br/>SSN: xxx-xx-" + $("#pssn4").val().trim() + "<br/>";
                                flag4 += 1;
                            }
                            if ($("#lastName4").val().trim().length > 0 || $("#firstName4").val().trim().length > 0) {
                                remainingbody4 += "PARTIC NAME: ";

                                if ($("#firstName4").val().length > 0) {
                                    remainingbody4 += $("#firstName4").val().trim();
                                }
                                if ($("#lastName4").val().length > 0) {
                                    remainingbody4 += " " + $("#lastName4").val().trim();
                                }
                                remainingbody4 += "<br/>";
                                flag4 += 1
                            }
                            if ($("#checkNum4").val().trim().length > 0) {
                                remainingbody4 += "CHECK #: " + $("#checkNum4").val().trim() + "<br/>";
                                flag4 += 1
                            }
                            if ($("#amount4").val().trim().length > 0) {
                                remainingbody4 += "AMOUNT: " + $("#amount4").val().trim() + "<br/>";
                                flag4 += 1
                            }
                            if ($("#issueDate4").val().trim().length > 0) {
                                var dateVal = $("#issueDate4").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                var issueDateFin = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody4 += "ISSUE DATE: " + issueDateFin + "<br/>";
                                flag4 += 1
                            }


                            if ($("#stopOrVoid4").val() != null) {
                                remainingbody4 += "STOP/VOID: " + $("#stopOrVoid4").val() + "<br/>";
                                flag4 += 1
                            }
                            if ($("#reissueCheck4").val() != null) {
                                remainingbody4 += "REISSUE?: " + $("#reissueCheck4").val() + "<br/>";
                                flag4 += 1
                            }
                            if ($("#specialInstructions4").val().trim().length > 0) {
                                remainingbody4 += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions4").val().trim() + "<br/><br/><br/>";
                                flag4 += 1
                            }
                            if (flag4 > 0) {

                                if (flag4 == 8) {
                                    $("#PARTICIPANTBODY5").val(remainingbody4);
                                } else {
                                    alert("- Participant and Check Information - Request # 5 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }

                            var remainingbody5 = "6"
                            var flag5 = 0;
                            if ($("#pssn5").val().trim().length > 0) {
                                remainingbody5 += "<br/>SSN: xxx-xx-" + $("#pssn5").val().trim() + "<br/>";
                                flag5 += 1;
                            }
                            if ($("#lastName5").val().trim().length > 0 || $("#firstName5").val().trim().length > 0) {
                                remainingbody5 += "PARTIC NAME: ";

                                if ($("#firstName5").val().length > 0) {
                                    remainingbody5 += $("#firstName5").val().trim();
                                }
                                if ($("#lastName5").val().length > 0) {
                                    remainingbody5 += " " + $("#lastName5").val().trim();
                                }
                                remainingbody5 += "<br/>";
                                flag5 += 1
                            }
                            if ($("#checkNum5").val().trim().length > 0) {
                                remainingbody5 += "CHECK #: " + $("#checkNum5").val().trim() + "<br/>";
                                flag5 += 1
                            }
                            if ($("#amount5").val().trim().length > 0) {
                                remainingbody5 += "AMOUNT: " + $("#amount5").val().trim() + "<br/>";
                                flag5 += 1
                            }
                            if ($("#issueDate5").val().trim().length > 0) {
                                var dateVal = $("#issueDate5").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                var issueDateFin = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody5 += "ISSUE DATE: " + issueDateFin + "<br/>";
                                flag5 += 1
                            }

                            if ($("#stopOrVoid5").val() != null) {
                                remainingbody5 += "STOP/VOID: " + $("#stopOrVoid5").val() + "<br/>";
                                flag5 += 1
                            }
                            if ($("#reissueCheck5").val() != null) {
                                remainingbody5 += "REISSUE?: " + $("#reissueCheck5").val() + "<br/>";
                                flag5 += 1
                            }
                            if ($("#specialInstructions5").val().trim().length > 0) {
                                remainingbody5 += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions5").val().trim() + "<br/><br/><br/>";
                                flag5 += 1
                            }
                            if (flag5 > 0) {

                                if (flag5 == 8) {
                                    $("#PARTICIPANTBODY6").val(remainingbody5);
                                } else {
                                    alert("- Participant and Check Information - Request # 6 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }

                            var remainingbody6 = "7"
                            var flag6 = 0;
                            if ($("#pssn6").val().trim().length > 0) {
                                remainingbody6 += "<br/>SSN: xxx-xx-" + $("#pssn6").val().trim() + "<br/>";
                                flag6 += 1;
                            }
                            if ($("#lastName6").val().trim().length > 0 || $("#firstName6").val().trim().length > 0) {
                                remainingbody6 += "PARTIC NAME: ";

                                if ($("#firstName6").val().length > 0) {
                                    remainingbody6 += $("#firstName6").val().trim();
                                }
                                if ($("#lastName6").val().length > 0) {
                                    remainingbody6 += " " + $("#lastName6").val().trim();
                                }
                                remainingbody6 += "<br/>";
                                flag6 += 1
                            }
                            if ($("#checkNum6").val().trim().length > 0) {
                                remainingbody6 += "CHECK #: " + $("#checkNum6").val().trim() + "<br/>";
                                flag6 += 1
                            }
                            if ($("#amount6").val().trim().length > 0) {
                                remainingbody6 += "AMOUNT: " + $("#amount6").val().trim() + "<br/>";
                                flag6 += 1
                            }
                            if ($("#issueDate6").val().trim().length > 0) {
                                var dateVal = $("#issueDate6").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                var issueDateFin = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody6 += "ISSUE DATE: " + issueDateFin + "<br/>";
                                flag6 += 1
                            }


                            if ($("#stopOrVoid6").val() != null) {
                                remainingbody6 += "STOP/VOID: " + $("#stopOrVoid6").val() + "<br/>";
                                flag6 += 1
                            }
                            if ($("#reissueCheck6").val() != null) {
                                remainingbody6 += "REISSUE?: " + $("#reissueCheck6").val() + "<br/>";
                                flag6 += 1
                            }
                            if ($("#specialInstructions6").val().trim().length > 0) {
                                remainingbody6 += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions6").val().trim() + "<br/><br/><br/>";
                                flag6 += 1
                            }
                            if (flag6 > 0) {

                                if (flag6 == 8) {
                                    $("#PARTICIPANTBODY7").val(remainingbody6);
                                } else {
                                    alert("- Participant and Check Information - Request # 7 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }

                            var remainingbody7 = "8"
                            var flag7 = 0;
                            if ($("#pssn7").val().trim().length > 0) {
                                remainingbody7 += "<br/>SSN: xxx-xx-" + $("#pssn7").val().trim() + "<br/>";
                                flag7 += 1;
                            }
                            if ($("#lastName7").val().trim().length > 0 || $("#firstName7").val().trim().length > 0) {
                                remainingbody7 += "PARTIC NAME: ";

                                if ($("#firstName7").val().length > 0) {
                                    remainingbody7 += $("#firstName7").val().trim();
                                }
                                if ($("#lastName7").val().length > 0) {
                                    remainingbody7 += " " + $("#lastName7").val().trim();
                                }
                                remainingbody7 += "<br/>";
                                flag7 += 1
                            }
                            if ($("#checkNum7").val().trim().length > 0) {
                                remainingbody7 += "CHECK #: " + $("#checkNum7").val().trim() + "<br/>";
                                flag7 += 1
                            }
                            if ($("#amount7").val().trim().length > 0) {
                                remainingbody7 += "AMOUNT: " + $("#amount7").val().trim() + "<br/>";
                                flag7 += 1
                            }
                            if ($("#issueDate7").val().trim().length > 0) {
                                var dateVal = $("#issueDate7").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                var issueDateFin = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody7 += "ISSUE DATE: " + issueDateFin + "<br/>";
                                flag7 += 1
                            }

                            if ($("#stopOrVoid7").val() != null) {
                                remainingbody7 += "STOP/VOID: " + $("#stopOrVoid7").val() + "<br/>";
                                flag7 += 1
                            }
                            if ($("#reissueCheck7").val() != null) {
                                remainingbody7 += "REISSUE?: " + $("#reissueCheck6").val() + "<br/>";
                                flag7 += 1
                            }
                            if ($("#specialInstructions7").val().trim().length > 0) {
                                remainingbody7 += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions7").val().trim() + "<br/><br/><br/>";
                                flag7 += 1
                            }
                            if (flag7 > 0) {

                                if (flag7 == 8) {
                                    $("#PARTICIPANTBODY8").val(remainingbody7);
                                } else {
                                    alert("- Participant and Check Information - Request # 8 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }

                            var remainingbody8 = "9"
                            var flag8 = 0;
                            if ($("#pssn8").val().trim().length > 0) {
                                remainingbody8 += "<br/>SSN: xxx-xx-" + $("#pssn8").val().trim() + "<br/>";
                                flag8 += 1;
                            }
                            if ($("#lastName8").val().trim().length > 0 || $("#firstName8").val().trim().length > 0) {
                                remainingbody8 += "PARTIC NAME: ";

                                if ($("#firstName8").val().length > 0) {
                                    remainingbody8 += $("#firstName8").val().trim();
                                }
                                if ($("#lastName8").val().length > 0) {
                                    remainingbody8 += " " + $("#lastName8").val().trim();
                                }
                                remainingbody8 += "<br/>";
                                flag8 += 1
                            }
                            if ($("#checkNum8").val().trim().length > 0) {
                                remainingbody8 += "CHECK #: " + $("#checkNum8").val().trim() + "<br/>";
                                flag8 += 1
                            }
                            if ($("#amount8").val().trim().length > 0) {
                                remainingbody8 += "AMOUNT: " + $("#amount8").val().trim() + "<br/>";
                                flag8 += 1
                            }
                            if ($("#issueDate8").val().trim().length > 0) {
                                var dateVal = $("#issueDate8").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                var issueDateFin = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody8 += "ISSUE DATE: " + issueDateFin + "<br/>";
                                flag8 += 1
                            }


                            if ($("#stopOrVoid8").val() != null) {
                                remainingbody8 += "STOP/VOID: " + $("#stopOrVoid8").val() + "<br/>";
                                flag8 += 1
                            }
                            if ($("#reissueCheck8").val() != null) {
                                remainingbody8 += "REISSUE?: " + $("#reissueCheck8").val() + "<br/>";
                                flag8 += 1
                            }
                            if ($("#specialInstructions8").val().trim().length > 0) {
                                remainingbody8 += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions8").val().trim() + "<br/><br/><br/>";
                                flag8 += 1
                            }
                            if (flag8 > 0) {

                                if (flag8 == 8) {
                                    $("#PARTICIPANTBODY9").val(remainingbody8);
                                } else {
                                    alert("- Participant and Check Information - Request # 9 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }

                            var remainingbody9 = "10"
                            var flag9 = 0;
                            if ($("#pssn9").val().trim().length > 0) {
                                remainingbody9 += "<br/>SSN: xxx-xx-" + $("#pssn9").val().trim() + "<br/>";
                                flag9 += 1;
                            }
                            if ($("#lastName9").val().trim().length > 0 || $("#firstName9").val().trim().length > 0) {
                                remainingbody9 += "PARTIC NAME: ";

                                if ($("#firstName9").val().length > 0) {
                                    remainingbody9 += $("#firstName9").val().trim();
                                }
                                if ($("#lastName9").val().length > 0) {
                                    remainingbody9 += " " + $("#lastName9").val().trim();
                                }
                                remainingbody9 += "<br/>";
                                flag9 += 1
                            }
                            if ($("#checkNum9").val().trim().length > 0) {
                                remainingbody9 += "CHECK #: " + $("#checkNum9").val().trim() + "<br/>";
                                flag9 += 1
                            }
                            if ($("#amount9").val().trim().length > 0) {
                                remainingbody9 += "AMOUNT: " + $("#amount9").val().trim() + "<br/>";
                                flag9 += 1
                            }
                            if ($("#issueDate9").val().trim().length > 0) {
                                var dateVal = $("#issueDate9").val().trim();
                                var dateConversionArray = dateVal.split("-");
                                var issueDateFin = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                remainingbody9 += "ISSUE DATE: " + issueDateFin + "<br/>";
                                flag9 += 1
                            }


                            if ($("#stopOrVoid9").val() != null) {
                                remainingbody9 += "STOP/VOID: " + $("#stopOrVoid9").val() + "<br/>";
                                flag9 += 1
                            }
                            if ($("#reissueCheck9").val() != null) {
                                remainingbody9 += "REISSUE?: " + $("#reissueCheck9").val() + "<br/>";
                                flag9 += 1
                            }
                            if ($("#specialInstructions9").val().trim().length > 0) {
                                remainingbody9 += "SPECIAL INSTRUCTIONS: " + $("#specialInstructions9").val().trim() + "<br/><br/><br/>";
                                flag9 += 1
                            }
                            if (flag9 > 0) {

                                if (flag9 == 8) {
                                    $("#PARTICIPANTBODY10").val(remainingbody9);
                                } else {
                                    alert("- Participant and Check Information - Request # 10 is incomplete");
                                    (e).preventDefault;
                                    return false;
                                }
                            }

                            if (flag != 8 && flag1 != 8 && flag2 != 8 && flag3 != 8 && flag4 != 8 && flag5 != 8 && flag6 != 8 && flag7 != 8 && flag8 != 8 && flag9 != 8) {

                                alert("At least one Participant and Check Information section must be complete");
                                (e).preventDefault;
                                return false;

                            }


                        });
                    }

                    /*---------------------------------------------------NON-CRITICAL SYSTEM ISSUES SUBMISSION---------------------------------------------------*/
                    if ((document.URL).includes("non-critical-system-issues-submission")) {
                        $("#SYSTEMHIDDEN").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() {
                            var arr = new Array();
                            for (var i = 0; i < 5; ++i) {
                                if ($("[name='systems']")[i].checked) {
                                    if ($("[name='systems']")[i].value != undefined) {
                                        arr.push($("[name='systems']")[i].value);
                                    }
                                }
                            }
                            var impactedSystem = arr.join(", ");
                            $("#SYSTEMHIDDEN").val(impactedSystem);
                            var subjectLine = "BSR System Issue - " + $("#SITE").val() + " - " + impactedSystem + " " + $("#WORKTYPE").val()
                            $("#mailSubject").val(subjectLine);
							
							if($("#DEPARTMENT").val() == "CB&T"){
								var emailID=$("#qualifierAddr1").val();
								$("#emailAddr").val(emailID);								
							}
							else if($("#DEPARTMENT").val() == "AFS"){
								var emailID=$("#qualifierAddr").val();
								$("#emailAddr").val(emailID);
							}
                        });
                    }


              /*------------------------------------------IC followup needed-----------------------------*/
					if ((document.URL).includes("ic-follow-up-needed")) 
					{
                        $("#blackoutdatehidden").parent().parent().css("display", "none");
                         $("#icHiddenCheckbox").parent().parent().css("display", "none");
                        var blackdate;
                        var icCheckArray= new Array(0);

                        $(document).on("click", "[name='submit-btn']", function() {

                            if ($("[name='ICCheck']")[0].checked) 
                            {
								icCheckArray.push($("[name='ICCheck']")[0].value.trim());

                            }
                             if ($("[name='ICCheck']")[1].checked) 
                            {
								icCheckArray.push($("[name='ICCheck']")[1].value.trim());

                            }

                             if ($("[name='ICCheck']")[2].checked) 
                            {
								icCheckArray.push($("[name='ICCheck']")[2].value.trim());

                            }

                             if ($("[name='ICCheck']")[3].checked) 
                            {
								icCheckArray.push($("[name='ICCheck']")[3].value.trim());

                            }

                             if ($("[name='ICCheck']")[4].checked) 
                            {
								icCheckArray.push($("[name='ICCheck']")[4].value.trim());

                            }

                            var icFinalValue= icCheckArray.join("<br/><br/>");
                            $("#icHiddenCheckbox").val(icFinalValue);


							function browserSupportsDateInputMethod3() {
                            var i = document.createElement("input");
                            i.setAttribute("type", "date");
                            return i.type !== "text";
							}
							if ($("#blackoutdate").val()!=undefined) {
								var finDate;
								if (browserSupportsDateInputMethod3()) 
								{
									var dateVal = $('#blackoutdate').val();
									var dateConversionArray = dateVal.split("-");
									finDate = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
								}
								else{
									finDate=$('#blackoutdate').val();
								}
								if(finDate==='undefined/undefined/')
								{
									blackdate="";
								}
								else
								{
									blackdate = "Blackout end date : " + finDate + "<br/><br/>";
								}
								$("#blackoutdatehidden").val(blackdate)
							} 
							else {
								$("#blackoutdatehidden").val("");
							}
						
                        });
                    }
					/*--------------------------------------------Associate Suggestion Form------------------------------------------------*/

					if ((document.URL).includes("associate-suggestion-form")) {

                        $("#initialsHidden").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() 
                        {
							var impactedSystem= new Array(0);
                            if ($("[name='allImpactedSystems']")[0].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[0].value);

                            }
                            if ($("[name='allImpactedSystems']")[1].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[1].value);

                            }
                            if ($("[name='allImpactedSystems']")[2].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[2].value);

                            }
                            if ($("[name='allImpactedSystems']")[3].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[3].value);

                            }
                            if ($("[name='allImpactedSystems']")[4].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[4].value);

                            }
                            if ($("[name='allImpactedSystems']")[5].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[5].value);

                            }
                            if ($("[name='allImpactedSystems']")[6].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[6].value);

                            }
                            if ($("[name='allImpactedSystems']")[7].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[7].value);

                            }
                            if ($("[name='allImpactedSystems']")[8].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[8].value);

                            }
                            if ($("[name='allImpactedSystems']")[9].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[9].value);

                            }
                            if ($("[name='allImpactedSystems']")[10].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[10].value);

                            }
                            if ($("[name='allImpactedSystems']")[11].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[11].value);

                            }
                            if ($("[name='allImpactedSystems']")[12].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[12].value);

                            }

                            var impactedSystemForm=impactedSystem.join(", ");
                            $("#initialsHidden").val(impactedSystemForm);


                        });
                    }
                    /*----------------------------------------------------------Bank Wire-------------------------------------------------*/

                    if ((document.URL).includes("bank-wire-investment-instructions")) {

                        $(document).on("click", "[name='submit-btn']", function() {

                            var accountNumbers = new Array();
                            var subjectLine = "Bank Wire Instructions - "
                            $("[name='account']").each(function() {
                                if (jQuery.inArray($(this).val(), accountNumbers) == -1) {
                                    accountNumbers.push(Number($(this).val()));

                                }
                            });
                            var uniqueAccountNumbers = new Array();
                            var numberOfAccounts = accountNumbers.length;

                            for (var i = 0; i < numberOfAccounts; i++) {
                                for (var j = i + 1; j < numberOfAccounts; j++)
                                    if (accountNumbers[i] === accountNumbers[j]) {
                                        j = ++i;
                                    }
                                uniqueAccountNumbers.push(accountNumbers[i]);
                            }

                            uniqueAccountNumbers = uniqueAccountNumbers.sort(sortNumber);
                            for (var i = 1; i < uniqueAccountNumbers.length; ++i) {
                                if (i == 1) {
                                    subjectLine += (uniqueAccountNumbers[i]);
                                } else {
                                    subjectLine += ", " + (uniqueAccountNumbers[i]);
                                }
                            }

                            function sortNumber(a, b) {
                                return a - b;
                            }

                            $("#mailSubject").val(subjectLine);
                        });

                    }
                    /*---------------------------------------fee disclosure mail----------------------------------------------------------------*/

                    if ((document.URL).includes("fee-disclosure-mailing")) {
						$(document).on("click", "[name='submit-btn']", function(e) {

if ($("#PLANID").val() == "" && $("#PARTICIPANTACC").val() == "")
{

alert('Please complete PLAN ID or PARTICIPANT A/C #');

e.preventDefault();
}
});
                        $("#extHidden").parent().parent().css("display", "none");
						$("#particAccHidden").parent().parent().css("display", "none");
						$("#socialCodeHidden").parent().parent().css("display", "none");
						$("#planHidden").parent().parent().css("display", "none");
						
                        $("#emailBodyStartHidden").parent().parent().css("display", "none");
                        $("#emailStartHidden").parent().parent().css("display", "none");
                        $("#emailBodyStartHidden").val(" Once the appropriate action is taken (lead/mailing account is established / address is updated / social code is corrected), please note the account including the Upend 978 which states the mailing was completed.");
                        $("#emailStartHidden").val("If return mail is in progress, please contact the associate working the return mail to inform them the item has been resolved.");

                        $(document).on("click", "[name='submit-btn']", function() {
                            var subjectLine = "408(b)(2) Fee Disclosure Mailing - ";
                            var site = $("#SITE").val();
                            var subjectLine = subjectLine + site + " - ";
                            if ($("#PLANID").val().length > 0) {
                                subjectLine += $("#PLANID").val();
                            }
                            if (($("#PLANID").val().length > 0) && ($("#PARTICIPANTACC").val().length > 0)) {
                                subjectLine += ", " + $("#PARTICIPANTACC").val();
                            }
                            if (($("#PLANID").val().length == 0) && ($("#PARTICIPANTACC").val().length > 0)) {
                                subjectLine += $("#PARTICIPANTACC").val();
                            }
                            $("#mailSubject").val(subjectLine);
							
							if ($("#EXTVALUE").val().length > 0) {
                                var extBody = "<br/>EXT: " + $("#EXTVALUE").val();
                                $("#extHidden").val(extBody);
                            }
                            if ($("#PARTICIPANTACC").val().length > 0) {
                                var particBody = "<br/><br/>PARTICIPANT A/C #: " + $("#PARTICIPANTACC").val();
                                $("#particAccHidden").val(particBody);
                            }
                            if ($("#CURRENTSOCIALCODE").val().length > 0) {
                                var socialBody = "<br/>CURRENT SOCIAL CODE (Participant A/C): " + $("#CURRENTSOCIALCODE").val();
                                $("#socialCodeHidden").val(socialBody);
                            }
							if ($("#PLANID").val().length > 0) {
                                var planBody = "<br/><br/>PLAN ID: " + $("#PLANID").val();
                                $("#planHidden").val(planBody);
                            }

                        });
                    }
					
					/*--------------------------------------------Empower techinal issues Form------------------------------------------------*/

					if ((document.URL).includes("empower-technical-issues-report")) {
                        $("#impactedHidden").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() 
                        {
							var allImpactedBrowser= new Array(0);
                            if ($("[name='allImpactedBrowser']")[0].checked) 
                            {
								allImpactedBrowser.push($("[name='allImpactedBrowser']")[0].value.trim());

                            }
                            if ($("[name='allImpactedBrowser']")[1].checked) 
                            {
								allImpactedBrowser.push($("[name='allImpactedBrowser']")[1].value.trim());

                            }
                            if ($("[name='allImpactedBrowser']")[2].checked) 
                            {
								allImpactedBrowser.push($("[name='allImpactedBrowser']")[2].value.trim());

                            }
                          
                            var allImpactedBrowserForm=allImpactedBrowser.join(",");
                            $("#impactedHidden").val(allImpactedBrowserForm);

                        });
                    }

                    /*-----------------------------------------------RKD Phone message-------------------------------------------*/

                    if ((document.URL).includes("rkd-phone-message-form")) {
                        $("#tnoteBody").parent().parent().css("display", "none");

                        $("#tnoteBody1").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() {

                            if ($("[name='tnote']")[0].checked) {
                                $("#tnoteBody").val("Yes");
                            }
                            if (!$("[name='tnote']")[0].checked) {
                                $("#tnoteBody").val("No");
                            }

                            if ($("[name='tnote']")[1].checked) {
                                $("#tnoteBody1").val("Yes");
                            }
                            if (!$("[name='tnote']")[1].checked) {
                                $("#tnoteBody1").val("No");
                            }
                            var icrushval = "";
                            var subjectLine = "";
                            if ($('input[name="workFlowRush"]:checked')) {
                                icrushval = "** RUSH ** ";
                            }
                            var workflow = $('input[name="thismessage"]:checked').val();

                            if (workflow == "normal") {
                                subjectLine = "RKD Phone Message form - [" + $("#recipinits").val() + "] RE: " + $("#planid-4").val() + " - " + $("#planname").val() + " - " + $("#callType").val();
                            } else if (workflow == "Workflow") {
                                subjectLine = icrushval + "RKD Phone Message form **ROUTED TO WORKFLOW** RE: " + $("#planid-4").val() + " - " + $("#planname").val() + " - " + $("#callType").val();
                            } else if (workflow == "websme") {
                                subjectLine = "RKD Phone Message From  (IC TO Client Services) RE: " + $("#planid-4").val() + " - " + $("#planname").val() + " Regular.Work.Active Plan Call Backs."
                            } else {
                                subjectLine = "PPTPA Phone Message From  (IC TO RPSS) RE: " + $("#planid-4").val() + " - " + $("#planname").val();
                            }


                            $("#mailSubject").val(subjectLine);

                        });
                    }
					
					/*---------------------------------------------------IMPLEMENTATION PROCESSING COMPLETE NOTIFICATION---------------------------------------------------*/
                    if ((document.URL).includes("implementation-processing-complete-notification")) 
					{                     
                        $(document).on("click", "[name='submit-btn']", function() {						
							if($("input[name=identifier]:checked").val() == "regular.work.installation."){
								var emailID=$("#qualifierAddr1").val();
								$("#emailAddr").val(emailID);								
							}
							else if($("input[name=identifier]:checked").val() == "regular.work.follow up."){
								var emailID=$("#qualifierAddr").val();
								$("#emailAddr").val(emailID);
							}
							
						});
					}

                    /*-------------------------------------------------FD-Multifund-rpe-notification-future-date-request-form----------------------------------*/

                  if ((document.URL).includes("fd-multifund-rpe-notification-future-date-request-form")) {

                        $("#lineDetails").parent().parent().css("display", "none");

                $("#subdate").parent().parent().css("display", "none");

                        $(document).on("click", "[name='submit-btn']", function() {
                            var subjectLine = "";
                            var nonfut = "NON_FUT";
                            var fut = "FUT";
                            var loanType = "";
                            var workType = $("select[id=reqtype] option:selected").val();
                            if (workType == "Money Type Change") {
                                subjectLine = "Money Type Change (MULTIFUND) - " + $("#plaNid5").val() + " - " + $("#planname").val();
                            } else if (workType == "Printed Fee Disclosure Order") {
                                subjectLine = "Fee Disclosure Booklet Order (MULTIFUND) - " + $("#plaNid5").val() + " - " + $("#planname").val();
                            } else if (workType == "Vesting Schedule Change") {
                                subjectLine = "Vesting Schedule Change (MULTIFUND) - " + $("#plaNid5").val() + " - " + $("#planname").val();
                            } else if (workType == "Investment Option Add - No Mapping") {
                                subjectLine = "Investment Option Add, No Mapping (MULTIFUND) - " + $("#plaNid5").val() + " - " + $("#planname").val();
                            } else if (workType == "Investment Option Remove - No Mapping") {
                                subjectLine = "Investment Option Remove, No Mapping (MULTIFUND) - " + $("#plaNid5").val() + " - " + $("#planname").val();
                            } else if (workType == "Investment Option Change - Mapping - Unit Class Change") {
                                subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form - " + $("#plaNid5").val() + " - " + $("#planname").val() + " (Investment Option Change, Mapping - Unit Class Change (MULTIFUND))";
                            } else if (workType == "Investment Option Change - Mapping - Inv Opt Replacement") {
                                subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form - " + $("#plaNid5").val() + " - " + $("#planname").val() + " (Investment Option Change, Mapping - Investment Option Replacement (MULTIFUND))";
                            } else if (workType == "Default Investment Option Change - No Mapping") {
                                subjectLine = setDate($("#effdate").val()) + " - Future Date Processing Request Form - " + $("#plaNid5").val() + " - " + $("#planname").val() + " (Default Investment Option Change, No Mapping (MULTIFUND))";
                            } else if (workType == "Loan Provision Add / Remove") {
                                if ($('input[name="loanType"]:checked')) {
                                    loanType = "Add Loans";
                                } else {
                                    loanType = "Remove Loans";
                                }
                                var fdp = "";
                                var today = new Date();
                                var time = today.getTime();
                                var effDate = $("#effdate").val();
                                var dateArray = effDate.split("/");
                                var theMonth = parseFloat(dateArray[0]);
                                theMonth -= 1;
                                var day = parseFloat(dateArray[1]);
                                var year = parseFloat(dateArray[2]);
                                year += 2000;
                                var effObj = new Date(year, theMonth, date);
                                var effTime = effObj.getTime();
                                if (time < effTime) {
                                    fdp = " - Future Date Processing Request Form";
                                }

                                subjectLine = $("#effdate").val() + " - Loan Provision Add / Remove (MULTIFUND) - " + $("#plaNid5").val() + " - " + $("#planname").val();
                            } else if (workType == "Other") {
                                subjectLine = "**Other** RPE Notification Request (MULTIFUND) - " + +$("#plaNid5").val() + " - " + $("#planname").val();
                            }
                            $("#mailSubject").val(subjectLine);


                    var liketolike = "";
					
					if($("input[name=liketolike]:checked").val() == null) {

                                   liketolike  = "";
                    }
                     else if($("input[name=liketolike]:checked").val() == "Like-to-Like Investment Option") {
                        liketolike = "Yes";
                    } else {

                        liketolike = "No";
                    }
                    $("#liketolike").val(liketolike);
                    var lineDetails = " ";

					var to = " ";
					 for (var i = 1; i <= 29; i++) {

                        var fromid = $("select[id=from] option:selected").val();
                         var toid = $("select[id=to] option:selected").val();

                        if (fromid == "" && toid == "") {
                            lineDetails += "LINE " + i + ": - <br/>";
                        } 

                         else if(i === 1){


                                var fromid1 = $("select[id=from] option:selected").val();
                         var toid1 = $("select[id=to] option:selected").val();
						 
						 if(fromid1 = "" && toid1 == "" || fromid1 == undefined || toid1 == undefined) {
    							to = "";
                             } else {
										to = fromid1 +" - "+ toid1 ;
										to = fromid +" - "+ toid ;
										
										}
                         lineDetails += "LINE " + i + ": - " + to + "<br/>";

                            }else {

                             var fromid = $("select[id=from"+i+"] option:selected").val();
                         var toid = $("select[id=to"+i+"] option:selected").val();

							
							if(( fromid == null) || ( toid == null) || ( fromid == undefined) || ( toid == undefined) ) {
                    to = " ";
                                lineDetails += "LINE " + i + ": - " + to + "<br/>";
                            }else{ 



                        to = fromid +" - "+ toid ;
                         lineDetails += "LINE " + i + ": - " + to + "<br/>";


                        }
                        }
						
						
                    }
                            
                    $("#lineDetails").val(lineDetails);

           var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var year = today.getFullYear().toString().substr(-2);
today = mm + '/' + dd + '/' + year;

$("#subdate").val(today);

                    function setDate(val) {



var dateVal = val;
var today = new Date(dateVal);
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
today = mm + '/' + dd + '/' + yyyy;
                              return today;



                            }
                        });
                    }

/*---------------------------------RPS ANNOUNCEMENT COMMUNICATION REQUEST FORM-----------------------------------------------------------------*/

/*---------------------------------RPS ANNOUNCEMENT COMMUNICATION REQUEST FORM-----------------------------------------------------------------*/

    if ((document.URL).includes("rps-announcement-communication-request-form")) {

        $("#impactedHidden").parent().parent().css("display", "none");
		$("#otherHidden").parent().parent().css("display", "none");
        $("#customAnnouncementDetails").parent().parent().css("display", "none");
        $("#customSiteSectionHidden").parent().parent().css("display", "none");


        $(document).on("click", "[name='submit-btn']", function() {
            
           var communication = new Array(0);
            if ($("[name='communicationDL']")[0].checked) 
            {
                communication.push($("[name='communicationDL']")[0].value.trim());
                
            }
            if ($("[name='communicationDL']")[1].checked) 
            {
                communication.push($("[name='communicationDL']")[1].value.trim());
                
            }
            if ($("[name='communicationDL']")[2].checked) 
            {
                communication.push($("[name='communicationDL']")[2].value.trim());
                
            }
            if ($("[name='communicationDL']")[3].checked) 
            {
                communication.push($("[name='communicationDL']")[3].value.trim());
                
            }
            if ($("[name='communicationDL']")[4].checked) 
            {
                communication.push($("[name='communicationDL']")[4].value.trim());
                
            }
            if ($("[name='communicationDL']")[5].checked) 
            {
                communication.push($("[name='communicationDL']")[5].value.trim());
                
            }

            var communicationForm=communication.join(",");            
            $("#impactedHidden").val(communicationForm);            
            var z = $("#Other1").val();

            if($("[name='communicationDL']").eq(5).prop("checked")) 
            {  
				$("#otherHidden").prop("required",true);
                $("#otherHidden").val(" ("+z+")");
            } 
            else 
            {
                $("#otherHidden").prop("required",false);
                $("#otherHidden").val("");
            }

            
            if(!$("#customSiteSection").is(":hidden"))
            {
                if($("[name='site1']").eq(3).prop("checked")) 
                {
                    $("#customSiteSectionHidden").val("Site Location: All Sites");
                } 
                else 
                {
                    var locationFR=new Array(0);
                    if ($("[name='site1']")[0].checked) 
                    {
                        locationFR.push("IND");   
                        
                    }
                    if ($("[name='site1']")[1].checked) 
                    {
                        locationFR.push("IRV");   
                        
                    }
                    if ($("[name='site1']")[2].checked) 
                    {
                        locationFR.push("SNO");  
                        
                    }
                    var finLocation="Site Location: " +locationFR;

                    $("#customSiteSectionHidden").val(finLocation);
                }
            }

            var announcementcontent = " ";
            var announcementcontent1 = " ";            
            announcementcontent = $('[name="outsideRPS"]:checked').val() + "<br/><br/>";

            if($("#outsideRPS").prop("checked")) {
                announcementcontent += "Contact Initials: " + $("#txtListContactInitials").val() + "<br/><br/>" ;
            } 
            
            
            if($.trim($("#txtnonCGEmailAddress").val()) != '') {                
                announcementcontent +=  "Non-CG Email Address: " + $("#txtnonCGEmailAddress").val() + "<br/><br/>" ;                                
            } 

            announcementcontent1 = $('[name="anotherDepartmentInitials"]:checked').val() + "<br/><br/>";
            if($("#TxtAnotherDepartment").prop("checked")) {
                announcementcontent1 +=  "Another Department Contact Initials: " + $("#txtAnotherDepartment").val() + "<br/><br/>" ;
                
            }
            else{
                $("#txtAnotherDepartment").val("");
            }            


            var typeOfAnnouncement = $("input[name=TypeOfAnnouncement]:checked").val();            
            var announcementContent = "--------------------------------------------------------------------------------------------------------------------------------------------------------------<br/><br/>";
            if(typeOfAnnouncement == "New Opportunity") {if(typeOfAnnouncement == "New Opportunity") {
                announcementContent += "Title of Role: " + $("#txtnewOpportunityTitle").val() + "<br/><br/>";            
                if($("[name='newOpportunityIndividualSiteSection']").eq(3).prop("checked")) {                        
                    announcementContent += "Site the opportunity is being offered: All Sites" + "<br/><br/>";            
                } else {
                    var locationFR=new Array(0);
                    if ($("[name='newOpportunityIndividualSiteSection']")[0].checked) 
                    {
                        locationFR.push("IND");   
                        
                    }
                    if ($("[name='newOpportunityIndividualSiteSection']")[1].checked) 
                    {
                        locationFR.push("IRV");   
                        
                    }
                    if ($("[name='newOpportunityIndividualSiteSection']")[2].checked) 
                    {
                        locationFR.push("SNO");  
                        
                    }
                    var finLocation=locationFR;
                    
                    announcementContent += "Site the opportunity is being offered: " + finLocation+ "<br/><br/>";
                    
                }
                
                announcementContent += "Is this position open to non-RPS associates? " + $('[name="newOpportunityNonRPSAssociates"]:checked').val() + "<br/><br/>";
                if($("#newOpportunityNonRPSAssociates").prop("checked")) {
                    announcementContent += "HR Contact Initials: " + $("#hri").val() + "<br/><br/>" ;
                } 
                announcementContent += "Is the position an internship? " + $('[name="newOpportunityInternship"]:checked').val() + "<br/><br/>";
                if($("#newOpportunityInternship").prop("checked")) {
                    announcementContent += "Duration of Internship: " + $("#txtNewOpportunityInternshipDuration").val() + "<br/><br/>" ;
                }
                announcementContent += "List Skills and Competencies: " + $("#txtSkillsAndCompetencies").val() + "<br/><br/>";
                announcementContent += "Role Description: " + $("#txtRoleDescription").val() + "<br/><br/>";
                announcementContent += "Deadline for Submitting Request: " + setDate($("#txtDeadline").val()) + "<br/><br/>";
                announcementContent += "Contact's Initials for submitting interest: " + $("#txtContactInitials").val() + "<br/><br/>";
                if($.trim($("#relaviteComments").val()) != '') {
                    announcementContent += "Relevant Information regarding the opportunity: " + $("#relaviteComments").val() + "<br/><br/>";
                }
            } else if(typeOfAnnouncement == "Filled Opportunity") {
                announcementContent += "Title of Role: " + $("#txtFilledOpportunityTitle").val() + "<br/><br/>";
                announcementContent += "Effective Date: " + setDate($("#txtFilledOpportunityEffectiveDate").val()) + "<br/><br/>";
                announcementContent += "Initials of  associate(s) being announced: " + $("#txtFilledOpportunityAssociateInitials").val() + "<br/><br/>";
                announcementContent += "Is an RPS associate moving from one work stram to another? or New Associate to RPS? " + $('[name="filledOpportunityScenarios"]:checked').val() + "<br/><br/>";
                if($("#filledOpportunityScenarios").prop("checked")) {
                    announcementContent += "BIO Template: " + $("#txtCompleteBIO").val() + "<br/><br/>";
                }
                if($.trim($("#txtFilledOpportunityRelevantInformation").val()) != '') {
                    announcementContent += "Relevant Information regarding the opportunity: " + $("#txtFilledOpportunityRelevantInformation").val() + "<br/><br/>";
                }                              
            } else if(typeOfAnnouncement == "Opportunity Updates (e.g., Internships ending, Associate transfers, etc.)") {
                announcementContent += "Title of Role: " + $("#txtOpportunityUpdateTitle").val() + "<br/><br/>";
                announcementContent += "Effective Date: " + setDate($("#txtOpportunityUpdateEffectiveDate").val()) + "<br/><br/>";
                announcementContent += "Initials of  associate(s) being announced: " + $("#txtOpportunityUpdateAssociateInitials").val() + "<br/><br/>";
                announcementContent += "Is this Opportunity Update related to a previously shared announcement? " + $('[name="opportunityUpdatePreviousAnnouncement"]:checked').val() + "<br/><br/>";
                if($("opportunityUpdatePreviousAnnouncement").prop("checked")) {
                    announcementContent += "Approximate Month/Year the previous announcement was shared: " + $("#txtOpportunityUpdateAnnouncementMonthYear").val() + "<br/><br/>";
                } 
                announcementContent += "Relevant Information regarding the opportunity: " + $("#txtOpportunityUpdateRelevantInformation").val() + "<br/><br/>";
            }

			$("#customAnnouncementDetails").val(announcementContent);
			$("#outsideRPS").val(announcementcontent);
			$("#TxtAnotherDepartment").val(announcementcontent1);
                                                         
			function setDate(val) {                                   
                var dateVal = val;
                var today = new Date(dateVal);
                var dd = String(today.getDate()).padStart(2, '0');
                var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                var yyyy = today.getFullYear();
                today = mm + '/' + dd + '/' + yyyy;
                return today;
			}
                                                         
          }
            
        });

    }
	

                    /*---------------------------------------RPS Research Transaction Request----------------------------------------------------------------*/

                    if ((document.URL).includes("rps-research-transaction-request")) {


                        $(document).on("click", "[name='submit-btn']", function() {



                            var rush = "";
                            var subjectLine = "";
                            var prfix = "";
                            var work = "";
                            if($("[name='rush']")[0].checked){
                                rush = "*RUSH";
                            }
                            var workType1 = $("#worktype2").val();
                            var workType = $("#worktype").val();


                            if (workType1 == "General Question" && $("#worktype2").is(":visible")) {
                                work = "Regular.Work.Research.";
                            } 
                            else if (workType1 == "Audit Report" && $("#worktype2").is(":visible")) {
                                work = "Regular.Work.Plan Audit.";
                            } 
                            else if (workType == "Statements or Forms" && $("#worktype2").is(":visible")) {
                                work = "Specialized.Work.Statements or Forms.Research.";
                            } 

                            else if (workType == "Web" && $("#worktype").is(":visible")) {
                                work = "Specialized.Work.Web.Research.";
                            }

                            else if (workType == "Rollover Investments" && $("#worktype").is(":visible")) {
                                work = "Specialized.Work.Rollover Investments.Research.";
                            }

                            else if (workType == "Other" && $("#worktype").is(":visible")) {
                                work = "Specialized.Work.Other.Research.";
                            }

                            else if (workType == "Earnings Payroll" && $("#worktype").is(":visible")) {
                                work = "Regular.Work.Earnings.";
                            }

                            else if (workType == "Web Walk-Through" && $("#worktype").is(":visible")) {
                                work = "Regular.Work.Web.";
                            }

                            else if (workType == "Residual Distribution" && $("#worktype").is(":visible")) {
                                work = "Regular.Work.Distribution.";
                            }

                             else if (workType == "Non-Financial Plan Maintenance" && $("#worktype").is(":visible")) {
                                work = "Regular.Work.Non-Fin Plan Maint.";
                            }

                            else if (workType == "ATR Rollover Acceptance" && $("#worktype").is(":visible")) {
                                work = "Regular.Work.Fin Participant Maint.";
                            }

                            else if(!$("#worktype2").is(":visible") && !$("#worktype").is(":visible")){
								work = "Regular.Work.Distribution.";
                            }

                            if ($('input[name="hiddenresolution"]:checked').val() == "Research") {
                                prfix = "RPS Research Request";
                            } else {
                                prfix = "RPS Transaction Request";
                            }
                            subjectLine += prfix + " " + work + " " + rush + " " + $("#planId").val() + " - " + $("#planname").val();
                            $("#mailSubject").val(subjectLine);
                        });
                    }
					
					/*--------------------------------------------RP - SCHEDULE ADJUSTMENT FORM-----------------------------------------------------*/

     if ((document.URL).includes("rp-schedule-adjustment-form")) {
var selectedValue = new Array();
var selectedValue1 = new Array();
         var selectedValue2 = new Array();
         var selectedValue3 = new Array();
$(document).on("click", "[name='submit-btn']", function() {
if($('input[name="flex1"]:checked')) {
var flex1 = "";
var stop = $('input[name="flex1"]:checked').val();
if(stop == "YES") {
flex1= "YES";
} else {
flex1= "NO";
}
$("#flex1").val(flex1);
}
$('input[name="montxt1"]:checked').each(function() {
selectedValue.push($(this).val());
});
$("#montxt1").val(selectedValue);
$('input[name="montxt2"]:checked').each(function() {
selectedValue1.push($(this).val());
});
$("#montxt2").val(selectedValue1);
$('input[name="montxt3"]:checked').each(function() {
selectedValue2.push($(this).val());
});
$("#montxt3").val(selectedValue2);
$('input[name="montxt4"]:checked').each(function() {
selectedValue3.push($(this).val());
});
$("#montxt4").val(selectedValue3);
});
}
					
					/*---------------------------------------------------Check Stop/Reissue Request (checkstop)-----------------------------------------------------------------------------*/

                        if ((document.URL).includes("reissue-request")) {	

                            $("#hidovnchk").parent().parent().css("display", "none");
                            $("#hidmailchg").parent().parent().css("display", "none");
                            $("#pocyesno").parent().parent().css("display", "none");
                            $("#pocyesnoRadio").parent().parent().parent().css("display", "none");
                            $("#mailchgRadio").parent().parent().parent().css("display", "none");
                            $("#ovnchkRadio").parent().parent().parent().css("display", "none");
                            $("#pocyesnoRadioText").parent().css("display", "none");
                            $("#mailchgRadioText").parent().css("display", "none");
                            $("#ovnchkRadioText").parent().css("display", "none");
                            $("#stopcancel").prop('disabled',true);
							$("#stopcancel").css('background-color' ,"#eee").css('opacity',1);
                            $("#ckhandyesno").parent().parent().parent().css("display", "none");
                            $("#ckhandyesnoText").parent().css("display", "none");
                            $("#less5yesno").parent().parent().parent().css("display", "none");
                            $("#less5yesnoText").parent().css("display", "none");
                            $("#more12yesno").parent().parent().parent().css("display", "none");
                            $("#more12yesnoText").parent().css("display", "none");
                            $("#reissue").parent().parent().css("display", "none");
							$("#planid_reissue").prop('maxlength',10);

                            $('input[name=casyesno]').change(function() { 
                                var counter=0;
                                $('input[name=ckhandyesno]').prop('checked',false)
                                $('input[name=less5yesno]').prop('checked',false)
                                $('input[name=more12yesno]').prop('checked',false)
                                $('input[name=casyesno]').each(function() {                                    
                                    if ($("input[name=casyesno]:checked").val() == "Yes") {
                                        if(counter==0){
										++counter;                                        
                                        alert('Please process this stop/re-issue request in SHARE (CAS) since the original check was issued there.');                                            
                                        }

                                        $("#ckhandyesno").parent().parent().parent().css("display", "none");
                                        $("#ckhandyesnoText").parent().css("display", "none");
                                        $("#less5yesno").parent().parent().parent().css("display", "none");
                                        $("#less5yesnoText").parent().css("display", "none");
                                        $("#more12yesno").parent().parent().parent().css("display", "none");
                                        $("#more12yesnoText").parent().css("display", "none");
                                        $("#reissue").parent().parent().css("display", "none");										
                                        document.getElementById("stopcancel").selectedIndex = "0";
                                        $("#pocyesnoRadio").parent().parent().parent().css("display", "none");
                                        $("#mailchgRadio").parent().parent().parent().css("display", "none");
                                        $("#ovnchkRadio").parent().parent().parent().css("display", "none");
                                        $("#pocyesnoRadioText").parent().css("display", "none");
                                        $("#mailchgRadioText").parent().css("display", "none");
                                        $("#ovnchkRadioText").parent().css("display", "none");
                                        $("#pocyesnoRadio").removeAttr('checked');
                                        $("#mailchgRadio").removeAttr('checked');
                                        $("#ovnchkRadio").removeAttr('checked');
                                        $("#reason").css('background-color' ,"#eee").css('opacity',1);
                                        $("#reason").val('');
                                        $("#mlchanges").css('background-color' ,"#eee").css('opacity',1);
                                        $("#mlchanges").val('');
                                        $("#overnight").css('background-color' ,"#eee").css('opacity',1);
                                        $("#overnight").val('');
                                        document.getElementById("reissue").selectedIndex = "0";


                                    }

                                    else if ($("input[name=casyesno]:checked").val() == "No") {
                                        $("#ckhandyesno").parent().parent().parent().css("display", "block");
                                        $("#ckhandyesnoText").parent().css("display", "block");
                                        $("#less5yesno").parent().parent().parent().css("display", "none");
                                        $("#less5yesnoText").parent().css("display", "none");
                                        $("#more12yesno").parent().parent().parent().css("display", "none");
                                        $("#more12yesnoText").parent().css("display", "none");
                                        $("#reissue").parent().parent().css("display", "none");                                        										
                                        document.getElementById("stopcancel").selectedIndex = "0";
										$("#pocyesnoRadio").parent().parent().parent().css("display", "none");
                                        $("#mailchgRadio").parent().parent().parent().css("display", "none");
                                        $("#ovnchkRadio").parent().parent().parent().css("display", "none");
                                        $("#pocyesnoRadioText").parent().css("display", "none");
                                        $("#mailchgRadioText").parent().css("display", "none");
                                        $("#ovnchkRadioText").parent().css("display", "none");
                                        $("#pocyesnoRadio").removeAttr('checked');
                                        $("#mailchgRadio").removeAttr('checked');
                                        $("#ovnchkRadio").removeAttr('checked');
                                        $("#reason").css('background-color' ,"#eee").css('opacity',1);
                                        $("#reason").val('');
                                        $("#mlchanges").css('background-color' ,"#eee").css('opacity',1);
                                        $("#mlchanges").val('');
                                        $("#overnight").css('background-color' ,"#eee").css('opacity',1);
                                        $("#overnight").val('');
                                        document.getElementById("reissue").selectedIndex = "0";
                                    }
                                });
                            });

                             $('input[name=ckhandyesno]').change(function() {                                 
                                $('input[name=less5yesno]').prop('checked',false);
                                $('input[name=more12yesno]').prop('checked',false);
                                $('input[name=ckhandyesno]').each(function() {
                                    if ($("input[name=ckhandyesno]:checked").val() == "Yes") {                                                                                
                                        $("#less5yesno").parent().parent().parent().css("display", "none");
                                        $("#less5yesnoText").parent().css("display", "none");
                                        $("#more12yesno").parent().parent().parent().css("display", "none");
                                        $("#more12yesnoText").parent().css("display", "none");
                                        $("#reissue").parent().parent().css("display", "block");
                                        document.getElementById("stopcancel").selectedIndex = "2";                                                                               

                                    }

                                    else if ($("input[name=ckhandyesno]:checked").val() == "No") {                                       
                                        $("#less5yesno").parent().parent().parent().css("display", "block");
                                        $("#less5yesnoText").parent().css("display", "block");
                                        $("#more12yesno").parent().parent().parent().css("display", "none");
                                        $("#more12yesnoText").parent().css("display", "none");
                                        $("#reissue").parent().parent().css("display", "none");
                                        document.getElementById("stopcancel").selectedIndex = "0";
                                        $("#pocyesnoRadio").parent().parent().parent().css("display", "none");
                                        $("#mailchgRadio").parent().parent().parent().css("display", "none");
                                        $("#ovnchkRadio").parent().parent().parent().css("display", "none");
                                        $("#pocyesnoRadioText").parent().css("display", "none");
                                        $("#mailchgRadioText").parent().css("display", "none");
                                        $("#ovnchkRadioText").parent().css("display", "none");
                                        $("#pocyesnoRadio").removeAttr('checked');
                                        $("#mailchgRadio").removeAttr('checked');
                                        $("#ovnchkRadio").removeAttr('checked');
                                        $("#reason").css('background-color' ,"#eee").css('opacity',1);
                                        $("#reason").val('');
                                        $("#mlchanges").css('background-color' ,"#eee").css('opacity',1);
                                        $("#mlchanges").val('');
                                        $("#overnight").css('background-color' ,"#eee").css('opacity',1);
                                        $("#overnight").val('');
                                        document.getElementById("reissue").selectedIndex = "0";


                                    }
                                });
                            });

                            $('input[name=less5yesno]').change(function() {                                  
                                $('input[name=more12yesno]').prop('checked',false);
                                $('input[name=less5yesno]').each(function() {
                                    if ($("input[name=less5yesno]:checked").val() == "Yes") {                                                                                                                        
                                        $("#more12yesno").parent().parent().parent().css("display", "none");
                                        $("#more12yesnoText").parent().css("display", "none");
                                        $("#reissue").parent().parent().css("display", "block");                                                                               
                                        document.getElementById("stopcancel").selectedIndex = "2";
                                    }

                                    else if ($("input[name=less5yesno]:checked").val() == "No") {                                                                               
                                        $("#more12yesno").parent().parent().parent().css("display", "block");
                                        $("#more12yesnoText").parent().css("display", "block");
                                        $("#reissue").parent().parent().css("display", "none");
                                        document.getElementById("stopcancel").selectedIndex = "0";
                                        $("#pocyesnoRadio").parent().parent().parent().css("display", "none");
                                        $("#mailchgRadio").parent().parent().parent().css("display", "none");
                                        $("#ovnchkRadio").parent().parent().parent().css("display", "none");
                                        $("#pocyesnoRadioText").parent().css("display", "none");
                                        $("#mailchgRadioText").parent().css("display", "none");
                                        $("#ovnchkRadioText").parent().css("display", "none");
                                        $("#pocyesnoRadio").removeAttr('checked');
                                        $("#mailchgRadio").removeAttr('checked');
                                        $("#ovnchkRadio").removeAttr('checked');
                                        $("#reason").css('background-color' ,"#eee").css('opacity',1);
                                        $("#reason").val('');
                                        $("#mlchanges").css('background-color' ,"#eee").css('opacity',1);
                                        $("#mlchanges").val('');
                                        $("#overnight").css('background-color' ,"#eee").css('opacity',1);
                                        $("#overnight").val('');
                                        document.getElementById("reissue").selectedIndex = "0";

                                    }
                                });
                            });

                            $('input[name=more12yesno]').change(function() {                                
                                $('input[name=more12yesno]').each(function() {
                                    if ($("input[name=more12yesno]:checked").val() == "Yes") {                                                                                                                                                                
                                        $("#reissue").parent().parent().css("display", "block");
                                        document.getElementById("stopcancel").selectedIndex = "2";
                                    }

                                    else if ($("input[name=more12yesno]:checked").val() == "No") {                                                                                                                      
                                        $("#reissue").parent().parent().css("display", "block");
                                        document.getElementById("stopcancel").selectedIndex = "1";
                                    }
                                });
                            });


                            $('select[name=reissue]').change(function() {
                                $("select[name=reissue] option:selected").each(function() {
                                    var counter=0;
                                    $("#reason").css('background-color' ,"#eee").css('opacity',1);
                            		$("#reason").val('');
                                    $("#mlchanges").css('background-color' ,"#eee").css('opacity',1);
                            		$("#mlchanges").val('');
                                    $("#overnight").css('background-color' ,"#eee").css('opacity',1);
                            		$("#overnight").val('');
                                    if ($(this).val() == "Yes") 
                                    {
                                        $("#pocyesnoRadio").parent().parent().parent().css("display", "block");
                                        $("#mailchgRadio").parent().parent().parent().css("display", "block");
                                        $("#ovnchkRadio").parent().parent().parent().css("display", "block");
                                        $("#pocyesnoRadioText").parent().css("display", "block");
                                        $("#mailchgRadioText").parent().css("display", "block");
                                        $("#ovnchkRadioText").parent().css("display", "block");
                                        
                                    }
                                    else
                                    {
                                        if(counter==0){
										++counter;
                                        alert("Please include a note in the Additional Comments field that the check will not be re-issued.");
                                        }
                                        $("#pocyesnoRadio").parent().parent().parent().css("display", "none");
                                        $("#mailchgRadio").parent().parent().parent().css("display", "none");
                                        $("#ovnchkRadio").parent().parent().parent().css("display", "none");
                                        $("#pocyesnoRadioText").parent().css("display", "none");
                                        $("#mailchgRadioText").parent().css("display", "none");
                                        $("#ovnchkRadioText").parent().css("display", "none");
                                        $("#pocyesnoRadio").removeAttr('checked');
                                        $("#mailchgRadio").removeAttr('checked');
                                        $("#ovnchkRadio").removeAttr('checked');
                                    }
                                });
                            });	
                            $("#reason").prop('disabled' , true);
                            $("#reason").css('background-color' ,"#eee").css('opacity',1);
                            $("#reason").val('');
                            $('input[name=pocyesnoRadio]').change(function() {
                                var counter=0;
                                $('input[name=pocyesnoRadio]').each(function() {
                                    if ($("input[name=pocyesnoRadio]:checked").val() == "Yes") {
                                        if(counter==0){
										++counter;
                                        alert("IMPORTANT:\n\n1.  Manager approval must be noted in TRAC on Payee Registration Changes.\n\n"+"2.  Note the changes in the Payee Registration Changes field.");
                                        }
                                        $("#reason").prop('disabled' , false);
                                        $("#reason").css('background-color' ,"white").css('opacity',1);
                                    } 
                                    else if ($("input[name=pocyesnoRadio]:checked").val() == "No") {
                                        $("#reason").prop('disabled' , true);
                                        $("#reason").css('background-color' ,"#eee").css('opacity',1);
                                        $("#reason").val('');
                                        
                                    } 
                                });
                            });
                                        
                            $("#mlchanges").prop('disabled' , true);
                            $("#mlchanges").css('background-color' ,"#eee").css('opacity',1);	
                            $("#mlchanges").val('');
                            $('input[name=mailchgRadio]').change(function() {
                                $('input[name=mailchgRadio]').each(function() {
                                    if ($("input[name=mailchgRadio]:checked").val() == "Yes") {
                                        $("#mlchanges").prop('disabled' , false);
                                        $("#mlchanges").css('background-color' ,"white").css('opacity',1);			
                                    } 
                                    else if ($("input[name=mailchgRadio]:checked").val() == "No") {
                                        $("#mlchanges").prop('disabled' , true);
                                        $("#mlchanges").css('background-color' ,"#eee").css('opacity',1);			
                                        $("#mlchanges").val('');
                                        
                                    } 
                                });
                            });			

                            $("#overnight").prop('disabled' , true);
                            $("#overnight").css('background-color' ,"#eee").css('opacity',1);
                            $("#overnight").val('');
                            $('input[name=ovnchkRadio]').change(function() {
                                $('input[name=ovnchkRadio]').each(function() {
                                    if ($("input[name=ovnchkRadio]:checked").val() == "Yes") {
                                        $("#overnight").prop('disabled' , false);
                                        $("#overnight").css('background-color' ,"white").css('opacity',1);			
                                    } 
                                    else if ($("input[name=ovnchkRadio]:checked").val() == "No") {
                                        $("#overnight").prop('disabled' , true);
                                        $("#overnight").css('background-color' ,"#eee").css('opacity',1);			
                                        $("#overnight").val('');
                                        
                                    } 
                                });
                            });		
                            $(document).on("click", "[name='submit-btn']", function(e) 
                            {
								if($("#reissue").val()=="SELECT" && $("#reissue").is(":visible")){
alert("RMAC will re-issue check through TRCRECON is a required field");
$("#reissue").focus();
(e).preventDefault();
}
                                if ($("[name='pocyesnoRadio']")[0].checked) 
                                    {
                                        $("#pocyesno").val("Yes");
                            
                                    }
                                if ($("[name='mailchgRadio']")[0].checked) 
                                    {
                                        $("#hidmailchg").val("Yes");
                            
                                    }
                            
                                if ($("[name='ovnchkRadio']")[0].checked) 
                                    {
                                        $("#hidovnchk").val("Yes");
                            
                                    }
                            });
                            }				



                   /*------------------------------------------rp-movement-telephone-referral-----------------------------------------------------------------------------------------*/


    if ((document.URL).includes("rp-movement-telephone-referral")) {

         var stop = [];
        var plantype = "";

        $("#PLANTYPEBody").parent().parent().css("display", "none");


        $(document).on("click", "[name='submit-btn']", function() {

$('input[name="PLANTYPE"]:checked').each(function() {
stop.push($(this).val());
});
            

for(var i=0; i<stop.length; i++) {
   
if(stop[i] === "TRAC"){
    
plantype+= "TRAC: Y";
}  if(stop[i] === "GPURCH"){
   
plantype+= " GPURCH: Y";
} if(stop[i] === "OTHER"){
    
plantype+= " OTHER: Y";
}
}
$("#PLANTYPEBody").val(plantype);
        });
    }



                    /*--------------------------------------------------rps-system-enhancement-manager-backlog-submission-form------------------------------------------------------*/
                    if ((document.URL).includes("rps-system-enhancement-manager-backlog-submission-form")) {

                        $("#clientBody").parent().parent().css("display", "none");
                        $("#gensysBody").parent().parent().css("display", "none");

                        var selectedValue = new Array();
                        var selectedValue1 = new Array();
                        $(document).on("click", "[name='submit-btn']", function() {
							 if($("#submitTo").val() == "Genesys (Email / Voice)"){
		var emailID=$("#qualifierAddr").val();
		$("#emailAddr").val(emailID);	
	} 
	else if($("#submitTo").val() == "TRAC Desktop"){
		var emailID=$("#qualifierAddr1").val();
		$("#emailAddr").val(emailID);	
	}  
	else if($("#submitTo").val() == "RPA" || $("#submitTo").val() == "AWD"){
		var emailID=$("#qualifierAddr2").val();
		$("#emailAddr").val(emailID);	
	}
	else if($("#submitTo").val() == "RKD PS/Partic Web" ){
		var emailID=$("#qualifierAddr3").val();
		$("#emailAddr").val(emailID);	
	}
	else if($("#submitTo").val() == "Empower" ){
		var emailID=$("#qualifierAddr4").val();
		$("#emailAddr").val(emailID);	
	}

                            $('input[name="Requesttimesensitive"]:checked').each(function() {
                                if ($(this).val() == "Yes") {


                                    $("#isReqTimeSensitiveVal").val($("#isReqTimeSensitiveVal").val());
                                } else {
                                    $("#isReqTimeSensitiveVal").val("No");

                                }
                            });
                           var impactedSystem= new Array(0);
                            if ($("[name='allImpactedSystems']")[0].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[0].value);

                            }
                            if ($("[name='allImpactedSystems']")[1].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[1].value);

                            }
                            if ($("[name='allImpactedSystems']")[2].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[2].value);

                            }
                            if ($("[name='allImpactedSystems']")[3].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[3].value);

                            }
                            if ($("[name='allImpactedSystems']")[4].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[4].value);

                            }
                            if ($("[name='allImpactedSystems']")[5].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[5].value);

                            }
                            if ($("[name='allImpactedSystems']")[6].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[6].value);

                            }
                            if ($("[name='allImpactedSystems']")[7].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[7].value);

                            }
                            if ($("[name='allImpactedSystems']")[8].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[8].value);

                            }
                            if ($("[name='allImpactedSystems']")[9].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[9].value);

                            }
                            if ($("[name='allImpactedSystems']")[10].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[10].value);

                            }
                            if ($("[name='allImpactedSystems']")[11].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[11].value);

                            }
                            if ($("[name='allImpactedSystems']")[12].checked) 
                            {
								impactedSystem.push($("[name='allImpactedSystems']")[12].value);

                            }
                            if ($("[name='allImpactedSystems']")[13].checked) 
                            {
                                 impactedSystem.push($("[name='allImpactedSystems']")[13].value.trim());


                            }
                            var impactedSystemForm=impactedSystem.join(",");
							$("#gensysBody").val(impactedSystemForm);
							var impactedAreas= new Array(0);
                            if ($("[name='allImpactedBusinessAreasID']")[0].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[0].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[1].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[1].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[2].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[2].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[3].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[3].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[4].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[4].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[5].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[5].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[6].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[6].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[7].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[7].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[8].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[8].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[9].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[9].value);

                            }
                            if ($("[name='allImpactedBusinessAreasID']")[10].checked) 
                            {
								 impactedAreas.push($("[name='allImpactedBusinessAreasID']")[10].value);

                            }
							 var impactedareasForm=impactedAreas.join(", ");
                            $("#clientBody").val(impactedareasForm);

                            
                        });
                    }
                    /*------------------------------------------G-Purch Batch Ticket------------------------------------------------------------*/

                    if ((document.URL).includes("g-purch-batch-ticket")) {
                        $("#sumHidden").parent().parent().css("display", "none");
						$("#sumHidden-2").parent().parent().css("display", "none");
						$("#sumHidden-3").parent().parent().css("display", "none");
						$("#approverHidden").parent().parent().css("display", "none");
                        $("#additionalHidden").parent().parent().css("display", "none");
                        $("#checkHidden").parent().parent().css("display", "none");    
                        $(document).on("click", "[name='submit-btn']", function() {


				     var deposit = $("#deposit_total").val()
					localStorage.setItem('deposit-value', deposit );
					var plan = $("#planType").val()
					localStorage.setItem('plan-value', plan );
					var batch = $("#batchid").val()
					localStorage.setItem('batch-value', batch );
					var tradeDate = $("#tradeDate").val()
					localStorage.setItem('trade-value', tradeDate );
					var reasonCode = $("#Reason_code").val()
					localStorage.setItem('reason-value', reasonCode );


                            $(".Element2a").not(":hidden").each(function() {
                                $(this).prop("required", true);
                            });
                            $(".Element2a").not(":visible").each(function() {
                                $(this).prop("required", false);
                            });
                            $(".Element2b").not(":hidden").each(function() {
                                $(this).prop("required", true);
                            });
                            $(".Element2b").not(":visible").each(function() {
                                $(this).prop("required", false);
                            });
                            var taskArray = new Array();
                            var processingArray = new Array();
                            $("input[name=groupplan_gpurch]").each(function() {
                                taskArray.push($(this).val());
                            });
                            $("input[name=pamtdemo_gpurch]").each(function() {
                                processingArray.push($(this).val());
                            });
                            var subjectLine = "G-Purch - ";
                            var gpItemString = "";
                            var lineGroupPlan = "";
                            var processingAmount = "";
                            if ($("#PAYMENTTYPE").val() == "WIRE") {
                                subjectLine += $("#site2").val() + " - ";
                            } else if ($("#PAYMENTTYPE").val() == "CHECK") {
                                subjectLine += $("#site").val() + " - ";
                            }
                            subjectLine += $("#PAYMENTTYPE").val() + " - ";
                            if (taskArray.length > 0 && processingArray.length > 0) {
                                for (var i = 0; i < taskArray.length; i++) {
                                    gpItemString = gpItemString + taskArray[i] + ":";
                                }
                            }
                            gpArray = gpItemString.split(":");
                            if (gpArray.length != 0) {
                                for (var i = 0; i < gpArray.length; i++) {
                                    if (i < gpArray.length - 2) {
                                        subjectLine += gpArray[i] + ", ";
                                    }
                                    if (i == gpArray.length - 2) {
                                        subjectLine += gpArray[i];
                                    }
                                }
                            }
                            subjectLine += "  " + $("#deposit_total").val();
                            $("#mailSubject").val(subjectLine);
							
                            var emailSum = $("#sumdisp").children().text().substring(8);
                             $("#sumHidden").val(emailSum);

						    var emailSumdisp = $("#sum1disp").children().text().substring(13);
                             $("#sumHidden-2").val(emailSumdisp);

							var emailTotaldisp = $("#totaldisp").children().text().substring(20);
                             $("#sumHidden-3").val(emailTotaldisp);


							 
							 if ($("#approver-4").val().length > 0) {
                                var approverBody = "APPROVER: " + $("#approver-4").val();
                                $("#approverHidden").val(approverBody);
                            }
                            if ($("#additional_comments").val().length > 0) {
                                var additonalBody = "ADDITIONAL COMMENTS: <br/>" + $("#additional_comments").val();
                                $("#additionalHidden").val(additonalBody);
                            }
                            if ($("#PAYMENTTYPE").val() == "CHECK") {
                                var checkBody = "<br/>TOTAL OF ALL CHECKS     $ " + $("#sumHidden").val();
                                $("#checkHidden").val(checkBody);
                            }
                        });
			
                    }
					if ((document.URL).includes("G-Purch-Alert")) {

                        function currDate() { 

                            var today = new Date();
                            var month = today.getMonth() + 1;
                            if (month < 10) {
                                month = "0" + month;
                            }
                            var day = today.getDate();
                            if (day < 10) {
                                day = "0" + day;
                            }
                            var year = today.getFullYear();
                            var dateString = year + "-" + month + "-" + day;
                            return dateString;
                        }
                        var todayDate = currDate();
                    

                        var date = new Date();
                        $("#date-g").css('width', '600px')
                        $("#date-g").val(date);
                        $("#date-g").prop("disabled", true);
                        
                        if(localStorage.getItem('deposit-value')!= null)
                        {
                        $("#deposit-total-g").val(localStorage.getItem('deposit-value'));
                        $("#deposit-total-g").click();
                        }
                        if(localStorage.getItem('plan-value')!= null)
                        {
                        $("#plan-type-g").val(localStorage.getItem('plan-value'));
                        $("#plan-type-g").click();
                        }
                        if(localStorage.getItem('batch-value')!= null)
                        {
                        $("#batch-g").val(localStorage.getItem('batch-value'));
                        $("#batch-g").click();
                        }
                        if(localStorage.getItem('trade-value')!= null)
                        {
                        $("#trade-date-g").val(localStorage.getItem('trade-value'));
                        $("#trade-date-g").click();
                        }
                        if(localStorage.getItem('reason-value')!= null)
                        {
                        $("#reason-code-g").val(localStorage.getItem('reason-value'));
                        $("#reason-code-g").click();
                        }
                        if(localStorage.getItem('trade-value') == todayDate)
                        {
                        $("#check-text-g").parent().css("display", "none");
                        }

                        localStorage.removeItem('deposit-value');
                        localStorage.removeItem('plan-value');
                        localStorage.removeItem('batch-value');
                        localStorage.removeItem('trade-value');
                        localStorage.removeItem('reason-value');

                        }


                    /*-------------------------------------special handle request----------------------------------------------------------------*/


                    if ((document.URL).includes("special-handle-request")) {


                        $(document).on("click", "[name='submit-btn']", function() {
							/*if($("#SITE").val() == "IRV"){
                                var emailID=$("#qualifierAddr").val();
                                $("#emailAddr").val(emailID);	
                            } 
                            else if($("#SITE").val() == "SNO"){
                                var emailID=$("#qualifierAddr1").val();
                                $("#emailAddr").val(emailID);	
                            } 
                            else if($("#SITE").val() == "IND"){
                                var emailID=$("#qualifierAddr2").val();
                                $("#emailAddr").val(emailID);	
                            } 
                            else if($("#SITE").val() == "HRO"){
                                var emailID=$("#qualifierAddr3").val();
                                $("#emailAddr").val(emailID);	
                            } */
                            var gpArray = new Array();
                            var gpItemString = "";
                            var subjectLine = "";
                            subjectLine += "Special Handle Request - ";
                            subjectLine += $("#AORSITE").val()+ " - " ;
                            var taskArray = new Array();
                            $("input[name=account]").each(function() {
                                if ($(this).val() != "") {

                                    taskArray.push($(this).val());
                                }
                            });

                            var accountNumbers=taskArray.join(", ");
							subjectLine+=accountNumbers;

                            var planArray = new Array();
                            $("input[name=pid]").each(function() {
                                if ($(this).val() != "") {

                                    planArray.push($(this).val());

                                }

                            });

                            var planNumbers=planArray.join(", ");
							subjectLine+=planNumbers;

                            var deliveryhidden="";
                            var deliverymethod = $("#DELIVERY").val();
                            var courier = $("#COURIER").val();
                            var courier1 = $("#COURIER1").val();
                            var billingNumber =$("#BILLING_NUMBER").val();
							var billingNumber1=$("#BILLING_NUMBER1").val();
                            var serviceRequested=$("#SERVICE_REQUESTED").val();
                            var signatureRequired=$("#SIGNATURE_REQUIRED").val();
                            var sitePickUp=$("#SITE_FOR_PICKUP").val();
                            var serviceRequested1=$("#SERVICE_REQUESTED1").val();
                            
                            if (deliverymethod == "Overnight Delivery") {
                            	deliveryhidden = deliverymethod +"<br/>"+"<br/>"+"COURIER:"+" " + courier+"<br/>"+"BILLING NUMBER:"+" "+ billingNumber+"<br/>"+"SERVICE REQUESTED:"+" "+ serviceRequested+"<br/>"+"SIGNATURE REQUIRED:"+" "+ signatureRequired+"<br/>"+"<br/>";
                             } else if (deliverymethod == "Overnight Delivery at AFS Expense") {
                               deliveryhidden = deliverymethod +"<br/>"+"<br/>"+"COURIER:"+" " + courier+"<br/>"+"SERVICE REQUESTED:"+" "+ serviceRequested+"<br/>"+"SIGNATURE REQUIRED:"+" "+ signatureRequired+"<br/>"+"<br/>";
                             } else if (deliverymethod == "Overnight Delivery Billed to Third Party") {
                            	deliveryhidden = deliverymethod +"<br/>"+"<br/>"+"COURIER:"+" " + courier1+"<br/>"+"BILLING NUMBER:"+" "+ billingNumber1+"<br/>"+"SIGNATURE REQUIRED:"+" "+ signatureRequired+"<br/>"+"SERVICE REQUESTED:"+" "+ serviceRequested1+"<br/>"+"<br/>";
                             }else if (deliverymethod == "Shareholder Pick-up") {
                            	deliveryhidden = deliverymethod +"<br/>"+"<br/>"+"SITE FOR PICK UP:"+" " + sitePickUp+"<br/>"+"<br/>";
                             } else if (deliverymethod == "Regular Mail") {
                            	deliveryhidden = deliverymethod +"<br/>"+"<br/>";
                            }
                            if($("input[name=enclorures]")[0].checked && !($("input[name=enclorures]")[1].checked)){
                            	deliveryhidden+="ENCLOSURES"+"<br/>"+"SOURCE : Y"+"<br/>";
                            }else if($("input[name=enclorures]")[0].checked && $("input[name=enclorures]")[1].checked){
                            	deliveryhidden+="ENCLOSURES"+"<br/>"+"SOURCE : Y"+"<br/>"+"TRAC AND SHARE CHECKS : Y"+"<br/>";
                            }else if(!($("input[name=enclorures]")[0].checked) && ($("input[name=enclorures]")[1].checked)) {
                            	deliveryhidden+="ENCLOSURES"+"<br/>"+"TRAC AND SHARE CHECKS : Y"+"<br/>";
                            }else {
                            	deliveryhidden+="<br/>";
                            }
                            $("#deliveryhidden").val(deliveryhidden);
                            $("#mailSubject").val(subjectLine);

                        });
                    }


                    /*--------------------------------share requirement feedback form----------------------------------------------------------------------------*/



                    if ((document.URL).includes("share-requirements-feedback-form")) {



                        $(document).ready(function() {


                            var url = window.location.href;
                            $("#requestURL").val(url);
                            var urlArray = url.split("/");
                            var length = urlArray.length;
                            var tit = urlArray[urlArray.length - 1];
                            var title = tit.split("?");
                            var paget = title[0].split("\\.");
                            var pagetitle = paget[0];

                            $("#pageTitle").val(pagetitle);
                        });
                    }

                    /*---------------------rps compliance refferal form -----------------------------------------------------------------------------*/
                    if ((document.URL).includes("rps-compliance-referral-form")) {

                        $("#AILDETAILSBody").parent().parent().css("display", "none");

                        $(document).on("click", "[name='submit-btn']", function() {


                            var hiddenDetails = "";
                            var referralType = $("#REFERRALTYPE").val();
							
							function browserSupportsDateInputMethod4() {
                            var i = document.createElement("input");
                            i.setAttribute("type", "date");
                            return i.type !== "text";
							}
                            if (referralType != "" && referralType == "Fraud/ID Theft") {
                                var RPSNotifiedDate;
								var finDate;
                                if ($("#RPSNotifiedDate").val()!=undefined) {
									if (browserSupportsDateInputMethod4()) 
									{
										var dateVal = $('#RPSNotifiedDate').val();
										var dateConversionArray = dateVal.split("-");
										finDate = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
									}
									else
									{
										finDate =$('#RPSNotifiedDate').val();
									}
                                    if(finDate==='undefined/undefined/')
                                    {
                                        RPSNotifiedDate="";
                                    }
                                    else
                                    {
                                        RPSNotifiedDate = finDate;
                                    }

                            } 
                                hiddenDetails = "<br/><br/> DATE RPS NOTIFIED : " + RPSNotifiedDate + "<br/><br/> SCENARIO DESCRIPTION : " +
                                    $("#SCENARIODESCRIPTION").val() + "<br/><br/> ACTION TAKEN : " + $("#ACTIONTAKEN").val() +
                                    "<br/><br/> RECOMMENDED RESOLUTION : " + $("#Resolution").val() + "<br/>";


                            } else if (referralType != "" && referralType == "Loan Default Reversal Request") {

								function browserSupportsDateInputMethod5() {
									var i = document.createElement("input");
									i.setAttribute("type", "date");
									return i.type !== "text";
								}
                                var LoanOriginationDate;
                                if ($("#LoanOriginationDate").val()!=undefined) {
									var finDate;
									if (browserSupportsDateInputMethod5()) 
									{
										var dateVal = $('#LoanOriginationDate').val();
										var dateConversionArray = dateVal.split("-");
										finDate = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
                                    }
									else
									{
										finDate=$('#LoanOriginationDate').val();
									}
									if(finDate==='undefined/undefined/')
                                    {
                                        LoanOriginationDate="";
                                    }
                                    else
                                    {
                                        LoanOriginationDate = finDate;
                                    }

                            	} 

                                var LoanMaturityDate;
                                if ($("#LoanMaturityDate").val()!=undefined) {
									var finDate;
									if (browserSupportsDateInputMethod5()) 
									{
										var dateVal = $('#LoanMaturityDate').val();
										var dateConversionArray = dateVal.split("-");
										var finDate = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
									}
									else
									{
										finDate=$('#LoanMaturityDate').val();
									}
                                    if(finDate==='undefined/undefined/')
                                    {
                                        LoanMaturityDate="";
                                    }
                                    else
                                    {
                                        LoanMaturityDate = finDate;
                                    }

                            	} 

                                 var DateLoanDefaulted;
                                if ($("#DateLoanDefaulted").val()!=undefined) {
									var finDate;
									if (browserSupportsDateInputMethod5()) 
									{
										var dateVal = $('#DateLoanDefaulted').val();
										var dateConversionArray = dateVal.split("-");
										finDate = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
									}
									else
									{
										finDate=$('#DateLoanDefaulted').val();
									}
                                    if(finDate==='undefined/undefined/')
                                    {
                                        DateLoanDefaulted="";
                                    }
                                    else
                                    {
                                        DateLoanDefaulted = finDate;
                                    }

                            	} 
                                 var CurePeriodEndDate;
                                if ($("#CurePeriodEndDate").val()!=undefined) {
									var finDate;
									if (browserSupportsDateInputMethod5()) 
									{
										var dateVal = $('#CurePeriodEndDate').val();
										var dateConversionArray = dateVal.split("-");
										finDate = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
									}
									else
									{
										finDate= $('#CurePeriodEndDate').val();
									}
                                    if(finDate==='undefined/undefined/')
                                    {
                                        CurePeriodEndDate="";
                                    }
                                    else
                                    {
                                        CurePeriodEndDate = finDate;
                                    }

                            	} 

                                hiddenDetails = "<br/><br/>" +
                                    "SSN (LAST 4 DIGITS) : " + $("#SSN").val() + "<br/><br/>" +
                                    "LOAN NUMBER : " + $("#LOANNUMBER").val() + "<br/><br/>" +
                                    "LOAN ORIGINATION DATE : " + LoanOriginationDate + "<br/><br/>" +
                                    "LOAN MATURITY DATE : " + LoanMaturityDate + "<br/><br/>" +
                                    "DATE LOAN DEFAULTED (IF APPLICABLE) : " + DateLoanDefaulted + "<br/><br/>" +
                                    "CURE PERIOD END DATE : " + CurePeriodEndDate + "<br/><br/>";
                                if ($.trim($("#NOTCURRENTLOAN").val()).length != 0) {
                                    hiddenDetails = hiddenDetails.concat("IF LOAN IS NOT CURRENT, HOW WILL IT BE BROUGHT CURRENT ONCE THE RECORD IS CORRECTED? : " + $("#NOTCURRENTLOAN").val() + "<br/><br/>");
                                }
                                hiddenDetails = hiddenDetails.concat("DESCRIBE THE CIRCUMSTANCES THAT LED TO THE NEED TO REVERSE DEFAULT : " + $("#LOANCIRCUMSTANCES").val() + "<br/><br/>" +
                                    "RECOMMENDED RESOLUTION : " + $("#Resolution").val() + "<br/><br/>");

                            } else if (referralType == "Testing") {
                                var checkedBoxes = [];
                                $('input[name="CONCERNTEST"]:checked').each(function() {
                                    checkedBoxes.push($(this).val());
                                });
                                hiddenDetails = "<br/><br/>" +
                                    "WHICH TEST IS OF CONCERN? : " + checkedBoxes + "<br/><br/>";
                                if (checkedBoxes.toString().indexOf("Other") != -1) {
                                    hiddenDetails = hiddenDetails.concat("Other (Describe) : " + $("#OTHERDESCRIBE").val() + "<br/><br/>");
                                }

                                hiddenDetails = hiddenDetails.concat("DESCRIBE WHAT OCCURRED : " + $("#PLANDESCOCCURRED").val() + "<br/><br/>" );
                                hiddenDetails = hiddenDetails.concat("WHAT STEPS HAS THE PLAN SPONSOR TAKEN TO CORRECT THE ISSUE? : " + $("#PLANSPONSORSTEPS").val() + "<br/><br/>");

                                if ($.trim($("#PLANADDITIONALQUE").val()).length != 0) {
                                    hiddenDetails = hiddenDetails.concat("WHAT ADDITIONAL QUESTIONS OR CONCERNS DOES THE PLAN SPONSOR HAVE? : " + $("#PLANADDITIONALQUE").val() + "<br/><br/>");
                                }
                                hiddenDetails = hiddenDetails.concat("WHAT DO YOU PROPOSE AS A SOLUTION? : " + $("#PLANPROPOSESOLUTIONTESTING").val() + "<br/><br/>");
                                if ($.trim($("#PLANADDITIONALQUE").val()).length != 0) {
                                    hiddenDetails = hiddenDetails.concat("WHAT QUESTIONS DO YOU HAVE REGARDING YOUR PROPOSED SOLUTION? : " + $("#PLANPROPOSEDQUES").val());
                                }
                            } else if (referralType == "Describe Line Request") {
                                hiddenDetails = "<br/><br/>" +
                                    "WHAT IS THE CURRENT PROVISION? : " + $("#PLANELECTIONCURRENTPRO").val() + "<br/><br/>" +
                                    "WHERE WILL THE DESCRIBE LINE APPEAR? : " + $("#PLANAPPEARDESCRIBELINE").val() + "<br/><br/>" +
                                    "WHAT IS THE PURPOSE OF USING \"DESCRIBE\"? : " + $("#PLANPURPOSEDESCRIBE").val() + "<br/><br/>" +
                                    "HOW WILL THE PROPOSED \"DESCRIBE\" LINE READ? : " + $("#PLANDESCRIBELINEREAD").val() + "<br/><br/>";


                            } else if (referralType == "Plan Document Issue/Question") {
                                hiddenDetails = "<br/><br/>" +
                                    "WHAT SECTION(S) OF THE DOCUMENT DOES THIS REQUEST IMPACT? : " + $("#PLANDOCREQUESTIMPACT").val() + "<br/><br/>" +
                                    "DESCRIBE WHAT OCCURRED : " + $("#PLANDESCWHATOCCURRED").val() + "<br/><br/>";
                                if ($.trim($("#PLANDESCSTEPSTOCORRECT").val()).length != 0) {
                                    hiddenDetails = hiddenDetails.concat("DESCRIBE WHAT STEPS THE PLAN SPONSOR HAS TAKEN TO CORRECT, IF APPLICABLE. : " + $("#PLANDESCSTEPSTOCORRECT").val() + "<br/><br/>");
                                }
                                if ($.trim($("#PLANSPONSORADDQUE").val()).length != 0) {
                                    hiddenDetails = hiddenDetails.concat("WHAT ADDITIONAL QUESTIONS/CONCERNS DOES THE PLAN SPONSOR HAVE? : " + $("#PLANSPONSORADDQUE").val() + "<br/><br/>");
                                }
                                hiddenDetails = hiddenDetails.concat("WHAT DO YOU PROPOSE AS A SOLUTION? : " + $("#PLANPROPOSESOLUTION").val() + "<br/><br/>");
                                if ($.trim($("#PLANSPONSORADDQUEPROPOSAL").val()).length != 0) {
                                    hiddenDetails = hiddenDetails.concat("WHAT QUESTIONS DO YOU HAVE REGARDING YOUR PROPOSAL ? : " + $("#PLANSPONSORADDQUEPROPOSAL").val() + "<br/><br/>");
                                }

                            } else {
                                hiddenDetails = "<br/><br/>" +
                                    "DESCRIPTION : " + $("#description").val() + "<br/><br/>" +
                                    "RECOMMENDED RESOLUTION : " + $("#Resolution").val() + "<br/><br/>";

                            }

                            $("#AILDETAILSBody").val(hiddenDetails);

                            var subject = $("input[name='referal']:checked").val() + " - " + $("#site").val() + " - " + $("#REFERRALTYPE").val() + " - RPS Compliance Referral Form";

                            $("#mailSubject").val(subject);



                        });
                    }

                    /*----------------------------RKD large trade---------------------------------------------------------------------------------------------*/

                    if ((document.URL).includes("rkd-multi-fund-large-trade-notification-form")) {

                        $("#hsos").parent().parent().css("display", "none");
                        $("#hsos1").parent().parent().css("display", "none");
                        $("#hsos2").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() {
                            var subjectLine = "RKD Multi-Fund Large Trade Notification - " + $("#Fplanid").val() + " - GW# " + $("#gwplan").val();
                            $("#mailSubject").val(subjectLine);

                            var selectedVal1 = $('select[name=state]').val();
                            if (selectedVal1 === "NY") {

                                if ($("#fund").val() == null) {
                                    $("#hsos").val(" ");
                                } else {
                                    $("#hsos").val('F');
                                }
                                if ($("#fund1").val() == null) {
                                    $("#hsos1").val(" ");
                                } else {
                                    $("#hsos1").val('F');
                                }
                                if ($("#fund2").val() == null) {
                                    $("#hsos2").val(" ");
                                } else {
                                    $("#hsos2").val('F');
                                }
                            } else {
                                if ($("#fund").val() == null) {
                                    $("#hsos").val(" ");
                                } else {
                                    $("#hsos").val('G');
                                }
                                if ($("#fund1").val() == null) {
                                    $("#hsos1").val(" ");
                                } else {
                                    $("#hsos1").val('G');
                                }

                                if ($("#fund2").val() == null) {
                                    $("#hsos2").val(" ");
                                } else {
                                    $("#hsos2").val('G');
                                }
                            }

                        });
                    }


                    /*------------------------------Reprint request for customer Enroll--------------------------------------------------------------*/


                    if ((document.URL).includes("reprint-request-for-customized-enrollment-guide-order")) {


                        $("#addllit").parent().parent().css("display", "none");
                         $("#dbdate").parent().parent().css("display", "none");
                        $("#pbdate").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() {

                            $("#chgcommBody").val($("#chgcomm").val());
                            var text = "";
                            var txt = "";
                            var n;
                            n = parseInt($("#dvdm").val());
                            if (n > 0) {
                                txt += "Enrollment DVD / ER Match: " + n + "<br/><br/>";
                            }
                            n = parseInt($("#dvdnm").val());
                            if (n > 0) {
                                txt += "Enrollment DVD / Without Match: " + n + "<br/><br/>";
                            }
                            n = parseInt($("#eps").val());
                            if (n > 0) {
                                txt += "Enrollment Payroll Stuffers (Teasers): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#seps").val());
                            if (n > 0) {
                                txt += "Enrollment Payroll Stuffers (Teasers): " + n + " (Spanish)<br/><br/>";
                            }
                            n = parseInt($("#emp").val());
                            if (n > 0) {
                                txt += "Enrollment Meeting Posters: " + n + "<br/><br/>";
                            }
                            n = parseInt($("#sepm").val());
                            if (n > 0) {
                                txt += "Enrollment Meeting Posters: " + n + " (Spanish)<br/><br/>";
                            }
                            n = parseInt($("#tss").val());
                            
                            if (n > 0) {
                                txt += "Value of saving over time (Non-participation): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#stss").val());
                            if (n > 0) {
                                txt += "Value of saving over time (Non-participation): " + n + " (Spanish)<br/><br/>";
                            }
                            n = parseInt($("#smiyr").val());
                            if (n > 0) {
                                txt += "Benefits of increasing contributions (Low Deferral): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#ssmiyr").val());
                            if (n > 0) {
                                txt += "Benefits of increasing contributions (Low Deferral): " + n + " (Spanish)<br/><br/>";
                            }
                            n = parseInt($("#cbtw").val());
                            if (n > 0) {
                                txt += "Roth vs. pre-tax contributions (Roth 401k/403b): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#scbtw").val());
                            if (n > 0) {
                                txt += "Roth vs. pre-tax contributions (Roth 401k/403b): " + n + " (Spanish)<br/><br/>";
                            }
                            n = parseInt($("#loans").val());
                            if (n > 0) {
                                txt += "Pros and cons of retirement plan loans (Loans): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#sloans").val());
                            if (n > 0) {
                                txt += "Pros and cons of retirement plan loans (Loans): " + n + " (Spanish)<br/><br/>";
                            }
                            n = parseInt($("#dyrp").val());
                            if (n > 0) {
                                txt += "Diversification:  Building your own portfolio (Diversification): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#iltf").val());
                            if (n > 0) {
                                txt += "Understanding market volatility (Market Volatility): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#kysot").val());
                            if (n > 0) {
                                txt += "Retirement plan options when leaving your employer (Rollovers): " + n + "<br/>";
                            }
                            n = parseInt($("#finprof").val());
                            if (n > 0) {
                                txt += "Working with a financial professional (Financial Professionals): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#sampnl").val());
                            if (n > 0) {
                                txt += "Sample newsletters (RKD only): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#ssampnl").val());
                            if (n > 0) {
                                txt += "Sample newsletters (RKD only): " + n + " (Spanish)<br/><br/>";
                            }
                            n = parseInt($("#tdf").val());
                            if (n > 0) {
                                txt += "One Fund. Many Benefits (Target Date Funds): " + n + "<br/><br/>";
                            }

                            n = parseInt($("#lyeb").val());
                            if (n > 0) {
                                txt += "Taking advantage of employer-matching contributions (Employer Match): " + n + "<br/><br/>";
                            }
                            n = parseInt($("#rtq").val());
                            if (n > 0) {
                                txt += "Asset Allocation Worksheet: " + n + "<br/><br/>";
                            }
                            n = parseInt($("#prmp").val());
                            if (n > 0) {
                                txt += "Progress Report Meeting Posters: " + n + "<br/><br/>";
                            }
                            n = parseInt($("#sprmp").val());
                            if (n > 0) {
                                txt += "Progress Report Meeting Posters: " + n + " (Spanish)<br/><br/>";
                            }
                            n = parseInt($("#prps").val());
                            if (n > 0) {
                                txt += "Progress Report Payroll Stuffers: " + n + "<br/><br/>";
                            }
                            n = parseInt($("#sprps").val());
                            if (n > 0) {
                                txt += "Progress Report Payroll Stuffers: " + n + " (Spanish)<br/><br/>";
                            }
                            n = parseInt($("#prosp").val());
                            if (n > 0) {
                                txt += "Prospectuses: " + n + "<br/><br/>";
                            }
                            n = parseInt($("#sprosp").val());
                            if (n > 0) {
                                txt += "Prospectuses: " + n + " (Spanish)<br/><br/>";
                            }
                            $("#addllit").val(txt);

                            var subjectLine = $("#planname").val() + " - Regular.Work.Reprints.";


$("#dbdate").val(setDate($("#delivdate").val()));
                            $("#pbdate").val(setpbdate());

                            $("#mailSubject").val(subjectLine);

                             function setDate(val) {

var dateVal = val;
var today = new Date(dateVal);
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var year = today.getFullYear().toString().substr(-2);
today = mm + '/' + dd + '/' + year;
                              return today;
                          }

                             function setpbdate() {
var today = new Date();
                                 today.setDate(today.getDate()+3);
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var year = today.getFullYear().toString().substr(-2);
today = mm + '/' + dd + '/' + year;
                              return today;
                            }
                        });
                    }
                    
/*----------------------------------------New plan maintence form---------------------------------------------------------------------*/


                    /*----------------------------------------New plan maintence form---------------------------------------------------------------------*/


                    if ((document.URL).includes("plan-maint-form")) {

                        $("#requestTypeHidden").parent().parent().css("display", "none");
                        $("#rushrequestTypeHidden").parent().parent().css("display", "none");
                        $("#tpaFeesBody").parent().parent().css("display", "none");


                        $(document).on("click", "[name='submit-btn']", function() {
                            var hiddenvalues = " ";
                            var requestTypeVal = "";
                            var genesysIdentifierVal = "";
                            if ($("#rushrequestType").val()==='YES'|| $("#rushrequestType").val()==='NO') {
                                requestTypeVal = "<br/><br/>RUSH REQUEST: " + $("#rushrequestType").val();
                            } else {
                                requestTypeVal = "";
                            }


                            $("#rushrequestTypeHidden").val(requestTypeVal);



                            var selectedVal = $("#rushrequestType").val();
                            if (selectedVal == null) {
                                genesysIdentifierVal = "";
                            }
                            else if (selectedVal == "YES") {
                                genesysIdentifierVal = "<br/><br/> GENESYS IDENTIFIER: REGULAR.WORK.FIN NEW PLAN MAINT.";
                            } else {
                                genesysIdentifierVal = "<br/><br/> GENESYS IDENTIFIER: REGULAR.WORK.NON-FIN NEW PLAN MAINT.";
                            }


                            var requestType = $("#requestType").val();

                            if (requestType == "Add/Remove money type") {
                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    "<br/><br/> ADD MONEY TYPE: " + $("#addMoneyType").val() +
                                    "<br/><br/> REMOVE MONEY TYPE: " + $("#removeMoneyType").val() +
                                    "<br/><br/> VESTING SCHEDULE FOR NEW MONEY TYPE: " + $("#addRemoveMoneyTypeVestingSchedule").val() +
                                    "<br/><br/> EFFECTIVE DATE OF VESTING SCHEDULE: " + setDate($("#addRemoveMoneyTypeEffectiveDate").val()) +
                                    "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE REORDERED?: " + setEnrollmentValues($("#enrollmentBookReorder").val()) +
                                    ($("#addRemoveMoneyTypeNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#addRemoveMoneyTypeNotes").val() : '');
                            } else if (requestType == "Vesting schedule update") {
                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    "<br/><br/> VESTING SCHEDULE FOR NEW MONEY TYPE : " + $("#vestingSchedule").val() +
                                    "<br/><br/> EFFECTIVE DATE OF VESTING SCHEDULE:" + setDate($("#effectiveDateForVestingSchedule").val()) +
                                    "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE REORDERED?: " + setEnrollmentValues($("#vestingScheduleEnrolBookReorder").val()) +
                                    ($("#vestingScheduleUpdateNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#vestingScheduleUpdateNotes").val() : '');
                            } else if (requestType == "Fund changes") {
                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    "<br/><br/> ADD FUNDS(S): " + $("#addFunds").val() +
                                    "<br/><br/> REMOVE FUNDS(S): " + $("#removeFunds").val() +
                                    "<br/><br/> EFFECTIVE DATE: " + setDate($("#fundChangesEffectiveDate").val()) +
                                    "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE ORDERED?: " + setEnrollmentValues($("#fundChangesChangeNotice").val()) +
                                    ($("#fundChangesNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#fundChangesNotes").val() : '');
                            } else if (requestType == "Fund changes") {
                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    "<br/><br/> LOAN REQUEST TYPE: " + $("#loanReqTypes").val() +
                                    "<br/><br/> EFFECTIVE DATE: " + setDate($("#loansEffectiveDate").val()) +
                                    "<br/><br/> PAYROLE FREQUENCY: " + $("#loansPayroleFrequency").val() +
                                    "<br/><br/> GENERAL PURPOSE YEARS: " + $("#loansGenPurposeYrs").val() +
                                    "<br/><br/> MORTAGE YEARS: " + $("#loansMortageYears").val() +
                                    "<br/><br/> MINIMUM AMOUNT: " + $("#loanMinAmount").val() +
                                    "<br/><br/> MAXIMUM AMOUNT: " + $("#loanMaxAmount").val() +
                                    "<br/><br/> #LOANS ALLOWED: " + $("#loansAllowed").val() +
                                    "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE ORDERED?: " + setEnrollmentValues($("#loanChangeNoticeReq").val()) +
                                    ($("#loanNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#loanNotes").val() : '');
                            } else if (requestType == "Plan Contacts") {
                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    ($("input[name=updatedPlanContactRPA]:checked") ? "<br/><br/> IC HAS UPDATED PLAN CONTACTS IN RPA :" + ' YES' : '') +
                                    "<br/><br/> PLAN SPONSORS TO ADD:" +
                                    "<br/><br/> NAME: " + $("#planSponcorName").val() +
                                    "<br/><br/> PHONE: " + $("#planSponcorName").val() +
                                    "<br/><br/> EMAIL: " + $("#planSponcorEmail").val() +
                                    (($("#additionaContactName").val().length > 0 || $("#additionaContactPhone").val().length > 0 || $("#additionaContactEmail").val().length > 0) ? "<br/><br/> ADDITIONAL CONTACT :" : '') +
                                    ($("#additionaContactName").val().length > 0 ? "<br/><br/> NAME :" + $("#additionaContactName").val() : '') +
                                    ($("#additionaContactPhone").val().length > 0 ? "<br/><br/> PHONE :" + $("#additionaContactPhone").val() : '') +
                                    ($("#additionaContactEmail").val().length > 0 ? "<br/><br/> EMAIL :" + $("#additionaContactEmail").val() : '') +
                                    ($("#planSponsorRemoveName").val().length > 0 ? "<br/><br/> PLAN SPONSORS TO REMOVE: NAME (s):" + $("#planSponsorRemoveName").val() : '') +
                                    "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE REORDERED?: " + setEnrollmentValues($("#planSponcorRemoveEnrollmentBookReorder").val()) +
                                    ($("#planContactNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#planContactNotes").val() : '');
                            } else if (requestType == "RIA - Adding Service Provider/RIA Contact") {
                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    "<br/><br/> DATE SALESCONNECT FORM WAS SUBMITTED: " + setDate($("#salesConnectFormDateSubmitted").val) +
                                    "<br/><br/> SERVICE PROVIDER: " + $("#riaServiceProvider").val() +
                                    "<br/><br/> PRIMARY REP/JOINT REP NAME(S): " + $("#riaRepJointName").val() +
                                    "<br/><br/> PRIMARY REP/JOINT REP ID: " + $("#riaRepJointID").val() +
                                    ($("#riaIndividualRepName1").val().length > 0 ? "<br/><br/> INDIVIDUAL REP NAME: :" + $("#riaIndividualRepName1").val() : '') +
                                    ($("#riaIndividualRepId1").val().length > 0 ? "<br/><br/> INDIVIDUAL REP ID: :" + $("#riaIndividualRepId1").val() : '') +
                                    ($("#riaIndividualRepName2").val().length > 0 ? "<br/><br/> INDIVIDUAL REP NAME: :" + $("#riaIndividualRepName2").val() : '') +
                                    ($("#riaIndividualRepId2").val().length > 0 ? "<br/><br/> INDIVIDUAL REP ID: :" + $("#riaIndividualRepId2").val() : '') +
                                    ($("input[name=riaUpdatedPlanContactsRpa]:checked") ? "<br/><br/> IC HAS UPDATED RIA CONTACT INFO IN RPA :" + ' YES' : '') +
                                    ($("#riaNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#riaNotes").val() : '');
                            } else if (requestType == "TPA Fees") {
								var value = "";
                                if($("input[name=tpaFeesRemoveLoanFee]:checked").val() == "Remove Loan Fee") {

                                    value =  "<br/><br/> REMOVE LOAN FEE :" + ' YES' ;

                                } else {

                                    value = "";

                                }

                                var value1 = "";
                                if($("input[name=tpaFeesRemoveDistributionFee]:checked").val() == "Remove Distribution Fee") {

                                    value1 =   "<br/><br/> REMOVE DISTRIBUTION FEE :" + ' YES';

                                } else {

                                    value1 = "";

                                }
                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    "<br/><br/> EFFECTIVE DATE: " + setDate($("#tpaFeesEffectiveDate").val()) +
                                    "<br/><br/> ADD LOAN FEE AMOUNT: " + $("#tpaFeesLoanFee").val() +
                                    "<br/><br/> ADD DISTRIBUTION FEE AMOUNT: " + $("#tpaFeesDistributionFee").val() +
                                     value + value1 + 

                                    "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE REORDERED?: " + setEnrollmentValues($("#tpaFeesChangeNeeded").val()) +
                                    ($("#tpaFeesNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#tpaFeesNotes").val() : '');

                            } else if (requestType == "Close Plan") {

                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    ($("input[name=closePlanWarningNoteInRpa]:checked") ? "<br/><br/> IC HAS ADDED A WARNING NOTE IN RPA :" + ' YES' : '') +
                                    ($("input[name=closePlanUpdatedStatus]:checked") ? "<br/><br/> IC HAS UPDATED PLAN STATUS TO 'PLAN NOT ACCEPTED' IN RPA :" + ' YES' : '') +
                                    ($("#closePlanNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#closePlanNotes").val() : '');
                            } else if (requestType == "Fiduciary Services") {

                                var value2 = "";
                                if($("input[name=wilshirefiduciaryServiceUpdatedInRpa]:checked").val() == " Wilshire Fiduciary Services - IC has updated the Fiduciary Services section in RPA.") {

                                    value2 =  "<br/><br/> " + $("#wilshirefiduciaryServiceUpdatedInRpa").val() + " : " + ' YES' ;

                                } else {

                                    value2 = "";

                                }

                                var value3 = "";
                                if($("input[name=wilshirefiduciaryServiceUpdatedInRpa]:checked").val() == "Non-Wilshire Fiduciary Services - IC has added note in RPA with specifics.") {

                                     value3 = "<br/><br/>Non-Wilshire Fiduciary Services - IC has added note in RPA with specifics. :" + ' YES'; ;

                                } else {

                                    value3 = "";

                                }

                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    "<br/><br/> SERVICE LEVEL: " + $("#fiduciaryServiceLevel").val() +
                                    value2+value3+
                                    ($("#fiduciaryServiceNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#fiduciaryServiceNotes").val() : '');
                            } else if (requestType == "Fiduciary Services") {
                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    ($("input[name=planSetupErrorsUpdatesToRpa]:checked") ? "<br/><br/> IC HAS UPDATED ANY APPLICABLE UPDATES TO RPA. : " + ' YES' : '') +
                                    "<br/><br/> DESCRIBE ERROR/CORRECTIVE ACTION NEEDED: " + $("#planSetupErrorsCorrectiveAction").val() +
                                    "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE REORDERED?: " + setEnrollmentValues($("#planSetupErrorsEnrollmentBooksReorder").val());
                            } else if (requestType == "Fee Level Recovery") {

                                var value4 = "";
                                if($("input[name=feeLevelRecoveryCommissionable]:checked").val() == "Commissionable") {

                                    value4 =  "<br/><br/> COMMISSIONABLE : " + ' YES';

                                } else {

                                    value4 = "";

                                }

                                 var value5 = "";
                                if($("input[name=feeLevelRecoveryRecapture]:checked").val() == "Recapture (Commissionable Share Class)") {

                                    value5 =  "<br/><br/> RECAPTURE (COMMISSIONABLE SHARE CLASS): " + ' YES' ;

                                } else {

                                    value5 = "";

                                }

                                 var value6 = "";
                                if($("input[name=feeLevelRecoveryFeeInvoice]:checked").val() == "Fees invoice directly to the plan sponsor.") {

                                    value6 =   "<br/><br/> FEES INVOICE DIRECTLY TO THE PLAN SPONSOR: " + ' YES' ;

                                } else {

                                    value6 = "";

                                }

                                 var value7 = "";
                                if($("input[name=feeLevelRecoveryForFP]:checked").val() == " Recovery for FP (Fee-based Share Class)") {

                                    value7 =    "<br/><br/> RECOVERY FOR FP(FEE-BASED SHARE CLASS): " + ' YES';

                                } else {

                                    value7 = "";

                                }

                                 var value8 = "";
                                if($("input[name=feeLevelRecoveryForTPA]:checked").val() == "Recovery for TPA") {

                                    value8 =    "<br/><br/> RECOVERY FOR TPA: " + ' YES';

                                } else {

                                    value8 = "";

                                }

                                 var value9 = "";
                                if($("input[name=feeLevelRecoveryExternal]:checked").val() == "External (Fee-Based Share Class)") {

                                    value9 =    "<br/><br/> EXTERNAL(FEE-BASED SHARE CLASS): " + ' YES';

                                } else {

                                    value9 = "";

                                }


                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    value4+value5+

                                    ($("#feeLevelRecoveryDollarAmt").val().length > 0 ? "<br/><br/> DOLLAR AMOUNT:" + $("#feeLevelRecoveryDollarAmt").val() : '') +
                                    ($("#feeLevelRecoveryBasisPoint").val().length > 0 ? "<br/><br/> BASIS POINT (E.G. ## BASIS POINTS):" + $("#feeLevelRecoveryBasisPoint").val() : '') +
                                    value6+value7+

                                    ($("#feeLevelRecoveryFPBasisPoint").val().length > 0 ? "<br/><br/> BASIS POINT (E.G. ## BASIS POINTS):" + $("#feeLevelRecoveryFPBasisPoint").val() : '') +
                                    ($("#feeLevelRecoveryFPProRata").val().length > 0 ? "<br/><br/> AMOUNT PER PLAN PRO RATA:" + $("#feeLevelRecoveryFPProRata").val() : '') +
                                    ($("#feeLevelRecoveryFPPerCapita").val().length > 0 ? "<br/><br/> AMOUNT PER PLAN PER CAPITA:" + $("#feeLevelRecoveryFPPerCapita").val() : '') +
                                    ($("#feeLevelRecoveryFPPerParticipant").val().length > 0 ? "<br/><br/> FLAT DOLLER AMOUNT PER PARTICIPANT:" + $("#feeLevelRecoveryFPPerParticipant").val() : '') +
                                    value8+
                                    ($("#feeLevelRecoveryTPABasisPoint").val().length > 0 ? "<br/><br/> BASIS POINT (E.G. ## BASIS POINTS):" + $("#feeLevelRecoveryTPABasisPoint").val() : '') +
                                    ($("#feeLevelRecoveryTPAProRata").val().length > 0 ? "<br/><br/> AMOUNT PER PLAN PRO RATA:" + $("#feeLevelRecoveryTPAProRata").val() : '') +
                                    ($("#feeLevelRecoveryTPAPerCapita").val().length > 0 ? "<br/><br/> AMOUNT PER PLAN PER CAPITA:" + $("#feeLevelRecoveryTPAPerCapita").val() : '') +
                                    ($("#feeLevelRecoveryTPAPerParticipant").val().length > 0 ? "<br/><br/> FLAT DOLLER AMOUNT PER PARTICIPANT:" + $("#feeLevelRecoveryTPAPerParticipant").val() : '') +
                                    value9+
                                    ($("#feeLevelRecoveryAdvisoryAccNum").val().length > 0 ? "<br/><br/> ADVISORY FIRM PLAN ACCOUNT NUMBER:" + $("#feeLevelRecoveryAdvisoryAccNum").val() : '') +
                                    "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE REORDERED?: " + setEnrollmentValues($("#feelevelrecoveryenrol").val()) +
                                    ($("#feeLevelRecoveryNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#feeLevelRecoveryNotes").val() : '');
                            } else if (requestType == "Fee Level Recovery") {
                                hiddenvalues += $("#requestType").val() + genesysIdentifierVal +
                                    ($("#addRemoveAfflAddContact").val().length > 0 ? "<br/><br/> CONTACT TYPE TO ADD :" + $("#addRemoveAfflAddContact").val() : '') +
                                    ($("#addRemoveAfflCompanyName1").val().length > 0 ? "<br/><br/> COMPANY NAME 1 :" + $("#addRemoveAfflCompanyName1").val() : '') +
                                    ($("#addRemoveAfflAttn1").val().length > 0 ? "<br/><br/> ATTENTION 1 :" + $("#addRemoveAfflAttn1").val() : '') +
                                    ($("#addRemoveAfflPhone1").val().length > 0 ? "<br/><br/> PHONE NUMBER 1 :" + $("#addRemoveAfflPhone1").val() : '') +
                                    ($("#addRemoveAfflAddress1").val().length > 0 ? "<br/><br/> ADDRESS 1 :" + $("#addRemoveAfflAddress1").val() : '') +
                                    ($("#addRemoveAfflTaxId1").val().length > 0 ? "<br/><br/> TAX ID 1 :" + $("#addRemoveAfflTaxId1").val() : '') +
                                    ($("#addRemoveAfflCompanyName2").val().length > 0 ? "<br/><br/> COMPANY NAME 2 :" + $("#addRemoveAfflCompanyName2").val() : '') +
                                    ($("#addRemoveAfflAttn2").val().length > 0 ? "<br/><br/> ATTENTION 2 :" + $("#addRemoveAfflAttn2").val() : '') +
                                    ($("#addRemoveAfflPhone2").val().length > 0 ? "<br/><br/> PHONE NUMBER 2 :" + $("#addRemoveAfflPhone2").val() : '') +
                                    ($("#addRemoveAfflAddress2").val().length > 0 ? "<br/><br/> ADDRESS 2 :" + $("#addRemoveAfflAddress2").val() : '') +
                                    ($("#addRemoveAfflTaxId2").val().length > 0 ? "<br/><br/> TAX ID 2 :" + $("#addRemoveAfflTaxId2").val() : '') +
                                    ($("#addRemoveAfflLocationToRemove").val().length > 0 ? "<br/><br/> AFFILIATE/LOCATION TO REMOVE: :" + $("#addRemoveAfflLocationToRemove").val() : '') +
                                    ($("#addRemoveAfflNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#addRemoveAfflNotes").val() : '');
                            }
                            else if (requestType == "Loans") {
                                hiddenvalues += requestType + genesysIdentifierVal +
                     "<br/><br/> LOAN REQUEST TYPE: "+$("#loanReqTypes").val() +
                     "<br/><br/> EFFECTIVE DATE: "+setDate($("#loansEffectiveDate").val()) +
                     "<br/><br/> PAYROLE FREQUENCY: "+$("#loansPayroleFrequency").val() +
                    "<br/><br/> GENERAL PURPOSE YEARS: "+$("#loansGenPurposeYrs").val() +
                     "<br/><br/> MORTAGE YEARS: "+$("#loansMortageYears").val() +
                     "<br/><br/> MINIMUM AMOUNT: "+$("#loanMinAmount").val() +
                     "<br/><br/> MAXIMUM AMOUNT: "+$("#loanMaxAmount").val() +
                     "<br/><br/> #LOANS ALLOWED: "+$("#loansAllowed").val() +
                     "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE ORDERED?: "+setEnrollmentValues($("#loanChangeNoticeReq").val()) +
                     ($("#loanNotes").val().length > 0 ? "<br/><br/> NOTES :"+ $("#loanNotes").val() : '');
} else if (requestType == "Plan Setup Errors") {
                                hiddenvalues += requestType + "<br/><br/> GENESYS IDENTIFIER: REGULAR.WORK.FIN NEW PLAN MAINT." +
                     ($("input[name=planSetupErrorsUpdatesToRpa]:checked") ? "<br/><br/> IC HAS UPDATED ANY APPLICABLE UPDATES TO RPA. : "+ ' YES' : '') +
                     "<br/><br/> DESCRIBE ERROR/CORRECTIVE ACTION NEEDED: "+$("#planSetupErrorsCorrectiveAction").val() +
                     "<br/><br/> DO ENROLLMENT GUIDES NEED TO BE REORDERED?: "+setEnrollmentValues($("#planSetupErrorsEnrollmentBooksReorder").val());

} else if(requestType == "Add/Remove Affiliate/Location") {
                     hiddenvalues += requestType + genesysIdentifierVal +
                     ($("#addRemoveAfflAddContact").val().length > 0 ? "<br/><br/> CONTACT TYPE TO ADD :"+$("#addRemoveAfflAddContact").val() : '')+
                     ($("#addRemoveAfflCompanyName1").val().length > 0 ? "<br/><br/> COMPANY NAME 1 :"+$("#addRemoveAfflCompanyName1").val() : '') +
                     ($("#addRemoveAfflAttn1").val().length > 0 ? "<br/><br/> ATTENTION 1 :"+$("#addRemoveAfflAttn1").val() : '') +
                     ($("#addRemoveAfflPhone1").val().length > 0 ? "<br/><br/> PHONE NUMBER 1 :"+$("#addRemoveAfflPhone1").val() : '') +
                     ($("#addRemoveAfflAddress1").val().length > 0 ? "<br/><br/> ADDRESS 1 :"+$("#addRemoveAfflAddress1").val() : '') +
                     ($("#addRemoveAfflTaxId1").val().length > 0 ? "<br/><br/> TAX ID 1 :"+$("#addRemoveAfflTaxId1").val() : '') +
                     ($("#addRemoveAfflCompanyName2").val().length > 0 ? "<br/><br/> COMPANY NAME 2 :"+$("#addRemoveAfflCompanyName2").val() : '') +
                     ($("#addRemoveAfflAttn2").val().length > 0 ? "<br/><br/> ATTENTION 2 :"+$("#addRemoveAfflAttn2").val() : '') +
                     ($("#addRemoveAfflPhone2").val().length > 0 ? "<br/><br/> PHONE NUMBER 2 :"+$("#addRemoveAfflPhone2").val() : '') +
                     ($("#addRemoveAfflAddress2").val().length > 0 ? "<br/><br/> ADDRESS 2 :"+$("#addRemoveAfflAddress2").val() : '') +
                     ($("#addRemoveAfflTaxId2").val().length > 0 ? "<br/><br/> TAX ID 2 :"+$("#addRemoveAfflTaxId2").val() : '') +
                     ($("#addRemoveAfflLocationToRemove").val().length > 0 ? "<br/><br/> AFFILIATE/LOCATION TO REMOVE: :"+$("#addRemoveAfflLocationToRemove").val() : '') +
                     ($("#addRemoveAfflNotes").val().length > 0 ? "<br/><br/> NOTES :"+$("#addRemoveAfflNotes").val() : '');
} else {
                                hiddenvalues += "";
                            }

                            $("#requestTypeHidden").val(hiddenvalues);

                            function setDate(val) {



var dateVal = val;
var today = new Date(dateVal);
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
today = mm + '/' + dd + '/' + yyyy;
                              return today;



                            }


                            function setEnrollmentValues(val) { // set values of Enrollment div
                                var setHiddenValues = "";
                                alert(val);
                                if (val == "YES") {
                                    setHiddenValues += " YES " +
                                        "<br/><br/> DELIVERY DATE: " + setDate($("#enrollBooksDeliveryDate").val()) +
                                        "<br/><br/> #ENGLISH GUIDES NEEDED: " + $("#enrollBooksEngBooksNeeded").val() +
                                        "<br/><br/> #SPANISH GUIDES NEEDED: " + $("#enrollBooksSpanBooksNeeded").val() +
                                        "<br/><br/> SHIP TO:" +
                                        "<br/><br/> Company Name: " + $("#enrollBooksShipCompanyName").val() +
                                        "<br/><br/> ATTN: " + $("#enrollBooksShipAttn").val() +
                                        "<br/><br/> STREET: " + $("#enrollBooksShipStreet").val() +
                                        "<br/><br/> CITY: " + $("#enrollBooksShipCity").val() +
                                        "<br/><br/> STATE: " + $("#enrollBooksShipState").val() +
                                        "<br/><br/> ZIP CODE: " + $("#enrollBooksShipZipCode").val() +
                                        ($("#enrollBooksNotes").val().length > 0 ? "<br/><br/> NOTES :" + $("#enrollBooksNotes").val() : '');

                                } else {
                                    setHiddenValues += val;
                                }
                                return setHiddenValues;
                            }
                            var subjectLine = "New Plan Maintenance Form - Request Type - " + $("#requestType").val();
                        });
                    }


/*------------------------------------------participant check stop payment cancellation---------------------------------------------------------*/


                    if ((document.URL).includes("participant-check-stop-payment-cancellation")) {

                        $("#rushBody").parent().parent().css("display", "none");
                        $("#STOPCANCELbody").parent().parent().css("display", "none");

                        $(document).on("click", "[name='submit-btn']", function() {
                            var subjectLine = "Payment/Cancellation - ";
                            subjectLine += $("#site").val();
                            subjectLine += " - ";
                            if($('input[name="rush"]')[0].checked) {
                                subjectLine += "RUSH - ";
                            }
                            subjectLine += $("#plan_id").val();

                            if ($('input[name="stop_cancel"]:checked')) {
                                var stop_cancel = "";
                                var stop = $('input[name="stop_cancel"]:checked').val();

                                if (stop == "Y") {
                                    stop_cancel = "STOP: Y         CANCEL: N";
                                } else if (stop == "N") {
                                    stop_cancel = "STOP: N         CANCEL: Y";
                                }

                                $("#STOPCANCELbody").val(stop_cancel);
                                
                                
                            }
                            if ($("#rush").prop('checked')) {
                                $("#rushBody").val("YES");
                            }
                            if (!$("#rush").prop('checked')) {
                                $("#rushBody").val("NO");
                            }
                            $("#mailSubject").val(subjectLine);
                        });
                    }
                   


                    /*------------------------------------------COPY OF CASHED CHECK REQUEST-----------------------------------------------------------------------------------------*/

                    if ((document.URL).includes("copy-of-cashed-check-request")) {

                        $("#accountnoteBody").parent().parent().css("display", "none");
                        $("#ACCNOTEHIDDEN").parent().parent().css("display", "none");

                        $(document).on("click", "[name='submit-btn']", function() {

                            if ($("#ACCNOTE").prop('checked')) {

                                $("#ACCNOTEHIDDEN").val("Y");

                            } else {
                                $("#ACCNOTEHIDDEN").val("N");
                            }

                            var accountNumbers = new Array();
                            var subjectLine = "Copy of Cashed Check Request - ";
                            var site = $("#SITE").val();
                            var subjectLine = subjectLine + site + " - ";
                            $("[name='account']").each(function() {
                                if (jQuery.inArray($(this).val(), accountNumbers) == -1) {
                                    accountNumbers.push(Number($(this).val()));

                                }
                            });
                            var uniqueAccountNumbers = new Array();
                            var numberOfAccounts = accountNumbers.length;

                            for (var i = 0; i < numberOfAccounts; i++) {
                                for (var j = i + 1; j < numberOfAccounts; j++)
                                    if (accountNumbers[i] === accountNumbers[j]) {
                                        j = ++i;
                                    }
                                uniqueAccountNumbers.push(accountNumbers[i]);
                            }

                            uniqueAccountNumbers = uniqueAccountNumbers.sort(sortNumber);
                            for (var i = 1; i < uniqueAccountNumbers.length; ++i) {
                                if (i == 1) {
                                    subjectLine += (uniqueAccountNumbers[i]);
                                } else {
                                    subjectLine += ", " + (uniqueAccountNumbers[i]);
                                }
                            }

                            function sortNumber(a, b) {
                                return a - b;
                            }

                            $("#mailSubject").val(subjectLine);
                        });

                    }
                    
                    /*---------------------------------------------------SHARE REQUIREMENT FEEDBACK FORM-----------------------------------------------------------------------------*/

                    if ((document.URL).includes("share-requirements-feedback-form")) 
       			{
       				$("#modifiedDate").parent().parent().css("display", "none");			
                        $(document).on("click", "[name='submit-btn']", function() {
       					$("#modifiedDate").val(new Date());
       					var sample="<body style='font-family: Arial; font-size: 10pt;'><p>** Please do not reply to this email**</p><p>This is notification that #initials# has submitted SHARE REQ content feedback.</p><table style='border-collapse: collapse;width: 40%;border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'><th colspan=2 bgcolor='#D3D3D3' style='text-align: left;border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'>Details</th><tr><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'><strong>Associate:</td><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'>INYMTHM</td></tr><tr><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'><strong>Date submitted:</td><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'>$modifiedDate$</td></tr><tr><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'><strong>Title:</td><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'></td></tr><tr><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'><strong>Content Type:</td><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'>$Choosecontenttype$</td></tr><tr><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'><strong>Feedback:</td><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'>$information$</td></tr><tr><td style='border: 1px solid #e6e6f9;font-family: Arial; font-size: 10pt;'><strong>REQ URL:</td><td></td></tr></table></body>"
       					$("#email_body").val(sample);
       					});	
       			}
       			
       			
       /*---------------------------------------------------WEB RESOLUTION CASE-----------------------------------------------------------------------------*/

                    if ((document.URL).includes("web-resolution-case")) 
       			{
       				$("#ONETIMEPASSCODEHIDDEN").parent().parent().css("display", "none");			
       				$("#ONETIMEPASSCODEYESHIDDEN").parent().parent().css("display", "none");			
       				$("#REPIDSEQUENCEADVISORHIDDEN").parent().parent().css("display", "none");			
       				$("#CLIENTACCREPVISIONIDHIDDEN").parent().parent().css("display", "none");			
       				$("#DSTVISIONREPVISIONIDHIDDEN").parent().parent().css("display", "none");			
       				$("#OTHERQUICKENTURBOHRHIDDEN").parent().parent().css("display", "none");			
       				$("#STEPSADDITIONALDETAILSHIDDEN").parent().parent().css("display", "none");			
       				$("#DEVICETYPECALLERHIDDEN").parent().parent().css("display", "none");			
       				$("#OPERATINGSYSTEMCALLERHIDDEN").parent().parent().css("display", "none");			
       				$("#BROWSERCALLERVERSIONHIDDEN").parent().parent().css("display", "none");			
       				$("#ALTERNATEBROWSERHIDDEN").parent().parent().css("display", "none");			
                        $(document).on("click", "[name='submit-btn']", function() {				    
       					
       					var ONETIMEPASSCODEHIDDENBODY;
       					var ONETIMEPASSCODEYESHIDDENBODY;
       					if($("#WEBSITE").val() == "Investor Website")
       					{
       						if ($("[name='onetimepasscode']")[0].checked)
       						{
       							ONETIMEPASSCODEHIDDENBODY="<font color='blue' size='3'>One-time passcode error/issue: </font><font size='3'><span>YES</span></font><br/>";
       							if($("#carrier").val().trim().length != 0 ){
       								ONETIMEPASSCODEYESHIDDENBODY = "<font color='blue' size='3'>Who is the carrier?: </font><font size='3'><span>"+ $("#carrier").val() + "</span></font><br/>";
       							}
       							if($("#deliver").val().trim().length != 0 ){
       								ONETIMEPASSCODEYESHIDDENBODY  += "<font color='blue' size='3'>Where was it delivered to?: </font><font size='3'><span>"+ $("#deliver").val()+ "</span></font><br/>";			
       							}
       						}
       						else{
       							ONETIMEPASSCODEHIDDENBODY="<font color='blue' size='3'>One-time passcode error/issue: </font><font size='3'><span>NO</span></font><br/>";;
       						}
       					}
       					else
       					{
       						ONETIMEPASSCODEHIDDENBODY="";
       						ONETIMEPASSCODEYESHIDDENBODY="";
       					}
       					$("#ONETIMEPASSCODEHIDDEN").val(ONETIMEPASSCODEHIDDENBODY);
       					$("#ONETIMEPASSCODEYESHIDDEN").val(ONETIMEPASSCODEYESHIDDENBODY);
       					
       					var REPIDSEQUENCEADVISORHIDDENBODY;
       					if($("#WEBSITE").val() == "Advisor Website")
       					{
       						if($("#repidsequence").val().trim().length == 0)
       						{
       							;
       						}
       						else
       						{
       							REPIDSEQUENCEADVISORHIDDENBODY = "<font color='blue' size='3'>Rep ID or Sequence # : </font><font size='3'>&nbsp;<span>"+ $("#repidsequence").val() + "</span></font><br/>";			
       						}
       					}
       					else
       					{
       						REPIDSEQUENCEADVISORHIDDENBODY ="";
       					}
       					$("#REPIDSEQUENCEADVISORHIDDEN").val(REPIDSEQUENCEADVISORHIDDENBODY);
       					
       					var CLIENTACCREPVISIONIDHIDDENBODY;
       				
       					if($("#WEBSITE").val() == "Client Accounts"){
       						if($("#clientaccrepid").val().trim().length == 0){
       							;
       						}
       						else{
       							CLIENTACCREPVISIONIDHIDDENBODY = "<font color='blue' size='3'>Rep ID : </font><font size='3'><span>"+ $("#clientaccrepid").val() + "</span></font>";			
       						}
       						
       						if($("#clientaccvisionid").val().trim().length == 0){
       							;
       						}else{
       							CLIENTACCREPVISIONIDHIDDENBODY += "&nbsp;&nbsp;&nbsp;<font color='blue' size='3'>Vision ID : </font><font size='3'><span>"+ $("#clientaccvisionid").val() + "</span></font><br/>";			
       						}		
       					}
       					else{
       						CLIENTACCREPVISIONIDHIDDENBODY="";
       					}
       					$("#CLIENTACCREPVISIONIDHIDDEN").val(CLIENTACCREPVISIONIDHIDDENBODY);
       					
       					var DSTVISIONREPVISIONIDHIDDENBODY;
       					if($("#WEBSITE").val() == "DST Vision")
       					{
       						if($("#clientaccrepid").val().trim().length == 0){
       							;
       						}else{
       							DSTVISIONREPVISIONIDHIDDENBODY = "<font color='blue' size='3'>Rep ID : </font><font size='3'><span>"+ $("#clientaccrepid").val() + "</span></font>";			
       						}
       						
       						if($("#clientaccvisionid").val().trim().length == 0){
       							;
       						}else{
       							DSTVISIONREPVISIONIDHIDDENBODY += "&nbsp;&nbsp;&nbsp;<font color='blue' size='3'>Vision ID : </font><font size='3'><span>"+ $("#clientaccvisionid").val() + "</span></font><br/>";			
       						}		
       					}
       					else{
       						DSTVISIONREPVISIONIDHIDDENBODY="";
       					}	
       					$("#DSTVISIONREPVISIONIDHIDDEN").val(DSTVISIONREPVISIONIDHIDDENBODY);
       					
       					var OTHERQUICKENTURBOHRHIDDENBODY;
       					if($("#WEBSITE").val()  == "Other (e.g., Quicken, Turbo Tax, HR Block)")
       					{
       						if($("#otherquickenturbohr").val().trim().length  == 0){
       							;
       						}else{
       							OTHERQUICKENTURBOHRHIDDENBODY = "<font size='3'><span>"+ $("#otherquickenturbohr").val() + "</span></font><br/>";			
       						}				
       					}
       					else{
       						OTHERQUICKENTURBOHRHIDDENBODY="";
       					}	
       					$("#OTHERQUICKENTURBOHRHIDDEN").val(OTHERQUICKENTURBOHRHIDDENBODY);
       	
       					var STEPSADDITIONALDETAILSHIDDENBODY;
       					
       					if($("#stepsadditionaldetails").val().trim().length != 0){
       						STEPSADDITIONALDETAILSHIDDENBODY = "<br/><font color='blue' size='3'>STEPS TAKEN/ADDITIONAL DETAILS: </font><font size='3'><span>"+ $("#stepsadditionaldetails").val() + "</span></font><br/><br/>";			
       					}
       					else{
       						STEPSADDITIONALDETAILSHIDDENBODY="";
       					}	
       					$("#STEPSADDITIONALDETAILSHIDDEN").val(STEPSADDITIONALDETAILSHIDDENBODY);	

       					
       					var DEVICETYPECALLERHIDDENBODY;
       					if($("#devicetypecaller").val().trim().length !=0){
       						DEVICETYPECALLERHIDDENBODY = "<font color='blue' size='3'>What type of device is the caller using?: </font><font size='3'><span>"+ $("#devicetypecaller").val() + "</span></font><br/><br/>";			
       					}
       					else{
       						DEVICETYPECALLERHIDDENBODY="";
       					}
       					$("#DEVICETYPECALLERHIDDEN").val(DEVICETYPECALLERHIDDENBODY);
       					
       					var OPERATINGSYSTEMCALLERHIDDENBODY;
       					if($("#operatingsystemcaller").val().trim().length !=0){
       						OPERATINGSYSTEMCALLERHIDDENBODY = "<font color='blue' size='3'>What operating system is the caller using?: </font><font size='3'><span>"+ $("#operatingsystemcaller").val() + "</span></font><br/><br/>";			
       					}
       					else{
       						OPERATINGSYSTEMCALLERHIDDENBODY="";
       					}
       					$("#OPERATINGSYSTEMCALLERHIDDEN").val(OPERATINGSYSTEMCALLERHIDDENBODY);
       									
       					var BROWSERCALLERVERSIONHIDDENBODY;
       					if($("#browsercaller").val().trim().length  !=0){
       						BROWSERCALLERVERSIONHIDDENBODY = "<font color='blue' size='3'>What browser is the caller using?: </font><font size='3'><span>"+ $("#browsercaller").val() + "</span></font><br/>";			
       						
       						if($("#browserversion").val().trim().length != 0){
       							BROWSERCALLERVERSIONHIDDENBODY+= "<font color='blue' size='3'>Browser version: </font><font size='3'><span>"+ $("#browserversion").val() + "</span></font><br/><br/>";			
       						}		
       					}
       					else{
       						BROWSERCALLERVERSIONHIDDENBODY="";
       					}
       					$("#BROWSERCALLERVERSIONHIDDEN").val(BROWSERCALLERVERSIONHIDDENBODY);
       					
       					
       					var ALTERNATEBROWSERHIDDENBODY;
       					if($("#alternatebrowser").val().trim().length  !=0){
       						ALTERNATEBROWSERHIDDENBODY = "<font color='blue' size='3'>What alternate browser or alternate device were used?: </font><font size='3'><span>"+ $("#alternatebrowser").val()+ "</span></font><br/>";									
       						if($("#alternatebrowserversion").val().trim().length != 0){
       							ALTERNATEBROWSERHIDDENBODY += "<font color='blue' size='3'>Browser version: </font><font size='3'><span>"+ $("#alternatebrowserversion").val() + "</span></font><br/><br/>";			
       						}
       					}
       					else{
       						ALTERNATEBROWSERHIDDENBODY="";
       					}	
       					$("#ALTERNATEBROWSERHIDDEN").val(ALTERNATEBROWSERHIDDENBODY);
       					});	
       			}		
       			

                    /*------------------------------------------COPY OF CASHED CHECK REQUEST RKD-----------------------------------------------------------------------------------------*/

                    if ((document.URL).includes("copy-of-cashed-check-request-rkd")) {

                        $("#ACCNOTEHIDDEN").parent().parent().css("display", "none");
                        $("#viewableHidden").parent().parent().css("display", "none");

                        $(document).on("click", "[name='submit-btn']", function() {
                            if ($("#ACCNOTE").prop('checked')) {

                                $("#ACCNOTEHIDDEN").val("Y");

                            } else {
                                $("#ACCNOTEHIDDEN").val("N");
                            }

                            if ($("#viewableInShare").prop('checked')) {

                                $("#viewableHidden").val("Y");

                            } else {
                                $("#viewableHidden").val("N");
                            }


                        });
                    }


                    /*--------------------------------------- CDSC Payment To Funds Form --------------------------------------------------*/
                    if ((document.URL).includes("cdsc-payment-to-funds-form")) {

                        $("#totalHidden").parent().parent().css("display", "none");
                        $(document).on("click", "[name='submit-btn']", function() {

                            var accountNumbers = new Array();
                            var subjectLine = "CDSC FEES - ";
                            var site = $("#SITE").val();
                            var subjectLine = subjectLine + site + " - ";
                            $("[name='account_cdsc']").each(function() {
                                if (jQuery.inArray($(this).val(), accountNumbers) == -1) {
                                    accountNumbers.push(Number($(this).val()));

                                }
                            });
                            var uniqueAccountNumbers = new Array();
                            var numberOfAccounts = accountNumbers.length;

                            for (var i = 0; i < numberOfAccounts; i++) {
                                for (var j = i + 1; j < numberOfAccounts; j++)
                                    if (accountNumbers[i] === accountNumbers[j]) {
                                        j = ++i;
                                    }
                                uniqueAccountNumbers.push(accountNumbers[i]);
                            }

                            uniqueAccountNumbers = uniqueAccountNumbers.sort(sortNumber);
                            for (var i = 0; i < uniqueAccountNumbers.length; ++i) {
                                if (i == 0) {
                                    subjectLine += (uniqueAccountNumbers[i]);
                                } else {
                                    subjectLine += ", " + (uniqueAccountNumbers[i]);
                                }
                            }

                            function sortNumber(a, b) {
                                return a - b;
                            }

                            var totalDisplay = $("#sumdisp").text().trim();
                            var totalArray = totalDisplay.split(":");
                            var finalTotal = "TOTAL:                       " + totalArray[1];
                            $("#totalHidden").val(finalTotal);
                            $("#mailSubject").val(subjectLine);
                        });

                    }



                    /* ---------- Drop Down, check box, text field and Radio button ---------*/

                    var arr = new Array(0);
                    var brr = new Array(0);
                    window.crr = Array(0);
                    $('#html_form').find($('*:hidden')).each(function() {

                        if ($(this).parent().parent().parent().css('display') === 'none' && $(this).parent().prop("required")) {

                            if (jQuery.inArray($(this).parent().attr("id"), arr) == -1) {
                                arr.push($(this).parent().attr("id"));
                            }
                            $(this).parent().prop("required", false);

                        } else if ($(this).parent().parent().css('display') === 'none' && $(this).prop("required")) {
                            if (jQuery.inArray($(this).attr("id"), arr) == -1) {
                                arr.push($(this).attr("id"));
                            }
                            $(this).prop("required", false);

                        } else if ($(this).parent().parent().parent().css('display') === 'none' && $(this).prop("required")) {
                            if (jQuery.inArray($(this).attr("id"), arr) == -1) {
                                arr.push($(this).attr("id"));
                            }
                            $(this).prop("required", false);

                        }

                    });


                    window.crr = arr;
                    $(document).on("click", "[name='submit-btn']", function(e) {
                        $(".cmp-form-options__field").not(":hidden").each(function() {
                            if ($(this).prop('nodeName') === 'SELECT' && $(this).prop("required") && $(this).val() == null) {
                                alert($(this).parent().children().eq(0).text() + ' is a required field');
                                $(this).focus();

                                (e).preventDefault();
                                return false;

                            } else if ($(this).prop('nodeName') === 'INPUT' && $(this).prop("required")) {
                                var tempId = $(this).attr("id");
                                var lengthOfInput = $(document).find('#' + tempId + ':checked').length;

                                if ($('#' + tempId + ':checked').length > 0) {
                                    brr.push($(this).attr("id"));

                                    $(this).prop("required", false);
                                }

                            }
                            if ($(this).prop('nodeName') === 'INPUT' && jQuery.inArray(this.id, brr) != -1) {
                                var tempId1 = $(this).attr("id");

                                if ($('#' + tempId1 + ':checked').length == 0) {
                                    $(this).prop("required", true);
                                }
                            }
                        });

                    });

                    $(document).on("change", ".cmp-form-options__field", function() {
                        var arr = crr;
                        $('#html_form').find($('*:hidden')).each(function() {
                            if ($(this).parent().parent().parent().css('display') === 'none' && $(this).parent().prop("required")) {

                                if (jQuery.inArray($(this).parent().attr("id"), arr) == -1) {
                                    arr.push($(this).parent().attr("id"));
                                }
                                $(this).parent().prop("required", false);
                            } else if ($(this).parent().parent().css('display') === 'none' && $(this).prop("required")) {
                                if (jQuery.inArray($(this).attr("id"), arr) == -1) {
                                    arr.push($(this).attr("id"));
                                }
                                $(this).prop("required", false);

                            } else if ($(this).parent().parent().parent().css('display') === 'none' && $(this).prop("required")) {
                                if (jQuery.inArray($(this).attr("id"), arr) == -1) {
                                    arr.push($(this).attr("id"));
                                }
                                $(this).prop("required", false);

                            }


                        });


                        $(document).find($('*:visible')).each(function() {

                            if (jQuery.inArray(this.id, arr) != -1) {
                                $(this).prop("required", true);
                            }
                        });

                    });


                    $(document).on("blur", "input", function() {

                        var arr = crr;
                        $('#html_form').find($('*:hidden')).each(function() {
                            if ($(this).parent().parent().parent().css('display') === 'none' && $(this).parent().prop("required")) {

                                if (jQuery.inArray($(this).parent().attr("id"), arr) == -1) {
                                    arr.push($(this).parent().attr("id"));
                                }
                                $(this).parent().prop("required", false);
                            } else if ($(this).parent().parent().css('display') === 'none' && $(this).prop("required")) {
                                if (jQuery.inArray($(this).attr("id"), arr) == -1) {
                                    arr.push($(this).attr("id"));
                                }
                                $(this).prop("required", false);

                            } else if ($(this).parent().parent().parent().css('display') === 'none' && $(this).prop("required")) {
                                if (jQuery.inArray($(this).attr("id"), arr) == -1) {
                                    arr.push($(this).attr("id"));
                                }
                                $(this).prop("required", false);

                            }


                        });


                        $(document).find($('*:visible')).each(function() {

                            if (jQuery.inArray(this.id, arr) != -1) {
                                $(this).prop("required", true);
                            }
                        });

                    });
                    /*-----------------------------------------------Email Body----------------------------------------------------------*/
                    $("#html_form").submit(function(e) {
					
						function browserSupportsDateInputMethod() {
                            var i = document.createElement("input");
                            i.setAttribute("type", "date");
                            return i.type !== "text";
                        }
						if (browserSupportsDateInputMethod()) 
						{
							$('input[type=date]').each(function() {
								if ($(this).val() != "") {
									var dateVal = $(this).val();
									var dateConversionArray = dateVal.split("-");
									$(this).removeAttr('type');
									$(this).attr('type', 'text');
									var finDate = dateConversionArray[1] + "/" + dateConversionArray[2] + "/" + dateConversionArray[0];
									$(this).val(finDate);
								}
							});
						}

                        var elementList = document.querySelectorAll('*');
                        var content = document.getElementById("email_body").value;
                        var mailSubject = document.getElementById("mailSubject").value;
                        var emailAddress = document.getElementById("emailAddr").value;
                        var ccAddress = document.getElementById("ccAddr").value;
                        var userInitials = "";
                        var userData = "";
                        if (localStorage.getItem("userInitials") !== null && localStorage.getItem("userData") !== null) {
                            userInitials = localStorage.getItem("userInitials");
                            userData = localStorage.getItem("userData");
                        } else if (localStorage.getItem("okta-token-storage") !== null) {
                            userInitials = JSON.parse(
                                localStorage.getItem("okta-token-storage")
                            ).idToken.claims.preferred_username.split("@")[0];
                        }
                        var userInfo = JSON.parse(userData);
                        var userManager = userInfo.userManager;
						var seniorManager = userInfo.seniorManager;


                        var formData = "";
                        var userValidations=[];
                        var formFileInfo;
                        var content = content.replace("#initials#", userInitials);
                        var content = content.replace("#tm#", userManager);
						var content = content.replace("#sm#", seniorManager);
                        for (var i in elementList) {

                            if (elementList[i].id != '' && elementList[i].id != undefined) {

                                var value = elementList[i].id;
                                var value = String(value);

                                if (value != null && value != '' && value != undefined) {
                                    if (((!(elementList[i].id).includes("sum1disp")) && (!(elementList[i].id).includes("accountTable")) && (!(elementList[i].id).includes("fundsTable")) && (!(elementList[i].id).includes("totaldisp")))) {

                                        var formValue = $("#" + value).val();
                                    }
                                }

                                if (value.includes("sum1disp") || value.includes("totaldisp")) {

                                    var formValue = $("#" + value).text().replace(/\n/g, '');
                                }

                                if (value.includes("ACCNOTE")) {

                                    if (($('input[name="ACCNOTE"]:checked').length) > 0) {

                                        var formValue = "Y";
                                    } else {

                                        var formValue = "N";
                                    }
                                }

                                if(value.includes("userValidations")){
 var initialValue = $("#" + value).val();
                                    userValidations.push(initialValue);
                                }
                                
                                
if(value.includes("linegpitems") && (document.URL).includes("special-handle-request")){
                                	
                                	var requestType= $("#REQUESTTYPE").val();
                                	var accountDetails = "";
                                	
                                	if(requestType == "TRAC"){

                                		$("#reqtype #fundsTable >tbody > tr").each(function(index) {
                                		
                                			var planId = $.trim($(this).find("input#pid").val());
                                			var participant = $.trim($(this).find("input#participant").val());
                                			var SSNo = $.trim($(this).find("input.ssn").val());
                                			var fund2 = $.trim($(this).find("input.trac").val());
                                			var dollarmanual2 = $.trim($(this).find("input.dolamount").val());
                                			var dollar2 = $.trim($(this).find("select#AccType").val());

                                			if((planId.length > 0) && (participant.length > 0) && (SSNo.length > 0) && (fund2.length > 0)) {
                                				accountDetails +=  "\n  PLAN ID: " + planId + "\n  PARTICIPANT: " + participant +"\n  TRAC ACCOUNT #: " + fund2+ "\n  SS#: XX-XX-" + SSNo;
                                			}

                                			if(dollar2.length > 0) {
                                				if (dollarmanual2.length > 0) {
                                					accountDetails = accountDetails + "\n  DOLLAR AMOUNT: " +  dollarmanual2 + " " + dollar2 + "\n";
                                				} else if(dollar2 == "All") {
                                					accountDetails = accountDetails + "\n  DOLLAR AMOUNT: " + dollar2 + "\n";
                                				} 
                                			}
                                			
                                			accountDetails += "\n";
                                			
                                		});


                                	}else{
                                		
                                		$("#account-div #accountTable >tbody > tr").each(function(number) {
                                			
                                			
                                			var account = $.trim($(this).find("input.account").val());
                                			var fund = $.trim($(this).find("input#funds").val());
                                			var dollarmanual = $.trim($(this).find("input.damount").val());
                                			var dollar = $.trim($(this).find("select#dType").val());
                                			var fedaralmanual = $.trim($(this).find("input.federal").val());
                                			var fedaral = $.trim($(this).find("select#fType").val());
                                			var statemanual = $.trim($(this).find("input.state").val());
                                			var state = $.trim($(this).find("select#sType").val());
                                			var accountTypeVal = document.getElementById("ACCOUNTTYPE").value;
                                			var requestTypeVal = document.getElementById("REQUESTTYPE").value;
                                			
                                			if((account.length > 0) && (fund.length > 0)) {
                                				accountDetails +=  "\n  ACCOUNT #: " + account + "\n  FUND #: " + fund
                                			} 
                                			
                                			if(dollar.length > 0) {
                                				if (dollarmanual.length > 0) {
                                					accountDetails = accountDetails + "\n  DOLLAR AMOUNT: " +  dollarmanual + " " + dollar + "\n";
                                				} else if(dollar == "All") {
                                					accountDetails = accountDetails + "\n  DOLLAR AMOUNT: " + dollar + "\n";	
                                				}
                                			}
                                			
                                			if(accountTypeVal =="CB&T" && (requestTypeVal=="TA2000 redemption" || requestTypeVal=="Fee from a fund not in the redemption" || requestTypeVal=="Special delivery to foreign address" ||  requestTypeVal=="Other")) {
                                				if(fedaral.length > 0) {
                                					if(fedaralmanual.length > 0) {
                                						accountDetails = accountDetails + "  FEDERAL WITHHOLDING: " +  fedaralmanual + " " + fedaral + "\n";
                                					} else if (fedaral == "Default W/H" || fedaral == "None") {
                                						accountDetails = accountDetails + "  FEDERAL WITHHOLDING: " + fedaral + "\n";	
                                					}
                                					
                                				}
                                				if(state.length > 0) {
                                					if(statemanual.length > 0) {
                                						accountDetails = accountDetails + "  STATE WITHHOLDING: " +  statemanual + " " + state + "\n" ;
                                					} else if(state == "Default W/H" || state == "None") {
                                						accountDetails = accountDetails + "  STATE WITHHOLDING: " + state ;	
                                					} 		
                                				}
                                				
                                			}
                                			 accountDetails += "\n";
                                			
                                		});
                                		$("#account-div-sp #accountTablesp >tbody > tr").each(function(number) {
                                			
                                			var account = $.trim($(this).find("input.account").val());
                                			var fund = $.trim($(this).find("input#funds").val());
                                			var dollarmanual = $.trim($(this).find("input.damount").val());
                                			var dollar = $.trim($(this).find("select#dType").val());
                                			var fedaralmanual = $.trim($(this).find("input.federal").val());
                                			var fedaral = $.trim($(this).find("select#fType").val());
                                			var statemanual = $.trim($(this).find("input.state").val());
                                			var state = $.trim($(this).find("select#sType").val());
                                			
                                			var accountTypeVal = document.getElementById("ACCOUNTTYPE").value;
                                			var requestTypeVal = document.getElementById("REQUESTTYPE").value;
                                			
                                			if((account.length > 0) && (fund.length > 0)) {
                                				accountDetails +=  "\n  ACCOUNT #: " + account + "\n  FUND #: " + fund
                                			} 
                                			
                                			if(dollar.length > 0) {
                                				if (dollarmanual.length > 0) {
                                					accountDetails = accountDetails + "\n  DOLLAR AMOUNT: " +  dollarmanual + " " + dollar + "\n";
                                				} else if(dollar == "All") {
                                					accountDetails = accountDetails + "\n  DOLLAR AMOUNT: " + dollar + "\n";	
                                				}
                                			}
                                			
                                			if(accountTypeVal =="CB&T" && (requestTypeVal=="TA2000 redemption" || requestTypeVal=="Fee from a fund not in the redemption" || requestTypeVal=="Special delivery to foreign address" ||  requestTypeVal=="Other")) {
                                			
                                				if(fedaral.length > 0) {
                                					if(fedaralmanual.length > 0) {
                                						accountDetails = accountDetails + "  FEDERAL WITHHOLDING: " +  fedaralmanual + " " + fedaral + "\n";
                                					} else if (fedaral == "Default W/H" || fedaral == "None") {
                                						accountDetails = accountDetails + "  FEDERAL WITHHOLDING: " + fedaral + "\n";	
                                					}
                                					
                                				}
                                				if(state.length > 0) {
                                					if(statemanual.length > 0) {
                                						accountDetails = accountDetails + "  STATE WITHHOLDING: " +  statemanual + " " + state + "\n" ;
                                					} else if(state == "Default W/H" || state == "None") {
                                						accountDetails = accountDetails + "  STATE WITHHOLDING: " + state ;	
                                					} 		
                                				}
                                				
                                			}
                                			 accountDetails += "\n";
                                			 
                                		});

                                		}
                                		
                                		var formValue = accountDetails;
                                		                                		
                                		
                                	}
                                	

                                		


                                if (value.includes("accountWrapper")) {
                                    var componentType = $("#accountWrapper").parent().attr('data-properties');
                                    var wireInstructions = "";
                                    if (componentType == "cashed_check") {

                                        $("#accountWrapper .accountTable").each(function(index) {

                                            var accountErrorLines = "";
                                            var account = $(this).attr('id');
                                            var acctIndex = index + 1;
                                            var acctNumber = $.trim($(this).find("input.accNumm").val());
                                            var acctViewableShare = $(this).find("input.cmp-form-options__field--checkbox").is(":checked");

                                            var acctType = $(this).find("select.cmp-form-options__field--drop-down").val();


                                            if (acctNumber.length == 0 || acctType.length == 0) {
                                                if (acctNumber.length == 0) accountErrorLines += "ACCOUNT #\n";
                                                if (acctType.length == 0) accountErrorLines += "A/C TYPE\n";
                                            } else {
                                                inShare = "N";
                                                if (acctViewableShare == true)
                                                    inShare = "Y";


                                                wireInstructions += "\n  ACCOUNT #: " + acctNumber + "    A/C TYPE: " + acctType

                                                    +
                                                    "    ACCOUNT VIEWABLE IN SHARE: " + inShare;

                                                wireInstructions += "\n\n    FUND    BANK ACCOUNT    CHECK#    DOLLAR AMOUNT        DATE PAID  \n";
                                            }                              

                                            $("#accountWrapper .accountTable #fundsBody > tr").each(function(number) {

                                                var fundIndex = $(this).parent().parent().parent().parent().attr('id');
                                                if (fundIndex.localeCompare(account) == 0) {
                                                    var fundNumber = $.trim($(this).find("input.funds").val());
                                                    var fundDollarAmt = $(this).find("input.dolamount").val();
                                                    var bankAccount = $(this).find("select.bankAccount").val();
                                                    var checkNumber = $.trim($(this).find("input.check").val());
                                                    var datePaid = $.trim($(this).find("input.date").val());


                                                    if (fundNumber.length != 0 || fundDollarAmt.length != 0 || bankAccount.length != 0 || checkNumber.length != 0 || datePaid.length != 0) {

                                                        if (fundNumber.length > 0 && fundDollarAmt.length > 0 && bankAccount.length > 0 && checkNumber.length > 0 && datePaid.length > 0) {
                                                            wireInstructions += "    " + (fundNumber);
                                                            wireInstructions += "     " + (bankAccount);
                                                            wireInstructions += "     " + (checkNumber);
                                                            wireInstructions += "    " + (fundDollarAmt);
                                                            wireInstructions += "            " + datePaid + "\n";


                                                        }




                                                    }
                                                }
                                            });


                                        });


                                    } else if (componentType == "bank_wire") {

                                        var accountErrorLines = "";
                                        var oneLineMinimum = false;

                                        $("#accountWrapper .accountTable").each(function(index) {

                                            var account = $(this).attr('id');
                                            var acctNumber = $.trim($(this).find("input.accNumm").val());


                                            var acctAlphaCode = $.trim($(this).find("input.cmp-form-text__text").val());
                                            var acctType = $(this).find("select.cmp-form-options__field--drop-down").val();
                                            var acctContribType = $(this).find("select.cmp-form-options__field--drop-down").text();

                                            if (acctNumber.length == 0 || acctAlphaCode.length == 0 || acctType.length == 0 || acctContribType.length == 0) {
                                                if (acctNumber.length == 0) accountErrorLines += "\n    ACCOUNT #";
                                                if (acctAlphaCode.length == 0) accountErrorLines += "\n    ALPHA CODE";
                                                if (acctType.length == 0) accountErrorLines += "\n    A/C TYPE";
                                                if (acctContribType.length == 0) accountErrorLines += "\n    CONTRIB TYPE";
                                            } else {
                                                wireInstructions += "ACCOUNT #: " + acctNumber + "    ALPHA CODE: " + acctAlphaCode + "    A/C TYPE: " + acctType;
                                                wireInstructions += "\n\n     FUND          DOLLAR AMOUNT      CONTRIB TYPE\n";
                                            }
                                            $("#accountWrapper .accountTable #fundsBody > tr").each(function(number) {

                                                var indexNumber = number + 1;
                                                var fundIndex = $(this).parent().parent().parent().parent().attr('id');
                                                if (fundIndex.localeCompare(account) == 0) {
                                                    var fundNumber = $.trim($(this).find("input.funds").val());
                                                    var fundDollarAmt = $.trim($(this).find("input.damount").val());
                                                    var fundContribType = $.trim($(this).find("select.fundtype").text());
                                                    if(fundContribType=='Direct-Investment')
													{
														fundContribType='Direct Investment';
                                                    }
                                                    if(fundContribType.length>50)
													{
														fundContribType= $.trim($(this).find("select.fundtype").val());
                                                    }

                                                    if (acctContribType == "varies") {
                                                        if (fundNumber.length != 0 || fundDollarAmt.length != 0 || fundContribType.length != 0) {
                                                            if (fundNumber.length > 0 && fundDollarAmt.length > 0 && fundContribType.length > 0) {
                                                                wireInstructions += "     " + (fundNumber);
                                                                wireInstructions += "             "+fundDollarAmt;
                                                                wireInstructions += "      " + fundContribType + "\n";
                                                                oneLineMinimum = true;
                                                            } else accountErrorLines += "\n    Line # " + indexNumber + " is incomplete";
                                                        }
                                                    } else {
                                                        if (fundNumber.length != 0 || fundDollarAmt.length != 0) {
                                                            if (fundNumber.length > 0 && fundDollarAmt.length > 0) {
                                                                wireInstructions += "     " + (fundNumber);
                                                                wireInstructions +=  "              "+fundDollarAmt;
                                                                wireInstructions +=  "      " + fundContribType + "\n";
                                                                oneLineMinimum = true;
                                                            } else accountErrorLines += "\n    Line # " + indexNumber + " is incomplete";
                                                        }
                                                    }

                                                }

                                            });
                                            if (oneLineMinimum == false) {
                                                accountErrorLines += "\n    At least one line must be complete\n";
                                            }
                                            wireInstructions += "\n\n"

                                        });
                                    }


                                    var formValue = wireInstructions;

                                }



                                if (elementList[i].id != '' && String(elementList[i].type) == "radio") {
                                    var name = String(elementList[i].name);
                                    var formValue = $("input[name=" + name + "]:checked").val();
                                }
                                if (elementList[i].id != '' && String(elementList[i].type) == "checkbox") {
                                    var visible = $("#" + elementList[i].id).is(':visible');
                                    if (visible) {
                                        var name = String(elementList[i].name);

                                        var checkboxValues = [];
                                        if ((String(name) != null) && (String(name) != undefined) && (String(name) != '')) {
                                            $("input[name=" + name + "]:checked").map(function() {
                                                checkboxValues.push($(this).val());


                                            });
                                        }

                                        var checkboxValues = checkboxValues.join('\r\n');
                                        var formValue = checkboxValues.toString();
                                    }
                                }
                                if (value === "devastaccountWrapper") {

                                    var accountDetails = "ACCOUNT DETAILS:"
                                    	var ind = 0;
                                    var accQuest = new Array();
                                    $("#devastaccountWrapper .accountTable").each(function(index) {
                                        var accountErrorLines = "";
                                        var acctIndex = index + 1;
                                        var fundHeader = "";
                                        var acctNumber = $.trim($(this).find("input.accNum").val());
                                		var acctAlphaCode = $.trim($(this).find("input#alphaCode").val());
                                		var acctReg = $.trim($(this).find("textarea#accountRegistration").val());
                                		accountDetails += "\n_______________________________________________________________";
                                		accountDetails += "\nACCOUNT: " + acctNumber;
                                		accountDetails += "\nVIEWABLE IN SHARE: ";
                                		if ($(this).find("input#accountShare").is(":checked")) 
                                			accountDetails += "Y";
                                		else
                                			accountDetails += "N";
                                		accountDetails += "\nALPHACODE: " + acctAlphaCode;
                                		accountDetails += "\nACCOUNT REGISTRATION:\n" + acctReg;

                                        var quest = $.trim($("#accountTable-" + (acctIndex)).find('[name^="ancientTranscripts"]').val());
                                        var allfund = $.trim($("#accountTable-" + (acctIndex)).find('[name^="allFunds"]').val());
                                        accountDetails += "\nAre you requesting transcripts prior to 1990? " + quest;
                                        if(quest != '') {
                                			accQuest[ind] = quest;
                                			ind++;
                                		}

                                        if (quest == "No" && allfund.length == 0) {
                                            accountErrorLines += "\n- ALL FUNDS";
                                        } else if (quest == "No") {
                                            accountDetails += "\n \nALL FUNDS: " + allfund;
                                        }

                                        var oneLineMinimum = false;

                                        if (quest == "Yes") {
                                            fundHeader = "\n\nFUND:      Int Inv Only:        FROM:           TO:	 \n";
                                            accountDetails = accountDetails + fundHeader;


                                            $("#devastaccountWrapper .accountTable #devastFundsBody > tr").each(function(number) {

                                                var fundIndex = number + 1;
                                                
                                                var fundNumber = $.trim($("#accountTable-" + (fundIndex)).find("input.funds").val());
                                                var fundintInv = "";
                                                if ($("#accountTable-" + (fundIndex)).find("input.invCheckbox").is(":checked")) fundintInv = "Y";
                                                else fundintInv = "N";

                                                var fundFromYear = $("#accountTable-" + (fundIndex)).find("select.ancientFrom").val();
                                                var fundToYear = $("#accountTable-" + (fundIndex)).find("select.ancientTo").val();

                                                if (fundintInv == "N") {
                                                    if (fundNumber.length != 0 || fundFromYear.length != 0 || fundToYear.length != 0) {
                                                        if (fundNumber.length > 0 && fundFromYear.length > 0 && fundToYear.length > 0) {
                                                            
                                                            accountDetails += padSpacesToRight(fundNumber, 7);
                                                            accountDetails += padSpacesToLeft(fundintInv, 15);
                                                            accountDetails += padSpacesToLeft(fundFromYear, 30);
                                                            accountDetails += padSpacesToLeft(fundToYear, 17);

                                                            accountDetails += "\n";
                                                            oneLineMinimum = true;
                                                        } else {
                                                            accountErrorLines += "\n- Line # " + fundIndex + " is incomplete";
                                                        }
                                                    }
                                                } else if (fundintInv == "Y") {
                                                    if (fundNumber.length > 0) {
                                                        accountDetails += padSpacesToRight(fundNumber, 7);
                                                        accountDetails += padSpacesToLeft(fundintInv, 15);

                                                        accountDetails += "\n";
                                                        oneLineMinimum = true;
                                                    } else {
                                                        accountErrorLines += "\n- Line # " + fundIndex + " is incomplete";
                                                    }
                                                }
                                            });
                                        }

                                        if (quest == "No" && allfund == "No") {
                                            fundHeader = "\n\nFUND:         TIMEFRAME:            FROM:            TO:	    \n";
                                            accountDetails = accountDetails + fundHeader;
                                            $("#devastaccountWrapper .accountTable #devastTimeBody > tr").each(function(time) {
                                                var fundIndex = time + 1;
                                                var fundNumber = $.trim($("#accountTable-" + (fundIndex)).find("input.fundsF").val());
                                                var fundTimeFrame = $("#accountTable-" + (fundIndex)).find("select.timeFrameT").val();
                                                var fundFromYear = $("#accountTable-" + (fundIndex)).find("select.from").val();
                                                var fundToYear = $("#accountTable-" + (fundIndex)).find("select.to").val();

                                                if (fundTimeFrame == "Years Selected") {
                                                    if (fundNumber.length != 0 || fundTimeFrame.length != 0 || fundFromYear.length != 0 || fundToYear.length != 0 || fundYearSelected.length != 0) {
                                                        if (fundNumber.length > 0 && fundFromYear.length > 0 && fundToYear.length > 0 && fundTimeFrame.length > 0) {
                                                           
                                                            accountDetails += padSpacesToRight(fundNumber, 7);
                                                            accountDetails += padSpacesToLeft(fundTimeFrame, 25);
                                                            accountDetails += padSpacesToLeft(fundFromYear, 15);
                                                            accountDetails += padSpacesToLeft(fundToYear, 18);

                                                            accountDetails += "\n";
                                                            oneLineMinimum = true;
                                                        } 
                                                    }
                                                }

                                                if (fundTimeFrame == "Init Inv Only" || fundTimeFrame == "All Years" || fundTimeFrame == "") {
                                                    if (fundNumber.length != 0 || fundTimeFrame.length != 0) {
                                                        if (fundNumber.length > 0 && fundTimeFrame.length > 0) {
                                                            accountDetails += padSpacesToRight(fundNumber, 7);
                                                            accountDetails += padSpacesToLeft(fundTimeFrame, 25);

                                                            accountDetails += "\n";
                                                            oneLineMinimum = true;
                                                        }                                                     }
                                                }

                                            });



                                        }

                                        if (quest == "No" && allfund == "Yes") {
                                            fundHeader = "\n\nTIMEFRAME:            FROM:          TO:	  \n";
                                            accountDetails = accountDetails + fundHeader;

                                            $("#devastaccountWrapper .accountTable #devastTimeFrameBody > tr").each(function(time) {
                                                var fundIndex = time + 1;
                                                var fundTimeFrame = $("#accountTable-" + (fundIndex)).find("select#timeframe1-1").val();
                                                var fundFromYear = $("#accountTable-" + (fundIndex)).find("select.fromYear").val();
                                                var fundToYear = $("#accountTable-" + (fundIndex)).find("select.toYear").val();

                                                if (fundTimeFrame == "Years Selected") {
                                                    if (fundTimeFrame.length != 0 || fundFromYear.length != 0 || fundToYear.length != 0) {
                                                        if (fundTimeFrame.length > 0 && fundFromYear.length > 0 && fundToYear.length > 0) {
                                                           
                                                            accountDetails += padSpacesToRight(fundTimeFrame, 20);
                                                            accountDetails += padSpacesToLeft(fundFromYear, 10);
                                                            accountDetails += padSpacesToLeft(fundToYear, 15);

                                                            accountDetails += "\n";
                                                            oneLineMinimum = true;
                                                        }                                                     }
                                                }

                                                if (fundTimeFrame == "Init Inv Only" || fundTimeFrame == "All Years" || fundTimeFrame == "") {
                                                    if (fundTimeFrame.length > 0) {
                                                        accountDetails += padSpacesToRight(fundTimeFrame, 20);
                                                        accountDetails += "\n";
                                                        oneLineMinimum = true;
                                                    } 
                                                }

                                            });

                                        }

                                    });

                                    function padSpacesToRight(inputstring, totalLength) {
                                        var returnstr = inputstring;
                                        for (var i = inputstring.length; i < totalLength; i++) {
                                            returnstr += " ";
                                        }
                                        return returnstr;
                                    }

                                    function padSpacesToLeft(inputstring, totalLength) {
                                        var returnstr = "";
                                        for (var i = 1; i < totalLength - inputstring.length; i++) {
                                            returnstr += " ";
                                        }
                                        returnstr += inputstring;
                                        return returnstr;
                                    }

                                    var formValue = accountDetails;
                                }
                               
                                var formDynamic = $("#" + value + ">thead").length;
                                var visible = $("#" + elementList[i].id).is(':visible');
                                if (formDynamic > 0 && visible) {

                                    var fundtable = "<table>";
                                    var mytable = "<thead><tr>";
                                    var headings = [];
                                    $("#" + value).find("th").each(function() {
                                        if ($(this).html() != '') {
                                            var label=$(this).html();
                                            var head=label.replace("*", "");
                                            mytable += "<th>" + head + "</th>";
                                            headings.push(head);
                                        }
                                    });
                                    mytable += "</tr></thead>";

                                    fundtable += mytable;

                                    var myTab = document.getElementById("" + value + "");

                                    var arrValues = new Array();

                                    var amounttable = "<tbody><tr>";
                                    //loop through each row of the table.
                                    for (row = 1; row < myTab.rows.length; row++) {
                                        // loop through each cell in a row.


                                        for (c = 1; c < myTab.rows[row].cells.length; c++) {
                                            var element = myTab.rows.item(row).cells[c].querySelectorAll('*[id]');
                                            if (element[0] != undefined) {
                                                if (document.getElementById(element[0].id).value != undefined) {
                                                    amounttable += "<td>" + document.getElementById(element[0].id).value + "</td>";

                                                }
                                            }
                                        }
                                        amounttable += "</tr></tbody>";

                                    }

                                    fundtable += amounttable;
                                    fundtable += "</table>";


                                    formValue = fundtable;


                                }

                                if ((formValue == null) || (formValue == undefined)) {
                                    formValue = " ";
                                }

                                var newEmail = content.replace("$" + value + "$", formValue);
                                var mailSubject = mailSubject.replace("$" + value + "$", formValue);
                                var content = newEmail;
                                var formData = String(content);
                            }
                        }
userValidations.toString();

                        var input = $("#file").val();
                        var base64String =null;var attachment2 = null;var attachment3 = null;
                        var fileName =null;var fileName2 = null;var fileName3=null;
                        var file=null;var file2=null;var file3=null;
                        if (input != null && input != ' ' && input != undefined && input != "") {
                            var element = document.getElementById('file');
                             file = element.files[0];
                            var promise = new Promise(getBuffer);
                            promise.then(function(data) {
                            	base64String=data;
                            	 fileName = $("#file").val().split("\\").pop();                                                
                                var input2 = $("#second").val();                                
                                if (input2 != null && input2 != ' ' && input2 != undefined && input2 != "") {                                
                                var secondelement = document.getElementById('second');
                                 file2 = secondelement.files[0];
                                var promise2 = new Promise(getBuffer2);
                                promise2.then(function(data) {
                                	attachment2=data;
                                	 fileName2 = $("#second").val().split("\\").pop();                                  
                                    var input3 = $("#third").val();                                  
                                    if (input3 != null && input3 != ' ' && input3 != undefined && input3 != "") {                                    
                                    var thirdelement = document.getElementById('third');
                                     file3 = thirdelement.files[0];
                                    var promise3 = new Promise(getBuffer3);
                                    promise3.then(function(data) {
                                    attachment3=data;
                                     fileName3 = $("#third").val().split("\\").pop();
                                     
                                    $.post("/bin/capital-group-ofr/formemailServlet", {
                                        formData: formData,
                                        mailSubject: mailSubject,
                                        emailAddress: emailAddress,
                                        ccAddress: ccAddress,
                                        firstBrowse: base64String,
                                        firstFileName: fileName,
                                        secondBrowse:attachment2,
                                        secondFileName:fileName2,
                                        thirdBrowse:attachment3,
                                        thirdFileName:fileName3
                                    })
                                    .done(function(data) {
                                        $("#submitAnalytics").click();
                                        alert("Form Submitted Successfully"); 
                                        location.reload();
                                    });
                                    });                                   
                                    }else{
                                    	 $.post("/bin/capital-group-ofr/formemailServlet", {
                                    		 formData: formData,
                                             mailSubject: mailSubject,
                                             emailAddress: emailAddress,
                                             ccAddress: ccAddress,
                                             firstBrowse: base64String,
                                             firstFileName: fileName,
                                             secondBrowse:attachment2,
                                             secondFileName:fileName2,
                                             thirdBrowse:attachment3,
                                             thirdFileName:fileName3
                                         })
                                         .done(function(data) {
                                             $("#submitAnalytics").click();
                                             alert("Form Submitted Successfully");
                                             location.reload();
                                         });
                                    	
                                    }
                                });
                                
                                }else{
                               	 $.post("/bin/capital-group-ofr/formemailServlet", {
                                     formData: formData,
                                     formData: formData,
                                     mailSubject: mailSubject,
                                     emailAddress: emailAddress,
                                     ccAddress: ccAddress,
                                     firstBrowse: base64String,
                                     firstFileName: fileName,
                                     secondBrowse:attachment2,
                                     secondFileName:fileName2,
                                     thirdBrowse:attachment3,
                                     thirdFileName:fileName3
                                 })
                                 .done(function(data) {
                                     $("#submitAnalytics").click();
                                     alert("Form Submitted Successfully");
                                     location.reload();
                                 });
                            	
                            }
                           });
                            function getBuffer(resolve) {
                            var reader = new FileReader();
                            reader.onload = function() {
                                var y = reader.result.replace("data:", "").replace(/^.+,/, "");
                                resolve(y);
                                
                            }
                            reader.readAsDataURL(file);
                            }
                            
                            function getBuffer2(resolve){
                            var reader2 = new FileReader();
                           reader2.onload =  function() {
                                var z = reader2.result.replace("data:", "").replace(/^.+,/, "");
                                resolve(z);
                                
                            }
                            reader2.readAsDataURL(file2);
                            }
                            
                           function getBuffer3(resolve){
                            var reader3 = new FileReader();
                         reader3.onload =  function() {
                                var p = reader3.result.replace("data:", "").replace(/^.+,/, "");
                                resolve(p);
                            }
                            reader3.readAsDataURL(file3);
                            }
                        } else {
                            $.post("/bin/capital-group-ofr/formemailServlet", {
                                    formData: formData,
                                    mailSubject: mailSubject,
                                    emailAddress: emailAddress,
                                ccAddress: ccAddress,initials:userValidations


                                })
                                .done(function(data) {
                                    $("#submitAnalytics").click();
									alert(data);
                                    if(data =="Email sent successfully"){
										
                                   if ((document.URL).includes("g-purch-batch-ticket")) {

									if($("#SOURCETYPE").val() == "Paper"){
									var link = location.origin+"/content/internal-sites/ofr/us/en/home/miscellaneous/G-Purch-Alert.html"
									window.location.replace(link);

									}
									}
									if ((document.URL).includes("trac2000-batch-ticket")) {

									if($("#SOURCETYPE").val() == "Paper"){
									var link = location.origin+"/content/internal-sites/ofr/us/en/home/miscellaneous/TRAC-2000-Alert.html"
									window.location.replace(link);

									}

									}


									setTimeout(function(){ location.reload(); }, 3000);
									}
																		
																		
																	});
                        }

                    });

                });