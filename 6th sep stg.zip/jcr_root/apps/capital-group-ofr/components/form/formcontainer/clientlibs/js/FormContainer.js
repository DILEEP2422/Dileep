(function(document, $) {
  "use strict";

  $(document).on("ready", function() {
    if ($(".cmp-form-cg-style").length > 0) {
      repositionPlaceholders();
    }
  });

  $(document).on("focus", ".cmp-form-cg-style .cmp-form-text input", function(
    event
  ) {
	  var inputElement = $(this);
	  if( inputElement.parents(".cmp-form-modal-style").length ==0){
          inputElement.siblings("span.form_error").hide();
          inputElement.parent().removeClass("required-element");
		  inputElement
     .siblings("label")
      .animate(
        {
          opacity: 0
        },
        200
      )
      .animate(
        {
          top: 0
        },
        200
      )
      .animate(
        {
          opacity: 1
        },
        200
      );
	  }

	 
  });
  //to check wether the form required input is empty or not.
    $(document).on("blur", ".modal-formmodal-container .modal-content .cmp-form-modal-style form .cmp-form-text input", function (event) {
    var inputType = $(this).attr("type");
    var inputName = $(this).attr("name");
    var parentElement = $(this).parent();
    var requiredMsge = "";
    var requiredName = inputName == "addressCity" || inputName == "lastName" || inputName == "middleName" || inputName == "firstName" || inputName == "middleName";
    if (requiredName) requiredMsge = "Do not exceed 50 characters";
    if (inputName == "suffix") requiredMsge = "Do not exceed 20 characters";
    if (inputName == "addressLine1" || inputName == "eAddress") requiredMsge = "Do not exceed 250 characters";
    if (inputName == "other") requiredMsge = "Do not exceed 250 characters";
    if (inputType == "tel") requiredMsge = "Enter 10 digits with no parenthesis or hyphens";
    if (inputType == "zipcode") requiredMsge = "Enter 5 digits with no parenthesis or hyphens";
    var validEmail = false;

    var errorMsgeEleCheck = $(this).parent().find('.form_error').length >= 1;
    if (inputName == "eAddress") {
		if($(this).val().length !== 0){
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        validEmail = regex.test($(this).val());
        if (!validEmail) requiredMsge = "Enter a valid email";
		}else{
		   parentElement.removeClass("required-element");
           parentElement.find(".form_error").addClass("hide");
		}

    }
    if ($(this).attr("required")) {

      
      if ($(this).val().length == 0) requiredMsge = "Required";
      if (!errorMsgeEleCheck) {
        $(this).parent().append('<span class="form_error">' + requiredMsge + "</span>");
      } else {

        $(this).parent().find('.form_error').text(requiredMsge);
      }

      if (inputType == "text" && inputName == "addressLine1" && $(this).val().length > 0 && $(this).val().length <= 250) {
        parentElement.removeClass("required-element");
        parentElement.find(".form_error").addClass("hide");
      } else if (inputType == "text" && $(this).val().length > 0 && $(this).val().length <= 50 && requiredName) {
        parentElement.removeClass("required-element");
        parentElement.find(".form_error").addClass("hide");
      } else if (inputType == "number" && $(this).val().length > 0) {
        parentElement.removeClass("required-element");
        parentElement.find(".form_error").addClass("hide");
      } else if (inputType == "email" && $(this).val().length > 0) {
        parentElement.removeClass("required-element");
        parentElement.find(".form_error").addClass("hide");
      } else if (inputType == "tel" && $.isNumeric($(this).val()) && $(this).val().length == 10) {
        parentElement.removeClass("required-element");
        parentElement.find(".form_error").addClass("hide");
      } else if (inputType == "zipcode" && $.isNumeric($(this).val()) && $(this).val().length == 5) {
        parentElement.removeClass("required-element");
        parentElement.find(".form_error").addClass("hide");
      }  else {
        parentElement.addClass("required-element");
        parentElement.find(".form_error").removeClass("hide");
      }
      //Non Mandiatory Form Feild Custom Validation
    } else if (inputType == "text" && inputName == "middleName") {
      if (!errorMsgeEleCheck) {
        $(this).parent().append('<span class="form_error">' + requiredMsge + "</span>");
      } else {
        $(this).parent().find('.form_error').text(requiredMsge);
      }
      if ($(this).val().length <= 50) {
        parentElement.removeClass("required-element");
        parentElement.find(".form_error").addClass("hide");
      } else {
        parentElement.addClass("required-element");
        parentElement.find(".form_error").removeClass("hide");
      }
    } else if (inputType == "text" && inputName == "eAddress" && $(this).val().length !== 0) {
        if (!errorMsgeEleCheck) {
        $(this).parent().append('<span class="form_error">' + requiredMsge + "</span>");
      } else {
        $(this).parent().find('.form_error').text(requiredMsge);
      }
      if ($(this).val().length <= 250 && validEmail) {
        parentElement.removeClass("required-element");
        parentElement.find(".form_error").addClass("hide");
      } else {
        parentElement.addClass("required-element");
        parentElement.find(".form_error").removeClass("hide");
      }
      }else if (inputType == "text" && inputName == "suffix") {

      if (!errorMsgeEleCheck) {
        $(this).parent().append('<span class="form_error">' + requiredMsge + "</span>");
      } else {
        $(this).parent().find('.form_error').text(requiredMsge);
      }
      if ($(this).val().length <= 20) {
        parentElement.removeClass("required-element");
        parentElement.find(".form_error").addClass("hide");
      } else {
        parentElement.addClass("required-element");
        parentElement.find(".form_error").removeClass("hide");
      }
    } else if (inputType == "text" && inputName == "other") {
        if ($(".modal-formmodal-container .cmp-form-modal-style  input[value='OTHER']").prop("checked")) {
            if (!errorMsgeEleCheck) {
                $(this).parent().append('<span class="form_error">Required</span>');
            } else {
                $(this).parent().find('.form_error').text("Required");
            }
            if ($(this).val().length > 0) {
                parentElement.removeClass("required-element");
                parentElement.find(".form_error").addClass("hide");
            } else {
                parentElement.addClass("required-element");
                parentElement.find(".form_error").removeClass("hide");
            }
        }
        if ($(this).val().length > 0 && !($(this).val().length < 251)) {
            if (!errorMsgeEleCheck) {
                $(this).parent().append('<span class="form_error">Do not exceed 250 characters</span>');
            } else {
                $(this).parent().find('.form_error').text("Do not exceed 250 characters");
            }
            parentElement.addClass("required-element");
            parentElement.find(".form_error").removeClass("hide");
        } else {
            parentElement.removeClass("required-element");
            parentElement.find(".form_error").addClass("hide");

        }
    }

  });
  
  //CheckBox Validation.
  $(document).on("click", ".modal-formmodal-container .modal-content .cmp-form-modal-style form input[type='checkbox']", function(event){
		
		var clickedElement = $(this);
		if(clickedElement.prop("checked")){
			//$(".modal-formmodal-container .modal-content .cmp-form-modal-style form input[type='checkbox']").eq('0').parent('.cmp-form-options__field-label').parent('.cmp-form-options--checkbox').find(".form_error").remove();
			$(".modal-formmodal-container  input[name='checkbox_error_message']").parent().addClass('hidden');

		}
  });
  //DropDown
  $(document).on("click", ".modal-formmodal-container  .modal-content .cmp-form-modal-style fieldset.cmp-form-options--drop-down select.cmp-form-options__field--drop-down", function(event){
	  var checkboxele = $(this);
	  if(checkboxele.val() !== null){ 
		checkboxele.parent().removeClass('required-element');
		checkboxele.parent().find(".form_error").addClass("hide");
	  }else{
		  checkboxele.parent().addClass("required-element");
		  checkboxele.parent().find(".form_error").removeClass("hide");
	  }
  });
  

  $(document).on("click", ".cmp-form-cg-style .cmp-form-button", function(
    event
  ) {
    event.stopPropagation();
	var currentElement = $(this);
    var parent = $(this).closest("form");
    var form = $(this).closest("form");
    var formHt = form.css("height");
    var expFrag = form.parents(".experiencefragment");
    var ciNewsletter = form.parents(".ci-newsletter-global-style");
    var thankYouMessage = parent.attr("formmessage")
      ? parent.attr("formmessage")
      : "Thank You!";
    var errorMessage = parent.attr("errormessage")
      ? parent.attr("errormessage")
      : "Sorry, your request can’t be processed at this time.  Please try again later.";  
    var runCookiesScript = parent.attr("runCookiesScript")
      ? parent.attr("runCookiesScript")
      : "false";
    var hostUrl = "https://" + window.location.host;

    var redirect = parent.attr("redirecturl") ? parent.attr("redirecturl") : "";
    if (redirect != "") {
      redirect = hostUrl + redirect;
    }
    parent.children(".cmp_form_message").hide();
    parent.find(".form_error").each(function() {
      $(this).remove();
    });

    var serviceUrl = parent.attr("serviceurl");
    var formId = parent.attr("formId");
    var payloadJson = {};
    var inputElmtName;
    var inputElmtValue;
    var inputElmt;
    var requiredMessage;
    var formError = false;
    var validEmailCheck = true;
    var checkBoxFlag = false;
    var checkBoxValues = [];
    var checkBoxCounter = 0;
    var type;
    var pathName = window.location.pathname;
    parent.find("input").each(function() {
      inputElmt = $(this);
      inputElmtName = inputElmt.attr("name");
      inputElmtValue = inputElmt.val();
      var type = inputElmt.attr("type");
      //If the input field is required and not filled any value for it.
      if (inputElmt.attr("required")) {
        if (inputElmtValue.length < 1) {
          if (inputElmt.parent().attr("data-cmp-required-message")) {
            requiredMessage = inputElmt
              .parent()
              .attr("data-cmp-required-message");
          } else {
            requiredMessage = "This field is required";
          }
          inputElmt.after(
            '<span class="form_error">' + requiredMessage + "<span class='error_alert'>&nbsp;</span></span>"
          );

		  inputElmt.parent().addClass("required-element");
          formError = true;
        }
      }
      //Email address element named as 'eAddress' to eliminate briteVerify check since CCPA business doen't need it
      if ((type === "email" || inputElmtName === "eAddress") && !(inputElmtValue.length < 1)) {
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        var validEmail = regex.test(inputElmtValue);

        if (!validEmail) {
          inputElmt.parent().addClass("required-element");
          inputElmt.after(
            '<span class="form_error">Enter a valid email<span class="error_alert">&nbsp;</span></span>'
          );
          formError = true;
		  validEmailCheck = false;
        } else {
          payloadJson["ContactKey"] = inputElmtValue;
        }
      }
	  //Mobile number validation for form modal with only 10 numbers.
      if (type === "tel" && !(inputElmtValue.length < 1) && form.parents(".cmp-form-modal-style").length !== 0) {
		if (inputElmtValue.length !== 10) {
          inputElmt.after(
            '<span class="form_error">Enter 10 digits with no parenthesis or hyphens</span>'
          );
          formError = true;
        } else {
          payloadJson[inputElmtName] = inputElmtValue;
        }
      }
		if (type === "radio") {
			inputElmtValue = $("input[name='" + inputElmtName + "']:checked").val();
		}

		if(type === "checkbox"){
	      if ($(this)[0].checked) {
            checkBoxFlag = true;
            inputElmtValue = $(this).val();
            checkBoxValues.push(inputElmtValue);
          }
			checkBoxCounter++;
		}else{
			if(inputElmtName === "eAddress"){
			  if(!(inputElmtValue.length < 1)){
				payloadJson["emailAddress"] = inputElmtValue;
			  }
			}else{
			payloadJson[inputElmtName] = inputElmtValue;
			}
		}
    });
    payloadJson["serviceUrl"] = parent.attr("serviceurl");
    payloadJson["formAuthKey"] = parent.attr("formId");

    
        if (parent
            .find(".cmp-form-options__field.cmp-form-options__field--drop-down")
            .size() != 0
        ) {
            parent.find(
                ".cmp-form-options__field.cmp-form-options__field--drop-down"
            ).each(function () {
                var dropDownElement = $(this);
                payloadJson[dropDownElement.attr("name")] = dropDownElement
                    .find("option:selected")
                    .val();
            });
        }

        if (parent
            .find(".cmp-form-options__field cmp-form-options__field--radio")
            .size() != 0
        ) {
            parent.find(
                ".cmp-form-options__field cmp-form-options__field--radio"
            ).each(function () {
                var radioelement = $(this);
                payloadJson[radioelement.attr("name")] = $("input[name='" + radioelement.attr("name") + "']:checked").val();

            });
        }
    
    if(checkBoxCounter > 0 ){
          if(checkBoxFlag === false){
               //$(".modal-formmodal-container input[type='checkbox']").eq('0').parent('.cmp-form-options__field-label').parent('.cmp-form-options--checkbox').prepend('<span class="form_error">Select all that apply</span>');
			   var parentElmt = $(".modal-formmodal-container  input[name='checkbox_error_message']").parent();
               parentElmt.append('<span class="form_error">Select all that apply</span>');
			   parentElmt.removeClass('hidden');

			   formError = true;
              } else {
                payloadJson["relationshipsToCg"] = checkBoxValues;
              }
       }
    //Other CheckBox Text Felid Validation

    if (form.parents(".cmp-form-modal-style").length > 0 && payloadJson.relationshipsToCg != undefined && payloadJson.relationshipsToCg.indexOf('OTHER') != -1 && payloadJson.other != undefined && !(payloadJson.other.length > 0)) {
	  var parentElmt = $(".modal-formmodal-container .cmp-form-modal-style  input[name='other']").parent();
      parentElmt.addClass('required-element');
      parentElmt.append('<span class="form_error">Required</span>');
      formError = true;
    }
	// Dropdown default validation
	 if($(".modal-formmodal-container  .modal-content .cmp-form-modal-style fieldset.cmp-form-options--drop-down select.cmp-form-options__field--drop-down").length > 0){		 
		 $(".modal-formmodal-container  .modal-content .cmp-form-modal-style fieldset.cmp-form-options--drop-down select.cmp-form-options__field--drop-down").each(function () {
                var checkBoxElement = $(this);
				if(checkBoxElement.val() == null){
					checkBoxElement.parent().append('<span class="form_error">Required</span>');
					checkBoxElement.parent().addClass('required-element');
					formError = true;
				}
            });	
    } else if ($("fieldset.cmp-form-options--drop-down select.cmp-form-options__field--drop-down").length > 0) {
            $("fieldset.cmp-form-options--drop-down select.cmp-form-options__field--drop-down").each(function() {
                var dropdownSelect = $(this);
                var reqMsg = $(this).attr('data-cmp-required-message');
                if (dropdownSelect.val() == null) {
                    dropdownSelect.parent().append('<span class="form_error">' + reqMsg + '</span>');
                    dropdownSelect.parent().addClass('required-element');
                    formError = true;
                }
            });			
	 }
	  //cmp-form-modal-style Form Appian Validation.
    if (form.parents(".cmp-form-modal-style").length > 0) {
        //Non Mandiatory Feilds Count should not exceed as per API
        if (payloadJson.middleName != undefined && !(payloadJson.middleName.length < 51)) {
			var parentElmt = $(".modal-formmodal-container .cmp-form-modal-style  input[name='middleName']").parent();
            parentElmt.addClass('required-element');
            parentElmt.append('<span class="form_error">Do not exceed 50 characters</span>');
            formError = true;

        }
        if (payloadJson.suffix != undefined && !(payloadJson.suffix.length < 21)) {
			var parentElmt = $(".modal-formmodal-container .cmp-form-modal-style  input[name='suffix']").parent();
            parentElmt.addClass('required-element');
            parentElmt.append('<span class="form_error">Do not exceed 20 characters</span>');
            formError = true;

        }
        //Mandiatory Feilds
        if (payloadJson.firstName != undefined && !(payloadJson.firstName.length < 51)) {
			var parentElmt = $(".modal-formmodal-container .cmp-form-modal-style  input[name='firstName']").parent();
            parentElmt.addClass('required-element');
            parentElmt.append('<span class="form_error">Do not exceed 50 characters</span>');
            formError = true;

        }
        if (payloadJson.lastName != undefined && !(payloadJson.lastName.length < 51)) {
			var parentElmt = $(".modal-formmodal-container .cmp-form-modal-style  input[name='lastName']").parent();
            parentElmt.addClass('required-element');
            parentElmt.append('<span class="form_error">Do not exceed 50 characters</span>');
            formError = true;

        }
        if (payloadJson.addressLine1 != undefined && !(payloadJson.addressLine1.length < 251)) {
			var parentElmt = $(".modal-formmodal-container .cmp-form-modal-style  input[name='addressLine1']").parent();
            parentElmt.addClass('required-element');
            parentElmt.append('<span class="form_error">Do not exceed 250 characters</span>');
            formError = true;

        }
        if (payloadJson.addressCity != undefined && !(payloadJson.addressCity.length < 51)) {
			var parentElmt = $(".modal-formmodal-container .cmp-form-modal-style  input[name='addressCity']").parent();
            parentElmt.addClass('required-element');
            parentElmt.append('<span class="form_error">Do not exceed 50 characters</span>');
            formError = true;

        }
        if (validEmailCheck && payloadJson.emailAddress != undefined && !(payloadJson.emailAddress.length < 251)) {
			var parentElmt = $(".modal-formmodal-container .cmp-form-modal-style  input[name='eAddress']").parent();
            parentElmt.addClass('required-element');
            parentElmt.append('<span class="form_error">Do not exceed 250 characters</span>');
            formError = true;

        }
        if (payloadJson.other != undefined && !(payloadJson.other.length < 251)) {
			var parentElmt = $(".modal-formmodal-container .cmp-form-modal-style  input[name='other']").parent();
            parentElmt.addClass('required-element');
            parentElmt.append('<span class="form_error">Do not exceed 250 characters</span>');
            formError = true;

        }
    }
	var zipElement = $(".modal-formmodal-container input[type='zipcode']");
    if (zipElement != undefined && zipElement.val() != undefined && zipElement.val().length > 0 && (zipElement.val().length !== 5 || !$.isNumeric(zipElement.val()))) {
	  var parentElmt = zipElement.parent();
      parentElmt.addClass('required-element');
      parentElmt.append('<span class="form_error">Required minimum 5 characters</span>');
      formError = true;
    }
	var telElement = $(".modal-formmodal-container input[type='tel']");
    if (telElement != undefined && telElement.val() != undefined && telElement.val().length > 0 && (telElement.val().length !== 10 || !$.isNumeric(telElement.val()))) {
	  var parentElmt = 	telElement.parent();
      parentElmt.addClass('required-element');
      parentElmt.append('<span class="form_error">Enter 10 digits with no parenthesis or hyphens</span>');
      formError = true;
    }
	
	if (formError === true) {
		  return false;
		}	
	// Adding a condition to skip reading values of cookies in payloadjson by checking if the form has cmp-form-modal-style 
    if (runCookiesScript == "true" && form.parents(".cmp-form-modal-style").length == 0) {
      var cookieList = ["AEID", "GUID", "DEVICE_TOKEN", "UUID"];

      for (var i = 0; i < cookieList.length; i++) {
        var cookieValue = readCookie(cookieList[i]);
        if (cookieValue != null && cookieValue.length > 0) {
          payloadJson[cookieList[i]] = cookieValue;
        }
      }

      var mcvidValue = readCookie("AMCV_A80B3BC75245AE7A0A490D4D%40AdobeOrg");
      if (mcvidValue != null && mcvidValue.length > 0) {
        var mcvidValuesArray = mcvidValue.split("|");
        if (mcvidValuesArray.length > 0) {
          for (var i = 0; i < mcvidValuesArray.length; i++) {
            if (mcvidValuesArray[i].indexOf("MCMID") >= 0) {
              payloadJson["MCVID"] = mcvidValuesArray[4];
              break;
            }
          }
        }
      }

      var iuidValue = readCookie("inst-nc");
      if (iuidValue != null && iuidValue.length > 0) {
        var iuidValuesArray = iuidValue.split("|");
        if (iuidValuesArray.length > 0) {
          for (var i = 0; i < iuidValuesArray.length; i++) {
            if (iuidValuesArray[i].indexOf("iuid") >= 0) {
              payloadJson["IUID"] = iuidValuesArray[i].split("=")[1];
              break;
            }
          }
        }
      }

      var ncValue = readCookie("nc");
      if (ncValue != null && ncValue.length > 0) {
        var ncValuesArray = ncValue.split("|");
        if (ncValuesArray.length > 0) {
          for (var i = 0; i < ncValuesArray.length; i++) {
            if (ncValuesArray[i].indexOf("firm") >= 0) {
              payloadJson["firm"] = ncValuesArray[i].split("=")[1];
              break;
            }
          }
        }
      }
      payloadJson["FormLocation"] = window.location.href;
    }
	
	if ( currentElement.data('requestRunning') ) {
        return;
    }

    currentElement.data('requestRunning', true);
	//disabled submit button for multiple calls on ccpa form.
	  if(form.parents(".cmp-form-modal-style").length !== 0){
		  currentElement.addClass('submitted_succuss');
	  }
    $.ajax({	  
      url: "/bin/capital-group-ofr/formemailServlet",
      type: "POST",
      data: {
        payload: JSON.stringify(payloadJson)
      },
      error: function(data) {
		  var formLength = form.parents(".cmp-form-modal-style").length;
		  //enabling submit button for multiple calls on ccpa form.
		  if(formLength !== 0){
			  currentElement.removeClass('submitted_succuss');
		  parent.children(".cmp_form_message").html("Your request did not go through.  Please resubmit your request.");
          parent.children(".cmp_form_message").show();
          form.find("div.text, div.button,div.options").hide();
          expFrag.find("div.cmp-text").parent().hide();
          ciNewsletter.css("width", "100%");
          $('.cmp-form-modal-style .cmp_form_message').css("width", 'fit-content');
          form.css("height", $('.cmp-form-modal-style .cmp_form_message').css("height"));
        } else {
          parent.children(".cmp_form_message").html(errorMessage);
          parent.children(".cmp_form_message").show();
        }
    
        var messageElement = parent.find(".cmp-form-text").last().append($(".cmp_form_message"));
        if(formLength !== 0){
         	var parentDiv=messageElement.parent("div.text");
         	parentDiv.find("input").hide();
         	parentDiv.show();
         	parentDiv.css("width", 'fit-content');
         	//trap Tab focus inside the Error modal
         	var modal =  document.querySelector(".modal-formmodal-container");
			if(modal){
				var firstFocusableElement = modal.querySelector(".formmodal-close");
				if(firstFocusableElement){
					var lastFocusableElement = firstFocusableElement;
					trapFocus(modal,firstFocusableElement,lastFocusableElement);
				}
			}
        }
        $(".cmp_form_message").addClass("formMainError");
        return false;
      },
      success: function(data) {
        var triggerDownload = parent.find(".cmp-form-button__download");
    	if(triggerDownload[0]){
              triggerDownload[0].click();
        }

		if (pathName == "/ria/tools/consultations-overview/consultations.html") {
			$("#submitAnalytics").attr("data-analytics-placement",payloadJson["Type of Consultation"]+" : body");
		}
    	$("#submitAnalytics").click();
        if (redirect !== "") {
          window.location.href = redirect;
        } else {
          parent.children(".cmp_form_message").html(thankYouMessage);
          parent.children(".cmp_form_message").show();
          form.find("div.text, div.button,div.options").hide();
          expFrag.find("div.cmp-text").parent().hide();
          ciNewsletter.css("width", "100%");
			if ($('div.cmp-form-thankyou-msg-style').length > 0) {
				form.css("height", "300px");
				$('html,body').animate({scrollTop: $('form.form-container').offset().top},1000);
			} else {
				if(form.parents(".cmp-form-modal-style").length > 0){
					 $('.cmp-form-modal-style .cmp_form_message').css("width", 'fit-content');
					form.css("height", $('.cmp-form-modal-style .cmp_form_message').css("height"));	
					 //trap tab focus in the Thank you modal
					 var modal =  document.querySelector(".modal-formmodal-container");
					 if(modal){
						 var firstFocusableElement = modal.querySelector(".formmodal-close");
						 if(firstFocusableElement){
							 var messageSpan = modal.querySelector("span.cmp_form_message");
							 var anchors = messageSpan?messageSpan.querySelectorAll("a"):messageSpan;
							 var lastFocusableElement = anchors?anchors[(anchors.length -1)]:messageSpan;
							 trapFocus(modal,firstFocusableElement,lastFocusableElement);
						 }
					 }
				}else{
					form.css("height", formHt);
				}
				
			}
        }
      },
      //Validating duplicate Ajax call
	  complete: function() {
            currentElement.data('requestRunning', false);
        }
    });
  });
  var trapFocus= function trapfocus(modal,firstFocusableElement,lastFocusableElement){
	       	document.addEventListener('keydown', function(e) {
	      	 let isTabPressed = e.key === 'Tab' || e.keyCode === 9;
	      	 if (!isTabPressed) {
	      		 return;
	      	 }

	      	 if (e.shiftKey) { // if shift key pressed for shift + tab combination
	      		 if (document.activeElement === firstFocusableElement) {
	      			 lastFocusableElement.focus(); // add focus for the last focusable element
	      			 e.preventDefault();
	      		 }
	      	 } else { // if tab key is pressed
	      		 if (document.activeElement === lastFocusableElement) { // if focused has reached to last focusable element then focus first focusable element after pressing tab
	      			 firstFocusableElement.focus(); // add focus for the first focusable element
	      			 e.preventDefault();
	      		 }
	      	 }
	       });
	       firstFocusableElement.focus(); 
  }
  function repositionPlaceholders() {
    var placeholderValue;
    $(".cmp-form-text input").each(function(i) {
      placeholderValue = $(this).attr("placeholder");
      $(this).attr("placeholder", "");
      $(this)
        .parent(".cmp-form-text")
        .attr("data-placeholdercontent", placeholderValue);
    });
  }

  function readCookie(cookieName) {
    for (
      var eachCookie = document.cookie.split(/;\s*/), i = eachCookie.length - 1;
      i >= 0;
      i--
    ) {
      if (!eachCookie[i].indexOf(cookieName)) {
        var cookieValue = eachCookie[i].replace(cookieName, "");
        cookieValue = decodeURIComponent(
          cookieValue.substring(1, cookieValue.length)
        );
        return cookieValue;
      }
    }
    return null;
  }
  
})(document, $);