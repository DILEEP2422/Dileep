$(document).ready(function() {

/*-----------------------------Textarea Line Count-------------------------*/

function CountNoOfLines(str){
    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

function LeftSpaceRemove(str) { 
    var re = /\s*((\S+\s*)*)/;
    return str.replace(re, "$1");
}

function RightSpaceRemove(str) { 
    var re = /((\s*\S+)*)\s*/;
    return str.replace(re, "$1");
}

function trim(str) {
    return LeftSpaceRemove(RightSpaceRemove(str));
}


function textAreaSize(txtArea, size){
    var str = $(txtArea).val()
    var lineBreaks =  CountNoOfLines(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		$(txtArea).val(trim(str));
    }
}
/*--------------------------------------------Extension Field Constraint-------------------------*/
$("#EXTN").mask('00000');

/*----------Cost Basis Referral------------*/

    $("#NOTE1").attr("maxlength","232");

    $("#NOTE2").attr("maxlength","232");
     $("#ADDRESS_DELIVERY").attr("maxlength","232");
     $("#ADDRESS_DELIVERY2").attr("maxlength","232");
    $("#ADDTNL_CMMNTS").attr("maxlength","588");

   $('#PHONE').on('keypress', function() {
    var p1 = $(this).val();
    var t1 =  ValidatePhone(p1);
        $("#PHONE").val(t1);

     $("#PHONE").attr("maxlength","14");

});
    $('#FAX').on('keypress', function() {
    var p1 = $(this).val();
    var t1 =  ValidatePhone(p1);
        $("#FAX").val(t1);

     $("#FAX").attr("maxlength","14");

});


    function ValidatePhone(p1){

	p1 = p1.replace(/ /g, "");
	p1 = p1.replace(/-/g, "");
	p1 = p1.replace(/\(/g, "");
	p1 = p1.replace(/\)/g, "");


	p = "";
	p = p1;
	
	var new_number = "";
	new_number  = "(";
	new_number += p.substr(0,1);
	new_number += p.substr(1,1);
	new_number += p.substr(2,1);	
	if (p.length >= 3){ new_number += ") "};
	new_number += p.substr(3,1);
	new_number += p.substr(4,1);
	new_number += p.substr(5,1);
	if (p.length >= 6){ new_number += "-"};
	new_number += p.substr(6,1);
	new_number += p.substr(7,1);
	new_number += p.substr(8,1);
	new_number += p.substr(9,1); 
      

	p1=new_number;

   return p1;    

}

function ValidatePhoneNew(p2){

	p2 = p2.replace(/ /g, "");
	p2 = p2.replace(/-/g, "");
	p2 = p2.replace(/\(/g, "");
	p2 = p2.replace(/\)/g, "");


	ph = "";
	ph = p2;

	var new_number = "";
	new_number  = "(";
	new_number += ph.substr(0,1);
	new_number += ph.substr(1,1);
	new_number += ph.substr(2,1);	
	if (ph.length >= 3){ new_number += ")"};
	new_number += ph.substr(3,1);
	new_number += ph.substr(4,1);
	new_number += ph.substr(5,1);
	if (ph.length >= 6){ new_number += "-"};
	new_number += ph.substr(6,1);
	new_number += ph.substr(7,1);
	new_number += ph.substr(8,1);
	new_number += ph.substr(9,1); 


	p2=new_number;

   return p2;    

}


/*----------CB&T Compliance form------------*/

    
     $("#approver").mask('SSSSSSSS');
    $("#ACCOUNTNO").attr("maxlength","50");

    $("#ACCOUNTOWNER").attr("maxlength","600").attr("data-maxrows","10").attr("title","Maximum 10 lines");
     $("#RESOLUTION").attr("maxlength","1800").attr("title","Maximum 30 lines");

     $("#DESCRIPTION").attr("maxlength","1800").attr("title","Maximum 30 lines");

if((document.URL).includes("cb-t-compliance-referral-form")){ 
    $('select[id=DEPARTMENT]').change(function () {
    if($("#DEPARTMENT").val() == "CB&T"){
		if(!($("#SITE").val() == "IND" || $("#SITE").val() == "IRV")){
			alert("-  Site should be either IND or IRV when CB&T department is selected\n");
			$("#SITE").prop("selectedIndex",0);
		}
	}
    });

 	$("#ACCOUNTOWNER").on('input', function() 
	{
		textAreaSize($(this), 10);
	});

    $("#DESCRIPTION").on('input', function() 
	{
		textAreaSize($(this), 30);
	});

    $("#RESOLUTION").on('input', function() 
	{
		textAreaSize($(this), 30);
	});

} 

/*----------RP movement assets------------*/


    $("#EXT").mask('00000');
     $("#CALLEREXT").mask('00000');

      $("#TIME").attr("maxlength","12");
       $("#SITUATION").attr("maxlength","1800");
    	$("#SITUATION").attr("title","30 lines maximum");
      $("#COMMENTS").attr("maxlength","1800");
    $("#COMMENTS").attr("title","30 lines maximum");



    //phone validation already present

/*----------non-critical------------*/
                 
    $("#APPROVINGTM").attr("maxlength","30");
    $("#ACCOUNTNUMBER").attr("maxlength","30");
    $("#SOCIALCODE").mask('000');
    $("#TRANSACTIONTYPE").attr("maxlength","30");
    $("#WORKTYPE").attr("maxlength","30");
    $("#DESCRIPTION").attr("maxlength","1800")
    $("#EXPECTEDRESULTS").attr("maxlength","1800")
    $("#OTHERMETHODSATTEMPTED").attr("maxlength","1800")

/*----------OGI ID REQUESt------------*/

     $('#ogiId').mask('AAAAAAAA');
    $("#CONTACTNAME").attr("maxlength","100");
    $("#NEWNAME").attr("maxlength","100");
    $("#PREVIOUSNAME").attr("maxlength","100");
    $("#ADDITIONALCOMMENTSHIDDEN").attr("maxlength","1800");

/*----------System Enhancement------------*/
    
    $("#DEPARTMENT").attr("maxlength","30");
    $("#APPROVINGTM").attr("maxlength","30");
    $("#DESCRIPTION").attr("maxlength","1800")
    $("#EXPECTEDRESULTS").attr("maxlength","1800")
    $("#OTHERMETHODSATTEMPTED").attr("maxlength","1800")
  
/*----------Vision Research Request------------*/

   $("#EXTENSION").mask('00000');   //number only
   $("#PHONEHIDDEN").attr("maxlength","14");
   $('#PHONEHIDDEN').on('keypress', function() {
    var p1 = $(this).val();
    var t1 =  ValidatePhone(p1);
        $("#PHONEHIDDEN").val(t1);
     });
   
    $("#SEQUENCE").mask('0000000000');        //number only
    $("#SAMPLEACCOUNT").mask('000000000000');   //number only
    $("#SEQUENCE").attr("maxlength","10");
    $("#ADDITIONALCOMMENTSHIDDEN").attr("maxlength","1800");
	$("#ADDITIONALCOMMENTSHIDDEN").attr("title","30 lines maximum");

/*----------web resolution checklist------------*/
    
    $("#EXT2").attr("maxlength","6");
    $("#issueerror").attr("maxlength","3600")
    $("#stepsadditionaldetails").attr("maxlength","3600")

/*----------g purch------------*/

     $("#planType").attr("maxlength","25");
      $("#Reason_code").attr("maxlength","2");
      $("#approver-4").mask('SSSSS');
      $("#tmsm").mask('SSSSS');
      $("#batchid").mask('0000000');
      $("#additional_comments").attr("maxlength","1800");


/*----------copy of cashed check------------*/


	$("#check-1").mask('0000000000');
	$("#date-1").attr("maxlength","10");
	
	$("#SPECIALINSTRUCTIONS").attr("maxlength","1800").attr("title","30 lines maximum");
	$("#EXT").attr("title","Extension - 5 numbers max");

/*----------Bank investment------------*/
$("#PHONE3").attr("maxlength","14");
$('#PHONE3').on('keypress', function() {
    var p1 = $(this).val();
    var t1 =  ValidatePhoneNew(p1);
        $("#PHONE3").val(t1);
     });
     
     $("#WIRETOTAL").attr("maxlength","15");
    $('#WIRETOTAL').maskMoney({ prefix:'$',allowEmpty:false});
    $("#ADDITIONALCOMMENTS").attr("maxlength","1800").attr("title","30 lines maximum");

/*----------Batch Ticket------------*/

    if((document.URL).includes("batch-ticket-investment"))
    { 
    	$("#COMMENTS").on('input', function()
		{
			textAreaSize($(this), 30);
		});
    }

      $("#BATCH").mask('0000000');
      $("#REASONCODE").mask('00');

/*----------TRAC2000------------*/
    
       $("#icu").mask('0');
       $("#reason_code").mask('00');

/*----------TRAC/OGI web resolution checklist------------*/
   
        $('#OTHEROPERSYSTEM').on('input', function(){

					   var len = $(this).val().length;

					   var ch = $(this).val();
					   
					   var regex = /^[a-zA-Z]*$/;

						if(!regex.test(ch))
						{
							$(this).val(ch.substring(0,len-1));
						}

				    });
					
					$('#OTHERBROWSER').on('input', function(){

					   var len = $(this).val().length;

					   var ch = $(this).val();
					   
					   var regex = /^[a-zA-Z]*$/;

						if(!regex.test(ch))
						{
							$(this).val(ch.substring(0,len-1));
						}

				    });


					  $("#EXT3").mask('000000');
					  $("#SSN-1").mask('0000');		  
					  $("#YOUREXT").mask('00000').attr("title","5 numeric characters only");
					  $("#RPTM").mask('SSSSS').attr("title","2 to 5 letter characters only");
					  $("#RPTMONE").mask('SSSSS').attr("title","2 to 5 letter characters only");
					  $("#RPTMTWO").mask('SSSSS').attr("title","2 to 5 letter characters only");
					  $("#COMPLETETASK").attr("maxlength","1800").attr("title","30 lines maximum");
					  $("#EXATSTEPS").attr("maxlength","1800").attr("title","30 lines maximum");
					  $("#CODEANDMESSAGE").attr("maxlength","1800").attr("title","30 lines maximum");
					  $("#DEPARTMENT-2").attr("maxlength","1800").attr("title","30 lines maximum");               
					  $("#TROUBLESHOOT").attr("maxlength","1800").attr("title","30 lines maximum");
				

/*----------call review------------*/

        $('#phone').on('keypress', function() {
    var p1 = $(this).val();
    var t1 =  ValidatePhone(p1);
        $("#phone").val(t1);

     $("#phone").attr("maxlength","14");

});
   $('#callerPhone').on('keypress', function() {
    var p1 = $(this).val();
    var t1 =  ValidatePhone(p1);
        $("#callerPhone").val(t1);

     $("#callerPhone").attr("maxlength","14");

});

if((document.URL).includes("call-review-request")){ 

    $("#investorName").on('input', function() 
{
	textAreaSize($(this), 3);
});
    $("#situation").on('input', function() 
{
	textAreaSize($(this), 30);
});
    $("#additionalcomments").on('input', function() 
{
	textAreaSize($(this), 30);
});
}


      $("#ext").mask('00000');
       $("#associatesinitials").mask('AAAAAAA');
       $("#associatesinitials").attr("minlength","3");
       $("#associatesext").mask('AAAAAAA');
       
        $("#timeofcall").attr("maxlength","30");
         $("#transactionline").attr("maxlength","4").attr("title","Transaction line â€“ 1 to 4 characters");
       $("#investorName").attr("maxlength","120").attr("title","3 lines maximum");
         $("#situation").attr("maxlength","1800").attr("title","30 lines maximum");
          $("#additionalcomments").attr("maxlength","1800").attr("title","30 lines maximum");

/*----------Participant check stop payment------------*/
     
      
        $('#phone_no').on('keypress', function() {
    var p1 = $(this).val();
    var t1 =  ValidatePhone(p1);
        $("#phone_no").val(t1);

     $("#phone_no").attr("maxlength","14");
     
});
     $("#icu1").attr("maxlength","1");
     $("#ssn").attr("maxlength","4");
     $("#AC").attr("maxlength","15");
      
 $('#dollar_amount').on('input', function(){

       var len = $('#dollar_amount').val().length;

       var ch = $('#dollar_amount').val();

       var regex = /^\d+(\.\d{0,2})?$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});

    $("#reson_manual_check_issued").attr("maxlength","1800");



/*-----------------------------------------------------------------------NON-LOB--------------------------------------------------------------*/

/*-----------------------------------------------------RP-Phone generated research---------------------------------------------*/
     $("#SOCIALSECNO").mask('0000');
     $("#RESEARCH").attr("maxlength","1800"); 

/*-----------------------------------------------------RKD -Corrections request--------------------------------------------*/
    $("#qc").attr("maxlength","7");
    $("#planid").attr("maxlength","12");
    $("#notifiedphone").attr("maxlength","12");

/*-----------------------------------------------------System SME checklist---------------------------------------------*/
  
    $("#planid-2").attr("maxlength","15");   
 
/*-----------------------------------------------------D/transcript request---------------------------------------------*/  
   $("#APPROVER").mask('SSSSS');
   $("#APPROVER").attr("minlength","2");
    $("#APPROVALREASON").attr("maxlength","50");
   $("#associate-initials").mask('SSSSS');
   $("#STATE").attr("maxlength","2");
   $("[name='ZIP']").attr("maxlength","10");

/*-----------------------------------------------------New Plan Maintain form---------------------------------------------*/  
   $("#addRemoveMoneyTypeNotes").attr("maxlength","1800"); 
   $("#enrollBooksNotes").attr("maxlength","1800");    
    $("#vestingScheduleUpdateNotes").attr("maxlength","1800"); 
   $("#fundChangesNotes").attr("maxlength","1800"); 
   $("#loanNotes").attr("maxlength","1800"); 
   $("#planContactNotes").attr("maxlength","1800"); 
   $("#riaNotes").attr("maxlength","1800"); 
   $("#tpaFeesNotes").attr("maxlength","1800");
   $("#closePlanNotes").attr("maxlength","1800");
   $("#fiduciaryServiceNotes").attr("maxlength","1800");
   $("#planSetupErrorsCorrectiveAction").attr("maxlength","1800");
   $("#feeLevelRecoveryNotes").attr("maxlength","1800");
   $("#addRemoveAfflNotes").attr("maxlength","1800");

/*-----------------------------------------------------Imaged Sources/ Imaging profiles request---------------------------------------------*/ 
  $('#ASSO_INITIALS').keyup(function(){
        $(this).val($(this).val().toUpperCase());
    });

/*----------------------------------------------------RPS System enhancement / manager backlog--------------------------------------------*/ 
	
	$("#suggestionIdea").attr("maxlength","300").attr("title","2 lines maximum");
    $("#currentState").attr("maxlength","300").attr("title","2 lines maximum");
    $("#desiredState").attr("maxlength","300").attr("title","2 lines maximum");
    $("#businessDriver").attr("maxlength","300").attr("title","2 lines maximum");
    $("#businessValue").attr("maxlength","300").attr("title","2 lines maximum");
    $("#businessImpact").attr("maxlength","300").attr("title","2 lines maximum");
    $("#currentWorkAroundVal").attr("maxlength","300").attr("title","2 lines maximum"); 
    $("#isReqTimeSensitiveVal").attr("maxlength","300").attr("title","2 lines maximum");
	
	if((document.URL).includes("rps-system-enhancement-manager-backlog-submission-form")){ 

    $("#suggestionIdea").on('input', function() 
{
	textAreaSize($(this), 2);
});
    $("#currentState").on('input', function() 
{
	textAreaSize($(this), 2);
});
    $("#isReqTimeSensitiveVal").on('input', function() 
{
	textAreaSize($(this), 2);
});
$("#currentWorkAroundVal").on('input', function() 
{
	textAreaSize($(this), 2);
});
    $("#businessImpact").on('input', function() 
{
	textAreaSize($(this), 2);
});
    $("#businessValue").on('input', function() 
{
	textAreaSize($(this), 2);
});
 $("#businessDriver").on('input', function() 
{
	textAreaSize($(this), 2);
});
$("#desiredState").on('input', function() 
{
	textAreaSize($(this), 2);
});
}
	
/*-------------------------------------------- batch ticket--------------------------------------------------------------------------------*/

		$("#batch").mask('0000000');

/*-------------------------------------------------------------------FD - MULTIFUND RPE NOTIFICATION / FUTURE DATE REQUEST FORM---------------------------*/
				$('#plaNid5').on('blur', function(){ 

				var planid1 = $(this).val();
				$("#planid1").val(planid1);
				});
				$('#planname').on('blur', function(){
				var planname2 = $(this).val();
				$("#planname1").val(planname2);
				});	
	
/*-------------------------------------TRAC WEB RESOLUTION CHECKLIST----------------------------------------------------------------------------*/
			$("#version").attr("maxlength","7");
/*-------------------------------------------------------Implementation Future Date Processing--------------------------------------------------------------*/
				$("#rpasubject").attr("maxlength","60");
				
/*------------------------------------------------------------FEEDBACK FORM--------------------------------------------------------------------------------*/

     
	 $("#associate").attr("maxlength","12");
	 $("#tm").attr("maxlength","7");
	 $("#account").attr("maxlength","70");
	  $("#summary").attr("maxlength","70");
	  
/*----------------------------------------INVOICE REQUEST FORM-------------------------------------------------------------------------*/

       $("#planID").attr("maxlength","17");
	 $("#Planname5").attr("maxlength","50");
	 $("#other").attr("maxlength","30");
	  $("#amount").attr("maxlength","10");
	  
/*-------------------------------------------------------------HOST PAYMENT ADMINISTRATION CONTACT FORM----------------------------------------------*/
				$('#contactphone').on('keypress', function() {
					var p1 = $(this).val();
					var t1 = ValidatePhoneNew(p1);
					$("#contactphone").val(t1);

					$("#contactphone").attr("maxlength","13");
					});
					$('#paymentamount').maskMoney({ prefix:'$',allowEmpty:false});
					$("#request").attr("title","30 lines maximum");          
/*------------------------------------------------------------------IC FOLLOW UP NEEDED----------------------------------------------------------*/

					$("#ic").attr("maxlength","60");
					 $("#icmanager").attr("maxlength","60");
					 $("#plaNid2").attr("maxlength","60");    
					  $("#Planname2").attr("maxlength","60"); 					  
					  $("#emaildate").attr("maxlength","40");
	                 $("#blackoutdate").attr("maxlength","40");
					 
					 
/*------------------------------------------Multiple Check Stop/Reissue Request for the Same Plan-----------------------------------------------------*/
					$("#numchx").attr("maxlength","10");
					 			$("#planName4").attr("maxlength","10");	 
					 $("#plaNid4").attr("maxlength","10"); 
					 $("#pssn").attr("maxlength","4");
					$("#pssn1").attr("maxlength","4");
					$("#pssn2").attr("maxlength","4");
					$("#pssn3").attr("maxlength","4");
					$("#pssn4").attr("maxlength","4");
					$("#pssn5").attr("maxlength","4");
					$("#pssn6").attr("maxlength","4");
					$("#pssn7").attr("maxlength","4");
					$("#pssn8").attr("maxlength","4");
					$("#pssn9").attr("maxlength","4");
					 
					 
/*-----------------------------------SPECIAL HANDLE/CHECK HOLD/CHECK CANCEL REQUEST-------------------------------------------------------------*/

	
                                         $("#ext-2").mask('AAAAAAA'); 
					
					 $("#planid5").attr("maxlength","12"); 
					 
/*-----------------------------TPA PSW Request-------------------------------------------------------------------------------------------------------*/
                      $("#planName3").attr("maxlength","40");  
					  $("#psw").attr("maxlength","15");
	                  $("#modelpsw").attr("maxlength","15");
					 $("#firmname").attr("maxlength","40");
					 $("#contact-name").attr("maxlength","40");
					 
/*--------------------------------------------Foundation Services Request-------------------------------------------------------------------------*/

						$("#ppmc").attr("maxlength","10");
					 
/*--------------------------------RKD PHONE MESSAGE FORM-------------------------------------------------------------------------------------------*/

					 $("#recipinits").attr("maxlength","7");
					  $("#recipientManager").attr("maxlength","7");
					  
/*--------------------------------ONLINE BATCH TICKET---------------------------------------------------------------------------------------------------*/
					if((document.URL).includes("online-batch-ticket")){
						
						
						$("#mancheck").css("color","#005f9e").css("border-color","#005f9e");
						$("#mancheck").parent().children().eq(0).css("color","#005f9e");
						$("#mancheck").parent().children().eq(2).css("color","#005f9e");


						$("#forfetiure").css("color","#005f9e").css("border-color","#005f9e");
						$("#forfetiure").parent().children().eq(0).css("color","#005f9e");
						$("#forfetiure").parent().children().eq(2).css("color","#005f9e");

						$("#loan").css("color","#005f9e").css("border-color","#005f9e");
						$("#loan").parent().children().eq(0).css("color","#005f9e");
						$("#loan").parent().children().eq(2).css("color","#005f9e");
						
						$("#redemption").css("color","#005f9e").css("border-color","#005f9e");
						$("#redemption").parent().children().eq(0).css("color","#005f9e");
						$("#redemption").parent().children().eq(2).css("color","#005f9e");
						
						$("#interest").css("color","#005f9e").css("border-color","#005f9e");
						$("#interest").parent().children().eq(0).css("color","#005f9e");
						$("#interest").parent().children().eq(2).css("color","#005f9e");
						
						$("#correction").css("color","#005f9e").css("border-color","#005f9e");
						$("#correction").parent().children().eq(0).css("color","#005f9e");
						$("#correction").parent().children().eq(2).css("color","#005f9e");
						
                      $("#batch").mask('AAAAAAA');
					  $("#reasoncode").attr("maxlength","7");
                      $("#qap").attr("maxlength","7");
					  
					  $("#reasoncode").attr("maxlength","10");
					  $("#noncurrentdate").attr("maxlength","10");
					  $("#approver3").attr("maxlength","7");
                      $('#prototal').prop("disabled",true);
                      $("#total").prop("disabled",true);

                     $(document).on('input', '[id^="amount"]', function () {
    				var amount=sumOnline().toFixed(2);
                    $("#prototal").click();
                    $('#prototal').val(amount);
					var totalSum=(Number(amount) + Number($("#overunder").val())).toFixed(2);
                    $("#total").click();
                    $("#total").val(totalSum);
                    $("#total").click();

                    });      
                    function sumOnline() {
                        var sum1=0;
                          $( '[id^="amount"]').each(function () {
                            sum1+=Number($(this).val());

                          });
						return sum1;
                        }
                $(document).on('input', '[id="overunder"]', function () {
                    var sum1=0
                    sum1=$(this).val();
                    var total= (Number(sum1)+Number($('#prototal').val())).toFixed(2);
                    $("#total").click();
                    $("#total").val(total);
                });
				
				}
/*-------------------------------------------------RPS Training Request--------------------------------------------------------------------------------*/
							 $("#title").attr("maxlength","60");
							  $("#number").attr("maxlength","8");
							 $("#site").attr("maxlength","11");
							  $("#target").attr("maxlength","11");
							  $("#owner").attr("maxlength","30");
							 $("#approver1").attr("maxlength","30"); 
							 
/*---------------------------------------------RP Services Abandoned Plans-----------------------------------------------------------------------*/
 						$("#plaNid3").attr("maxlength","15");   
							  $("#Planname3").attr("maxlength","40"); 
							 $("#ein").attr("maxlength","15");
							  $("#asset").attr("maxlength","15");
							  $("#forfeiture").attr("maxlength","15");
							 	
							 
							 
/*------------------------------------------------TM SYSTEM ENHANCEMENT REQUEST FORM-------------------------------------------------------------------*/


							$("#teammanager").attr("maxlength","7");
							  $("#seniormanager").attr("maxlength","7");
							 $("#submitter").attr("maxlength","7");
							  $("#dateapproved").attr("maxlength","10");
							  

/*-----------------------------------------------------RPS RESEARCH / TRANSACTION REQUEST---------------------------------------------------------------------*/					
					        
							  $("#callernum").attr("maxlength","15");
							 $("#helpDeskInitials").attr("maxlength","15");
							  $("#dateapproved").attr("maxlength","10");
  /*------------------------------------REPRINT REQUEST FOR CUSTOMIZED ENROLLMENT GUIDE ORDER-----------------------------------------------------------------*/					
							 $("#tss").attr("maxlength","4");
							  $("#stss").attr("maxlength","4");
							 $("#smiyr").attr("maxlength","4");
							  $("#ssmiyr").attr("maxlength","4");
								$("#cbtw").attr("maxlength","4");
							  $("#iltf").attr("maxlength","4");
							 $("#tdf").attr("maxlength","4");
						 
/*-------------------------------------------------------DEEM REVERSAL REQUEST-----------------------------------------------------------------------------*/
						 
							 $("#loan").attr("maxlength","7");
							  $("#loanorig").attr("maxlength","10");
								$("#loanmaturity").attr("maxlength","12");
							  $("#startdate").attr("maxlength","7");
							 $("#stopdate").attr("maxlength","7");
							 
							 $("#deemdate").attr("maxlength","10");
/*-------------------------------------------------------------RPS COMPLIANCE REFERRAL FORM------------------------------------------------------------------*/
							 $("#ASSOCIATEROLE").attr("maxlength","30");
							  $("#PID").attr("maxlength","30");
							 $("#PYIM").attr("maxlength","10");
							  $("#PLANPARTICIPANTNAME").attr("maxlength","240");
								$("#description").attr("maxlength","1800");
							  $("#Resolution").attr("maxlength","1800");
							 $("#Soni").attr("maxlength","1800");
							  $("#SCENARIODESCRIPTION").attr("maxlength","1800");
							  $("#ACTIONTAKEN").attr("maxlength","1800");
							 $("#SSN").attr("maxlength","4");
							  $("#LOANNUMBER").attr("maxlength","15");
								$("#NOTCURRENTLOAN").attr("maxlength","1800");
							  $("#LOANCIRCUMSTANCES").attr("maxlength","1800");
							  $("#PLANDESCOCCURRED").attr("maxlength","1800");
							 $("#PLANSPONSORSTEPS").attr("maxlength","1800");
							 $("#PLANADDITIONALQUE").attr("maxlength","1800");
							 $("#PLANPROPOSESOLUTIONTESTING").attr("maxlength","1800");
							 $("#PLANPROPOSEDQUES").attr("maxlength","1800");
							 $("#PLANELECTIONCURRENTPRO").attr("maxlength","1800");
							 $("#PLANAPPEARDESCRIBELINE").attr("maxlength","1800");
							  $("#PLANPURPOSEDESCRIBE").attr("maxlength","1800");
							 $("#PLANDESCRIBELINEREAD").attr("maxlength","1800");
							  $("#PLANDOCREQUESTIMPACT").attr("maxlength","1800");
								$("#PLANDESCWHATOCCURRED").attr("maxlength","1800");
							  $("#PLANDESCSTEPSTOCORRECT").attr("maxlength","1800");
							  $("#PLANSPONSORADDQUE").attr("maxlength","1800");
							 $("#PLANPROPOSESOLUTION").attr("maxlength","1800");
							 $("#PLANSPONSORADDQUEPROPOSAL").attr("maxlength","1800");
/*--------------------------------------------------------Loan Re-amortization Request----------------------------------------------------------*/
				 $("#matdate").attr("maxlength","11");
				  $("#nextpayment").attr("maxlength","11");
				  $("#phone-4").attr("maxlength","30");
				  $('input[name=nochg]').change(function () 
         {
             $("input[name=nochg]").each(function ()
            {
                  if ($("input[name=nochg]:checked").val() == "No Change") 
                { 
                     $("#matdate").removeAttr('type');
                     $('#matdate').attr('type', 'text')                      
                     $("#matdate").prop( "value", "No change" );
                    }
               if ($("input[name=nochg]:checked").val() == undefined) 
               {
                  $("#matdate").removeAttr('type');
                     $('#matdate').attr('type', 'date')                      
                     $("#matdate").prop( "value", "" ); 
               }
                 });

                 });
				 
/*---------------------------------	EMPOWER TECHNICAL ISSUES REPORT-----------------------------------------------------------------------------------*/

			$("#detailedDescription").attr("maxlength","1800").attr("title","30 lines maximum");
$("#expectedResults").attr("maxlength","1800").attr("title","30 lines maximum");
$("#plansAffected").attr("maxlength","1800");
$("#ISSUEIMPACT").attr("maxlength","1800").attr("title","30 lines maximum");
$("#workaround").attr("maxlength","1800").attr("title","30 lines maximum");
				  
/*-----------------------------------------------------------------BIRG REFERRAL FORM---------------------------------------------------------------------------*/
							 $("#Extension").attr("maxlength","5");
/*-------------------------------------------------------------SPECIAL HANDLE REQUEST--------------------------------------------------------------------*/
							$('#TMEXTENSION').mask('00000');
							$("#BILLING_NUMBER").attr("maxlength","35");
							$("#ADDITIONAL_COMMENTS").attr("maxlength","1800");
							
							if ((document.URL).includes("special-handle-request")) {

							$("#ADDITIONAL_COMMENTS").on('input', function()
							{
							textAreaSize($(this), 10);
							});
							$("#SPECIAL_INSTRUCTIONS").on('input', function()
							{
							textAreaSize($(this), 6);
							});

							}
														 
/*-------------------------------------------408(B)(2) FEE DISCLOSURE MAILING-------------------------------------------------------------------------------*/
									$('#PHONE2').on('keypress', function() { 
									var p1 = $(this).val();
									var t1 =  ValidatePhone(p1);
										$("#PHONE2").val(t1);

									 $("#PHONE2").attr("maxlength","14");

								});
                                       $("#PLANSPONSORNAME").attr("maxlength","1800"); 
   									 $("#ADDRESS").attr("maxlength","1800");															 
								   $('#EXTVALUE').mask('00000');
								    $('#CURRENTSOCIALCODE').mask('000');
									
/*--------------------------------------------------------------------ASSOCIATE FEEDBACK----------------------------------------------------------------------*/
								$("#Assoc").attr("maxlength","8");
								$("#AssocTM").attr("maxlength","8");
								$("#Date").attr("maxlength","10");
								$("#Account").attr("maxlength","25");
/*--------------------------------------------------------------ADVISER LOCATOR REQUEST FORM--------------------------------------------------------------------*/
									$("#CALLDATE").attr("maxlength","10");
								$("#acTypeOtherText").attr("maxlength","60");
								$("#planTypeDetails").attr("maxlength","1800");
								$("#ACCOUNT").attr("maxlength","20");
								$("#name").attr("maxlength","50");
								$("#address1").attr("maxlength","40");
								$("#FORMATTEDADDRESS").attr("maxlength","40");
								$("#CITY").attr("maxlength","30");								
								$("#PHONE1").attr("maxlength","30"); 
								$("#TOWNS").attr("maxlength","30");
								$('#PHONE1').on('keypress', function() {
								var p1 = $(this).val();
								var t1 =  ValidatePhone(p1);
									$("#PHONE1").val(t1);

								 $("#PHONE1").attr("maxlength","30"); 

							});
							
/*-----------------------------------------------------------------UFIDX------------------------------------------------------------------------------------------*/	   
	                   $("#planidx").attr("maxlength","10"); 
/*---------------------------------------------copy of cashed check request-------------------------------------------------------*/    
                       $("#bankAccount_rkd").prop( "value", "4375-666666" );
                    $("#bankAccount_rkd").prop( "disabled", true );
                   $("#check_rkd").mask('0000000000');
                 $("#date_rkd").attr("maxlength","10");
            $('[name^="amtdemo"]').attr("maxlength","15");
     $(document).on('input','[name^="amtdemo"]', function(){
    $('[name^="amtdemo"]').maskMoney({ prefix:'$',allowEmpty:false});
});
/*---------------------------------------------trac2000 -------------------------------------------------------*/ 

    $('[name^="planid_trac"]').attr("maxlength","10");
    $('[name^="check_trac2"]').attr("maxlength","15");
    $('[name^="pamtdemo"]').attr("maxlength","15");
    $('[name^="vamtdemo"]').attr("maxlength","15");
    $(document).on('input','[name^="pamtdemo"]', function(){
      $('[name^="pamtdemo"]').maskMoney({ prefix:'$',allowEmpty:false});
});
    $(document).on('input','[name^="vamtdemo"]', function(){
     $('[name^="vamtdemo"]').maskMoney({ prefix:'$',allowEmpty:false});
});
/*-------------------------------------------------------- Date Validations-----------------------------------*/
 /* --------------------------------------foundation-services-------------------------------*/
        if((document.URL).includes("foundation-services-request")){ 

                    function minDays(theDate, days) {
                    return new Date(theDate.getTime() - days*24*60*60*1000);
                    }
                        var minDate = minDays(new Date(),0).toISOString().substring(0, 10);
                        var field = document.querySelector('#dateNeeded');
                        field.setAttribute("min",minDate);

        }
/*---------------------------------------------Imaged sources------------------------------------------------------*/
   if((document.URL).includes("imaged-sources-imaging-profile-change-request")){ 

        $('#DATE_SOURCE').on('input', function() {
    
         var slicedDate = $('#DATE_SOURCE').val().substring(5, 10);
          $("#DATE_SOURCE").removeAttr('type');
          $('#DATE_SOURCE').attr('type', 'text');

        var dateArr = slicedDate.split("-");
        var customFormattedDate = dateArr[0] + "/" + dateArr[1] ;
    
         $('#DATE_SOURCE').val(customFormattedDate);

});
        $('#DATE_SOURCE').on('click', function() {
            var attr = $(this).attr('type');

            if(attr=='text')
            {
                $("#DATE_SOURCE").removeAttr('type');
                $('#DATE_SOURCE').attr('type', 'date');


            }
 });
   }   

/*---------------------------------------------RPS Announcement------------------------------------------------------*/
      if((document.URL).includes("rps-announcement-communication-request-form")){ 

       function minDays(theDate, days) {
                    return new Date(theDate.getTime() - days*24*60*60*1000);
                    }
                        var minDate = minDays(new Date(),0).toISOString().substring(0, 10);
                        var field = document.querySelector('#txtCommunicationDate');
                        field.setAttribute("min",minDate);

                    
                    function selectedDays(e){

                    var day = new Date(e.target.value).getUTCDay();
					if( day != 3 && day != 5 ){


                        alert('Please only select Fridays or Wednesdays');
                        e.preventDefault();
    					this.value = '';


                    } 

					}
                var dateField = document.querySelector('#txtCommunicationDate');
                          dateField.addEventListener('input', selectedDays);
    }

 /*---------------------------------------------Implementation Future date processing------------------------------------------------------*/

        if((document.URL).includes("implementation-future-date-processing")){ 

       $('#procdate').prop("disabled",true);
       $('#tradedate').on('input', function() {

     var datevalue = $('#tradedate').val();


          function proDate(datevalue, days) {
                var day = new Date(datevalue).getUTCDay();
                if(day ==1){
                days =3;
                }
                else if (day ==0)
                {
                days =2;
                }

                return new Date(new Date(datevalue).getTime() - days*24*60*60*1000);

                }
          var newDate = proDate(datevalue,1);
          var finalDate = newDate.toISOString().substring(0, 10);
        var field = document.querySelector('#procdate');
        field.value = finalDate ;
    });
        }

 /*---------------------------------------------Reprint customized enrollment------------------------------------------------------*/
      if((document.URL).includes("reprint-request-for-customized-enrollment-guide-order")){ 
          $('input[name=copyadv]').change(function () 
		 {
             $("input[name=copyadv]").each(function ()
        	{
                  if ($("input[name=copyadv]:checked").val() == "Same as Advisor") 
				{ 
    	             $("#reqname").val($("#advname").val());
                     $("#reqname").click();
                     $("#reqphone").val($("#advphone").val());
                     $("#reqphone").click();

					}

                else if($("input[name=copyadv]:checked").val() == undefined) 
				{ 
                    console.log("OK")
                     $("#reqname").val("");
    	             $("#reqphone").val("");

					}
				 
				 });
				 
				 });
           $('input[name=ship]').change(function () 
		 {
             $("input[name=ship]").each(function ()
        	{
                  if ($("input[name=ship]:checked").val() == "Financial Advisor" && $("[name='Requestor']")[0].checked) 
				{ 
    	             $("#attn").val($("#advname").val());
					 $("#attn").click();
                     $("#cophone").val($("#advphone").val());                     
                     $("#cophone").click();
					 $("#reqname").val($("#advname").val());                     
                     $("#reqname").click();
					 $("#reqphone").val($("#advphone").val());                     
                     $("#reqphone").click();

					}

                else if($("input[name=copyadv]:checked").val() != "Financial Advisor") 
				{ 
                     $("#attn").val("");
    	             $("#cophone").val("");

					}
				 
				 });

			});

			$(document).on('change', '[name="ship"]', function () {   
                if ($("[name='ship']")[1].checked && $("[name='Requestor']")[1].checked)
                {
                    var reqName=$("#reqname").val();
                    var reqPhone=$("#reqphone").val();
                    $("#attn").val(reqName);
                    $("#cophone").val(reqPhone);
                }
            	if ($("[name='ship']")[2].checked && $("[name='Requestor']")[3].checked)
                {
                    var reqName=$("#reqname").val();
                    var reqPhone=$("#reqphone").val();
                    $("#attn").val(reqName);
                    $("#cophone").val(reqPhone);
                }
            });

           $('#pbdate').parent().parent().hide();
             var myDate = new Date(new Date().getTime()+(15*24*60*60*1000));
             var defdate = myDate.toISOString().substring(0,10);
             var field = document.querySelector('#delivdate');
             field.value = defdate ; 

        function isBiz(dateValue){
	var dobj = new Date(dateValue); // date object
	
	var dayindex = dobj.getDay(); // get day of week index
	
	// 0 = sunday, 6 = saturday
	
	if (dayindex == 0 || dayindex == 6){
		return false;	// not biz	
	} else {
		return true; // yes biz
	}	
   }


        function testDistance(dateValue){
	var curr = new Date(); // current date
	var mscurr = curr.getTime();
	
	var seldate = new Date(dateValue); // selected date	
	var mssel = seldate.getTime();
	
	var inst; // holds date instance
	var daycount = 0; // counts calendar days
	var nbcount = 0; // counts weekend days
	var dow;
	
	while (mscurr <= mssel) {
		mscurr += 86400000;	
		daycount++;
		
		inst = new Date(mscurr);
		
		dow = inst.getDay(); // day of week
		
		if (dow == 0 || dow == 6) {
			nbcount++; // increment non-biz day count				
		} 
	}// end while
		
	var result = daycount - nbcount;
		
	return result;
        }

        $('#delivdate').on('change', function(){
	var prev = $(this).data('val');
	var dist = testDistance($(this).val());
	var bool = isBiz($(this).val());

	if(bool) {
		if (dist < 8) {
		
			var msg = "Delivery Date must be 8 or more business days from current date.  Please choose a different Delivery Date." +
				"  Please note approvals for exceptions granted in the 'Comments / Exception Approvals / Additional" +
				" Address' field below.";
			alert(msg);
			$(this).val(prev);
            $('#pbdate').val('');
		}
	} else {
		alert("Please select a valid business day.");			
		$(this).val(prev);
        $('#pbdate').val('');
	}
              if( $('#delivdate').val() != ''){
              var prodate = $('#delivdate').val();
            var prodate2 = new Date(new Date(prodate).getTime() - 8*24*60*60*1000).toISOString().substring(0, 10);
            $('#pbdate').val(prodate2);
            }
  });
      }
/*------------------------------------------------------FD multifund notification------------------------------------------------------*/
    if((document.URL).includes("fd-multifund-rpe-notification-future-date-request-form")){ 

        $('select[name=reqtype]').change(function () 
         {
             $("selct[name=reqtype] option:selected").each(function ()
            {
                  if ($(this).val() == "Investment Option Change - Mapping - Unit Class Change" || $(this).val() == "Investment Option Change - Mapping - Inv Opt Replacement") 
                  {
                      function pastDays(theDate, days) {
					var day = new Date(theDate).getUTCDay();
                        if(day ==1){
                            days =3;
                        }
                        else if (day ==0)
                        {
			    days =2;
                        }

                    return new Date(theDate.getTime() - days*24*60*60*1000);

                    }
                    
                    function minDays(theDate, days) {
                    return new Date(theDate.getTime() - days*24*60*60*1000);
                    }
                    function maxDays(theDate, days) {
                    return new Date(theDate.getTime() + days*24*60*60*1000);
                    }
                    
                    var newDate = pastDays(new Date(),1);
                  
                    var finalDate = newDate.toISOString().substring(0, 10);
                    var field = document.querySelector('#effdate');
                    field.value = finalDate ;
                    

                    function noWeekends(e){

                    var day = new Date(e.target.value).getUTCDay();
			if( day == 0 || day == 6 ){

                		
                        alert('Cannot be a weekend');
                        e.preventDefault();
                        this.value = '';


                    } 

					}
                    var dateField = document.querySelector('#tradedt');
                    dateField.addEventListener('input',noWeekends);

				}

                else if ($(this).val() == "Loan Provision Add / Remove")
                {
                     function noWeekends(e){

                    var day = new Date(e.target.value).getUTCDay();
		
                     if( day == 0 || day == 6 ){

                		
                        alert('Cannot be a weekend');
                        e.preventDefault();
    			this.value = '';


                    } 

					}
                    var dateField = document.querySelector('#effdate');
                    dateField.addEventListener('input',noWeekends);

				}

               });
         });

  }      
/*------------------------------------------------------FD rpe notification------------------------------------------------------*/
     if((document.URL).includes("fd-rpe-notification-future-date-request-form")){ 

        $('select[name=reqtype]').change(function () 
         {
             $("selct[name=reqtype] option:selected").each(function ()
            {
                  if ($(this).val() == "Money Type Change" || $(this).val() == "Loan Provision Add / Remove" || $(this).val() == "Loan Provision Add / Remove" ) 
                  {
                      function noWeekends(e){

                    var day = new Date(e.target.value).getUTCDay();
					if( day == 0 || day == 6 ){

                		
                        alert('Cannot be a weekend');
                        e.preventDefault();
    					this.value = '';


                    } 

					}
                    var dateField = document.querySelector('#effdate');
                    dateField.addEventListener('input',noWeekends);

				}
       });
     });
            }  

 /*--------------------------------------GPurch datepicker ------------------------------*/

if((document.URL).includes("g-purch-batch-ticket")){ 

        $("[id='today_date']").click(function() {
         function currDay(theDate, days) {
                    return new Date(theDate.getTime() - days*24*60*60*1000);
                    }
            var currentDate = currDay(new Date(),0).toISOString().substring(0, 10);
            var field = document.querySelector('input[name="tradeDate"]');
            field.value = currentDate ;
            field.click();
});
            } 

/*----------------------------batch-ticket-investment-----------------------------*/

if((document.URL).includes("batch-ticket-investment")){ 

       $("[id='today_date']").click(function() {
         function currDay(theDate, days) {
                    return new Date(theDate.getTime() - days*24*60*60*1000);
                    }
            var currentDate = currDay(new Date(),0).toISOString().substring(0, 10);
            var field = document.querySelector('input[name="TRADEDATE"]');
            field.value = currentDate ;
            field.click();
});
            }
/*-------------------call-review-request date picker validation------------------*/


if((document.URL).includes("call-review-request")){ 

        $("#startdate").change(function() {
			var startDate = document.querySelector('#startdate').value;
            console.log(startDate);
            var field = document.querySelector('#enddate');
            if(startDate != undefined){
                field.setAttribute("min",startDate);}
	});
}


/*------------------------------------fd-multifund-rpe-notification-future-date-request-form calc days ----- */


if((document.URL).includes("fd-multifund-rpe-notification-future-date-request-form")){ 
		$("#numdays").mask('000000');
        $('#calcbtn').click(function() {
         function addDays(theDate, days) {
                    return new Date(theDate.getTime() + days*24*60*60*1000);
                    }
            var days = document.querySelector('#numdays').value;
            var effdate = addDays(new Date(),days).toISOString().substring(0, 10);
            var field = document.querySelector('#effdate');
            field.value = effdate ;
});
            }
/*------------------------------------fd-rpe-notification-future-date-request-form calc days ----- */


if((document.URL).includes("fd-rpe-notification-future-date-request-form")){ 
		$("#numdays").mask('000000');
        $('#calcbtn').click(function() {            
         function addDays(theDate, days) {
                    return new Date(theDate.getTime() + days*24*60*60*1000);
                    }
            var days = document.querySelector('#numdays').value;
            var effdate = addDays(new Date(),days).toISOString().substring(0, 10);
            var field = document.querySelector('#effdate');
            field.value = effdate ;
            $("#effdate").focus();
});
            }

/*---------------------------------------------GPurch ----------------------------------------------------------------*/ 
                      $("#groupplan_gpurch").attr("maxlength","10");
                  $("#check_gpurch").attr("maxlength","15");
/*--------------------------------------------- batch ticket ----------------------------------------------------------------*/ 
            $('[name^="fund_batch"]').mask('00000');
            $('[name^="account_batch"]').mask('000000000000');
			 $('#depositTotal').maskMoney({ prefix:'$',allowEmpty:false});
               $("#depositTotal").attr("maxlength","15");
			   $('#outOfBalanceReadOnly').maskMoney({ prefix:'$',allowEmpty:false});
			$('#outOfBalanceReadOnly').prop("disabled",true);
              $('#feeAmount').maskMoney({ prefix:'$',allowEmpty:false});
               $("#feeAmount").attr("maxlength","15");
/*-------------------------------------------batch ticket ----------------------------------------------------------------*/     
                    $("#conp").attr("maxlength","10");
                     $("#fund_conp").attr("maxlength","5");
                     $("#account_conp").attr("maxlength","12");
/*---------------------------------------------TRAC we resolution----------------------------------------------------------------*/

    		  $('[name^="gPurch-text"]').mask('000000000000');
              $("#planid_trac").attr("maxlength","12");
              $("#psw_trac").attr("maxlength","12"); 
 /*---------------------------------------------cdsc fee payments to fund ------------------------------*/
    		  $('[name^="fund_cdsc"]').mask('00000');
				$('[name^="account_cdsc"]').mask('000000000000');
    			$("#COMMENTS").attr("title","30 lines maximum");
/*------------------------------------RP Phone Generated Research ------------------------------------------*/
   				$("#RESEARCH").attr("title","30 lines maximum");
/*------------------------------------DAVAST----------------------------------------------------------------*/
             $('[name="FAX"]').on('keypress', function() 
           {
            	var p1 = $(this).val();
            	var t1 =  ValidatePhone(p1);
                $(this).val(t1);       
             	$(this).attr("maxlength","14");
        
        });



/*---------------------------------------------------WEB RESOLUTION CHECKLIST(**)-----------------------------------------------------------------------------*/
	if((document.URL).includes("web-resolution-case")){ 
       $('#PHONE-check').on('keypress', function() {
    if(!$("#internationalcall").prop('checked'))
    {
    var p1 = $(this).val();
    var t1 =  ValidatePhone(p1);
        $("#PHONE-check").val(t1);
         $("#PHONE-check").attr("maxlength","14");
    
    }
   
});

 $('input[name="internationalcall"]').change(function () 
		 {
            $('input[name="internationalcall"]').each(function ()
        	{
                if($('input[name="internationalcall"]:checked'))
                {
                $("#PHONE-check").val('');
                $("#PHONE-check").removeAttr('maxlength');
                }
                else
                {
                  $("#PHONE-check").val('');
                }
            });
     });
    
     }
/*----------------------------------------------RPS COMPLIANCE REFERRAL FORM---------------------------------*/
if((document.URL).includes("rps-compliance-referral-form"))
{

	$("#PLANPARTICIPANTNAME").on('input', function()
	{
		textAreaSize($(this), 4);
	});

	$("#description").on('input', function()
	{
		textAreaSize($(this), 30);
	});
	$("#Resolution").on('input', function()
	{
		textAreaSize($(this), 30);
	});
}
/*----------------------------------------------Copy of Cashed Check Request---------------------------------*/
if((document.URL).includes("copy-of-cashed-check-request"))
{

	$("#SPECIALINSTRUCTIONS").on('input', function()
	{
		textAreaSize($(this), 30);
	});

}
/*----------------------------------------------Empower Technical Issues Report---------------------------------*/
if((document.URL).includes("empower-technical-issues-report"))
{

	$("#detailedDescription").on('input', function()
	{
		textAreaSize($(this),30);
	});

	$("#expectedResults").on('input', function()
	{
		textAreaSize($(this), 30);
	});
	$("#plansAffected").attr("title","30 lines maximum")
	$("#plansAffected").on('input', function()
	{
		textAreaSize($(this), 30);
	});
    $("#ISSUEIMPACT").on('input', function()
	{
		textAreaSize($(this), 30);
	});
    $("#workaround").on('input', function()
	{
		textAreaSize($(this), 30);
	});
}
/*----------------------------------------------NON-CRITICAL SYSTEM ISSUES SUBMISSION---------------------------------*/
if((document.URL).includes("non-critical-system-issues-submission"))
{

	$("#DESCRIPTION").on('input', function()
	{
		textAreaSize($(this), 30);
	});

	$("#EXPECTEDRESULTS").on('input', function()
	{
		textAreaSize($(this), 30);
	});
	$("#OTHERMETHODSATTEMPTED").on('input', function()
	{
		textAreaSize($(this), 30);
	});
}
/*----------------------------------------------OGI ID REQUEST---------------------------------*/
if((document.URL).includes("ogi-id-request"))
{

	$("#ADDITIONALCOMMENTSHIDDEN").on('input', function()
	{
		textAreaSize($(this), 30);
	});

}
/*---------------------------------------------RP Movement Telephone Referral---------------------------------*/
if((document.URL).includes("rp-movement-telephone-referral"))
{

	$("#SITUATION").on('input', function()
	{
		textAreaSize($(this), 30);
	});

	$("#COMMENTS").on('input', function()
	{
		textAreaSize($(this), 30);
	});

}
/*----------------------------------------------SYSTEM ENHANCEMENT REQUEST---------------------------------*/
if((document.URL).includes("system-enhancement-request"))
{

	$("#DESCRIPTION").on('input', function()
	{
		textAreaSize($(this), 30);
	});

	$("#EXPECTEDRESULTS").on('input', function()
	{
		textAreaSize($(this), 30);
	});
	$("#OTHERMETHODSATTEMPTED").on('input', function()
	{
		textAreaSize($(this), 30);
	});
}
});    