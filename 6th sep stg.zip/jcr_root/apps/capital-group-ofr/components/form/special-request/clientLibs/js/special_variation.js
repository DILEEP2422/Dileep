$(document).ready(function () 
{
    $(document).on('change', 'select[name^="damount"]',function () 
    {
        $("select[name^='damount'] option:selected").each(function ()
         {

             if($(this).val()=="All")
             {
                 $(this).parent().parent().parent().children().eq(3).children().val('');
                 $(this).parent().parent().parent().children().eq(3).children().prop("disabled",true);
             }
             else
             {
				$(this).parent().parent().parent().children().eq(3).children().prop("disabled",false);             
             }
         });
    });

     $(document).on('change', 'select[name^="fType"]',function () 
    {
        $("select[name^='fType'] option:selected").each(function ()
         {

             if($(this).val()=="Default W/H" || $(this).val()=="None")
             {
                 $(this).parent().parent().parent().children().eq(5).children().val('');
                 $(this).parent().parent().parent().children().eq(5).children().prop("disabled",true);
             }
             else
             {
				$(this).parent().parent().parent().children().eq(5).children().prop("disabled",false);             
             }
         });
    });
    $(document).on('change', 'select[name^="sType"]',function () 
    {
        $("select[name^='sType'] option:selected").each(function ()
         {

             if($(this).val()=="Default W/H" || $(this).val()=="None")
             {
                 $(this).parent().parent().parent().children().eq(7).children().val('');
                 $(this).parent().parent().parent().children().eq(7).children().prop("disabled",true);
             }
             else
             {
				$(this).parent().parent().parent().children().eq(7).children().prop("disabled",false);             
             }
         });
    });
});
