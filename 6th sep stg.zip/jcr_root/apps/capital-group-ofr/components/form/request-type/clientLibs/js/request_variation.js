$(document).ready(function ()
{
   $(document).on('change', 'select[name^="AccType"]',function ()
     {
    $("select[name^='AccType'] option:selected").each(function ()
      {

         if($(this).val()=="All")
            {
            $(this).parent().parent().parent().children().eq(5).children().val('');
            $(this).parent().parent().parent().children().eq(5).children().prop("disabled",true);
            }
         else
            {
            $(this).parent().parent().parent().children().eq(5).children().prop("disabled",false); }
            });
     });
});