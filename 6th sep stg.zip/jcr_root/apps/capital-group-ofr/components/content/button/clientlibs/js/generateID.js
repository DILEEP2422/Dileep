use(function() {
  let randomNumber = Math.round(
    new Date().getTime() + Math.random() * 1000000000000000
  );

  return randomNumber;
});
