(function(document, $) {
    "use strict";

	let 
    	buttonText = {},
        analyticsIdValue = {},
        isAnalyticsDisabled = false,
        setAnalyticsIdValue = function (){};
	
        setAnalyticsIdValue= function(buttonTextElement) {
            isAnalyticsDisabled = $("input[name~='./disabledanalytics']").prop("checked");
            if (!isAnalyticsDisabled) {
                analyticsIdValue = $("input[name~='./dataanalyticsid']");
                $(analyticsIdValue).val(buttonTextElement.value);
            }
        };

    $(document).on("foundation-contentloaded", function(e) {
        buttonText = $("input[name~='./jcr:title']")[1];
        $(buttonText).on("input", function() {
            setAnalyticsIdValue(buttonText);
        })
    });

    $(document).on("click", "input[name~='./disabledanalytics']", function(e) {
        setAnalyticsIdValue(buttonText);
    });

})(document, Granite.$);