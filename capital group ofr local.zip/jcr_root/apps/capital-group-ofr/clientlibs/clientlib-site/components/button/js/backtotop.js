/*
 //ES6 code
document.addEventListener("DOMContentLoaded",()=>{
    const scrollToTopButton = document.querySelector('.cmp-button--backtotop');

    const scrollToTop = () => {
        const scrollPosition = document.documentElement.scrollTop || document.body.scrollTop;
        if (scrollPosition > 0) {
          window.requestAnimationFrame(scrollToTop);
          window.scrollTo(0, scrollPosition - scrollPosition / 10);
        }
    };    

    const handleScrollToTop = () => {
        if (window.scrollY >= 2 * (document.documentElement.clientHeight)) {
            scrollToTopButton.className = "cmp-button--backtotop show";
        } else {
            scrollToTopButton.className = "cmp-button--backtotop hide";
        }
    };

    if(scrollToTopButton) {
        const contactUsButton = document.querySelector('.cmp-contactusmodal__layout');
        contactUsButton ? contactUsButton.classList.add('cmp-contactusmodal__reposition') : null;
        scrollToTopButton.addEventListener('click', () => scrollToTop());
        window.addEventListener("scroll", handleScrollToTop);
    }
});
*/

"use strict";

document.addEventListener("DOMContentLoaded", function () {
  var scrollToTopButton = document.querySelector('.cmp-button--backtotop');

  var scrollToTop = function scrollToTop() {
    var scrollPosition = document.documentElement.scrollTop || document.body.scrollTop;

    if (scrollPosition > 0) {
      window.requestAnimationFrame(scrollToTop);
      window.scrollTo(0, scrollPosition - scrollPosition / 10);
    }
  };

  var handleScrollToTop = function handleScrollToTop() {
    if (window.scrollY >= 2 * document.documentElement.clientHeight) {
      scrollToTopButton.className = "cmp-button--backtotop show";
    } else {
      scrollToTopButton.className = "cmp-button--backtotop hide";
    }
  };

  if (scrollToTopButton) {
    var contactUsButton = document.querySelector('.cmp-contactusmodal__layout');
    contactUsButton ? contactUsButton.classList.add('cmp-contactusmodal__reposition') : null;
    scrollToTopButton.addEventListener('click', function () {
      return scrollToTop();
    });
    window.addEventListener("scroll", handleScrollToTop);
  }
});