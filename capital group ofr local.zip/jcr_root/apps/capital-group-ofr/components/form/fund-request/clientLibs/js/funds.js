$(document).ready(function () {

    $("#account-div").css("display","none");;
       $('select[id=REQUESTTYPE]').change(function () 
	{


        $("select[id=REQUESTTYPE] option:selected").each(function ()

        {

            if ($(this).val() != "TRAC"  ) 
			{
            $("#account-div").css("display","block");

            }
            else
            {
               $("#account-div").css("display","none");;
            }
		});
	});

      function incrementRow() {
        var rowCount = $("#accountTable > tbody > tr").length;
        for (i = 2; i <= rowCount; i++) {
          $("#accountTable > tbody > tr").eq(i - 1).find("td:first-child").text(i);
          if (rowCount > 1) {
            $("#accountTable > tbody > tr:first-child > td:last-child #Delete-funds").removeClass('dlt-display').addClass('Delete-funds');
          }
        }
      }
      $('#AddFundsBtn').on('click', function () {
        $("<tr><td  class='sNo'></td><td> <input class='input-fields account' type='text' id='account' name='account' maxlength='15' style='width:130px'></td><td> <input class='input-fields' type='text' id= 'funds' name='funds' style='width:130px'></td><td> <input class='input-fields damount' type='text' id='damount' name='damount' maxlength='10' style='width:130px'></td><td> <select name='dType' id='dType' class='select-fields' style='width:154px'><option value=''>-Select-</option><option value='Dollars'>Dollars (Gross)</option><option value='Shares'>Shares</option><option value='Tax'>After Tax(net)</option><option value='All'>All</option></select></td><td><button id='Delete-funds' class='Delete-funds' ></button></td></tr>").insertAfter('#accountTable > tbody > tr:last-child');
        incrementRow();
      });
      $(document).on('click', '#Delete-funds', function () {
        deleteAccountRow($(this).parent().parent());
      });
      function deleteAccountRow(parent) {
        $(parent).remove();
        var rowCount = $("#accountTable > tbody > tr").length;
        if (rowCount == 1) {
          $("#accountTable > tbody > tr:first-child > td:last-child #Delete-funds").addClass('dlt-display').removeClass('Delete-funds');
        }
        for (i = 1; i <= rowCount; i++) {
          var count = 1;
          $('#accountTable > tbody > tr').each(function () {
            $(this).find('td.sNo').text(count);
            count++;
          })
        }
      }
    $(document).on('input','.account', function(){

       var len = $(this).val().length;

       var ch = $(this).val();
       console.log(ch+" "+len);

       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
    $(document).on('input','.damount', function(){

       var len = $(this).val().length;

       var ch = $(this).val();
       console.log(ch+" "+len);

       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
    });
