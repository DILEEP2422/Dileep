
$(document).ready(function () {


      function incrementSno_second(parent) {
        if (parent) {

			var rowCount = $(parent).children().find($("#tablePrimaryInc > tbody > tr")).length+1;			
            var parentTable=$(parent).find('table').eq(5).parent().attr("id");
            console.log("Par:"+parentTable)
            var finTable=$("#"+parentTable).find('table');
            console.log($(parent).find('table').eq(2).parent());

                $(' <tr><td class="sNo">1</td><td> <input class="input-fields fundsF" type="text" id="fundsF1-1" name="funds" maxlength="5" required></td><td> <select class="select-fields timeFrameT" type="text" id="timeFrameT1-1" name="timeFrame" style="width:230px" required><option value="">-Select-</option><option value="Years Selected">Years Selected</option><option value="All Years">All Years</option><option value="Init Inv Only">Init Inv Only</option></select></td><td><select class="select-fields from" type="text" id="from1-1" name="from" style="width:230px" required><option value="">-Select-</option></select></td><td><select class="select-fields to" type="text" id="to1-1" name="to" style="width:230px" required><option value="">-Select-</option></select></td><td><button id="Delete_second" class="Delete-funds1"></button></td></tr>').insertAfter($(parent).find('table').eq(5).parent().find("#tablePrimaryInc > tbody > tr:last-child"));
				var dynId=parentTable[parentTable.length-1];
                for (i = 2; i <= rowCount; i++) {                   
                    $(parent).find(".fundsF").eq(i - 1).attr('id', "fundsF"+dynId+"-" + (i));
                    $(parent).find(".timeFrameT").eq(i - 1).attr('id', "timeFrameT"+dynId+"-" + (i));
                    $(parent).find(".from").eq(i - 1).attr('id', "from"+dynId+"-" +(i));
                    $(parent).find(".to").eq(i - 1).attr('id', "to"+dynId+"-" +(i));
                    $(parent).find('table').eq(5).parent().find("#tablePrimaryInc > tbody > tr").eq(i - 1).find("td.sNo").text(i);                   
                    if (rowCount > 1) {

                        $(parent).find("#tablePrimaryInc > tbody > tr:first-child > td:last-child #Delete_second").removeClass('dlt-display').addClass('Delete-funds1');
                    }
                }

        }
        if (parent == undefined) {	
          var accountTableCount = $('#accountWrapper .accountTable').length;
          for (i = 1; i <= accountTableCount; i++) {
            var count = 1;
            $('#accountWrapper #accountTable-' + i).find('#tablePrimaryInc > tbody > tr').each(function () {
              	$(this).find(".fundsF").attr('id', "fundsF"+accountTableCount+"-" + (count));
                $(this).find(".timeFrameT").attr('id', "timeFrameT"+accountTableCount+"-" + (count));
                $(this).find(".from").attr('id', "from"+accountTableCount+"-" +(count));
                $(this).find(".to").attr('id', "to"+accountTableCount+"-" +(count));
              	$(this).find('td.sNo').text(count);
              count++;
            })
            if(Number(count-1) == 1) {                
				$('#accountWrapper #accountTable-' + i).find('#tablePrimaryInc > tbody > tr:first-child > td:last-child #Delete_second').addClass('dlt-display');

			}
          }

        }
      }

      function incrementAcoNo() 
      {
          var rowCount = $(".accountTable > .account-count").length;       
          var temp1="accountTable-"+(rowCount-1);
          var dynId=(rowCount-1);
          $("#"+temp1).find(".fundsF").attr('id', "fundsF"+dynId+"-" + (1));
          $("#"+temp1).find(".timeFrameT").attr('id', "timeFrameT"+dynId+"-" + (1));
          $("#"+temp1).find(".from").attr('id', "from"+dynId+"-" + (1));
          $("#"+temp1).find(".to").attr('id', "to"+dynId+"-" + (1));

      }

      $(document).on('click', '.Add-Fund-Btn-second', function () {
        incrementSno_second($(this).parent().parent().parent().parent());
      });

      $(document).on('click', '#Delete_second', function () {
        deleteFundsRow_second($(this).parent().parent());		
        incrementSno_second();

      });
      function deleteFundsRow_second(parent) {
        $(parent).remove();
      }
      function removeAccount() {
        var accountCount = $('#accountWrapper .accountTable').length;
            var temp1="accountTable-"+(accountCount);
           	var dynId=(accountCount);
            $("#"+temp1).find(".fundsF").attr('id', "fundsF"+dynId+"-" + (1));
            $("#"+temp1).find(".timeFrameT").attr('id', "timeFrameT"+dynId+"-" + (1));
            $("#"+temp1).find(".from").attr('id', "from"+dynId+"-" + (1));
            $("#"+temp1).find(".to").attr('id', "to"+dynId+"-" + (1));
        }



    });