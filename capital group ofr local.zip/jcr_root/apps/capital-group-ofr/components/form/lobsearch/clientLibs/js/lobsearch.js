$(document).ready(function(){
  $("#lobSearch").on("keyup", function() {
              $("#close").show();
    var value = $(this).val().toLowerCase();
    $("#formsRows tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});  

