$(document).ready(function () 
{
    if((document.URL).includes("copy-of-cashed-check-request"))
    { 
    $('.bank-wire-total').css("display", "none");
	$('.account-total').css("display", "none");
    }


	$('#NewAccountBtn').on('click', function () {

        var rowCount = $(".accountTable > .account-count").length-1;        
        var bankAccount="bankAccount"+rowCount;
        $("[id^="+bankAccount+"]").empty().append( '<option value="">Select Account Type</option>');        

    });


function accountType(tempid){

    		var countId=tempid[tempid.length-1];
        	var accountType="accountType-"+countId; 
    		var bankAccount="bankAccount"+countId;
    		var rowCount = $("#fundsTable > tbody>tr").length-1;


            $("select[id="+accountType+"] option:selected").each(function ()
        	{

              	if($(this).val()=="AFS")
                { 
					var counter=-1;
                    $("[id^="+bankAccount+"]").each( function () 
                     {      
                        if(!$(this).text().endsWith("682"))
                   		{
							$(this).empty();
                            $(this).append( '<option value="">-Select-</option><option value="4600-076442">4600-076442</option><option value="4600-076459" >4600-076459</option><option value="4600-153266" >4600-153266</option><option value="4600-158778" >4600-158778</option><option value="4600-076418" >4600-076418</option><option value="4375-666682" >4375-666682</option>');
                            ++counter;
                   		}
						else
                        {

                            if($("[id^="+bankAccount+"]").find('option').length<8)
                        	{
                                $(this).empty();
                       			$(this).append( '<option value="">-Select-</option><option value="4600-076442">4600-076442</option><option value="4600-076459" >4600-076459</option><option value="4600-153266" >4600-153266</option><option value="4600-158778" >4600-158778</option><option value="4600-076418" >4600-076418</option><option value="4375-666682" >4375-666682</option>');
								++counter;
                            }
                            else
                            { 
                                ++counter;                      
                       			if(counter==rowCount)
                       			{
									$(this).empty();
                       				$(this).append( '<option value="">-Select-</option><option value="4600-076442">4600-076442</option><option value="4600-076459" >4600-076459</option><option value="4600-153266" >4600-153266</option><option value="4600-158778" >4600-158778</option><option value="4600-076418" >4600-076418</option><option value="4375-666682" >4375-666682</option>');
                                }
                            }

                        }                    
                    });
                }

                else if($(this).val()=="CB&T")
                {

                    var counter=-1;
                    var flag=0

                    $("[id^="+bankAccount+"]").each( function () 
                     {      


                        if(!$(this).text().endsWith("766"))
                   		{

							$(this).empty();
                            $(this).append( '<option value="">-Select-</option><option value="4600-076434">4600-076434</option><option value="4375-666666">4600-158778</option><option value="4375-666666">4375-666666</option><option value="4375-666682">4375-666682</option><option value="4375-666690">4375-666690</option><option value="4123-102766">4123-102766</option>');
                            ++counter;
                   		}
						else
                        {

                            if($("[id^="+bankAccount+"]").find('option').length<8)
                        	{

								$(this).empty();
                       			$(this).append( '<option value="">-Select-</option><option value="4600-076434">4600-076434</option><option value="4375-666666">4600-158778</option><option value="4375-666666">4375-666666</option><option value="4375-666682">4375-666682</option><option value="4375-666690">4375-666690</option><option value="4123-102766">4123-102766</option>');
								++counter;
                            }
                            else
                            { 
                                ++counter;                      
                       			if(counter==rowCount)
                       			{

                                    $(this).empty();
                       				$(this).append( '<option value="">-Select-</option><option value="4600-076434">4600-076434</option><option value="4375-666666">4600-158778</option><option value="4375-666666">4375-666666</option><option value="4375-666682">4375-666682</option><option value="4375-666690">4375-666690</option><option value="4123-102766">4123-102766</option>');
                                }
                            }

                        }                    
                    });
                }

                else if($(this).val()=="529"){

                   

                     var counter=-1;
                    $("[id^="+bankAccount+"]").each( function () 
                     {      


                        if(!$(this).text().endsWith("260"))
                   		{

							$(this).empty();
                            $(this).append( '<option value="">-Select-</option><option value="4600-076442">4600-076442</option><option value="4600-076459" >4600-076459</option><option value="4600-153266" >4600-153266</option><option value="4600-153260">4600-153260</option>');
                            ++counter;
                   		}
						else
                        {

                            if($("[id^="+bankAccount+"]").find('option').length<6)
                        	{

								$(this).empty();
                       			$(this).append( '<option value="">-Select-</option><option value="4600-076442">4600-076442</option><option value="4600-076459" >4600-076459</option><option value="4600-153266" >4600-153266</option><option value="4600-153260">4600-153260</option>');
								++counter;
                            }
                            else
                            { 
                                ++counter;                      
                       			if(counter==rowCount)
                       			{

                                    $(this).empty();
                       				$(this).append( '<option value="">-Select-</option><option value="4600-076442">4600-076442</option><option value="4600-076459" >4600-076459</option><option value="4600-153266" >4600-153266</option><option value="4600-153260">4600-153260</option>');
                                }
                            }

                        }                    
                    });

                }
            });
    }





    $(document).on('change', 'select[name^="accountType"]',function () 
		{

			var tempid=$(this).parent().parent().parent().parent().parent().parent().parent().parent().parent().attr("id");
			accountType(tempid);
        });

    $(document).on('click', '.Add-Fund-Btn', function () {
        var tempid=$(this).parent().parent().parent().attr("id");
        accountType(tempid);

    });




});