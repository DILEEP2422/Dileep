$(document).ready(function () {
	
    var selector=document.querySelector(".container-config1");
	var val1=selector.getAttribute("data-properties");
    var idElement1=selector.getAttribute("data-element4a");
    var idElement2=selector.getAttribute("data-element4b");
    var idElement3=selector.getAttribute("data-element4c");
    var idElement4=selector.getAttribute("data-element4d");
	var idElement2a=selector.getAttribute("data-element2a");
    var idElement2b=selector.getAttribute("data-element2b");
    var idElement3a=selector.getAttribute("data-element3a");
    var idElement3b=selector.getAttribute("data-element3b");
    var idElement3c=selector.getAttribute("data-element3c");
	var idbutton=selector.getAttribute("data-button");
    var stylingClasses="cmp-form-options__field cmp-form-options__field--drop-down cmp-form-text__text";

    var idElementMain=selector.getAttribute("data-elementMain");
	idElementMain="#"+idElementMain;

    var firstElement=document.getElementById(idElement1);
    var secondElement=document.getElementById(idElement2);
    var thirdElement=document.getElementById(idElement3);
    var fourthElement=document.getElementById(idElement4);
    var firstElement2a=document.getElementById(idElement2a);
    var secondElement2b=document.getElementById(idElement2b);
    var firstElement3a=document.getElementById(idElement3a);
    var secondElement3b=document.getElementById(idElement3b);
    var thirdElement3c=document.getElementById(idElement3c);

    $(firstElement).attr("class","Element1 "+stylingClasses);;
    $(secondElement).attr("class","Element2 "+stylingClasses);
    $(thirdElement).attr("class","Element3 "+stylingClasses);
    $(fourthElement).attr("class","Element4 "+stylingClasses);
    $(firstElement2a).attr("class","Element2a "+stylingClasses);
    $(secondElement2b).attr("class","Element2b "+stylingClasses);
    $(firstElement3a).attr("class","Element3a "+stylingClasses);
    $(secondElement3b).attr("class","Element3b "+stylingClasses);
    $(thirdElement3c).attr("class","Element3c "+stylingClasses);

	$.fn.digits = function(){ 
    return this.each(function(){ 
        $(this).text( $(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") ); 
    })
}



    $(document).on('focus', '[name^="amtdemo"]', function () {
         $(this).maskMoney({ prefix:'$',allowEmpty:false});

    });


    $(document).on('blur', '#depositTotal', function(){

		var deposit=depositValue();
        var firstSum=sumData();
        var outOfBal=deposit-firstSum;
        if(outOfBal>0){
            $("#outOfBalanceReadOnly").val(outOfBal).css("color", "green").css("font-weight","Bold");
        }
        else{
			$("#outOfBalanceReadOnly").val(outOfBal).css("color", "red").css("font-weight","Bold");
        }

      });


    function depositValue(){
		var depositVal=$("#depositTotal").val().replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '');
        return depositVal;

    }

	$(document).on('blur', '[name^="amtdemo"]', function () {
        $(this).maskMoney({ prefix:'$',allowEmpty:false});
        var firstSum=sumData();
        if($("#depositTotal").val()!=undefined)
        {
            var deposit=depositValue();
            var outOfBal=deposit-firstSum;
            if(outOfBal>0){
                $("#outOfBalanceReadOnly").val(outOfBal).css("color", "green").css("font-weight","Bold");
            }
            else{
                $("#outOfBalanceReadOnly").val(outOfBal).css("color", "red").css("font-weight","Bold");
            }
        }
		
    });

    function sumData() {
        var sum1=0
        var dispSum=0
        var rowCount = $("#accountTable > tbody > tr").length;
          $('[name^="amtdemo"]').each(function () {
               var format = $(this).val().replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '');
              sum1+=Number(format);
               dispSum=(sum1).toFixed(2);

           $('#sumdisp h5').html("Total: $"+dispSum);
              $('#sumdisp h5').digits();

          })

			$('#sumdisp h5').html("Total: $"+dispSum);
        	$('#sumdisp h5').digits();
			return dispSum;
 }


   

    function incrementRow() {

        var rowCount =$("#accountTable ").find("tbody > tr").length;
       
        for (i = 2; i <= rowCount; i++) {
            $("#accountTable").find("tbody > tr").eq(i - 1).find("td .Element1").attr("id",idElement1+""+i);
            $("#accountTable").find("tbody > tr").eq(i - 1).find("td .Element2").attr("id",idElement2+""+i);
            $("#accountTable").find("tbody > tr").eq(i - 1).find("td .Element3").attr("id",idElement3+""+i);
            $("#accountTable").find("tbody > tr").eq(i - 1).find("td .Element4").attr("id",idElement4+""+i);
            $("#accountTable").find("tbody > tr").eq(i - 1).find("td .Element2a").attr("id",idElement2a+""+i);
            $("#accountTable").find("tbody > tr").eq(i - 1).find("td .Element2b").attr("id",idElement2b+""+i);
            $("#accountTable").find("tbody > tr").eq(i - 1).find("td .Element3a").attr("id",idElement3a+""+i);
            $("#accountTable").find("tbody > tr").eq(i - 1).find("td .Element3b").attr("id",idElement3b+""+i);
            $("#accountTable").find("tbody > tr").eq(i - 1).find("td .Element3c").attr("id",idElement3c+""+i);
           $(".funds").eq(i - 1).attr('id', "funds-" + (i));
          $("#accountTable > tbody > tr").eq(i - 1).find("td:first-child").text(i);
           

          if (rowCount > 1) {

            $("#accountTable > tbody > tr:first-child > td:last-child #Delete-funds").removeClass('dlt-display').addClass('Delete-funds');
             
          }
        }
      }

      $("#AddFundsBtn").on('click', function () {

        var cloneTable= $("#accountTable").find('#text12').clone();
		
        $(cloneTable).find("td .Element1").val('');
        $(cloneTable).find("td .Element2").val('');
        $(cloneTable).find("td .Element3").val('');
        $(cloneTable).find("td .Element4").val('');
        $(cloneTable).find("td .Element2a").val('');
		$(cloneTable).find("td .Element2b").val('');
        $(cloneTable).find("td .Element3a").val('');
        $(cloneTable).find("td .Element3b").val('');
        $(cloneTable).find("td .Element3c").val('');
        $(cloneTable).find("td:last-child #Delete-funds").removeClass('dlt-display').addClass('Delete-funds');
        $(cloneTable).insertAfter($("#accountTable").find("tbody > tr:last-child"));

        incrementRow();
      });
      $(document).on('click', '#Delete-funds', function () {
        deleteAccountRow($(this).parent().parent());

      });
      function deleteAccountRow(parent) {
        $(parent).remove();
        var rowCount = $("#accountTable > tbody > tr").length;
        
        if (rowCount == 1) {
          $("#accountTable > tbody > tr:first-child > td:last-child #Delete-funds").addClass('dlt-display').removeClass('Delete-funds');
        }
        for (i = 1; i <= rowCount; i++) {
          var count = 1;
          $('#accountTable > tbody > tr').each(function () {
            $(this).find('td.sNo').text(count);
            count++;
          })
        }

          var firstSum=sumData();
         if($("#depositTotal").val()!=undefined)
         {
               var deposit=depositValue();
               var outOfBal=deposit-firstSum;
                if(outOfBal>0){
                    $("#outOfBalanceReadOnly").val(outOfBal).css("color", "green").css("font-weight","Bold");
                }
                else{
                    $("#outOfBalanceReadOnly").val(outOfBal).css("color", "red").css("font-weight","Bold");
                }
        
         }

      }
    });


