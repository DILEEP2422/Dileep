
$(document).ready(function () {

    $("#reqtype").css("display","none");
       $('select[id=REQUESTTYPE]').change(function () 
	{


        $("select[id=REQUESTTYPE] option:selected").each(function ()

        {

            if ($(this).val() == "TRAC"  ) 
			{
            $("#reqtype").css("display","block");

            }
            else
            {
             $("#reqtype").css("display","none");

            }
		});
	});



      function incrementSno() {
        var rowCount = $("#fundsTable > tbody > tr").length;
        for (i = 2; i <= rowCount; i++) {
          $("#fundsTable > tbody > tr").eq(i - 1).find("td:first-child").text(i);
          if (rowCount > 1) {
            $("#fundsTable > tbody > tr:first-child > td:last-child #Delete").removeClass('dlt-display').addClass('Delete-funds');
          }
        }
      }
      $('#NewFundsBtn').on('click', function () {
        $("<tr><td  class='sNo'></td><td> <input class='input-fields' type='text' id='pid' name='pid' maxlength='10' style='width:130px'></td><td> <input class='input-fields' type='text' id= 'participant' name='participant' maxlength='25' style='width:130px'></td><td> <input class='input-fields trac' type='text' id='trac' name='trac' maxlength='10' style='width:130px'></td><td> <input class='input-fields ssn'  type='text' id='ssn' name='ssn' maxlength='4' placeholder='XXX-XX-' style='width:130px'></td><td> <input class='input-fields dolamount' type='text' id='dolamount' name='dolamount' maxlength='10' style='width:130px'></td><td> <select name='AccType' id='AccType' class='select-fields' style='width:154px'><option value=''>-Select-</option><option value='Dollars'>Dollars (Gross)</option><option value='Shares'>Shares</option> <option value='Tax'>After Tax(net)</option><option value='All'>All</option></select></td><td><button id='Delete' class='Delete-funds' ></button></td></tr>").insertAfter('#fundsTable > tbody > tr:last-child');
        incrementSno();
      });
      $(document).on('click', '#Delete', function () {
        deleteFundsRow($(this).parent().parent());
      });
      function deleteFundsRow(parent) {
        $(parent).remove();
      }
      $(document).on('click', '#Delete', function () {
        deleteFundsRow($(this).parent().parent());
      });
      function deleteFundsRow(parent) {
        $(parent).remove();
        var rowCount = $("#fundsTable > tbody > tr").length;
        if (rowCount == 1) {
          $("#fundsTable > tbody > tr:first-child > td:last-child #Delete").addClass('dlt-display').removeClass('Delete-funds');
        }
        for (i = 1; i <= rowCount; i++) {
          var count = 1;
          $('#fundsTable > tbody > tr').each(function () {
            $(this).find('td.sNo').text(count);
            count++;
          })
        }
      }
    $(document).on('input','.trac', function(){

       var len = $(this).val().length;

       var ch = $(this).val();


       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

	});
    $(document).on('input','.ssn', function(){

       var len = $(this).val().length;

       var ch = $(this).val();


       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
    $(document).on('input','.dolamount', function(){

       var len = $(this).val().length;

       var ch = $(this).val();
       

       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
    });