$(document).ready(function () {
    	var selector=document.querySelector(".container-config2");
		var val1=selector.getAttribute("data-properties");

      $(document).on('blur', '#account', function () {
        $(this).parent().parent().parent().parent().parent().parent().find('#accountText').text(($(this).val()));
      });

    	$(window).keydown(function(event){
        if(event.keyCode == 13) {
          event.preventDefault();
          return false;
        }
      });


      function incrementSno(parent) {
        if (parent) {

			var rowCount = $(parent).children().find($("#tableOneInc > tbody > tr")).length+1;			
            var parentTable=$(parent).find('table').eq(2).parent().attr("id");
            var finTable=$("#"+parentTable).find('table');

                $('<tr><td class="sNo">1</td><td> <input class="input-fields funds" type="text" id="fundsOf1-1" name="fundsOf" maxlength="5" required></td><td><div style="width:180px"><label class="invCheckboxLabel"><input class="invCheckbox" id="invCheckbox1-1" type="checkbox"><strong>&nbsp;Init Inv Only</strong></label></div></td><td><select class="select-fields ancientFrom" id="ancientFrom1-1" name="ancientFrom1-1" style="width:230px" required><option value="">-Select-</option><option value="UNAVAILABLE">UNAVAILABLE</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><option value="2007">2007</option><option value="2006">2006</option><option value="2005">2005</option><option value="2004">2004</option><option value="2003">2003</option><option value="2002">2002</option><option value="2001">2001</option><option value="2000">2000</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option></select></td><td><select class="select-fields ancientTo" type="text" id="ancientTo1-1" name="ancientTo" style="width:230px" required><option value="">-Select-</option><option value="UNAVAILABLE">UNAVAILABLE</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><option value="2007">2007</option><option value="2006">2006</option><option value="2005">2005</option><option value="2004">2004</option><option value="2003">2003</option><option value="2002">2002</option><option value="2001">2001</option><option value="2000">2000</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option></select></td><td><button id="Delete" class="Delete-funds1"></button></td></tr>').insertAfter($(parent).find('table').eq(2).parent().find("#tableOneInc > tbody > tr:last-child"));
				var dynId=parentTable[parentTable.length-1];
                for (i = 2; i <= rowCount; i++) {                   
                    $(parent).find(".funds").eq(i - 1).attr('id', "funds"+dynId+"-" + (i));
                    $(parent).find(".invCheckbox").eq(i - 1).attr('id', "invCheckbox"+dynId+"-" + (i));
                    $(parent).find(".ancientFrom").eq(i - 1).attr('id', "ancientFrom"+dynId+"-" +(i));
                    $(parent).find(".ancientTo").eq(i - 1).attr('id', "ancientTo"+dynId+"-" +(i));
                    $(parent).find('table').eq(2).parent().find("#tableOneInc > tbody > tr").eq(i - 1).find("td.sNo").text(i);
                    
                    if (rowCount > 1) {

                        $(parent).find("#tableOneInc > tbody > tr:first-child > td:last-child #Delete").removeClass('dlt-display').addClass('Delete-funds1');
                    }
                }

        }
        if (parent == undefined) {	
          var accountTableCount = $('#accountWrapper .accountTable').length;
         
          for (i = 1; i <= accountTableCount; i++) {
            var count = 1;
            $('#accountWrapper #accountTable-' + i).find('#tableOneInc > tbody > tr').each(function () {
              	$(this).find('td.sNo').text(count);
                $(this).find(".funds").eq(i - 1).attr('id', "funds"+accountTableCount+"-" + (count));
                $(this).find(".invCheckbox").eq(i - 1).attr('id', "invCheckbox"+accountTableCount+"-" + (count));
                $(this).find(".ancientFrom").eq(i - 1).attr('id', "ancientFrom"+accountTableCount+"-" +(count));
                $(this).find(".ancientTo").eq(i - 1).attr('id', "ancientTo"+accountTableCount+"-" +(count));
                count++;
            })
            if(Number(count-1) == 1) {
               
				$('#accountWrapper #accountTable-' + i).find('#tableOneInc > tbody > tr:first-child > td:last-child #Delete').addClass('dlt-display');

			}
          }

        }
      }

      function incrementAcoNo() {
        var rowCount = $(".accountTable > .account-count").length;       
          for (i = 1; i <= rowCount; i++) {
          $(".accountTable").eq(i - 1).attr('id', "accountTable-" + (i - 1));
          $(".accountTable > .account-count").eq(i - 1).find(".accountNo").text(i - 1);          
          $("#accountTable-" + (i - 1)).find('[name^="ancientTranscripts"]').attr("id","ancientTranscripts" + (i-1));
          $("#accountTable-" + (i - 1)).find('[name^="allFunds"]').attr("id","allFunds" + (i-1));
          $("#accountTable-" + (i - 1)).find('[name^="fundsTablePrimary1"]').attr("id","fundsTablePrimary" + (i-1));
          $("#accountTable-" + (i - 1)).find('[name^="fundsTableFirst1"]').attr("id","fundsTableFirst" + (i-1));
          $("#accountTable-" + (i - 1)).find('[name^="fundsTableSecond1"]').attr("id","fundsTableSecond" + (i-1));
          $("#accountTable-" + (i - 1)).find('[name^="displayTwo1"]').attr("id","displayTwo" + (i-1));
          $("#accountTable-" + (i - 1)).find('[name^="displayOne1"]').attr("id","displayOne" + (i-1));

          if (rowCount > 1) {
            $('.accountTable').find('#deleteAccount').removeClass('dlt-display').addClass('Delete-funds1');
          }
              var temp1="accountTable-"+(rowCount-1);
              var dynId=(rowCount-1);
              $("#"+temp1).find(".funds").attr('id', "funds"+dynId+"-" + (1));
              $("#"+temp1).find(".invCheckbox").attr('id', "invCheckbox"+dynId+"-" + (1));
              $("#"+temp1).find(".ancientFrom").attr('id', "ancientFrom"+dynId+"-" + (1));
              $("#"+temp1).find(".ancientTo").attr('id', "ancientTo"+dynId+"-" + (1));

        }

      }
      $('#NewAccountBtn').on('click', function () {
        var accountTableMarkup = $('#accountTableCloneWrapper').clone();
        $(accountTableMarkup).find(".accountTable").removeClass('display').appendTo("#accountWrapper");
        incrementAcoNo();
      });

      $(document).on('click', '.Add-Fund-Btn', function () {
        incrementSno($(this).parent().parent().parent().parent());
      });

      $(document).on('click', '#Delete', function () {
        deleteFundsRow($(this).parent().parent());		
        incrementSno();

      });
      function deleteFundsRow(parent) {
        $(parent).remove();
      }
      function removeAccount() {
        var accountCount = $('#accountWrapper .accountTable').length;
        for (i = 1; i <= accountCount; i++) {
          $(".accountTable").eq(i).attr('id', "accountTable-" + (i));
          $(".accountTable > .account-count").eq(i).find(".accountNo").text(i);
          $("#accountTable-" + (i)).find('[name^="ancientTranscripts"]').attr("id","ancientTranscripts" + (i));
          $("#accountTable-" + (i)).find('[name^="allFunds"]').attr("id","allFunds" + (i));
          $("#accountTable-" + (i)).find('[name^="fundsTablePrimary1"]').attr("id","fundsTablePrimary" + (i));
          $("#accountTable-" + (i)).find('[name^="fundsTableFirst1"]').attr("id","fundsTableFirst" + (i));
          $("#accountTable-" + (i)).find('[name^="fundsTableSecond1"]').attr("id","fundsTableSecond" + (i));
          $("#accountTable-" + (i)).find('[name^="displayTwo1"]').attr("id","displayTwo" + (i));
          $("#accountTable-" + (i)).find('[name^="displayOne1"]').attr("id","displayOne" + (i));
          if (accountCount  <2) {
          $('.accountTable').find('#deleteAccount').addClass('dlt-display').removeClass('Delete-funds1');

        }

            var temp1="accountTable-"+(accountCount);
           	var dynId=(accountCount);
            $("#"+temp1).find(".funds").attr('id', "funds"+dynId+"-" + (1));
            $("#"+temp1).find(".invCheckbox").attr('id', "invCheckbox"+dynId+"-" + (1));
            $("#"+temp1).find(".ancientFrom").attr('id', "ancientFrom"+dynId+"-" + (1));
            $("#"+temp1).find(".ancientTo").attr('id', "ancientTo"+dynId+"-" + (1));
        }
      }

      $(document).on('click', '#deleteAccount', function () {
        deleteAccount($(this).parent().parent());
        removeAccount();
      });

      function deleteAccount(parent) {
        $(parent).remove();
      }
    $(document).on('input','.accNum', function(){

       var len = $(this).val().length;
	   $(this).attr("maxlength","12")
       var ch = $(this).val();

       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
    $(document).on('input','[name=alphaCode]', function(){
    $(this).attr("maxlength","10")
});

    });