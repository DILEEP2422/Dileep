$(document).ready(function(){
    $("#formId").on("click", function() {
	        $("#categoryid").hide();
			$("#formid").show();


	    });
	    $("#categoryId").on("click", function() {
	        $("#formid").hide();
			$("#categoryid").show();
	    });
  $("#lobSearch").on("keyup", function() {
              $("#close").show();     
    var value = $(this).val().toLowerCase();
    $("#formsRows tr").filter(function() {
         
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});  

