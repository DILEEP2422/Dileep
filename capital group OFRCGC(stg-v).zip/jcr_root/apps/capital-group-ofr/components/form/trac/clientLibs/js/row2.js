
$(document).ready(function () {


      function vincrementSrno() {
        var rowCount = $("#vtracTable > tbody > tr").length;
        for (i = 2; i <= rowCount; i++) {
          $("#vtracTable > tbody > tr").eq(i - 1).find("td:first-child").text(i);
          if (rowCount > 1) {
            $("#vtracTable > tbody > tr:first-child > td:last-child #vDelete").removeClass('dlt-display');
          }
        }
      }




      $('#vNewTracBtn').on('click', function () {
        $("<tr><td  class='srNo'></td><td><select name='VARIANCE' id='VARIANCE' class='select-fields'><option value=''>SELECT ONE</option><option value='3 Day Hold'>3 Day Hold</option><option value='Allowance-Overage'>Allowance-Overage</option><option value='Allowance-Shortage'>Allowance-Shortage</option><option value='Fee'>Fee</option><option value='Manual Check'>Manual Check</option><option value='Redemption'>Redemption</option><option value='PURCH'>PURCH</option><option value='GPURCH'>GPURCH</option></select></td><td> <input class='input-fields' type='number' id= 'VARIANCE_AMT' name='VARIANCE_AMT' maxlength='15' placeholder='$' required><td> <input class='input-fields' type='text' id='Account_Plan_ID_SSN' name='Account_Plan_ID_SSN' maxlength='10'></td><td><button id='vDelete'>Delete</button></td></tr>").insertAfter('#vtracTable > tbody > tr:last-child');
        vincrementSrno();
      });

    $(document).on('click', '#vDelete', function () {
       vdeleteTracRow($(this).parent().parent());
      });	



  function vdeleteTracRow(parent) {
        $(parent).remove();
        var rowCount = $("#vtracTable > tbody > tr").length;
        if (rowCount == 1) {
          $("#vtracTable > tbody > tr:first-child > td:last-child #vDelete").addClass('dlt-display');
        }
        for (i = 1; i <= rowCount; i++) {
          var count = 1;
          $('#vtracTable > tbody > tr').each(function () {
            $(this).find('td.srNo').text(count);
            count++;
          })
        }
      }





    });