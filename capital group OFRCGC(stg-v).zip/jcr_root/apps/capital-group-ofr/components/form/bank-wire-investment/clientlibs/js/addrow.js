$(document).ready(function () 
{
    $("[id='contribtype']").prop("disabled",true);
    $("[id^='fundtype1']").prop("disabled",true);

	$('#NewAccountBtn').on('click', function () {

        var rowCount = $(".accountTable > .account-count").length-1;        
        $("[id^='contribtype']").prop("disabled",true);
		var fundtype="fundtype"+rowCount;
		var contribtype="contribtype"+rowCount;
        $("[id^="+fundtype+"]").empty().append( '<option value="">-Select-</option>');
        $("[id^="+contribtype+"]").empty().append( '<option value="">-Select-</option>');
 		$("[id^="+fundtype+"]").prop("disabled",true);

    });



    function accType(tempid){
			var countId=tempid[tempid.length-1];
        	var acctype="acctype-"+countId;
        	var contribtype="contribtype"+countId;
        	var fundtype="fundtype"+countId;        	

            $("select[id="+acctype+"] option:selected").each(function ()
        	{

              	if($(this).val()=="AFS")
                {

                    $("[id="+contribtype+"]").find('option').replaceWith( '<option value="">Direct-Investment</option>');
					$("[id="+contribtype+"]").prop("disabled",true);
                    $("[id^="+fundtype+"]").each( function () {
                        $(this).find('option').replaceWith( '<option value="">Direct-Investment</option>');
						$(this).prop("disabled",true);
                    });
                }

                else if($(this).val()=="CB&T")
                {
                    $("[id="+contribtype+"]").prop("disabled",false);
                    $("[id="+contribtype+"]").empty()
                    $("[id="+contribtype+"]").append( '<option value="">-Select-</option><option value="Transfer of Assets" class="removable">Transfer of Assets</option><option value="Rollover">Rollover</option><option value="Employee-Current">Employee-Current</option><option value="Employee-Prior">Employee-Prior</option><option value="Employer Contribution">Employer Contribution</option><option value="Salary Deferral">Salary Deferral</option><option value="varies">Varies By Fund</option>');
					$("[id^="+fundtype+"]").each( function () 
                    {
						$(this).empty();
                        $(this).append( '<option value="">-Select-</option>');
						$(this).prop("disabled",true);
                    });
                }

                else if($(this).val()=="529"){
                    $("[id="+contribtype+"]").prop("disabled",false);
                    $("[id="+contribtype+"]").empty()
                    $("[id="+contribtype+"]").append( '<option value="">-Select-</option><option value="CS-Contribution">CS-Contribution</option><option value="CS-Earnings" >CS-Earnings</option><option value="Rollover-Contribution">Rollover-Contribution</option><option value="Rollover-Earnings">Rollover-Earnings</option><option value="varies1">Varies By Fund</option>');
					$("[id^="+fundtype+"]").each( function () {
						$(this).empty();
                        $(this).append( '<option value="">-Select-</option>');
						$(this).prop("disabled",true);
                    });


                }
            });
    }

    function accType1(tempid){

        	var countId=tempid[tempid.length-1];
        	var acctype="acctype-"+countId;
        	var contribtype="contribtype"+countId;
        	var fundtype="fundtype"+countId;        	

            $("select[id="+acctype+"] option:selected").each(function ()
        	{
                if($(this).val()=="AFS")
                {

                    $("[id="+contribtype+"]").find('option').replaceWith( '<option value="">Direct-Investment</option>');
					$("[id="+contribtype+"]").prop("disabled",true);
                    $("[id^="+fundtype+"]").each( function () {
                        $(this).find('option').replaceWith( '<option value="">Direct-Investment</option>');
						$(this).prop("disabled",true);
                    });
                }

            });
    }





     $(document).on('change', 'select[name^="acctype"]',function () 
		{
			var tempid=$(this).parent().parent().parent().parent().parent().parent().parent().parent().parent().attr("id");
            accType(tempid);
        });



    $(document).on('click', '.Add-Fund-Btn', function () {
        var tempid=$(this).parent().parent().parent().attr("id");
        accType1(tempid);
		fundTypeSelect(tempid)
    });


    function fundTypeSelect(tempid)
    {        	
        var countId=tempid[tempid.length-1];
        var acctype="acctype-"+countId;
        var contribtype="contribtype"+countId;
        var fundtype="fundtype"+countId;        	       
        var rowCount = $("#fundsTable > tbody>tr").length-1;

        $("[id^="+fundtype+"]").prop("disabled",true);

    	$("select[id="+contribtype+"] option:selected").each(function ()
       {

           if($(this).val()=="varies")
           {
              
               var tempVal=$(this).val();
               var counter=-1;               

               $("[id^="+fundtype+"]").each( function ()
               {

                   $(this).prop("disabled",false);
                  
                   if(!$(this).text().endsWith("ContributionSalary Deferral"))
                   {
                        $(this).empty();
                    	$(this).append('<option value="">-Select-</option><option value="Transfer of Assets">Transfer of Assets</option><option value="Rollover">Rollover</option><option value="Employee-Current">Employee-Current</option><option value="Employee-Prior" class="removable">Employee-Prior</option><option value="Employer Contribution" class="removable">Employer Contribution</option><option value="Salary Deferral" class="removable">Salary Deferral</option>');
						++counter;
                   }
                   else
                   {
                   		if($("[id^="+fundtype+"]").find('option').length<=6)
                        {
                            $(this).empty();
                            $(this).append('<option value="">-Select-</option><option value="Transfer of Assets">Transfer of Assets</option><option value="Rollover">Rollover</option><option value="Employee-Current">Employee-Current</option><option value="Employee-Prior" class="removable">Employee-Prior</option><option value="Employer Contribution" class="removable">Employer Contribution</option><option value="Salary Deferral" class="removable">Salary Deferral</option>');
                            ++counter;
                        }
                      	else
                        {
                            ++counter;                      
                       		if(counter==rowCount)
                       		{
                           		$(this).empty();
                           		$(this).append('<option value="">-Select-</option><option value="Transfer of Assets">Transfer of Assets</option><option value="Rollover">Rollover</option><option value="Employee-Current">Employee-Current</option><option value="Employee-Prior" class="removable">Employee-Prior</option><option value="Employer Contribution" class="removable">Employer Contribution</option><option value="Salary Deferral" class="removable">Salary Deferral</option>');
                       		}
                        }
                   }
                 });
           }

           else if($(this).val()=="Transfer of Assets" || $(this).val()=="Rollover" || $(this).val()=="Employee-Current" || $(this).val()=="Employee-Prior" || $(this).val()=="Employer Contribution" || $(this).val()=="Salary Deferral" || $(this).val()=="CS-Contribution" || $(this).val()=="CS-Earnings" || $(this).val()=="Rollover-Contribution" || $(this).val()=="Rollover-Earnings" )
           {

               	var tempVal=$(this).val();               	
				$("[id^="+fundtype+"]").each( function () 
                 {
                    	var replace='<option value="">'+tempVal+'</option>';
                     	$(this).empty()
						$(this).append(replace)               
						$(this).prop("disabled",true); 
                 });
           }

           else if($(this).val()=="varies1")
           { 
          
               var tempVal=$(this).val();
				var counter1=-1;


				$("[id^="+fundtype+"]").each( function () 
                { 
                	$(this).prop("disabled",false);					
                    if(!$(this).text().endsWith("ContributionRollover-Earnings"))
                    {	                        
                        $(this).empty();
                    	$(this).append('<option value="">-Select-</option><option value="CS-Contribution">CS-Contribution</option><option value="CS-Earnings" >CS-Earnings</option><option value="Rollover-Contribution">Rollover-Contribution</option><option value="Rollover-Earnings">Rollover-Earnings</option>');
						++counter1;
                    }
                     else
                   {
                   		if($("[id^="+fundtype+"]").find('option').length<=4)
                        {                            
                            $(this).empty();
                            $(this).append('<option value="">-Select-</option><option value="CS-Contribution">CS-Contribution</option><option value="CS-Earnings" >CS-Earnings</option><option value="Rollover-Contribution">Rollover-Contribution</option><option value="Rollover-Earnings">Rollover-Earnings</option>');
                            ++counter1;
                        }
						else
                        {                            
                            ++counter1;                      
                       		if(counter1==rowCount)
                       		{
                           		$(this).empty();
                           		$(this).append('<option value="">-Select-</option><option value="CS-Contribution">CS-Contribution</option><option value="CS-Earnings" >CS-Earnings</option><option value="Rollover-Contribution">Rollover-Contribution</option><option value="Rollover-Earnings">Rollover-Earnings</option>');
                       		}
                        }

                   }
                 });

           }

        });

    }

    $(document).on('change', 'select[name^="contribtype"]',function ()
	{
        var tempid=$(this).parent().parent().parent().parent().parent().parent().parent().parent().parent().attr("id");
        fundTypeSelect(tempid);
    });



});