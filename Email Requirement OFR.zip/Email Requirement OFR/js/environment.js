var Environment = new EnvironmentClass();

function EnvironmentClass() {
	this.ServiceLocal = 'http://localhost:62519/';
	this.Service = "https://providerapp08.collabproviderqa.spapps/onlineformsroom/";
}