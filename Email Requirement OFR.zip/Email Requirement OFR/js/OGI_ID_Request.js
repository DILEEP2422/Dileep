function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

Form.FormSpecificReset = function () {
	document.getElementById('$SITE$').focus(); 
	document.getElementById('prevname').style.display = 'none';
	document.getElementById('newname').style.display = 'none';
	document.getElementById('contactName').style.display = 'none';
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if(!document.getElementById("MEMOACCOUNT").checked){
		errorMsgArr[$("#MEMOACCOUNT").attr('tabindex')] = "- MEMO ACCOUNT\n";
	}
	
	if($.trim(ogiForm.$REQUESTTYPE$.value) == "CONTACT NAME CHANGE"){
		if($.trim(ogiForm.$PREVIOUSNAME$.value).length == 0){
			errorMsgArr[$("#PREVIOUSNAME").attr('tabindex')] = "- CONTACT'S PREVIOUS NAME\n";
		}
		if($.trim(ogiForm.$NEWNAME$.value).length == 0){
			errorMsgArr[$("#NEWNAME").attr('tabindex')] = "- CONTACT'S NEW NAME\n";
		}
	}
	
	if($.trim(ogiForm.$REQUESTTYPE$.value) == "DELETE OGI ID"){
		if($.trim(ogiForm.$CONTACTNAME$.value).length == 0){
			errorMsgArr[$("#CONTACTNAME").attr('tabindex')] = "- CONTACT'S NAME\n";
		}
	}
	
	if($.trim(ogiForm.$CALLER$.value).length > 0){
		ogiForm.$CALLERHIDDEN$.value = "\nCALLER: " + ogiForm.$CALLER$.value;
	}
	
	if($.trim(ogiForm.$RELATIONSHIP$.value).length >0) {
		ogiForm.$RELATIONSHIPHIDDEN$.value = "RELATIONSHIP: " + ogiForm.$RELATIONSHIP$.value + "\n";
	}
	
	if($.trim(ogiForm.$ADDITIONALCOMMENTS$.value).length >0) {
		ogiForm.$ADDITIONALCOMMENTSHIDDEN$.value = "ADDITIONAL COMMENTS: " + ogiForm.$ADDITIONALCOMMENTS$.value;
	}
	
	if(document.getElementById("MEMOACCOUNT").checked){
		ogiForm.$MEMOACCOUNTHIDDEN$.value = "***ACCOUNT MEMO ADDED***";
	}
	
	if ($.trim(ogiForm.$REQUESTTYPE$.value) == "CONTACT NAME CHANGE"){
		if($.trim(ogiForm.$PREVIOUSNAME$.value).length >0) {
			ogiForm.$CONTACTNAMESECTIONHIDDEN$.value = "CONTACT'S PREVIOUS NAME: " + ogiForm.$PREVIOUSNAME$.value + "\n";
		}
		if($.trim(ogiForm.$NEWNAME$.value).length >0) {
			ogiForm.$CONTACTNAMESECTIONHIDDEN$.value += "CONTACT'S NEW NAME: " + ogiForm.$NEWNAME$.value + "\n";
		}
	}
	
	if ($.trim(ogiForm.$REQUESTTYPE$.value) == "DELETE OGI ID"){
		if($.trim(ogiForm.$CONTACTNAME$.value).length >0) {
			ogiForm.$CONTACTNAMESECTIONHIDDEN$.value = "CONTACT'S NAME: " + ogiForm.$CONTACTNAME$.value + "\n";
		}
	}

}

Form.CreateSubject = function () {
	ogiForm.subject.value = ogiForm.$REQUESTTYPE$.value + " " + ogiForm.$SITE$.value + " - " + ogiForm.$OGIID$.value;
}

function toggleValues(obj)
{
	if (obj.value == 'CONTACT NAME CHANGE') {
		document.getElementById('prevname').style.display = 'block';
		document.getElementById('newname').style.display = 'block';
		document.getElementById('contactName').style.display = 'none';
	}
	else if (obj.value == 'DELETE OGI ID') {
		document.getElementById('contactName').style.display = 'block';
		document.getElementById('prevname').style.display = 'none';
		document.getElementById('newname').style.display = 'none';
	}
	else {
		document.getElementById('prevname').style.display = 'none';
		document.getElementById('newname').style.display = 'none';
		document.getElementById('contactName').style.display = 'none';
	}
}