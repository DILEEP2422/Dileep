Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if (!document.forms[0].$q1$[0].checked && !document.forms[0].$q1$[1].checked){
		errorMsgArr[$("#q1").attr('tabindex')] = "- 1st Friday of the month?\n";
	} 
	if (!document.forms[0].$q2$[0].checked && !document.forms[0].$q2$[1].checked){
		errorMsgArr[$("#q2").attr('tabindex')] = "- 2nd Friday of the month?\n";
	} 
	if (!document.forms[0].$q3$[0].checked && !document.forms[0].$q3$[1].checked){
		errorMsgArr[$("#q3").attr('tabindex')] = "- 3rd Friday of the month?\n";
	} 
	if (!document.forms[0].$q4$[0].checked && !document.forms[0].$q4$[1].checked){
		errorMsgArr[$("#q4").attr('tabindex')] = "- 4th Friday of the month?\n";
	} 
	if (!document.forms[0].$q5$[0].checked && !document.forms[0].$q5$[1].checked){
		errorMsgArr[$("#q5").attr('tabindex')] = "- Last Friday of the month?\n";
	} 
	if (!document.forms[0].$q6$[0].checked && !document.forms[0].$q6$[1].checked){
		errorMsgArr[$("#q6").attr('tabindex')] = "- Is this a special or out-of-cycle request?\n";
	} 
}

Form.CreateSubject = function () {
	// Do Nothing as subject is hard coded in HTML
}