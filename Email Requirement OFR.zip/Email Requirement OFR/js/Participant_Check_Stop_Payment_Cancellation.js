var submitCount = 0;
var regexLetter = /[^a-zA-z\s]/;
var regexLetterNoSpace = /[^a-zA-z]/;
var datePat = /^(\d{1,2})(\/)(\d{1,2})\2(\d{4})$/;


function isValidDate(dateStr)
{
var matchArray = dateStr.match(datePat); // is the format ok?
if (matchArray == null) {
return false;
}
return true;
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if(document.getElementById("$rush$").checked==true){
		document.participantForm.$RUSHHidden$.value = "YES";
	}
	else if(document.getElementById("$rush$").checked==false){
		document.participantForm.$RUSHHidden$.value = "NO"
	}
	
	if(!(document.participantForm.$stop_cancel$[0].checked || document.participantForm.$stop_cancel$[1].checked))
	{
		errorMsgArr[$("#stop_cancel").attr('tabindex')] = "\nPlease select STOP or CANCEL. \n\n";
	}
	else if(document.participantForm.$stop_cancel$[0].checked)
	{
		document.participantForm.$STOPCANCELHid$.value = "STOP: Y"   + "\t " + "\t" +   "CANCEL: N" ;
	}
	else if(document.participantForm.$stop_cancel$[1].checked)
	{
		document.participantForm.$STOPCANCELHid$.value = "STOP: N"   + "\t" + "\t" +  "CANCEL: Y" ;
	}
	
	if(!(document.participantForm.$account_no$[0].checked || document.participantForm.$account_no$[1].checked))
	{
		errorMsgArr[$("#account_no").attr('tabindex')] = "- BANK ACCT\n";		
	}
	
	if(!document.participantForm.$account_note$.checked)
	{
		errorMsgArr[$("#account_note").attr('tabindex')] = "\nACCOUNT NOTE ADDED not selected";				
	}
}

Form.CreateSubject = function () {
	/*	
	Sample subject line: G-Purch - GA123456, GA123456
	*/	
	var emailSubject = "Payment/Cancellation - ";	
	emailSubject += document.participantForm.$site$.value;
	emailSubject += " - ";
	if(document.participantForm.$rush$.checked){
		emailSubject += "RUSH - ";
	}
	emailSubject += document.participantForm.$plan_id$.value ;
	
	$("#subject").val(emailSubject);	
}


function checkBoxValidate(cb,gp,grp){
		
	if(grp=="$account_no$")
	{
		var gn=gp.$account_no$
		var len=2
		var lx=gp.$account$
	}
	if(grp=="$stop_cancel$"){
		var gn=gp.$stop_cancel$
		var len=2
		var lx=gp.$hstop_cancel$
	}
	
	if(grp=="$reissue_yes_no$"){
		var gn=gp.$reissue_yes_no$
		var len=2
		var lx=gp.$reissue$
	}
	
	if(grp=="$payorder_yes_no$"){
		var gn=gp.$payorder_yes_no$
		var len=2
		var lx=gp.$payorder$
	}
	for (j=0; j < len ; j++ )
	{
		if(gn[j].checked==true)
		{
			gn[j].checked = false
		}				
		if(j == cb)
		{
			gn[j].checked=true
			lx.value=gn[j].value			
		}
			
				
	}
			
}

function alertselected(selectobj)
{
	if(selectobj.value != "")
	{
		var answer = confirm("You selected "+selectobj.value+". Is that correct?");
		if (answer){
			return answer;
		}
		else{
			var cbo=document.getElementById('site_select_box'); 
			cbo.selectedIndex=0; 
		}
	}
	
}	

function alltrim(str) {
    return str.replace(/^\s*/, "").replace(/\s*$/, "");
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = alltrim(str);
    }
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

<!-- Begin

var p;


function ValidatePhone(p1){
//	alert(p1.value);
	p = "";
	p = p1.value;
	if(p.length == 3){

		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ") ";
		}
	p1.value=""; p1.value=pp;
//		document.avcForm.$PHONE$.value = "";
//		document.avcForm.$PHONE$.value = pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
//alert("d1=" + d1 + ": d2=" + d2);
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
p1.value=""; p1.value=pp;
//			document.avcForm.$PHONE$.value = "";
//			document.avcForm.$PHONE$.value = pp;
		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
//alert("p11="+p11+"'");
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
//			document.avcForm.$PHONE$.value = "";
			pp = "(" + p13 + ")" + p14 + p15;
//			document.avcForm.$PHONE$.value = pp;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 3 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
p1.value=""; p1.value=pp;
//			document.avcForm.$PHONE$.value = "";
//			document.avcForm.$PHONE$.value = pp;
		}

	}
}

function getIt(m){
	p1 = null;
	p1 = m;
	ValidatePhone(p1);
}

//  End -->