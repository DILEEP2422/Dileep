Form.FormSpecificReset = function () {
	document.getElementById("notice1").style.display = "none";
}

function toggleSOS(){
	if (form_lgtrade.$state$.value == "NY") {
		form_lgtrade.$hsos$.value = "F";
		form_lgtrade.$hsos1$.value = "F";
		form_lgtrade.$hsos2$.value = "F";
	} else {
		form_lgtrade.$hsos$.value = "G";
		form_lgtrade.$hsos1$.value = "G";
		form_lgtrade.$hsos2$.value = "G";				
	}
}
	
function toggleuclass() {
	form_lgtrade.$uclass1$.value = form_lgtrade.$uclass$.value;
	form_lgtrade.$uclass2$.value = form_lgtrade.$uclass$.value;	
}
	
function show2() {
	document.getElementById("notice1").style.display = "block";	
}					

function hide2() {
	document.getElementById("notice1").style.display = "none";
}					

function show3() {
	document.getElementById("notice2").style.display = "block";	
}					

function hide3() {
	document.getElementById("notice2").style.display = "none";	
}

Form.CreateSubject = function () {
	// REMOVE UNIT CLASS AND SOS VALUES IF CORRESPONDING FUNDS NOT SELECTED
	if (form_lgtrade.$fund1$.value == "") {
		form_lgtrade.$uclass1$.value = "";
		form_lgtrade.$hsos1$.value = "";			
	}

	if (form_lgtrade.$fund2$.value == ""){
		form_lgtrade.$uclass2$.value = "";
		form_lgtrade.$hsos2$.value = "";			
	}

	form_lgtrade.subject.value = "RKD Multi-Fund Large Trade Notification - " + form_lgtrade.$planid$.value + " - GW# " +form_lgtrade.$gwplan$.value ;
}