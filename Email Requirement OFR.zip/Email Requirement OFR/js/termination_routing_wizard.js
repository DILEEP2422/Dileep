$(document).ready(function() {
	$('.panel-group')
		.on('show.bs.collapse', function(e) {
		$(e.target).prev('.panel-heading').parent().addClass('panel-success');
		})
		.on('hide.bs.collapse', function(e) {
			$(e.target).prev('.panel-heading').parent().removeClass('panel-success');
			$('.panelDetails').not('.panel-success').each(function() {
				$(this).find('.panel-collapse').each(function () {
					$(this).removeClass("in");
					$(this).prev('.panel-heading').parent().removeClass('panel-success');
				});
			});
		});
});