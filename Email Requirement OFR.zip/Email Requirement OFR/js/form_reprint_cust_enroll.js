$(".date-picker").each(function() {
	$(this).datepicker({
		onClose : function () {
			/* over riding on close function (from onlineformsroom.js) to ensure that delivery date validations
			   work i.e. invoked in on change function
			*/
		}			
	});
});

$("#\\$delivdate\\$").on('focusin', function(){
    console.log("Saving value " + $(this).val());
    $(this).data('val', $(this).val());
});

$("#\\$delivdate\\$").change(function () { 
	var prev = $(this).data('val');
	var dist = testDistance($(this).val());
	var bool = isBiz($(this).val());
	
	if(bool) {
		if (dist < 8) {
		
			var msg = "Delivery Date must be 8 or more business days from current date.  Please choose a different Delivery Date." +
				"  Please note approvals for exceptions granted in the 'Comments / Exception Approvals / Additional" + 
				" Address' field below.";
		
			alert(msg);
			$(this).val(prev);
		}
	} else {
		alert("Please select a valid business day.");			
		$(this).val(prev);
	}
	
	var procby = bizCount($(this).val(), 8, 0); // count back 8 days from delivery date of mm/dd/yyyy:  def[1]

	ge("$pbdate$").value = procby[0];
});

// CHECKS IF DATE IS BIZ DAY
function isBiz(dateValue){
	var dobj = new Date(dateValue); // date object
	
	var dayindex = dobj.getDay(); // get day of week index
	
	// 0 = sunday, 6 = saturday
	
	if (dayindex == 0 || dayindex == 6){
		return false;	// not biz	
	} else {
		return true; // yes biz
	}	
}

function testDistance(dateValue){
	var curr = new Date(); // current date
	var mscurr = curr.getTime();
	
	var seldate = new Date(dateValue); // selected date	
	var mssel = seldate.getTime();
	
	var inst; // holds date instance
	var daycount = 0; // counts calendar days
	var nbcount = 0; // counts weekend days
	var dow;
	
	while (mscurr <= mssel) {
		mscurr += 86400000;	
		daycount++;
		
		inst = new Date(mscurr);
		
		dow = inst.getDay(); // day of week
		
		if (dow == 0 || dow == 6) {
			nbcount++; // increment non-biz day count				
		} 
	}// end while
		
	var result = daycount - nbcount;
		
	return result;
}// end function

function copyAdvisor() {
	var bool = ge("copyadv").checked;
	if (bool) {
		ge("$reqphone$").value = ge("$advphone$").value;
		ge("$reqname$").value = ge("$advname$").value;
	} else {
		ge("$reqphone$").value = "";
		ge("$reqname$").value = "";
	}
}

function propFA2() {
	if(ge("$Rfa$").checked && ge("$send_fa$").checked) {
		ge("$attn$").value = ge("$advname$").value;
		ge("$reqphone$").value = ge("$advphone$").value;
		ge("$cophone$").value = ge("$advphone$").value;
		ge("$reqname$").value = ge("$advname$").value;
		ge("$reqby$").value = "Financial Advisor";
	} 
}

function propPS() {
	if(ge("$Rps$").checked && ge("$send_ps$").checked) {
		ge("$coname$").value = ge("$planname$").value;		
		ge("$attn$").value = ge("$reqname$").value;
		ge("$cophone$").value = ge("$reqphone$").value;
		ge("$reqby$").value = "Plan Sponsor";		
	}
}

function propTPA() {
	if(ge("$Rtpa$").checked && ge("$send_tpa$").checked) {
		ge("$attn$").value = ge("$reqname$").value;
		ge("$cophone$").value = ge("$reqphone$").value;
		ge("$reqby$").value = "TPA";		
	} 
}

function checkprq() {
	var eng = parseInt(ge("$eprqty$").value);
	var span = parseInt(ge("$sprqty$").value);

	if (eng > 0 || span > 0) {
		ge("prdata").style.display = "block";
	} else {
		ge("$psd$").checked = false;
		ge("$hidpsd$").value = "No";
		ge("$avgbal$").value = "";
		ge("$avgbimo$").value = "";
		ge("$rkdg$").checked = false;
		ge("$hidrkdg$").value = "No";
		ge("$pscag$").checked = false;
		ge("$hidpscag$").value = "No";
		ge("prdata").style.display = "none";
	}
}

function togglepsd() {
	var chkd = ge("$psd$").checked;
	
	if (chkd) {
		ge("$hidpsd$").value = "Yes";
	} else {
		ge("$hidpsd$").value = "No";			
	}
}

function togglerkdg() {
	var chkd = ge("$rkdg$").checked;

	if (chkd) {
		ge("$hidrkdg$").value = "Yes";
	} else {
		ge("$hidrkdg$").value = "No";			
	}
}

function togglepscag() {
	var chkd = ge("$pscag$").checked;

	if (chkd) {
		ge("$hidpscag$").value = "Yes";
	} else {
		ge("$hidpscag$").value = "No";			
	}
}

function buildLit() {
	var txt = "";
	var n;

	n = parseInt(ge("dvdm").value);	
	if (n > 0) {txt += "Enrollment DVD / ER Match: " + n + "\n\n";}

	n = parseInt(ge("dvdnm").value);	
	if (n > 0) {txt += "Enrollment DVD / Without Match: " + n + "\n\n";}

	n = parseInt(ge("eps").value);	
	if (n > 0) {txt += "Enrollment Payroll Stuffers (Teasers): " + n + "\n\n";}

	n = parseInt(ge("seps").value);	
	if (n > 0) {txt += "Enrollment Payroll Stuffers (Teasers): " + n + " (Spanish)\n\n";}

	n = parseInt(ge("emp").value);	
	if (n > 0) {txt += "Enrollment Meeting Posters: " + n + "\n\n";}

	n = parseInt(ge("semp").value);	
	if (n > 0) {txt += "Enrollment Meeting Posters: " + n + " (Spanish)\n\n";}

	n = parseInt(ge("tss").value);	
	if (n > 0) {txt += "Value of saving over time (Non-participation): " + n + "\n\n";}

	n = parseInt(ge("stss").value);	
	if (n > 0) {txt += "Value of saving over time (Non-participation): " + n + " (Spanish)\n\n";}

	n = parseInt(ge("smiyr").value);	
	if (n > 0) {txt += "Benefits of increasing contributions (Low Deferral): " + n + "\n\n";}

	n = parseInt(ge("ssmiyr").value);	
	if (n > 0) {txt += "Benefits of increasing contributions (Low Deferral): " + n + " (Spanish)\n\n";}

	n = parseInt(ge("cbtw").value);	
	if (n > 0) {txt += "Roth vs. pre-tax contributions (Roth 401k/403b): " + n + "\n\n";}

	n = parseInt(ge("scbtw").value);	
	if (n > 0) {txt += "Roth vs. pre-tax contributions (Roth 401k/403b): " + n + " (Spanish)\n\n";}

	n = parseInt(ge("dhmi").value);	
	if (n > 0) {txt += "Retirement goal setting (Saving Goals): " + n + "\n\n";}

	n = parseInt(ge("loans").value);	
	if (n > 0) {txt += "Pros and cons of retirement plan loans (Loans): " + n + "\n\n";}

	n = parseInt(ge("sloans").value);	
	if (n > 0) {txt += "Pros and cons of retirement plan loans (Loans): " + n + " (Spanish)\n\n";}

	n = parseInt(ge("dyrp").value);	
	if (n > 0) {txt += "Diversification:  Building your own portfolio (Diversification): " + n + "\n\n";}

	n = parseInt(ge("iltf").value);	
	if (n > 0) {txt += "Understanding market volatility (Market Volatility): " + n + "\n\n";}

	n = parseInt(ge("kysot").value);	
	if (n > 0) {txt += "Retirement plan options when leaving your employer (Rollovers): " + n + "\n\n";}

	n = parseInt(ge("finprof").value);	
	if (n > 0) {txt += "Working with a financial professional (Financial Professionals): " + n + "\n\n";}

	n = parseInt(ge("sampnl").value);	
	if (n > 0) {txt += "Sample newsletters (RKD only): " + n + "\n\n";}

	n = parseInt(ge("ssampnl").value);	
	if (n > 0) {txt += "Sample newsletters (RKD only): " + n + " (Spanish)\n\n";}

	n = parseInt(ge("tdf").value);	
	if (n > 0) {txt += "Diversification:  Using a target date fund(Target Date Funds): " + n + "\n\n";}

	n = parseInt(ge("lyeb").value);	
	if (n > 0) {txt += "Taking advantage of employer-matching contributions (Employer Match): " + n + "\n\n";}

	n = parseInt(ge("rtq").value);	
	if (n > 0) {txt += "Asset Allocation Worksheet: " + n + "\n\n";}

	n = parseInt(ge("prmp").value);	
	if (n > 0) {txt += "Progress Report Meeting Posters: " + n + "\n\n";}

	n = parseInt(ge("sprmp").value);	
	if (n > 0) {txt += "Progress Report Meeting Posters: " + n + " (Spanish)\n\n";}

	n = parseInt(ge("prps").value);	
	if (n > 0) {txt += "Progress Report Payroll Stuffers: " + n + "\n\n";}

	n = parseInt(ge("sprps").value);	
	if (n > 0) {txt += "Progress Report Payroll Stuffers: " + n + " (Spanish)\n\n";}

	n = parseInt(ge("prosp").value);	
	if (n > 0) {txt += "Prospectuses: " + n + "\n\n";}

	n = parseInt(ge("sprosp").value);	
	if (n > 0) {txt += "Prospectuses: " + n + " (Spanish)\n\n";}

	ge("$addllit$").value = txt;
}

function toggleChanges() {

	if (ge("$chgno$").checked) {
		ge("$anychgs$").value = "No";
	} else if (ge("$chgyes$").checked) {
		ge("$anychgs$").value = "Yes";
	} else if (ge("$chgna$").checked) {
		ge("$anychgs$").value = "N/A";
	} else {
	}
}

function toggleFA() { 
	var chkd = ge("$send_fa$").checked;

	if (chkd) {
		ge("$hidfa$").value = "Financial Advisor";
		ge("$attn$").value = ge("$advname$").value;
		ge("$cophone$").value = ge("$advphone$").value;
	} else {
		ge("$hidfa$").value = "";
		ge("$attn$").value = "";
		ge("$cophone$").value = "";
	}
}

function togglePS() {
	var chkd = ge("$send_ps$").checked;
	if (chkd){ge("$hidps$").value = "Plan Sponsor";}else{ge("$hidps$").value = "";}
}

function toggleTPA() { 
	var chkd = ge("$send_tpa$").checked;
	if (chkd){ge("$hidtpa$").value = "TPA";}else{ge("$hidtpa$").value = "";}
}

function toggleOther() {
	var chkd = ge("$send_other$").checked;
	if (chkd){ge("$hidother$").value = "Other";}else{ge("$hidother$").value = "";}
}

function defDate() {
	var thedate = currDate();
	var def = bizCount(thedate, 15, 1); // count fwd 15 days from current date
	ge("$delivdate$").value = def[0];	

	var procby = bizCount(def[1], 8, 0); // count back 8 days from delivery date of mm/dd/yyyy:  def[1]

	ge("$pbdate$").value = procby[0];
}

function currDate() {
	today = new Date();
	var month = today.getMonth() + 1;
	var day = today.getDate();
	var year = today.getFullYear();
	var dateString = month + "/" + day + "/" + year;
	return dateString;
}	

// biz day counter; dir = 0 for count back, 1 for count fwd; returns an array
function bizCount(ctdate, ctdays, dir) {
	var dtarr = ctdate.split("/");

	// DATE PARTS
	var mo = parseFloat(dtarr[0]) - 1;
	var day = parseFloat(dtarr[1]);
	var yr = parseInt(dtarr[2]);

	var dtinst = new Date(yr, mo, day); // DATE INSTANCE

	var thems = dtinst.getTime(); // DATE TO MILLISECS

	var addDay = 1000 * 60 * 60 * 24; // 24 HOURS

	var newms = thems;

	var counter = 1;

	// COUNTING LOOP
	while (counter <= ctdays) {  
		if (dir == 1) {
			newms += addDay; // ADD 24 HRS TO MS DATE
		} else {
			newms -= addDay; // SUBTRACT 24 HRS FROM MS DATE
		}
		newinst = new Date(newms); // NEW DATE'S INSTANCE

		// GET DATE PARTS
		newmo = newinst.getMonth() + 1;
		newday = newinst.getDate();
		newdow = newinst.getDay(); // DAY OF WEEK
		newyr = newinst.getYear();

		// MON THRU FRI
		if (newdow == 1 || newdow == 2 || newdow == 3 || newdow == 4 || newdow == 5)

		counter++;
	}

	var dtresult = convDBDate2(newinst); // STORE DATE RESULTS IN ARRAY dtresult

	return dtresult;
}

function convDBDate2(cdate) { //***RETURNS ARRAY; 2 DATE STRINGS:  mm/dd/yy & mm/dd/yyyy
	// CREATE ARRAY
	var dString = new Array();

	//	INCOMING DATE STRING TO DATE OBJECT
	var dinst = new Date(cdate);

	///////////////////////////

	// GET DATE PARTS
	var cMonth = (dinst.getMonth()) + 1;
		if (cMonth < 10) {cMonth = "0" + cMonth;}
		
	var cDay = dinst.getDate();
		if (cDay < 10) {cDay = "0" + cDay;}

	var cYear = dinst.getFullYear() + "";

	var yrlen = cYear.length;
	var yr2 = cYear.substring(yrlen - 2, yrlen);

	///////////////////////////

	dString[0] = cMonth + "/" + cDay + "/" + yr2; // yy
	dString[1] = cMonth + "/" + cDay + "/" + cYear; // yyyy

	return dString;
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {

	// SET UP REGULAR EXPRESSION FOR DETECTING PO BOXES IN COMPANY ADDRESS (NOT PERMITTED)
	
	var theexp = new RegExp(/(p.\s*o.\s*box)|(p\s*o\s*box)/gi);

	if (!form_reprint_ce.$Rfa$.checked && !form_reprint_ce.$Rps$.checked && !form_reprint_ce.$Rrkd$.checked && !form_reprint_ce.$Rtpa$.checked && !form_reprint_ce.$Rother$.checked) {
		errorMsgArr[$("#\\$Rfa\\$").attr('tabindex')] = "- Requestor\n";
	}
	
	if (!form_reprint_ce.$send_fa$.checked && !form_reprint_ce.$send_ps$.checked && !form_reprint_ce.$send_tpa$.checked && !form_reprint_ce.$send_other$.checked) {
		errorMsgArr[$("#\\$send_fa\\$").attr('tabindex')] = "- Where should we ship the order?\n";
	}
	
	if ($.trim(ge("$address$").value) != "") {
		var bool = theexp.test(ge("$address$").value);
		if(bool) { // **** PO BOX DETECTED ****
			errorMsgArr[$("#\\$address\\$").attr('tabindex')] = "- A PO Box was detected in the Company Address.  Please replace teh entry with a physical mailing address\n";
		}
	}
		
	if (!form_reprint_ce.$chgno$.checked && !form_reprint_ce.$chgyes$.checked && !form_reprint_ce.$chgna$.checked) {
		errorMsgArr[$("#\\$chgno\\$").attr('tabindex')] = "- Have there been any changes to the plan that impact the books since the last order?\n";
	}
				
	if (form_reprint_ce.$chgyes$.checked && form_reprint_ce.$chgcomm$.value == "" ) {
		errorMsgArr[$("#\\$chgyes\\$").attr('tabindex')] = "- Comments are required in the 'Indicate any changes here' field since 'Yes' is selected for 'Changes since last order'.\n";
	}
}	

Form.CreateSubject = function () {

	buildLit(); // build string for addl literature
	buildPRD(); // build string for pr data
		
	if(ge("$ccsender$").checked) {
		form_reprint_ce.Qualifier.value = "COPY";
	}		

	form_reprint_ce.subject.value = form_reprint_ce.$planname$.value + " - Regular.Work.Reprints.";
}
	 
// BUILD PR DATA STRING

function buildPRD() {

	var txt = "";
	
	var psd = ge("$psd$").checked;
	var rkdg = ge("$rkdg$").checked;
	var pscag = ge("$pscag$").checked;	
	
	var avgbal = ge("$avgbal$").value;
	var avgbimo = ge("$avgbimo$").value;

	if (psd) {
		txt += "PLAN SPECIFIC DATA - Average Balance: $"+ avgbal +"   Average bi-monthly contribution: $" + avgbimo + "\n\n";
	}	

	if (rkdg) {
		txt += "RKD GENERIC DATA - Average Balance: $50,000 / Average bi-monthly contribution: $250\n\n";
	}	
	
	if (pscag) {
		txt += "PSCA GENERIC DATA - Average Balance: $85,000 / Average bi-monthly contribution: $84\n\n";
	}		
	
	ge("$prdtxt$").value = txt;
}

//	GETS & RETURNS ELEMENT REFERENCE
function ge(id) {
	var myelement = document.getElementById(id);
	return myelement;
}

Form.FormSpecificReset = function () {
	ge("prdata").style.display = "none";
	ge("Qualifier").value = "";
	ge("$hidpsd$").value = "No";
	ge("$hidrkdg$").value = "No";
	ge("$hidpscag$").value = "No";
	ge("$hidfa$").value = "";
	ge("$hidps$").value = "";
	ge("$hidtpa$").value = "";
	ge("$hidother$").value = "";
	ge("$reqby$").value = "";
	ge("$anychgs$").value = "";
	defDate();
}