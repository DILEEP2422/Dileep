Form.FormSpecificReset = function () {
	document.getElementById('$SITE$').focus();

	$("#bankWireInstructionAccounts #account").remove();
	$("#bankWireInstructionAccounts").append($("#accountTemplate #account").clone(true)); 

	$("#accountWireInvestmentTable:first").append($("#bankWireInvestmentLineTemplate #bankWireInvestmentLineSection").clone(true)); 
	$("#bankWireInstructionAccounts div[id=account]:last #accountWireInvestmentTable").find("input.dollarAmount").autoNumeric({aSign: '$'});

	reindexAccounts();
	reindexRows($("#bankWireInstructionAccounts").find("div[id=account]:last"));
	
	$("#wireInvestmentTotal").html("$0.00");
}

$("#TOTALWIREAMOUNT").autoNumeric({aSign: '$'});
$("#addAccount").click(function(){addNewAccount();});
$("#addAccount").keypress(function(){if (event.which == 32) addNewAccount();});

$("#addFund").click(function(){addLineItems(this);});
$("#addFund").keypress(function(){if (event.which == 32) addLineItems(this);});

$(".deleteFund").click(function(){
	var acct = $(this).closest("#accountWireInstructions");
	$(this).parent().parent().parent().remove();
	reindexRows(acct);
	recalcTotals(acct);
});

$(".deleteAccount").click(function(){
	$(this).closest("div#account").hide(200, function(){
		$(this).remove();
		reindexAccounts();
		recalcWireTotal();
	});
});

$(".accountNumber").blur(function(){
	var acNum = $(this).val();
	var acHeadNum = $(this).closest("div#account").find("span.accountHeaderNumber");

	if ($.trim(acNum).length == 0) $(acHeadNum).html("");
	else $(acHeadNum).html(acNum);
});


function addNewAccount(){

	$("#accountTemplate #account").clone(true).appendTo($("#bankWireInstructionAccounts"));
	$("#bankWireInstructionAccounts div[id=account]:last").find("input.accountNumber").focus();
	$("#bankWireInstructionAccounts div[id=account]:last #accountWireInvestmentTable").append($("#bankWireInvestmentLineTemplate #bankWireInvestmentLineSection").clone(true));
	$("#bankWireInstructionAccounts div[id=account]:last #accountWireInvestmentTable").find("input.dollarAmount").autoNumeric({aSign: '$'});
	
	reindexAccounts();
	reindexRows($("#bankWireInstructionAccounts").find("div[id=account]:last"));

}

function reindexAccounts(){
	Form.SetTabIndex();
	$("#bankWireInstructionAccounts .accountIndex").each(function(index){
		$(this).html(index+1 + ":&nbsp;");
	});
	
	if ($("#bankWireInstructionAccounts div[id=account]").length == 1) 
		$(".deleteAccount").css('visibility','hidden');
	else 
		$(".deleteAccount").css('visibility','visible');

	if ($("#bankWireInstructionAccounts div[id=account]").length == 10) 
		$("#addAccount").css('visibility','hidden');
	else
		$("#addAccount").css('visibility','visible');
	
}


function addLineItems(addFundButton){
	var acct = $(addFundButton).closest("div#accountWireInstructions");
	var lastLine = $(acct).find("div#accountWireInvestmentTable #bankWireInvestmentLineSection:last");
	var ACType = $(addFundButton).closest("div#account").find("select.accountType").val();
	var ACContribType = $(addFundButton).closest("div#account").find("select.accountContribType").val();
	
	$("#bankWireInvestmentLineTemplate #bankWireInvestmentLineSection").clone(true).insertAfter(lastLine); 

	$(acct).find("div#accountWireInvestmentTable div[id=bankWireInvestmentLineSection]:last input.dollarAmount").autoNumeric({aSign: '$'});
	
	$(acct).find("div#accountWireInvestmentTable div[id=bankWireInvestmentLineSection]:last input.fundNumber").focus();
	
	var newFundContribType = $(acct).find("div#accountWireInvestmentTable div[id=bankWireInvestmentLineSection]:last select.fundContribType");
	
	var lastFundContribTypeOption = $(newFundContribType).find("option:last");
	
	reindexRows(acct);
	
	$(addFundButton).closest("div#accountWireInstructions").find("div#accountWireInvestmentTable div:last input.fundNumber").focus();
	
	if (ACType == "AFS") {
		$("#accountTypeAFSTemplate option").clone(true).insertAfter(lastFundContribTypeOption);
		$(newFundContribType).val("Direct Investment")
	}	
	if (ACType == "CB&T") {
		$("#accountTypeCBTTemplate option").clone(true).insertAfter(lastFundContribTypeOption);
		if (ACContribType.length > 0 && ACContribType != "varies") {
			$(newFundContribType).val(ACContribType)
		}
		if (ACContribType == "varies") {
			$(newFundContribType).removeAttr("disabled");
		}
	}	
	if (ACType == "529") {
		$("#accountType529Template option").clone(true).insertAfter(lastFundContribTypeOption);
		if (ACContribType.length > 0 && ACContribType != "varies") {
			$(newFundContribType).val(ACContribType)
		}
		if (ACContribType == "varies") {
			$(newFundContribType).removeAttr("disabled");
		}
	}	
}

function reindexRows(acct){
	Form.SetTabIndex();
	var fundIndexes = $(acct).find("#accountWireInvestmentTable span.fundIndex");
	var numLines = $(acct).find("#accountWireInvestmentTable div[id=bankWireInvestmentLineSection]").length;

	$(fundIndexes).each(function(index){
		$(this).html(index+1);
	});
	
	if (numLines == 1) {
		$(acct).find(".deleteFund").css('visibility','hidden');
	} else {
		if(numLines == 20) {
			$(acct).find("#addFund").css('visibility','hidden');
		} else {
			$(acct).find("#addFund").css('visibility','visible');
		}
		$(acct).find(".deleteFund").css('visibility','visible');
	}
}

$("select.accountType").change(function(){
	var ACType = this.value;
	var acctContribTypeSelect = $(this).closest("div#accountDetails").find("select.accountContribType");
	var fundContribTypes = $(this).closest("div#account").find("select.fundContribType");
	
	resetContibType(acctContribTypeSelect);
	resetContibType(fundContribTypes);

	var lastAccountContribTypeOption = $(this).closest("div#accountDetails").find("select.accountContribType option:last");
	var lastFundContribTypeOption = $(this).closest("div#account").find("select.fundContribType option:last");

	if (ACType == "AFS"){
		$("#accountTypeAFSTemplate option").clone(true).insertAfter(lastAccountContribTypeOption);
		$(fundContribTypes).each(function(){
			$("#accountTypeAFSTemplate option").clone(true).insertAfter($(this).find("option:last"));
			$(this).val("Direct Investment"); 
		});
		$(acctContribTypeSelect).val("Direct Investment");
	}
	else if (ACType == "CB&T"){
		$("#accountTypeCBTTemplate option, #variesOptionTemplate option").clone(true).insertAfter(lastAccountContribTypeOption); 
		$(fundContribTypes).each(function(){
			$("#accountTypeCBTTemplate option").clone(true).insertAfter($(this).find("option:last"));
		});
		$(acctContribTypeSelect).removeAttr("disabled");
		$(acctContribTypeSelect).focus();
		$(acctContribTypeSelect).val("");
	}
	else if (ACType == "529"){
		$("#accountType529Template option, #variesOptionTemplate option").clone(true).insertAfter(lastAccountContribTypeOption); 
		$(fundContribTypes).each(function(){
			$("#accountType529Template option").clone(true).insertAfter($(this).find("option:last"));
		});
		$(acctContribTypeSelect).removeAttr("disabled");
		$(acctContribTypeSelect).focus();
		$(acctContribTypeSelect).val("");

	}
});

function resetContibType(selects){
	$(selects).each(function() {
		$(this).val("");
		$(this).find("option.removable").remove();
		$(this).removeAttr("disabled");
		$(this).attr("disabled", "disabled");
	});
}

$("select.accountContribType").change(function(){
	var fundLines = $(this).closest("div#account").find("select.fundContribType");

	if (this.value == "varies") {
		$(fundLines).each(function() {
			$(this).val("");
			$(this).removeAttr("disabled");
		});
	}
	else {
		var ACContribType = this.value;
		$(fundLines).each(function() {
			$(this).val(ACContribType);
			$(this).attr("disabled", "disabled");
		});
	}
	
});

$(".dollarAmount").blur(function(){recalcTotals($(this).closest("div#accountWireInstructions"));});

function recalcTotals(acct){
	var thisAcctsAmts = $(acct).find(".dollarAmount");
	var acctTotal = 0.00;
	var acctTotalLabel = $(acct).closest("#account").find("span.accountHeaderTotal");
	
	$("#tempAccountTotal").val("");
	
	$(thisAcctsAmts).each(function(){
		acctTotal += parseFloat($(this).autoNumericGet());
	});
	
	$("#tempAccountTotal").autoNumericSet(acctTotal, {aSign: '$', vMin: '0.00', vMax: '99999999999.99'});
	$(acctTotalLabel).text($("#tempAccountTotal").val());
	
	recalcWireTotal();
}

function recalcWireTotal() {
	var allDollarAmounts = $("#bankWireInstructionAccounts").find(".dollarAmount")
	var wireTotal = 0.00;
	var wireTotalLabel = $("#wireInvestmentTotal");
	
	$("#tempWireTotal").val("");

	$(allDollarAmounts).each(function(){
		wireTotal += parseFloat($(this).autoNumericGet());
	});

	$("#tempWireTotal").autoNumericSet(wireTotal, {aSign: '$', vMin: '0.00', vMax: '99999999999.99'});
	$(wireTotalLabel).text($("#tempWireTotal").val());
}

function returnUniqueAccountNumbers(){
	var accountNumbers = new Array();

	$("#bankWireInstructionAccounts input.accountNumber").each(function (){
		if (this.value != "") {accountNumbers.push((this).value);}
	});
	
	var uniqueAccountNumbers = new Array();
	var numberOfAccounts = accountNumbers.length;
	
	for (var i=0; i<numberOfAccounts; i++) {
		for(var j=i+1; j<numberOfAccounts; j++)
			if (accountNumbers[i] === accountNumbers[j]) {
				j = ++i;
			}
			uniqueAccountNumbers.push(accountNumbers[i]);
	}
	
	uniqueAccountNumbers = uniqueAccountNumbers.sort(sortNumber);
	return uniqueAccountNumbers.join(", ");
}

function sortNumber(a,b) {
	return a - b;
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	var wbiForm = document.getElementById("wbiForm");
	
	if ($("#TOTALWIREAMOUNT").autoNumericGet() != $("#tempWireTotal").autoNumericGet()) {
		errorMsgArr[$("#TOTALWIREAMOUNT").attr('tabindex')] = "- Wire Instructions total must equal Total Wire Amount field\n";
	}
	
	testLineItems(wbiForm, errorMsgArr);
	
	if (wbiForm.$ACCTNOTE$.checked == false) {
		errorMsgArr[$("#\\$ACCTNOTE\\$").attr('tabindex')] = "- Account Note Added\n";
	}
	
}

Form.CreateSubject = function () {
	wbiForm.$WIRETOTAL$.value = wbiForm.TOTALWIREAMOUNT.value;
	wbiForm.subject.value = "Bank Wire Instructions - " + returnUniqueAccountNumbers();
}

function testLineItems(form, errorMsgArr) {

	form.$WIREINSTRUCTIONS$.value = "";

	$("#bankWireInstructionAccounts #account").each(function(index) {
		var accountErrorLines = "";
		var acctIndex = index + 1;
		var acctNumber = $.trim($(this).find("input.accountNumber").val());
		var acctAlphaCode = $.trim($(this).find("input.alphaCode").val());
		var acctType = $(this).find("select.accountType").val();
		var acctContribType = $(this).find("select.accountContribType").val();
		
		if (acctNumber.length == 0 || acctAlphaCode.length == 0 || acctType.length == 0 || acctContribType.length == 0) {
			if (acctNumber.length == 0) accountErrorLines+= "\n    ACCOUNT #";
			if (acctAlphaCode.length == 0) accountErrorLines+= "\n    ALPHA CODE";
			if (acctType.length == 0) accountErrorLines+= "\n    A/C TYPE";
			if (acctContribType.length == 0) accountErrorLines+= "\n    CONTRIB TYPE";
		}
		else {
			form.$WIREINSTRUCTIONS$.value += "ACCOUNT #: " + acctNumber + "    ALPHA CODE: " + acctAlphaCode + "    A/C TYPE: " + acctType;
			form.$WIREINSTRUCTIONS$.value += "\n\n    FUND          DOLLAR AMOUNT      CONTRIB TYPE\n";
		}
		
		var acctFundLines = $(this).find("#accountWireInvestmentTable #bankWireInvestmentLineSection");
		var oneLineMinimum = false;
		
		$(acctFundLines).each(function(index){
			var fundIndex = index + 1;
			var fundNumber = $.trim($(this).find("input.fundNumber").val());
			var fundDollarAmt = $(this).find("input.dollarAmount").val();
			var fundContribType = $(this).find("select.fundContribType").val();

			if (acctContribType == "varies"){
				if (fundNumber.length != 0 || fundDollarAmt.length != 0 || fundContribType.length != 0){
					if (fundNumber.length > 0 && fundDollarAmt.length > 0 && fundContribType.length > 0){
						form.$WIREINSTRUCTIONS$.value += "    " + padSpacesToRight(fundNumber, 6);
						form.$WIREINSTRUCTIONS$.value += padSpacesToLeft(fundDollarAmt, 22) + "   ";
						form.$WIREINSTRUCTIONS$.value += "   "+fundContribType + "\n";
						oneLineMinimum = true;
					}
					else accountErrorLines += "\n    Line # " + fundIndex + " is incomplete";
				}				
			}
			else {
				if (fundNumber.length != 0 || fundDollarAmt.length != 0){
					if (fundNumber.length > 0 && fundDollarAmt.length > 0) {
						form.$WIREINSTRUCTIONS$.value += "    " + padSpacesToRight(fundNumber, 6);
						form.$WIREINSTRUCTIONS$.value += padSpacesToLeft(fundDollarAmt, 22) + "   ";
						form.$WIREINSTRUCTIONS$.value += "   "+fundContribType + "\n";
						oneLineMinimum = true;
					}
					else accountErrorLines += "\n    Line # " + fundIndex + " is incomplete";
				}				
			}
			
			
		});
		if (oneLineMinimum == false) {
			accountErrorLines += "\n    At least one line must be complete\n";
		}
		
		if (accountErrorLines.length > 0) {
			errorMsgArr[$(this).find("input.accountNumber").attr('tabindex')] = "\n- ACCOUNT # " + acctIndex + ":\n" + accountErrorLines + "\n";
		}

		form.$WIREINSTRUCTIONS$.value += "\n\n"
		
		
	});
	
	
	
}

function ValidatePhone(m){
	p1 = null;
	p1 = m;
	ValidatePhone1(p1);
}

function ValidatePhone1(p1){
	var p;
	p = "";
	p = p1.value;
	
	if(p.length == 3){
		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ")";
		}
	p1.value=""; p1.value=pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
			p1.value=""; p1.value=pp;

		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
			pp = "(" + p13 + ")" + p14 + p15;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 2 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
			p1.value=""; p1.value=pp;
		}

	}
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = $.trim(str);
    }
}

function padSpacesToRight(inputstring, totalLength){
	var returnstr=inputstring;
	for (var i = inputstring.length; i<totalLength; i++) {
		returnstr += " ";
	}
	return returnstr;
}

function padSpacesToLeft(inputstring, totalLength){
	var returnstr="";
	for (var i = 1; i<totalLength-inputstring.length; i++) {
		returnstr += " ";
	}
	returnstr += inputstring;
	return returnstr;
}