// http://johnliu.net/blog/2015/12/convert-sharepoint-jsoms-executequeryasync-to-promise-in-the-prototype
SP.ClientContext.prototype.executeQuery = function() {
   var deferred = $.Deferred();
   this.executeQueryAsync(
       function(){ deferred.resolve(arguments); },
       function(){ deferred.reject(arguments); }
   );
   return deferred.promise();
};

var siteRoot = "http://appsqa2/sites/onlineformsroom/_vti_bin/ListData.svc/";

$(document).ready(function () {
	setFilters();
	SP.SOD.executeOrDelayUntilScriptLoaded(Initialize, 'sp.js');
	$("#formListDiv").height($( window ).height() * 0.5);
});

var preset;
var area;
var formName = "";

$('input:radio[name="presetRadio"]').on("click", function () {
	$("#formListDiv").empty();
	$("#searchForm").val("");
	resetArea();
	resetForms();
	resetSearch();
	setFilters();
	SP.SOD.executeOrDelayUntilScriptLoaded(Initialize, 'sp.js');
});

$('input:radio[name="areaRadio"]').on("click", function () {
	$("#formListDiv").empty();
	$("#searchForm").val("");
	resetForms();
	resetSearch();
	setFilters();
	SP.SOD.executeOrDelayUntilScriptLoaded(Initialize, 'sp.js');
});

function registerFormsRadioClickEvent() {
	$('input:radio[name="formsRadio"]').on("click", function () {
		formName = $('input:radio[name="formsRadio"]:checked').val();
		drawCharts();
		drawTables();
	});
}

function resetArea() {
	$('input:radio[name="areaRadio"]:first').prop('checked',true);
}

function resetForms() {
	$('input:radio[name="formsRadio"]').each(function () {
		$(this).prop('checked',false);
	});
	formName = "";
}

function resetSearch() {
	$('.search').val("");
}

function setFilters() {
	preset = $('input:radio[name="presetRadio"]:checked').val();
	area = $('input:radio[name="areaRadio"]:checked').val();
}

var forms = [];

function createDateArrayUsingPreset() {
	var dateRange = [];
	var endDate = new Date();
	var startDate = endDate - ((-1*(preset-1))*24*60*60*1000);
	
	while (startDate <= endDate) {
		dateRange.push(startDate);
		startDate = startDate + (24*60*60*1000);
	}
	
	return dateRange;
}

var allFormsProcessed = false;
var formsCount = 0;
var clicksNext = false;
var submissionsNext = false;

function Initialize() {
	clicksNext = false;
	submissionsNext = false;
	$("#report").css('display','none');
	$("#fetchDataButton").css('display','none');
	$("body").append("<div id='patience'><div><img src='images/loader.gif'></div></div>");
	clicksUrl = siteRoot + "Clicks";
	submissionsUrl = siteRoot + "Submissions";
	forms = [];
	allClicks = [];
	allSubmissions = [];
	Lists.Load();
	formsCount = 0;
	var formsQueryBuilder = new CamlQueryBuilder(['ID','Title','Area'], 'ID', true, null, new OFRWhereByArea(area));
	Lists.ReadWithQueryBuilder('Forms', formsQueryBuilder, false, function (formItems) {
		formItems.forEach( function(formItem) {
			formsCount++;
			var form = {};
			form.ID = formItem.ID;
			form.Name = formItem.Title;
			var areas = [];
			formItem.Area.forEach(function (e, i, a) {
				areas.push(e.get_lookupValue());
			});
			form.Areas = areas;
			form.Clicks = [];
			form.Submissions = [];
			forms[formItem.ID] = form;
		});
		GetClicks();
	});
}

function processData() {
	updateFormsInFilter();
	registerFormsRadioClickEvent();
	$("body").find("#patience").remove();
	$("#fetchDataButton").css('display','block');
	$("#report").css('display','block');
	drawCharts();
	drawTables();
}

var clicksUrl = siteRoot+"Clicks";
var allClicks = [];
function GetClicks() {
	jQuery.ajax({
		url: clicksUrl,
		method: "GET",
		headers: { "Accept": "application/json;odata=verbose" },
		success: function (data) {
			allClicks = allClicks.concat(data.d.results);
			if (data.d.__next) {
				clicksUrl = data.d.__next;
				GetClicks();
			}
			else {
				clicksNext = true;
			}
		},
		complete: function () {
			if(clicksNext) {
				ProcessClicks();
			}
		}
	});
}

function parseJsonDate( sDate ) {
    var b, e, i;
    b = sDate.indexOf('(');
    e = sDate.indexOf(')');
    i = sDate.substring(b+1,e);

    if (isNaN(i)) { return null };
    return new Date(parseInt(i));
}

function ProcessClicks() {
	var endDate = new Date();
	var startDate = endDate - ((-1*(preset-1))*24*60*60*1000);
	
	allClicks = jQuery.grep(allClicks, function (n, i) {
		return (parseJsonDate(n.Clicked) >= startDate);
	});
	
	GetSubmissions();
}

var submissionsUrl = siteRoot+"Submissions";
var allSubmissions = [];
function GetSubmissions() {
	jQuery.ajax({
		url: submissionsUrl,
		method: "GET",
		headers: { "Accept": "application/json;odata=verbose" },
		success: function (data) {
			allSubmissions = allSubmissions.concat(data.d.results);
			if (data.d.__next) {
				submissionsUrl = data.d.__next;
				GetSubmissions();
			}
			else {
				submissionsNext = true;
			}
		},
		complete: function () {
			if(submissionsNext) {
				ProcessSubmissions();
			}
		}
	});
}

function ProcessSubmissions() {
	var endDate = new Date();
	var startDate = endDate - ((-1*(preset-1))*24*60*60*1000);
	
	allSubmissions = jQuery.grep(allSubmissions, function (n, i) {
		return (parseJsonDate(n.Submitted) >= startDate);
	});
	
	UpdateFormsArray();
}

function UpdateFormsArray() {
	var counter = 0;
	/* Update Forms Array */
	$.each(forms, function (key, value) {
		if(value != null) {
			var formId = value.ID;
			$.each(allClicks, function (key, value) {
				if(value.FormId == formId) {
					var click = {};
					var clickDate = parseJsonDate(value.Clicked);
					var clickMonth = (clickDate.getMonth() + 1) + "-" + clickDate.getFullYear();
					var clickDateOnly = (clickDate.getMonth() + 1) + "/" + clickDate.getDate() + "/" + clickDate.getFullYear();
					click.ClickDate = clickDateOnly;
					click.ClickMonth = clickMonth;
					forms[formId].Clicks.push(click);
				}
			});
			$.each(allSubmissions, function (key, value) {
				if(value.FormId == formId) {
					var submission = {};
					var submissionDate = parseJsonDate(value.Submitted);
					var submissionMonth = (submissionDate.getMonth() + 1) + "-" + submissionDate.getFullYear();
					var submissionDateOnly = (submissionDate.getMonth() + 1) + "/" + submissionDate.getDate() + "/" + submissionDate.getFullYear();
					submission.SubmissionDate = submissionDateOnly;
					submission.SubmissionMonth = submissionMonth;
					forms[formId].Submissions.push(submission);
				}
			});
		}
	});
	processData();
}

function updateFormsInFilter() {
	$("#formListDiv").empty();
	var mainDiv = $("#formListDiv");
	
	$.each(forms, function (key, value) {
		if(value!=null) {
			var div = $("<div class='radio' />");
			var label = $("<label class='name' style='font-weight: bold;' />");
			var clickSpan = $("<span class='badge badge-clicks' />");
			var submittedSpan = $("<span class='badge badge-submissions' />");
			if(area != "") {
				var input = $("<input type='radio' name='formsRadio' value='"+value.Name+"' />");
			} else {
				var input = $("<input type='radio' name='formsRadio' value='"+value.Name+"' disabled=disabled />");
			}

			label.append(input);
			label.append(value.Name);
			label.append("&nbsp;");
			label.append(label);
			clickSpan.append(value.Clicks.length);
			submittedSpan.append(value.Submissions.length);
			label.append(clickSpan);
			label.append(submittedSpan);
			div.append(label);
			mainDiv.append(div);
		}
	});
	$("#formList").append(mainDiv);
	
	var options = {
		valueNames: [ 'name' ]
	};
	
	var formList = new List('formList', options);
	formList.sort('name', { order: "asc" }); 
}

var myChart;

function drawLineChart(id, clickTitle, submittedTitle, labels, clicksData, submittedData) {
	
	if(formName == "") {
		$("#chartTitle").text("Clicks & Submission Chart - Last " + (-1*preset) + " days");
	} else {
		$("#chartTitle").text(formName + " - Clicks & Submission Chart - Last " + (-1*preset) + " days");
	}
	
	var ctx = document.getElementById(id);
	
	var data = {
		labels: labels,
		datasets: [
			{
				label: clickTitle,
				fill: false,
				lineTension: 0.1,
				backgroundColor: "rgba(0,154,223,1)",
				borderColor: "rgba(0,154,223,1)",
				borderCapStyle: 'round',
				borderJoinStyle: 'round',
				pointBorderColor: "rgba(120, 120, 120, 1)",
				pointBackgroundColor: "rgba(120, 120, 120, 1)",
				pointBorderWidth: 1,
				pointHoverRadius: 2,
				pointHoverBackgroundColor: "rgba(0,0,0,1)",
				pointHoverBorderColor: "rgba(0,0,0,1)",
				pointHoverBorderWidth: 2,
				pointRadius: 2,
				pointHitRadius: 10,
				data: clicksData,
				spanGaps: false,
				showLines: false
			}, 
			{
				label: submittedTitle,
				fill: false,
				lineTension: 0.1,
				backgroundColor: "rgba(30, 90, 160, 1)",
				borderColor: "rgba(30, 90, 160, 1)",
				borderCapStyle: 'round',
				borderJoinStyle: 'round',
				pointBorderColor: "rgba(120, 120, 120, 1)",
				pointBackgroundColor: "rgba(120, 120, 120, 1)",
				pointBorderWidth: 1,
				pointHoverRadius: 2,
				pointHoverBackgroundColor: "rgba(0,0,0,1)",
				pointHoverBorderColor: "rgba(0,0,0,1)",
				pointHoverBorderWidth: 2,
				pointRadius: 2,
				pointHitRadius: 10,
				data: submittedData,
				spanGaps: false,
				showLines: false
			}
		]
	};
	
	var options = {
		scales: {
			xAxes: [{gridLines: {  display:false }}],
			yAxes: [{gridLines: { color: "rgba(242, 242, 242, 1)" }}]
		}
    };
	
	if(myChart!=null) {
		myChart.destroy();
	}
	
	myChart = new Chart(ctx, {
		type: 'line',
		data: data,
		options: options
	});
}

function uniqueObjectArray(array, field) {
    var processed = [];
    for (var i=array.length-1; i>=0; i--) {
        if (array[i].hasOwnProperty(field)) {
            if (processed.indexOf(array[i][field])<0) {
                processed.push(array[i][field]);
            } 
        }
    }
	return processed;
}

var clickedDates = [];
var submittedDates = [];

function drawClicksChart(formName) {
	clickedDates = [];
	submittedDates = [];
	
	var labels = [];
	var clicksData = [];
	var submittedData = [];
	
	var formsCopy = forms.slice();
	
	if(formName != "") {
		formsCopy = $.grep(forms, function(key, value) {
			if(key!=null) {
				return (key.Name == formName);
			}
		});
	}
	
	$.each(formsCopy, function( key, value ) {
		if(value != null) {
			var clicks = value.Clicks;
			var submissions = value.Submissions;
			var formName = value.Name;
			$.each(clicks, function (key, value) {
				var click = {};
				click.ClickDate = value.ClickDate;
				click.Form = formName;
				clickedDates.push(click);
			});
			$.each(submissions, function (key, value) {
				var submission = {};
				submission.SubmissionDate = value.SubmissionDate;
				submission.Form = formName;
				submittedDates.push(submission);
			});
		}
	});
	
	var dateRange = createDateArrayUsingPreset();
	
	/* Parse through unique months and identify # of clicks */
	$.each(dateRange, function (key, value) {
		var dateValue = new Date(value);
		var dateInRange = (dateValue.getMonth() + 1) + "/" + dateValue.getDate() + "/"+ dateValue.getFullYear();
		var clickEntries = $.grep(clickedDates, function(v) {
			return(v.ClickDate == dateInRange);
		});
		var submitEntries = $.grep(submittedDates, function(v) {
			return(v.SubmissionDate == dateInRange);
		});
		labels.push(dateInRange);
		clicksData.push(clickEntries.length);
		submittedData.push(submitEntries.length);
	});
	
	drawLineChart("chartCanvas", "# of Clicks", "# of Submissions", labels, clicksData, submittedData);
}

function drawFormsTable(formName) {
	$("#tableData").empty();
	var tbody = $("<tbody id='tableRows' class='list' />");
	var table = $("<table class='table table-hover table-striped' />");
	if(formName == "") {
		var thead = $("<thead />");
		var headingRow = $("<tr />");
		
		var thName = $("<th />");
		thName.append("<a class='sort' data-sort='name'>Form </a>");
		headingRow.append(thName);
		
		var thClicks = $("<th />");
		thClicks.append("<a class='sort' data-sort='clicks'>Clicks </a>");
		headingRow.append(thClicks);
		
		var thSubmissions = $("<th />");
		thSubmissions.append("<a class='sort' data-sort='submissions'>Submissions </a>");
		headingRow.append(thSubmissions);
		
		thead.append(headingRow);
		
		var headingRow2 = $("<tr />");
		var th = $("<th />");
		th.append("<strong>Total</strong>");
		headingRow2.append(th);
		
		var thClicksTotal = $("<th />");
		thClicksTotal.append("<span id='clicksTotal' class='badge badge-clicks'></span>");
		headingRow2.append(thClicksTotal);
		
		var thSubmissionsTotal = $("<th />");
		thSubmissionsTotal.append("<span id='submissionsTotal' class='badge badge-submissions'></span>");
		headingRow2.append(thSubmissionsTotal);
		
		thead.append(headingRow2);
		
		table.append(thead);
		var clicksTotal = 0;
		var submissionsTotal = 0;
		forms.forEach(function (form) {
			if(form != null) {
				var tr = $('<tr/>');
				var tdName = $("<td class='name'  />");
				tdName.append(form.Name);
				
				var tdClicks = $("<td class='clicks' />");
				tdClicks.append(form.Clicks.length);
				clicksTotal += form.Clicks.length;
				
				var tdSubmissions = $("<td class='submissions'  />");
				tdSubmissions.append(form.Submissions.length);
				submissionsTotal += form.Submissions.length;
				
				tr.append(tdName);
				tr.append(tdClicks);
				tr.append(tdSubmissions);
				
				tbody.append(tr);
			}
		});
		table.find("#clicksTotal").html(clicksTotal);
		table.find("#submissionsTotal").html(submissionsTotal);
		
		$("#tableTitle").text("Clicks & Submission Data - Last " + (-1*preset) + " days");
		table.append(tbody);
		$("#tableData").append(table);
		$("#tableData").append("<ul class='pagination'></ul>");
		var options = { valueNames: [ 'name', 'clicks', 'submissions' ], page: 15, plugins: [ ListPagination({}) ]};
		var tableList = new List('tableData', options);
		tableList.sort('name', { order: 'asc'} );
	} else {
		var formsCopy = forms.slice();
	
		formsCopy = $.grep(forms, function(key, value) {
			if(key!=null) {
				return (key.Name == formName);
			}
		});
		
		var thead = $("<thead />");
		var headingRow = $("<tr />");
		
		var thName = $("<th />");
		thName.append("<a class='sort' data-sort='date'>Date </a>");
		headingRow.append(thName);
		
		var thClicks = $("<th />");
		thClicks.append("<a class='sort' data-sort='clicks'>Clicks </a>");
		headingRow.append(thClicks);
		
		var thSubmissions = $("<th />");
		thSubmissions.append("<a class='sort' data-sort='submissions'>Submissions </a>");
		headingRow.append(thSubmissions);
		
		thead.append(headingRow);
		
		var headingRow2 = $("<tr />");
		var th = $("<th />");
		th.append("<strong>Total</strong>");
		headingRow2.append(th);
		
		var thClicksTotal = $("<th />");
		thClicksTotal.append("<span id='clicksTotal' class='badge badge-clicks'></span>");
		headingRow2.append(thClicksTotal);
		
		var thSubmissionsTotal = $("<th />");
		thSubmissionsTotal.append("<span id='submissionsTotal' class='badge badge-submissions'></span>");
		headingRow2.append(thSubmissionsTotal);
		
		thead.append(headingRow2);
		
		table.append(thead);
		
		var dateRange = createDateArrayUsingPreset();
		var clicksTotal = 0;
		var submissionsTotal = 0;
		
		/* Parse through unique months and identify # of clicks */
		$.each(dateRange, function (key, value) {
			var dateValue = new Date(value);
			var dateInRange = (dateValue.getMonth() + 1) + "/" + dateValue.getDate() + "/"+ dateValue.getFullYear();
			var clickEntries = $.grep(clickedDates, function(v) {
				return(v.ClickDate == dateInRange);
			});
			var submitEntries = $.grep(submittedDates, function(v) {
				return(v.SubmissionDate == dateInRange);
			});
			var tr = $('<tr/>');
			var tdDate = $("<td class='date'  />");
			tdDate.append(dateInRange);
			
			var tdClicks = $("<td class='clicks' />");
			tdClicks.append(clickEntries.length);
			clicksTotal += clickEntries.length;
			
			var tdSubmissions = $("<td class='submissions'  />");
			tdSubmissions.append(submitEntries.length);
			submissionsTotal += submitEntries.length;	
			
			tr.append(tdDate);
			tr.append(tdClicks);
			tr.append(tdSubmissions);
			
			tbody.append(tr);
		});
		
		table.find("#clicksTotal").html(clicksTotal);
		table.find("#submissionsTotal").html(submissionsTotal);
		
		$("#tableTitle").text(formName + " - Clicks & Submission Data - Last " + (-1*preset) + " days");
		table.append(tbody);
		$("#tableData").append(table);
		$("#tableData").append("<ul class='pagination'></ul>");
		var options = { valueNames: [ 'date', 'clicks', 'submissions' ], page: 15, plugins: [ ListPagination({}) ]};
		var tableList = new List('tableData', options);
		tableList.sort('date', { order: 'asc'} );
	}
}

function drawTables() {
	drawFormsTable(formName);
}

function drawCharts() {
	drawClicksChart(formName);
	$("canvas").each(function () {
		$(this).css("border","1px solid #e0e0e0");
		$(this).css("margin-top", "10px;");
		$(this).css("display", "block");
	});
}

function OFRWhere(days, formID) {
	this.BuildElement = function() {
		var where = "<Where><And><Eq><FieldRef Name='Form' LookupId='TRUE'/><Value Type='Lookup'>"+formID+"</Value></Eq><Geq><FieldRef Name='Created'/><Value Type='DateTime' ><Today OffsetDays='"+days+"'/></Value></Geq></And></Where>";
		return where;
	}	
}

function OFRWhereByArea(area) {
	this.BuildElement = function() {
		if(area == "") {
			return null;
		} else {
			var where = '<Where><Contains><FieldRef Name="Area" LookupId="FALSE"/><Value Type="Text">' + area + '</Value></Contains></Where>';
			return where;
		}
	}	
}