function checkWorktype() {
	var wktype = ge("$worktype$").value;
	if (wktype == "Web Walk-Through") {
		alert("For RUSH Web Walk-Through requests, please contact Client Services and do not complete this form.");
	}
}					
	
function showResearch() {
	ge("rushlbl").style.display = "block";
	ge("msg").innerHTML = "IMPORTANT:  Research requests should only be initiated by Client Services associates.";
	ge("hdmsg1").style.display = "block";	
	ge("hdmsg2").style.display = "block";	
	ge("$worktype$").length = 0; // clear list
	ge("$worktype$").options[0] = new Option ("General Question");
	ge("$worktype$").options[0].value = "General Question";
	ge("$hidtype$").value = "Research";
}	

function showTrans() {
	ge("helpyes").checked = false;
	ge("helpno").checked = false;
	ge("$rush$").checked = false;
	ge("rushlbl").style.display = "none";
	ge("msg").innerHTML = "&#160;";
	ge("hdmsg1").style.display = "none";
	ge("hdmsg2").style.display = "none";
	ge("$worktype$").length = 0; // clear list
	ge("$worktype$").options[0] = new Option ("");
	ge("$worktype$").options[0].value = "";

	ge("$worktype$").options[1] = new Option ("ATR Rollover Acceptance");
	ge("$worktype$").options[1].value = "ATR Rollover Acceptance";

	ge("$worktype$").options[2] = new Option ("Earnings Payroll");
	ge("$worktype$").options[2].value = "Earnings Payroll";

	ge("$worktype$").options[3] = new Option ("Residual Distribution");
	ge("$worktype$").options[3].value = "Residual Distribution";

	ge("$worktype$").options[4] = new Option ("Web Walk-Through");
	ge("$worktype$").options[4].value = "Web Walk-Through";
}						
	
function toggleType() {

	if (ge("afo").checked) {
		ge("$hidptype$").value = "AFO";
	} else if (ge("mf").checked) {
		ge("$hidptype$").value = "Multifund";
	} else if (ge("pptpa").checked) {
		ge("$hidptype$").value = "PP/PPTPA";
	}
}

function toggleCBR() {
	if (ge("$cbyes$").checked) {
		ge("$hidcbreq$").value = "Yes";
	} else if (ge("$cbno$").checked) {
		ge("$hidcbreq$").value = "No";
	}
}
	
Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if (!ge("afo").checked && !ge("mf").checked && !ge("pptpa").checked){
		errorMsgArr[$("#afo").attr('tabindex')] = "- Plan Type\n";
	}		

	if (!ge("$cbyes$").checked && !ge("$cbno$").checked ) {
		errorMsgArr[$("#\\$cbyes\\$").attr('tabindex')] = "- Callback Required?\n";
	}

	if (!ge("$research$").checked && !ge("$trans$").checked) {
		errorMsgArr[$("#\\$research\\$").attr('tabindex')] = "- Request Type\n";
	}
	
	if (ge("$research$").checked && !ge("helpyes").checked && !ge("helpno").checked) {
		errorMsgArr[$("#\\$research\\$").attr('tabindex')] = "- Was the Help Desk contacted regarding this situation?\n";
	}
}

Form.CreateSubject = function () {
	var wktype = form_rps_transaction.$worktype$.value;
	var dotwkt = ""; 
	var theplanid = form_rps_transaction.$planid$.value;
	var theplanname = form_rps_transaction.$planname$.value;
	var thesubject = "";
	var isRush = ge("$rush$").checked;
	if (isRush){
		var priority = " *RUSH"; // includes leading space
	} else {
		var priority = "";
	}
	
	switch(wktype) {
		case "General Question":
			dotwkt = "Specialized.Work.General Question.Research.";
			break;
		case "Statements or Forms":
			dotwkt = "Specialized.Work.Statements or Forms.Research.";
			break;
		case "Web":
			dotwkt = "Specialized.Work.Web.Research.";
			break;
		case "Rollover Investments":
			dotwkt = "Specialized.Work.Rollover Investments.Research.";
			break;
		case "Other":
			dotwkt = "Specialized.Work.Other.Research.";
			break;	
		case "Earnings Payroll":
			dotwkt = "Regular.Work.Earnings.";
			ge("$hidtype$").value = wktype;
			break;			
		case "Residual Distribution":
			dotwkt = "Regular.Work.Distribution.";
			ge("$hidtype$").value = wktype;
			break;			
		case "Web Walk-Through":
			dotwkt = "Regular.Work.Web.";
			ge("$hidtype$").value = wktype;
			break;			
		case "ATR Rollover Acceptance":
			dotwkt = "Regular.Work.Fin Participant Maint.";
			ge("$hidtype$").value = wktype;
			break;	
	}
	
	if (ge("$research$").checked) {
		var prefix = "RPS Research Request ";
	} else if (ge("$trans$").checked) {
		var prefix = "RPS Transaction Request ";
	}

	thesubject = prefix + dotwkt + priority + " " + theplanid + " - " + theplanname;
	form_rps_transaction.subject.value = thesubject;
}

function ge(id) {
	var myelement = document.getElementById(id);
	return myelement;
}

Form.FormSpecificReset = function () {
	ge("helpyes").checked = false;
	ge("helpno").checked = false;
	ge("$rush$").checked = false;
	ge("rushlbl").style.display = "none";
	ge("msg").innerHTML = "&#160;";
	ge("hdmsg1").style.display = "none";
	ge("hdmsg2").style.display = "none";
	ge("$worktype$").length = 0;
	ge("$worktype$").options[0] = new Option ("");
	ge("$worktype$").options[0].value = "";
	ge("$hidptype$").value = "";
	ge("$hidcbreq$").value = "";
	ge("$hidtype$").value = "";
	ge("$hidhelpdesk$").value = "";
}