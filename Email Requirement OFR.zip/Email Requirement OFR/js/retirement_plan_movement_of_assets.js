Form.ValidateSpecificFormFields = function (errorMsgArr) {

	rpmaForm.$COMBINEDPHONE$.value = "";
	rpmaForm.$PLANTYPES$.value = "";
	if(!rpmaForm.TRAC.checked && !rpmaForm.GPURCH.checked && !rpmaForm.OTHER.checked) {
		errorMsgArr[$("#TRAC").attr('tabindex')] = "- PLAN TYPE: Select TRAC, GPURCH, or OTHER (may be more than one)\n";
	} else {
		var planTypes = new Array();
		
		if ($('#' + "TRAC").is(":checked")) planTypes.push("TRAC: Y");
		if ($('#' + "GPURCH").is(":checked")) planTypes.push("GPURCH: Y");
		if ($('#' + "OTHER").is(":checked")) planTypes.push("OTHER: Y");
		
		if (planTypes.length == 1) rpmaForm.$PLANTYPES$.value = "PLAN TYPE: " + planTypes[0];
		else if (planTypes.length > 1) {
			rpmaForm.$PLANTYPES$.value = "PLAN TYPES: " + planTypes[0] + "\n";
			rpmaForm.$PLANTYPES$.value += "            " + planTypes[1];
			if (planTypes.length == 3) rpmaForm.$PLANTYPES$.value += "\n            " + planTypes[2];
		}
	}
	
	rpmaForm.$COMBINEDPHONE$.value = rpmaForm.$PHONE$.value + " Ext: " + rpmaForm.$CALLEREXT$.value;
}

Form.CreateSubject = function () {
	rpmaForm.subject.value = "RETIREMENT_PLAN_MOVEMENT_OF_ASSETS";
}

function ValidatePhone(p1){
	
	p1.value = p1.value.replace(/ /g, "");
	p1.value = p1.value.replace(/-/g, "");
	p1.value = p1.value.replace(/\(/g, "");
	p1.value = p1.value.replace(/\)/g, "");
	

	p = "";
	p = p1.value;
	
	var new_number = "";
	new_number  = "(";
	new_number += p.substr(0,1);
	new_number += p.substr(1,1);
	new_number += p.substr(2,1);	
	if (p.length >= 3){ new_number += ") "};
	new_number += p.substr(3,1);
	new_number += p.substr(4,1);
	new_number += p.substr(5,1);
	if (p.length >= 6){ new_number += "-"};
	new_number += p.substr(6,1);
	new_number += p.substr(7,1);
	new_number += p.substr(8,1);
	new_number += p.substr(9,1);
	
	p1.value=new_number;
}

function lineBreakCount(str){ // return the number of line breaks in given String
    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

function checkThisString(txtArea, size){ // check the string if number of line breaks are more than entered paramater
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = $.trim(str);
    }
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
		alert("Please limit to a maximum of " + limitNum +" characters");
	}
}