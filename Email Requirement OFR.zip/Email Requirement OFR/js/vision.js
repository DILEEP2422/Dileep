var regexPhnNumber = /^[0-9 ()-]+$/

Form.FormSpecificReset = function() {
	$('.checkbox').click(function() {
      $('.checkbox').attr("checked", false);
      $(this).attr("checked", true);
   });
	document.getElementById('$SITE$').focus();
	resetReasonCheckboxes();
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

function ValidatePhone1(p){
var p;  //AANS - Move this into ValidatePhone Function
	p = "";
	p = p1.value;
	if(p.length == 3){
		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ")";
		}
	p1.value=""; p1.value=pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
			p1.value=""; p1.value=pp;

		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
			pp = "(" + p13 + ")" + p14 + p15;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 2 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
			p1.value=""; p1.value=pp;
		}

	}
}

function ValidatePhone(m){
	p1 = null;
	p1 = m;
	if(regexPhnNumber.test(p1.value)){
		ValidatePhone1(p1);
	}
}

function resetReasonCheckboxes()
{
	document.visionForm.$reason1$.value = "N";
	document.visionForm.$reason2$.value = "N";
	document.visionForm.$reason3$.value = "N";
	document.visionForm.$reason4$.value = "N";
	document.visionForm.$reason5$.value = "N";
	document.visionForm.$reason6$.value = "N";
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	resetReasonCheckboxes();
	testReasons(errorMsgArr);
	if($.trim(visionForm.$PHONE$.value).length > 0){
		visionForm.$PHONEHIDDEN$.value = "PHONE #: " + visionForm.$PHONE$.value + "\n";
	}
	
	if($.trim(visionForm.$DEALER$.value).length >0) {
		visionForm.$REMAININGHIDDEN$.value = "DEALER #: " + visionForm.$DEALER$.value + "\n";
	}

	if($.trim(visionForm.$BRANCH$.value).length >0) {
		visionForm.$REMAININGHIDDEN$.value += "BRANCH #: " + visionForm.$BRANCH$.value + "\n";
	}

	if($.trim(visionForm.$REPRESENTATIVE$.value).length >0) {
		visionForm.$REMAININGHIDDEN$.value += "REPRESENTATIVE #:" + visionForm.$REPRESENTATIVE$.value + "\n";
	}

    if($.trim(visionForm.$SAMPLEACCOUNT$.value).length >0) {
		visionForm.$REMAININGHIDDEN$.value += "SAMPLE ACCOUNT #" + visionForm.$SAMPLEACCOUNT$.value + "\n";
	}
}

Form.CreateSubject = function () {
	visionForm.subject.value = "VISION RESEARCH REQUEST - " + visionForm.$SITE$.value;
}

function testReasons(errorMsgArr) {
	var checked=false;

	if(document.visionForm.checkbox1.checked) {
		checked=true;
		document.visionForm.$reason1$.value = "Y";
	}
	
	if(document.visionForm.checkbox2.checked) {
		checked=true;
		document.visionForm.$reason2$.value = "Y";
	}
	if(document.visionForm.checkbox3.checked) {
		checked=true;
		document.visionForm.$reason3$.value = "Y";
	}
	
	if(document.visionForm.checkbox4.checked) {
		checked=true;
		document.visionForm.$reason4$.value = "Y";
	}
	
	if(document.visionForm.checkbox5.checked) {
		checked=true;
		document.visionForm.$reason5$.value = "Y";
	}
	
	if(document.visionForm.checkbox6.checked) {
		if($.trim(document.visionForm.$ADDITIONALCOMMENTS$.value).length == 0) {
			errorMsgArr[$("#ADDITIONALCOMMENTS").attr('tabindex')] = "\n  - If 'OTHER' is selected, then 'ADDITIONAL COMMENTS' is required";
		} else {
			checked=true;
			document.visionForm.$reason6$.value = "Y";
		}
	}
	
	document.visionForm.$ADDITIONALCOMMENTSHIDDEN$.value = "ADDITIONAL COMMENTS : \n"+ document.visionForm.$ADDITIONALCOMMENTS$.value;
	
	//first check that at least one reason is checked
	if (!checked) {
		errorMsgArr[$("#checkbox1").attr('tabindex')] = "\n - REASON FOR REFERRAL";
	}
}