function populatewebsitedd(dropdown) {
	
	var selection = dropdown.options[dropdown.selectedIndex].value;	
	if(selection=="Investor Website") {
		//Fetching User initials for subsequent form submits 
		userInitials();
		document.getElementById('advisordiv').style.display="none";
		document.getElementById('clientaccountsdiv').style.display="none";
		document.getElementById('dstvisiondiv').style.display="none";
		document.getElementById('otherwebsitediv').style.display="none";
		document.getElementById('onetimepasscodecheckboxdiv').style.display="block";
		document.getElementById('onetimepasscodediv').style.display="none";
		
		document.getElementById('repidsequence').value = "";
		document.getElementById('clientaccrepid').value = "";
		document.getElementById('clientaccvisionid').value = "";
		document.getElementById('dstvisionrepid').value = "";
		document.getElementById('dstvisionvisionid').value = "";
		document.getElementById('otherquickenturbohr').value = "";	
		document.getElementById('carrier').value = "";
		document.getElementById('deliver').value = "";	
		document.getElementsByName('$onetimepasscode$')[0].checked=false;
		
	} else if(selection=="Advisor Website") {
		//Fetching User initials for subsequent form submits 
		userInitials();
		document.getElementById('advisordiv').style.display="block";
		document.getElementById('clientaccountsdiv').style.display="none";
		document.getElementById('dstvisiondiv').style.display="none";
		document.getElementById('otherwebsitediv').style.display="none";
		document.getElementById('onetimepasscodecheckboxdiv').style.display="none";
		document.getElementById('onetimepasscodediv').style.display="none";

		document.getElementById('clientaccrepid').value = "";
		document.getElementById('clientaccvisionid').value = "";
		document.getElementById('dstvisionrepid').value = "";
		document.getElementById('dstvisionvisionid').value = "";
		document.getElementById('otherquickenturbohr').value = "";
		document.getElementById('carrier').value = "";
		document.getElementById('deliver').value = "";
		document.getElementsByName('$onetimepasscode$')[0].checked=false;
			
	} else if(selection=="Client Accounts") {
		//Fetching User initials for subsequent form submits 
		userInitials();
		document.getElementById('advisordiv').style.display="none";
		document.getElementById('clientaccountsdiv').style.display="block";
		document.getElementById('dstvisiondiv').style.display="none";
		document.getElementById('otherwebsitediv').style.display="none";
		document.getElementById('onetimepasscodecheckboxdiv').style.display="none";
		document.getElementById('onetimepasscodediv').style.display="none";

		document.getElementById('repidsequence').value = "";		
		document.getElementById('dstvisionrepid').value = "";
		document.getElementById('dstvisionvisionid').value = "";
		document.getElementById('otherquickenturbohr').value = "";
		document.getElementById('carrier').value = "";
		document.getElementById('deliver').value = "";
		document.getElementsByName('$onetimepasscode$')[0].checked=false;
		
	} else if(selection=="DST Vision") {
		//Fetching User initials for subsequent form submits 
		userInitials();
		document.getElementById('advisordiv').style.display="none";
		document.getElementById('clientaccountsdiv').style.display="none";
		document.getElementById('dstvisiondiv').style.display="block";
		document.getElementById('otherwebsitediv').style.display="none";
		document.getElementById('onetimepasscodecheckboxdiv').style.display="none";
		document.getElementById('onetimepasscodediv').style.display="none";

		document.getElementById('repidsequence').value = "";
		document.getElementById('clientaccrepid').value = "";
		document.getElementById('clientaccvisionid').value = "";		
		document.getElementById('otherquickenturbohr').value = "";
		document.getElementById('carrier').value = "";
		document.getElementById('deliver').value = "";	
		document.getElementsByName('$onetimepasscode$')[0].checked=false;		
		
	} else if(selection=="Other (e.g., Quicken, Turbo Tax, HR Block)") {
		//Fetching User initials for subsequent form submits 
		userInitials();
		document.getElementById('advisordiv').style.display="none";
		document.getElementById('clientaccountsdiv').style.display="none";
		document.getElementById('dstvisiondiv').style.display="none";
		document.getElementById('otherwebsitediv').style.display="block";
		document.getElementById('onetimepasscodecheckboxdiv').style.display="none";
		document.getElementById('onetimepasscodediv').style.display="none";
		
		document.getElementById('repidsequence').value = "";
		document.getElementById('clientaccrepid').value = "";
		document.getElementById('clientaccvisionid').value = "";
		document.getElementById('dstvisionrepid').value = "";
		document.getElementById('dstvisionvisionid').value = "";
		document.getElementById('carrier').value = "";
		document.getElementById('deliver').value = "";
		document.getElementsByName('$onetimepasscode$')[0].checked=false;
		
	} else if(selection=="SELECT") {
		//Fetching User initials for subsequent form submits 
		userInitials();
		document.getElementById('advisordiv').style.display="none";
		document.getElementById('clientaccountsdiv').style.display="none";
		document.getElementById('dstvisiondiv').style.display="none";
		document.getElementById('otherwebsitediv').style.display="none";
		document.getElementById('onetimepasscodecheckboxdiv').style.display="none";
		document.getElementById('onetimepasscodediv').style.display="none";
		
		document.getElementById('repidsequence').value = "";
		document.getElementById('clientaccrepid').value = "";
		document.getElementById('clientaccvisionid').value = "";
		document.getElementById('dstvisionrepid').value = "";
		document.getElementById('dstvisionvisionid').value = "";
		document.getElementById('otherquickenturbohr').value = "";
		document.getElementById('carrier').value = "";
		document.getElementById('deliver').value = "";
		document.getElementsByName('$onetimepasscode$')[0].checked=false;
	}
}

function onetimepasscodecheck(checkboxes){
	var checkboxes = document.getElementsByName('$onetimepasscode$');
	
	if(checkboxes[0].checked){
		document.getElementById("onetimepasscodediv").style.display='block';			
	}else{
		document.getElementById("onetimepasscodediv").style.display='none';
	}	
}

function userInitials(){
	SP.SOD.executeFunc('sp.js', 'SP.ClientContext', function(){		
        var clientContext = new SP.ClientContext.get_current();
        var tempcurrentUser = clientContext.get_web().get_currentUser();
        clientContext.load(tempcurrentUser); 
        clientContext.executeQueryAsync(function () {
        var index = tempcurrentUser.get_loginName().indexOf('|') + 1;
        var currentUser = tempcurrentUser.get_loginName().substring(index);		 
		wrcForm.$USERINITIALHIDDEN$.value = currentUser.substring(7).toUpperCase();		 
		});
	});	
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {

	if(wrcForm.$website$.value == "Investor Website"){
		
		if(wrcForm.$onetimepasscode$.checked){
		wrcForm.$ONETIMEPASSCODEHIDDEN$.value="<font color='blue' size='3'>One-time passcode error/issue: </font><font size='3'><span>YES</span></font><br/>";
		
		if($.trim(wrcForm.$carrier$.value).length != 0 ){
			wrcForm.$ONETIMEPASSCODEYESHIDDEN$.value = "<font color='blue' size='3'>Who is the carrier?: </font><font size='3'><span>"+ wrcForm.$carrier$.value + "</span></font><br/>";
		}
		if($.trim(wrcForm.$deliver$.value).length != 0){
			wrcForm.$ONETIMEPASSCODEYESHIDDEN$.value += "<font color='blue' size='3'>Where was it delivered to?: </font><font size='3'><span>"+ wrcForm.$deliver$.value + "</span></font><br/>";			
		}
	}else{
		wrcForm.$ONETIMEPASSCODEHIDDEN$.value="<font color='blue' size='3'>One-time passcode error/issue: </font><font size='3'><span>NO</span></font><br/>";;
	}
	}
	else{
		wrcForm.$ONETIMEPASSCODEHIDDEN$.value="";
		wrcForm.$ONETIMEPASSCODEYESHIDDEN$.value="";
	}
	
	if(wrcForm.$website$.value == "Advisor Website"){
		if($.trim(wrcForm.$repidsequence$.value).length == 0){
			errorMsgArr[$("#repidsequence").attr('tabindex')] = "- Rep ID or Sequence #\n"
		}else{
			wrcForm.$REPIDSEQUENCEADVISORHIDDEN$.value = "<font color='blue' size='3'>Rep ID or Sequence # : </font><font size='3'>&nbsp;<span>"+ wrcForm.$repidsequence$.value + "</span></font><br/>";			
		}
	}
	else{
		wrcForm.$REPIDSEQUENCEADVISORHIDDEN$.value="";
	}
	
	if(wrcForm.$website$.value == "Client Accounts"){
		if($.trim(wrcForm.$clientaccrepid$.value).length == 0){
			errorMsgArr[$("#clientaccrepid").attr('tabindex')] = "- Rep ID\n";
		}else{
			wrcForm.$CLIENTACCREPVISIONIDHIDDEN$.value = "<font color='blue' size='3'>Rep ID : </font><font size='3'><span>"+ wrcForm.$clientaccrepid$.value + "</span></font>";			
		}
		
		if($.trim(wrcForm.$clientaccvisionid$.value).length == 0){
			errorMsgArr[$("#clientaccvisionid").attr('tabindex')] = "- Vision ID\n";
		}else{
			wrcForm.$CLIENTACCREPVISIONIDHIDDEN$.value += "&nbsp;&nbsp;&nbsp;<font color='blue' size='3'>Vision ID : </font><font size='3'><span>"+ wrcForm.$clientaccvisionid$.value + "</span></font><br/>";			
		}		
	}
	else{
		wrcForm.$CLIENTACCREPVISIONIDHIDDEN$.value="";
	}
	
	if(wrcForm.$website$.value == "DST Vision"){
		if($.trim(wrcForm.$dstvisionrepid$.value).length == 0){
			errorMsgArr[$("#dstvisionrepid").attr('tabindex')] = "- Rep ID\n";
		}else{
			wrcForm.$DSTVISIONREPVISIONIDHIDDEN$.value = "<font color='blue' size='3'>Rep ID : </font><font size='3'><span>"+ wrcForm.$dstvisionrepid$.value + "</span></font>";			
		}
		
		if($.trim(wrcForm.$dstvisionvisionid$.value).length == 0){
			errorMsgArr[$("#dstvisionvisionid").attr('tabindex')] = "- Vision ID\n";
		}else{
			wrcForm.$DSTVISIONREPVISIONIDHIDDEN$.value += "&nbsp;&nbsp;&nbsp;<font color='blue' size='3'>Vision ID : </font><font size='3'><span>"+ wrcForm.$dstvisionvisionid$.value + "</span></font><br/>";			
		}		
	}
	else{
		wrcForm.$DSTVISIONREPVISIONIDHIDDEN$.value="";
	}	
	
	if(wrcForm.$website$.value == "Other (e.g., Quicken, Turbo Tax, HR Block)"){
		if($.trim(wrcForm.$otherquickenturbohr$.value).length == 0){
			errorMsgArr[$("#otherquickenturbohr").attr('tabindex')] = "- Other (e.g., Quicken, Turbo Tax, HR Block)\n";
		}else{
			wrcForm.$OTHERQUICKENTURBOHRHIDDEN$.value = "<font size='3'><span>"+ wrcForm.$otherquickenturbohr$.value + "</span></font><br/>";			
		}				
	}
	else{
		wrcForm.$OTHERQUICKENTURBOHRHIDDEN$.value="";
	}	
	
	if($.trim(wrcForm.$stepsadditionaldetails$.value).length != 0){
		wrcForm.$STEPSADDITIONALDETAILSHIDDEN$.value = "<font color='blue' size='3'>STEPS TAKEN/ADDITIONAL DETAILS: </font><font size='3'><span>"+ wrcForm.$stepsadditionaldetails$.value + "</span></font><br/>";			
	}
	else{
		wrcForm.$STEPSADDITIONALDETAILSHIDDEN$.value="";
	}
	
	if($.trim(wrcForm.$devicetypecaller$.value).length !=0){
		wrcForm.$DEVICETYPECALLERHIDDEN$.value = "<font color='blue' size='3'>What type of device is the caller using?: </font><font size='3'><span>"+ wrcForm.$devicetypecaller$.value + "</span></font><br/>";			
	}
	else{
		wrcForm.$DEVICETYPECALLERHIDDEN$.value ="";
	}
	
	if($.trim(wrcForm.$operatingsystemcaller$.value).length !=0){
		wrcForm.$OPERATINGSYSTEMCALLERHIDDEN$.value = "<font color='blue' size='3'>What operating system is the caller using?: </font><font size='3'><span>"+ wrcForm.$operatingsystemcaller$.value + "</span></font><br/>";			
	}
	else{
		wrcForm.$OPERATINGSYSTEMCALLERHIDDEN$.value="";
	}

	if($.trim(wrcForm.$browsercaller$.value).length !=0){
		wrcForm.$BROWSERCALLERVERSIONHIDDEN$.value = "<font color='blue' size='3'>What browser is the caller using?: </font><font size='3'><span>"+ wrcForm.$browsercaller$.value + "</span></font><br/>";			
		
		if($.trim(wrcForm.$browserversion$.value).length != 0){
			wrcForm.$BROWSERCALLERVERSIONHIDDEN$.value += "<font color='blue' size='3'>Browser version: </font><font size='3'><span>"+ wrcForm.$browserversion$.value + "</span></font><br/>";			
		}		
	}
	else{
		wrcForm.$BROWSERCALLERVERSIONHIDDEN$.value="";
	}
	
	if($.trim(wrcForm.$alternatebrowser$.value).length !=0){
		wrcForm.$ALTERNATEBROWSERHIDDEN$.value = "<font color='blue' size='3'>What alternate browser or alternate device were used?: </font><font size='3'><span>"+ wrcForm.$alternatebrowser$.value + "</span></font><br/>";			
		
		if($.trim(wrcForm.$alternatebrowserversion$.value).length != 0){
			wrcForm.$ALTERNATEBROWSERHIDDEN$.value += "<font color='blue' size='3'>Browser version: </font><font size='3'><span>"+ wrcForm.$alternatebrowserversion$.value + "</span></font><br/>";			
		}
	}
	else{
		wrcForm.$ALTERNATEBROWSERHIDDEN$.value="";
	}	
}

Form.CreateSubject = function () {	
 wrcForm.subject.value = "WRC: " + wrcForm.$ISSUEDATE$.value + " - " + wrcForm.$SITE$.value + " - " + wrcForm.$USERINITIALHIDDEN$.value + " - " + wrcForm.$website$.value;		
}

Form.FormSpecificReset = function () {
	document.getElementById('$SITE$').focus(); 
	
	document.getElementById('advisordiv').style.display="none";
	document.getElementById('clientaccountsdiv').style.display="none";
	document.getElementById('dstvisiondiv').style.display="none";
	document.getElementById('otherwebsitediv').style.display="none";
	document.getElementById('onetimepasscodediv').style.display="none";
	document.getElementById('onetimepasscodecheckboxdiv').style.display="none";
	
	document.getElementById('repidsequence').value = "";
	document.getElementById('clientaccrepid').value = "";
	document.getElementById('clientaccvisionid').value = "";
	document.getElementById('dstvisionrepid').value = "";
	document.getElementById('dstvisionvisionid').value = "";
	document.getElementById('otherquickenturbohr').value = "";	
	document.getElementById('carrier').value = "";
	document.getElementById('deliver').value = "";
	document.getElementsByName('$onetimepasscode$')[0].checked=false;
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

// return the number of line breaks in given String
function lineBreakCount(str){
    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 60
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = $.trim(str);
    }
}

function InternationalCallValidate(){
	document.getElementById('$PHONE$').value = "";		
}

function ValidatePhone(m){
	p1 = null;
	p1 = m;
	ValidatePhone1(p1);
}

function ValidatePhone1(p1){
	var p;
	p = "";
	p = p1.value;
	var intercall = document.getElementsByName('$internationalcall$');
	var intercallval = "";
	
	if(intercall[0].checked)
	{
		intercallval = intercall[0].value;		
	}
	
	if(intercallval.indexOf("International Call") == '-1')
	{
		document.getElementById('$PHONE$').maxLength = "13";
		if(p.length == 3){
		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ")";
		}
	p1.value=""; p1.value=pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
			p1.value=""; p1.value=pp;

		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
			pp = "(" + p13 + ")" + p14 + p15;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 2 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
			p1.value=""; p1.value=pp;
		}
	}
	}else
	{		
	document.getElementById('$PHONE$').maxLength = "32767";		
	}	
}