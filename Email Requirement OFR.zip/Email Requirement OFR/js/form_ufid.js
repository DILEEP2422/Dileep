Form.FormSpecificReset = function () {
	$("#ufidMismatchSection").css('display','none');
	$("#houseSection").css('display','none');
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	var ufidErrorType = $("#ufid").val();
	
	if(ufidErrorType == 'House Account') {
		if($.trim($("#dealer").val()) == "") {
			errorMsgArr[$("#dealer").attr('tabindex')] = "- Dealer #\n";
		}
		
		if($.trim($("#branch").val()) == "") {
			errorMsgArr[$("#branch").attr('tabindex')] = "- Branch #\n";
		}
		
		if($.trim($("#house").val()) == "") {
			errorMsgArr[$("#house").attr('tabindex')] = "- Rep Name\n";
		}
		
		if($.trim($("#phone").val()) == "") {
			errorMsgArr[$("#phone").attr('tabindex')] = "- Phone #\n";
		}
		
	} else if (ufidErrorType == "UFID Mismatch") {
		
		if($.trim($("#dealer2").val()) == "") {
			errorMsgArr[$("#dealer2").attr('tabindex')] = "- Dealer #\n";
		}
		
		if($.trim($("#branch2").val()) == "") {
			errorMsgArr[$("#branch2").attr('tabindex')] = "- Branch #\n";
		}
		
		if($.trim($("#repid").val()) == "") {
			errorMsgArr[$("#repid").attr('tabindex')] = "- Rep ID\n";
		}
		
		if($.trim($("#repname").val()) == "") {
			errorMsgArr[$("#repname").attr('tabindex')] = "- Rep Name (First,Last)\n";
		}
	
	}
	
}

function toggleSection() {
	var ufidErrorType = $("#ufid").val();
	
	if(ufidErrorType == "House Account") {
		$("#dealer2").val("");
		$("#branch2").val("");
		$("#repid").val("");
		$("#repname").val("");
		$("#fax2").val("");
		$("#dealer").val("");
		$("#branch").val("");
		$("#house").val("");
		$("#phone").val("");
		$("#fax").val("");
		$("#ufidMismatchSection").css('display','none');
		$("#houseSection").css('display','block');
	}
	else if (ufidErrorType == "UFID Mismatch") {
		$("#dealer2").val("");
		$("#branch2").val("");
		$("#repid").val("");
		$("#repname").val("");
		$("#fax2").val("");
		$("#dealer").val("");
		$("#branch").val("");
		$("#house").val("");
		$("#phone").val("");
		$("#fax").val("");
		$("#houseSection").css('display','none');
		$("#ufidMismatchSection").css('display','block');
	}
	
}

Form.CreateSubject = function () {
	form_ufid.subject.value = "UFID Issue - "+form_ufid.$planid$.value;	
}