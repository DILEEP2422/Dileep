function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
		alert("Please limit to a maximum of " + limitNum +" characters");
	}
}

function lineBreakCount(str){ // return the number of line breaks in given String
    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

function checkThisString(txtArea, size){ // check the string if number of line breaks are more than entered paramater
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = $.trim(str);
    }
}
	
function otherInputFldVisible(){
	if(document.getElementById("otherTest").checked==true){
		document.getElementById("OTHERDESCRIBE").style.display=""; 
		document.getElementById("otherRequired").style.display=""; 
	}else{
		document.getElementById("OTHERDESCRIBE").style.display="none"; 
		document.getElementById("otherRequired").style.display="none"; 
	}
}

function selectSubsection() {
	var referraltypeVal = RPSComplRefForm.$REFERRALTYPE$.value;
	document.getElementById("fraudIDTheft").style.display="none";
	document.getElementById("loanRequests").style.display="none";
	document.getElementById("planAuditOrYearEndTesting").style.display="none";
	document.getElementById("planElectionOrProvisionLineRequest").style.display="none";	
	document.getElementById("planElectionOrProvisionLineQuestion").style.display="none";
	
	if(referraltypeVal=="Fraud/ID Theft"){
		RPSComplRefForm.$RPSNotifiedDate$.value = "";
		RPSComplRefForm.$SCENARIODESCRIPTION$.value = "";
		RPSComplRefForm.$ACTIONTAKEN$.value = "";
		document.getElementById("fraudIDTheft").style.display="block";
	}else if(referraltypeVal=="Loan Default Reversal Request"){
		RPSComplRefForm.$SSN$.value = "";
		RPSComplRefForm.$LOANNUMBER$.value = "";
		RPSComplRefForm.$LoanOriginationDate$.value = "";
		RPSComplRefForm.$LoanMaturityDate$.value = "";
		RPSComplRefForm.$DateLoanDefaulted$.value = "";
		RPSComplRefForm.$CurePeriodEndDate$.value = "";
		// var absenceOptions = document.getElementsByName("$ABSENCE$");
		// for(i=0;i<absenceOptions.length;i++)
		// {
			// absenceOptions[i].checked = false;
		// }
		//document.getElementById("leaveOfAbsenceDate").style.display="none";	
		//RPSComplRefForm.$LeaveAbStartDate$.value = "";
		//RPSComplRefForm.$LeaveAbEndDate$.value = "";
		RPSComplRefForm.$NOTCURRENTLOAN$.value = "";
		RPSComplRefForm.$LOANCIRCUMSTANCES$.value = "";
		document.getElementById("loanRequests").style.display="block";
	}else if(referraltypeVal=="Testing"){
		var concernList = document.getElementsByName("$CONCERNTEST$");
		for(i=0;i<concernList.length;i++)
		{
			concernList[i].checked = false;
		}
		RPSComplRefForm.$OTHERDESCRIBE$.value = "";
		RPSComplRefForm.$PLANDESCOCCURRED$.value = "";
		RPSComplRefForm.$PLANSPONSORSTEPS$.value = "";
		RPSComplRefForm.$PLANADDITIONALQUE$.value = "";
		RPSComplRefForm.$PLANPROPOSESOLUTIONTESTING$.value = "";
		RPSComplRefForm.$PLANPROPOSEDQUES$.value = "";
		document.getElementById("planAuditOrYearEndTesting").style.display="block";
	}else if(referraltypeVal=="Describe Line Request"){
		RPSComplRefForm.$PLANELECTIONCURRENTPRO$.value = "";
		RPSComplRefForm.$PLANAPPEARDESCRIBELINE$.value = "";
		RPSComplRefForm.$PLANPURPOSEDESCRIBE$.value = "";
		RPSComplRefForm.$PLANDESCRIBELINEREAD$.value = "";
		document.getElementById("planElectionOrProvisionLineRequest").style.display="block";	
	}else if(referraltypeVal=="Plan Document Issue/Question"){
		RPSComplRefForm.$PLANDOCREQUESTIMPACT$.value = "";
		RPSComplRefForm.$PLANDESCWHATOCCURRED$.value = "";
		RPSComplRefForm.$PLANDESCSTEPSTOCORRECT$.value = "";
		RPSComplRefForm.$PLANSPONSORADDQUE$.value = "";
		RPSComplRefForm.$PLANPROPOSESOLUTION$.value = "";
		RPSComplRefForm.$PLANSPONSORADDQUEPROPOSAL$.value = "";
		document.getElementById("planElectionOrProvisionLineQuestion").style.display="block";	
	}
	
	
	//To show/Hide Description and Recommended Resolution Fields
	
	//When not to show Description field
	if(referraltypeVal=="Fraud/ID Theft" || referraltypeVal=="Loan Default Reversal Request" || referraltypeVal=="Testing" || referraltypeVal=="Describe Line Request" || referraltypeVal=="Plan Document Issue/Question"){
		document.getElementById("descriptionGroup").style.display="none";
	}else{
		document.getElementById("descriptionGroup").style.display="block";
	}
	
	//When not to show Recommended Resolution field
	
	if(referraltypeVal=="Testing" || referraltypeVal=="Describe Line Request" || referraltypeVal=="Plan Document Issue/Question"){
		document.getElementById("resolutionGroup").style.display="none";
	}else{
		document.getElementById("resolutionGroup").style.display="block";
	}
}

Form.CustomFields = function() {
	var referraltypeVal = RPSComplRefForm.$REFERRALTYPE$.value;
	if(referraltypeVal != "" && referraltypeVal=="Fraud/ID Theft"){
		RPSComplRefForm.$HIDDENEAILDETAILS$.value="\n\n"+
		"DATE RPS NOTIFIED : "+ RPSComplRefForm.$RPSNotifiedDate$.value+ "\n\n"+
		"SCENARIO DESCRIPTION : "+ RPSComplRefForm.$SCENARIODESCRIPTION$.value+ "\n\n"+
		"ACTION TAKEN : "+ RPSComplRefForm.$ACTIONTAKEN$.value+ "\n\n"+
		"RECOMMENDED RESOLUTION : "+ RPSComplRefForm.$RESOLUTION$.value+"\n";
		
	}else if(referraltypeVal != "" && referraltypeVal=="Loan Default Reversal Request"){
		var participantAbsence = document.getElementsByName('$ABSENCE$');
		var participantAbsence_val;
		for(var i = 0; i < participantAbsence.length; i++){
			if(participantAbsence[i].checked){
				participantAbsence_val = participantAbsence[i].value;
			}
		}
	
		var emailContent="";
		emailContent="<br/><br/>"+
		"SSN (LAST 4 DIGITS) : "+ RPSComplRefForm.$SSN$.value+ "\n\n"+
		"LOAN NUMBER : "+ RPSComplRefForm.$LOANNUMBER$.value+ "\n\n"+
		"LOAN ORIGINATION DATE : "+ RPSComplRefForm.$LoanOriginationDate$.value+ "\n\n"+
		"LOAN MATURITY DATE : "+ RPSComplRefForm.$LoanMaturityDate$.value+ "\n\n"+
		"DATE LOAN DEFAULTED (IF APPLICABLE) : "+ RPSComplRefForm.$DateLoanDefaulted$.value+ "\n\n"+
		"CURE PERIOD END DATE : "+ RPSComplRefForm.$CurePeriodEndDate$.value+ "\n\n"+
		"WAS THE PARTICIPANT ON LEAVE OF ABSENCE? : "+ participantAbsence_val+ "\n\n";
		if(participantAbsence_val=="YES"){
			emailContent = emailContent.concat("LEAVE OF ABSENCE DATES : "+ RPSComplRefForm.$LeaveAbStartDate$.value+" to "+RPSComplRefForm.$LeaveAbEndDate$.value+ "\n\n");
		}
		if($.trim(RPSComplRefForm.$NOTCURRENTLOAN$.value).length != 0){
			emailContent = emailContent.concat("IF LOAN IS NOT CURRENT, HOW WILL IT BE BROUGHT CURRENT ONCE THE RECORD IS CORRECTED? : "+ RPSComplRefForm.$NOTCURRENTLOAN$.value+ "\n\n");
		}
		emailContent = emailContent.concat("DESCRIBE THE CIRCUMSTANCES THAT LED TO THE NEED TO REVERSE DEFAULT : "+ RPSComplRefForm.$LOANCIRCUMSTANCES$.value+ "\n\n"+		
		"RECOMMENDED RESOLUTION : "+ RPSComplRefForm.$RESOLUTION$.value+"\n\n");
		
		RPSComplRefForm.$HIDDENEAILDETAILS$.value = emailContent;
			
	}else if(referraltypeVal != "" && (referraltypeVal == "Testing")){
		
		var checkedBoxes = [];
		
		$("input:checkbox[name='$CONCERNTEST$']:checked").each(function(){
			checkedBoxes.push($(this).val());
		});
		var emailContent="";
		
		emailContent="\n\n"+
		"WHICH TEST IS OF CONCERN? : "+ checkedBoxes+ "\n\n";
		if(checkedBoxes.toString().indexOf("Other")!=-1){
			emailContent = emailContent.concat("Other (Describe) : "+ RPSComplRefForm.$OTHERDESCRIBE$.value+ "\n\n");
		}
		
		emailContent = emailContent.concat("DESCRIBE WHAT OCCURRED : "+ RPSComplRefForm.$PLANDESCOCCURRED$.value+ "\n\n"+
		"WHAT STEPS HAS THE PLAN SPONSOR TAKEN TO CORRECT THE ISSUE? : "+ RPSComplRefForm.$PLANSPONSORSTEPS$.value+ "\n\n");
		
		if($.trim(RPSComplRefForm.$PLANADDITIONALQUE$.value).length != 0){
			emailContent = emailContent.concat("WHAT ADDITIONAL QUESTIONS OR CONCERNS DOES THE PLAN SPONSOR HAVE? : "+ RPSComplRefForm.$PLANADDITIONALQUE$.value+ "\n\n");
		}
		emailContent = emailContent.concat("WHAT DO YOU PROPOSE AS A SOLUTION? : "+ RPSComplRefForm.$PLANPROPOSESOLUTIONTESTING$.value+ "\n\n");
		if($.trim(RPSComplRefForm.$PLANPROPOSEDQUES$.value).length != 0){
			emailContent = emailContent.concat("WHAT QUESTIONS DO YOU HAVE REGARDING YOUR PROPOSED SOLUTION? : "+ RPSComplRefForm.$PLANPROPOSEDQUES$.value);
		}
		
        RPSComplRefForm.$HIDDENEAILDETAILS$.value = emailContent;
	}else if(referraltypeVal != "" && referraltypeVal == "Describe Line Request"){
	
		RPSComplRefForm.$HIDDENEAILDETAILS$.value="\n\n"+
		"WHAT IS THE CURRENT PROVISION? : "+ RPSComplRefForm.$PLANELECTIONCURRENTPRO$.value+ "\n\n"+
		"WHERE WILL THE DESCRIBE LINE APPEAR? : "+ RPSComplRefForm.$PLANAPPEARDESCRIBELINE$.value+ "\n\n"+
		"WHAT IS THE PURPOSE OF USING \"DESCRIBE\"? : "+ RPSComplRefForm.$PLANPURPOSEDESCRIBE$.value+ "\n\n"+
		"HOW WILL THE PROPOSED \"DESCRIBE\" LINE READ? : "+ RPSComplRefForm.$PLANDESCRIBELINEREAD$.value+"\n\n";
		
	} else if(referraltypeVal != "" && referraltypeVal == "Plan Document Issue/Question"){
		var emailContent="";	
		emailContent="\n\n"+
		"WHAT SECTION(S) OF THE DOCUMENT DOES THIS REQUEST IMPACT? : "+ RPSComplRefForm.$PLANDOCREQUESTIMPACT$.value+ "\n\n"+
		"DESCRIBE WHAT OCCURRED : "+ RPSComplRefForm.$PLANDESCWHATOCCURRED$.value+ "\n\n";
		if($.trim(RPSComplRefForm.$PLANDESCSTEPSTOCORRECT$.value).length != 0){
			emailContent = emailContent.concat("DESCRIBE WHAT STEPS THE PLAN SPONSOR HAS TAKEN TO CORRECT, IF APPLICABLE. : "+ RPSComplRefForm.$PLANDESCSTEPSTOCORRECT$.value+ "\n\n");
		}
		if($.trim(RPSComplRefForm.$PLANSPONSORADDQUE$.value).length != 0){
			emailContent = emailContent.concat("WHAT ADDITIONAL QUESTIONS/CONCERNS DOES THE PLAN SPONSOR HAVE? : "+ RPSComplRefForm.$PLANSPONSORADDQUE$.value+ "\n\n");
		}
		emailContent = emailContent.concat("WHAT DO YOU PROPOSE AS A SOLUTION? : "+ RPSComplRefForm.$PLANPROPOSESOLUTION$.value+ "\n\n");
		if($.trim(RPSComplRefForm.$PLANSPONSORADDQUE$.value).length != 0){
			emailContent = emailContent.concat("WHAT QUESTIONS DO YOU HAVE REGARDING YOUR PROPOSAL ? : "+ RPSComplRefForm.$PLANSPONSORADDQUEPROPOSAL$.value+"\n\n");
		}
		
		RPSComplRefForm.$HIDDENEAILDETAILS$.value = emailContent;	
	}else{
		RPSComplRefForm.$HIDDENEAILDETAILS$.value="\n\n"+
		"DESCRIPTION : "+ RPSComplRefForm.$DESCRIPTION$.value+ "\n\n"+
		"RECOMMENDED RESOLUTION : "+ RPSComplRefForm.$RESOLUTION$.value+ "\n\n";
	}
}

Form.CreateSubject = function () {
	RPSComplRefForm.subject.value = $("input[name='$REFFURGENCY$']:checked").val() +" - "+RPSComplRefForm.$SITE$.value+" - "+RPSComplRefForm.$REFERRALTYPE$.value+" - "+"RPS Compliance Referral Form";
}

Form.CustomLoad = function () {
	$('#otherTest').on('change', otherInputFldVisible);
}