var optionsToKeep = 0;

Form.CustomLoad = function () {
	$("#approver").keyup(function() {
		$("#approvalReasonGroup").toggle($(this).val() ? true : false);
	});
	$("#addAccount").click(function(){addNewAccount();});
	$("#addAccount").keypress(function(){addNewAccount();});

	$(".addFund").click(function(){addLineItems(this);});
	$(".addFund").keypress(function(){addLineItems(this);});

	//$(".ancientDropdown").change(function(){showDifferentDiv(this);});
	//$(".dropdownSecond").change(function(){showAllFundSection(this);});
	$(".timeFrameQuestNoAllFundNo").change(function(){showFromTo(this);});
	SetYears();
	$("#rushRequest, #transferredAccounts").change(function () {
		var priorTranscriptSelects = $("#transcriptAccounts select.ancientDropdown");
		if ($(this).prop("checked")) {
			var pre1990 = priorTranscriptSelects.filter(function () { return $(this).val() == "Yes"; });
			pre1990.val("No");
			pre1990.trigger("change");
			priorTranscriptSelects.find("option[value='Yes']").attr('disabled', 'disabled');
		} else {
			priorTranscriptSelects.find("option[value='Yes']").removeAttr('disabled');
		}
	});
	$("#transcriptAccounts").on("change", "div.account select.timeframe", function () {
		var ele = $(this);
		var selection = ele.val();
		var acctDetails = $(this).parents(".accountDetails");
		$(".yearLabel").toggleClass("required", false);
		
		if (selection == "Years Selected") {
			acctDetails.find("select.fromYear").removeAttr('disabled');
			acctDetails.find("select.toYear").removeAttr('disabled');
			$(".yearLabel").toggleClass("required", true);
		} else {
			acctDetails.find("select.fromYear").prop("selectedIndex",0);
			acctDetails.find("select.toYear").prop("selectedIndex",0);
			acctDetails.find("select.fromYear").attr("disabled","disabled");
			acctDetails.find("select.toYear").attr("disabled","disabled");
		}
	});
	$("#transcriptAccounts").on("change", ".ancientDropdown, .allFunds", function () {
		var ele = $(this);
		var template = "";
		var account = $(this).parents(".account");
		account.data("lineItemType", "");
		var lines = $(this).parents(".account").find(".accountTranscriptLines");
		var header = lines.find(".header");
		var table = lines.find(".transcriptAccountTable");
		lines.hide();
		header.empty();
		table.empty();
		if (ele.hasClass("ancientDropdown")) {
			if (ele.val() == "Yes") {
				template = "ancient";
				account.find(".allFundsSelectGroup").hide();
				lines.show();
			} else if (ele.val() == "No") {
				account.find(".allFundsSelectGroup").show();
				lines.hide();
			} else {
				account.find(".allFundsSelectGroup").hide();
				lines.hide();
			}
		} else {
			if (ele.val() == "Yes") {
				template = "allFunds";
				lines.show();
			} else if (ele.val() == "No") {
				template = "normal";
				lines.show();
			} else {
				lines.hide();
			}
		}
		if (template) {
			account.data("lineItemType", template);
			var templateEle = $("#lineItemTemplates ." + template);
			account.find(".newFund")
			header.append($("#lineItemTemplates ." + template + " .header").clone());
			table.append($("#lineItemTemplates ." + template + " .lineItem").clone());
			lines.find("button").toggle(templateEle.data("add") != false);
		}
	});
	$(".overnightDeliveryCheck").change(function(){
		var closestOvernightOptions = $(this).closest("div.mailDeliveryDetails").find("div.overnightDeliveryOptions");
		$(closestOvernightOptions).slideToggle(500);
	});

	$(".deleteFund").click(function() {
		var acct = $(this).closest(".accountTranscriptLines");
		var acctfundno = $(this).closest(".accountTranscriptLinesQuestNoAllFundNo");
		var dpQuestLocal = $(this).parent().parent().parent().parent().parent().parent().find("select.ancientDropdown").val();
		var dpSecondQuestLocal = $(this).parent().parent().parent().parent().parent().parent().find("select.dropdownSecond").val();
		
		if(dpQuestLocal == "Yes") {
			$(this).parent().parent().parent().remove();
			reindexRows(acct);
		}
		if(dpQuestLocal == "No" && dpSecondQuestLocal == "No") {
			$(this).parent().parent().parent().remove();
			reindexRowsFundNo(acctfundno);
		}	
	});

	$("#deleteAccount").click(function(){$(this).parent().parent().parent().parent().parent().remove();reindexAccounts();});

	$(".accountNumber").blur(function() {
		var acNum = $(this).val();
		var acHeadNum = $(this).closest("div.account").find("span.accountHeaderNumber");
		if ($.trim(acNum).length == 0)
			$(acHeadNum).html(" ");
		else
			$(acHeadNum).html(acNum);
	});

	$("input.mail").click(function() {
		var closestFieldset =  $(this).closest("fieldset");
		$(closestFieldset).toggleClass("open","closed");
	});

	$("input.fax").click(function() {
		var closestFieldset =  $(this).closest("fieldset");
		$(closestFieldset).toggleClass("open","closed");
	});
}

function SetYears() {
	var curYear = new Date().getFullYear();
	var years = [];
	years.push("UNAVAILABLE");
	for (var i = curYear; i >= 1940; i--) {
		years.push(i);
	}
	var ancientFunds = $("#lineItemTemplates > div.ancient select.years");
	var normalFundsSet = $("#lineItemTemplates > div:not(.ancient) select.years");
	
	years.forEach(function (e, i, a) {
		var opt = $("<option />", {"value": e});
		opt.html(e);
		if (years >= 1990)
			normalFundsSet.append(opt.clone());
		ancientFunds.append(opt.clone());
	});
}

Form.FormSpecificReset = function () {
	document.getElementById('site').focus(); 
	$("#recipientSection fieldset").removeClass("open");
	$(".mailDetails").empty();
	$(".faxDetails").empty();
	
	includeTransferred = false;
	requestType="davast";

	$("#transcriptAccounts").empty();
	//$("#transcriptAccounts").append($("#accountTemplate .account").clone(true)); 
	addNewAccount();
	//$("#transcriptAccounts .account #transcriptAccountTableQuestNoAllFundYes:first").append($("#transcriptAccountLineTemplateQuestNoAllFundYes .transcriptAccountLineTemplateQuestNoAllFundYesSection").clone(true));
	
	$(".mailDetails").append($("#deliveryDetailsTemplates .mailDeliveryDetails").clone(true)); 
	$(".faxDetails").append($("#deliveryDetailsTemplates .faxDeliveryDetails").clone(true)); 
	
	$(".collapse").collapse('hide');
	
	$(".prior1990Msg").hide(0);
	$(".initInvCheck").show(0);

	
	$("#rushRequest, #transferredAccounts").removeAttr("disabled");
	$("#rushLabel, #labelTransferredAccounts").css("color", "#03f");

	$(".recipientDeliveryMethod").hide(0);
	
	$(".mailDetails input[type='radio']").each(function(index, obj)  {
		var old_name = $(this).attr("name");
		var new_name = old_name+index;
		$(this).attr("name", new_name);
	});
}

Form.CustomFields = function () {
	var accountDetails = "ACCOUNT DETAILS:"
	var ind = 0;
	
	$("#transcriptAccounts .account").each(function(index) {
		var accountErrorLines = "";
		var acctIndex = index + 1;
		var acctNumber = $.trim($(this).find("input.accountNumber").val());
		var acctAlphaCode = $.trim($(this).find("input.alphaCode").val());
		var acctReg = $.trim($(this).find("textarea.accountRegistration").val());
		var fundHeader = "";
			
		var quest = $.trim($(this).find("select.ancientDropdown").val());
		var allfund = $.trim($(this).find("select.dropdownSecond").val());
		
		if(quest != '') {
			accQuest[ind] = quest;
			ind++;
		}
		accountDetails += "\n_______________________________________________________________";
		accountDetails += "\nACCOUNT: " + acctNumber;
		accountDetails += "\nVIEWABLE IN SHARE: ";
		if ($(this).find("input.acctInSHARE").is(":checked")) 
			accountDetails += "Y";
		else
			accountDetails += "N";
		accountDetails += "\nALPHACODE: " + acctAlphaCode;
		accountDetails += "\nACCOUNT REGISTRATION:\n" + acctReg;
		accountDetails += "\nAre you requesting transcripts prior to 1990? " + quest;
		
		if(quest == "No") {
			accountDetails += "\n \nALL FUNDS: " + allfund;
		}
	});
	form.$accountdetails$.value = accountDetails;
}


function changeMailLabelName(obj) {
	$(obj).parent().parent().parent().parent().find(".mailDetails").find("#companyName").text("*FIRM NAME");
}

function changeFaxLabelName(obj){
	$(obj).parent().parent().parent().parent().find(".faxDetails").find("#companyName").text("*FIRM NAME");
}

function removeTranscriptYears() {
	var keepProcessing = true;
	
	$("select.fromYear:first").each(function(){
		if (this.options[this.length-1].value == 1990) {
			keepProcessing = false;
		}
	});
	
	if (keepProcessing == false) {
		return false;	
	}

	$("select.fromYear").each(function() {
		var selectLength= this.length;
		this.remove(1);
		for (var i=optionsToKeep; i<selectLength; i++){
			this.remove(optionsToKeep-1);
		};
	});
	
	$("select.toYear").each(function() {
		var selectLength= this.length;
		for (var i=optionsToKeep; i<selectLength; i++){
			this.remove(optionsToKeep);
		};
	});
};

function addTranscriptYears() {
	var keepProcessing = true;

	$("select.fromYear:first").each(function(){
		if (this.options[this.length-1].value == 1940){
			keepProcessing = false;
		}	
	});

	if (keepProcessing == false) {
		return false;	
	}

	$("select.fromYear").each(function(){
		var val = this.value;
		var i=2;
		var y=thisYear-1;
		while(y>startYear-1){
			this.options[i] = new Option(y, y);
			y--;
			i++;
		}
		this.value = val;
	});
	
	$("select.toYear").each(function(){
		var i=optionsToKeep;
		var y=1989;
		while(y>startYear-1){
			this.options[i] = new Option(y, y);
			y--;
			i++;
		}
	});
};

$("select.fromYear").change(function() {
	var tempRT = requestType;
	determineRequestType();
	
	if (tempRT != requestType) {
		if (requestType == "transcript") {
			$("#rushRequest, #transferredAccounts").attr("disabled", "disabled");
			$("#rushLabel, #labelTransferredAccounts").css("color", "#ccc");
		}
		else {
			$("#rushRequest, #transferredAccounts").removeAttr("disabled");
			$("#rushLabel, #labelTransferredAccounts").css("color", "#03f");
		}
	}
});

function determineRequestType() {
	var flagactype = false;
	for(var j=0;j<accQuest.length;j++) {
		if(accQuest[j] == "Yes"){
			flagactype = true;
			break;
		}
		else if(accQuest[j] == "No") {
			flagactype = false;
			continue;
		}
	}
	if(flagactype) {
		requestType="transcript";  // request type for mail to Admin 
	}
	else{
		requestType="davast";  // request type for mail to BSA 
	}
}


function addNewAccount() {
	$("#transcriptAccounts").append($("#accountTemplate .account").clone(true));
	$("#transcriptAccounts .account:last").find("input.accountNumber").focus();
	$("#transcriptAccounts .account:last #transcriptAccountTableQuestNoAllFundYes").append($("#transcriptAccountLineTemplateQuestNoAllFundYes .transcriptAccountLineTemplateQuestNoAllFundYesSection").clone(true));
	reindexAccounts();
	reindexRows($("#transcriptAccounts").find("div.accountTranscriptLines:last"));
	reindexRowsFundNo($("#transcriptAccounts").find("div.accountTranscriptLinesQuestNoAllFundNo:last"));
}

function reindexAccounts() {
	$("#transcriptAccounts .account").each(function (i) {
		var index = i + 1;
		$(this).data('label', 'Account ' + index)
		$(this).find('.accountIndex').html(index + ":&nbsp;");
		$(this).find('label[data-for]').each(function () {
			$(this).attr('for', $(this).data('for') + index);
		});
		$(this).find('[data-id]').each(function () {
			$(this).attr('id', $(this).data('id') + index);
		});
	});
	if ($("#transcriptAccounts .account").length == 1) 
		$("#deleteAccount").hide();
	else 
		$("#deleteAccount").show();

	if ($("#transcriptAccounts .account").length == 10) 
		$("#addAccount").hide();
	else
		$("#addAccount").show();
}

function addLineItems(addFundButton) {
	var acct = $(addFundButton).closest("div.accountTranscriptLines");
	var dpQuestLocal = $(addFundButton).parent().parent().find("select.ancientDropdown").val();
	var dpSecondQuestLocal = $(addFundButton).parent().parent().find("select.dropdownSecond").val();
	var lastLine = $(acct).find("#transcriptAccountTable .transcriptAccountLineTemplateSection:last");

	var acctallfundyes = $(addFundButton).closest("div.accountTranscriptLinesQuestNoAllFundYes");
	var lastLinefundyes = $(acctallfundyes).find("#transcriptAccountTableQuestNoAllFundYes .transcriptAccountLineTemplateQuestNoAllFundYesSection:last");	

	var acctallfundno = $(addFundButton).closest("div.accountTranscriptLinesQuestNoAllFundNo");
	var lastLinefundno = $(acctallfundno).find("#transcriptAccountTableQuestNoAllFundNo .transcriptAccountLineTemplateQuestNoAllFundNoSection:last");
		
	if(dpQuestLocal == "Yes") {
		$("#transcriptAccountLineTemplate .transcriptAccountLineTemplateSection").clone(true).insertAfter(lastLine); 
		reindexRows(acct);
		$(addFundButton).closest("div.accountTranscriptLines").find("#transcriptAccountTable .transcriptAccountLineTemplateSection:last input.fundNumber").focus();
	}
	
	if((dpQuestLocal == "No") && (dpSecondQuestLocal == "Yes")) {
		$("#transcriptAccountLineTemplateQuestNoAllFundYes .transcriptAccountLineTemplateQuestNoAllFundYesSection").clone(true).insertAfter(lastLinefundyes); 
		$(addFundButton).closest("div.accountTranscriptLinesQuestNoAllFundYes").find("#transcriptAccountTableQuestNoAllFundYes .transcriptAccountLineTemplateQuestNoAllFundYesSection:last select.timeFrame").focus();
	} else if((dpQuestLocal == "No") && (dpSecondQuestLocal == "No")) {
		$("#transcriptAccountLineTemplateQuestNoAllFundNo .transcriptAccountLineTemplateQuestNoAllFundNoSection").clone(true).insertAfter(lastLinefundno); 
		reindexRowsFundNo(acctallfundno);
		$(addFundButton).closest("div.accountTranscriptLinesQuestNoAllFundNo").find("#transcriptAccountTableQuestNoAllFundNo .transcriptAccountLineTemplateQuestNoAllFundNoSection:last input.fundNumber").focus();
	}
}

function showDifferentDiv(dropdownFirst) {
	var acct = $(dropdownFirst).closest("div.account");
	var value = $(dropdownFirst).val();
	var dpQuest = value;
	
	var dropDownSecond = $(acct).find("select.dropdownSecond");
	$(dropDownSecond).prop("selectedIndex",0);
	
	if (value == "Yes") {	
		$(acct).find("div.divTwo").hide();
		$(acct).find("div.accountTranscriptLines").show();	
			
		$(acct).find("div.accountTranscriptLinesQuestNoAllFundNo").hide();		
		$(acct).find("div.accountTranscriptLinesQuestNoAllFundYes").hide();	
		
		$(acct).find("#transcriptAccountTable:first").append($("#transcriptAccountLineTemplate .transcriptAccountLineTemplateSection").clone(true)); 
		reindexRows($("#transcriptAccounts").find("div.accountTranscriptLines:last"));
		$(acct).find(".transcriptAccountTableQuestNoAllFundNo").empty();
	} else if(value == "No") {
		$(acct).find("div.divTwo").show();
		$(acct).find("div.accountTranscriptLines").hide();	
		$(acct).find("#transcriptAccountTable").empty();
	} else if(value == "" || allfundyn == "") {
		$(acct).find("div.divTwo").hide();
		$(acct).find("div.accountTranscriptLines").hide();	
		$(acct).find("div.accountTranscriptLinesQuestNoAllFundYes").hide();	
		$(acct).find("div.accountTranscriptLinesQuestNoAllFundNo").hide();
		$(acct).find("#transcriptAccountTable").empty();
	}
}

function showAllFundSection(dropdownSecond) {
	var acct = $(dropdownSecond).closest("div.account");
	var value1 = $(dropdownSecond).val();
	var dpSecond = value1;
	var tfReset = $(acct).find("select.timeFrame");
	$(tfReset).prop("selectedIndex",0);
	
	if(value1 == "Yes") {
		$(acct).find("div.accountTranscriptLines").hide();
		$(acct).find("div.allFundsGroup").show();
		$(acct).find(".transcriptAccountTable").empty();
	} else if(value1 == "No") {
		addNormalFund(acct);
		$(acct).find("div.accountTranscriptLines").show();
		$(acct).find("div.allFundsGroup").hide();
	} else if(value1 == "") {
		$(acct).find("div.accountTranscriptLines").hide();
		$(acct).find("div.allFundsGroup").hide();
		$(acct).find(".transcriptAccountTable").empty();
	}
}

function addNormalFund(acctElement) {
	$(acctElement).find(".transcriptAccountTable").append($("#lineItemTemplates div.normalFund").clone());
}

function showFromTo(selectedTimeFrame) {
	var div1 = $(selectedTimeFrame).parent().parent().parent().parent();
	var fundTimeFrame = $(div1).find("select.timeFrameQuestNoAllFundNo").val();
	
	if(fundTimeFrame == "Years Selected") {
		$(div1).find("select.fromYear").removeAttr("disabled");
		$(div1).find("select.toYear").removeAttr("disabled");
	} else if(fundTimeFrame == "Init Inv Only" || fundTimeFrame == "All Years" || fundTimeFrame == "") {
		$(div1).find("select.fromYear").prop("selectedIndex",0);
		$(div1).find("select.toYear").prop("selectedIndex",0);
		$(div1).find("select.fromYear").attr("disabled","disabled");
		$(div1).find("select.toYear").attr("disabled","disabled");
	}
}

function reindexRows(acct) {
	var fundIndexes = $(acct).find("#transcriptAccountTable span.fundIndex");
	var numLines = $(acct).find("#transcriptAccountTable .transcriptAccountLineTemplateSection").length;

	$(fundIndexes).each(function(index) {
		$(this).html(index+1);

	});
	
	if (numLines == 1) 
		$(acct).find(".deleteFund").hide();
	else 
		$(acct).find(".deleteFund").show();

	if (numLines == 20) 
		$(acct).find(".addFund").hide();
	else 
		$(acct).find(".addFund").show();
}

function reindexRowsFundNo(acctallfundno) {
	var fundIndexesN = $(acctallfundno).find("#transcriptAccountTableQuestNoAllFundNo span.fundIndex1");
	var numLinesN = $(acctallfundno).find("#transcriptAccountTableQuestNoAllFundNo .transcriptAccountLineTemplateQuestNoAllFundNoSection").length;
	
	$(fundIndexesN).each(function(index2) {
		$(this).html(index2+1);
	});
	
	if (numLinesN == 1) {
		$(acctallfundno).find(".deleteFund").hide();
	} else {
		$(acctallfundno).find(".deleteFund").show();
	}

	if (numLinesN == 20) {
		$(acctallfundno).find(".addFund").hide();
	} else {
		$(acctallfundno).find(".addFund").show();	
	}
}


function returnUniqueAccountNumbers() {
	var accountNumbers = new Array();

	$("#transcriptAccounts input.accountNumber").each(function () {
		if (this.value != "") {
			accountNumbers.push((this).value);
		}
	});
	
	var uniqueAccountNumbers = new Array();
	var numberOfAccounts = accountNumbers.length;
	
	for (var i=0; i<numberOfAccounts; i++) {
		for(var j=i+1; j<numberOfAccounts; j++) {
			if (accountNumbers[i] === accountNumbers[j]) {
				j = ++i;
			}
		}
		uniqueAccountNumbers.push(accountNumbers[i]);
	}
	
	uniqueAccountNumbers = uniqueAccountNumbers.sort(function (a, b) {
		return a-b;
	});
	return uniqueAccountNumbers.join(", ");
}

var lineItemErrors = "";

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	var alertMsg = "Please correct or complete the required field(s) below:\n";
	var error = false;

	var topSectionErrors = "";
	lineItemErrors = "";
	
	if($.trim($("#\\#APPROVER\\#").val()).length != 0) {
		if($.trim(transForm.$APPROVALREASON$.value).length == 0) {
			errorMsgArr[$("#\\$APPROVALREASON\\$").attr('tabindex')] = "- Approval Reason\n";
		}
	}
	lineItemErrors = "";
	// testAccounts(transForm);
	// testRecipients(transForm);
	
	// if($.trim(lineItemErrors) != "") {
		// errorMsgArr[$(".accountNumber:first").attr('tabindex')] = lineItemErrors;
	// }
}

Form.CreateSubject = function () {
	determineRequestType();
	determineEmailRecepient();
	
	if (requestType=="davast") {
		transForm.subject.value = "DAVAST/TRANSCRIPT REPORT REQUEST" ;
		transForm.subject.value = "Davast or Transcript Report Request - " + transForm.$SITE$.value + " - ";
		
		if(document.transForm.rushRequest.checked) {
			transForm.subject.value += "RUSH - ";
			transForm.$rush$.value += "\nRUSH REQUEST: Y";
		} else {
			transForm.$rush$.value += "\nRUSH REQUEST: N";
		}
		
		if(document.transForm.transferredAccounts.checked) {
			transForm.subject.value += "TRANSFERRED - ";
			transForm.$rush$.value += "\nINCLUDE ALL TRANSFERRED ACCOUNTS AND FUNDS: Y\n";
		} else {
			transForm.$rush$.value += "\nINCLUDE ALL TRANSFERRED ACCOUNTS AND FUNDS: N\n";
		}
		
		transForm.subject.value += returnUniqueAccountNumbers();  
		transForm.$requesttype$.value="DAVAST/TRANSCRIPT REPORT REQUEST:";
	}
	else if (requestType=="transcript") {
		transForm.subject.value = "Transcript Request - " + transForm.$SITE$.value + " - " + returnUniqueAccountNumbers();
		transForm.$requesttype$.value="TRANSCRIPT REPORT REQUEST:";  
	}
}

var accQuest = new Array();
function determineEmailRecepient() {
	var flagactype = false;
		
	for(var j=0;j<accQuest.length;j++) {
		if(accQuest[j] == "Yes") {
			flagactype = true;
			break;
		} else if(accQuest[j] == "No") {
			flagactype = false;
			continue;
		}
	}
	
	if(flagactype) {
		transForm.Qualifier.value = "ADMIN";
	} else {
		transForm.Qualifier.value = "BSA";
	}
}

function testAccounts(form) {
	var accountDetails = "ACCOUNT DETAILS:"
	var ind = 0;
	
	$("#transcriptAccounts .account").each(function(index) {
		var accountErrorLines = "";
		var acctIndex = index + 1;
		var fundHeader = "";
			
		var quest = $.trim($(this).find("select.ancientDropdown").val());
		var allfund = $.trim($(this).find("select.dropdownSecond").val());
		
		if(quest != '') {
			accQuest[ind] = quest;
			ind++;
		}
			
		
		if(quest == "No" && allfund.length == 0) {
			accountErrorLines+= "\n- ALL FUNDS";	
		} else if(quest == "No") {
			accountDetails += "\n \nALL FUNDS: " + allfund;
		}
		
		var acctFundLines = $(this).find("#transcriptAccountTable .transcriptAccountLineTemplateSection");
		var acctAllFundLinesNo = $(this).find("#transcriptAccountTableQuestNoAllFundNo .transcriptAccountLineTemplateQuestNoAllFundNoSection");
		var acctAllFundLinesYes = $(this).find("#transcriptAccountTableQuestNoAllFundYes .transcriptAccountLineTemplateQuestNoAllFundYesSection");
		var oneLineMinimum = false;
			
		if(quest == "Yes") {
			fundHeader = "\n\nFUND:      Int Inv Only:        FROM:           TO:	 \n";
			accountDetails = accountDetails + fundHeader;
						
			$(acctFundLines).each(function(index) {
				var fundIndex = index + 1;
				var fundNumber = $.trim($(this).find("input.fundNumber").val());
				var fundintInv = "";
				if($(this).find("input.invCheckbox").is(":checked")) fundintInv = "Y";
				else fundintInv = "N";
				
				var fundFromYear = $(this).find("select.fromYear").val();
				var fundToYear = $(this).find("select.toYear").val();

				if(fundintInv == "N") {
					if (fundNumber.length != 0 || fundFromYear.length != 0 || fundToYear.length != 0) {
						if (fundNumber.length > 0 && fundFromYear.length > 0 && fundToYear.length > 0) {
							if (fundFromYear != "UNAVAILABLE" || fundToYear != thisYear) {
								if (parseInt(fundFromYear) > parseInt(fundToYear)) {
									accountErrorLines += "\n- Line # " + fundIndex + ": 'From' year cannot be greater than 'To' Year";
								}
							}
							accountDetails += padSpacesToRight(fundNumber, 7);
							accountDetails += padSpacesToLeft(fundintInv, 15);
							accountDetails += padSpacesToLeft(fundFromYear, 30);
							accountDetails += padSpacesToLeft(fundToYear, 17);

							accountDetails += "\n";					
							oneLineMinimum = true;
						} else {
							accountErrorLines += "\n- Line # " + fundIndex + " is incomplete";
						}
					}
				} else if(fundintInv == "Y") {
					if (fundNumber.length > 0) {
						accountDetails += padSpacesToRight(fundNumber, 7);
						accountDetails += padSpacesToLeft(fundintInv, 15);
						
						accountDetails += "\n";					
						oneLineMinimum = true;
					} else {
						accountErrorLines += "\n- Line # " + fundIndex + " is incomplete";
					}
				}
			});
		}
		
		if(quest == "No" && allfund =="No") {
			fundHeader = "\n\nFUND:         TIMEFRAME:            FROM:            TO:	    \n";
			accountDetails = accountDetails + fundHeader;
			
			$(acctAllFundLinesNo).each(function(index) {
				var fundIndex = index + 1;
				var fundNumber = $.trim($(this).find("input.fundNumber").val());
				var fundTimeFrame = $(this).find("select.timeFrameQuestNoAllFundNo").val();
				var fundFromYear = $(this).find("select.fromYear").val();
				var fundToYear = $(this).find("select.toYear").val();
				
				if(fundTimeFrame == "Years Selected") {
					if(fundNumber.length != 0 || fundTimeFrame.length != 0 || fundFromYear.length != 0 || fundToYear.length != 0 || fundYearSelected.length != 0) {
						if (fundNumber.length > 0 && fundFromYear.length > 0 && fundToYear.length > 0 && fundTimeFrame.length > 0) {
							if (fundToYear != thisYear) {
								if (parseInt(fundFromYear) > parseInt(fundToYear)) {
									accountErrorLines += "\n- Line # " + fundIndex + ": 'From' year cannot be greater than 'To' Year";
								}
							}
							accountDetails += padSpacesToRight(fundNumber, 7);
							accountDetails += padSpacesToLeft(fundTimeFrame, 25);
							accountDetails += padSpacesToLeft(fundFromYear, 15);
							accountDetails += padSpacesToLeft(fundToYear, 18);
														
							accountDetails += "\n";					
							oneLineMinimum = true;	
						} else {
							accountErrorLines += "\n- Line # " + fundIndex + " is incomplete";
						}
					}
				}
				
				if(fundTimeFrame == "Init Inv Only" || fundTimeFrame =="All Years" || fundTimeFrame == "") {
					if(fundNumber.length != 0 || fundTimeFrame.length != 0) {
						if (fundNumber.length > 0 && fundTimeFrame.length > 0) {
							accountDetails += padSpacesToRight(fundNumber, 7);
							accountDetails += padSpacesToLeft(fundTimeFrame, 25);
															
							accountDetails += "\n";					
							oneLineMinimum = true;	
						} else {
							accountErrorLines += "\n- Line # " + fundIndex + " is incomplete";
						}
					}
				}	
			});	
		}
		
		if(quest == "No" && allfund =="Yes") {
				fundHeader = "\n\nTIMEFRAME:            FROM:          TO:	  \n";
				accountDetails = accountDetails + fundHeader;
				
				$(acctAllFundLinesYes).each(function(index) {
				var fundIndex = index + 1;
				var fundTimeFrame = $(this).find("select.timeFrameQuestNoAllFundYes").val();
				var fundFromYear = $(this).find("select.fromYear").val();
				var fundToYear = $(this).find("select.toYear").val();
			
				if(fundTimeFrame == "Years Selected") {
					if (fundTimeFrame.length != 0 || fundFromYear.length != 0 || fundToYear.length != 0) {
						if (fundTimeFrame.length > 0 && fundFromYear.length > 0 && fundToYear.length > 0) {
							if (fundToYear != thisYear) {
								if (parseInt(fundFromYear) > parseInt(fundToYear)) {
									accountErrorLines += "\n- Line # " + fundIndex + ": 'From' year cannot be greater than 'To' Year";
								}
							}
							accountDetails += padSpacesToRight(fundTimeFrame, 20);
							accountDetails += padSpacesToLeft(fundFromYear, 10);
							accountDetails += padSpacesToLeft(fundToYear, 15);
											
							accountDetails += "\n";					
							oneLineMinimum = true;
						} else {
							accountErrorLines += "\n- Line # " + fundIndex + " is incomplete";
						}
					}
				}
				
				if(fundTimeFrame == "Init Inv Only" || fundTimeFrame =="All Years" || fundTimeFrame == "") {
					if (fundTimeFrame.length > 0) {
						accountDetails += padSpacesToRight(fundTimeFrame, 20);
						accountDetails += "\n";					
						oneLineMinimum = true;
					} else {
						accountErrorLines += "\n- Line # " + fundIndex + " is incomplete";	
					}
				}
			});
		}		
		
		if (oneLineMinimum == false ) {
			if(quest == "Yes"){
				accountErrorLines += "\n- At least one fund line must be complete";
			} else if(quest == "No") {
				if(allfund != ""){
					accountErrorLines += "\n- At least one fund line must be complete";
				}
			}
		}
		
	});
	
}

function testRecipients(form) {
	var recipientDetails = "RECIPIENT INFO:"
	var recipientIndex = 1;
	
	//first check that at least one recipient is checked
	if (!document.transForm.ownerCheckbox.checked && !document.transForm.brokerCheckbox.checked && !document.transForm.specialCheckbox.checked && !document.transForm.returnCheckbox.checked) {
		lineItemErrors += "\n\n- RECIPIENT(S)";
		return;
	} else {  //as long as one is checked continue validation
		var recipientErrorLines = "";
		$(".standardRecipient:checked").each(function(index) {  //loop through Owner, Broker, and Special if checked
			var recipientLabel = $(this).attr("data-label"); //get the label of the checked recipient
			var closestMail = $(this).closest("div.recipient").find("input.mail").is(":checked");
			var closestFax = $(this).closest("div.recipient").find("input.fax").is(":checked");
			
			if (closestMail == false && closestFax == false) {
				recipientErrorLines += "\n- " + recipientLabel + "- DELIVERY METHOD(S)";
			}
			
			if (closestMail == true) { //Validate Mail Section if checked
				var errorcount = recipientErrorLines.length;
				var mailCompanyName = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(0)").val();
				var mailName = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(1)").val();
				var mailAddress1 = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(2)").val();
				var mailAddress2 = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(3)").val();
				var mailCity = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(4)").val();
				var mailState = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(5)").val();
				var mailZip = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(6)").val();
				var mailOvernight = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(7)").is(":checked");
				var mailOvernightPriority = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(8)").is(":checked");
				var mailOvernightStandard = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(9)").is(":checked");
				var mailCarrier = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(10)").val();
				var mailBilling = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(11)").val();
				var mailOvernightSignature = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(12)").is(":checked");
				if(recipientLabel=="BROKER") {
					if ($.trim(mailCompanyName).length == 0) recipientErrorLines += "\n- " + recipientLabel + " - MAIL: FIRM NAME";
				}
				
				if ($.trim(mailName).length == 0) recipientErrorLines += "\n- " + recipientLabel + " - MAIL: NAME";
				if ($.trim(mailAddress1).length == 0) recipientErrorLines += "\n- " + recipientLabel + " - MAIL: ADDRESS";
				if ($.trim(mailCity).length == 0) recipientErrorLines += "\n- " + recipientLabel + " - MAIL: CITY";
				if ($.trim(mailState).length == 0) recipientErrorLines += "\n- " + recipientLabel + " - MAIL: STATE";
				if ($.trim(mailZip).length == 0) recipientErrorLines += "\n- " + recipientLabel + " - MAIL: ZIP";
				if (mailOvernight == true) {
				
					if (!(mailOvernightPriority || mailOvernightStandard)) {
					  recipientErrorLines += "\n- " + recipientLabel + " - MAIL: SERVICE REQUESTED";
					}
					if ($.trim(mailCarrier).length == 0) recipientErrorLines += "\n- " + recipientLabel + " - MAIL: CARRIER";
					if ($.trim(mailBilling).length == 0) recipientErrorLines += "\n- " + recipientLabel + " - MAIL: BILLING #";
				}
				
				if (errorcount == recipientErrorLines.length) {
					recipientDetails += "\n_______________________________________________________________";
					recipientDetails += "\n" + recipientIndex.toString() + ". " + recipientLabel + " - MAIL";
					if (mailOvernight == true) 
						recipientDetails += " (OVERNIGHT)" 
					recipientDetails += "\nOWNER MAILING ADDRESS:";
					
					if($.trim(mailCompanyName).length > 0) {
						recipientDetails += "\n" + mailCompanyName;	
					}
					recipientDetails += "\n" + mailName;
					recipientDetails += "\n" + mailAddress1;
					if ($.trim(mailAddress2).length > 0) 
						recipientDetails += "\n" + mailAddress2;
					recipientDetails += "\n" + mailCity + " " + mailState + ", " + mailZip;
					
					if (mailOvernight == true) {
						recipientDetails += "\n\nOVERNIGHT DELIVERY OPTIONS:";
						var overNightDeliveryService = "";
						if(mailOvernightPriority) {
							overNightDeliveryService = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(8)").val();
						} else if (mailOvernightStandard) {
							overNightDeliveryService = $(this).closest("div.recipient").find("div.mailDeliveryDetails").find("input:eq(9)").val();	
						}
						
						recipientDetails += "\nSERVICE REQUESTED:"+ overNightDeliveryService;
						recipientDetails += "\nCARRIER: " + mailCarrier;
						recipientDetails += "\nBILLING #: " + mailBilling;
						recipientDetails += "\nSIGNATURE REQUIRED: ";
						if (mailOvernightSignature == true) 
							recipientDetails += "Y";
						else 
							recipientDetails += "N";
					}
					recipientDetails += "\n";
					recipientIndex++
				}
			}

			if (closestFax == true) { //Validate Fax Section if checked
				var errorcount = recipientErrorLines.length;
				var faxAttn = $(this).closest("div.recipient").find("div.faxDeliveryDetails").find("input:eq(0)").val();
				var faxNumber = $(this).closest("div.recipient").find("div.faxDeliveryDetails").find("input:eq(1)").val();
				var faxCompany = $(this).closest("div.recipient").find("div.faxDeliveryDetails").find("input:eq(2)").val();
				var faxAssocName = $(this).closest("div.recipient").find("div.faxDeliveryDetails").find("input:eq(3)").val();
				var faxAssocPhoneNumber = $(this).closest("div.recipient").find("div.faxDeliveryDetails").find("select:eq(0)").val();
				var faxAssocExt = $(this).closest("div.recipient").find("div.faxDeliveryDetails").find("input:eq(4)").val();
				var faxMessage = $(this).closest("div.recipient").find("div.faxDeliveryDetails").find("textarea:eq(0)").val();
					
				if ($.trim(faxAttn).length == 0) 
					recipientErrorLines += "\n- " + recipientLabel + " - FAX: ATTN";

				if ($.trim(faxNumber).length == 0) 
					recipientErrorLines += "\n- " + recipientLabel + " - FAX: FAX #";
				
				if(recipientLabel=="BROKER") {
					if ($.trim(faxNumber).length == 0) recipientErrorLines += "\n- " + recipientLabel + " - FAX: FIRM NAME";
				}

				if ($.trim(faxAssocName).length == 0) 
					recipientErrorLines += "\n- " + recipientLabel + " - FAX: ASSOCIATE NAME";
					
				if ($.trim(faxAssocPhoneNumber).length == 0) 
					recipientErrorLines += "\n- " + recipientLabel + " - FAX: ASSOCIATE PHONE #";
					
				if ($.trim(faxAssocExt).length == 0) 
					recipientErrorLines += "\n- " + recipientLabel + " - FAX: ASSOCIATE EXT";
					
				if (errorcount == recipientErrorLines.length) {
					recipientDetails += "\n_______________________________________________________________";
					recipientDetails += "\n" + recipientIndex.toString() + ". " + recipientLabel + " - FAX";
					recipientDetails += "\nTO:";
					recipientDetails += "\nATTN: " + faxAttn;
					recipientDetails += "\nFAX #: " + faxNumber;
					if ($.trim(faxCompany).length > 0) {
						if(recipientLabel=="BROKER") {
							recipientDetails += "\nFIRM NAME: " + faxCompany;
						} else {
							recipientDetails += "\nCOMPANY NAME: " + faxCompany;
						}
					}
						
					recipientDetails += "\n\nFROM:";
					recipientDetails += "\nASSOCIATE NAME: " + faxAssocName;
					recipientDetails += "\nASSOCIATE PHONE #: " + faxAssocPhoneNumber;
					recipientDetails += "\nASSOCIATE EXT: " + faxAssocExt;
					if ($.trim(faxMessage).length > 0) {
						recipientDetails += "\n\nFAX MESSAGE:";
						recipientDetails += "\n" + faxMessage;
					}
							
					recipientDetails += "\n";
					recipientIndex++
				}
			}
		});

		if (document.transForm.returnCheckbox.checked) { //validate Return To section if checked
			var errorcount = recipientErrorLines.length;
			if($.trim(document.transForm.returnToInitials.value).length == 0) {
				recipientErrorLines += "\n- RETURN TO: ASSOCIATE INITIALS";
			}
			
			if($.trim(document.transForm.returnToMailStop.value).length == 0) {
				recipientErrorLines += "\n- RETURN TO: MAIL STOP";
			}

			if (errorcount == recipientErrorLines.length) {
				recipientDetails += "\n_______________________________________________________________";
				recipientDetails += "\n" + recipientIndex.toString() + ". RETURN TO:";
				recipientDetails += "\nASSOCIATE INITIALS: " + $.trim(document.transForm.returnToInitials.value);
				recipientDetails += "\nMAIL STOP: " + $.trim(document.transForm.returnToMailStop.value);
			}
		}
	}
		
	if (recipientErrorLines.length > 15) {
		lineItemErrors += "\n\n- RECIPIENT(S):\n" + recipientErrorLines;
	}
	form.$recipientdetails$.value = recipientDetails;
}

recipientChecked = function(e, obj) {
	if(e.checked) {
		$('#'+obj).collapse('show');
	} else {
		$('#'+obj).find('input').val('');
		$('#'+obj).find('textarea').val('');
		$('#'+obj).find('input').prop('checked',false);
		if($(e).attr('class') == 'mail' || $(e).attr('class') == 'fax') {
			$(e).parents('.rightMargin').find('.collapse').collapse('hide');
		} else {
			$('#'+obj).parents('.recipient').find('.collapse').collapse('hide');
			if($('#'+obj).parents('.recipient').find('fieldset').hasClass("open")) {
				$('#'+obj).parents('.recipient').find('fieldset').removeClass("open");
			}
		}
	}
};

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

function ValidatePhone(m){
	p1 = null;
	p1 = m;
	ValidatePhone1(p1);
}

function ValidatePhone1(p1){
	var p;
	p = "";
	p = p1.value;
	
	if(p.length == 3){
		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ")";
		}
	p1.value=""; p1.value=pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
			p1.value=""; p1.value=pp;

		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
			pp = "(" + p13 + ")" + p14 + p15;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 2 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
			p1.value=""; p1.value=pp;
		}

	}
}

function padSpacesToRight(inputstring, totalLength){
	var returnstr=inputstring;
	for (var i = inputstring.length; i<totalLength; i++) {
		returnstr += " ";
	}
	return returnstr;
}

function padSpacesToLeft(inputstring, totalLength){
	var returnstr="";
	for (var i = 1; i<totalLength-inputstring.length; i++) {
		returnstr += " ";
	}
	returnstr += inputstring;
	return returnstr;
}