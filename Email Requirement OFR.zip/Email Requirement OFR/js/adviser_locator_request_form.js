$("span.todaybutton").click(function(){applyTodaysDate();});
$("span.todaybutton").keydown(function(event){if (event.which == 32) applyTodaysDate();});

function applyTodaysDate() {
	var today = new Date(); 
	var dd = today.getDate(); 
	var mm = today.getMonth()+1;
	var yyyy = today.getFullYear(); 

	if (dd<10) {dd="0"+dd};
	if (mm<10){mm="0"+mm}; 

	var today = mm+"/"+dd+"/"+yyyy; 
	
	$("#CALLDATE").val(today);
	$("#shareholdertype").focus();
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	var alrForm = document.getElementById("alrForm");
	alrForm.$ACCOUNTTYPES$.value = "";
	
	if ($.trim(alrForm.$ACCOUNT$.value).length > 0) {alrForm.$ACCOUNTTYPES$.value = "ACCOUNT #: " + alrForm.$ACCOUNT$.value + "\n\n";}
	
	if(alrForm.shareholdertype.value.length > 0 && !alrForm.shareholderTypeVerification.checked) {
		errorMsgArr[$("#shareholderTypeVerification").attr('tabindex')] = "- Shareholder Type - SHARE verification\n";
	} else if (alrForm.shareholdertype.value == "ps") {
		alrForm.$SHAREHOLDERTYPE$.value = "PROSPECTIVE SHAREHOLDER: Y\nNO EXISTING ACCOUNT";
	} else if (alrForm.shareholdertype.value == "os") {
		alrForm.$SHAREHOLDERTYPE$.value = "ORPHAN SHAREHOLDER: Y\nNO ADVISORS ON EXISTING ACCOUNTS";
	}
	
	if(!alrForm.acTypeMutualFunds.checked && !alrForm.acTypeCollegeAmerica.checked && !alrForm.acTypeERSponsoredRP.checked && !alrForm.acTypeOther.checked ) {
		errorMsgArr[$("#acTypeMutualFunds").attr('tabindex')] = "- Account Type(s)\n";
	} else if((alrForm.acTypeERSponsoredRP.checked && alrForm.planTypeDetails.value.length == 0) || (alrForm.acTypeOther.checked && alrForm.acTypeOtherText.value.length == 0)) {
		if(alrForm.acTypeERSponsoredRP.checked && alrForm.planTypeDetails.value.length == 0) {
			errorMsgArr[$("#acTypeERSponsoredRP").attr('tabindex')] = "- Account Type(s) - Enter information in the Plan Type/Details\n";
		}
		if(alrForm.acTypeOther.checked && alrForm.acTypeOtherText.value.length == 0)
		{
			errorMsgArr[$("#acTypeOther").attr('tabindex')] = "- Account Type(s) - Enter information for Other\n";
		}
	}
	else
	{
		var accountTypes = new Array();
		var accountTypesOther = "OTHER: " + alrForm.acTypeOtherText.value;
	
		if (alrForm.acTypeMutualFunds.checked) accountTypes.push("MUTUAL FUNDS: Y");
		if (alrForm.acTypeCollegeAmerica.checked) accountTypes.push("COLLEGEAMERICA: Y");
		if (alrForm.acTypeERSponsoredRP.checked) accountTypes.push("ER SPONSORED RP: Y");
		if (alrForm.acTypeOther.checked) accountTypes.push(accountTypesOther);
		
		if (accountTypes.length == 1) 
			alrForm.$ACCOUNTTYPES$.value += accountTypes[0];
		else if (accountTypes.length > 1) 
		{
			alrForm.$ACCOUNTTYPES$.value += accountTypes[0] + "\n";
			alrForm.$ACCOUNTTYPES$.value += accountTypes[1];
			if (accountTypes.length == 3) 
				alrForm.$ACCOUNTTYPES$.value += "\n" + accountTypes[2];
			else if (accountTypes.length > 3)
			{
				alrForm.$ACCOUNTTYPES$.value += "\n" + accountTypes[2];
				alrForm.$ACCOUNTTYPES$.value += "\n" + accountTypes[3];
			}
		}
		
		if (alrForm.acTypeERSponsoredRP.checked && $.trim(alrForm.planTypeDetails.value).length >0) {
			alrForm.$ACCOUNTTYPES$.value += "\n\nPLAN TYPE/DETAILS:\n" + alrForm.planTypeDetails.value;
		}
	}

}

Form.CreateSubject = function () {
	var alrForm = document.getElementById("alrForm");
	alrForm.subject.value = "Adviser Locator Request Form - ";
	alrForm.$FORMATTEDADDRESS$.value = "";
	
	alrForm.$NAME$.value = alrForm.salutation.value + alrForm.name.value

		
	if (alrForm.callerpreference.value == "ps") {
		alrForm.$CALLERPREFERENCE$.value = "THE ";
		if (alrForm.shareholdertype.value == "ps") alrForm.$CALLERPREFERENCE$.value += "PROSPECTIVE SHAREHOLDER ";
		else if (alrForm.shareholdertype.value == "os") alrForm.$CALLERPREFERENCE$.value += "ORPHAN SHAREHOLDER ";
		alrForm.$CALLERPREFERENCE$.value += "WILL CONTACT THE ADVISER.\nWE DO NOT PROVIDE THE ADVISER WITH THEIR NAME OR PHONE NUMBER.";
	}
	else if (alrForm.callerpreference.value == "os") {
		alrForm.$CALLERPREFERENCE$.value = "THE ADVISER WILL CONTACT THE ";
		if (alrForm.shareholdertype.value == "ps") alrForm.$CALLERPREFERENCE$.value += "PROSPECTIVE SHAREHOLDER. ";
		else if (alrForm.shareholdertype.value == "os") alrForm.$CALLERPREFERENCE$.value += "ORPHAN SHAREHOLDER.\n";
		alrForm.$CALLERPREFERENCE$.value += "WE WILL PROVIDE THE ADVISER WITH THEIR NAME AND PHONE NUMBER.";
	}

	alrForm.$CALLDATE$.value = alrForm.CALLDATE.value

	alrForm.$ADDRESS$.value = "ADDRESS: " + $.trim(alrForm.address1.value);
	if ($.trim(alrForm.address2.value).length > 0) alrForm.$ADDRESS$.value += "\n         " + $.trim(alrForm.address2.value);

	generateFormattedAddress();
		
	alrForm.subject.value += alrForm.$SITE$.value + " - " + alrForm.name.value;
}

function generateFormattedAddress() {
	alrForm.$FORMATTEDADDRESS$.value = alrForm.salutation.value + alrForm.name.value + "\n" + $.trim(alrForm.address1.value);
	if ($.trim(alrForm.address2.value).length > 0) alrForm.$FORMATTEDADDRESS$.value += "\n" + $.trim(alrForm.address2.value);
	alrForm.$FORMATTEDADDRESS$.value += "\n" + $.trim(alrForm.$CITY$.value) + ", " + $.trim(alrForm.$STATE$.value) + "  " + $.trim(alrForm.$ZIP$.value);
}

Form.FormSpecificReset = function () {
	$("#acTypeOtherText").prop('disabled','disabled');
	$("#shareholderTypeVerification").removeAttr("checked");
	$("#shareholderTypeVerificationBox").hide(0);
	$("#erPlanTypeSection").hide(0);
	$("#preferenceNote").hide(0);
}

$('#acTypeOther').change(function() { 
    var acTypeOtherIsChecked = $(this).prop('checked');
	if(!acTypeOtherIsChecked)
	{
		$('#acTypeOtherText').prop('value',"");
	}
    $('#acTypeOtherText').prop('disabled', !acTypeOtherIsChecked); 
});

$("#shareholdertype").change(function() {
	$("#shareholderTypeVerification").removeAttr("checked");

	if ($("#shareholdertype").val() == "ps") {
		$("#shareholderTypeVerificationLabel").html("*No Existing Account - Verfied in SHARE");
		$("#shareholderTypeVerificationBox:visible").hide(0);
		$("#hiddenAccountSection:visible").slideUp(500);
		$("#shareholderTypeVerificationBox").delay(100).slideDown(500);
		document.alrForm.$ACCOUNT$.value = "";
	}
	else if ($("#shareholdertype").val() == "os") {
		$("#shareholderTypeVerificationLabel").html("*Verified in SHARE the caller does not have an adviser on his/her accounts - including those in the cume.");
		$("#shareholderTypeVerificationBox:visible").hide(0);
		$("#shareholderTypeVerificationBox").hide(0).delay(100).slideDown(500);
		$("#hiddenAccountSection").hide(0).delay(250).slideDown(500);
	}
	else {
		$("#shareholderTypeVerificationBox:visible").slideUp(500);
		$("#hiddenAccountSection:visible").slideUp(500);
		document.alrForm.$ACCOUNT$.value = "";
		$("#hiddenAccountSection:visible").slideUp(500);
	}
});

$("#callerpreference").change(function() {
	if ($("#callerpreference").val() == "ps") {
		$("#preferenceNote:visible").slideUp(100).delay(100);
		$("#preferenceNoteMsg").html("Let the caller know they will receive a letter with the name(s) of a/some financial adviser(s) in their area.");
		$("#preferenceNote").slideDown(500);
	}
	else if ($("#callerpreference").val() == "os") {
		$("#preferenceNote:visible").slideUp(100).delay(100);
		$("#preferenceNoteMsg").html("Let the caller know they will receive a confirmation letter of their request and a financial adviser may contact them.");
		$("#preferenceNote").slideDown(500);
	}
	else {
		$("#preferenceNote:visible").slideUp(500);
	}
});

$("#acTypeERSponsoredRP").change(function() {
	var acTypeERSponsoredRPIsChecked = $(this).prop('checked');
	if(!acTypeERSponsoredRPIsChecked)
	{
		$('#planTypeDetails').prop('value',"");
	}
	$("#erPlanTypeSection").slideToggle(500);
});

function ValidatePhone(m){
	p1 = null;
	p1 = m;
	ValidatePhone1(p1);
}

function ValidatePhone1(p1){
	var p;
	p = "";
	p = p1.value;
	
	if(p.length == 3){
		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ")";
		}
	p1.value=""; p1.value=pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
			p1.value=""; p1.value=pp;

		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
			pp = "(" + p13 + ")" + p14 + p15;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 2 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
			p1.value=""; p1.value=pp;
		}

	}
}

function ValidateZip(z){
	if (z.value.length == 5) z.value += "-";
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = $.trim(str);
    }
}
