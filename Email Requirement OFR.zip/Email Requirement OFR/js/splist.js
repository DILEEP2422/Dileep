var Lists = new ListsClass();

function ListsClass () {
	this.Context = null;
	this.Lists = null;
	this.Loaded = false;
	this.Load = function () {
		this.Context = new SP.ClientContext.get_current();
		this.Lists = this.Context.get_web().get_lists();
		this.Context.load(this.Lists);
		this.Context.executeQueryAsync(null, null);
	}
	var finish = function(list, query, columns, includeFile, complete) {
		var items = list.getItems(query);
		if (includeFile) {
			var include = 'Include(';
			columns.forEach(function (e, i, a) {
				if (i != 0) 
					include += ', ';
				include += e;
			});
			include += ')';
			Lists.Context.load(items, include);
		}
		else
			Lists.Context.load(items);
		var result = [];
		var promise = Lists.Context.executeQuery();
		promise.then(function () {
			var enumerator = items.getEnumerator();
			while(enumerator.moveNext()) {
				
				var item = enumerator.get_current();
				var values = item.get_fieldValues();
				if (includeFile)
					values.FileUrl = item.get_file().get_serverRelativeUrl();
				result.push(values);
			}
			complete(result);
		}, function () {});
	}
	this.Read = function (listName, columns, orderBy, ascending, complete) {
		var query = SimpleQuery(columns, orderBy, ascending);
		finish(this.Lists.getByTitle(listName), query, columns, false, complete);
	}
	this.ReadWithQueryBuilder = function (listName, queryBuilder, includeFile, complete) {
		var query = queryBuilder.BuildQuery();
		finish(this.Lists.getByTitle(listName), query, queryBuilder.Columns, includeFile, complete);
	}
	// Returns a list object. Does not execute immediately, waits until next executeQuery.
	// This is used for getting counts of items and thus doesn't need to be fired automatically.
	this.Get = function(listName) {
		var list = this.Lists.getByTitle(listName);
		Lists.Context.load(list);
		return list;
	}
	// Same as list item, but returns items 
	this.GetItems = function (listName, queryBuilder) {
		var list = this.Lists.getByTitle(listName);
		var query = queryBuilder.BuildQuery();
		var items = list.getItems(query);
		this.Context.load(items);
		return items;
	}
}

function SimpleQuery(columns, orderBy, ascending) {
	var query = new SP.CamlQuery();
	var queryString = '<View><Query><OrderBy><FieldRef Name="' + orderBy + '" Ascending="' + ascending + '" /></OrderBy></Query><ViewFields>';
	columns.forEach(function (e, i, a) {
		queryString += '<FieldRef Name="' + e + '" />';
	});
	queryString += "</ViewFields></View>";
	query.set_viewXml(queryString);
	return query;
}

function CamlQueryBuilder(columns, orderBy, ascending, limit, where, lastID) {
	this.Template = "<View>{{query}}{{rowLimit}}<ViewFields>{{fields}}</ViewFields></View>";
	this.QueryTemplate = "<Query>{{orderBy}}{{where}}</Query>";
	this.OrderByTemplate = '<OrderBy><FieldRef Name="{{orderBy}}" Ascending="{{ascending}}" /></OrderBy>';
	this.RowLimitTemplate = '<RowLimit>{{limit}}</RowLimit>';
	this.Columns = columns;
	this.Limit = limit;
	this.OrderBy = orderBy;
	this.Ascending = ascending;
	this.Where = where;
	this.BuildQuery = function () {
		var caml = this.Template;
		var query = this.QueryTemplate;
		var orderBy = '';
		if (this.OrderBy) {
			orderBy  = this.OrderByTemplate.replace('{{orderBy}}', this.OrderBy)
				.replace('{{ascending}}', this.Ascending == false ? "FALSE": "TRUE");
		}
		query = query.replace('{{orderBy}}', orderBy);
		var where = '';
		if (this.Where != null) {
			where = this.Where.BuildElement();
		}
		query = query.replace('{{where}}', where);
		var viewFields = '';
		this.Columns.forEach(function (e, i, a) {
			viewFields += '<FieldRef Name="' + e + '" />';
		});
		var limit = '';
		if (this.Limit) {
			limit = this.RowLimitTemplate.replace('{{limit}}', this.Limit);
		}
		caml = caml.replace('{{fields}}', viewFields).replace('{{query}}', query).replace('{{rowLimit}}', limit);;
		caml = caml;
		var camlQuery = new SP.CamlQuery();
		camlQuery.set_viewXml(caml);
		if (lastID) {
			var position = new SP.ListItemCollectionPosition();
			position.set_pagingInfo('Paged=TRUE&p_ID=' + lastID);
			camlQuery.set_listItemCollectionPosition(position);
		}
		return camlQuery;
	}
	
}

// comparisonType should be "eq", "neq" or "both". EQ means it has to be equal to ColumnA (send null for columnB),
// NEQ means greater than (for column A) or less than (for column B), NOT equal. Send null for a column if you don't want to check for that direction.
// Both means greater than or equal to col A, and less than or equal to col B. Send null for a column if you don't want to check for that direction.
// In short, columnA should be lower than (or equal to) the value you sent in for 'compareValue', and columnB should be greater than (or equal to) that value.
// If you don't want to check a column (and thus a direction), send null. So to check that today's date is more recent (or the same day) as a start date column,
// send 'moment.utc().now()' as the compareValue, 'both' as comparisonType, and 'StartDate' in columnA.

// For now, dataType should be "Text", "Integer", or "DateTime". Others might work but I'm not testing it

function Where(compareValue, comparisonType, columnA, columnB, dataType, includeTimeValue) {
	this.FieldTemplate = '<FieldRef Name="{{name}}" /><Value IncludeTimeValue="TRUE" Type="{{type}}">{{value}}</Value>';
	this.Value = compareValue;
	this.ColumnA = columnA;
	this.ColumnB = columnB;
	this.ComparisonType = comparisonType;
	this.DataType = dataType;
	this.IncludeTimeValue = includeTimeValue;
	this.BuildElement = function () {
		var element = "<Where>";
		var compareA = "";
		var compareB = "";
		switch(this.ComparisonType) {
			case "eq":
				compareA = "<Eq>{{field}}</Eq>";
				break;
			case "neq":
				compareA = "<Lt>{{field}}</Lt>";
				compareB = "<Gt>{{field}}</Gt>";
				break;
			case "both":
				compareA = "<Leq>{{field}}</Leq>";
				compareB = "<Geq>{{field}}</Geq>";
				break;
			default:
				throw new Error("Comparison Type provided to Where object could not be matched!");
		}
		var endElement = "</Where>";
		if (!this.ColumnA && !this.ColumnB) {
			throw new Error("No columns provided for a Where object!");
		}		
		if (!this.Value) {
			throw new Error("No value provided for a Where object!");
		}
		if (this.ColumnA && this.ColumnB) {
			element += "<And>";
			endElement = "</And>" + endElement;
		}
		var field = this.FieldTemplate.replace('{{value}}', this.Value).replace('{{type}}', this.DataType);
		if (this.DataType != "DateTime" || !this.IncludeTimeValue)
			field = field.replace(' IncludeTimeValue="TRUE"', '');
		if (this.ColumnA) {
			element += compareA.replace('{{field}}', field.replace('{{name}}', this.ColumnA));
		}
		if (this.ColumnB) {
			element += compareB.replace('{{field}}', field.replace('{{name}}', this.ColumnB));
		}
		return element + endElement;
	}
}

function WhereInRange(column, datatype, range) {
	this.ElementTemplate = '<Where><In><FieldRef Name="{{column}}" /><Values>{{values}}</Values></In></Where>';
	this.ValueTemplate = '<Value Type="{{datatype}}">{{value}}</Value>';
	this.Column = column;
	this.DataType = datatype;
	this.Range = range;
	this.BuildElement = function () {
		var value = this.ValueTemplate.replace('{{datatype}}', this.DataType);
		var values = '';
		if (Array.isArray(range))
			this.Range.forEach(function (e, i, a) {
				values += value.replace('{{value}}', e);
			});
		else
			values = value.replace('{{value}}', range);
		return this.ElementTemplate.replace('{{values}}', values).replace('{{column}}', this.Column);
	}
}