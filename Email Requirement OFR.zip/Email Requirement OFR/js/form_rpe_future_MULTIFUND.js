var index = 1;
Form.CustomLoad = function () {
	$('select').change(function () {
		$(this).blur();
	});
}
Form.FormSpecificReset = function() {
	document.getElementById("$subdate$").value = currDate(); // POPULATE SUBMISSION DATE FIELD
	
	$("#notice30").css('display','none');
	$("#loandiv").css('display','none');
	$("#loanfields2").css('display','none');
	$("#loanfields").css('display','none');
	$("#rpa").css('display','none');
	$("#erlower").css('display','none');
	$("#defnm").css('display','none');
	$("#loanwarn").css('display','none');
	$("#mapwarn").css('display','none');
	$("#efflbl").css('display','none');
	$("#tradelbl").css('display','none');

	$(".add").click(function(){	addLineItems();});
	$(".add").keydown(function(event){if (event.which == 32) addLineItems();});
	$(".delete").click(function(){$(this).parent().parent().remove(); index--; reindexMappingInstructions(); reindexRows();});

	$("#mappingInstructionsFundDetails").empty();	
	
	setupMappingInstructions();
	document.getElementById("rightpanel").style.display = "none";
	
	reindexMappingInstructions();
	reindexRows();
}
	
function setupMappingInstructions() {
	index=1;
	for(index = 1; index <=10; index++) {
		$("#mappingInstructionsFundDetails").append($("#mappingInstructionsFundDetailsTemplate #mappingInstructionsFundDetailsSection").clone(true).attr('id',"mappingInstructionsFundDetailsSection"+index));
		$("#mappingInstructionsFundDetails #mappingInstructionsFundDetailsSection"+index).find("select:first").attr('name','$ff'+index+'$');
		$("#mappingInstructionsFundDetails #mappingInstructionsFundDetailsSection"+index).find("select:last").attr('name','$tf'+index+'$');
		$("#mappingInstructionsFundDetails #mappingInstructionsFundDetailsSection"+index).find("select:last").attr('id','t'+index);
		$("#mappingInstructionsFundDetails #mappingInstructionsFundDetailsSection"+index).find("select:first").attr('data-rowIndex',index);
	}
}

function reindexMappingInstructions() {
	$("div[id^='mappingInstructionsFundDetailsSection']").each(function(index) {
		$(this).find("select:first").attr('name','$ff'+(index+1)+'$');
		$(this).find("select:last").attr('name','$tf'+(index+1)+'$');
		$(this).find("select:last").attr('id','t'+(index+1));
		$(this).find("select:first").attr('data-rowIndex',(index+1));
	});
}

function addLineItems(){
	index++;
	$("#mappingInstructionsFundDetailsTemplate #mappingInstructionsFundDetailsSection").clone(true).attr('id',"mappingInstructionsFundDetailsSection"+index).appendTo("#mappingInstructionsFundDetails:last"); 
	$("#mappingInstructionsFundDetails #mappingInstructionsFundDetailsSection"+index).find("select:first").attr('name','$ff'+index+'$');
	$("#mappingInstructionsFundDetails #mappingInstructionsFundDetailsSection"+index).find("select:last").attr('name','$tf'+index+'$');
	$("#mappingInstructionsFundDetails #mappingInstructionsFundDetailsSection"+index).find("select:last").attr('id','t'+index);
	reindexMappingInstructions();
	reindexRows();
}

function reindexRows(){
	if (index == 1) 
		$(".delete").hide();
	else
		$(".delete").show();

	if (index > 29) 
		$(".add").hide();
	else 
		$(".add").show();
}

function toggleER() {
	if (ge("expno").checked) {
		ge("notice30").style.display="block";
		ge("$hidexp$").value = "No";
	} else if (ge("expyes").checked) {
		// uncheck 30day yes/no
		ge("noticeyes").checked = false;
		ge("noticeno").checked = false;
		ge("notice30").style.display = "none"; // hide 30day div
		ge("$hidexp$").value = "Yes";
	} else {}	
}// end function 		

function toggleNotice() {
	if (ge("noticeyes").checked){
		ge("$hidnotice$").value = "Yes";
	} else if (ge("noticeno").checked) {
		ge("$hidnotice$").value = "No";
	} else {}	
}	

function popCurrEff() { // POPULATE CURRENT DATE
	if(document.getElementById("$currchecked$").checked){
		document.getElementById("effdatetxt").value = currDate();
		document.getElementById("loanfields").style.display = 'none';		
		document.getElementById("loanfields2").style.display = 'none';									
	} else {
		document.getElementById("effdatetxt").value = "";			
		document.getElementById("loanfields").style.display = 'block';		
		document.getElementById("loanfields2").style.display = 'block';									
	}
}			

function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy)
	var today = new Date();
	var month = today.getMonth() + 1;
	if(month < 10){month = "0" + month;}

	var day = today.getDate();
	if(day < 10){day = "0" + day;}

	var year = today.getFullYear() - 2000;

	var dateString = month + "/" + day + "/" + year;

	return dateString;
	}	

	function ge(id) {
	var theElement = document.getElementById(id);
	return theElement;
	}

	function checkType() {
	if (form_broad.$reqtype$.value == "Investment Option Change - Mapping - Unit Class Change" || form_broad.$reqtype$.value == "Investment Option Change - Mapping - Inv Opt Replacement" || form_broad.$reqtype$.value == "Default Investment Option Change - No Mapping" || form_broad.$reqtype$.value == "Loan Provision Add / Remove") {
		document.getElementById("$worktype$").value = "Fin Plan Maint";
		document.getElementById("efflbl").style.display = 'block';
		document.getElementById("loandiv").style.display = 'none';							
	} else {							 	
		document.getElementById("$worktype$").value = "";
		document.getElementById("efflbl").style.display = 'none';
		document.getElementById("rightpanel").style.display = "none";
		document.getElementById("loandiv").style.display = 'none';							
	}

	if (form_broad.$reqtype$.value == "Investment Option Change - Mapping - Unit Class Change" || form_broad.$reqtype$.value == "Investment Option Change - Mapping - Inv Opt Replacement") {
		document.getElementById("rpa").style.display="block";
		document.getElementById("mapwarn").style.display="block";
		document.getElementById("rightpanel").style.display = "block";	
		document.getElementById("loandiv").style.display = 'none';	
		document.getElementById("tradelbl").style.display = 'block';
	} else {
		document.getElementById("rpa").style.display="none";
		document.getElementById("mapwarn").style.display="none";
		document.getElementById("rightpanel").style.display = "none";	
		document.getElementById("loandiv").style.display = 'none';	
		document.getElementById("tradelbl").style.display = 'none';
	}
								
	if (form_broad.$reqtype$.value == "Default Investment Option Change - No Mapping") {
		document.getElementById("defnm").style.display = 'block';
		document.getElementById("loandiv").style.display = 'none';							
	} else {
		document.getElementById("defnm").style.display = 'none';
		document.getElementById("loandiv").style.display = 'none';
	}
								
	if (form_broad.$reqtype$.value == "Money Type Change" || form_broad.$reqtype$.value == "Printed Fee Disclosure Order" || form_broad.$reqtype$.value == "Vesting Schedule Change" || form_broad.$reqtype$.value == "Investment Option Change - No Mapping" || form_broad.$reqtype$.value == "Other" || form_broad.$reqtype$.value == "") {							
		document.getElementById("loanfields").style.display = 'none';
		document.getElementById("loanfields2").style.display = 'none';							
		document.getElementById("efflbl").style.display = 'none';
		document.getElementById("loanwarn").style.display="none";	
		document.getElementById("loandiv").style.display = 'none';	
							
		//	DISPLAY POP-UP IF MT CHANGE IS SELECTED

		if (form_broad.$reqtype$.value == "Money Type Change") {
			alert("Please provide the contribution formula in the Comments section when adding SHNE, SHM, and/or Purchase Money.");
		}		
	} else if (form_broad.$reqtype$.value == "Loan Provision Add / Remove") {
		document.getElementById("loanfields").style.display = 'block';		
		document.getElementById("loanfields2").style.display = 'block';									
		document.getElementById("efflbl").style.display = 'block';
		document.getElementById("loanwarn").style.display="block";	
		document.getElementById("loandiv").style.display = 'block';						
	} else { // MEANS:  FC MAPPING, OR DF NO MAP
		document.getElementById("loanfields").style.display = 'none';		
		document.getElementById("loanfields2").style.display = 'none';									
		document.getElementById("efflbl").style.display = 'block';
		document.getElementById("loanwarn").style.display="none";
		document.getElementById("loandiv").style.display = 'none';									
	}

	// TOGGLERS FOR ***UCC*** + FD REQUIREMENTS

	if (ge("$reqtype$").value == "Investment Option Change - Mapping - Unit Class Change") {
		ge("erlower").style.display = "block";
	} else {
		ge("erlower").style.display = "none";
		ge("notice30").style.display = "none";
		ge("expyes").checked = false;
		ge("expno").checked = false;
		ge("noticeyes").checked = false;
		ge("noticeno").checked = false;
		
		// clear hidden fields
		
		ge("$hidexp$").value = "";
		ge("$hidnotice$").value = "";
	}					
								
	}// end checktype
	function propagate(fromFundDropDown) {
		var rowIndex = fromFundDropDown.getAttribute("data-rowIndex");
		var selectedIndex = fromFundDropDown.selectedIndex;
		if(form_broad.$likefund$.checked) {
			$("#t"+rowIndex).prop('selectedIndex',selectedIndex);
		}
	}		
	function dateProv() {
	if(form_broad.dateprov.checked) {
		document.getElementById("loanfields").style.display = 'none';	
		alert("Please select the Effective Date.")
	} else {		 	
		document.getElementById("loanfields").style.display = 'block';				
	}
	}

	//	CALCULATES FUTURE DATE BASED ON ENTRY
	function calcDate() {
	var numberdays = document.getElementById("numdays").value; // number of days indicated

	var today = new Date(); //	get current date

	var msTime = today.getTime(); // millisecond time

	var addedDays = msTime + (1000 * 60 * 60 * 24 * numberdays); // add days to current date

	addedDays = new Date(addedDays); // conv mstime to date obj

	// get date parts and place into date string:

	var cMonth = addedDays.getMonth() + 1;
	var cDay = addedDays.getDate();
	var cYear = addedDays.getFullYear() - 2000;

	var dString = cMonth + "/" + cDay + "/" + cYear;

	document.getElementById("effdatetxt").value = dString; // populate eff date field
	}

	function copyid() {
	document.getElementById("planid2").value = document.getElementById("$planid$").value;
	}

	function copyname() {
	document.getElementById("planname2").value = document.getElementById("$planname$").value;
	}	


	Form.ValidateSpecificFormFields = function(errorMsgArr) {

	// SET HIDDEN FIELD(S)
	if (document.getElementById("$likefund$").checked) {
		document.getElementById("$liketolike$").value = "Yes";
	} else {
		document.getElementById("$liketolike$").value = "No";			
	}

	//	VALIDATE FIELDS

	if ((form_broad.$reqtype$.value == "Loan Provision Add / Remove" || form_broad.$reqtype$.value == "Investment Option Add - No Mapping" || form_broad.$reqtype$.value == "Investment Option Remove - No Mapping") && $.trim(form_broad.$effdate$.value) == ""){
		errorMsgArr[$("#effdatetxt").attr('tabindex')] = "- Effective Date\n";		
	}

	if ((form_broad.$reqtype$.value == "Investment Option Change - Mapping - Unit Class Change" || form_broad.$reqtype$.value == "Investment Option Change - Mapping - Inv Opt Replacement" ) && $.trim(form_broad.$tradedt$.value) == "") {
		errorMsgArr[$("#tradedt").attr('tabindex')] = "- Trade Date\n";
	}
				
	if (form_broad.$reqtype$.value == "Loan Provision Add / Remove" && !form_broad.$addloans$.checked && !form_broad.$remloans$.checked) {
		errorMsgArr[$("#\\$addloans\\$").attr('tabindex')] = "- Select 'Add Loans' or 'Remove Loans'\n";
	}	

	if (form_broad.$reqtype$.value == "Investment Option Change - Mapping - Unit Class Change" || form_broad.$reqtype$.value == "Investment Option Change - Mapping - Inv Opt Replacement" ) {

		// REQUIRED  FIELDS SPECIFIC TO FUND CHG - MAPPING ONLY
		if ($.trim(form_broad.$effdate$.value) == ""){
			errorMsgArr[$("#effdatetxt").attr('tabindex')] = "- Effective Date\n";		
		} 
		
		if ($.trim(form_broad.$fsc$.value) == ""){
			errorMsgArr[$("#\\$fsc\\$").attr('tabindex')] = "- From Unit Class\n";		
		} 
		
		if ($.trim(form_broad.$tsc$.value) == ""){
			errorMsgArr[$("#\\$tsc\\$").attr('tabindex')] = "- To Unit Class\n";					
		}
		
		if(form_broad.$reqtype$.value != "Investment Option Change - Mapping - Inv Opt Replacement") {
			if (!ge("expyes").checked && !ge("expno").checked){
				errorMsgArr[$("#expyes").attr('tabindex')] = "- Is the new unit class price margin lower than the prior unit class price margin?\n";					
			}
							
			if (ge("expno").checked && (!ge("noticeyes").checked && !ge("noticeno").checked)) {
				errorMsgArr[$("#noticeyes").attr('tabindex')] = "- Are 30-day notification requirements met?\n";	
			}
		}
	} else if (form_broad.$reqtype$.value == "Default Investment Option Change - No Mapping" ) {

		// REQUIRED  FIELDS SPECIFIC TO DEF CHANGE NO MAPPING
		if ($.trim(form_broad.$prevdef$.value) == "") {
			errorMsgArr[$("#\\$prevdef\\$").attr('tabindex')] = "- Previous Default Investment Option\n";
		}
		
		if ($.trim(form_broad.$newdef$.value) == ""){
			errorMsgArr[$("#\\$newdef\\$").attr('tabindex')] = "- New Default Investment Option\n";		
		}
				
		if ($.trim(form_broad.$effdate$.value) == "") {
			errorMsgArr[$("#effdatetxt").attr('tabindex')] = "- Effective Date\n";	
		}
	}

	createLineDetailsTemplate();
	}

	function createLineDetailsTemplate() {
	var lineDetails = "";
	for(lineIndex=1; lineIndex <=29; lineIndex++) {
		if(document.getElementsByName("$ff"+lineIndex+"$")[0]) {
			lineDetails += "LINE  " + lineIndex + ":  " + document.getElementsByName("$ff"+lineIndex+"$")[0].value + " - " + document.getElementsByName("$tf"+lineIndex+"$")[0].value + "\r\n";
		} else {
			lineDetails += "LINE  " + lineIndex + ":  - \r\n";
		}
	}
	document.getElementById("$lineDetails$").value = lineDetails;
	}

	Form.CreateSubject = function() {

	var nonfut = "NON_FUT";
	var fut = "FUT";
		
	var planid = form_broad.$planid$.value;
	var pname = form_broad.$planname$.value;

	// DETERMINE REQUEST TYPE AND SUBJECT LINE TEXT	@recipient

	switch(form_broad.$reqtype$.value) {

		case "Money Type Change":
			form_broad.Qualifier.value = nonfut;
			form_broad.subject.value = "Money Type Change (MULTIFUND) - " + planid + " - " + pname;	
			break;

		case "Printed Fee Disclosure Order":
			form_broad.Qualifier.value = nonfut;
			form_broad.subject.value = "Fee Disclosure Booklet Order (MULTIFUND) - " + planid + " - " + pname;		
			break;

		case "Vesting Schedule Change":
			form_broad.Qualifier.value = nonfut;
			form_broad.subject.value = "Vesting Schedule Change (MULTIFUND) - " + planid + " - " + pname;		
			break;		

		// new 4-5-13
		case "Investment Option Add - No Mapping":
			form_broad.Qualifier.value = nonfut; 
			form_broad.subject.value = "Investment Option Add, No Mapping (MULTIFUND) - " + planid + " - " + pname;		
			break;

		// new 4-5-13
		// update 4-6-16:  per discussion w/szw & srkm, verbiage in soni, & gui behavior,
		// this request type should route to E-mail
		// changing routing variable to fut to route to E-mail
		case "Investment Option Remove - No Mapping":
			form_broad.Qualifier.value = fut;
			form_broad.subject.value = "Investment Option Remove, No Mapping (MULTIFUND) - " + planid + " - " + pname;		
			break;		

		// new 4-5-13
		case "Investment Option Change - Mapping - Unit Class Change":
			form_broad.Qualifier.value = fut;
			form_broad.subject.value = form_broad.$effdate$.value + " - Future Date Processing Request Form - " + planid + " - " + pname + " (Investment Option Change, Mapping - Unit Class Change (MULTIFUND))";		
			break;

		// new 4-5-13
		case "Investment Option Change - Mapping - Inv Opt Replacement":
			form_broad.Qualifier.value = fut;
			form_broad.subject.value = form_broad.$effdate$.value + " - Future Date Processing Request Form - " + planid + " - " + pname + " (Investment Option Change, Mapping - Investment Option Replacement (MULTIFUND))";		
			break;

		case "Default Investment Option Change - No Mapping":
			form_broad.Qualifier.value = fut;
			form_broad.subject.value = form_broad.$effdate$.value + " - Future Date Processing Request Form - " + planid + " - " + pname + " (Default Investment Option Change, No Mapping (MULTIFUND))";		
			break;

		case "Loan Provision Add / Remove":		
			if (form_broad.$addloans$.checked) {
				form_broad.$loantype$.value = "Add Loans";
			} else if (form_broad.$remloans$.checked) {
				form_broad.$loantype$.value = "Remove Loans";
			}					
			
			// IF EFF DATE IS CURRENT OR PAST, DO NOT ROUTE TO E-mail
			// IF EFF DATE IS FUTURE, YES ROUTE TO E-mail

			var thecurr = new Date(); // get current date
			thecurr = thecurr.getTime(); // convert current to ms

			var theeffdate = ge("effdatetxt").value; // get eff date

			// get date parts:
			var dtarray = theeffdate.split("/"); // split eff date string into mm/dd/yy (array)
		
			// parse to float (since month may have a leading zero) in order to perform calcs
			var themonth = parseFloat(dtarray[0]);
			themonth -= 1; //	subtract "1" for use with the Date() object
		
			var theday = parseInt(dtarray[1]);

			var theyear = parseInt(dtarray[2]);		
			theyear += 2000; // conv year to yyyy format
		
			var effobj = new Date(theyear, themonth, theday); // date object: eff date
			var effms = effobj.getTime(); // eff date to ms

			// COMPARE CURRENT AND FUTURE DATES HERE:
			
			//  RCEM 9/23/15:  HERE IS A NEW VARIABLE (fdp) THAT STORES A LITERAL TO BE ADDED TO THE 
			//	SUBJECT LINE IF THE REQUEST IS FUTURE-DATED.  THE DEFAULT VALUE IS NULL, BUT WILL BE
			//	CHANGED IF THE REQUEST IS FUTURE-DATED.
			
			var fdp = "";
			
			if (effms > thecurr){			
				form_broad.Qualifier.value = fut;	
				fdp = " - Future Date Processing Request Form";		
			} else {		
				form_broad.Qualifier.value = nonfut;			
			}			
				
			form_broad.subject.value = form_broad.$effdate$.value + fdp + " - Loan Provision Add / Remove (MULTIFUND) - " + planid + " - " + pname;		
			break;

		case "Other":
			form_broad.Qualifier.value = nonfut;
			form_broad.subject.value = "**Other** RPE Notification Request (MULTIFUND) - " + planid + " - " + pname;		
			break;	
	}// end switch
}