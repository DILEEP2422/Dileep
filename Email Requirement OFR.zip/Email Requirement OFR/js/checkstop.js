function togglemore12() {
	if (ge("more12yes").checked){
		ge("$stopcancel$").value = "Void";
		ge("reisslbl").style.display = "block";

	} else if (ge("more12no").checked) {
		ge("$stopcancel$").value = "Stop";
		ge("reisslbl").style.display = "block";
	}					
}

function toggleless5() { 
	if (ge("less5yes").checked) {
		ge("$stopcancel$").value = "Void";
		ge("more12yes").checked = false;
		ge("more12no").checked = false;							
		ge("more12").style.display = "none";								
				
		ge("reisslbl").style.display = "block";
	} else if (ge("less5no").checked) {						 	
		ge("$stopcancel$").value = "";
		ge("more12").style.display = "block";
	}
}

function toggleckhand() {
	if (ge("ckhandyes").checked) {
		ge("ckhandno").checked = false;
		ge("$stopcancel$").value = "Void";
		ge("less5yes").checked = false;
		ge("less5no").checked = false;
		ge("more12yes").checked = false;
		ge("more12no").checked = false;
		ge("less5").style.display = "none";
		ge("more12").style.display = "none";
		ge("reisslbl").style.display = "block";
	} else if (ge("ckhandno").checked) {
		ge("ckhandyes").checked = false;
		ge("less5").style.display = "block";
	}
}
		
function toggleCas() {
	if (ge("casyes").checked) {
		ge("$stopcancel$").value = "";
		ge("ckhandyes").checked = false;
		ge("ckhandno").checked = false;
		ge("less5yes").checked = false;
		ge("less5no").checked = false;
		ge("more12yes").checked = false;
		ge("more12no").checked = false;
		ge("ckhand").style.display = "none";
		ge("less5").style.display = "none";
		ge("more12").style.display = "none";
		alert("Please process this stop/re-issue request in SHARE (CAS) since the original check was issued there.");
	} else if (ge("casno").checked) {
		ge("ckhand").style.display = "block";
	}
}
		
function togglePoc() {
	if (ge("pocyes").checked) {
		ge("$pocyesno$").value = "Yes";
		ge("$reason$").readOnly = false;
	} else if (ge("pocno").checked) {
		ge("$pocyesno$").value = "No";
		ge("$reason$").value = "";
		ge("$reason$").readOnly = true;
	}
}

function toggleMic() {
	if (ge("mailchgyes").checked) {
		ge("$hidmailchg$").value = "Yes";
		ge("$mlchanges$").readOnly = false;
	} else if (ge("mailchgno").checked) {
		ge("$hidmailchg$").value = "No";
		ge("$mlchanges$").value = "";
		ge("$mlchanges$").readOnly = true;
	}
}
			
function toggleOvn() {
	if (ge("ovnchkyes").checked) {
		ge("$hidovnchk$").value = "Yes";
		ge("$overnight$").readOnly = false;
	} else if (ge("ovnchkno").checked) {
		ge("$hidovnchk$").value = "No";
		ge("$overnight$").value = "";
		ge("$overnight$").readOnly = true;
	}
}
	
function less12() {
	ge("$stopcancel$").value = "Stop";						
}

function more12() {
	ge("$stopcancel$").value = "Void";						
}
			
function more5() {
	ge("twelvediv").style.display = "block";
	ge("$stopcancel$").value = "";						
}

function less5() {
	ge("$stopcancel$").value = "Void";
	ge("twelvediv").style.display = "none";		
	ge("twelveyes").checked = false;
	ge("twelveno").checked = false;
}
		
function noHand() {
	ge("fivediv").style.display = "block";
	ge("$stopcancel$").value = "";
}

function yesHand() {
	ge("$stopcancel$").value = "Void";
	ge("fivediv").style.display = "none";
	ge("twelvediv").style.display = "none";
	ge("fiveyes").checked = false;
	ge("fiveno").checked = false;
}
		
function popMgrApp() {
	var msg = "IMPORTANT:\n\n1.  Manager approval must be noted in TRAC on Payee Registration Changes.\n\n"+
			"2.  Note the changes in the Payee Registration Changes field.";
			
	alert(msg);
			
}
		
function ge(id) {
	var myelement = document.getElementById(id);
	return myelement;
}
		
function toggleReiss() {
	var reiss = ge("$reissue$").value;
	if (reiss == "Yes") {
		ge("reissdiv").style.display = "block";
	} else {
		ge("reissdiv").style.display = "none";
		ge("pocyes").checked = false;
		ge("pocno").checked = false;
		ge("mailchgyes").checked = false;
		ge("mailchgno").checked = false;
		ge("ovnchkyes").checked = false;
		ge("ovnchkno").checked = false;
		ge("$reason$").value = "";
		ge("$mlchanges$").value = "";
		ge("$overnight$").value = "";
		ge("$reason$").readOnly = true;
		ge("$mlchanges$").readOnly = true;
		ge("$overnight$").readOnly = true;
		alert("Please include a note in the Additional Comments field that the check will not be re-issued.");
	}
}
			
Form.ValidateSpecificFormFields = function (errorMsgArr) {
						  
	if (!ge("casyes").checked && !ge("casno").checked){
		errorMsgArr[$("#casyes").attr('tabindex')] = "- Was the check that is being replaced originally processed in SHARE (CAS)?\n";
	}	
	
	if (ge("casno").checked && !ge("ckhandyes").checked && !ge("ckhandno").checked){
		errorMsgArr[$("#ckhandyes").attr('tabindex')] = "- Is the check on hand?\n";
	}
	
	if (ge("ckhandno").checked && !ge("less5yes").checked && !ge("less5no").checked) {
		errorMsgArr[$("#less5yes").attr('tabindex')] = "- Is the check less than $5.00?\n";
	}

	if (!ge("more12yes").checked && !ge("more12no").checked && ge("less5no").checked) {
		errorMsgArr[$("#more12yes").attr('tabindex')] = "- Is the check older than 12 months? \n";
	}
	
	if (form_checkstop.$stopcancel$.value != "" && form_checkstop.$reissue$.value == "") {
		errorMsgArr[$("#\\$reissue\\$").attr('tabindex')] = "- Will RMAC re-issue the check through TRCRECON? \n";
	}

	if (ge("$reissue$").value == "No" && $.trim(ge("$addlcomm$").value) == "") {
		errorMsgArr[$("#\\$addlcomm\\$").attr('tabindex')] = "- A note is required in Additional Comments when No is selected for 'RMAC will re-issue check.' \n";
	}

	if (ge("$reissue$").value == "Yes" && !ge("pocyes").checked && !ge("pocno").checked) {
		errorMsgArr[$("#pocyes").attr('tabindex')] = "- Has the Payee Registration changed? \n";
	} 
	
	if (ge("$reissue$").value == "Yes" && !ge("mailchgyes").checked && !ge("mailchgno").checked) { 
		errorMsgArr[$("#mailchgyes").attr('tabindex')] = "- Has the Alternate Mailing / Address changed?  \n";
	}
	
	if (ge("$reissue$").value == "Yes" && ge("$reissue$").value == "Yes" && !ge("ovnchkyes").checked && !ge("ovnchkno").checked) {
		errorMsgArr[$("#ovnchkyes").attr('tabindex')] = "- Overnight the replacement check?   \n";
	} 
	
	if (ge("pocyes").checked && $.trim(ge("$reason$").value) == "") {
		errorMsgArr[$("#\\$reason\\$").attr('tabindex')] = "- Payee Registration Changes are required when Yes is selected for this question.\n";
	}
	
	if (ge("mailchgyes").checked && $.trim(ge("$mlchanges$").value) == "") {
		errorMsgArr[$("#\\$mlchanges\\$").attr('tabindex')] = "- Alternate Mailing / Address Changes are required when Yes is selected for this question.\n";
	}

	if (ge("ovnchkyes").checked && $.trim(ge("$overnight$").value) == "") {
		errorMsgArr[$("#\\$overnight\\$").attr('tabindex')] = "- Overnight Instructions are required when Yes is selected for this question.\n";
	}

}

Form.CreateSubject = function () {
	ge("$stopcancel$").disabled = false;
	form_checkstop.subject.value = "Payment/Cancellation - " + form_checkstop.$site$.value + " - " + form_checkstop.$planid$.value;
}	

Form.FormSpecificReset = function () {
	$("#ckhand").css('display','none');
	$("#less5").css('display','none');
	$("#more12").css('display','none');
	$("#reisslbl").css('display','none');
	$("#reissdiv").css('display','none');
	$("#\\$reason\\$").val('');
	$("#\\$reason\\$").prop('readOnly',true);
	$("#\\$mlchanges\\$").val('');
	$("#\\$mlchanges\\$").prop('readOnly',true);
	$("#\\$overnight\\$").val('');
	$("#\\$overnight\\$").prop('readOnly',true);
}