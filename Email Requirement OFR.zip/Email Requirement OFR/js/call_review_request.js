$(document).ready(function() {
	initializeForm();	
});

var selectConfirmDone = false;
var emailSubject = "Call Review Request - ";
var regexLetter = /[^a-zA-z\s]/;
var regexLetterNoSpace = /[^a-zA-z]/;
var regexNos = /[^0-9\s\,]/;
var regexNosNoSpace = /[^0-9]/;
var regexPhoneNo = /^((\+\d{1,3}(-| )?\(?\d\)?(-| )?\d{1,5})|(\(?\d{2,6}\)?))(-| )?(\d{3,4})(-| )?(\d{4})(( x| ext)\d{1,5}){0,1}$/;
var prevIniatials = "";
var regexPhnNumber = /^[0-9 ()-]+$/

function giveWarningAndFixValue(field) {
//removes all non-numeric value and replaces
	var value = parseInt(field.value);
	if(!isNaN(value)) field.value = value;
	else field.value = "";
	//used for NS4.7 because when changing value the cursor is placed in front of the value, instead of behind
	if(document.layers) field.select();
}

function fixValue(field, event) {
	var replaceStr = String.fromCharCode(event.keyCode);
	field.value = field.value.substring(0,field.value.length-1);
	field.value = field.value.replace(replaceStr, "");
	if(document.layers) field.select();
}

function isNumericValue(str) {
	var isValid = true;
	if(str.search(/^[0-9]+$/) == -1) {
		isValid = false;
	}
	return isValid;
}

function isAlphaValue(str) {
	var isValid = true;
	if(str.search(regexLetterNoSpace) != -1) {
		isValid = false;
	}
	prevIniatials = str;
	return isValid;
}

function checkNumber(field) {
	if(!isNumericValue(field.value)) {
		giveWarningAndFixValue(field);
	}
}

function checkAccount(field) {
	if(!isAccountValid(field.value)) {
		giveWarningAndFixValue(field);
	}
}

function isAccountValid(str) {
	var isValid = true;
	if(str.search(/^[0-9/-]+$/) == -1) {
		isValid = false;
	}
	return isValid;
}

function checkAlpha(field, event) {
	if(!isAlphaValue(field.value)) {
		fixValue(field, event);
	}
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	var selectSiteOfCallAlertMsg = "";
	var alertMsg ="";
	var alert2ndMsg ="";
	var finalAlertMsg = "";
	callrevForm.$UNKNOWNCB$.checked
	if(!callrevForm.$UNKNOWNCB$.checked){
		if($.trim($("#DATEOFCALL").val()).length ==0){
			errorMsgArr[$("#DATEOFCALL").attr('tabindex')] = "- DATE OF CALL\n";
		}
	}	
	
	if(callrevForm.callerPhoneNoCheck.checked || callrevForm.$UNKNOWNCB$.checked){
		if($.trim($("#unknownStartDate").val()).length==0 || $.trim($("#unknownEndDate").val()).length==0){
			errorMsgArr[$("#DATEOFCALL").attr('tabindex')] = "- ENTER DATE RANGE (Select DATE OF CALL as Unknown and provide a date range)\n";	
		}
	}
	var startDate = new Date($.trim($("#unknownStartDate").val()));
	var endDate = new Date($.trim($("#unknownEndDate").val()));
	if(startDate > endDate){
		errorMsgArr[$("#unknownStartDate").attr('tabindex')] = "- DATE RANGE - Start Date can not be grater than End Date\n";
	}
	
	if($("#UNKNOWNCB").prop('checked'))	{
		$("#DATERANGEVAL").val("DATE OF CALL: Unknown\nDATE RANGE: "+$.trim($("#unknownStartDate").val())+ " TO "+$.trim($("#unknownEndDate").val()));
	}else{
		$("#DATERANGEVAL").val("DATE OF CALL: "+$.trim($("#DATEOFCALL").val()));
	}
		
	if($("#callerPhoneNoCheck").prop('checked')){
		$("#callerPhoneNoCheckVal").val("YES");
	} else {
		$("#callerPhoneNoCheckVal").val("NO");
	}
	
	if($("#accountnoteadded").prop('checked')){
		$("#accountnoteaddedVal").val("Y");
	} else {
		$("#accountnoteaddedVal").val("N");
	}
}

Form.Confirm = function () {
	var answer = confirm("Have you verified that all information entered is complete?\nClick Ok to submit.");   
	return answer;
}

Form.CreateSubject = function () {
	//Sample subject line: CALL REVIEW � XXX � (RUSH) - 11111111	
	var emailSubject = "CALL REVIEW - " + $("#site_select_box").val();

	if($("#rushbox").prop('checked')){
		$("#rush").val("Y");
		emailSubject += " - (RUSH)";
	} else {
		$("#rush").val("N");
	}
	
	if($.trim($("#fundaccount").val()).length > 0){
		emailSubject += " - " + $.trim($("#fundaccount").val());
	} 
	else {
		emailSubject += " - ACCOUNT NOT PROVIDED";
	}
	$("#subject").val(emailSubject);
}

function alertselected(selectobj) {
	if(selectobj.value != "")
	{
		var answer = confirm("You selected "+selectobj.value+". Is that correct?");
		if (answer){
			return answer;
		}
		else{
			var cbo=document.getElementById('site_select_box'); 
			cbo.selectedIndex=0; 
			return answer;
		}
	} 
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
		alert("Please limit to a maximum of " + limitNum +" characters");
	}
}

function ValidatePhone1(p){
var p;  //AANS - Move this into ValidatePhone Function
	p = "";
	p = p1.value;
	if(p.length == 3){
		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ")";
		}
	p1.value=""; p1.value=pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
			p1.value=""; p1.value=pp;

		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
			pp = "(" + p13 + ")" + p14 + p15;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 2 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
			p1.value=""; p1.value=pp;
		}

	}
}

function ValidatePhone(m){
	p1 = null;
	p1 = m;
	if(regexPhnNumber.test(p1.value)){
		ValidatePhone1(p1);
	}
}

function LeftTrim(str) { // removing leading white space
    var re = /\s*((\S+\s*)*)/;
    return str.replace(re, "$1");
}

function RightTrim(str) { // removing trailing white space
    var re = /((\s*\S+)*)\s*/;
    return str.replace(re, "$1");
}

function trim(str) { // remove leading and trailing white spaces and assigning it to the text area
    return LeftTrim(RightTrim(str));
}

function lineBreakCount(str){ // return the number of line breaks in given String
    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

function checkThisString(txtArea, size){ // check the string if number of line breaks are more than entered paramater
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

function initializeForm() {
	
	if(callrevForm.$UNKNOWNCB$.checked){
		callrevForm.$UNKNOWNCB$.checked = false;
	}
	if(callrevForm.$callerPhoneNoCheck$.checked){
		callrevForm.$callerPhoneNoCheck$.checked = false;
	}
	
	$("#\\$UNKNOWNNOTE\\$").css('display','none');
}

Form.FormSpecificReset = function () {
	initializeForm();
}

function unknownCBSelection(){
	if(callrevForm.$UNKNOWNCB$.checked){
		document.getElementById("$UNKNOWNNOTE$").style.display="";
		document.getElementById("DATEOFCALL").value="";
		document.getElementById("DATEOFCALL").disabled="true";
	}else{
		document.getElementById("$UNKNOWNNOTE$").style.display="none";
		document.getElementById("DATEOFCALL").disabled='';
		document.getElementById("unknownStartDate").value="";		
		document.getElementById("unknownEndDate").value="";
	}
}
