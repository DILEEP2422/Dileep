Form.ValidateSpecificFormFields = function(errorMsgArr) {
	if(!document.getElementById("process").checked) {
		errorMsgArr[$("#process").attr('tabindex')] = "- Is RPA process established?\n";
	}
}

Form.CreateSubject = function () {
	corrections_request.subject.value = "RKD Correction Request Form - "+corrections_request.$site$.value+" - "+corrections_request.$planid$.value+" - "+corrections_request.$urgency$.value;
}