function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
		alert("Please limit to a maximum of " + limitNum +" characters");
	}
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if ((CBTComplRefForm.$REFFURGENCY$[0].checked == false) && (CBTComplRefForm.$REFFURGENCY$[1].checked == false) && (CBTComplRefForm.$REFFURGENCY$[2].checked == false)) {
		errorMsgArr[$("#REFFURGENCY").attr('tabindex')] = "- Referral Urgency\n";
	}
	
	if(CBTComplRefForm.$DEPARTMENT$.value == "CB&T"){
		if(!(CBTComplRefForm.$SITE$.value == "IND" || CBTComplRefForm.$SITE$.value == "IRV")){
			errorMsgArr[$("#DEPARTMENT").attr('tabindex')] = "-  Site should be either IND or IRV when CB&T department is selected\n";
		}
	}
	
	if($.trim(CBTComplRefForm['#approver#'].value).length == 0){	
		CBTComplRefForm['#approver#'] = '--';
	}
	
}

Form.CreateSubject = function () {
	var emailSubject = "";
	var reffUrg = document.getElementsByName('$REFFURGENCY$');
	var reffUrg_val;
	for(var i = 0; i < reffUrg.length; i++){
		if(reffUrg[i].checked){
			reffUrg_val = reffUrg[i].value;
		}
	}
	emailSubject = reffUrg_val +" - "+CBTComplRefForm.$SITE$.value+" - "+CBTComplRefForm.$REFERRALTYPE$.value+" - "+"CB&T Compliance Referral Form";
 
	CBTComplRefForm.subject.value  = emailSubject;
}