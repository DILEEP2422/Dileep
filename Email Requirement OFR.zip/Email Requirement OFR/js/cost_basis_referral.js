var selectConfirmDone = false;
var emailSubject = "Cost Basis Referral - ";
var regexLetter = /[^a-zA-z\s]/;
var regexNosNoSpace = /[^0-9]/;

Form.ValidateSpecificFormFields = function (errorMsgArr) {

	avcForm.$DELIVERY_METHOD_MAIL$.value = "";
	avcForm.$DELIVERY_METHOD_EMAIL$.value = "";
	avcForm.$DELIVERY_METHOD_FAX$.value = "";
	avcForm.$MAIL_TO_AOR$.value = "";
	avcForm.$MAIL_TO_DOR$.value = "";
	avcForm.$MAIL_TO_SPECIAL$.value = "";
	
	if(!avcForm.DELIVERY_METHOD_MAIL.checked && !avcForm.DELIVERY_METHOD_FAX.checked && !avcForm.DELIVERY_METHOD_EMAIL.checked){
		errorMsgArr[$("#DELIVERY_METHOD").attr('tabindex')] = "- DELIVERY METHOD not selected\n";	
	}

	if(!avcForm.MAIL_TO_AOR.checked && !avcForm.MAIL_TO_DOR.checked && !avcForm.MAIL_TO_SPECIAL.checked){
		errorMsgArr[$("#MAIL_TO").attr('tabindex')] = "- RECIPIENT not selected\n";	
	}

	if(avcForm.DELIVERY_METHOD_FAX.checked){
		avcForm.$DELIVERY_METHOD_FAX$.value = "FAX : Y";
		if($.trim($("#FAX").val()).length == 0){
			errorMsgArr[$("#FAX").attr('tabindex')] = "- DELIVERY METHOD - FAX is selected, but fax number is needed\n";	
		}
	}
	else if($.trim($("#FAX").val()).length > 0){
		errorMsgArr[$("#FAX").attr('tabindex')] = "- FAX number is provided, but FAX in DELIVERY METHOD is not selected\n";
	}

	if(avcForm.DELIVERY_METHOD_EMAIL.checked){
		avcForm.$DELIVERY_METHOD_EMAIL$.value = "EMAIL : Y";
		if($.trim($("#emailid").val()).length == 0){
			errorMsgArr[$("#emailid").attr('tabindex')] = "- DELIVERY METHOD - EMAIL is selected, but an email address is needed\n";	
		}
	}
	else if($.trim($("#emailid").val()).length > 0){
		errorMsgArr[$("#emailid").attr('tabindex')] = "- EMAIL ADDRESS is provided, but EMAIL in DELIVERY METHOD is not selected\n";
	}

	if(avcForm.DELIVERY_METHOD_MAIL.checked){
		avcForm.$DELIVERY_METHOD_MAIL$.value = "MAIL : Y";
	}

	if(avcForm.MAIL_TO_AOR.checked){
		avcForm.$MAIL_TO_AOR$.value = "AOR : Y";
	}

	if(avcForm.MAIL_TO_DOR.checked){
		avcForm.$MAIL_TO_DOR$.value = "DOR : Y";
	}

	if(avcForm.MAIL_TO_SPECIAL.checked){
		avcForm.$MAIL_TO_SPECIAL$.value = "SPECIAL : Y";
	}

	avcForm.$RUSH$.value = avcForm.IS_RUSH.checked ? "Y" : "N";
	avcForm.$ACCT_NOTE$.value = avcForm.ACCOUNT_NOTE.checked ? "Y" : "N";
		 
}

Form.CreateSubject = function () {
	var emailSubject = "";
	if(avcForm.IS_RUSH.checked){
		emailSubject = emailSubject + "RUSH" + " - " + avcForm.$ACCOUNT$.value + " - " + avcForm.$TYPE_OF_REQUEST$.value;
	}
	else{
		emailSubject = emailSubject + avcForm.$ACCOUNT$.value + " - " + avcForm.$TYPE_OF_REQUEST$.value;
	}
	$("#subject").val(emailSubject);	
}

Form.Confirm = function () {
	var answer = confirm('You selected - ' + $("#TYPE_OF_REQUEST").val() + ', is this correct?');
	if(answer) {
		return true;
	} else {
		$("#TYPE_OF_REQUEST").prop("selectedIndex", 0);
		return false;
	}

}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

var p;


function ValidatePhone(p1){
	
	p1.value = p1.value.replace(/ /g, "");
	p1.value = p1.value.replace(/-/g, "");
	p1.value = p1.value.replace(/\(/g, "");
	p1.value = p1.value.replace(/\)/g, "");
	

	p = "";
	p = p1.value;
	
	var new_number = "";
	new_number  = "(";
	new_number += p.substr(0,1);
	new_number += p.substr(1,1);
	new_number += p.substr(2,1);	
	if (p.length >= 3){ new_number += ") "};
	new_number += p.substr(3,1);
	new_number += p.substr(4,1);
	new_number += p.substr(5,1);
	if (p.length >= 6){ new_number += "-"};
	new_number += p.substr(6,1);
	new_number += p.substr(7,1);
	new_number += p.substr(8,1);
	new_number += p.substr(9,1);
	
	p1.value=new_number;
}
function getIt(m){
	p1 = null;
	p1 = m;
	ValidatePhone(p1);
}

// removing leading white space
function LeftTrim(str) {
    var re = /\s*((\S+\s*)*)/;
    return str.replace(re, "$1");

}

// removing trailing white space
function RightTrim(str) {
    var re = /((\s*\S+)*)\s*/;
    return str.replace(re, "$1");

}

// remove leading and trailing white spaces
// and assigning it to the text area
function trim(str) {
    return LeftTrim(RightTrim(str));
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}