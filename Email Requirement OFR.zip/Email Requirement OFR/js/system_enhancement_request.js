Form.FormSpecificReset = function() {
	document.getElementById('Other_text').value = "";
	document.getElementById('Other_text').style.display='none';  
	document.getElementById('$SITE$').focus(); 
	$("span[class='form-control']").each(function(index) {
		$(this).html("");
	});
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if ($("#systems_block label input:checked").length == 0) {
		errorMsgArr[$("#SmartDesk").attr('tabindex')] = "\n- SYSTEMS IMPACTED\n";
	} else {
		bsrForm.$SYSTEM$.value = getImpactedSystems();
	}
	
	if(document.getElementById('Other').checked == true){
		if($.trim(document.getElementById("Other_text").value).length == 0){
			errorMsgArr[$("#Other_text").attr('tabindex')] = "\n- SYSTEMS IMPACTED\n";
		} else {
			bsrForm.$SYSTEM$.value += "-" + bsrForm.$Other_text$.value;   
		}
	}
}

Form.CreateSubject = function () {
	bsrForm.subject.value = "System Enhancement Request  - ";
	bsrForm.subject.value += bsrForm.$SITE$.value + " - " + bsrForm.$DEPARTMENT$.value + " - " + bsrForm.$SYSTEM$.value;
}

function getImpactedSystems() {
	var impactedSystems = new Array();
	$("#systems_block label input:checked").each(function () {
		impactedSystems.push($(this).closest("label").text());
	});
	return impactedSystems.join(", ");
}


function toggleText() {
	if (document.getElementById('Other').checked == true) {
		document.getElementById('Other_text').style.display='inline';  
	}
	else
	{
		document.getElementById('Other_text').value = "";
		document.getElementById('Other_text').style.display='none';  
	}
}