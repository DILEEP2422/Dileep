Form.CreateSubject = function () {
	diagnosticchecklist.subject.value = "System Issue Submission - "+diagnosticchecklist.$site$.value+" - "+diagnosticchecklist.$planid$.value+" - "+
	diagnosticchecklist.$urgency$.value;
}