Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if (form_dly_adj.$flex1n$.checked && form_dly_adj.$start1$.selectedIndex == 0) {
		errorMsgArr[$("#\\$start1\\$").attr('tabindex')] = "- Adjustment Start Time\n";
	}

	if (form_dly_adj.$flex1n$.checked && form_dly_adj.$end1$.selectedIndex == 0) {
		errorMsgArr[$("#\\$end1\\$").attr('tabindex')] = "- Adjustment End Time\n";
	}
}
	  
	  
Form.CreateSubject = function () {
	rtxt = ""; // HOLDS RUSH TXT
	if(form_dly_adj.$rush$.checked){rtxt = "**RUSH** ";}
	form_dly_adj.subject.value = rtxt + "Schedule Adjustments for the Week of " + form_dly_adj.$result$.value;
}

function clearSection (id) {
	$('#'+id).children().find('input,select,textarea').each(function(){
	   $(this).val('');
	   $(this).attr('checked',false);
	});
}
					  

// SHORTCUT FUNCT:  REFERENCES & RETURNS ELEMENT W/ID OF id
function ge(id) {						  
	var anElem = document.getElementById(id);							  
	return anElem;
}


// ********** SECTION 1 FUNCTIONS **********
function enRange1() {
	ge("$start1$").disabled = false;
	ge("$end1$").disabled = false;						  
}
  
function disRange1() {
	ge("$start1$").disabled = true;
	ge("$end1$").disabled = true;						  
}
  
function togmon1() {
	if(ge("$mon1$").checked) {
		ge("$montxt1$").value = "Monday";							
	}else {
		ge("$montxt1$").value = "";								
	}
}

function togtue1() {
	if(ge("$tue1$").checked) {
		ge("$tuetxt1$").value = "Tuesday";							
	} else {
		ge("$tuetxt1$").value = "";								
	}
}

function togwed1() {
	if(ge("$wed1$").checked) {
		ge("$wedtxt1$").value = "Wednesday";							
	} else {
		ge("$wedtxt1$").value = "";								
	}
}

function togthu1(){
	if(ge("$thu1$").checked) {
		ge("$thutxt1$").value = "Thursday";							
	} else {
		ge("$thutxt1$").value = "";								
	}
}

function togfri1() {
	if(ge("$fri1$").checked) {
		ge("$fritxt1$").value = "Friday";							
	} else {
		ge("$fritxt1$").value = "";								
	}
}

// ********** SECTION 2 FUNCTIONS **********

function enRange2() {
	ge("$start2$").disabled = false;
	ge("$end2$").disabled = false;						  
}

function disRange2() {
	ge("$start2$").selectedIndex = 0;
	ge("$end2$").selectedIndex = 0;
	ge("$start2$").disabled = true;
	ge("$end2$").disabled = true;						  
}						  
  
function enSect2() {
	clearSection("tab2");
	disRange2();
	document.getElementById("tab2").style.display = 'block';
}
  
function disabSect2() {
	document.getElementById("tab2").style.display = 'none';
}						  

function togmon2() {
	if(ge("$mon2$").checked) {
		ge("$montxt2$").value = "Monday";							
	} else {
		ge("$montxt2$").value = "";								
	}
}

function togtue2() {
	if(ge("$tue2$").checked) {
		ge("$tuetxt2$").value = "Tuesday";							
	} else {
		ge("$tuetxt2$").value = "";								
	}
}

function togwed2(){
	if(ge("$wed2$").checked) {
		ge("$wedtxt2$").value = "Wednesday";							
	} else {
		ge("$wedtxt2$").value = "";								
	}
}

function togthu2(){
	if(ge("$thu2$").checked) {
		ge("$thutxt2$").value = "Thursday";							
	} else {
		ge("$thutxt2$").value = "";								
	}
}

function togfri2() {
	if(ge("$fri2$").checked) {
		ge("$fritxt2$").value = "Friday";							
	} else {
		ge("$fritxt2$").value = "";								
	}
}

// ********** SECTION 3 FUNCTIONS **********

function enRange3() {
	ge("$start3$").disabled = false;
	ge("$end3$").disabled = false;						  
}

function disRange3() {
	ge("$start3$").selectedIndex = 0;
	ge("$end3$").selectedIndex = 0;
	ge("$start3$").disabled = true;
	ge("$end3$").disabled = true;						  
}						  
  
function enSect3() {
	clearSection("tab3");
	disRange3();
	document.getElementById("tab3").style.display = 'block';
}
  
  
function disabSect3() {
	document.getElementById("tab3").style.display = 'none';
}						  

function togmon3() {
	if(ge("$mon3$").checked) {
		ge("$montxt3$").value = "Monday";							
	} else {
		ge("$montxt3$").value = "";								
	}
}

function togtue3(){
	if(ge("$tue3$").checked) {
		ge("$tuetxt3$").value = "Tuesday";							
	} else {
		ge("$tuetxt3$").value = "";								
	}
}

function togwed3() {
	if(ge("$wed3$").checked) {
		ge("$wedtxt3$").value = "Wednesday";							
	} else {
		ge("$wedtxt3$").value = "";								
	}
}

function togthu3() {
	if(ge("$thu3$").checked) {
		ge("$thutxt3$").value = "Thursday";							
	} else {
		ge("$thutxt3$").value = "";								
	}
}

function togfri3() {
	if(ge("$fri3$").checked) {
		ge("$fritxt3$").value = "Friday";							
	} else {
		ge("$fritxt3$").value = "";								
	}
}

// ********** SECTION 4 FUNCTIONS **********

function enRange4() {
	clearSection("tab4");
	disRange4();
	ge("$start4$").disabled = false;
	ge("$end4$").disabled = false;						  
}

function disRange4() {
	ge("$start4$").selectedIndex = 0;
	ge("$end4$").selectedIndex = 0;
	ge("$start4$").disabled = true;
	ge("$end4$").disabled = true;						  
}						  
  
function enSect4() {
	document.getElementById("tab4").style.display = 'block';
}

function disabSect4() {
	document.getElementById("tab4").style.display = 'none';
}						  

function togmon4() {
	if(ge("$mon4$").checked) {
		ge("$montxt4$").value = "Monday";							
	} else {
		ge("$montxt4$").value = "";								
	}
}

function togtue4() {
	if(ge("$tue4$").checked) {
		ge("$tuetxt4$").value = "Tuesday";							
	} else {
		ge("$tuetxt4$").value = "";								
	}
}

function togwed4() {
	if(ge("$wed4$").checked) {
		ge("$wedtxt4$").value = "Wednesday";							
	} else {
		ge("$wedtxt4$").value = "";								
	}
}

function togthu4() {
	if(ge("$thu4$").checked) {
		ge("$thutxt4$").value = "Thursday";							
	} else {
		ge("$thutxt4$").value = "";								
	}
}

function togfri4() {
	if(ge("$fri4$").checked) {
		ge("$fritxt4$").value = "Friday";							
	} else {
		ge("$fritxt4$").value = "";								
	}
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
	window.open(theURL,winName,features);
}

Form.FormSpecificReset = function () {
	clearSection("tab2");
	clearSection("tab3");
	clearSection("tab4");
	ge("tab2").style.display = 'none';
	ge("tab3").style.display = 'none';
	ge("tab4").style.display = 'none';
}