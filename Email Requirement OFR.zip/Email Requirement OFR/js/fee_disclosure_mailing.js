Form.FormSpecificReset = function() {
	document.getElementById('$SITE$').focus(); 
}

function returnSubjectLine(){
	
	var siteName = document.fdmForm.$SITE$.value;
	var planId = $.trim(document.fdmForm.$PLANID$.value);
	var participantId = $.trim(document.fdmForm.$PARTICIPANTACC$.value);
	
	var subjectLine = siteName;
	if (planId.length > 0)
	{
		subjectLine += " - "+ planId;
	} 
	if ((participantId.length > 0) && (planId.length > 0))
	{
		subjectLine += ", " + participantId;
	} 
	if ((planId.length == 0) && (participantId.length > 0))
	{
		subjectLine += " - "+ participantId;
	}
	return subjectLine;
}

function testLineItems() {
	form = document.fdmForm;
	form.$PLANACCOUNTINFO$.value = "";
	form.$RETURNEDMAIL$.value = "";
	form.$EXTVALUE$.value = "";
	
	var planId = $.trim(form.$PLANID$.value);
	var participantId = $.trim(form.$PARTICIPANTACC$.value);
	var currentSocialCode = $.trim(form.$CURRENTSOCIALCODE$.value);
	var extValue = $.trim(form.$EXT$.value);
	
	if (planId.length  > 0) {
	   form.$PLANACCOUNTINFO$.value += "PLAN ID: "+ planId + "\n";
	} 
	if (participantId.length > 0) {
	   form.$PLANACCOUNTINFO$.value += "\nPARTICIPANT A/C #: "+ participantId + "\n";
	} 
	if (currentSocialCode.length > 0) {
	   form.$PLANACCOUNTINFO$.value +=  "CURRENT SOCIAL CODE (Participant A/C): "+ currentSocialCode + "\n";
	}
	
	if (form.$RETURNEDMAILREC$.checked == true) {
		form.$RETURNEDMAIL$.value = "\n*RETURNED MAIL RECEIVED* \n";
	}
	
	if (extValue.length > 0) {
		form.$EXTVALUE$.value = "EXT: " + form.$EXT$.value + "\n";
	}
	
}

function lineBreakCount(str){ // return the number of line breaks in given String
    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

function checkThisString(txtArea, size){ // check the string if number of line breaks are more than entered paramater
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
		alert("Please limit to a maximum of " + limitNum +" characters");
	}
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if(($.trim(fdmForm.$PLANID$.value).length == 0) && ($.trim(fdmForm.$PARTICIPANTACC$.value).length == 0)){
		errorMsgArr[$("#PLANID").attr('tabindex')] = "- PLAN ID or PARTICIPANT A/C #\n";
	}
	
	if($.trim(fdmForm.$PARTICIPANTACC$.value).length > 0){
		if ($.trim(fdmForm.$CURRENTSOCIALCODE$.value).length == 0){
			errorMsgArr[$("#CURRENTSOCIALCODE").attr('tabindex')] = "- CURRENT SOCIAL CODE\n";
		} else if ($.trim(fdmForm.$CURRENTSOCIALCODE$.value).length < 3){
			errorMsgArr[$("#CURRENTSOCIALCODE").attr('tabindex')] = "- CURRENT SOCIAL CODE (must 3 numeric characters only)\n";
        }
    }
}

Form.CreateSubject = function () {
	testLineItems();
	fdmForm.subject.value = "408(b)(2) Fee Disclosure Mailing - "+ returnSubjectLine();
}

function isDigit(c) {
	return "0123456789".indexOf(c) > -1;
}

function getDigits(phone) {
	var newphone = "";
	var c;
	for (var i=0; i < phone.length; i++) {
    c = phone.charAt(i);
    if (isDigit(c)) newphone = newphone + c;
	}
    return newphone;
}

function getPhone(phone) {
	  var phoneDigits = getDigits(phone);
	  var newphone = "";
	  for (var i=0; i < phoneDigits.length && i < 10; i++) {
   		 if (i == 0) newphone = newphone + "(";
		 if (i == 3) newphone = newphone + ") ";
		 if (i == 6) newphone = newphone + "-";
		 newphone = newphone + phoneDigits.charAt(i);
	  }
	  return newphone;
}