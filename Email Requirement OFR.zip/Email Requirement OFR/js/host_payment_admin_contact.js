var selectConfirmDone = false;
var emailSubject = "Call Review Request - ";
var regexLetter = /[^a-zA-z\s]/;
var regexLetterNoSpace = /[^a-zA-z]/;
var regexNos = /[^0-9\s\,]/;
var regexNosNoSpace = /[^0-9]/;
var regexPhoneNo = /^((\+\d{1,3}(-| )?\(?\d\)?(-| )?\d{1,5})|(\(?\d{2,6}\)?))(-| )?(\d{3,4})(-| )?(\d{4})(( x| ext)\d{1,5}){0,1}$/;
var prevIniatials = "";
var regexPhnNumber = /^[0-9 ()-]+$/
var regexEmail = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*";
var regexEmailSimple = ".+@{1}.+[.]{1}.+";
	
function ValidateEmail(mail) 
{
	if(document.getElementById('contactemail').value != ''){
  if (document.getElementById('contactemail').value.match(regexEmailSimple))
  {
     //Form.Submit();
	 return (true)
  }
   alert("You have entered an invalid email address!")
   document.getElementById('contactemail').value = ''
   document.getElementById('contactemail').focus();
   return (false)
	}
}

function DollarAmount(amt){
	//let keyPressed = true
	if(document.getElementById('paymentamount').value != ''){
	const value = document.getElementById('paymentamount').value.replace(/,/g, '');
	let finalVal = parseFloat(value).toLocaleString('en-US', {
    style: 'decimal',
    maximumFractionDigits: 2,
    minimumFractionDigits: 2
	});	
	if(finalVal == 0.00){
		alert("Payment amount cannot be 0.");
		document.getElementById('paymentamount').value = '';
	}
	else{
		let idx = document.getElementById('paymentamount').value.indexOf('$');
		if(idx == -1){
			document.getElementById('paymentamount').value = "$"+finalVal
		}
		if(document.getElementById('paymentamount').value == '$NaN' || document.getElementById('paymentamount').value == 0){
			document.getElementById('paymentamount').value = ''
		}
	}
	}
}

function ValidatePhone1(p){
var p;  //AANS - Move this into ValidatePhone Function
	p = "";
	p = p1.value;
	if(p.length == 3){
		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ")";
		}
	p1.value=""; p1.value=pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
			p1.value=""; p1.value=pp;

		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
			pp = "(" + p13 + ")" + p14 + p15;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 2 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
			p1.value=""; p1.value=pp;
		}

	}
}
function ValidatePhone(m){
	p1 = null;
	p1 = m;
	if(regexPhnNumber.test(p1.value)){
		ValidatePhone1(p1);
	}
}

function FinalPhoneValidation(){
	if(document.getElementById('contactphone').value != ''){
		if(!document.getElementById('contactphone').value.match(regexPhnNumber))
			document.getElementById('contactphone').value = '';
	}
}

Form.CreateSubject = function () {
		//host_payment_admin_contact.subject.value =  "Host Payment Administration Contact Form-Test";
		host_payment_admin_contact.subject.value = "RKD Compensation Research – " + host_payment_admin_contact.$firmname$.value + " " + host_payment_admin_contact.$firmid$.value +" " + host_payment_admin_contact.$planid$.value ;
}

//function Send() {
	//if(host_payment_admin_contact.$feetype$.value == "")
		//host_payment_admin_contact.$feetype$.value = "NA";
	//if(host_payment_admin_contact.$request$.value == "")
		//host_payment_admin_contact.$request$.value = "NA";
	//Form.Submit();
//}