var index=1;

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

Form.OnSuccess = function () {
	Form.ShowDialog();
	$("#confirmationAlert").html("Your request is submitted successfully");
	$(".modal-content.submissionResult").addClass('success');
	$(".modal-content.submissionResult .btn").toggleClass('btn-success', true);
	$(".modal-content.submissionResult .btn").toggleClass('btn-danger', false);
	$(".modal-content.submissionResult .btn").click( function() { $("#cdscForm").hide(); $("#cdscConfirmation").show(); });
}

Form.FormSpecificReset = function () {
	$(".add").click(function(){	addLineItems();});
	$(".add").keydown(function(event){if (event.which == 32) addLineItems();});
	$(".delete").click(function(){$(this).parent().parent().remove(); index--; reindexRows();recalculateTotals(); });
	$("input.processingAmount").blur(function(){recalculateTotals();});
	
	$("#cdscConfirmation").hide();
	$("#cdscForm").show();
	resetConfirmationSection();
	
	document.btiForm.reset();
	document.getElementById('$SITE$').focus();
	$("#cdscFeesTable").empty();	
	
	index=1;
	
	$("#cdscFeesTable #cdscFeesSection"+index).remove();
	$("#cdscFeesTable").append($("#cdscFeesLineTemplate #templatecdscFeesSection").clone(true).attr('id',"cdscFeesSection"+index)); 
	$("#cdscFeesTable #cdscFeesSection"+index).find("input.processingAmount").autoNumeric({aSign: '$'});
	$("#processingTotalReadOnly").text("$0.00");
	reindexRows();
	index++;
}

function alertselected(selectobj) {
	if(selectobj.value != "")
	{
		var answer = confirm("You selected "+selectobj.value+". Is that correct?");
		if (answer){
			return answer;
		}
		else{
			var cbo=document.getElementById('$SITE$'); 
			cbo.selectedIndex=0;
			return answer;
		}
	}
}

function getUniqueAccountNumbers() {
	var accountNumbers = new Array();

	$("input.accountNumber").each(function (){
		if (this.value != "") {accountNumbers.push((this).value);}
	});
	
	var uniqueAccountNumbers = new Array();
	var numberOfAccounts = accountNumbers.length;
	
	for (var i=0; i<numberOfAccounts; i++) {
		for(var j=i+1; j<numberOfAccounts; j++)
			if (accountNumbers[i] === accountNumbers[j]) {
				j = ++i;
			}
			uniqueAccountNumbers.push(accountNumbers[i]);
	}
	
	uniqueAccountNumbers = uniqueAccountNumbers.sort(sortNumber);
	return uniqueAccountNumbers.join(", ");
}

function sortNumber(a,b) {
	return a - b;
}

function recalculateTotals() {
	var total = 0.00;
	$("input.processingAmount").each(function(){
		total += parseFloat($(this).autoNumericGet());
	});
	
	$("#processingTotal").autoNumericSet(total, {aSign: '$', vMin: '0.00', vMax: '99999999999.99'});
	$("#processingTotalReadOnly").text($("#processingTotal").val());
}

function addLineItems(){
	$("#cdscFeesLineTemplate #templatecdscFeesSection").clone(true).attr('id',"cdscFeesSection"+index).insertAfter("#cdscFeesTable #cdscFeesSection"+(index-1)+":last"); 
	$("#cdscFeesTable #cdscFeesSection"+index).find("input.fund").focus();
	$("#cdscFeesTable #cdscFeesSection"+index).find(".processingAmount").autoNumeric({aSign: '$'});
	reindexRows();
	index++;
}

var lineItemErrors = "";

function reindexRows(){
	$(".index").each(function(index){
		$(this).html(index+1);
	});
	
	var count = $("div[id^='cdscFeesSection']").length;
	
	if (count == 1) $(".delete").hide();
	else $(".delete").show();

	if (count == 20) $(".add").hide();
	else $(".add").show();
}

var cdscItemString = "";

function testLineItems(errorMsgArr) {
	lineItemErrors = "";
	blankLine = false;
	document.btiForm.$CDSCLINES$.value = "";
	var cdscHeader ="[";
	var cdscFooter = "]";
	
	cdscItemString =cdscHeader;

	$("div[id^='cdscFeesSection']").each(function(index) {
		var lineIndex = index + 1;
		var lineFundNumber = $.trim($(this).find("input.fund").val());
		var lineAccount = $(this).find("input.accountNumber").val();
		var processingAmount = $.trim($(this).find("input.processingAmount").val());
		
		//test if any cells have value
		if (lineFundNumber.length > 0 || lineAccount.length > 0 || processingAmount.length > 0) {
			//test that all cells have value
			if (lineFundNumber.length > 0 && lineAccount.length > 0 && processingAmount.length > 0) {
				//if they do create the Batch Ticket Lines to pass to the mail servlet
				document.btiForm.$CDSCLINES$.value += padSpacesToRight(lineFundNumber, 7);
				document.btiForm.$CDSCLINES$.value += padSpacesToRight(lineAccount, 15);  
				document.btiForm.$CDSCLINES$.value += padSpacesToLeft(processingAmount, 18) + "\n";
				
				cdscItemString +="{\"fund\":"+lineFundNumber+",\"account\":"+lineAccount+",\"dollaramt\":\""+processingAmount+"\""+"},";
			}
			//otherwise indicate that the line is incomplete
			else lineItemErrors += " - CDSC FEES: Line # " + lineIndex + " is incomplete\n";
		} else {
			blankLine = true;
		}		
	});
	cdscItemString = cdscItemString.substring(0,cdscItemString.lastIndexOf(','));
	cdscItemString += cdscFooter;
	
	if (blankLine) lineItemErrors = " - At least one CDSC FEES line must be complete\n" + lineItemErrors;
	
	if(lineItemErrors.length > 0) {
		errorMsgArr[$("#COMMENTS").attr('tabindex')] = lineItemErrors;
	}
}



function padSpacesToRight(inputstring, totalLength){
	var returnstr=inputstring;
	for (var i = inputstring.length; i<totalLength; i++) {
		returnstr += " ";
	}
	return returnstr;
}

function padSpacesToLeft(inputstring, totalLength){
	var returnstr="";
	for (var i = 1; i<totalLength-inputstring.length; i++) {
		returnstr += " ";
	}
	returnstr += inputstring;
	return returnstr;
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	
	if (btiForm.$MEMOACCOUNT$.checked == false) { 
		errorMsgArr[$("#MEMOACCOUNT").attr('tabindex')] = "\n- MEMO ACCOUNT\n";
	}
	
	testLineItems(errorMsgArr);
	
	btiForm.$TOTAL$.value = "TOTAL:" + padSpacesToLeft($("#processingTotalReadOnly").text(), 34);
	if (btiForm.$MEMOACCOUNT$.checked == true) { 
		btiForm.$MEMOACC$.value = "Y";
	} else if(btiForm.$MEMOACCOUNT$.checked == true) {
		btiForm.$MEMOACC$.value = "N";
	}
	btiForm.$CDSCITEMSTRING$.value = cdscItemString;
	btiForm.$AMOUNTTOTAL$.value = $("#processingTotalReadOnly").text();
	
}

Form.CreateSubject = function () {
	btiForm.subject.value = "CDSC FEES - " +btiForm.$SITE$.value+ " - " + getUniqueAccountNumbers();
	updateConfirmationSection();
}

function resetConfirmationSection()
{
	$("#confirmationSite").html("");
	$("#confirmationExt").html("");
	$("#confirmationMemoAccount").html("");
	$("#confirmationSubmittedDate").html("");
	$("#confirmationAdditionalComments").html("");
	$("#confirmationCDSCFeesTable").html("");
	$("#confirmationTotal").html("");
}

function updateConfirmationSection()
{
	$("#confirmationSite").html(btiForm.$SITE$.value);
	$("#confirmationExt").html(btiForm.$EXT$.value);
	$("#confirmationMemoAccount").html(btiForm.$MEMOACC$.value);
	$("#confirmationSubmittedDate").html(new Date());
	$("#confirmationAdditionalComments").html(btiForm.$COMMENTS$.value);
	
	var divRow = "<div class='row'>";
	var divCol = "<div class='col-sm-4'>";
	var closingDiv = "</div>";
	
	var cdscFeesTable = "";
	$("div[id^='cdscFeesSection']").each(function(index) {
		var lineIndex = index + 1;
		var lineFundNumber = $.trim($(this).find("input.fund").val());
		var lineAccount = $(this).find("input.accountNumber").val();
		var processingAmount = $.trim($(this).find("input.processingAmount").val());
		
		cdscFeesTable += divRow + divCol + lineFundNumber + closingDiv +
						divCol + lineAccount + closingDiv +
						divCol + processingAmount + closingDiv +
						closingDiv;
	});
	$("#confirmationCDSCFeesTable").html(cdscFeesTable);
	$("#confirmationTotal").html($("#processingTotalReadOnly").text());
}