function toggleicweb() {
	var bool = ge("$ictoweb$").checked;
	if(bool) {
		hideicweb();
	} else {
		showicweb();
	}	
}

function hideicweb() {
	// hide fields if ic to web
	ge("genimpwf").style.display = "none";
	ge("recipientSection").style.display = "none";
	ge("$procreq$").value = "Callback Required";
}
	  
function showicweb() {
	// hide fields if ic to web
	ge("genimpwf").style.display = "block";
	ge("recipientSection").style.display = "block";
	ge("$procreq$").value = "";
}
						
function ge(id) {
	var myelement = document.getElementById(id);
	return myelement;
}

// CONVERT RECIP TO UPPER-CASE
function upperText(id) {
	document.getElementById(id).value = document.getElementById(id).value.toUpperCase();
}

// TOGGLE
function toggleRecip() {
	if(form_phonemessage.$icroute$.checked) {
		document.getElementById("recipientSection").style.display = "none";
		document.getElementById("icrushdiv").style.display = "block";
		document.getElementById("icwebdiv").style.display = "none";														
	} else {
		document.getElementById("recipientSection").style.display = "block";
		document.getElementById("icrushdiv").style.display = "none";	
		document.getElementById("icwebdiv").style.display = "block";							
		document.getElementById("$icrush$").checked = false;
		document.getElementById("#recipinits#").value = "";
		document.getElementById("#recipmgr#").value = "";
	}
}

Form.FormSpecificReset = function () {
	ge("genimpwf").style.display = "block";
	document.getElementById("icwebdiv").style.display = "block";
	document.getElementById("recipientSection").style.display = "block";
	document.getElementById("icrushdiv").style.display = "none";
	document.getElementById("$icrush$").checked = false;
	document.getElementById("$amark$").value = "";
	document.getElementById("$tnote$").value = "";
	document.getElementById("$rnote$").value = "";
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	  
	if (!form_phonemessage.$icroute$.checked && !form_phonemessage.$ictoweb$.checked && $.trim(ge("#recipinits#").value) == "") {
		errorMsgArr[$("#\\#recipinits\\#").attr('tabindex')] = "- Recipient's Initials\n";
	} 
	
	if (!form_phonemessage.$icroute$.checked && !form_phonemessage.$ictoweb$.checked &&	$.trim(ge("#recipmgr#").value) == "") {
		errorMsgArr[$("#\\#recipmgr\\#").attr('tabindex')] = "- Recipient's Manager Initials\n";
	} 
	
	if (!form_phonemessage.amyes.checked && !form_phonemessage.amno.checked) {
		errorMsgArr[$("#amyes").attr('tabindex')] = "- Received After Market Close\n";
	}
}

Form.CreateSubject = function () {

	if(form_phonemessage.amyes.checked){document.getElementById("$amark$").value = "Yes";}
	if(form_phonemessage.$tracnoted$.checked){document.getElementById("$tnote$").value = "Yes";}
	if(form_phonemessage.$rpanoted$.checked){document.getElementById("$rnote$").value = "Yes";}	

	var icrushval = "";	

	if (form_phonemessage.$icrush$.checked) {
		icrushval = "** RUSH ** ";
	}
	
	if (form_phonemessage.$icroute$.checked) {
		form_phonemessage.subject.value = icrushval + "RKD Phone Message form **ROUTED TO WORKFLOW** RE: "+	form_phonemessage.$planid$.value+" - "+ form_phonemessage.$planname$.value+" - "+form_phonemessage.$procreq$.value;	
	} else if (!form_phonemessage.$icroute$.checked && !form_phonemessage.$ictoweb$.checked && $.trim(ge("#recipinits#").value) != "") {
		form_phonemessage.Qualifier.value = "Workflow_Web_NotChecked";
		form_phonemessage.subject.value = "RKD Phone Message form - ["+ge("#recipinits#").value+"] RE: "+ form_phonemessage.$planid$.value + " - " + form_phonemessage.$planname$.value + " - " + form_phonemessage.$procreq$.value;	
	} else if (!form_phonemessage.$icroute$.checked && form_phonemessage.$ictoweb$.checked) {
		form_phonemessage.Qualifier.value = "Workflow_NotChecked_Web_Checked";
		form_phonemessage.subject.value = "RKD Phone Message From "+" (IC TO WEBSME) RE: "+ form_phonemessage.$planid$.value + " - " + form_phonemessage.$planname$.value;
	}
} 