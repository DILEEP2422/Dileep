Form.CreateSubject = function () {
	  form_invoice.subject.value = "Invoice Request Form - "+form_invoice.$invoicetype$.value+" - "+form_invoice.$planid$.value;
}