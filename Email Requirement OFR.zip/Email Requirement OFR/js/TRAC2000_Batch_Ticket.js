/* Group Plan Section */
$("#addPlan").click(function(){addLineItems();});
$("#addPlan").keydown(function(event){if (event.which == 32) addLineItems();});
$("input.processingAmount").blur(function(){recalculateTotals(); recalculateTotalsVar()});
$("#deletePlan").click(function(){$(this).parent().parent().parent().remove();reindexRows();recalculateTotals();});


/* Varience Section */
$("#addVariance").click(function(){addLineItemsVar();});
$("#addVariance").keydown(function(event){if (event.which == 32) addLineItemsVar();});
$("input.varianceamount").blur(function(){recalculateTotals(); recalculateTotalsVar();});
$("#deleteVariance").click(function(){$(this).parent().parent().parent().remove();reindexRowsVar();recalculateTotalsVar()});
$("select.variance").change(function(){
	recalculateTotalsVar();
});

/* Check Section  */
$("#addCheck").click(function(){addLineItemsCheck();});
$("#addCheck").keydown(function(event){if (event.which == 32) addLineItemsCheck();});
$("#deleteCheck").click(function(){$(this).parent().parent().parent().remove();reindexRowsCheck();recalculateCheckTotals();});
$("input.checkamount").blur(function(){recalculateCheckTotals();});

$("#\\$deposit_total\\$").blur(function(){
	$("#\\$deposit_total\\$").autoNumericSet($("#\\$deposit_total\\$").val(), {vMin: '0.00', vMax: '99999999999.99'});
});

var today = new Date();

function recalculateTotalsVar() {
	var varianceArr = new Array();
	var varianceAmtArr = new Array();
	var newPlusSum = 0.00;
	var i=0;
	
	var subtotal = $("#processingTotalReadOnly").text();
		
	$("select.variance").each(function(){
		varianceArr[i] = $(this).val();
		i++;
	});
	i=0;	
	$("input.varianceamount").each(function() {
		varianceAmtArr[i] = $(this).autoNumericGet();
		i++;
	});
	for(var i=0;i<varianceArr.length;i++) {
		if(isNaN(parseFloat(varianceAmtArr[i]))) {
			varianceAmtArr[i] = 0;
		}
		if(varianceArr[i] == "Allowance-Shortage") {
			varianceAmtArr[i] = (varianceAmtArr[i] * -1);
		}
		newPlusSum = newPlusSum + parseFloat(varianceAmtArr[i]);
	}	
	trac2000Form.$PROCESSING_TOTAL_Hidden$.value =  parseFloat(totalvrt + newPlusSum).toFixed(2);
	$("#PROCESSING_TOTAL_Hidden").autoNumericSet(trac2000Form.$PROCESSING_TOTAL_Hidden$.value, {vMin: '-99999999999.99', vMax: '99999999999.99'});
	$("#varianceprocessingTotalReadOnly").text("$ "+trac2000Form.$PROCESSING_TOTAL_Hidden$.value);
}

var totalvrt = 0.00;
function recalculateTotals() {
	totalvrt = 0.00;
	$("input.processingAmount").each(function() {
		if($(this).val() != '') {
			totalvrt += parseFloat($(this).autoNumericGet());
		}
	});
	$("#processingTotalSum").autoNumericSet(totalvrt, {vMin: '-99999999999.99', vMax: '99999999999.99'});
	$("#processingTotalReadOnly").text("$ "+$("#processingTotalSum").val()); 
}

function recalculateCheckTotals() {
	var total = 0.00;
	$("input.checkamount").each(function() {
		if($(this).val() != '') {
			total += parseFloat($(this).autoNumericGet());
		}
	});
	
	$("#totalCheckSum").autoNumericSet(total, {vMin: '-99999999999.99', vMax: '99999999999.99'});
	$("#allcheckTotalReadOnly").text("$ "+$("#totalCheckSum").val());
	$("#total_all_check").autoNumericSet(total, {vMin: '-99999999999.99', vMax: '99999999999.99'});
}

function addLineItems() {
	$("#groupLineTemplate .groupLineTemplateSection").clone(true).insertAfter("#groupPlanTable .groupLineTemplateSection:last"); 
	$("#groupPlanTable .groupLineTemplateSection:last").find("input.groupplan").focus();
	$("#groupPlanTable .groupLineTemplateSection:last").find("input.processingAmount").autoNumeric();
	reindexRows();
}

function addLineItemsVar() {
	$("#varianceTemplate .varianceTemplateSection").clone(true).insertAfter("#varianceTable .varianceTemplateSection:last"); 
	$("#varianceTable .varianceTemplateSection:last").find("select.variance").focus();
	$("#varianceTable .varianceTemplateSection:last").find("input.varianceamount").autoNumeric();
	reindexRowsVar();
}

function addLineItemsCheck() {
	$("#checkTabularListTemplate .checkTabularListTemplateSection").clone(true).insertAfter("#checkTabularList .checkTabularListTemplateSection:last"); 
	$("#checkTabularList .checkTabularListTemplateSection:last").find("input.check").focus();
	$("#checkTabularList .checkTabularListTemplateSection:last").find("input.checkamount").autoNumeric();
	reindexRowsCheck();
}

function reindexRows() {
	$(".index").each(function(index) {
		$(this).html(index+1);
	});

	if ($("#groupPlanTable .groupLineTemplateSection").length == 1) 
		$("#deletePlan").hide();
	else 
		$("#deletePlan").show();

	if ($("#groupPlanTable .groupLineTemplateSection").length == 20) 
		$("#addPlan").hide();
	else
		$("#addPlan").show();
}

function reindexRowsVar(){
	$(".index1").each(function(index1){
		$(this).html(index1+1);
	});

	if ($("#varianceTable .varianceTemplateSection").length == 1) 
		$("#deleteVariance").hide();
	else 
		$("#deleteVariance").show();

	if ($("#varianceTable .varianceTemplateSection").length == 20) 
		$("#addVariance").hide();
	else 
		$("#addVariance").show();
}

function reindexRowsCheck(){
	$(".index2").each(function(index2){
		$(this).html(index2+1);
	});

	if ($("#checkTabularList .checkTabularListTemplateSection").length == 1) 
		$("#deleteCheck").hide();
	else 
		$("#deleteCheck").show();

	if ($("#checkTabularList .checkTabularListTemplateSection").length == 20) 
		$("#addCheck").hide();
	else 
		$("#addCheck").show();
}

Form.FormSpecificReset = function () {
	resetConfirmation();
	document.getElementById("confirmsection").style.display = "none";
	document.getElementById("trac2000Form").style.display = "block";
	
	$("#groupPlanTable").empty();
	$("#groupPlanTable").append($("#groupLineTemplate .groupLineTemplateSection").clone(true));
	$("#groupPlanTable .groupLineTemplateSection:last").find("input.processingAmount").autoNumeric();
	reindexRows();
	
	$("#varianceTable").empty();
	$("#varianceTable").append($("#varianceTemplate .varianceTemplateSection").clone(true));
	$("#varianceTable .varianceTemplateSection:last").find("input.varianceamount").autoNumeric();
	reindexRowsVar();
	
	$("#checkTabularList").empty();
	$("#checkTabularList").append($("#checkTabularListTemplate .checkTabularListTemplateSection").clone(true));
	$("#checkTabularList .checkTabularListTemplateSection:last").find("input.checkamount").autoNumeric();
	reindexRowsCheck();
	
	$("#processingTotalReadOnly").text("$ " +"0.00");
	$("#varianceprocessingTotalReadOnly").text("$ "+"0.00");
	$("#allcheckTotalReadOnly").text("$ "+"0.00");
	
	document.getElementById("wireSection").style.display="none";
	document.getElementById("checkSection").style.display="none";
			
	totalvrt = 0.00;
}

function achChecked(obj) {
	if(obj.checked) {
		document.getElementById("fileAttachment1").value = "";
		trac2000Form.$CHECKBOX_Hidden$.value = "ACH";
		trac2000Form.$check1$.checked = false;
		trac2000Form.$wire$.checked = false;
		document.getElementById("checkSection").style.display="none";
		document.getElementById("wireSection").style.display="none";
		$("#checkTabularList").empty();
		$("#checkTabularList").append($("#checkTabularListTemplate .checkTabularListTemplateSection").clone(true));
		$("#checkTabularList .checkTabularListTemplateSection:last").find("input.checkamount").autoNumeric();
		reindexRowsCheck();
	} else {
		trac2000Form.$CHECKBOX_Hidden$.value = "";
	}
}

function checkChecked(obj) {
	if(obj.checked) {
		trac2000Form.$CHECKBOX_Hidden$.value = "CHECK";
		trac2000Form.$ach$.checked = false;
		trac2000Form.$wire$.checked = false;
		document.getElementById("fileAttachment1").value = "";
		document.getElementById("wireSection").style.display="none";
		document.getElementById("checkSection").style.display="block";
	} else {
		trac2000Form.$CHECKBOX_Hidden$.value = "";
		document.getElementById("checkSection").style.display="none";
	}
}

function wireChecked(obj) {
	if(obj.checked) {
		document.getElementById("fileAttachment1").value = "";
		trac2000Form.$CHECKBOX_Hidden$.value = "WIRE";
		trac2000Form.$ach$.checked = false;
		trac2000Form.$check1$.checked = false;
		document.getElementById("wireSection").style.display="block";
		document.getElementById("checkSection").style.display="none";
		$("#checkTabularList").empty();
		$("#checkTabularList").append($("#checkTabularListTemplate .checkTabularListTemplateSection").clone(true));
		$("#checkTabularList .checkTabularListTemplateSection:last").find("input.checkamount").autoNumeric();
		reindexRowsCheck();
	} else {
		trac2000Form.$CHECKBOX_Hidden$.value = "";
		document.getElementById("wireSection").style.display="none";
	}
}

function alertselected(selectobj) {
	if(selectobj.value != "") {
		var answer = confirm("You selected "+selectobj.value+". Is that correct?");
		if (answer) {
			return answer;
		} else{
			selectobj.selectedIndex=0;
		}
	}
}

var lineItemGPlanErrors="";
var gpItemString = "";

function testGplanLineItem(trac2000Form) {
	lineItemGPlanErrors = "";
	gpItemString = "";
	trac2000Form.$GROUPPLANLINES$.value="";
	
	$("#groupPlanTable .groupLineTemplateSection").each(function(index) {
		var lineIndex = index + 1;
		var linegroupPlan = $.trim($(this).find("input.groupplan").val());
		var processingAmount = $.trim($(this).find("input.processingAmount").val());
		
		if((linegroupPlan.length > 0) && (processingAmount.length > 0)) {
			trac2000Form.$GROUPPLANLINES$.value += "<tr><td style='width: 10%'>" + linegroupPlan + "</td><td style='width: 20%;'>$ " + processingAmount + "</td></tr>";
			gpItemString = gpItemString + linegroupPlan + ":";		
		} else {	
			lineItemGPlanErrors += "- PLAN ID: Line # " + lineIndex + " is incomplete\n";
		}
	});
}

var lineItemVarianceErrors="";

function testVarianceLineItem(trac2000Form) {
	lineItemVarianceErrors = "";
	trac2000Form.$VARIANCELINES$.value="";
	
	var varianceHeader= "VARIANCE TYPE:  	VARIANCE AMOUNT: 	ACCOUNT# / PARTICIPANT NAME & SSN / TRAC Plan ID:";
	
	$("#varianceTable .varianceTemplateSection").each(function(index) {
		var lineIndex = index + 1;
		var lineVarianceCombo = $(this).find("select.variance").val();
		var lineVarianceAmount = $.trim($(this).find("input.varianceamount").val());
		var lineactparticipant  = $.trim($(this).find("input.accountparticipant").val());
		
		if(lineVarianceCombo.length > 0) {
			if(lineVarianceAmount.length > 0) {
				trac2000Form.$VARIANCELINES$.value += "<tr><td style='width: 15%'>" + lineVarianceCombo + "</td><td style='width: 20%;'>$ " + lineVarianceAmount + "</td><td style='width: 45%'>" + lineactparticipant + "</td></tr>";
			} else {	
				lineItemVarianceErrors += "- VARIANCE: Line # " + lineIndex + " is incomplete\n";
			}
		}
	});
}

var lineItemCheckErrors="";
var linevalCheck="";
function testCheckLineItem(trac2000Form) {
	linevalCheck = "";
	lineItemCheckErrors = "";
	trac2000Form.$CHECKLINES$.value="";
	
	var checkHeader = "<table style='width: 30%'><tr><td style='width: 20%'>CHECK #(S)</td><td style='width: 30%'>CHECK AMOUNT(S)</td></tr>"; 
	
	$("#checkTabularList .checkTabularListTemplateSection").each(function(index) {
		var lineIndex = index + 1;
		var linecheck = $(this).find("input.check").val();
		var lineCheckAmount = $.trim($(this).find("input.checkamount").val());
		
		if(linecheck.length != 0 && lineCheckAmount.length == 0) {
			linevalCheck = "- CHECK AMT(S) " + "\n";
		}
		
		if(lineCheckAmount.length != 0 && linecheck.length == 0) {
			linevalCheck = "- CHECK #(S) " + "\n"; 
		}
		
		if((linecheck.length > 0) && (lineCheckAmount.length > 0)) {
			trac2000Form.$CHECKLINES$.value += "<tr><td style='width: 20%'>"+linecheck+"</td><td style= 'width: 30%'>$ " + lineCheckAmount + "</td></tr>";
		} else {	
			lineItemCheckErrors += "- CHECK : Line # " + lineIndex + " is incomplete\n";
		}
	});
	trac2000Form.$CHECKLINES$.value = checkHeader + trac2000Form.$CHECKLINES$.value;
	trac2000Form.$CHECKLINES$.value += "<tr><td style='width: 20%'>TOTAL OF ALL CHECKS</td><td style= 'width: 30%'>$ " + $("#totalCheckSum").val() + "</td></tr></table>";
}

var dateflag = false;
function dateCheck() {
	var d = new Date();
	var date = ("0" + d.getDate()).slice(-2);
	var month = ("0" + (d.getMonth() + 1)).slice(-2);
	var year = d.getFullYear();
	var today1 = (month+"/"+date +"/"+year);
	if(today1 == document.trac2000Form.$tradeDate$.value) { 
		dateflag = true;
	} else {
		dateflag = false;
	}
}

Form.ValidateSpecificFormFields = function (errorMsgArr) { 
	
	if($.trim(trac2000Form.$reason_code$.value) != "") {
		if($.trim(trac2000Form.$nonCurrentDate$.value) == "") {
			errorMsgArr[$("#\\$nonCurrentDate\\$").attr('tabindex')] = "- Non-Current Date\n";
		}
		trac2000Form.$REASONHIDDEN$.value = "REASON CODE: " + trac2000Form.$reason_code$.value;
	}
	
	if($.trim(trac2000Form.$nonCurrentDate$.value) != "") {
		if($.trim(trac2000Form.$reason_code$.value) == "") {		
			errorMsgArr[$("#\\$reason_code\\$").attr('tabindex')] = "- Reason Code\n";
		}
		trac2000Form.$hiddenNonCurrent$.value = "NON-CURRENT DATE: " + trac2000Form.$nonCurrentDate$.value;
	}
	
	if($.trim(trac2000Form.$batchid$.value) != "") {
		trac2000Form.$BATCHHIDDEN$.value = "BATCH ID #: " + trac2000Form.$batchid$.value ;
	}
	
	testGplanLineItem(trac2000Form);		
	if($.trim(lineItemGPlanErrors) != "") {
		errorMsgArr[$("input.groupplan:first").attr('tabindex')] = lineItemGPlanErrors;
	}
	
	testVarianceLineItem(trac2000Form);	
	if($.trim(lineItemVarianceErrors) != "") {
		errorMsgArr[$("input.varianceamount:first").attr('tabindex')] = lineItemVarianceErrors;
	}
	
	if($.trim($("#\\#tmsm\\#").val()) != "") {
		trac2000Form.$APPROVERHIDDEN$.value = "APPROVER: " + $("#\\#tmsm\\#").val(); 
	}
	
	if(!(trac2000Form.$ach$.checked || trac2000Form.$check1$.checked || trac2000Form.$wire$.checked )) {
		errorMsgArr[$("#\\$ach\\$").attr('tabindex')] = "- Payment Type\n";
	}
	
	if(trac2000Form.$check1$.checked) {
		testCheckLineItem(trac2000Form);
		if($.trim(lineItemCheckErrors) != "") {
			errorMsgArr[$("input.check:first").attr('tabindex')] = lineItemCheckErrors;
		}
	}
	
	if($.trim(trac2000Form.$additional_comments$.value) != "") {
		trac2000Form.$ADDCOMMENTSHID$.value = "ADDITIONAL COMMENTS: <br/>"+ trac2000Form.$additional_comments$.value;
	}
}

Form.Confirm = function () {
	var dpvalue = trac2000Form.$deposit_total$.value;
	if(dpvalue != trac2000Form.$PROCESSING_TOTAL_Hidden$.value) {
		var retVal = confirm("The Processing Total does not match the Deposit Total. Are the amounts correct? \r Click OK to SUBMIT FORM \r Click Cancel to GO BACK TO REVIEW");
		return retVal;
	} else {
		return true;
	}
}

Form.CreateSubject = function () {
	createEmailSubject(trac2000Form);
	trac2000Form.subject.value  = emailSubject ;
}

Form.OnSuccess = function () {
	Form.ShowDialog();
	$("#confirmationAlert").html("Your request is submitted successfully");
	$(".modal-content.submissionResult").addClass('success');
	$(".modal-content.submissionResult .btn").toggleClass('btn-success', true);
	$(".modal-content.submissionResult .btn").toggleClass('btn-danger', false);
	
	if(trac2000Form.$SOURCETYPE$.value == "Paper") {
		var showdate = new Date();
		
		$("#fieldDepositTotal").html("$"+trac2000Form.$deposit_total$.value);
		$("#fieldPlanType").html(trac2000Form.$planName$.value);
		$("#fieldTradeDate").html(trac2000Form.$tradeDate$.value);
		$("#fieldBatchNumber").html(trac2000Form.$batchid$.value);
				
		if($.trim(trac2000Form.$reason_code$.value) == "") {
			$("#fieldReasonCode").hide();
			$("#reasonCodeLabel").hide();
		} else if($.trim(trac2000Form.$reason_code$.value) != "") {
			$("#fieldReasonCode").show();
			$("#reasonCodeLabel").show();
			$("#fieldReasonCode").html(trac2000Form.$reason_code$.value);
		}
		
		$("#loadtime").html(showdate.toString());
		dateCheck();
		if(dateflag == false){
			document.getElementById("showmessage").style.display="block";
		}
		$(".modal-content.submissionResult .btn").click( function() { $("#trac2000Form").hide(); $("#confirmsection").show(); });
	} else {
		$(".modal-content.submissionResult .btn").click( function() { Form.EnableForm(); Form.FormReset(); });
	}
}
	
function resetConfirmation() {
	$("#fieldDepositTotal").html("");
	$("#fieldPlanType").html("");
	$("#fieldTradeDate").html("");
	$("#fieldBatchNumber").html("");
	$("#fieldReasonCode").html("");
	$("#loadtime").html("");
	$("#showmessage").css("display","none");
}

var emailSubject = "";
function createEmailSubject(trac2000Form) {
	emailSubject = "TRAC";	
	emailSubject += " - ";
	emailSubject += trac2000Form.$site$.value;
	emailSubject += " - ";
	emailSubject += trac2000Form.$CHECKBOX_Hidden$.value;
	emailSubject += " - ";
		
	var gparray = new Array(); 
	gparray = gpItemString.split(":");

	if(gparray.length !=0 ) {		
		for(var i =0; i< gparray.length ;i++) {
			if(i<gparray.length-2) {
				if(i<3) { 
					emailSubject = emailSubject + gparray[i] + ", ";
				} else if(i==3) {
					emailSubject = emailSubject + gparray[i];
					break;	
				}		
			}
			if(i == gparray.length-2) {
				emailSubject = emailSubject + gparray[i];
			}
		}
	}
	emailSubject += "  $"+ trac2000Form.$deposit_total$.value;
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}
