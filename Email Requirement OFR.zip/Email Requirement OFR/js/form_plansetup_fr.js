Form.CreateSubject = function () {
	if (ge("$flex$").checked){
		form_plansetup_fr.Qualifier.value = "Flex";
	} else {
		form_plansetup_fr.Qualifier.value = "";
	}		
	form_plansetup_fr.$results$.value = buildResult();
		
	form_plansetup_fr.subject.value = "New Plan Setup - Follow Up Required ("+
			ge("#ic#").value+") - " + 
			form_plansetup_fr.$planid$.value + " - " +
			form_plansetup_fr.$planname$.value;
}

// BUILD THE RESULT STRING @build

function buildResult() {
	
	var theresult = "";
	
	if (ge("$retnps$").checked) {
		theresult += "\n\nRETURNING NEW PLAN SETUP DOCUMENTS / FOLLOW UP REQUIRED:\n\n";			
	}

	if (ge("$psmiss$").checked) {
		theresult += "\n*Plan sponsor name / plan name missing or incomplete\n";			
	}

	if (ge("$pcmiss$").checked) {
		theresult += "\n*Plan primary contact / trustee / signers missing or incomplete\n";			
	}
	
	if (ge("$mtmiss$").checked) {
		theresult += "\n*No money types provided / Money type discrepancy (see comments below)\n";			
	}

	if (ge("$loanhardblank$").checked) {
		theresult += "\n*Loan or hardship information left blank (old plan specifications form)\n";			
	}

	if (ge("$vestingnot$").checked) {
		theresult += "\n*Vesting schedule not provided / incomplete\n";			
	}

	if (ge("$scnot$").checked) {
		theresult += "\n*Share class or investments not provided\n";			
	}

	if (ge("$more20$").checked) {
		theresult += "\n*More than 20 investment options--No pending approval\n";			
	}
		if (ge("$mfplandefault$").checked) {
		theresult += "\n*Plan default fund not specified\n";			
	}
	if (ge("$retnpsother$").checked) {
		theresult += "\n*Other--see comments below\n";			
	}
				
	////////////////////////////////// NEXT STEPS SECTION

	if (ge("$retnsd$").checked) {
		theresult += "\n\nRETURNING NEXT STEPS DOCUMENT / FOLLOW UP REQUIRED (RKDM INITIAL SETUP ONLY):\n\n";			
	}
		
	if (ge("$mfpnamemiss$").checked) {
		theresult += "\n*Plan sponsor name / plan name missing or incomplete\n";			
	}

	if (ge("$mfpcmiss$").checked) {
		theresult += "\n*Primary contact missing / incomplete\n";			
	}

	if (ge("$mfreptpamiss$").checked) {
		theresult += "\n*Rep / TPA information missing / incomplete\n";			
	}

	if (ge("$mfunitnot$").checked) {
		theresult += "\n*Unit class not provided\n";			
	}

	if (ge("$mfcompmethnot$").checked) {
		theresult += "\n*Compensation method not selected\n";			
	}

	if (ge("$mfother$").checked) {
		theresult += "\n*Other--see comments below\n";			
	}
				
	////////////////////////////////// PLAN EST'D / SETUP DEFAULTS USED SECTION

	if (ge("$pesdu$").checked) {
		theresult += "\n\nPLAN ESTABLISHED / SETUP DEFAULTS USED--FOLLOW UP REQUIRED:\n\n";			
	}

	if (ge("$psachmiss$").checked) {
		theresult += "\n*Plan sponsor ACH information missing / incomplete / invalid\n";			
	}

	if (ge("$sigsmiss$").checked) {
		theresult += "\n*Required signatures missing for authorized signers\n";			
	}

	if (ge("$reptpadisc$").checked) {
		theresult += "\n*Rep / TPA contact discrepancy\n";			
	}

	if (ge("$effdmiss$").checked) {
		theresult += "\n*Plan Effective Date missing\n";			
	}

	if (ge("$cbttdisc$").checked) {
		theresult += "\n*CB&T Trustee discrepancy / supporting documents missing\n";			
	}


	if (ge("$forffundnot$").checked) {
		theresult += "\n*Forfeiture fund not provided (MMF selected per setup defaults)\n";			
	}

	if (ge("$loanincomp$").checked) {
		theresult += "\n*Loan information incomplete, defaults used\n";			
	}

	if (ge("$nranot$").checked) {
		theresult += "\n*Normal retirement age not specified\n";			
	}

	if (ge("$vestincomp$").checked) {
		theresult += "\n*Vesting information is incomplete\n";			
	}

	if (ge("$pesduother$").checked) {
		theresult += "\n*Other--see comments below\n";			
	}
				
return theresult;

}
					 
//	GETS & RETURNS ELEMENT REFERENCE
function ge(id) {
	var myelement = document.getElementById(id);
	return myelement;
}					 