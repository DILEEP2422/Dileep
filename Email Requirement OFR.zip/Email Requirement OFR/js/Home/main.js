// http://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
var pinData = [];
// http://johnliu.net/blog/2015/12/convert-sharepoint-jsoms-executequeryasync-to-promise-in-the-prototype
SP.ClientContext.prototype.executeQuery = function() {
   var deferred = $.Deferred();
   this.executeQueryAsync(
       function(){ deferred.resolve(arguments); },
       function(){ deferred.reject(arguments); }
   );
   return deferred.promise();
};
var categories = {};
var title = " - ";
var area = null;
var isHidden = false;
var query = getParameterByName('area');
if (query != null) {
	switch(query.toLowerCase()) {
		case "shsv":
			area = "Shareholder Services";
			title = title + "SHSV/CB&T";
			break;
		case "rkd":
			area = "Retirement Planning";
			title = title + "Retirement Planning";
			isHidden = true;
			break;
		case "host":
			area = "HOST";
			title = title + "HOST";
			break;
		case "all":
			area = "all";
			title = title + "All Areas";
	}
} else {
	$('#selectArea').show();
	$('#standard').hide();
}

$(document).ready(function () {
	SP.SOD.executeOrDelayUntilScriptLoaded(Initialize, 'sp.js');
	Pins.Load();
	$("#pinSort").click(function () {
		formList.sort('category', { sortFunction: baseSort });
	});
	
	$('#x-img').hide();   // line to recheck
	
	if (!area) {
		$('#standard').hide();
		$('#selectArea').show();
	} else {
		if (area == 'all')
			$('#forms').find('thead tr').append('<th><a class="sort" data-sort="area">Area(s)</a></th>');
		else {
			$('#title').text("Online Forms" + title);
			if(isHidden) {
				$("#informationPanel").hide();
			}
		}
		document.title = $('#title').text();
		$('#formsRows').on('click', 'td.pin', function (e) {
			var element = $(e.currentTarget);
			var isPinned = Pins.TogglePin(element.data('formID'));
			element.toggleClass('pinned', isPinned);
			element.parent().data('pinned', isPinned);
		});
		$('#formsRows').on('click', 'span.name', function (e) {
			var target = $(e.currentTarget);
			e.preventDefault();
			var name = target.text();
			var clientContext = new SP.ClientContext.get_current();
			var oList = clientContext.get_web().get_lists().getByTitle('Clicks');
			var itemCreateInfo = new SP.ListItemCreationInformation();
			var item = oList.addItem(itemCreateInfo);
			var formLookup = new SP.FieldLookupValue();
			formLookup.set_lookupId(target.data('id'));
			item.set_item('Form', formLookup);
			item.update();
			clientContext.load(item);
			var navigate = function() { 
				var newWindow = window.open($(e.currentTarget).attr('data-link'));
				newWindow.focus();
			};
			// Don't hold anything up, success or failure, but make sure the request gets off before we navigate away.
			clientContext.executeQueryAsync(navigate, navigate);
		});
	}
	
	
});

function showIcon(value) {	
	if(value==""){
		$('#x-img').hide();
	}else if(value!=""){
		$('#x-img').show();
	}	
	
};


function hideIcon() {	
	if($('#searchBox').val() == ''){
	$('#x-img').hide();
	}else if($('#searchBox').val() !=''){	
	$('#x-img').show();
	}	
	
};

function sortList(){	
										
					$('#searchBox').val('');					
					hideIcon();					
					var options = area != "all" 
                    ? { valueNames: [ 'pin', 'name', 'category' ]}
                    : { valueNames: [ 'pin', 'name', 'category', 'area' ]};
                    var categoryQueryBuilder = new CamlQueryBuilder(['Title', 'Order0'], 'ID', true, null, null);
                    formList.remove();
                                
                    Lists.ReadWithQueryBuilder('Categories', categoryQueryBuilder, false, function (categoryItems) {
							categoryItems.forEach(function (categoryItem) {
							var category = {};
							category.Order = categoryItem.Order0;
							category.Name = categoryItem.Title;
							categories[category.Name] = category;
							});
							var queryBuilder = new CamlQueryBuilder(['ID', 'Title', 'File', 'Category', 'Area', 'Active'], 'Category', true, null, new OFRWhere(area));
						Lists.ReadWithQueryBuilder('Forms', queryBuilder, true, function (formItems) {
							if (formItems.length == 0) {
							$('div.container *').hide();
							$('.alert-danger').show();
							} else {
							var forms = [];
							var tbody = $('#formsRows');
							formItems.forEach(function (form) {
							var categoryNames = [];
							form.Category.forEach(function (e, i, a) {
							categoryNames.push(e.get_lookupValue());
							});
							var tr = $('<tr/>');
							var td = $('<td/>');
							td.html('<span class="glyphicon glyphicon-pushpin">');
							td.addClass('pin');
							td.data('formID', form.ID);
							var isPinned = Pins.IsPinned(form.ID);
							tr.data('pinned', isPinned);
							td.toggleClass('pinned', isPinned);
							tr.append(td);
							tr.data('title', form.Title);
							tr.data('order', categories[categoryNames[0]].Order);
							var spanName = $('<span/>', {'class':'name', 'data-link':form.FileUrl, 'data-id':form.ID, 'title':form.FileUrl});
							spanName.html(form.Title + " ");
							var name = $('<td/>', {'class':'form' + form.ID });
							name.append(spanName);
							tr.append(name);
							tr.append('</td><td class="category">' + categoryNames.join(', ') + '</td>');
							if (area == 'all') {
							var areas = [];
							form.Area.forEach(function (e, i, a) {
							areas.push(e.get_lookupValue());
							});
							tr.append('<td class="area">' + areas.join(', ') + '</td>');
							}
							tbody.append(tr);
							});
							formsLoaded = true;
							formList = new List('forms', options);
							formList.sort('category', { sortFunction: baseSort });
						}
							});
				});

	
  
};

function Initialize() {
	var context = new SP.ClientContext.get_current();
	var user = context.get_web().get_currentUser();
	var groups = user.get_groups();
	context.load(groups);
	context.executeQueryAsync(function () {
		var enumerator = groups.getEnumerator();
		var found = false;
		while (enumerator.moveNext() && !found) {
			var group = enumerator.get_current();
			var title = group.get_title();
			if (title == "Online Forms Room Owners" || title == "Online Forms Room Members") {
				found = true;
				var contentButton = document.getElementById('siteContentButton');
				contentButton.style.display = '';
			}
		}
	});
	var formsLoaded = false;
	if (area) {
		var options = area != "all" 
			? { valueNames: [ 'pin', 'name', 'category' ]}
			: { valueNames: [ 'pin', 'name', 'category', 'area' ]}; 
		Lists.Load();
		FAQs.Load();
		var categoryQueryBuilder = new CamlQueryBuilder(['Title', 'Order0'], 'ID', true, null, null);
		Lists.ReadWithQueryBuilder('Categories', categoryQueryBuilder, false, function (categoryItems) {
			categoryItems.forEach(function (categoryItem) {
				var category = {};
				category.Order = categoryItem.Order0;
				category.Name = categoryItem.Title;
				categories[category.Name] = category;
			});
			var queryBuilder = new CamlQueryBuilder(['ID', 'Title', 'File', 'Category', 'Area', 'Active'], 'Category', true, null, new OFRWhere(area));
			Lists.ReadWithQueryBuilder('Forms', queryBuilder, true, function (formItems) {
				if (formItems.length == 0) {
					$('div.container *').hide();
					$('.alert-danger').show();
				} else {
					var forms = [];
					var tbody = $('#formsRows');
					formItems.forEach(function (form) {
						
						var categoryNames = [];
						form.Category.forEach(function (e, i, a) {
							categoryNames.push(e.get_lookupValue());
						});
						var tr = $('<tr/>');
						var td = $('<td/>');
						td.html('<span class="glyphicon glyphicon-pushpin">');
						td.addClass('pin');
						td.data('formID', form.ID);
						var isPinned = Pins.IsPinned(form.ID);
						tr.data('pinned', isPinned);
						td.toggleClass('pinned', isPinned);
						tr.append(td);
						tr.data('title', form.Title);
						tr.data('order', categories[categoryNames[0]].Order);
						var spanName = $('<span/>', {'class':'name', 'data-link':form.FileUrl, 'data-id':form.ID, 'title':form.FileUrl});
						spanName.html(form.Title + " ");
						var name = $('<td/>', {'class':'form' + form.ID });
						name.append(spanName);
						
						tr.append(name);
						tr.append('</td><td class="category">' + categoryNames.join(', ') + '</td>');
						if (area == 'all') {
							var areas = [];
							form.Area.forEach(function (e, i, a) {
								areas.push(e.get_lookupValue());
							});
							tr.append('<td class="area">' + areas.join(', ') + '</td>');
						}
						tbody.append(tr);
					});					
					formsLoaded = true;
					formList = new List('forms', options);
					formList.sort('category', { sortFunction: baseSort });
				}
			});
		});
		var helpSheetsBuilder = new CamlQueryBuilder(['Form', 'File'], 'ID', true, null, null);
		var processSheets = function (helpSheetItems) {
			if (!formsLoaded)
				setTimeout(processSheets, 200, helpSheetItems);
			else {
				helpSheetItems.forEach(function (helpSheetItem) {
					var formLink = $(".form"+ helpSheetItem.Form.get_lookupId());
					var anchorTag = $('<a />', {'href':helpSheetItem.FileUrl, 'target':'_blank', 'title':'Help Sheet'});
					var span = $('<span />', { 'class':'glyphicon glyphicon-question-sign'});
					anchorTag.append(span);
					formLink.append(anchorTag);
				});
			}
		}
		Lists.ReadWithQueryBuilder('Help Sheets', helpSheetsBuilder, true, processSheets);
	}
}



var formList = null;

function areaFilter(source) {
	formList.filter(function(item) { if (item.values().area.indexOf(source) > -1) return true; return false; });
}

function baseSort(a, b) {
	var eleA = $(a.elm);
	var eleB = $(b.elm);
	if (eleA.data('pinned') && !eleB.data('pinned'))
		return -1;
	if (eleB.data('pinned') && !eleA.data('pinned'))
		return 1;
	if (eleA.data('order') < eleB.data('order'))
		return -1;
	if (eleB.data('order') < eleA.data('order'))
		return 1;
	var titleA = eleA.data('title').toLowerCase();
	var titleB = eleB.data('title').toLowerCase();
	if (titleA < titleB)
		return -1;
	return 1;
}

function OFRWhere(area) {
	this.BuildElement = function() {
		var element = '<Where>';
		var endElement = '</Where>';
		if (area != "all") {
			element += '<And><Contains><FieldRef Name="Area" LookupId="FALSE"/><Value Type="Text">' + area + '</Value></Contains>';
			endElement = '</And>' + endElement;
		}
		var output = element + '<And>' +
			'<Eq><FieldRef Name="Active" /><Value Type="Boolean">1</Value></Eq>' +
			'<Eq><FieldRef Name="OnHomePage" /><Value Type="Boolean">1</Value></Eq>' +
		'</And>' + endElement;
		return output;
	}
}