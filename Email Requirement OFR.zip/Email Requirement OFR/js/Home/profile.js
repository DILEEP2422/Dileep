var Profiles = new ProfilesClass();

function ProfilesClass () {
	this.Context = null;
	this.Web = null;
	this.Manager = null;
	this.Loaded = false;
	this.Load = function () {
		this.Context = new SP.ClientContext.get_current();
		this.Web = this.Context.get_web();
		this.Manager = new SP.UserProfiles.PeopleManager(this.Context);
	}
	this.Read = function (id, success) {
		var user = this.Web.getUserById(id);
		this.Context.load(user);
		var result = this.Context.executeQuery();
		result.done(function() { 
			Profiles.ToProfile(user.get_loginName(), success);
		}, Main.Failure);
	}
	this.ReadGroup = function (ids, success) {
		var that = this;
		var users = [];
		ids.forEach(function (id, i, a) {
			var user = that.Web.getUserById(id);
			users.push(user);
			that.Context.load(user);
		});
		var result = this.Context.executeQuery();
		result.done(function () {
			Profiles.ToProfiles(users, success);
		});
	}
	this.ToProfile = function (loginName, success) {
		var profile = null;
		var properties = this.Manager.getPropertiesFor(loginName);
		this.Context.load(properties);
		var result = this.Context.executeQuery();
		result.done(function() { 
			profile = new Profile(properties);
			success(profile);
		}, Main.Failure);
	}
	this.ToProfiles = function(users, success) {
		var propertiesGroup = [];
		var that = this;
		users.forEach(function (user, i, a) {
			var properties = that.Manager.getPropertiesFor(user.get_loginName());
			properties.Id = user.get_id();
			propertiesGroup.push(properties);
			that.Context.load(properties);
		});
		var result = this.Context.executeQuery();
		result.done(function () {
			var profiles = [];
			propertiesGroup.forEach(function (properties, i, a) {
				profiles.push(new Profile(properties));
			});
			success(profiles);
		});
	}
}

function Profile(properties) {
	this.Id = properties.Id;
	this.Email = properties.get_email();
	this.Picture = properties.get_pictureUrl();
	this.Name = properties.get_displayName();
	this.Link = properties.get_userUrl();
	var props = properties.get_userProfileProperties();
	this.Initials = props.UserName;
	this.Department = props.Department;
}