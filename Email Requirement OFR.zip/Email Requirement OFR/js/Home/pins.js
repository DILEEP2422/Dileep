var Pins = new PinsClass();

function PinsClass() {
	var pins = [];
	var that = this;
	var serialize = function () {
		var output = "";
		pins.forEach(function (e, i, a) {
			if (pins[i] == 'pinned')
				output += i + ";";
		});
		return output;
	}
	var deserialize = function (input) {
		if (input) {
			var ids = input.split(';');
			ids.forEach(function (e, i, a) {
				if (e) {
					pins[e] = 'pinned';
				}
			});
		}
	}
	
	this.Load = function () {
		var state = localStorage.getItem("ofrpins");
		deserialize(state);
		this.SetElements();
	}
	this.SetElements = function () {
		$("#export").click(function () {
			var text = $('<textarea />');
			text.html(serialize());
			$('div.container').append(text);
			text.select();
			document.execCommand('copy');
			text.remove();
			$('#export').popover('show');	
			$('#export').focus();
			$('#export').focusout(function () {
				$('#export').off('focusout');
				$('#export').popover('hide');
			});
		});
		$('#importModal').on('shown.bs.modal', function (e) {
			$('#pinInput').focus();
		});
		$('#completeImport').click(function () {
			var val = $('#pinInput').val();
			if (!val)
				alert('Your pin string is empty!');
			else {
				$('#completeImport').prop('disabled', true);
				that.Import(val);
				$('#importSuccessful').show();
			}
		});
	}
	this.Export = function () {
		return serialize();
	}
	this.Import = function (input) {
		deserialize(input);
		that.Save();
	}
	
	this.Save = function () {
		var str = serialize();
		localStorage.setItem("ofrpins", str);
	}
	this.IsPinned = function (formID) {
		if (pins[formID] == 'pinned')
			return true;
		return false;
	}
	this.TogglePin = function(id) {
		var pinned = that.IsPinned(id);
		pins[id] = pinned ? 'null' : 'pinned';
		that.Save();
		return !pinned;
	}
}

