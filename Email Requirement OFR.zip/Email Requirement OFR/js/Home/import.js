function setImport () {
	
	
	$("#export").click(function () {
		var text = $('<textarea />');
		var pinInfo = pinData.join('\n');
		text.html(pinInfo);
		$('div.container').append(text);
		text.select();
		document.execCommand('copy');
		text.remove();
		$('#export').popover('show');	
		$('#export').focus();
		$('#export').focusout(function () {
			$('#export').off('focusout');
			$('#export').popover('hide');
		});
		//window.setTimeout(function () { $("#export").popover('hide'); }, 4000);
	});
	$('#importModal').on('shown.bs.modal', function (e) {
	  $('#pinInput').focus();
	})
	$('#completeImport').click(function () {
		var val = $('#pinInput').val();
		if (!val)
			alert('Your pin string is empty!');
		else {
			$('#completeImport').prop('disabled', true);
			var forms = val.split('\n');
			forms.forEach(function (e, i, a) {
				localStorage.setItem(e, 'pinned');
			});
			$('#importSuccessful').show();
		}
	});
}

