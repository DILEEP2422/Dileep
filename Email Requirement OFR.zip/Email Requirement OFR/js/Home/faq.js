var FAQs = new FAQsClass();

function FAQsClass () {
	var faqTemplate = '<div class="faq"><div class="question">{{question}}</div><div class="answersWrapper"><div class="answers">{{answer}}</div></div></div>'
	var answerTemplate = '<div class="answer">{{answer}}</div>';
	var display = function(faqs, complete) {
		var faqsElement = $('#faqSection');
		faqs.forEach(function (f, i, a) {
			var faq = faqTemplate.replace('{{question}}', f.Question);
			faq = faq.replace('{{answer}}', f.Answer ? answerTemplate.replace('{{answer}}', f.Answer) : '');
			var faqElement = $(faq);
			faqElement.find('.question').click(function () {
				var sibling = $(this).next();
				if (sibling.height() == 0) {
					$(this).addClass('selected');
					sibling.height(sibling.find('.answers').outerHeight());
				}
				else {
					$(this).removeClass('selected');
					sibling.height(0);
				}
			});
			faqsElement.append(faqElement);
		});
	}	
	this.Load = function () {
		var faqs = [];
		Lists.Read('Questions', ['ID', 'Title', 'Answer', 'Order0'], 'Order0', true, function(faqItems) {
			faqItems.forEach(function (item, i, a) {
				faqs.push(new FAQ(item));
			});
			display(faqs);
		});
	}
}


function FAQ(item) {
	this.Question = item.Title;
	this.Answer = item.Answer;
	this.Order = item.Order0;
}