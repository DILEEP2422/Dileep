function setAudience(chkid, hiddenid, literal) {
	// FUNCTION RECEIVES THE ID OF THE BOX CHECKED, THE ID OF THE HIDDEN FIELD TO HOLD THE LITERAL,
	// AND THE LITERAL TO DISPLAY ON THE OUTPUT EMAIL

	if (document.getElementById(chkid).checked) {
		document.getElementById(hiddenid).value = literal; // if checked, store in hidden field
	} else {
		document.getElementById(hiddenid).value = ""; // if not checked, make hidden field blank
	}
}
					
Form.CreateSubject = function () {
	form_rps_training_request.subject.value = "RPS Training Request - " + form_rps_training_request.$title$.value;
}