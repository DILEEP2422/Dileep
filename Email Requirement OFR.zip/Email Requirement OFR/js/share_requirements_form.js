var today = new Date();

// http://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

Form.FormSpecificReset = function () {
	var pageurl = getParameterByName('pageurl');
	var pagetitle = getParameterByName('pagetitle');
	$("#currentDate").html((today.getMonth()+1) + "/" + today.getDate() + "/" + today.getFullYear());
	$("#\\$dateSubmitted\\$").val(today);
	
	$("#title").html(pagetitle);
	$("#\\$pageTitle\\$").val(pagetitle);
	
	$("#requestURL").html(pageurl);
	$("#\\$requestURL\\$").val(pageurl);
}

Form.CreateSubject = function () {
	$("#subject").val("SHARE REQ feedback notification");
}