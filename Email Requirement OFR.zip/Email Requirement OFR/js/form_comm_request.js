Form.CreateSubject = function () {
	form_comm_req.subject.value = "CS Communications Request " + "(" + form_comm_req.$urgency$.value + ")";
}