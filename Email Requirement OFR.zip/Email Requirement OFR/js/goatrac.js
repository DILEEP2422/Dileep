Form.FormSpecificReset = function () {
	document.getElementById('$SITE$').focus();
	hideFieldsOnLoad();
}

function hideFieldsOnLoad() {
	$("#planId").hide();
	$("#planName").hide();
	$("#grpPlanName").hide();
	$("#participantName").hide();
	$("#accountNo").hide();
	$("#ssnNo").hide();
}

function toggleTrackDisplay() {
	
	if (document.getElementById('TRACK_CHECK').checked == true) {
		
		$("#planId").show();
		$("#planName").show();
		$("#participantName").show();
		$("#ssnNo").show();
		
	} else if (document.getElementById('TRACK_CHECK').checked == false) {
		
		if (document.getElementById('SHARE_CHECK').checked == true) {
			$("#planId").hide();
		} else {
			$("#planId").hide();
			$("#planName").hide();
			$("#participantName").hide();
			$("#ssnNo").hide();
		}
	}
}

function toggleShareDisplay() {
	
	if (document.getElementById('SHARE_CHECK').checked == true) {
		
		$("#planName").show();
		$("#grpPlanName").show();
		$("#participantName").show();
        $("#accountNo").show();
		$("#ssnNo").show();
		
	} else if (document.getElementById('SHARE_CHECK').checked == false) {
		
		if (document.getElementById('TRACK_CHECK').checked == true) {
			$("#grpPlanName").hide();
			$("#accountNo").hide();
		} else {
			$("#planName").hide();
			$("#grpPlanName").hide();
			$("#participantName").hide();
			$("#accountNo").hide();
			$("#ssnNo").hide();
		}
	}
	
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	
	if ($("#systems_block span input:checked").length == 0) {
		errorMsgArr[$("#TRACK_CHECK").attr('tabindex')] = "- System\n";
	}
	
	if (document.getElementById('RETPLAN_CHECK').checked == false && document.getElementById('CBTPLAN_CHECK').checked == false && document.getElementById('OGIPLAN_CHECK').checked == false && document.getElementById('403bPLAN_CHECK').checked == false)   {
	    errorMsgArr[$("#RETPLAN_CHECK").attr('tabindex')] = "- Plan Type\n";
	}
	
	if (document.getElementById('TRACK_CHECK').checked == true) {
		if($.trim($("#PLANID").val()).length == 0){
			errorMsgArr[$("#PLANID").attr('tabindex')] = "- Plan ID\n";
			
		}	
	}	
}

Form.CreateSubject = function () {
	$("#SYSTEM").val("");
	$("#PLAN_TYPE").val("");
	
	var checked = getSystems();
	$("#SYSTEM").val(checked);
	
	var planType = getPlanType();
	$("#PLAN_TYPE").val(planType);

	fdmForm.subject.value = "RP Phone-Generated Research / Correction Request - "+ document.getElementById("$SITE$").value;
}

function isDigit(c) {
	return "0123456789".indexOf(c) > -1;
}

function getDigits(phone) {
	var newphone = "";
	var c;
	for (var i=0; i < phone.length; i++) {
    c = phone.charAt(i);
    if (isDigit(c)) newphone = newphone + c;
	}
    return newphone;
}

function getPhone(phone) {
	  var phoneDigits = getDigits(phone);
	  var newphone = "";
	  for (var i=0; i < phoneDigits.length && i < 10; i++) {
   		 if (i == 0) newphone = newphone + "(";
		 if (i == 3) newphone = newphone + ") ";
		 if (i == 6) newphone = newphone + "-";
		 newphone = newphone + phoneDigits.charAt(i);
	  }
	  return newphone;
}

function getSystems() {
	var systems = new Array();
	$("#systems_block span input:checked").each(function () {
		systems.push($(this).closest("span").text());
	});
	return systems.join(", ");
}

function getPlanType() {
	var planType = new Array();
	$("#plan_block span input:checked").each(function () {
		planType.push($(this).closest("span").text());
	});
	return planType.join(", ");
}

function alltrim(str) {
    return str.replace(/^\s*/, "").replace(/\s*$/, "");
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = alltrim(str);
    }
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}