Form.ValidateSpecificFormFields = function (errorMsgArr) {
	
	if ($("#systems_block label input:checked").length == 0) {
		errorMsgArr[$("#SHARE_MAIL_MODE").attr('tabindex')] = "\n- SYSTEM(S) IMPACTED: Check at least one\n";
	} else {
		bsrForm.$SYSTEM$.value = getImpactedSystems();
	}
}

Form.CreateSubject = function () {
	bsrForm.Qualifier.value = bsrForm.$DEPARTMENT$.value;
	bsrForm.subject.value = "BSR System Issue - ";
	bsrForm.subject.value += bsrForm.$SITE$.value + " - " + getImpactedSystems() + " " + bsrForm.$WORKTYPE$.value;
}

function getImpactedSystems() {
	var impactedSystems = new Array();
	$("#systems_block label input:checked").each(function () {
		impactedSystems.push($(this).val());
	});
	return impactedSystems.join(", ");
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

function alltrim(str) {
    return str.replace(/^\s*/, "").replace(/\s*$/, "");
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = alltrim(str);
    }
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}