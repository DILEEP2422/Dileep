var index = 1;

Form.FormSpecificReset = function () {
	index = 1;
	$("#conpTable").empty();
	$("#conpTable").append($("#conpLineTemplate #conpLineSection").clone(true).attr('id',"conpLineSection"+index));
	$("#conpTable #conpLineSection"+index).find("input.processingAmount").autoNumeric({aSign: '$'});
	$("#processingTotalReadOnly").text("$0.00");
	$("#outOfBalanceReadOnly").text("$0.00");
	$("#outOfBalanceReadOnly").css("color", "black");

	reindexRows();
}

$(document).ready(function() {
	$("#feeAmount, #depositTotal").autoNumeric({aSign: '$'});
	$(".add").click(function(){addLineItems();});
	$(".add").keydown(function(event){if (event.which == 32) addLineItems();});
	$(".delete").click(function(){$(this).parent().parent().remove(); index--; reindexRows();	recalculateTotals();});
	$("input.processingAmount, #feeAmount, #depositTotal ").blur(function(){recalculateTotals();});
});

$(".conpNumber, .fundNumber, .accountNumber").keypress(function() {
	return numbersonly(event, true);
});

function reindexRows(){
	$(".index").each(function(counter){
		$(this).html(counter+1);
	});

	var count = $("#conpTable > div").length;
	
	if(count == 1)
		$(".delete").hide();
	else
		$(".delete").show();
		
	if(count == 20)
		$(".add").hide();
	else
		$(".add").show();	
}

function addLineItems() {
	index++;
	$("#conpLineTemplate #conpLineSection").clone(true).attr('id',"conpLineSection"+index).appendTo("#conpTable:last");
	$("#conpTable #conpLineSection"+index).find("input.conpNumber").focus();
	$("#conpTable #conpLineSection"+index).find("input.processingAmount").autoNumeric({aSign: '$'});
	reindexRows();
}

function recalculateTotals() {
	var total = 0.00;
	var fee = parseFloat($("#feeAmount").autoNumericGet());
	var depositTotal = parseFloat($("#depositTotal").autoNumericGet());
	var outofbalance = 0.00
	
	$("input.processingAmount").each(function(){
		total += parseFloat($(this).autoNumericGet());
	});
	
	outofbalance = depositTotal - (total.toFixed(2) + fee);
	
	$("#processingTotal").autoNumericSet(total, {aSign: '$', vMin: '0.00', vMax: '99999999999.99'});
	$("#OOB").autoNumericSet(outofbalance, {aSign: '$', vMin: '-99999999999.99', vMax: '99999999999.99'});
	
	$("#processingTotalReadOnly").text($("#processingTotal").val());
	$("#outOfBalanceReadOnly").text($("#OOB").val());
	
	if (outofbalance > 0) $("#outOfBalanceReadOnly").css("color", "green");
	else if (outofbalance < 0) $("#outOfBalanceReadOnly").css("color", "red");
	else if (outofbalance == 0) $("#outOfBalanceReadOnly").css("color", "black");
}

function numbersonly(e, decimal) {
	var key;
	var keychar;
	var ctrl = (document.all) ? event.ctrlKey:e.modifiers & Event.CONTROL_MASK;

	if (window.event) key = window.event.keyCode;
	else if (e) key = e.which;
	else return true;
	
	keychar = String.fromCharCode(key);

	if ((key==null) || (key==0) || (key==8) ||  (key==9) || (key==13) || (key==27) ) return true;
	else if (ctrl && key==86) return true;
	else if ((("0123456789").indexOf(keychar) > -1)) return true;
	else if (decimal && (keychar == ".")) return true;
	else return false;
}

function testLineItems(errorMsgArr) {
	var lineItemErrors = "";
	blankLine = false;
	conpBatchForm.$conps$.value = "";
	$("#conpTable > div").each(function(index) {
		var lineIndex = index + 1;
		var lineConpNumber = $.trim($(this).find("input.conpNumber").val());
		var lineFundNumber = $.trim($(this).find("input.fundNumber").val());
		var lineAccount = $.trim($(this).find("input.accountNumber").val());
		var processingAmount = $.trim($(this).find("input.processingAmount").val());

		//test if any cells have value
		if (lineConpNumber.length > 0 || lineFundNumber.length > 0 || lineAccount.length > 0 || processingAmount.length > 0) {
			//test that all cells have value
			if (lineConpNumber.length > 0  && lineFundNumber.length > 0 && lineAccount.length > 0 && processingAmount.length > 0) {
				//if they do create the CONP Batch Ticket Lines to pass to the mail servlet
				conpBatchForm.$conps$.value += padSpacesToRight(lineConpNumber, 10);
				conpBatchForm.$conps$.value += padSpacesToRight(lineFundNumber, 7);
				conpBatchForm.$conps$.value += padSpacesToRight(lineAccount, 15);  
				conpBatchForm.$conps$.value += padSpacesToLeft(processingAmount, 18) + "\n";
			}
			//otherwise indicate that the line is incomplete
			else lineItemErrors += "- CONP Batch Ticket: Line # " + lineIndex + " is incomplete\n";
		} else {
			blankLine = true;
		}
	});
	
	if(blankLine) lineItemErrors = "- At least one CONP Batch Ticket line must be complete:\n" + lineItemErrors;
	
	if(lineItemErrors.length > 0) {
		errorMsgArr[$("#COMMENTS").attr('tabindex')] = lineItemErrors;
	}
	
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	testLineItems(errorMsgArr);

	conpBatchForm.$conps$.value += "-------------------------------------------------\n\n";
	conpBatchForm.$conps$.value += "Total: " + conpBatchForm.processingTotal.value + "\n\n";
	conpBatchForm.$conps$.value += "Fee: " + conpBatchForm.feeAmount.value + "\n\n";
	conpBatchForm.$conps$.value += "Check(s) Total: " + conpBatchForm.depositTotal.value + "\n\n";
	conpBatchForm.$conps$.value += "Out of Balance +/-: " + conpBatchForm.OOB.value + "\n\n";
}

Form.CreateSubject = function () {
	conpBatchForm.subject.value = "CONP Batch Titcket - " + conpBatchForm.processingTotal.value + " - Batch #: " + conpBatchForm.$batch$.value;

}

function padSpacesToRight(inputstring, totalLength){
	var returnstr=inputstring;
	for (var i = inputstring.length; i<totalLength; i++) {
		returnstr += " ";
	}
	return returnstr;
}

function padSpacesToLeft(inputstring, totalLength){
	var returnstr="";
	for (var i = 1; i<totalLength-inputstring.length; i++) {
		returnstr += " ";
	}
	returnstr += inputstring;
	return returnstr;
}

function getUniqueAccountNumbers() {
	var accountNumbers = new Array();

	for (var linenumber=1;linenumber<=9;linenumber++){
		if (document.getElementById('$acct'+linenumber+'$').value != "") {
			accountNumbers.push(document.getElementById('$acct'+linenumber+'$').value);
		}
	}
	
	var uniqueAccountNumbers = new Array();
	var numberOfAccounts = accountNumbers.length;
	
	for (var i=0; i<numberOfAccounts; i++) {
		for(var j=i+1; j<numberOfAccounts; j++)
			if (accountNumbers[i] === accountNumbers[j]) {
				j = ++i;
			}
			uniqueAccountNumbers.push(accountNumbers[i]);
	}
	
	uniqueAccountNumbers = uniqueAccountNumbers.sort(sortNumber);
	return uniqueAccountNumbers.join(", ");
}

function sortNumber(a,b) {
	return a - b;
}