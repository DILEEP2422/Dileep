var Form = new FormClass();

var regexLetterNoSpace = /[^a-zA-z]/;
var regexNos = /[^0-9\s\,]/;
var regexAllNumbersWith2DecimalPoints = /^[-+]?\d+(\.\d{1,2})?$/;
var formIdArr = [63]; //Part of AFSIT-2162
		
$(document).ready(function () {
	Form.Load();
});


SP.SOD.executeOrDelayUntilScriptLoaded(function () {
	SP.ClientContext.prototype.executeQuery = function() {
		var deferred = $.Deferred();
		this.executeQueryAsync(
			function(){ deferred.resolve(arguments); },
			function(){ deferred.reject(arguments); }
		);
		return deferred.promise();
	};
	Lists.Load();
	var where = new Where(window.location.href, 'eq', 'FileRef', null, 'Text', false);
	var queryBuilder = new CamlQueryBuilder(['ID'], null, true, null, where);
	Lists.ReadWithQueryBuilder('Forms', queryBuilder, false, function (formItems) {
		if (formItems != null && formItems.length == 1) {
			Form.LogSubmission = true;
			Form.ID = formItems[0].ID;
		}
	});
}, 'sp.js');

function FormClass() {
	this.ID = null;
	//this.ServiceUrl = 'http://localhost:62519/';
	this.ServiceUrl = Environment.Service;
	this.LogSubmission = false;
	this.Load = function () {
		this.RemoveTabIndex();
		$.support.cors = true;
		$("#confirmationModal").remove();
		this.CustomLoad();
		Form.FormReset();
		var today = new Date();
		date = today.toLocaleString();

		$("form:first").each(function() {
			$(this).attr('autocomplete', 'off');
			$(this).attr('action',Form.ServiceUrl + 'Process');
		});
		
		$('.numbersOnly').keyup(function () { 
			this.value = this.value.replace(/[^0-9]/g,'');
		});	

		$('.numbersOnlyWithDecimal').keyup(function () { 
			this.value = this.value.replace(/[^0-9\.]/g,'');
		});	

		$('.alphaOnly').keyup(function () { 
			this.value = this.value.replace(/[^a-zA-z]/,'');
		});
		
		$('.alphaNumeric').keyup(function () { 
			this.value = this.value.replace(/[^a-zA-Z0-9]/g,'');
		});	
		
		$('.numbersWithDecimalDollarComma').keyup(function () { 
			this.value = this.value.replace(/[^0-9\.,$]/g,'');
		});
		
		$( "button:contains('Submit')" ).attr( "id", "submit" );
		$( "button:contains('Send')" ).attr( "id", "submit" );
		$( "button:contains('Clear')" ).attr( "id", "clear" );
		$(document).on('keydown', function(e) {
			if (e.key == 't' && e.altKey) {
				if ($('#testInput').length == 0) {
					var input = $('<input>', {'id':'testInput', 'type':'hidden', 'name':'testSubmission', 'value':'true'});
					$('form').append(input);
					$('div.container').css('color', '#bf871b');
				} else {
					$('#testInput').remove();
					$('div.container').css('color', '#03F');
				}
				
			}
		});
		this.InitializeDatePickers();
		
		$("form").append("<div id='patience' class='hidden'><div><img src='../images/loader.gif'></div></div>");
	}
	this.CustomLoad = function () {}
	this.FormReset = function() {
		document.forms[0].reset();
		$("input[type!='radio'][type!='checkbox']").not('.preserve').val('');
		$("span[class='form-control']").each(function(index) {
			$(this).html("");
		});
		this.FormSpecificReset();
		Form.Prefill();
	}
	this.Prefill = function() {
		$.ajax(
		{
			url: Form.ServiceUrl + 'user/extension',
			type: "GET",
			xhrFields: {
				 withCredentials: true
			},
			success: function(data) {
				$('input.extension').val(data);
			},
			error: function() {
				// For now, don't care; TBD how we handle this.
			}
			
		});
		$.ajax(
		{
			url: Form.ServiceUrl + 'user/location',
			type: "GET",
			xhrFields: {
				 withCredentials: true
			},
			success: function(data) {
				var sel = $('select.location');
				if (sel.find("option[value='" + data + "']").length > 0)
					sel.val(data);
			},
			error: function() {
				// For now, don't care; TBD how we handle this.
			}
			
		});
	}
	this.FormSpecificReset = function () {
	}
	this.InitializeDatePickers = function () {
		$(".date-picker").each(function() {
			$(this).datepicker({
				/* fix buggy IE focus functionality */
				fixFocusIE: false,
				beforeShowDay:function(date) {
					if(date.toString().indexOf('Sun ')!=-1 || date.toString().indexOf('Sat ')!=-1) {
						return [1,'red'];
					} else {
						return [1,'blue'];
					}
				},
				beforeShow: function(input, inst) {
					var result = !this.fixFocusIE;
					this.fixFocusIE = false;
					return result;
				},
				onSelect : function () {
					this.fixFocusIE = true;
					$(this).focus();
					$(this).trigger('change');
				},
				onClose : function () {
					this.fixFocusIE = true;
					$(this).focus();
				}			
			});
		});
	}
	this.CreateSubject = function () {
		alert("createSubject called directly without overriding");
	}
	this.CustomFields = function () {
		
	}
	this.Confirm = function () {
		return true;
	}
	this.ShowError = function(errorMsgArr) {
		var errorMsg = "Please correct or complete the required field(s) below:\n\n";
		$.each(errorMsgArr, function( index, value ) {
			if(value) {
				errorMsg += value;
			}
		});	
		alert(errorMsg);
	}
	this.SetTabIndex = function() {
		var tabindex = 10;
		$('form').find('input,select,textarea,button').each(function() {
			if (this.type != "hidden") {
				var $input = $(this);
				$input.attr("tabindex", tabindex);
				tabindex++;
			}
		});
	}
	this.RemoveTabIndex = function() {
		$('form').find('input,select,textarea,button').each(function() {
			if (this.type != "hidden") {
				var $input = $(this);
				$input.removeAttr("tabindex");
			}
		});
	}
	this.Execute = function () {
		this.SetTabIndex();
		var errorMsgArr = this.ValidateForm(errorMsgArr);
		if (errorMsgArr.length > 0) {
			this.ShowError(errorMsgArr);
			return false;
		} else {
			Form.CreateSubject();
			Form.CustomFields();
			return this.Confirm();
		}
	}
	this.ValidateForm = function () {
		var errorMsgArr = [];
		var errorMsg = "";
		var newLine = "\n";
		/* Should play around with this concept below - this version just looks for a parent div with a class
			of 'blob', which tells us this is a 'blob' of data, say an Account group in DAVAST (the origin of this feature).
			This way we can provide some guidance text for the user to find where they missed data.
			If it finds a blob, it looks for a label for that blob (or a data('label') if that doesn't exist) and puts that 
			text in front of the control's label.
			
			It will actually chain up blobs recursively, so if there's a blob inside of a blob, it'll decorate the string
			with all the parent blobs available.
		
			There may be a better way to handle this in the future?
		*/
		var getBlobString = function (ele) {
			var result = '';
			if (!ele.hasClass("noblob")) {
				var blob  = ele.parents('div.blob');
				if (blob.length > 0) {
					var labelFound = false;
					if (blob.attr('id')) {
						var bloblLabel = $('label[for="'+blob.attr('id')+'"]');
						if (bloblLabel.length) {
							result = blobLabel.text().replace(':', '').replace('*', '') + ': ';
							labelFound = true;
						}
					}
					if (!labelFound && blob.data('label'))
						result = blob.data('label') + ': ';
					result = getBlobString(blob) + result;
				}
			}
			return result;
		}
		var generateMessage = function(arr, ele, failureMsg) {
			var lbl = $('label[for="'+ele.attr('id')+'"]');
			var name = getBlobString(ele);
			if (lbl.length)
				name = name + lbl.text().replace(':', '').replace('*', '');
			else
				name = name + ele.attr('data-name');
			arr[ele.attr('tabindex')] = '- ' + name + ': ' + failureMsg + '\n';
		}
		// Validate all required fields
		$(".validate-required").not(':hidden').not(':disabled').each(function() {
			var ele = $(this);
			if(ele.is("select") && ele.has('option').val().length == 0)
				generateMessage(errorMsgArr, ele, 'Must select an option.');
			else if($.trim(ele.val()) == 0)
				generateMessage(errorMsgArr, ele, 'Cannot be empty.');
		});
		
		$(".validate-checks").not(':hidden').each(function () {
			var ele = $(this);
			var name = ele.attr('name');
			if ($("input[name='" + name + "']:checked").length == 0) {
				generateMessage(errorMsgArr, ele, 'Must select an option.');
			}
		});
		
		$(".validate-integer").not(':hidden').each(function () {
			var ele = $(this);
			var val = $.trim(ele.val());
			if (val) {
				if (regexNos.test(val)) {
					generateMessage(errorMsgArr, ele, 'Input is not a number.');
				}
			}
		});
		
		
		// Validate fields that have length restrictions
		$(".validate-length").not(':hidden').each(function() {
			var ele = $(this);
			// If a failure message doesn't already exist (a higher level failure hasn't already occurred)
			if (!errorMsgArr[ele.attr('tabindex')]) {
				var msg = '';
				var str = ele.val();
				var length = $.trim(str).length;
				var exactLength = ele.attr('data-length');
				var rows = ele.attr('data-maxrows');
				if (exactLength != undefined && length != exactLength) {
					msg = " Must be exactly " + exactLength + " characters.";
				} else {
					var minLength = ele.attr('data-minlength');
					var maxLength = ele.attr('maxlength');
					
					var failed = false;
					if (minLength && length < minLength)
						failed = true;
					if (maxLength && length > maxLength) 
						failed = true;
					if (failed) {
						if (minLength && maxLength) {
							msg = 'Must be between ' + minLength + ' and ' + maxLength + ' characters.';
						} else if (minLength) {
							msg = 'Must be at least ' + minLength + ' characters.';
						} else {
							msg = 'Must be at most ' + maxLength + ' characters.';
						}
					}
				}
				
				if (rows) {
					var lineBreaks = str.match(/[^\n]*\n[^\n]*/gi);
					if (lineBreaks) {
						var actualRows = lineBreaks.length + 1;
						if (rows < actualRows)
						msg = 'Cannot have more than ' + rows + ' rows of text. Currently: ' + actualRows;
					}
				}
				if (msg != '') {
					generateMessage(errorMsgArr, ele, msg);
				}
			}
		});
		
		// Validate fields that can accept letters only
		$(".validate-regex-nospace").not(':hidden').each(function() {
			var ele = $(this);
			var fieldValue = $.trim(ele.val());
			if(regexLetterNoSpace.test(fieldValue)){
				errorMsg = ele.attr('data-msg-validate-regex-nospace') + newLine;
				errorMsgArr[ele.attr('tabindex')] = errorMsg;
			}
		});
		
		// Validate fields that can accept numbers only
		$(".validate-regex-allnumbers-upto2decimal").not(':hidden').each(function() {
			var ele = $(this);
			var fieldValue = $.trim(ele.val());
			if(!regexAllNumbersWith2DecimalPoints.test(fieldValue)) {
				errorMsg = ele.attr('data-msg-validate-regex-allnumbers') + newLine;
				errorMsgArr[ele.attr('tabindex')] = errorMsg;
			}
		});
		$(".validate-greaterOrEqual").not(':hidden').not(':disabled').each(function () {
			var ele = $(this);
			var current = ele.val();
			var compareEle = $('#' + ele.data("compare"));
			var comparison = compareEle.val();
			if (current && comparison && $.isNumeric(current) && $.isNumeric(comparison)) {
				if (current < comparison) {
					generateMessage(errorMsgArr, ele, "cannot be lower than " + compareEle.data('name') + ".");
				}
			}
		});
		$(".validate-phone").not(':hidden').not(':disabled').each(function() {
			var ele = $(this);
			var regex = /^(\([0-9]{3}\)\s*|[0-9]{3}\-)[0-9]{3}-[0-9]{4}$/;
			var val = ele.val();
			if (val && !val.match(regex))
				generateMessage(errorMsgArr, ele, "Invalid phone number.");
		});
		
		Form.ValidateSpecificFormFields(errorMsgArr);
		return errorMsgArr;
	}
	this.ValidateSpecificFormFields = function (errorMsgArr) {
	}
	this.CreateDialog = function () {
		var dialogHTML = "";
		dialogHTML = "<div class='modal fade' id='confirmationModal' role='dialog'>";
		dialogHTML += "<div class='modal-dialog'>";
		dialogHTML += "<div class='modal-content submissionResult'>";
		dialogHTML += "<div class='modal-header'>";
		dialogHTML += "<button type='button' class='close' data-dismiss='modal'>&times;</button>";
		dialogHTML += "</div>";
		dialogHTML += "<div class='modal-body'>";
		dialogHTML += "<div id='confirmationAlert'>";
		dialogHTML += "</div>";
		dialogHTML += "</div>";
		dialogHTML += "<div class='modal-footer'>";
		dialogHTML += "<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>";
		dialogHTML += "</div>";
		dialogHTML += "</div>";
		dialogHTML += "</div>";
		dialogHTML += "</div>";
		
		$(".container").append(dialogHTML);
	}
	this.ShowDialog = function () {
		this.CreateDialog();
		$('#confirmationModal').modal({backdrop: 'static', keyboard: false}); 
	}
	this.OnSuccess = function () {
		Form.ShowDialog();
		$("#confirmationAlert").html("Your request was submitted successfully");
		$(".modal-content.submissionResult").addClass('success');
		$(".modal-content.submissionResult .btn").toggleClass('btn-success', true);
		$(".modal-content.submissionResult .btn").toggleClass('btn-danger', false);
		
		//AFSIT-2162 : OFR - Retain Entered Data in Reprint Request for Customized Enrollment Booklet Order" form after submission		
		if(formIdArr.length != 0){			
			for(var i=0; i < formIdArr.length; i++ )
			{		
				if(formIdArr[i] == Form.ID){
					$(".modal-content.submissionResult .btn").click( function() { Form.EnableForm(); });
				}
				else{
					$(".modal-content.submissionResult .btn").click( function() { Form.EnableForm(); Form.FormReset(); });
				}
			}
		}
		
	}
	this.OnFailure = function (message) {
		Form.ShowDialog();
		$("#confirmationAlert").html(message);
		$(".modal-content.submissionResult").addClass('error');
		$(".modal-content.submissionResult .btn").toggleClass('btn-success', false);
		$(".modal-content.submissionResult .btn").toggleClass('btn-danger', true);
		$(".modal-content.submissionResult .btn").click( function() { Form.EnableForm(); });
	}
	this.Kaboom = function () {
		Form.ShowDialog();
		$("#confirmationAlert").html("An Internal Error occurred.  Please contact AFTSD to submit a ticket");
		$(".modal-content.submissionResult").addClass('error');
		$(".modal-content.submissionResult .btn").toggleClass('btn-success', false);
		$(".modal-content.submissionResult .btn").toggleClass('btn-danger', true);
		$(".modal-content.submissionResult .btn").click( function() { Form.EnableForm(); });	
	}
	this.DisableForm = function () {
		$("form :input").prop("disabled", true);
		$("form span").prop("disabled", true);
	}
	this.EnableForm = function () {
		$("form :input").removeAttr('disabled');
		$("form span").removeAttr('disabled');
	}
	this.Submit = function () {
		this.SubmitForm(this.OnSuccess, this.OnFailure, this.Kaboom);
	}
	this.SubmitForm = function (success, failure, kaboom) {
		$("#confirmationModal").remove();
		$('html, body').animate({ scrollTop: 0 }, 'fast');
		if(this.Execute()) {
			var formObj = document.forms[0];
			var formData = new FormData(formObj);
			var formURL = $(formObj).attr("action");
			this.DisableForm();
			
			$.ajax(
			{
				url : formURL,
				type: "POST",
				data : formData,
				contentType: false,
				cache: false,
				processData:false,
				xhrFields: { withCredentials: true },
				beforeSend: function() {
					$('#patience').toggleClass('hidden',false);
				},
				success:function(data, textStatus, jqXHR) 
				{
					Form.RemoveTabIndex();
					$('#patience').toggleClass('hidden',true);
					if(data.length == 0) {
						Form.Log();
						success();
					} else {
						failure(data);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					Form.RemoveTabIndex();
					$('#patience').toggleClass('hidden',true);
					kaboom();
				}
			});	
		}
	}
	this.Log = function () {
		if (Form.LogSubmission) {
			var clientContext = new SP.ClientContext.get_current();
			var oList = clientContext.get_web().get_lists().getByTitle('Submissions');
			var itemCreateInfo = new SP.ListItemCreationInformation();
			var item = oList.addItem(itemCreateInfo);
			var formLookup = new SP.FieldLookupValue();
			formLookup.set_lookupId(Form.ID);
			item.set_item('Form', formLookup);
			item.update();
			clientContext.load(item);
			clientContext.executeQueryAsync(null, null);
		}
		
	}
}