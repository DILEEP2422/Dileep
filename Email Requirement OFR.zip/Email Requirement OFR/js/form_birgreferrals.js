Form.CreateSubject = function () {
	form_birgreferrals.subject.value = form_birgreferrals.$site$.value + " - AFS Gap/Bridge Letter Request Form (non-financial) - "+form_birgreferrals.$planid$.value.replace(/\r?\n/g, ', ');
}