dateRegularExpression = /^([1-9]|0[1-9]|1[0-2])\/([1-9]|0[1-9]|1[0-9]|2[0-9]|3[0-1])\/20\d\d$/;

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	document.forms[0].$Date$.value = document.forms[0].$Date$.value.replace(/ /g, "");
	
	if (document.forms[0].$Date$.value && !dateRegularExpression.test(document.forms[0].$Date$.value) ){
		errorMsgArr[$("#Date").attr('tabindex')] = "- SCHEDULE ADJUSTMENT DATE should be in the format MM/DD/YYYY\n";
	}
}
	
Form.CreateSubject = function () {
	document.forms[0].subject.value = document.forms[0].$site$.value + ", " + document.forms[0].$Date$.value + ", " + document.forms[0].$Adjustment$.value;
}

function alertselected(selectobj) {
	if(selectobj.value != "")
	{
		var answer = confirm("You selected "+selectobj.value+". Is that correct?");
		if (answer){
			return answer;
		}
		else{
			var cbo=document.getElementById('site_select_box');
			cbo.selectedIndex=0;
			return answer;
		}
	}
}