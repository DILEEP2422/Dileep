//GET CURRENT DATE:
function currDateYY() {
	$(".date-picker").datepicker('setDate', new Date());
}

$(document).ready(function () {
	currDateYY();
});

Form.FormSpecificReset = function () {
	currDateYY();
}

Form.CreateSubject = function () {
	form_potential_fraud.subject.value = "Potential Fraud Reporting Form - " + form_potential_fraud.$planid$.value;
}