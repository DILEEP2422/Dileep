function disablePrecedInptFld2() {
	var index = $("#groupPlanTable2 .groupLineTemplateSection").length;
	$("#groupPlanTable2 .groupLineTemplateSection").each(function(index) {
		var dollar2manual = ($(this).find("input.accLineManualDollar2").val());
		var dollar2 = ($(this).find("select.dollar2").val());
		if(dollar2=="All") {
			$(this).find("input.accLineManualDollar2").val("");
			$(this).find("input.accLineManualDollar2").prop("disabled",true);
			$(this).find("input.accLineManualDollar2").css('background-color' , '#DEDEDE');
		} else {
			$(this).find("input.accLineManualDollar2").prop("disabled",false);
			$(this).find("input.accLineManualDollar2").css('background-color' , '#FFFFFF');
		}
	})
}

function disablePrecedInptFld() {

	var index = $("#groupPlanTable .groupLineTemplateSection").length;
	$("#groupPlanTable .groupLineTemplateSection").each(function(index) {
		var dollarmanual = ($(this).find("input.accLineManualDollar").val());
		var dollar = ($(this).find("select.dollar").val());
		var fedaralmanual = ($(this).find("input.accLineManualFederal").val());
		var fedaral = ($(this).find("select.fedaral").val());
		var statemanual = ($(this).find("input.accLineManualStateWithHolding").val());
		var state = ($(this).find("select.state").val());
		
		if(dollar=="All") {
			$(this).find("input.accLineManualDollar").val("");
			$(this).find("input.accLineManualDollar").prop("disabled",true);
			$(this).find("input.accLineManualDollar").css('background-color' , '#DEDEDE');
		} else {
			$(this).find("input.accLineManualDollar").prop("disabled",false);
			$(this).find("input.accLineManualDollar").css('background-color' , '#FFFFFF');
		}
		
		if(fedaral=="Default W/H" || fedaral == "None") {
			$(this).find("input.accLineManualFederal").val("");
			$(this).find("input.accLineManualFederal").prop("disabled",true);
			$(this).find("input.accLineManualFederal").css('background-color' , '#DEDEDE');
		} else {
			$(this).find("input.accLineManualFederal").prop("disabled",false);
			$(this).find("input.accLineManualFederal").css('background-color' , '#FFFFFF');
		}
		
		if(state=="Default W/H" || state=="None") {
			$(this).find("input.accLineManualStateWithHolding").val("");
			$(this).find("input.accLineManualStateWithHolding").prop("disabled",true);
			$(this).find("input.accLineManualStateWithHolding").css('background-color' , '#DEDEDE');
		} else {
			$(this).find("input.accLineManualStateWithHolding").prop("disabled",false);
			$(this).find("input.accLineManualStateWithHolding").css('background-color' , '#FFFFFF');
		}
	})
}

function addLineItems() {
	var accountTypeVal = document.getElementById("$ACCOUNTTYPE$").value;
	var requestType = document.getElementById("$REQUESTTYPE$").value;
	var hideWithholdingFlag = showHideFederal(accountTypeVal,requestType);
	
	if(!hideWithholdingFlag) {
		$("#groupLineTemplate .groupLineTemplateSection").clone(true).insertAfter("#groupPlanTable .groupLineTemplateSection:last"); 
		$("#groupPlanTable .groupLineTemplateSection:last").find(".account").focus();
	}
	else {
		$("#groupLineTemplateWithoutWithHolding .groupLineTemplateSection").clone(true).insertAfter("#groupPlanTable .groupLineTemplateSection:last"); 
		$("#groupPlanTable .groupLineTemplateSection:last").find(".account").focus();
	}
	reindexRows();
}

function addLineItems2() {
	$("#groupLineTemplate2 .groupLineTemplateSection").clone(true).insertAfter("#groupPlanTable2 .groupLineTemplateSection:last"); 
	$("#groupPlanTable2 .groupLineTemplateSection:last").find("input.planId").focus();
	reindexRows2();
}

function reindexRows() {
	$(".index").each(function(index){
		$(this).html(index+1);
	});

	if ($("#groupPlanTable .groupLineTemplateSection").length == 1) {
		$("#deleteAccount").hide();
		$("#deleteAccountWithoutWithHolding").hide();
	} else {
		$("#deleteAccount").show();
		$("#deleteAccountWithoutWithHolding").show();		
	}

	if ($("#groupPlanTable .groupLineTemplateSection").length == 10) 
		$("#addAccount").hide();
	else
		$("#addAccount").show();
}

function reindexRows2() {
	$(".index2").each(function(index2){
		$(this).html(index2+1);
	});

	if ($("#groupPlanTable2 .groupLineTemplateSection").length == 1)
		$("#deletePlan").hide();
	else
		$("#deletePlan").show();

	if ($("#groupPlanTable2 .groupLineTemplateSection").length == 10) 
		$("#addPlan").hide();
	else 
		$("#addPlan").show();
}

function checkRequestTypeAndShow(name) {
	if(name=="TRAC") {
		document.getElementById("planDetails").style.display="block";
		document.getElementById("accountDetailsDiv").style.display="none";
		$("#groupPlanTable2").empty();
		$("#groupPlanTable2").append($("#groupLineTemplate2 .groupLineTemplateSection").clone(true));
		reindexRows2();
	} else if(name=="Fee from a fund not in the redemption" || name=="TA2000 redemption" || name=="Special delivery to foreign address" || name=="Other" ) {
		document.getElementById("accountDetailsDiv").style.display="block";
		document.getElementById("planDetails").style.display="none";
		var accountTypeVal = document.getElementById("$ACCOUNTTYPE$").value;
	
		var hideWithholdingFlag = showHideFederal(accountTypeVal,name);
		$("#groupPlanTable").empty();
		if(!hideWithholdingFlag) {
			$("#groupPlanTable").append($("#groupLineTemplate .groupLineTemplateSection").clone(true));
		} else {
			$("#groupPlanTable").append($("#groupLineTemplateWithoutWithHolding .groupLineTemplateSection").clone(true));
		}
		$("#groupPlanTable .groupLineTemplateSection:last").find("input.account").focus();
		reindexRows();
	} else if(name=="") {
		document.getElementById("planDetails").style.display="none";
		document.getElementById("accountDetailsDiv").style.display="none";
	}
	
	if(name=="TRAC" || name=="Special delivery to foreign address") {
		shForm.$AORSITE$.value = "SNO";
	} else {
		shForm.$AORSITE$.value = "";
	}
}

function showHideFederal(accountTypeVal,requestType) {
	var flag=false;
	if(accountTypeVal!="CB&T" && (requestType!="TA200 Fee(R/T Only)" || requestType != "Fee from a fund not in the redemption")) {
		document.getElementById("fedaralId").style.display="none";
		document.getElementById("stateId").style.display="none";
		flag=true;
	} else {
		document.getElementById("fedaralId").style.display="block";
		document.getElementById("stateId").style.display="block";
	}
	return flag;
}

function resetSelection() {
	document.getElementById("$REQUESTTYPE$").value = "";
	document.getElementById("accountDetailsDiv").style.display="none";
	document.getElementById("planDetails").style.display="none";
	$("#groupPlanTable").empty();
	$("#groupPlanTable2").empty();
	reindexRows();
	reindexRows2();
}	

function checkDeliveryTypeAndShow(name, shForm) {
	document.getElementById("$BILLING_NUMBER$").value = '';
	document.getElementById("billingNumberSection").style.display='block';
	if(name=="Overnight Delivery" || name=="Overnight Delivery at AFS Expense" || name=="Overnight Delivery Billed to Third Party") {
		document.getElementById("courierDetails").style.display="block";
		document.getElementById("pickUpDetails").style.display="none";
		
		if(name=="Overnight Delivery at AFS Expense") {
			document.getElementById("billingNumberSection").style.display='none';
		}
		
		if(name=="Overnight Delivery Billed to Third Party") {
			var opt = document.createElement("option");        
			opt.text = "UPS";
			opt.value = "UPS";
			
			document.getElementById("$COURIER$").add(opt);
							
			var opt1 = document.createElement("option");        
			opt1.text = "UPS End of day Saturday";
			opt1.value = "UPS End of day Saturday";
			
			document.getElementById("$SERVICE_REQUESTED$").add(opt1);
			
			var opt2 = document.createElement("option");        
			opt2.text = "UPS Next Day Air by mid-afternoon";
			opt2.value = "UPS Next Day Air by mid-afternoon";
			
			document.getElementById("$SERVICE_REQUESTED$").add(opt2);
		} else {
			if(document.getElementById("$COURIER$").length == 4) {
				document.getElementById("$COURIER$").remove(3);
			}
			
			if(document.getElementById("$SERVICE_REQUESTED$").length > 9) {
				document.getElementById("$SERVICE_REQUESTED$").remove(10);
				document.getElementById("$SERVICE_REQUESTED$").remove(9);
			}
		}
		
	} else if(name=="Shareholder Pick-up") {
		document.getElementById("pickUpDetails").style.display="block";
		document.getElementById("courierDetails").style.display="none";	
	} else if(name=="" || name=="Regular Mail") {
		document.getElementById("pickUpDetails").style.display="none";
		document.getElementById("courierDetails").style.display="none";	
	}
	
	if(name=="Overnight Delivery") {
		document.getElementById("mandate").style.display="none";
	} else {
		document.getElementById("mandate").style.display="";
	}
}

var lineItemGPlanErrors="";
var gpItemString="";

function testGplanLineItem(shForm) {
	gpItemString = "";
	lineItemGPlanError = "";
	shForm.$GROUPPLANLINES$.value="";
	var count = 1;
	$("#groupPlanTable .groupLineTemplateSection").each(function(index) {
		var accountDetails = "";
		var lineIndex = index + 1;
		var account = $.trim($(this).find("input.account").val());
		var fund = $.trim($(this).find("input.fund").val());
		var dollarmanual = $.trim($(this).find("input.accLineManualDollar").val());
		var dollar = $.trim($(this).find("select.dollar").val());
		var fedaralmanual = $.trim($(this).find("input.accLineManualFederal").val());
		var fedaral = $.trim($(this).find("select.fedaral").val());
		var statemanual = $.trim($(this).find("input.accLineManualStateWithHolding").val());
		var state = $.trim($(this).find("select.state").val());
		var error = "false";
		var accountTypeVal = document.getElementById("$ACCOUNTTYPE$").value;
		var requestTypeVal = document.getElementById("$REQUESTTYPE$").value;
		gpItemString = gpItemString + account + ":";
		
		// Formatting account details for mail 
		if((account.length > 0) && (fund.length > 0)) {
			accountDetails =  "\n  ACCOUNT #: " + account + "\n  FUND #: " + fund
		} else {
			error = "true";
		}
		if(dollar.length > 0) {
			if (dollarmanual.length > 0) {
				accountDetails = accountDetails + "\n  DOLLAR AMOUNT: " +  dollarmanual + " " + dollar + "\n";
			} else if(dollar == "All") {
				accountDetails = accountDetails + "\n  DOLLAR AMOUNT: " + dollar + "\n";	
			} else {
				error = "true";
			}
		} else {
			error = "true";
		}
		
		if(accountTypeVal =="CB&T" && (requestTypeVal=="TA2000 redemption" || requestTypeVal=="Fee from a fund not in the redemption" || requestTypeVal=="Special delivery to foreign address" ||  requestTypeVal=="Other")) {
			if(fedaral.length > 0) {
				if(fedaralmanual.length > 0) {
					accountDetails = accountDetails + "  FEDERAL WITHHOLDING: " +  fedaralmanual + " " + fedaral + "\n";
				} else if (fedaral == "Default W/H" || fedaral == "None") {
					accountDetails = accountDetails + "  FEDERAL WITHHOLDING: " + fedaral + "\n";	
				} else {
					error = "true";
				}		
			} else {
				error = "true";
			}
			
			if(state.length > 0) {
				if(statemanual.length > 0) {
					accountDetails = accountDetails + "  STATE WITHHOLDING: " +  statemanual + " " + state + "\n" ;
				} else if(state == "Default W/H" || state == "None") {
					accountDetails = accountDetails + "  STATE WITHHOLDING: " + state + "\n";	
				} else {
					error = "true";
				}		
			} else {
				error = "true";
			}
		}
		
		if(error == "true") {
			gpItemString = "";
			lineItemGPlanErrors += "- Account : Line # " + lineIndex + " is incomplete\n";
		}
		shForm.$GROUPPLANLINES$.value +=  accountDetails ;
	});
}

var lineItemGPlanErrors2="";

function testGplanLineItem2(shForm) {
	gpItemString = "";
	lineItemGPlanErrors2 = "";
	shForm.$GROUPPLANLINES$.value="";
	$("#groupPlanTable2 .groupLineTemplateSection").each(function(index2) {
		var planDetails = "";
		var lineIndex = index2 + 1
		var planId = $.trim($(this).find("input.planId").val());
		var participant = $.trim($(this).find("input.participant").val());
		var SSNo = $.trim($(this).find("input.SSNo").val());
		var fund2 = $.trim($(this).find("input.fund2").val());
		var dollarmanual2 = $.trim($(this).find("input.accLineManualDollar2").val());
		var dollar2 = $.trim($(this).find("select.dollar2").val());
		var error = "false";
		
		// Formatting account details for mail 
		gpItemString = gpItemString + planId + ":";
		
		if((planId.length > 0) && (participant.length > 0) && (SSNo.length > 0) && (fund2.length > 0)) {
			planDetails =  "\n  PLAN ID: " + planId + "\n  PARTICIPANT: " + participant +"\n  TRAC ACCOUNT #: " + fund2+ "\n  SS#: XX-XX-" + SSNo;
		} else {
			error = "true";
		}
		
		if(dollar2.length > 0) {
			if (dollarmanual2.length > 0) {
				planDetails = planDetails + "\n  DOLLAR AMOUNT: " +  dollarmanual2 + " " + dollar2 + "\n";
			} else if(dollar2 == "All") {
				planDetails = planDetails + "\n  DOLLAR AMOUNT: " + dollar2 + "\n";
			} else {
				error = "true";
			}
		} else {
			error = "true";
		}
		
		if(error == "true") {
			gpItemString = "";
			lineItemGPlanErrors2 += "- Plan: Line # " + lineIndex + " is incomplete\n";
		}
		shForm.$GROUPPLANLINES$.value +=  planDetails;
	});
} 

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	
	lineItemGPlanErrors = "";
	lineItemGPlanErrors2 = "";	
	
	if(!shForm.$ACCOUNT_MEMO_ADDED$.checked) {
		errorMsgArr[$("#ACCOUNT_MEMO_ADDED").attr('tabindex')] = "- Account Memo Added\n";
	} else {
		shForm.$ACCOUNT_MEMO_ADDED_TEMP$.value = "YES";
	}
	
	if(shForm.$REQUESTTYPE$.value != "TRAC") {
		testGplanLineItem(shForm);
		if($.trim(lineItemGPlanErrors) != "") {
			errorMsgArr[$("input.account:first").attr('tabindex')] = lineItemGPlanErrors;
		}
	} else {
		testGplanLineItem2(shForm);
		if($.trim(lineItemGPlanErrors2) != "") {
			errorMsgArr[$("input.planId:first").attr('tabindex')] = lineItemGPlanErrors2;
		}
	}
	
	if(shForm.$DELIVERY$.value == "Overnight Delivery" || shForm.$DELIVERY$.value == "Overnight Delivery at AFS Expense" || shForm.$DELIVERY$.value == "Overnight Delivery Billed to Third Party")
	{		
		courierFlag = true;
		shForm.$COURIER_INFO$.value = "";
		if($.trim(shForm.$COURIER$.value) == "") {
			errorMsgArr[$("#\\$COURIER\\$").attr('tabindex')] = "- Courier\n";
			courierFlag = false;
		}

		if(shForm.$DELIVERY$.value!="Overnight Delivery at AFS Expense" && shForm.$DELIVERY$.value!="Overnight Delivery") {
			if($.trim(shForm.$BILLING_NUMBER$.value) == "") {
				errorMsgArr[$("#\\$BILLING_NUMBER\\$").attr('tabindex')] = "- Billing Number\n";
				courierFlag = false;
			}
		}

		if($.trim(shForm.$SERVICE_REQUESTED$.value) == "") {
			errorMsgArr[$("#\\$SERVICE_REQUESTED\\$").attr('tabindex')] = "- Service Requested\n";
			courierFlag = false;
		}
		
		if($.trim(shForm.$SIGNATURE_REQUIRED$.value) == "") {
			errorMsgArr[$("#\\$SIGNATURE_REQUIRED\\$").attr('tabindex')] = "- Signature Required\n";				
			courierFlag = false;
		}
		
		if(courierFlag) {
			shForm.$COURIER_INFO$.value += "\n  COURIER: " + shForm.$COURIER$.value;
			if((shForm.$DELIVERY$.value!="Overnight Delivery at AFS Expense") || shForm.$BILLING_NUMBER$.value!="") 
			{
				shForm.$COURIER_INFO$.value += "\n  BILLING NUMBER: " + shForm.$BILLING_NUMBER$.value;
			}
			shForm.$COURIER_INFO$.value += "\n  SERVICE REQUESTED: " + shForm.$SERVICE_REQUESTED$.value;
			shForm.$COURIER_INFO$.value += "\n  SIGNATURE REQUIRED: " + shForm.$SIGNATURE_REQUIRED$.value;
		}
	}
	if(shForm.$DELIVERY$.value == "Shareholder Pick-up") {
		if(shForm.$SITE_FOR_PICKUP$.value == "") {
			errorMsgArr[$("#\\$SITE_FOR_PICKUP\\$").attr('tabindex')] = "- Site for Pick-Up\n";				
		} else {
			shForm.$SITE_FOR_PICKUP_TEMP$.value = "\nSITE FOR PICK UP: " + shForm.$SITE_FOR_PICKUP$.value;
		}
	}
	
	if(shForm.$SOURCE$.checked && shForm.$TRAC_SHARE_CHECK$.checked) {
		shForm.$ENCLOSURESHIDDEN$.value="\n  ENCLOSURES\n  SOURCE : Y \n  TRAC AND SHARE CHECKS : Y";
	}else if(shForm.$SOURCE$.checked) {
		shForm.$ENCLOSURESHIDDEN$.value="\n  ENCLOSURES\n  SOURCE : Y";
	}else if(shForm.$TRAC_SHARE_CHECK$.checked) {
		shForm.$ENCLOSURESHIDDEN$.value="\n  ENCLOSURES\n  TRAC AND SHARE CHECKS : Y";
	}else {
		shForm.$ENCLOSURESHIDDEN$.value="";
	}
}

Form.CreateSubject = function () {
	createEmailSubject(shForm);
	shForm.subject.value  = emailSubject;
	determineDestinationMailId(shForm.$AORSITE$.value, shForm.$REQUESTTYPE$.value);
}

function determineDestinationMailId(aorSite, requestType)
{
	if (aorSite == "IRV"){
		shForm.Qualifier.value = "IRV";
	} else if (aorSite == "SNO") {
		shForm.Qualifier.value = "SNO";
	} else if (aorSite == "IND") {
		shForm.Qualifier.value = "IND";
	} else if (aorSite == "HRO") {
		shForm.Qualifier.value = "HRO";
	}
}

var emailSubject = "";
function createEmailSubject(shForm) {
	emailSubject = "Special Handle Request";	
	emailSubject += " - ";
	emailSubject += shForm.$AORSITE$.value;
	emailSubject += " - ";
		
	var gparray = new Array(); 
	gparray = gpItemString.split(":");

	if(gparray.length !=0 ) {		
		for(var i =0; i< gparray.length ;i++) {
			if(i<gparray.length-2) {
				if(i<9) {
					emailSubject = emailSubject + gparray[i] + ", ";
				} else if(i==9) {
					emailSubject = emailSubject + gparray[i];
					break;	
				}		
			}
			if(i == gparray.length-2) {
				emailSubject = emailSubject + gparray[i];
			}
		}
	}
}

$("#addAccount").click(function(){addLineItems();});
$("#addAccount").keydown(function(event){if (event.which == 32) addLineItems();});
$("#deleteAccount").click(function(){ $(this).parent().parent().parent().parent().remove();reindexRows();});
$("#deleteAccountWithoutWithHolding").click(function(){ $(this).parent().parent().parent().parent().parent().parent().remove();reindexRows();});			

$("#addPlan").click(function(){addLineItems2();});
$("#addPlan").keydown(function(event){if (event.which == 32) addLineItems2();});
$("#deletePlan").click(function(){$(this).parent().parent().parent().parent().remove();reindexRows2();});

Form.FormSpecificReset = function () {

	$(".numbersOnlyWithSpecialCharecters").keyup(function () { 
		this.value = this.value.replace(/[^0-9\.\,\)\(]/g,'');
		ValidatePhone(this);
	});	

	$("#groupPlanTable").empty();
	$("#groupPlanTable2").empty();
		
	if(shForm.$REQUESTTYPE$.value =="")
	{
		document.getElementById("accountDetailsDiv").style.display="none";
		document.getElementById("planDetails").style.display="none";
	}	
	if(shForm.$DELIVERY$.value =="")
	{
		document.getElementById("courierDetails").style.display="none";
		document.getElementById("pickUpDetails").style.display="none";
	}	
	
	$('.numbersOnlySH').keypress(function (e) {
		var unicode=e.charCode? e.charCode : e.keyCode
		if (unicode!=8){ //if the key isn't the backspace key (which we should allow)
			if (unicode<48||unicode>57) //if not a number
				return false //disable key press
			}
	});
	
	$('.alphaOnlySH').keypress(function (e) {
		var unicode=e.charCode? e.charCode : e.keyCode
		if (unicode!=8){ //if the key isn't the backspace key (which we should allow)
		if ((unicode > 64 && unicode < 91) || (unicode > 96 && unicode < 123))
		   return true;
		else
		   return false;
	  }
	});
	
	$('.numbersOnlyWithDecimalOrCommaSH').keypress(function (e) { 
		var unicode=e.charCode? e.charCode : e.keyCode
		if (unicode!=8){ //if the key isn't the backspace key (which we should allow)
			if((unicode>=48 && unicode<=57) || (unicode ==44|| unicode==46))
				return true;
			else
				return false;
		}
	});
}

function ValidatePhone(m){
	p1 = null;
	p1 = m;
	ValidatePhone1(p1);
}

function ValidatePhone1(p1){
	var p;
	p = "";
	p = p1.value;
	
	if(p.length == 3){
		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ")";
		}
	p1.value=""; p1.value=pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
			p1.value=""; p1.value=pp;

		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
			pp = "(" + p13 + ")" + p14 + p15;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 2 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
			p1.value=""; p1.value=pp;
		}

	}
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}