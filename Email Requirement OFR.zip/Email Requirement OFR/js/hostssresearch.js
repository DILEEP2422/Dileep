Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if (hostssresearch.transactiontype.value == "") {
		errorMsgArr[$("#transactiontype").attr('tabindex')] = "- Choose at least (1) transaction type\n";
	}
}

Form.CreateSubject = function () {
	var my_string = "";
		
	for (var i=0; i<hostssresearch.transactiontype.length; i++){
		if (hostssresearch.transactiontype[i].selected){
			my_string += hostssresearch.transactiontype[i].value + "\r";
		}	
	}
		
	hostssresearch.$transactiontype$.value = my_string;

	if (hostssresearch.$ssrush$.value == "HIGH" || "MEDIUM" || "LOW" ){
		hostssresearch.subject.value = "URGENT - Assign to HOST System Support - Mailbox Research";
	}

	if (hostssresearch.$ssdealername$.value == "" || hostssresearch.$ssdealername$.value == " " ){
		hostssresearch.$ssdealername$.value = "NA";
	}

	if (hostssresearch.$ssdealernumber$.value == "" || hostssresearch.$ssdealernumber$.value == " " ){
		hostssresearch.$ssdealernumber$.value = "NA";
	}

	if (hostssresearch.$ssfundacct$.value == "" || hostssresearch.$ssfundacct$.value == " " ){
		hostssresearch.$ssfundacct$.value = "NA";
	}

	if (hostssresearch.$sscontrolordernumber$.value == "" || hostssresearch.$sscontrolordernumber$.value == " " ){
		hostssresearch.$sscontrolordernumber$.value = "NA";
	}

	if (hostssresearch.$ssrejectreportnumber$.value == "" || hostssresearch.$ssrejectreportnumber$.value == " " ){
		hostssresearch.$ssrejectreportnumber$.value = "NA";
	}

	if (hostssresearch.$ssrejectmessage$.value == "" || hostssresearch.$ssrejectmessage$.value == " " ){
		hostssresearch.$ssrejectmessage$.value = "NA";
	}

	if (hostssresearch.$ssufidsettings$.value == "" || hostssresearch.$ssufidsettings$.value == " " ){
		hostssresearch.$ssufidsettings$.value = "NA";
	}		

	if (hostssresearch.$sssocialcoderestriction$.value == "" || hostssresearch.$sssocialcoderestriction$ == " " ){
		hostssresearch.$sssocialcoderestriction$.value = "NA";
	}		
}