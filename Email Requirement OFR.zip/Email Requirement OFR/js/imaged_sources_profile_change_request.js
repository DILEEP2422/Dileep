Form.FormSpecificReset = function() {
	document.getElementById("grid1").style.display='none';
	document.getElementById("grid2").style.display='none';
	document.getElementById("associateInitials").style.display='none';
}

function ClearTextArea() {
	document.getElementById('ASSO_INITIALS').value="";
	document.getElementById('ASSO_INITIALS').selectionStart = 0;
}

function limitCharSize() {
	var yesOrNo1 = document.getElementById('MULSOURCES');
	var yesOrNo2 = document.getElementById('MULSOURCESUP');
	var data = document.getElementById('ASSO_INITIALS').value;
	
	if(yesOrNo1.value=='MULSOURCES_NO' || yesOrNo2.value=='MULSOURCESUP_NO'){
		data = data.substring(0, 8);
		document.getElementById('ASSO_INITIALS').value = data;
	}
}
		
function customDateFormat() {
	var selectedDate = document.getElementById("$DATE_SOURCE$").value;
	var dateArr = selectedDate.split("/");
	var customFormattedDate = dateArr[0] + "/" + dateArr[1] ;
	document.getElementById("$DATE_SOURCE$").value = customFormattedDate;
}
	
var permanatProfFlag = false;
var tempProfFlag = false;
var liveSource = false;
var reinfoSource = false;

function checkRequestTypeAndShow() {
	var selObjValue = document.getElementById('$REQUESTTYPE$').value;
	
    if(selObjValue!=' ') {
		if (selObjValue == "Permanent Profile Change"){
			permanatProfFlag = true;
			reinfoSource=false;
			tempProfFlag=false;
			liveSource=false;
		}
		if (selObjValue == "Reinforcement Sources"){
			reinfoSource = true;
			permanatProfFlag = false;
			tempProfFlag=false;
			liveSource=false;
		}
		if (selObjValue == "Temporary Profile Change"){
			tempProfFlag = true;
			permanatProfFlag = false;
			reinfoSource=false;
			liveSource=false;
		}
		if (selObjValue == "Live Sources for Training"){
			liveSource = true;
			permanatProfFlag = false;
			reinfoSource=false;
			tempProfFlag=false;
		}
		document.getElementById("associateInitials").style.display='block';
	} else {
		 permanatProfFlag = false;
		 tempProfFlag = false;
		 liveSource = false;
		 reinfoSource = false;
		document.getElementById("grid2").style.display='none';
		document.getElementById("grid1").style.display='none';
		document.getElementById("associateInitials").style.display='none';
	}
	
	if(permanatProfFlag || tempProfFlag) {
		document.getElementById("grid2").style.display='block';
		document.getElementById("grid1").style.display='none';
		document.getElementById("associateInitials").style.display='block';
	} else if(liveSource || reinfoSource) {
		document.getElementById("grid1").style.display='block';
		document.getElementById("grid2").style.display='none';
		document.getElementById("associateInitials").style.display='block';
	}
}


var hasRequestValue = false;
function setRequestTypes() {
	document.getElementById("$REQUEST_TYPES$").value = document.getElementById("$REQUESTTYPE$").value;
} 

var HROFLAG = false;
var INDFLAG = false;
var IRVFLAG = false;
var SNOFLAG = false;
var hasSiteValue = false;

function setSiteSelection() {
	document.getElementById("$SITES$").value = document.getElementById('$SITE$').value;
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if($.trim(document.workManageForm.$HOURS$.value) == "" || $.trim(document.workManageForm.$AMPM$.value) == "")
	{
		errorMsgArr[$("#HOURS").attr('tabindex')] = "- HOUR NEEDED BY\n";
	}
	
	if(liveSource || reinfoSource){
		if($.trim(document.workManageForm.$MULSOURCES$.value) == ""){
			errorMsgArr[$("#MULSOURCES").attr('tabindex')] = "- Do sources need to be placed in multiple folders?\n";
		}
		if($.trim(document.workManageForm.$ASSO_INITIALS$.value) == ""){
			errorMsgArr[$("#ASSO_INITIALS").attr('tabindex')] = "- ASSOCIATE INITIALS\n";
		}
	}
	
	if(permanatProfFlag || tempProfFlag){
		if($.trim(document.workManageForm.$MULSOURCESUP$.value) == "")
		{
			errorMsgArr[$("#MULSOURCESUP").attr('tabindex')] = "- Do multiple associates need to be updated?\n";
		}
		if($.trim(document.workManageForm.$ASSO_INITIALS$.value) == ""){
			errorMsgArr[$("#ASSO_INITIALS").attr('tabindex')] = "- ASSOCIATE INITIALS\n";
		}
	}
}

Form.CreateSubject = function () {
	var emailSubject = "";
	setRequestTypes();
	setSiteSelection();
	var yesOrNo1 = document.getElementById('MULSOURCES');
	var yesOrNo2 = document.getElementById('MULSOURCESUP');
	var data = document.getElementById('ASSO_INITIALS').value;
	var date = document.getElementById('$DATE_SOURCE$').value;
	var requestType = document.getElementById("$REQUESTTYPE$").value;
	var hours = document.getElementById("HOURS").value; 
	var AMPM = document.getElementById("$AMPM$").value; 
	var time = hours +" "+ AMPM;
	var site = document.getElementById('$SITE$').value;
	var emailSubReqType;
	
	if(yesOrNo1.value=='MULSOURCES_YES'){
		document.getElementById('$MULTIPLE$').value = "Do sources need to be placed in multiple folders?: Yes";
	}else if(yesOrNo1.value=='MULSOURCES_NO'){
		document.getElementById('$MULTIPLE$').value = "Do sources need to be placed in multiple folders?: No";
	}else if(yesOrNo2.value=='MULSOURCESUP_YES'){
		document.getElementById('$MULTIPLE$').value = "Do multiple associates need to be updated? Yes";
	}else if(yesOrNo2.value=='MULSOURCESUP_NO'){
		document.getElementById('$MULTIPLE$').value = "Do multiple associates need to be updated? No";
	}
			
	
	if(requestType=="Live Sources for Training"){
		emailSubReqType = "live work by";
	}else if(requestType=="Reinforcement Sources"){
		emailSubReqType = "reinforcement work by";
	}else if(requestType=="Temporary Profile Change"){
		emailSubReqType = "temporary prof change by";
	}else if(requestType=="Permanent Profile Change"){
		emailSubReqType = "permanent prof change by";
	}
		
	emailSubject = date +" "+ emailSubReqType +" "+ time +" "+site;
	
	if(yesOrNo1.value=='MULSOURCES_NO' || yesOrNo2.value=='MULSOURCESUP_NO'){
		emailSubject =  emailSubject + " " +data;
	}else{
		emailSubject = emailSubject + " VARIOUS";
	}
	
	$("#subject").val(emailSubject);
}