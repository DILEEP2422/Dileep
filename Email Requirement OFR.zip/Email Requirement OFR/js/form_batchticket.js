function currDate() {
	today = new Date();
	var month = today.getMonth() + 1;
	var day = today.getDate();
	var year = today.getFullYear();
	var dateString = month + "/" + day + "/" + year;
	return dateString;
}

function calcPlans() { 	
	var amt = document.getElementById("$amount$").value;
	if (amt == ""){amt = "0";}
	amt = amt.replace(/,/g, ""); // remove commas for conversion/calcs

	var amt2 = document.getElementById("$amount2$").value;
	if (amt2 == ""){amt2 = "0";}	
	amt2 = amt2.replace(/,/g, ""); 
		
	var amt3 = document.getElementById("$amount3$").value;
	amt3 = amt3.replace(/,/g, ""); 
	if (amt3 == ""){amt3 = "0";}
				
	var amt4 = document.getElementById("$amount4$").value;
	if (amt4 == ""){amt4 = "0";}		
	amt4 = amt4.replace(/,/g, "");
		
	// CHECK FOR NON-NUMBERS		
	if (isNaN(amt) || isNaN(amt2) || isNaN(amt3) ||	isNaN(amt4)) {
		alert("Please check Processing Amounts in Section 3.  A non-numeric value was detected.");
	} else {
		var proctotal = (parseFloat(amt) + parseFloat(amt2) + parseFloat(amt3) + parseFloat(amt4)).toFixed(2);
		document.getElementById("$amounttotal$").value = proctotal;
	}		 
}

function calcDeposit() { 	
	var ovund = document.getElementById("$overunder$").value;
	if (ovund == ""){ovund = "0";}
	ovund = ovund.replace(/,/g, ""); // remove commas for conversion/calcs

	var manchk = document.getElementById("$mancheck$").value;
	if (manchk == ""){manchk = "0";}	
	manchk = manchk.replace(/,/g, ""); 

	var forf = document.getElementById("$forfeiture$").value;
	if (forf == ""){forf = "0";}
	forf = forf.replace(/,/g, ""); 

	var loan = document.getElementById("$loan$").value;
	if (loan == ""){loan = "0";}
	loan = loan.replace(/,/g, "");

	var redempt = document.getElementById("$redemption$").value;
	if (redempt == ""){redempt = "0";}
	redempt = redempt.replace(/,/g, "");

	var interest = document.getElementById("$interest$").value;
	if (interest == ""){interest = "0";}	
	interest = interest.replace(/,/g, "");
		
	var correct = document.getElementById("$correction$").value;
	if (correct == ""){correct = "0";}	
	correct = correct.replace(/,/g, "");
		
	// CHECK FOR NON-NUMBERS		
		
	if (isNaN(ovund) || isNaN(manchk) || isNaN(forf) || isNaN(loan) || isNaN(redempt) || isNaN(interest) || isNaN(correct)) { 
		alert("Please check Processing Amounts in Section 4.  A non-numeric value was detected.");
	} else {
		var deptotal = (parseFloat(document.getElementById("$amounttotal$").value) + parseFloat(ovund)  ).toFixed(2);
		document.getElementById("$total$").value = deptotal;
	}		 
}
	
function recalcAll() {
	calcPlans();
	calcDeposit();	
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if (!document.getElementById("yesconv").checked && !document.getElementById("noconv").checked ){
		errorMsgArr[$("#yesconv").attr('tabindex')] = "- Is QC needed?\n";
	}			
	
	if (document.getElementById("yesconv").checked && $.trim($("#\\#qap\\#").val()) == "" ){
		errorMsgArr[$("#\\#qap\\#").attr('tabindex')] = "- QCer's Initials\n";
	}
}

Form.CreateSubject = function () {
	var convchkd = document.getElementById("yesconv").checked;
	if (convchkd) {
		form_batchticket.Qualifier.value = "QC";
		form_batchticket.subject.value = "TRAC - "+form_batchticket.$site$.value+" - "+form_batchticket.$planid$.value+" - $"+form_batchticket.$total$.value +
			" - " + form_batchticket.$batch$.value;	;	
	} else {

		form_batchticket.subject.value = "TRAC - "+form_batchticket.$site$.value+" - "+form_batchticket.$planid$.value+" - $"+form_batchticket.$total$.value +
		" - " + form_batchticket.$batch$.value;	
	}			
}
  
function togglePRD() {
	var usecurr = document.getElementById("$usetoday$").checked;
	if (usecurr) {
		document.getElementById("$payroll$").value = currDate();
	} else {
		document.getElementById("$payroll$").value = "";
	}
}