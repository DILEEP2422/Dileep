function resetConfirmationSection () {
	$("#batchTicketConfirmation #confirmationTradeDate").html("");
	$("#batchTicketConfirmation #fieldDepositTotal").html("");
	$("#batchTicketConfirmation #fieldBatchNumber").html("");
	$("#batchTicketConfirmation #fieldAccountType").html("");
	$("#batchTicketConfirmation #fieldCashEquivalent").html("");
	$("#batchTicketConfirmation #fieldTradeDate").html("");
	$("#batchTicketConfirmation #fieldReasonCode").html("");
	$("#batchTicketConfirmation #loadtime").html("");
}

Form.OnSuccess = function () {
	Form.ShowDialog();
	$("#confirmationAlert").html("Your request is submitted successfully");
	$(".modal-content.submissionResult").addClass('success');
	$(".modal-content.submissionResult .btn").toggleClass('btn-success', true);
	$(".modal-content.submissionResult .btn").toggleClass('btn-danger', false);
	if (btiForm.$INPAPER$.value == "Y") {
		$(".modal-content.submissionResult .btn").click( function() { $("#btiForm").hide(); $("#batchTicketConfirmation").show(); });
	} else {
		$(".modal-content.submissionResult .btn").click( function() { Form.EnableForm(); Form.FormReset(); });
	}
}

Form.FormSpecificReset = function () {
	$("#batchTicketConfirmation").hide();
	$("#btiForm").show();
	
	
	$("#batchTicketTable").empty();
	$("#batchTicketTable").append($("#batchTicketLineTemplate .batchTicketLineSection").clone(true)); 
	$("#batchTicketTable .batchTicketLineSection:last").find("input.processingAmount").autoNumeric({aSign: '$'});
	reindexRows();
	
	document.getElementById('$ACCOUNTTYPE$').focus(); 
	
	$("#optional_approver").hide(0);
	$("#APPROVER").val("");
	$("#approver_message").hide(0);
	$("#manual_check_question").hide(0);
	$("#processingTotalReadOnly").text("$0.00");
	$("#outOfBalanceReadOnly").text("$0.00");
	$("#outOfBalanceReadOnly").css("color", "black");
		
	$("#REASONCODE").blur(function(){
		if (this.value.length == 0) {
			if ($("#optional_approver").css("display") != "none") {
				$("#approver_message").hide(250);
				$("#optional_approver").delay(100).hide(250);
				$("#APPROVER").val("");
			}
		} else if (this.value.length > 0){
			if ($("#optional_approver").css("display") == "none") {
				$("#optional_approver").slideDown(250);
				$("#approver_message").hide(0).delay(250).slideDown(250);
				$("#APPROVER").focus();
			}
		}
	});

	$("#MANUALCHECK").change(function() {
		if (btiForm.MANUALCHECK.checked) {
			$("#manualCheckDetails").slideDown(500);
		} else if (!btiForm.MANUALCHECK.checked) {
			btiForm.manualCheckAccount.value = "";
			btiForm.manualCheckFund.value = "";
			$("#manualCheckDetails").slideUp(500);
		}
	});
	
	resetConfirmationSection();
}

$(document).ready(function () {
	$(".add").click(function(){addLineItems();});
	$(".add").keydown(function(event){if (event.which == 32) addLineItems();});
	$(".delete").click(function(){$(this).parent().parent().parent().remove();reindexRows();recalculateTotals();});
	$("input.processingAmount, #feeAmount, #depositTotal ").blur(function(){recalculateTotals();});
	$("span.todaybutton").click(function(){applyTodaysDate();});
	$("span.todaybutton").keydown(function(event){if (event.which == 32) applyTodaysDate();});
	$("#feeAmount").autoNumeric({aSign: '$'});
	$("#depositTotal").autoNumeric({aSign: '$'});
});

function getUniqueAccountNumbers() {
	var accountNumbers = new Array();

	$("input.accountNumber").each(function (){
		if (this.value != "") {accountNumbers.push((this).value);}
	});
	
	var uniqueAccountNumbers = new Array();
	var numberOfAccounts = accountNumbers.length;
	
	for (var i=0; i<numberOfAccounts; i++) {
		for(var j=i+1; j<numberOfAccounts; j++)
			if (accountNumbers[i] === accountNumbers[j]) {
				j = ++i;
			}
			uniqueAccountNumbers.push(accountNumbers[i]);
	}
	
	uniqueAccountNumbers = uniqueAccountNumbers.sort(sortNumber);
	return uniqueAccountNumbers.join(", ");
}

function sortNumber(a,b) {
	return a - b;
}

function applyTodaysDate() {
	var today = new Date(); 
	var dd = today.getDate(); 
	var mm = today.getMonth()+1;
	var yyyy = today.getFullYear(); 

	if (dd<10) {dd="0"+dd};
	if (mm<10){mm="0"+mm}; 

	var today = mm+"/"+dd+"/"+yyyy; 
	
	$("#TRADEDATE").val(today);
	$("#REASONCODE").focus();
}


function recalculateTotals() {
	var total = 0.00;
	var fee = parseFloat($("#feeAmount").autoNumericGet());
	var depositTotal = parseFloat($("#depositTotal").autoNumericGet());
	var outofbalance = 0.00
	
	$("input.processingAmount").each(function(){
		total += parseFloat($(this).autoNumericGet());
	});
	
	outofbalance = depositTotal - (total.toFixed(2) + fee);
	
	$("#processingTotal").autoNumericSet(total, {aSign: '$', vMin: '0.00', vMax: '99999999999.99'});
	$("#OOB").autoNumericSet(outofbalance, {aSign: '$', vMin: '-99999999999.99', vMax: '99999999999.99'});
	
	$("#processingTotalReadOnly").text($("#processingTotal").val());
	$("#outOfBalanceReadOnly").text($("#OOB").val());
	
	if (outofbalance > 0) {
		$("#outOfBalanceReadOnly").css("color", "green");
		if ($("#manual_check_question").css("display") == "none") {
			$("#manual_check_question").show(250);
			$("#MANUALCHECK").prop("checked", "checked");
		}
	}
	else if (outofbalance < 0) {
		$("#outOfBalanceReadOnly").css("color", "red");
		if ($("#manual_check_question").css("display") != "none") {
			$("#manual_check_question").hide(250);
			$("#MANUALCHECK").removeAttr("checked");
		}
	}
	else if (outofbalance == 0) {
		$("#outOfBalanceReadOnly").css("color", "black");
		if ($("#manual_check_question").css("display") != "none") {
			$("#manual_check_question").hide(250);
			$("#MANUALCHECK").removeAttr("checked");
		}
	}
}
function addLineItems(){
	$("#batchTicketLineTemplate .batchTicketLineSection").clone(true).insertAfter("#batchTicketTable .batchTicketLineSection:last"); 
	$("#batchTicketTable .batchTicketLineSection:last input.fund").focus();
	$("#batchTicketTable .batchTicketLineSection:last input.processingAmount").autoNumeric({aSign: '$'});
	reindexRows();
}

var lineItemErrors = "";

function reindexRows(){
	Form.SetTabIndex();
	$(".index").each(function(index){
		$(this).html(index+1);
	});

	if ($("#batchTicketTable .batchTicketLineSection").length == 1) $(".delete").hide();
	else $(".delete").show();

	if ($("#batchTicketTable .batchTicketLineSection").length == 50) $(".add").hide();
	else $(".add").show();
}

function testLineItems(form, errorMsgArr) {

	form.$BATCHTICKETLINES$.value = "";

	$("#batchTicketTable .batchTicketLineSection").each(function(index) {
		var lineIndex = index + 1;
		var lineFundNumber = $.trim($(this).find("input.fund").val());
		var lineAccount = $(this).find("input.accountNumber").val();
		var processingAmount = $.trim($(this).find("input.processingAmount").val());

		//test if any cells have value
		if (lineFundNumber.length > 0 || lineAccount.length > 0 || processingAmount.length > 0) {
			//test that all cells have value
			if (lineFundNumber.length > 0 && lineAccount.length > 0 && processingAmount.length > 0) {
				//if they do create the Batch Ticket Lines to pass to the mail servlet
				form.$BATCHTICKETLINES$.value += padSpacesToRight(lineFundNumber, 7);
				form.$BATCHTICKETLINES$.value += padSpacesToRight(lineAccount, 15);  
				form.$BATCHTICKETLINES$.value += padSpacesToLeft(processingAmount, 18) + "\n";
			}
			//otherwise indicate that the line is incomplete
			else {
				errorMsgArr[$(this).find("input.accountNumber").attr('tabindex')] = "- BATCH TICKET: Line # " + lineIndex + " is incomplete\n";
			}
		}
	});
	
	if (form.$BATCHTICKETLINES$.value.length == 0) {
		errorMsgArr[$("#feeAmount").attr('tabindex')] = "- At least one BATCH TICKET line must be complete\n";
	}
}

function generateBatchTicketLinesSection(form) {
	form.$BATCHTICKETLINES$.value += "\nPROCESSING TOTAL:" + padSpacesToLeft($("#processingTotalReadOnly").text(), 23);

	if ($.trim(form.feeAmount.value).length != 0) {
		form.$BATCHTICKETLINES$.value += "\nFEE:" + padSpacesToLeft($("#feeAmount").val(), 36);
	}
	
	form.$BATCHTICKETLINES$.value += "\nDEPOSIT TOTAL:" + padSpacesToLeft($("#depositTotal").val(), 26);
	
	if ($("#outOfBalanceReadOnly").text() != "$0.00") {
		form.$BATCHTICKETLINES$.value += "\nOUT OF BALANCE +/-:" + padSpacesToLeft($("#outOfBalanceReadOnly").text(), 21);
	}
	
	if (form.$CASHEQUIVALENT$.checked == true) {
			form.$BATCHTICKETLINES$.value += "\n\nCASH EQUIVALENT: Y";
		} else if (form.$CASHEQUIVALENT$.checked == false) {
			form.$BATCHTICKETLINES$.value += "\n\nCASH EQUIVALENT: N";
		}
	
	if (form.MANUALCHECK.checked ) {
		form.$BATCHTICKETLINES$.value += "\n\nMANUAL CHECK ISSUED FOR OVERAGE FROM: " + btiForm.manualCheckAccount.value + " / " + btiForm.manualCheckFund.value;
	}
	
}

function padSpacesToRight(inputstring, totalLength){
	var returnstr=inputstring;
	for (var i = inputstring.length; i<totalLength; i++) {
		returnstr += " ";
	}
	return returnstr;
}

function padSpacesToLeft(inputstring, totalLength){
	var returnstr="";
	for (var i = 1; i<totalLength-inputstring.length; i++) {
		returnstr += " ";
	}
	returnstr += inputstring;
	return returnstr;
}

function generateTradeDateSection(form){
	form.$TRADEDATE$.value = "TRADE DATE: " + form.TRADEDATE.value;
	if ($.trim(form.REASONCODE.value).length != 0) {
		form.$TRADEDATE$.value += "\nREASON CODE: " + form.REASONCODE.value;
		form.$TRADEDATE$.value += "\nAPPROVER: " + form.APPROVER.value;
	}
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	var btiForm = document.getElementById("btiForm");
	if (validateDate($.trim(btiForm.TRADEDATE.value),'p') == false){
		errorMsgArr[$("#TRADEDATE").attr('tabindex')] = "- Invalid Trade Date\n";
	}
	
	testLineItems(btiForm, errorMsgArr);
	
	if (btiForm.MANUALCHECK.checked) {
		if (btiForm.manualCheckAccount.value == "") {
			errorMsgArr[$("#manualCheckAccount").attr('tabindex')] = "- Manual Check Issued From - Account\n";
		}
		if (btiForm.manualCheckFund.value == "") {
			errorMsgArr[$("#manualCheckFund").attr('tabindex')] = "- Manual Check Issued From - Fund\n";
		}
	} 
}

Form.CreateSubject = function () {
	var btiForm = document.getElementById("btiForm");
	generateTradeDateSection(btiForm);
	generateBatchTicketLinesSection(btiForm);
	btiForm.subject.value = "Batch Ticket - " +btiForm.$SITE$.value + " - "+$.trim(btiForm.processingTotal.value)+ " - " + getUniqueAccountNumbers();
		
	if (btiForm.$CASHEQUIVALENT$.checked == true) {
		btiForm.$CASHEQ$.value = "Y";
	} else if (btiForm.$CASHEQUIVALENT$.checked == false) {
		btiForm.$CASHEQ$.value = "N";
	}
		
	if (btiForm.$INPAPER$.value == "Y") {
		updateConfirmationSection();
	}
}

function updateConfirmationSection() {
	$("#batchTicketConfirmation #confirmationTradeDate").html($("#TRADEDATE").val());
	$("#batchTicketConfirmation #fieldDepositTotal").html($("#depositTotal").val());
	$("#batchTicketConfirmation #fieldBatchNumber").html($("#\\$BATCH\\$").val());
	$("#batchTicketConfirmation #fieldAccountType").html($("#\\$ACCOUNTTYPE\\$").val());
	$("#batchTicketConfirmation #fieldCashEquivalent").html($("#\\$CASHEQ\\$").val());
	$("#batchTicketConfirmation #fieldTradeDate").html($("#TRADEDATE").val());
	$("#batchTicketConfirmation #fieldReasonCode").html($("#REASONCODE").val());
	$("#batchTicketConfirmation #loadtime").html(new Date());
}

function validateDate(fld,rng) {
	var dd, mm, yy;
	var today = new Date;
	var t = new Date;
	fld = stripBlanks(fld);

	if (fld == '') return false;

	var d1 = fld.split('\/');

	if (d1.length != 3) d1 = fld.split(' ');
	if (d1.length != 3) return false;
	dd = d1[1]; mm = d1[0]; yy = d1[2];
	
	var n = dd.lastIndexOf('st');
	
	if (n > -1) dd = dd.substr(0,n);
	n = dd.lastIndexOf('nd');

	if (n > -1) dd = dd.substr(0,n);
	n = dd.lastIndexOf('rd');
	
	if (n > -1) dd = dd.substr(0,n);
	n = dd.lastIndexOf('th');

	if (n > -1) dd = dd.substr(0,n);
	n = dd.lastIndexOf(',');
	
	if (n > -1) dd = dd.substr(0,n);
	n = mm.lastIndexOf(',');

	if (n > -1) mm = mm.substr(0,n);

	if (!isNumber(dd)) return false;
	if (!isNumber(yy)) return false;
	
	if (!isNumber(mm)) {
		var nn = mm.toLowerCase();
		for (var i=1; i < 13; i++) {
			if (nn == mth[i] || nn == mth[i].substr(0,3)) {
				mm = i;
				i = 13;
			}
		}
	}

	if (!isNumber(mm)) return false;
	dd = parseFloat(dd); mm = parseFloat(mm); yy = parseFloat(yy);
	
	
	if (yy < 100 && yy > 40) yy += 1900;
	if (yy < 40) yy += 2000;
	if (yy < 1941 || yy > 2025) return false;
	
	if (mm == 2 && (yy%400 == 0 || (yy%4 == 0 && yy%100 != 0))) day[1]=29;
	else day[1]=28;

	if (mm < 1 || mm > 12) return false;
	if (dd < 1 || dd > day[mm-1]) return false;

	t.setDate(dd); 
	t.setMonth(mm-1); 
	t.setFullYear(yy);

	if (rng == 'p' || rng == 'P') {
		if (t > today) return false;
	}

	else if (rng == 'f' || rng == 'F') {
		if (t < today) return false;
	}

	else if (rng != 'a' && rng != 'A') return false;
	
	return t;
}

function stripBlanks(fld) {
	var result = "";
	var c=0;
	
	for (i=0; i<fld.length; i++) {
		if (fld.charAt(i) != " " || c > 0) {
			result += fld.charAt(i);
			if (fld.charAt(i) != " ") c = result.length;
		}
	}
	
	return result.substr(0,c);
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = $.trim(str);
    }
}

function isNumber(parm) {
	return isValid(parm,numb);
}

var numb = '0123456789';
var day = new Array(31,28,31,30,31,30,31,31,30,31,30,31);

function isValid(parm,val) {
	if (parm == "") return false;
	for (i=0; i<parm.length; i++) {
		if (val.indexOf(parm.charAt(i),0) == -1) return false;
	}
	return true;
}