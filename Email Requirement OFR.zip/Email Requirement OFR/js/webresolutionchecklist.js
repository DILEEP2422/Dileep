Form.FormSpecificReset = function () {
	hidePRdetails();
	document.getElementById("helpdeskInitials").style.display = "none";
	document.getElementById("helpdeskMemberInitials").value = "";	
	document.getElementById("helpdeskMemberInitials").classList.remove("validate-required");
	document.getElementById("helpdeskMemberInitials").removeAttribute("data-msg-validate-required");
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	
	if (!webresolutionchecklist.helpdeskyes.checked && !webresolutionchecklist.helpdeskno.checked ) {
		errorMsgArr[$("#helpdeskyes").attr('tabindex')] = "- Was the Help Desk contacted regarding this situation?\n";
	}	
	
	if (!webresolutionchecklist.ccacheyes.checked && !webresolutionchecklist.ccacheno.checked ) {
		errorMsgArr[$("#ccacheyes").attr('tabindex')] = "- Did you have the user clear their cache?\n";
	}
		//INYPIYP -start AFSIT-26240
	if (!webresolutionchecklist.cobrowseyes.checked && !webresolutionchecklist.cobrowseno.checked ) {
	errorMsgArr[$("#cobrowseyes").attr('tabindex')] = "- Did you use Co-Browse?\n";
	}

	if (!webresolutionchecklist.recreateIssueyes.checked && !webresolutionchecklist.recreateIssueno.checked ) {
	errorMsgArr[$("#recreateIssueyes").attr('tabindex')] = "- Did you try to recreate the issue?\n";
	}

	if (!webresolutionchecklist.rpanotesyes.checked && !webresolutionchecklist.rpanotesno.checked ) {
	errorMsgArr[$("#rpanotesyes").attr('tabindex')] = "- Did you check RPA for any notes that may affect websites?\n";
	}

	if (!webresolutionchecklist.smartdeskyes.checked && !webresolutionchecklist.smartdeskno.checked ) {
	errorMsgArr[$("#smartdeskyes").attr('tabindex')] = "- Did you check Smartdesk settings?\n";
	}

	if ($.trim(webresolutionchecklist.$devicetype$.value == "")) {
	errorMsgArr[$("#devicetype").attr('tabindex')] = "- Device Type (PC or MAC / desktop/laptop/phone/tablet)\n";
	}
//INYPIYP -end AFSIT-26240
	if (webresolutionchecklist.$inprog$.checked && $.trim(webresolutionchecklist.$prdate$.value) == "") {
		errorMsgArr[$("#\\$prdate\\$").attr('tabindex')] = "- Payroll Date\n";
	}

	if (webresolutionchecklist.$inprog$.checked && $.trim(webresolutionchecklist.$batchnum$.value) == "") {
		errorMsgArr[$("#\\$batchnum\\$").attr('tabindex')] = "- Batch Number\n";
	}
	
	if (webresolutionchecklist.$inprog$.checked && $.trim(webresolutionchecklist.$pramount$.value) == "") {
		errorMsgArr[$("#\\$pramount\\$").attr('tabindex')] = "- Payroll Amount\n";
	}		

	if (webresolutionchecklist.$inprog$.checked && $.trim(webresolutionchecklist.$funding$.value) == "") {
		errorMsgArr[$("#\\$funding\\$").attr('tabindex')] = "- Funding Information\n";
	}
	
	if (webresolutionchecklist.$inprog$.checked && webresolutionchecklist.$funding$.value == "Other" && $.trim(webresolutionchecklist.$fundcomm$.value) == "") {
		errorMsgArr[$("#\\$funding\\$").attr('tabindex')] = "- Funding Comments\n";
	}	
}

Form.CreateSubject = function () {
	
	if ($.trim(webresolutionchecklist.$planID$.value) == "") {
		webresolutionchecklist.$planID$.value = "No Plan ID";
	}	
	var priority=webresolutionchecklist.$priority$.value;
	if ($.trim(priority) == "RUSH") {
		priority = " *RUSH";
	}
	else 
	{	priority = "";}
	webresolutionchecklist.subject.value = webresolutionchecklist.$planID$.value + " (Site: "+ webresolutionchecklist.$website$.value +")"+ " - Resolution Checklist Submission -"+ " Regular.Work.WebSME." + priority ;
}					
	 
	 
function toggleccache() {
	if (document.getElementById("ccacheyes").checked) {
		document.getElementById("$hidcc$").value = "Yes";
	} else if (document.getElementById("ccacheno").checked) {
		document.getElementById("$hidcc$").value = "No";
	}
}
//INYPIYP -start AFSIT-26240
function websiteonchange(val){
	if(val == "EEE Website" || val == "Sponsor" || val == "TPA"){
	webresolutionchecklist.$pswID$.classList.add("validate-required");
	document.getElementById("pswIDLabel").innerHTML = '<span class="redText">*</span>PSW ID:';
	if(val == "EEE Website"){
	webresolutionchecklist.$EEEWebsiteUrl$.classList.add("validate-required");
	webresolutionchecklist.$planID$.classList.add("validate-required");
	webresolutionchecklist.$ssn$.classList.add("validate-required");
	document.getElementById("EEEWebsiteUrlLabel").innerHTML = '<span class="redText">*</span>EEE Website URL:';
	document.getElementById("planIDLabel").innerHTML = '<span class="redText">*</span>Plan ID:';
	document.getElementById("ssnLabel").innerHTML = '<span class="redText">*</span>SSN:';
	}
	else{
	webresolutionchecklist.$EEEWebsiteUrl$.classList.remove("validate-required");
	webresolutionchecklist.$planID$.classList.remove("validate-required");
	webresolutionchecklist.$ssn$.classList.remove("validate-required");
	document.getElementById("EEEWebsiteUrlLabel").innerHTML = 'EEE Website URL:';
	document.getElementById("planIDLabel").innerHTML = 'Plan ID:';
	document.getElementById("ssnLabel").innerHTML = 'SSN:';
	}
	}
	else{
	webresolutionchecklist.$pswID$.classList.remove("validate-required");
	webresolutionchecklist.$EEEWebsiteUrl$.classList.remove("validate-required");
	webresolutionchecklist.$planID$.classList.remove("validate-required");
	webresolutionchecklist.$ssn$.classList.remove("validate-required");
	document.getElementById("pswIDLabel").innerHTML = 'PSW ID:';
	document.getElementById("EEEWebsiteUrlLabel").innerHTML = 'EEE Website URL:';
	document.getElementById("planIDLabel").innerHTML = 'Plan ID:';
	document.getElementById("ssnLabel").innerHTML = 'SSN:';
	}
}
function togglecobrowse() {
	if (document.getElementById("cobrowseyes").checked) {
		document.getElementById("$hidcobrowse$").value = "Yes";
	} else if (document.getElementById("cobrowseno").checked) {
		document.getElementById("$hidcobrowse$").value = "No";
	}
}

function togglerecreateissues() {
	if (document.getElementById("recreateIssueyes").checked) {
		document.getElementById("$hidrecreateIssue$").value = "Yes";
	} else if (document.getElementById("recreateIssueno").checked) {
		document.getElementById("$hidrecreateIssue$").value = "No";
	}
}

function togglerpanotes() {
	if (document.getElementById("rpanotesyes").checked) {
		document.getElementById("$hidrpanotes$").value = "Yes";
	} else if (document.getElementById("rpanotesno").checked) {
		document.getElementById("$hidrpanotes$").value = "No";
	}
}
function togglesmartdesk() {
	if (document.getElementById("smartdeskyes").checked) {
		document.getElementById("$hidsmartdesk$").value = "Yes";
	} else if (document.getElementById("smartdeskno").checked) {
		document.getElementById("$hidsmartdesk$").value = "No";
	}
}
//INYPIYP -end	AFSIT-26240

function togglehelpdesk() {
	if (document.getElementById("helpdeskyes").checked) {
		document.getElementById("$hidhelpdesk$").value = "Yes";
		document.getElementById("helpdeskMemberInitials").classList.add("validate-required");
		document.getElementById("helpdeskMemberInitials").setAttribute("data-msg-validate-required","- Initials of Help Desk Member");
		document.getElementById("helpdeskInitials").style.display = "block";
		
	} else if (document.getElementById("helpdeskno").checked) {
		document.getElementById("$hidhelpdesk$").value = "No";
		document.getElementById("helpdeskInitials").style.display = "none";
		document.getElementById("helpdeskMemberInitials").value = "";
		document.getElementById("helpdeskMemberInitials").classList.remove("validate-required");
		document.getElementById("helpdeskMemberInitials").removeAttribute("data-msg-validate-required");
	}
}

function toggleInProg() {
	if (webresolutionchecklist.$inprog$.checked) {
		document.getElementById("$inprog$").value = "Yes";
		webresolutionchecklist.$issue$.value = "N/A";
		showPRdetails();
	} else {
		webresolutionchecklist.$issue$.value = "";
		document.getElementById("$inprog$").value = "No";
		hidePRdetails();
	}
}	

function showPRdetails() {
	document.getElementById("ipfields").style.display = "block";
}					 

function hidePRdetails() {
	document.getElementById("ipfields").style.display = "none";
	$("#ipfields").find("input").each(function() {
		$(this).val("");
	});
	
	$('#\\$funding\\$').val(0);
	
	hideFC();
}	

function toggleFC() {
	if(webresolutionchecklist.$funding$.value == "Other") {
		showFC();
	} else {
		hideFC();
	}
}

function showFC() {
	document.getElementById("fcomm").style.display="block";
}	

function hideFC() {
	document.getElementById("$fundcomm$").value = "";
	document.getElementById("fcomm").style.display="none";
}