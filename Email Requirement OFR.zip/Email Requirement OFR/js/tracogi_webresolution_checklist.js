$("#addGPurch").click(function(){addLineItems();});
$("#addGPurch").keydown(function(event){if (event.which == 32) addLineItems();});
$("#deleteGPurch").click(function(){$(this).parent().parent().parent().remove(); reindexRows();});

$("#addPlan").click(function(){addLineForPlan();});
$("#addPlan").keydown(function(event){if (event.which == 32) addLineForPlan();});
$("#deletePlan").click(function(){$(this).parent().parent().parent().remove();reindexRowsForPlan();});

$("#addPSW").click(function(){addLineForPsw();});
$("#addPSW").keydown(function(event){if (event.which == 32) addLineForPsw();});
$("#deletePsw").click(function(){$(this).parent().parent().parent().remove();reindexRowsForPsw();});

Form.FormSpecificReset = function () {
	document.getElementById('$SITE$').focus(); 
	
	document.getElementById("divtrac").style.display="none";
	document.getElementById("divogi").style.display="none";  
	
	$("#gPurchTable").empty();
	$("#gPurchTable").append($("#gPurchLineTemplate #gPurchLineTemplateSection").clone(true));  
	reindexRows();
	
	$("#tracPlanTable").empty();
	$("#tracPlanTable").append($("#tracPlanTemplate #tracPlanTemplateSection").clone(true)); 
	reindexRowsForPlan();
	
	$("#tracPSWTable").empty();
	$("#tracPSWTable").append($("#tracPSWTemplate #tracPSWTemplateSection").clone(true)); 
	reindexRowsForPsw();
	
	document.getElementById("otheroperatingsystem").style.display="none";  	
	document.getElementById("otherbrowser").style.display="none";  	
	
}

function showdropwebsitedown(name){    
	
	if(name=="OGI Website"){
		document.getElementById("divtrac").style.display="none";
		document.getElementById("divogi").style.display="block";
		$("#tracPlanTable").empty();
		$("#tracPSWTable").empty();
		if ($("#gPurchTable #gPurchLineTemplateSection").length == 0)
		$("#gPurchTable").append($("#gPurchLineTemplate #gPurchLineTemplateSection").clone(true));
		reindexRows();
	}
	else if(name=='TRAC Plan Sponsor Website'){
		document.getElementById("divogi").style.display="none";    
		document.getElementById("divtrac").style.display="block"; 
		if ($("#tracPlanTable #tracPlanTemplateSection").length == 0)
			$("#tracPlanTable").append($("#tracPlanTemplate #tracPlanTemplateSection").clone(true));
		if ($("#tracPSWTable #tracPSWTemplateSection").length == 0)
			$("#tracPSWTable").append($("#tracPSWTemplate #tracPSWTemplateSection").clone(true));
		$("#gPurchTable").empty(); 
		reindexRowsForPlan();
		reindexRowsForPsw();
	}
	else{
		document.getElementById("divtrac").style.display="none";
		document.getElementById("divogi").style.display="none";  
		$("#tracPlanTable").empty();
		$("#tracPSWTable").empty(); 
		$("#gPurchTable").empty();
	}
} 

function showoperdrop(name){    
	if(name=="Other"){
		document.getElementById("otheroperatingsystem").style.display="block"; 
	}
	else{
		document.getElementById("otheroperatingsystem").style.display="none"; 
	}
}
function showotherbrowser(name){
	if(name=="Other"){
		document.getElementById("otherbrowser").style.display="block"; 
	}
	else{
		document.getElementById("otherbrowser").style.display="none"; 
	}
}

function addLineItems(){
	$("#gPurchLineTemplate #gPurchLineTemplateSection").clone(true).appendTo("#gPurchTable #gPurchLineTemplateSection:last"); 
	reindexRows();
}

function reindexRows(){
	$(".index").each(function(index){
		$(this).html(index+1);
	});
	if ($("#gPurchTable #gPurchLineTemplateSection").length == 10) $("#addGPurch").hide();
	else $("#addGPurch").show();
	
	if ($("#gPurchTable #gPurchLineTemplateSection").length == 1) $("#deleteGPurch").hide();
	else $("#deleteGPurch").show();
}

function testGPurchItems(form) {
	lineItemGPurchErrors = "";
	form.$GPURCHLINES$.value = "";
	$("#gPurchTable #gPurchLineTemplateSection").each(function(index) 
	{
		var lineIndex = index + 1;
		var gpruchValue = $.trim($(this).find("input.gPurch").val());
		if (gpruchValue.length == 0) {
			lineItemGPurchErrors += "- GPRUCH # " + lineIndex + "\n";
		}
		if(gpruchValue.length > 0){
			form.$GPURCHLINES$.value += "\t" +lineIndex+"." + "\t" + gpruchValue + "\n";
			twcForm.$WEBSITEHIDDEN$.value = "OGI ID #: " + twcForm.$OGIID$.value + "\n"  + "ACCOUNT #: " + twcForm.$ACCOUNT$.value + "\n" + "GPURCH #:  " + "\n" + form.$GPURCHLINES$.value; 
		}
	});
}

function testPlanIdLineItems(form) {
	lineItemPlanIdErrors = "";
	form.$PLANIDLINES$.value = "";
	$("#tracPlanTable #tracPlanTemplateSection").each(function(index) 
	{
		var lineIndex = index + 1;
		var planIdValue = $.trim($(this).find("input.planid").val());
		
		if (planIdValue.length == 0) {
			lineItemPlanIdErrors += "- PLAN ID # " + lineIndex + "\n";
		}
		if(planIdValue.length > 0){
			form.$PLANIDLINES$.value += "\t" +lineIndex+"." + "\t" +  planIdValue + "\n" ;
			twcForm.$WEBSITEHIDDEN$.value = "PLAN ID #: " + "\n" + form.$PLANIDLINES$.value;
		}
	});
}

function testPswItems(form) {
	lineItemPswErrors = "";
	form.$PSWLINES$.value = "";
	$("#tracPSWTable #tracPSWTemplateSection").each(function(index) 
	{
		var lineIndex = index + 1;
		var pswValue = $.trim($(this).find("input.psw").val());
		
		if (pswValue.length == 0) {
			lineItemPswErrors += "- PSW # " + lineIndex + "\n";
		}
		if(pswValue.length > 0){
			form.$PSWLINES$.value += "\t" +lineIndex+"." + "\t" + pswValue + "\n" ;
			twcForm.$WEBSITEHIDDEN$.value = "PLAN ID #: " + "\n" + form.$PLANIDLINES$.value + "\n" + "SSN:  XXX-XX- " + twcForm.$SSN$.value + "\n" + "PSW #:" + "\n" + form.$PSWLINES$.value;
		}
	});
}


function addLineForPlan(){
	$("#tracPlanTemplate #tracPlanTemplateSection").clone(true).appendTo("#tracPlanTable #tracPlanTemplateSection:last"); 
	reindexRowsForPlan();
}

function reindexRowsForPlan(){
	$(".index1").each(function(index1){
		$(this).html(index1+1);
	});
	if ($("#tracPlanTable #tracPlanTemplateSection").length == 10) $("#addPlan").hide();
	else $("#addPlan").show();	
	
	if ($("#tracPlanTable #tracPlanTemplateSection").length == 1) $("#deletePlan").hide();
	else $("#deletePlan").show();
}

function addLineForPsw(){
	if ($("#tracPSWTable #tracPSWTemplateSection").length < 10)
	{
		$("#tracPSWTemplate #tracPSWTemplateSection").clone(true).appendTo("#tracPSWTable #tracPSWTemplateSection:last");
	}
	reindexRowsForPsw();	
}

function reindexRowsForPsw(){
	$(".index2").each(function(index2){
		$(this).html(index2+1);
	});
	if ($("#tracPSWTable #tracPSWTemplateSection").length == 10) $("#addPSW").hide();
	else $("#addPSW").show();
	
	if ($("#tracPSWTable #tracPSWTemplateSection").length == 1) $("#deletePsw").hide();
	else $("#deletePsw").show();
}

Form.CreateSubject = function () {
	document.getElementById("$ISSUEDATEVALUE$").value = twcForm.$ISSUEDATE$.value;
	twcForm.subject.value  = "TRAC/OGI WEB"  + " - " + twcForm.$SITE$.value + " - " + twcForm.$WEBSITE$.value ;
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if($.trim($("#\\#RPTM\\#").val()).length == 0 && $.trim($("#\\#RPTMONE\\#").val()).length == 0 && $.trim($("#\\#RPTMTWO\\#").val()).length == 0) {
		errorMsgArr[$("#\\#RPTM\\#").attr('tabindex')] = "- RP TM(s)\n";
 	}
	
	if(twcForm.$WEBSITE$.value == "OGI Website") {
		if($.trim(twcForm.$OGIID$.value).length == 0) {
			errorMsgArr[$("#\\$OGIID\\$").attr('tabindex')] = "- OGI ID #\n";
		} else {
			twcForm.$WEBSITEHIDDEN$.value = "OGI ID #: " + twcForm.$OGIID$.value;
		} 
		
		if($.trim(twcForm.$ACCOUNT$.value).length == 0) {
			errorMsgArr[$("#\\$ACCOUNT\\$").attr('tabindex')] = "- Account #\n";
		} else 	{
			twcForm.$WEBSITEHIDDEN$.value = "OGI ID #:  " + twcForm.$OGIID$.value + "\n"  + "ACCOUNT #:  " + twcForm.$ACCOUNT$.value + "\n";
		}
		testGPurchItems(twcForm);
		if($.trim(lineItemGPurchErrors).length != 0) {
			errorMsgArr[$("input.gPurch:first").attr('tabindex')] = lineItemGPurchErrors;
		}
	} else if(twcForm.$WEBSITE$.value == "TRAC Plan Sponsor Website") {
		testPlanIdLineItems(twcForm);
		if($.trim(lineItemPlanIdErrors).length != 0) {
			errorMsgArr[$("input.planid:first").attr('tabindex')] = lineItemPlanIdErrors;
		}
	
		if($.trim(twcForm.$SSN$.value).length == 0) {
			errorMsgArr[$("#\\$SSN\\$").attr('tabindex')] = "- SSN #\n";
		} else if($.trim(twcForm.$SSN$.value).length != 0)  {
			twcForm.$WEBSITEHIDDEN$.value = "PLAN ID #: " + "\n" + twcForm.$PLANIDLINES$.value + "\n" + "SSN:  XXX-XX- " + twcForm.$SSN$.value;
		}
		
		testPswItems(twcForm);
		if($.trim(lineItemPswErrors).length != 0) {
			errorMsgArr[$("input.psw:first").attr('tabindex')] = lineItemPswErrors;
		}
				
		if($.trim(twcForm.$PAYROLLPROCESS$.value).length !=0) {
			twcForm.$WEBSITEHIDDEN$.value = "PLAN ID #:  " + "\n" + twcForm.$PLANIDLINES$.value + "\n" + "SSN:  XXX-XX- " + twcForm.$SSN$.value + "\n" + "PSW #:" + "\n" + twcForm.$PSWLINES$.value + "\n" + "METHOD PAYROLL WAS PROCESSED: " + twcForm.$PAYROLLPROCESS$.value;
		}
	}
	
	if(twcForm.$OPERATINGSYSTEM$.value == "Other") {
		if($.trim(twcForm.$OTHEROPERSYSTEM$.value)=="") {
			errorMsgArr[$("#\\$OTHEROPERSYSTEM\\$").attr('tabindex')] = "- Other Operating System\n";
		} else {
			twcForm.$OTHEROPEROSHIDDEN$.value  = "OTHER OPERATING SYSTEM:" + twcForm.$OTHEROPERSYSTEM$.value;
		}
	}
		
	if(twcForm.$BROWSER$.value == "Other") {
		if($.trim(twcForm.$OTHERBROWSER$.value)=="") {
			errorMsgArr[$("#\\$OTHERBROWSER\\$").attr('tabindex')] = "- Other Browser\n";
		} else {
			twcForm.$OTHERBROWSERHIDE$.value = "OTHER BROWSER:" + twcForm.$OTHERBROWSER$.value;
		}
	}
	
	if($.trim(twcForm.$BROWSERVERSION$.value).length != 0) {
		twcForm.$BROWSERVERSION$.value = "BROWSER VERSION : " + twcForm.$BROWSERVERSION$.value;
	}
}

function ValidatePhone(m){
	p1 = null;
	p1 = m;
	ValidatePhone1(p1);
}

function ValidatePhone1(p1){
	var p;
	p = "";
	p = p1.value;
	
	if(p.length == 3){
		pp = p;
		d4 = p.indexOf('(');
		d5 = p.indexOf(')');
		if(d4 == -1){
			pp = "(" + pp;
		}
		if(d5 == -1){
			pp = pp + ")";
		}
	p1.value=""; p1.value=pp;
	}

	if(p.length > 3){
		d1 = p.indexOf('(');
		d2 = p.indexOf(')');
		if (d2 == -1){
			l30 = p.length;
			p30 = p.substring(0,4);
			p30 = p30+")";
			p31 = p.substring(4,l30);
			pp = p30+p31;
			p1.value=""; p1.value=pp;

		}
	}

	if(p.length > 5){
		p11 = p.substring(d1 + 1, d2);
		if(p11.length > 3){
			p12 = p11;
			l12 = p12.length;
			l15 = p.length;
			p13 = p11.substring(0, 3);
			p14 = p11.substring(3, l12);
			p15 = p.substring(d2 + 1, l15);
			pp = "(" + p13 + ")" + p14 + p15;
			p1.value=""; p1.value=pp;
		}
		l16 = p.length;
		p16 = p.substring(d2 + 1, l16);
		l17 = p16.length;
		if(l17 > 2 && p16.indexOf('-') == -1){
			p17 = p.substring(d2 + 1, d2 + 5);//4
			p18 = p.substring(d2 + 5, l16);//4
			p19 = p.substring(0, d2 + 1);

			pp = p19 + p17 + "-" + p18;
			p1.value=""; p1.value=pp;
		}

	}
}

// return the number of line breaks in given String
function lineBreakCount(str){

    try {
        return((str.match(/[^\n]*\n[^\n]*/gi).length));
    } catch(e) {
        return 0;
    }
}

// check the string if number of line breaks are more than 3
function checkThisString(txtArea, size){
    str = txtArea.value
    var lineBreaks =  lineBreakCount(str) ;

    if (lineBreaks > size-1){
        alert("Please limit to a maximum of " + size +" lines");
		txtArea.value = trim(str);
    }
}

function limitText(limitField, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	}
}