function toggleSameInt() {
	var sameint = document.getElementById("sameyes").checked;
	if (sameint) {
		document.getElementById("$intrate$").value = "No Change";
	} else {
		document.getElementById("$intrate$").value = "";
		document.getElementById("$intrate$").focus(); 
	}
}
			
function toggleNC() {
	var mdnc = document.getElementById("$nochg$").checked;
	if (mdnc) {
		document.getElementById("$matdate$").value = "No Change";
	} else {
		document.getElementById("$matdate$").value = "";
	}
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
					  
	if (form_loan_reamort.$rpaprocess$.checked) {
		form_loan_reamort.$rpa$.value = "Yes";
    }

	if (document.getElementById("chgyes").checked) {
		form_loan_reamort.$hidpcok$.value = "Yes";
	} else if (document.getElementById("chgno").checked) {
		form_loan_reamort.$hidpcok$.value = "No";
	}
						  
	//	VALIDATE FIELDS
	if (!form_loan_reamort.$rpaprocess$.checked) {
		errorMsgArr[$("#rpaprocess").attr('tabindex')] = "- Is RPA Process established?\n" ;
	}
	
	if (!document.getElementById("chgyes").checked && !document.getElementById("chgno").checked ) {
		errorMsgArr[$("#chgyes").attr('tabindex')] = "- Indicate if it is okay that the payment amount changes due to re-amortizing.\n" ;
	}
	
	if (document.getElementById("sameno").checked && form_loan_reamort.$intrate$.value == "" ) {
		errorMsgArr[$("#sameno").attr('tabindex')] = "- New Interest Rate.\n" ;
	} else if (!document.getElementById("sameyes").checked && !document.getElementById("sameno").checked ){
		errorMsgArr[$("#sameyes").attr('tabindex')] = "- Indicate if the Interest Rate will stay the same.\n" ;
	}
}

Form.CreateSubject = function () {
	form_loan_reamort.subject.value = "RKD Correction Request Form - Re-amortization Request - " + form_loan_reamort.$planid$.value;
}