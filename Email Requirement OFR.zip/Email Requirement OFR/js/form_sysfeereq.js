Form.FormSpecificReset = function () {
	ge("$hidachtpa$").value = "";
	ge("$hidachria$").value = "";
	ge("$hidpayfreq$").value = "";
	ge("$hidfeedur$").value = "N / A";
	ge("Qualifier").value = "";
	ge("subject").value = "";
	ge("abplbl").style.display = "none";
	ge("afalbl").style.display = "none";
	ge("duration").style.display = "none";
	ge("achtpadiv").style.display = "none";
	ge("achriadiv").style.display = "none";
	ge("$abips$").value = "";
	ge("$amount$").value = "";
	ge("ryes").checked = false;
	ge("rno").checked = false;
	ge("tyes").checked = false;
	ge("tno").checked = false;
	ge("$once$").checked = false;
	ge("$ong$").checked = false;
}

function toggleforb() {
	if (ge("afa").checked) {
		ge("$abips$").value = "";
		ge("afalbl").style.display = "block";
		ge("abplbl").style.display = "none";
	} else if (ge("abp").checked) {
		ge("$amount$").value = "";
		ge("abplbl").style.display = "block";
		ge("afalbl").style.display = "none";
	}
}

function toggleachtype() {
	if (ge("$feetype$").value == "RIA") {
		ge("$once$").checked = false;
		ge("$ong$").checked = false;
		ge("tyes").checked = false;
		ge("tno").checked = false;
		ge("achriadiv").style.display = "block";	
		ge("achtpadiv").style.display = "none";			
	} else if (ge("$feetype$").value == "TPA") {
		ge("$once$").checked = false;
		ge("$ong$").checked = false;
		ge("ryes").checked = false;
		ge("rno").checked = false;
		ge("achtpadiv").style.display = "block";
		ge("achriadiv").style.display = "none";			
	} else {
		ge("ryes").checked = false;
		ge("rno").checked = false;
		ge("tyes").checked = false;
		ge("tno").checked = false;
		ge("$once$").checked = false;
		ge("$ong$").checked = false;
		ge("achriadiv").style.display = "none";	
		ge("achtpadiv").style.display = "none";	
	}
}				  
  
function toggleachtpa() {
	if (ge("tyes").checked) {
		ge("$hidachtpa$").value = "Yes";
	} else if (ge("tno").checked) {
		ge("$hidachtpa$").value = "No";
	}
}

function toggleachria() {
	if (ge("ryes").checked) {
		ge("$hidachria$").value = "Yes";
	} else if (ge("rno").checked) {
		ge("$hidachria$").value = "No";
	}
}

function togglefreq() {
	if (ge("ann").checked) {
		ge("$hidpayfreq$").value = "Annually";
	} else if (ge("qtr").checked) {
		ge("$hidpayfreq$").value = "Quarterly";
	} else if (ge("mon").checked) {
		ge("$hidpayfreq$").value = "Monthly";
	}
}

function toggledur() {
	if (ge("$once$").checked) {
		ge("$hidfeedur$").value = "One-Time";
	} else if (ge("$ong$").checked) {
		ge("$hidfeedur$").value = "Ongoing";
	}
}	

function togglefptype() {
	var fptval = ge("$feetype$").value;
	if (fptval == "TPA" || fptval == "RIA") {
		ge("duration").style.display = "block";
	} else {
		ge("duration").style.display = "none";
		ge("$hidfeedur$").value = "One-Time";			
	}
}				  
	
	
Form.ValidateSpecificFormFields = function (errorMsgArr) {
	
	if ((form_sysfee.$feetype$.value == "TPA" || form_sysfee.$feetype$.value == "RIA") && (!ge("$once$").checked && !ge("$ong$").checked)) {
		errorMsgArr[$("#\\$once\\$").attr('tabindex')] = "- Duration\n";
	}	

	if (!ge("afa").checked && !ge("abp").checked ) {
		errorMsgArr[$("#afa").attr('tabindex')] = "- Annualized Fee Amount or Annualized Basis Points\n";
	}

	if (ge("afa").checked && $.trim(ge("$amount$").value) == ""){
		errorMsgArr[$("#\\$amount\\$").attr('tabindex')] = "- Annualized Fee Amount\n";
	}		

	if (ge("abp").checked && $.trim(ge("$abips$").value) == "") {
		errorMsgArr[$("#\\$abips\\$").attr('tabindex')] = "- Annualized Basis Points\n";
	}	
	
	if (!ge("ann").checked && !ge("qtr").checked && !ge("mon").checked) {
		errorMsgArr[$("#ann").attr('tabindex')] = "- Payment Frequency\n";
	}
	
	if (ge("$feetype$").value == "RIA" && !ge("ryes").checked && !ge("rno").checked) {
		errorMsgArr[$("#ryes").attr('tabindex')] = "- Is RIA ACH information established?\n";
	}

	if (ge("$feetype$").value == "TPA" && !ge("tyes").checked && !ge("tno").checked) {
		errorMsgArr[$("#tyes").attr('tabindex')] = "- Is TPA ACH information established?\n";
	}	
}


Form.CreateSubject = function () {
	if (ge("isflex").checked) {
		form_sysfee.Qualifier.value = "FLEX";
	}
	form_sysfee.subject.value = "Specialized.Work.Fin Plan Maint.SysFee. Sysfee Request:  " + form_sysfee.$planid$.value + " - " + form_sysfee.$planname$.value;
}

function ge(id) {
	return document.getElementById(id);
}