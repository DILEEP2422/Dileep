function initTest() {
	document.getElementById("$procdate$").style.color = "black";
	
	var curDate = new Date().getTime();
	var selDate = Date.parse(document.getElementById("$procdate$").value);
	var num_of_days = Math.floor((selDate - curDate ) / 86400000);
	
	if (num_of_days > 90) {

		var msg = "The Effective Date selected is greater than 90 days from today.  To accept, click OK (date will turn red)."+
			"  To re-enter, click Cancel."
		if (confirm(msg)) {
			//	DATE ACCEPTED: PROCEED & CHANGE COLOR TO RED DUE TO DISCREPANCY
			document.getElementById("$procdate$").style.color = "red";
		} else {
			//	CLEAR SELECTED DATE & REVERT COLOR TO BLACK
			document.getElementById("$procdate$").value = "";
			document.getElementById("$procdate$").style.color = "black";
			document.getElementById("$procdate$").focus();
		}// END ELSE
	}// END IF
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	if (form_imp_future.$srctype$.value == "Other" && $.trim(form_imp_future.$comments$.value) == "" ){
		errorMsgArr[$("#comments").attr('tabindex')] = "- Comments are required when the Type of Source is 'Other'.\n" ;
	}
}

Form.CreateSubject = function () {	
	//	VALIDATE FIELDS
	var theproc = form_imp_future.$procdate$.value;
	var theplanid = form_imp_future.$planid$.value;
	var theplname = form_imp_future.$planname$.value;
		
	var thesubj = theproc + " - Future Date Processing Request Form - " + theplanid + " - " + theplname + " (Internal Conversion)";
	form_imp_future.subject.value = thesubj;
}