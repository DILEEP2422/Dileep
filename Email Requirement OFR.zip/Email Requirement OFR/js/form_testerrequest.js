Form.FormSpecificReset = function () {
	lockSoni();
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	
	if($("#yes").prop('checked')) { // FOLLOW THESE STEPS IF SONI UPDATES NEEDED:
					
		//	VALIDATE SONI FIELDS HERE:					
		if ($.trim(testerform.$numart$.value) == "" ) {
			errorMsgArr[$("#numart").attr('tabindex')] = "- Number of SONI articles needing review\n";
		} 
		
		if ($.trim(testerform.$numppl$.value) == "") {
			errorMsgArr[$("#numppl").attr('tabindex')] = "- Number of Associates needed (SONI)\n";		
		}
		
		if ($.trim(testerform.$blocks$.value) == "" ){
			errorMsgArr[$("#blocks").attr('tabindex')] = "- Schedule time in blocks?\n";		
		}	
		
		if ($.trim(testerform.$sonihrs$.value) == "") {
			errorMsgArr[$("#sonihrss").attr('tabindex')] = "- Grand total hours needed?\n";		
		}
		
		if ($.trim(testerform.$specdates2$.value) == "") {
			errorMsgArr[$("#specdates2").attr('tabindex')] = "- Specific dates that review/updates need to be completed\n";	
		}
		
		if ($.trim(testerform.$usetest$.value) == "" ) {
			errorMsgArr[$("#usetest").attr('tabindex')] = "- Would you like to utilize tester resources identified above if available?\n";	
		}
	}
}
					  
Form.CreateSubject = function () {
		testerform.subject.value = "Testing Resource Request";	
} 

function lockSoni(){	// LOCKS SONI-RELATED FIELDS
	$("#numart").val("");
	$("#numppl").val("");
	$("#blocks").val("");
	$("#sonihrss").val("");
	$("#specdates2").val("");
	$("#usetest").val("");
	$("#soniskill").val("");
	$("#soniother").val("");
	
	$("#numart").attr('disabled','disabled');
	$("#numppl").attr('disabled','disabled');
	$("#blocks").attr('disabled','disabled');
	$("#sonihrss").attr('disabled','disabled');
	$("#specdates2").attr('disabled','disabled');
	$("#usetest").attr('disabled','disabled');
	$("#soniskill").attr('disabled','disabled');
	$("#soniother").attr('disabled','disabled');
}
						 

function unlockSoni() {	// UNLOCKS SONI-RELATED FIELDS
	$("#numart").removeAttr('disabled');
	$("#numppl").removeAttr('disabled');
	$("#blocks").removeAttr('disabled');
	$("#sonihrss").removeAttr('disabled');
	$("#specdates2").removeAttr('disabled');
	$("#usetest").removeAttr('disabled');
	$("#soniskill").removeAttr('disabled');
	$("#soniother").removeAttr('disabled');
}