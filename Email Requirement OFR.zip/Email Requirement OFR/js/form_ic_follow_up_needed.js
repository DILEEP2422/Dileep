function getblackoutenddate(){		
	if(document.getElementById("$blackoutdate$").value !=""){
		document.getElementById("$blackoutdatehidden$").value = "Blackout end date : "+document.getElementById("$blackoutdate$").value +"\n\n";
	}else{
		document.getElementById("$blackoutdatehidden$").value = "";
	}		
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {		
		if(validateIcfollowupCheckboxes() == false){
			errorMsgArr[$("#ic_1").attr('tabindex')] = "- Must select at least one option\n";
		}
	}

function validateIcfollowupCheckboxes() {
    var checkboxs=document.getElementsByName("ICCheck");	
    var okay=false;	
    for(var i=0,l=checkboxs.length;i<l;i++) {
        if(checkboxs[i].checked) {
            okay=true;
		}
    }	
	return okay;
}

function setAudience(chkid, hiddenid, literal) {
	// FUNCTION RECEIVES THE ID OF THE BOX CHECKED, THE ID OF THE HIDDEN FIELD TO HOLD THE LITERAL,
	// AND THE LITERAL TO DISPLAY ON THE OUTPUT EMAIL	

	if (document.getElementById(chkid).checked) {
		document.getElementById(hiddenid).value = literal + "\n\n"; // if checked, store in hidden field
	} else {
		document.getElementById(hiddenid).value = ""; // if not checked, make hidden field blank
	}
}

Form.CreateSubject = function () {
	form_ic_follow_up_needed.subject.value = "regular.work.follow up. IC Follow Up Needed " + form_ic_follow_up_needed.$planid$.value +" "+ form_ic_follow_up_needed.$planname$.value;
}
