$("#addAccount").click(function(){addNewAccount();});
$("#addAccount").keypress(function(){if (event.which == 32) addNewAccount();});
$("#addCheck").click(function(){ addLineItems(this);});
$("#addCheck").keypress(function(){ if (event.which == 32)addLineItems(this);});
DefaultOptions = $("#accountTypeDefaultTemplate").html();
AFSOptions = $("#accountTypeAFSTemplate").html();
CBTOptions = $("#accountTypeCBTTemplate").html();
_529Options = $("#accountType529Template").html();

$(".deleteFund").click(function() {
	var acct = $(this).closest("#accountWireInstructions");
	$(this).parent().parent().remove();
	reindexRows(acct);
});

$(".deleteAccount").click(function() {
	$(this).closest("div#account").hide(200, function(){
		$(this).remove();
		reindexAccounts();
	});
});

$(".accountNumber").blur(function() {
	var acNum = $(this).val();
	var acHeadNum = $(this).closest("div#account").find("span.accountHeaderNumber");

	if ($.trim(acNum).length == 0) $(acHeadNum).html("");
	else $(acHeadNum).html(acNum);
});

$("#ACTYPE").change(function() {
	var ACType = this.value;
	var bankAccountLines = $(this).closest("div#account").find("select.bankAccount");
	$(bankAccountLines).each(function() {
		$(this).find("option").remove();
		$(this).removeAttr("disabled");
		$(this).attr("disabled", "disabled");
	});
	
	if (ACType == "AFS") {
		$(bankAccountLines).each(function() {
			$(this).append(AFSOptions);
			$(this).val(""); 
			$(this).removeAttr("disabled");
		});
	}
	else if (ACType == "CB&T") {
		$(bankAccountLines).each(function() {
			$(this).append(CBTOptions);
			$(this).val(""); 
			$(this).removeAttr("disabled");
		});
	}
	else if (ACType == "529"){
		$(bankAccountLines).each(function() {
			$(this).append(_529Options);
			$(this).val(""); 
			$(this).removeAttr("disabled");
		});
	}
	else {
		$(bankAccountLines).each(function() {
			$(this).append(DefaultOptions);
		});
	}

});

Form.FormSpecificReset = function () {
	document.getElementById('$SITE$').focus(); 
	
	$("#bankWireInstructionAccounts #account").remove();
	$("#bankWireInstructionAccounts").append($("#accountTemplate #account").clone(true)); 

	$("#accountWireInvestmentTable:first").append($("#bankWireInvestmentLineTemplate #bankWireInvestmentLineSection").clone(true)); 
	$("#bankWireInstructionAccounts div[id=account]:last #accountWireInvestmentTable").find("input.dollarAmount").autoNumeric({aSign: '$'});
	
	$("#bankWireInstructionAccounts div[id=account]:last #accountWireInvestmentTable").find("input.datePaid").addClass('date-picker');
	Form.InitializeDatePickers();
	reindexAccounts();
	reindexRows($("#bankWireInstructionAccounts").find("div[id=account]:last"));
	getTodaysDate();
	calculateAvailability();
}

function calculateAvailability() {
	checkAvailYear = thisYear - 7;
	checkAvailMonthNum = thisMonth;
	checkAvailDate = new Date;
	
	if (thisMonth == 12) {
		checkAvailMonthNum = 1;
		checkAvailYear += 1;
	}
	
	switch (checkAvailMonthNum) {
		case 1: checkAvailFullMonth = "January "; break;
		case 2: checkAvailFullMonth = "February "; break;
		case 3: checkAvailFullMonth = "March "; break;
		case 4: checkAvailFullMonth = "April "; break;
		case 5: checkAvailFullMonth = "May "; break;
		case 6: checkAvailFullMonth = "June "; break;
		case 7: checkAvailFullMonth = "July "; break;
		case 8: checkAvailFullMonth = "August "; break;
		case 9: checkAvailFullMonth = "September "; break;
		case 10: checkAvailFullMonth = "October "; break;
		case 11: checkAvailFullMonth = "November "; break;
		case 12: checkAvailFullMonth = "December "; break;
		default: checkAvailFullMonth = "UNKNOWN - ERROR "; break;
	}

	$("#checkAvailMonthYear").html(checkAvailFullMonth + " " + thisDay + ", " + checkAvailYear);
		
	checkAvailDate.setDate(thisDay);
	checkAvailDate.setMonth(checkAvailMonthNum-1);	
	checkAvailDate.setFullYear(checkAvailYear);	
}

function getTodaysDate() {
	today = new Date();
	thisMonth = today.getMonth()+1;
	thisDay = today.getDate();
	thisYear = today.getFullYear();

	var todaysDate = thisMonth.toString() + "/" + thisDay.toString() + "/" + thisYear.toString();
	$("#todayDate").html(todaysDate);
}

function addNewAccount() {
	$("#accountTemplate #account").clone(true).appendTo($("#bankWireInstructionAccounts"));
	$("#bankWireInstructionAccounts div[id=account]:last").find("input.accountNumber").focus();
	$("#bankWireInstructionAccounts div[id=account]:last #accountWireInvestmentTable").append($("#bankWireInvestmentLineTemplate #bankWireInvestmentLineSection").clone(true));
	$("#bankWireInstructionAccounts div[id=account]:last #accountWireInvestmentTable").find("input.dollarAmount").autoNumeric({aSign: '$'});
	$("#bankWireInstructionAccounts div[id=account]:last #accountWireInvestmentTable").find("input.datePaid").addClass('date-picker');
	Form.InitializeDatePickers();
	reindexAccounts();
	reindexRows($("#bankWireInstructionAccounts").find("div[id=account]:last"));
}

function reindexAccounts() {
	$("#bankWireInstructionAccounts .accountIndex").each(function(index) {
		$(this).html(index+1 + ":&nbsp;");
	});
	
	if ($("#bankWireInstructionAccounts div[id=account]").length == 1) 
		$(".deleteAccount").css('visibility','hidden');
	else 
		$(".deleteAccount").css('visibility','visible');

	if ($("#bankWireInstructionAccounts div[id=account]").length == 10) 
		$("#addAccount").css('visibility','hidden');
	else
		$("#addAccount").css('visibility','visible');
}


function addLineItems(addFundButton) {
	var acct = $(addFundButton).closest("div#accountWireInstructions");
	var lastLine = $(acct).find("div#accountWireInvestmentTable #bankWireInvestmentLineSection:last");
	var ACType = $(addFundButton).closest("div#account").find("select.accountType").val();
	var bankAccountType = $(addFundButton).closest("div#account").find("div[id=bankWireInvestmentLineSection]:last .bankAccount").val();
	
	$("#bankWireInvestmentLineTemplate #bankWireInvestmentLineSection").clone(true).insertAfter(lastLine); 

	$(acct).find("div#accountWireInvestmentTable div[id=bankWireInvestmentLineSection]:last input.dollarAmount").autoNumeric({aSign: '$'})
	var newbankAccount = $(acct).find("div#accountWireInvestmentTable div[id=bankWireInvestmentLineSection]:last .bankAccount");
	$(acct).find("div#accountWireInvestmentTable div[id=bankWireInvestmentLineSection]:last .datePaid").addClass('date-picker');
	Form.InitializeDatePickers();
	var lastbankAccountOption = $(newbankAccount).find("option:last");
	
	reindexRows(acct);
	
	$(addFundButton).closest("div#accountWireInstructions").find("div#accountWireInvestmentTable div:last input.fundNumber").focus();
	
	if (ACType == "AFS") {
		$("#accountTypeAFSTemplate option").clone(true).insertAfter(lastbankAccountOption);
		$(newbankAccount).selectedIndex = 0;
		if (ACType.length > 0) $(newbankAccount).find("option:first").remove();
	}
	
	if (ACType == "CB&T") {
		$("#accountTypeCBTTemplate option").clone(true).insertAfter(lastbankAccountOption);
		$(newbankAccount).selectedIndex = 0;
		if (ACType.length > 0) $(newbankAccount).find("option:first").remove();
		
	}	
	if (ACType == "529") {
		$("#accountType529Template option").clone(true).insertAfter(lastbankAccountOption);
		$(newbankAccount).selectedIndex = 0;
		if (ACType.length > 0) $(newbankAccount).find("option:first").remove();
	}
}

function reindexRows(acct) {

	var fundIndexes = $(acct).find("#accountWireInvestmentTable span.fundIndex");
	var numLines = $(acct).find("#accountWireInvestmentTable div[id=bankWireInvestmentLineSection]").length;

	$(fundIndexes).each(function(index) {
		$(this).html(index+1);
	});
	
	if (numLines == 1) {
		$(acct).find(".deleteFund").css('visibility','hidden');
	} else {
		if(numLines == 20) {
			$(acct).find("#addCheck").css('visibility','hidden');
		} else {
			$(acct).find("#addCheck").css('visibility','visible');
		}
		$(acct).find(".deleteFund").css('visibility','visible');
	}
}

function returnUniqueAccountNumbers() {
	var accountNumbers = new Array();

	$("#bankWireInstructionAccounts input.accountNumber").each(function (){
		if (this.value != "") {accountNumbers.push((this).value);}
	});
	
	var uniqueAccountNumbers = new Array();
	var numberOfAccounts = accountNumbers.length;
	
	for (var i=0; i<numberOfAccounts; i++) {
		for(var j=i+1; j<numberOfAccounts; j++) {
			if (accountNumbers[i] === accountNumbers[j]) {
				j = ++i;
			}
		}
		uniqueAccountNumbers.push(accountNumbers[i]);
	}
	uniqueAccountNumbers = uniqueAccountNumbers.sort(sortNumber);
	return uniqueAccountNumbers.join(", ");
}

function sortNumber(a,b) {
	return a - b;
}

Form.CreateSubject = function () {

	if (wbiForm.$ACCTNOTE$.checked == true) {
		wbiForm.$ACCNOTE$.value = "Y";
	} else if (wbiForm.$ACCTNOTE$.checked == false) {
		wbiForm.$ACCNOTE$.value = "N";
	}
	
	wbiForm.subject.value = "Copy of Cashed Check Request - "+ wbiForm.$SITE$.value + " - "+ returnUniqueAccountNumbers();
}

Form.ValidateSpecificFormFields = function (errorMsgArr) {
	var form = document.getElementById("wbiForm");
	testLineItems(form, errorMsgArr);
}

function testLineItems(form, errorMsgArr) {
	
	form.$CASHEDCHECKS$.value = "";

	$("#bankWireInstructionAccounts #account").each(function(index) {
		
		var accountErrorLines = "";
		var acctIndex = index + 1;
		var acctNumber = $.trim($(this).find("input.accountNumber").val());
		var acctViewableShare = $(this).find("input.viewableInShare").is(":checked");
		
		var acctType = $(this).find("select.accountType").val();
		
		
		if (acctNumber.length == 0 || acctType.length == 0) {
			if (acctNumber.length == 0) accountErrorLines+= "ACCOUNT #\n";
			if (acctType.length == 0) accountErrorLines+= "A/C TYPE\n";
		}
		else {
			inShare = "N"; 
			if (acctViewableShare == true)
			    inShare = "Y";
			    
			
            form.$CASHEDCHECKS$.value += "\n ACCOUNT #: " + acctNumber + "    A/C TYPE: " + acctType
			
			+ "    ACCOUNT VIEWABLE IN SHARE: " + inShare;
			
			form.$CASHEDCHECKS$.value += "\n\n   FUND    BANK ACCOUNT    CHECK#    DOLLAR AMOUNT        DATE PAID  \n";
		}
		
		var acctFundLines = $(this).find("#accountWireInvestmentTable #bankWireInvestmentLineSection");
		var oneLineMinimum = false;
		
		$(acctFundLines).each(function(index){
			var fundIndex = index + 1;
			var fundNumber = $.trim($(this).find("input.fundNumber").val());
			var fundDollarAmt = $(this).find("input.dollarAmount").val();
			var bankAccount = $(this).find("select.bankAccount").val();
			var checkNumber = $.trim($(this).find("input.checkNumber").val());
			var datePaid = $.trim($(this).find("input.datePaid").val());
			

			if (fundNumber.length != 0 || fundDollarAmt.length != 0 || bankAccount.length !=0 || checkNumber.length !=0 || datePaid.length !=0) {
				
				if (fundNumber.length > 0 && fundDollarAmt.length > 0 &&  bankAccount.length>0 && checkNumber.length > 0 && datePaid.length > 0) {
					form.$CASHEDCHECKS$.value += "   "+padSpacesToRight(fundNumber, 5);
					form.$CASHEDCHECKS$.value += "    "+padSpacesToRight(bankAccount,12);
					form.$CASHEDCHECKS$.value += "    "+padSpacesToRight(checkNumber,6);
					form.$CASHEDCHECKS$.value += "    "+padSpacesToRight(fundDollarAmt, 16) +" ";
					form.$CASHEDCHECKS$.value += "    "+datePaid + "\n";
							
					oneLineMinimum = true;
				}
				else {
					accountErrorLines += "Line #" + fundIndex + " is incomplete\n";
				}
				
				
				if (datePaid.length > 0) {	
					if (validateDate(datePaid,'p') == false) {
						accountErrorLines += "Line #" + fundIndex +": DATE PAID is invalid\n";
			    	} else if (validateDate(datePaid,'p') < checkAvailDate) {
						accountErrorLines += "Line #" + fundIndex + ": DATE PAID - Check is no longer available to order\n";
					}
			   }
				
		  }				
		});
		
		if (oneLineMinimum == false) {
			accountErrorLines += "At least one line must be complete\n";
		}
		
		if (accountErrorLines.length > 0) {
			errorMsgArr[$(this).find("input.accountNumber").attr('tabindex')] = "\n- ACCOUNT # " + acctIndex + ":\n" + accountErrorLines;
		}
	});
}

function validateDate(fld,rng) {
	var dd, mm, yy;
	var today = new Date;
	var t = new Date;
	fld = stripBlanks(fld);

	if (fld == '') return false;

	var d1 = fld.split('\/');

	if (d1.length != 3) d1 = fld.split(' ');
	if (d1.length != 3) return false;
	dd = d1[1]; mm = d1[0]; yy = d1[2];
	
	var n = dd.lastIndexOf('st');
	
	if (n > -1) dd = dd.substr(0,n);
	n = dd.lastIndexOf('nd');

	if (n > -1) dd = dd.substr(0,n);
	n = dd.lastIndexOf('rd');
	
	if (n > -1) dd = dd.substr(0,n);
	n = dd.lastIndexOf('th');

	if (n > -1) dd = dd.substr(0,n);
	n = dd.lastIndexOf(',');
	
	if (n > -1) dd = dd.substr(0,n);
	n = mm.lastIndexOf(',');

	if (n > -1) mm = mm.substr(0,n);

	if (!isNumber(dd)) return false;
	if (!isNumber(yy)) return false;
	
	if (!isNumber(mm)) {
		var nn = mm.toLowerCase();
		for (var i=1; i < 13; i++) {
			if (nn == mth[i] || nn == mth[i].substr(0,3)) {
				mm = i;
				i = 13;
			}
		}
	}

	if (!isNumber(mm)) return false;
	dd = parseFloat(dd); mm = parseFloat(mm); yy = parseFloat(yy);
	
	
	if (yy < 100 && yy > 40) yy += 1900;
	if (yy < 40) yy += 2000;
	if (yy < 1941 || yy > 2025) return false;
	
	if (mm == 2 && (yy%400 == 0 || (yy%4 == 0 && yy%100 != 0))) day[1]=29;
	else day[1]=28;

	if (mm < 1 || mm > 12) return false;
	if (dd < 1 || dd > day[mm-1]) return false;

	t.setDate(dd); 
	t.setMonth(mm-1); 
	t.setFullYear(yy);

	if (rng == 'p' || rng == 'P') {
		if (t > today) return false;
	}

	else if (rng == 'f' || rng == 'F') {
		if (t < today) return false;
	}

	else if (rng != 'a' && rng != 'A') return false;
	
	return t;
}

function stripBlanks(fld) {
	var result = "";
	var c=0;
	
	for (i=0; i<fld.length; i++) {
		if (fld.charAt(i) != " " || c > 0) {
			result += fld.charAt(i);
			if (fld.charAt(i) != " ") c = result.length;
		}
	}
	
	return result.substr(0,c);
}

function isValid(parm,val) {
	if (parm == "") return false;
	for (i=0; i<parm.length; i++) {
		if (val.indexOf(parm.charAt(i),0) == -1) return false;
	}
	return true;
}

function isNumber(parm) {
	return isValid(parm,numb);
}

var numb = '0123456789';
var day = new Array(31,28,31,30,31,30,31,31,30,31,30,31);

function padSpacesToRight(inputstring, totalLength){
	var returnstr=inputstring;
	for (var i = inputstring.length; i<totalLength; i++) {
		returnstr += " ";
	}
	return returnstr;
}