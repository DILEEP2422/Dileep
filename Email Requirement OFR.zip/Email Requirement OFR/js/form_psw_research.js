Form.CreateSubject = function () {
	form_pswqc.subject.value = "Request for "+form_pswqc.$worktypes$.value+" - "+form_pswqc.$planid$.value;
}				  