Form.CreateSubject = function () {
	$("#Qualifier").val($("#\\$group\\$").val());
	$('#subject').val('TM System Enhancement Request Submission');
}

Form.FormSpecificReset = function () {
	$("#Qualifier").val("");
}