Form.CreateSubject = function () {
	form_imp_misc_maint.subject.value = "Regular.Work.New Plan Maint. Implementation Misc. Maint. - " + form_imp_misc_maint.$planid$.value + " - " + form_imp_misc_maint.$planname$.value;
}
 
//	GETS & RETURNS ELEMENT REFERENCE
function ge(id) {
	var myelement = document.getElementById(id);
	return myelement;
}

function togglerush() {
	if (ge("imaintrush").checked) {
		ge("$hidrush$").value = "Yes";
	} else {
		ge("$hidrush$").value = "No";
	}
}

function togglefid() {
	if (ge("fidsvc").checked) {
		ge("$hidfs$").value = "Yes";
	} else {
		ge("$hidfs$").value = "No";
	}
}

function togglefs()	{
	if (ge("m321").checked) {
		ge("$hidfstype$").value = "3(21) Menu";
	} else if (ge("l321").checked) {
		ge("$hidfstype$").value = "3(21) List";
	} else if (ge("m338").checked) {
		ge("$hidfstype$").value = "3(38) Menu";
	} else if (ge("mfm321").checked) {
		ge("$hidfstype$").value = "Multifund 3(21) Menu";
	} else if (ge("mfl321").checked) {
		ge("$hidfstype$").value = "Multifund 3(21) List";
	} else if (ge("mfm338").checked) {
		ge("$hidfstype$").value = "Multifund 3(38) Menu";
	}
}

function togglefpup() {
	if (ge("fpupdate").checked) {
		ge("$hidfpupdate$").value = "Yes";
	} else {
		ge("$hidfpupdate$").value = "No";
	}
}

function toggletpa() {
	if (ge("addtpa").checked){
		ge("$hidtpa$").value = "Yes";
	} else {
		ge("$hidtpa$").value = "No";
	}
}

function togglecbt() {
	if (ge("addcbt").checked) {
		ge("$hidcbt$").value = "Yes";
	} else {
		ge("$hidcbt$").value = "No";
	}
}

function toggleother() {
	if (ge("othertype").checked) {
		ge("$hidother$").value = "Yes";
	} else {
		ge("$hidother$").value = "No";
	}
}

Form.FormSpecificReset = function () {
	ge("$hidfs$").value = "No";
	ge("$hidfstype$").value = "";
	ge("$hidfpupdate$").value = "No";
	ge("$hidtpa$").value = "No";
	ge("$hidcbt$").value = "No";
	ge("$hidother$").value = "No";
	ge("$hidrush$").value = "No";
}