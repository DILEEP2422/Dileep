import { Product } from './product';
import { Seller } from './seller';

export class ProductOnDeals {
    dealId: number;
    product:Product;
    dealDiscount:number;
    startDateTime:Date;
    endDateTime:Date;
    seller:Seller;

    setProduct(product:Product){
        this.product=product
    }
    setStartDate(startdate:Date){
        this.startDateTime=startdate
    }
    setEndDate(enddate:Date){
        this.startDateTime=enddate
    }
}