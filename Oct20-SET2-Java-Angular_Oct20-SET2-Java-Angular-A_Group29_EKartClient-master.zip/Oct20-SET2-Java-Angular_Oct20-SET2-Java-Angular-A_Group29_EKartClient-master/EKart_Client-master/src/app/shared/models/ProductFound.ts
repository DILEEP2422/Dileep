export class ProductFound{
    productId: number;
    dealId:number;
    name: string;
    description: string;
    category: string;
    brand: string;
    price: number;
    discount: number;
    dealDiscount:number;
    quantity: number;
    status:String;
    sellerEmail?:String;
    dealStartDate ?:Date
    dealEndDate ?: Date
}