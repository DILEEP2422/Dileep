export class DealProduct {
    productId ?: number = 0;
    dealId ?: number = 0;
    startDateAndTime ?: string = "";
    endDateAndTime ?: string = "";
    dealDiscount ?: number = 0;
    sellerEmailId ?: string = "";
}