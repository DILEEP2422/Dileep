import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/app/shared/models/product';
import { CustomerSharedService } from '../../customer-shared-service';
import { CustomerCartService } from '../../customer-cart/customer-cart.service';
import { Cart } from 'src/app/shared/models/cart';
import { Customer } from 'src/app/shared/models/customer';

@Component({
  selector: 'view-selected-product',
  templateUrl: './view-selected-product.component.html'
  
})
export class ViewSelectedProductComponent implements OnInit {
  @Input()
  dealDiscount: number;
  @Input()
  dealId:number;
  @Input()
  name:string;
  @Input()
  brand:string;
  @Input()
  productId:number;
  @Input()
  category:string;
  @Input()
   price:number;
   @Input()
   quantity:number
   @Input()
   description:string
   @Input()
   sellerEmail:string
   successMessage:string;
   errorMessage:string;
   flag:boolean=false;
   selectedProduct:Product;
  constructor(private customerCommonService: CustomerSharedService, private customerCartService: CustomerCartService) { 
    
  }
  
  
  beforePrice : number;
  afterPrice : number;
  
  ngOnInit() {
    // this.beforePrice = this.price - (this.price*this.dealDiscount/100)
    this.afterPrice = this.price - (this.price*this.dealDiscount/100)
    this.flag  = true;
  }
  goBack(){
    this.flag=false;
  }
  
  

}
  

  
