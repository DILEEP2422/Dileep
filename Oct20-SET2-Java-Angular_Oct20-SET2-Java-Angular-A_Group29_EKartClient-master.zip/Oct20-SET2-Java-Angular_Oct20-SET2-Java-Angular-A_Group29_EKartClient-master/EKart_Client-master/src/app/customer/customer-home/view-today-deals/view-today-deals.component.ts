import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Product } from 'src/app/shared/models/product';
import { ProductOnDeals } from 'src/app/shared/models/productOnDeals';
import { CustomerViewDealsService } from './customer-view-deals.service';
import { DealProduct } from 'src/app/shared/models/DealProduct';
import { ProductFound } from 'src/app/shared/models/ProductFound';
import { NodeWithI18n } from '@angular/compiler';
import { Customer } from 'src/app/shared/models/customer';




@Component({
  selector: 'app-view-today-deals',
  templateUrl: './view-today-deals.component.html'
})


export class ViewTodayDealsComponent implements OnInit {
  loggedInCustomer: Customer;
  page:boolean=true
  isProductSelected: boolean = false;
  selectedProduct: Product;
  productOnDeals: ProductOnDeals[]=[];
  DealProduct: DealProduct[]=[];
  count : number = 0;
  errorMessage: string;
  successMessage: string;
  now = new Date();
  status: number[];
  dealDiscount: number=0;
  dealId:number=0;
  name:string="";
  brand:string="";
  productId:number=0;
  category:string="";
  price:number=0;
  description:string=""
  sellerEmail:string=""
  product:Product[]=[];
  quantity:number=0
  id:number;
  productNeed:ProductFound
  x:number=0;
  pageno:any
  productFound:ProductFound[]=[];
  constructor(private customerViewDealsService: CustomerViewDealsService) {}

   
  

  ngOnInit() {
    this.successMessage = null;
    this.errorMessage = null;
    this.productOnDeals = null;
    
    this.getProductOnDealsForCustomer();
    
  }

  getProductOnDealsForCustomer() {
    this.status = [],
    

      this.customerViewDealsService.getProductOnDealsForCustomer().subscribe
        (
          (response) => {
            this.DealProduct = response;
           
            
          },
          (error) => {
                 this.errorMessage=error.error.message
          } 
        
        )
      this.customerViewDealsService.getAllProducts().subscribe(

        (response) => {
          this.product = response;
          console.log(this.product)
          this.setProduct()
        },
        (error) => {
               this.errorMessage=error.error.message
        } 
      )
      this.setProduct()
      }
        setProduct(){
          var c=0
          for(let i =0 ;i<this.DealProduct.length ;i++){
            this.id=this.DealProduct[i].productId
        
            for(let j =0 ;j<this.product.length;j++){
                   if(this.id == this.product[j].productId){
                   let  productNeed =new ProductFound()
                   productNeed.productId=this.id;
                   productNeed.discount=this.product[j].discount
                   productNeed.dealDiscount=this.DealProduct[i].dealDiscount
                   productNeed.dealId=this.DealProduct[i].dealId
                   productNeed.name=this.product[j].name
                   productNeed.price=this.product[j].price
                   productNeed.description=this.product[j].description
                   productNeed.brand=this.product[j].brand
                   productNeed.category=this.product[j].category
                   productNeed.quantity=this.product[j].quantity
                   productNeed.sellerEmail=this.DealProduct[i].sellerEmailId
                   let objStartDate :any = new Date(this.DealProduct[i].startDateAndTime);
                   let objEndDate : any = new Date(this.DealProduct[i].endDateAndTime);
                   productNeed.dealStartDate=objStartDate
                   productNeed.dealEndDate=objEndDate
                   
                   if( (objStartDate.getDate() == this.now.getDate())){
                      productNeed.status="Deal On"
                    }
                   else if(objStartDate.getDate() > this.now.getDate()){
                                    productNeed.status="Deal is yet to come"
                                  }
                    else{
                        productNeed.status="Deal Over"
                         }
                      this.productFound.push(productNeed)
                      this.count=this.productFound.length
                   }
            }
          }
          console.log(this.productFound)
        }
        
  

  



  setSelectedProduct(productId: number,dealId:number,name:string,category:string,brand:string,price:number,description:string,quantity:number,sellerEmail:string, dealDiscount: number) {
    this.dealDiscount = dealDiscount;
    this.isProductSelected = true;
    this.successMessage = null;
    this.sellerEmail=sellerEmail
    this.productId = productId;
    this.brand=brand;
    this.dealId=dealId;
    this.name=name;
    this.category=category;
    this.price=price;
    this.description=description
    this.quantity=quantity
    
    
  }



  unsetSelectedProduct() {
    this.dealDiscount = null;
    this.isProductSelected = false;
    this.selectedProduct = null;
  }
  // onChange(event){
  //   this.pageno=event;
  //   this.getProductOnDealsForCustomer();
  // }
 
        }