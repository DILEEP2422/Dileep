import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { ProductOnDeals } from 'src/app/shared/models/productOnDeals';
import { environment } from 'src/environments/environment';
import { catchError } from 'rxjs/operators';
import { DealProduct } from 'src/app/shared/models/DealProduct';
import { Product } from 'src/app/shared/models/product';


@Injectable({
  providedIn: 'root'
})
export class CustomerViewDealsService {

  constructor(private http:HttpClient) {

     }

     getProductOnDealsForCustomer():Observable<DealProduct[]>{

      const url=environment.customerProductAPI+"/getTodaysDeals/";

       return this.http.get<DealProduct[]>(url)
       .pipe(catchError(this.handleError));
     }
     getAllProducts(): Observable<Product[]> {

      let url = environment.customerProductAPI + "/products";
      return this.http.get<Product[]>(url)
        .pipe(catchError(this.handleError));
  
    }
     private handleError(err: HttpErrorResponse) {
      console.log(err)
      let errMsg:string='';
      if (err.error instanceof Error) {   
          errMsg=err.error.message;
          console.log(errMsg)
      }
       else if(typeof err.error === 'string'){
          errMsg=JSON.parse(err.error).message
      }
      else {
         if(err.status==0){ 
             errMsg="No Deals Available";
         }else{
             errMsg=err.error.message;
         }
       }
          return throwError(errMsg);
  }

}