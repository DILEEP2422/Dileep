import { TestBed } from '@angular/core/testing';

import { CustomerViewDealsService } from './customer-view-deals.service';

describe('CutomerViewDealsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CustomerViewDealsService = TestBed.get(CustomerViewDealsService);
    expect(service).toBeTruthy();
  });

});