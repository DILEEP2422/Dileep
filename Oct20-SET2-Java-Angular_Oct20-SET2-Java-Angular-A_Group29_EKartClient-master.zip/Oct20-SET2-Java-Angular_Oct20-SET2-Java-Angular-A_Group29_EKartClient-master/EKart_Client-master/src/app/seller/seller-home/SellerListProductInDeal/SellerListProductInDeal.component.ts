import { Component, Output, EventEmitter, OnInit, OnDestroy } from "@angular/core";
import { Seller } from "../../../shared/models/seller";
import { Router, ActivatedRoute } from "@angular/router";
import { SellerSharedService } from "../seller-shared.service";
import { SellerProductsService } from '../products/seller-products/seller-products.service';
import { Product } from 'src/app/shared/models/product';
import { DealProduct } from 'src/app/shared/models/DealProduct';



@Component(
    {
        selector: 'seller-list-dealProducts',
        templateUrl: './SellerListProductInDeal.component.html',
        
        styleUrls: [],
        
    }
)


export class SellerListProductInDealComponent implements OnInit
{
    seller: Seller;
    productList : Product[];
    displayProducts : Boolean = true;

    productToBeAddedToDeal : DealProduct;

    bShowProductDetails : Boolean = false;
    ProductInfoDisplay : Product;
    productCategoryList : string[];
    
    constructor(private SellerProductsService: SellerProductsService) 
    {

    }
    ngOnInit() 
    {

        debugger;
        this.seller = JSON.parse(sessionStorage.getItem("seller"));

        this.SellerProductsService.getProductCategories()
        .subscribe(productCategoryList => {
            this.productCategoryList = productCategoryList
        })

        this.SellerProductsService.getDealsAvailableForSeller(this.seller).subscribe((objResponse) => {
          //Assign The Total Product List To Variable
          debugger;
          let objCurrentProductlist = JSON.parse(sessionStorage.getItem("sellerProducts"));

          let objInDealProducts = [];

          let objDealProducts = [];
          let objDealProductDetails = {};

          //Loop Over Response And Filter Deal Products
          for(let objProduct in objResponse)
          {
            if(objResponse[objProduct]["dealProductId"])
            {
              objDealProducts.push(objResponse[objProduct]["dealProductId"]);
              objDealProductDetails[objResponse[objProduct]["dealProductId"]] = objResponse[objProduct];
            }
          }

          for(let objProduct in objCurrentProductlist)
          {
            if(objDealProducts.indexOf(objCurrentProductlist[objProduct]["productId"]) >= 0)
            {
                let objProductCode = objCurrentProductlist[objProduct]["productId"];
                objCurrentProductlist[objProduct]["dealStartDate"] = objDealProductDetails[objProductCode]["startDateAndTime"];
                objCurrentProductlist[objProduct]["dealEndDate"] = objDealProductDetails[objProductCode]["endDateAndTime"];

                objInDealProducts.push(objCurrentProductlist[objProduct]);
            }
          }

            this.productList = objInDealProducts;
        });



    }
   
    //To Display Product Details Section
    DisplayProductDetails(objSelectedProduct : Product)
    {
        this.bShowProductDetails = true;

        this.ProductInfoDisplay = objSelectedProduct;
    }


    ClickCancelDisplayProducts()
    {
        this.bShowProductDetails = false;
    }
}
