import { Component, Output, EventEmitter, OnInit, OnDestroy } from "@angular/core";
import { Seller } from "../../../shared/models/seller";
import { Product } from 'src/app/shared/models/product';
import { SellerProductsService } from '../products/seller-products/seller-products.service';
import { DealProduct } from 'src/app/shared/models/DealProduct';

@Component(
    {
        selector: 'seller-list-NotIndealProducts',
        templateUrl: './SellerListProductNotInDeal.component.html',
        styleUrls: []
    }
)


export class SellerListProductNotInDealComponent implements OnInit
{
    seller: Seller;
    productList : Product[];
    displayProducts : Boolean = true;
    addToDealsSection : Boolean =false;
    isStartEndDateTimeValid : Boolean = true;
    productToBeAddedToDeal : DealProduct;
    
    constructor(private SellerProductsService: SellerProductsService) 
    {

    }


    ngOnInit() 
    {

        debugger;
        this.seller = JSON.parse(sessionStorage.getItem("seller"));

        this.SellerProductsService.getDealsAvailableForSeller(this.seller).subscribe((objResponse) => {
          //Assign The Total Product List To Variable
          let objCurrentProductlist = JSON.parse(sessionStorage.getItem("sellerProducts"));

          let objNonDealProducts = [];

          let objDealProducts = [];

          //Loop Over Response And Filter Deal Products
          for(let objProduct in objResponse)
          {
            if(objResponse[objProduct]["dealProductId"])
            {
              objDealProducts.push(objResponse[objProduct]["dealProductId"]);
            }
          }
//note
          for(let objProduct in objCurrentProductlist)
          {
            if(objDealProducts.indexOf(objCurrentProductlist[objProduct]["productId"]) < 0)
            {
              objNonDealProducts.push(objCurrentProductlist[objProduct]);
            }
          }

            this.productList = objNonDealProducts;
        });



    }


    //On Click For Each Product Add To Deal Button
  AddToDeals(objProductSelected : Product)
  {
    //Set Display Product To False To Remove Above Section
    this.displayProducts = false;

    //Mark The Add To Deal Section To Visible True
    this.addToDealsSection = true;

    //To Reset The Validation Status To True
    this.isStartEndDateTimeValid = true;

    this.productToBeAddedToDeal = new DealProduct;
    debugger;
    this.productToBeAddedToDeal.productId = objProductSelected.productId;
    this.productToBeAddedToDeal.sellerEmailId = this.seller.emailId;
  }


 /** Called On Change For Stand And End Date/Time And Validate If The Start Date And End Date Are Same
 And Date Is With In 1 Month Of Present Date And Start Time Is Less Than End Time*/
ValidateStartEndDateAndTime()
{
  debugger;
  console.log("The Start Date And Time Is"+this.productToBeAddedToDeal.startDateAndTime);
  console.log("The End Date And Time Is"+this.productToBeAddedToDeal.endDateAndTime);

  if(this.productToBeAddedToDeal.startDateAndTime && 
    this.productToBeAddedToDeal.startDateAndTime.length > 0 &&
    this.productToBeAddedToDeal.endDateAndTime && 
    this.productToBeAddedToDeal.endDateAndTime.length > 0)
  {
    this.isStartEndDateTimeValid = false;

    if(this.productToBeAddedToDeal.startDateAndTime.split("T").length == 2 && 
      this.productToBeAddedToDeal.endDateAndTime.split("T").length == 2)
    {
      let objStartDate : any = new Date(this.productToBeAddedToDeal.startDateAndTime);
      let objEndDate : any = new Date(this.productToBeAddedToDeal.endDateAndTime);
  
      let objStartDateInString = this.productToBeAddedToDeal.startDateAndTime.split("T");
      let objEndDateInString = this.productToBeAddedToDeal.endDateAndTime.split("T");
      
      //Get Current Date
      let objCurrentDate = new Date();
      let objDateOneMonthFromToday = new Date(objCurrentDate.getFullYear(),objCurrentDate.getMonth()+1,objCurrentDate.getDate());
    



      if(objStartDate > objCurrentDate && objStartDate < objDateOneMonthFromToday && 
        objStartDateInString[0] == objEndDateInString[0] && objEndDate-objStartDate > 0)
      {
        this.isStartEndDateTimeValid = true;
      }
    }
   
  }
}

//To Close The Add Product To Deal Section
CloseAddToDealSection() 
{
  //Hide Add To Deal Section
  this.addToDealsSection = false;

  //Show Product List Section
  this.displayProducts = true;
}


AddProductToDeals()
{
  debugger;
  this.SellerProductsService.addProductToDealService(this.productToBeAddedToDeal).subscribe((objResponse) => {

    console.log("Response For Add Product To Deal :-"+ JSON.stringify(objResponse));


    //If Response Contains Deal Id To Treat Same As Success
    if(objResponse && objResponse["dealId"])
    {
      let objDealSuccessAddedComponent = document.getElementById("Success_Deal_Added");
      objDealSuccessAddedComponent.setAttribute("style","display:block");
    }


  }, (objError) => {
    console.log("Service Failed For Adding Product Deal To Response");
  });
}



}
