import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../../../../shared/models/product';
import { SellerProductsService } from './seller-products.service';
import { Seller } from '../../../../shared/models/seller';
import { DealProduct } from 'src/app/shared/models/DealProduct';
import { Validators, FormGroup, FormBuilder, FormControl } from '@angular/forms';


@Component({
  selector: 'app-seller-products',
  templateUrl: './seller-products.component.html'
})

export class SellerProductsComponent implements OnInit {

  errorMessage: string = "";
  successMessage: string = "";
  seller: Seller
  product
  productCategoryList: string[]
  @Input()
  productRecieved: Product
  productList: Product[]
  productToBeModified: Product
  displayProducts: Boolean
  addToDealsSection:Boolean = false;
  productToBeAddedToDeal : DealProduct;
  isStartEndDateTimeValid : Boolean =true;



  constructor(private SellerProductsService: SellerProductsService , private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.SellerProductsService.getProductCategories()
      .subscribe(productCategoryList => {
        this.productCategoryList = productCategoryList
      })
    // .catch(product =>{
    //   this.errorMessage = product.errorMessage;
    // })
    this.productList = JSON.parse(sessionStorage.getItem("sellerProducts"));
    this.displayProducts = true
    this.seller = JSON.parse(sessionStorage.getItem("seller"));

  }

  viewProductDetails(product: Product) {
    this.productToBeModified = new Product
    this.productToBeModified.productId = product.productId
    this.productToBeModified.name = product.name
    this.productToBeModified.description = product.description
    this.productToBeModified.discount = product.discount
    this.productToBeModified.category = product.category
    this.productToBeModified.brand = product.brand
    this.productToBeModified.price = product.price
    this.productToBeModified.quantity = product.quantity
    this.displayProducts = false
  }

  modifyProductDetails() {
    this.SellerProductsService.updateProductDetails(this.productToBeModified).subscribe(
      (response) => {
        this.successMessage = response.successMessage;

        console.log("response____"+response)
        console.log("response____"+this.successMessage)


        this.errorMessage = ""
        for (let product1 of this.productList) {
          if (product1.productId == this.productToBeModified.productId) {
            product1.name = this.productToBeModified.name
            product1.description = this.productToBeModified.description
            product1.discount = this.productToBeModified.discount
            product1.category = this.productToBeModified.category
            product1.brand = this.productToBeModified.brand
            product1.price = this.productToBeModified.price
            product1.quantity = this.productToBeModified.quantity
            // Object.assign(product1, this.productToBeModified);
          }
        }
        this.displayProducts = true
        sessionStorage.setItem("sellerProducts", JSON.stringify(this.productList));
      }, error => {
        this.errorMessage = <any>error
        console.log(error)
        this.successMessage = "";
        this.displayProducts = true;
      }
    )
  }

  removeProduct(product: Product) {
    product.sellerEmailId = this.seller.emailId;
    this.SellerProductsService.removeProductFromSeller(product).subscribe(
      (response) => {
        console.log(JSON.stringify(response));
        this.successMessage = response.successMessage;
        this.errorMessage = ""
        let newProductList: Product[] = []
        for (let product1 of this.productList) {
          if (product1.productId != product.productId) {
            newProductList.push(product1)
          }
        }
        this.productList = newProductList
        sessionStorage.setItem("sellerProducts", JSON.stringify(this.productList));
      }, error => {
        this.errorMessage = <any>error
        this.successMessage = "";
      }
    )

  }


  //On Click For Each Product Add To Deal Button
  AddToDeals(objProductSelected : Product)
  {
    //Set Display Product To False To Remove Above Section
    this.displayProducts = false;

    //Mark The Add To Deal Section To Visible True
    this.addToDealsSection = true;

    //To Reset The Validation Status To True
    this.isStartEndDateTimeValid = true;

    this.productToBeAddedToDeal = new DealProduct;

    this.productToBeAddedToDeal.productId=objProductSelected.productId;
    
  }
  
 /** Called On Change For Stand And End Date/Time And Validate If The Start Date And End Date Are Same
 And Date Is With In 1 Month Of Present Date And Start Time Is Less Than End Time*/
ValidateStartEndDateAndTime()
{
  debugger;
  console.log("The Start Date And Time Is"+this.productToBeAddedToDeal.startDateAndTime);
  console.log("The End Date And Time Is"+this.productToBeAddedToDeal.endDateAndTime);

  if(this.productToBeAddedToDeal.startDateAndTime && 
    this.productToBeAddedToDeal.startDateAndTime.length > 0 &&
    this.productToBeAddedToDeal.endDateAndTime && 
    this.productToBeAddedToDeal.endDateAndTime.length > 0)
  {
    this.isStartEndDateTimeValid = false;

    if(this.productToBeAddedToDeal.startDateAndTime.split("T").length == 2 && 
      this.productToBeAddedToDeal.endDateAndTime.split("T").length == 2)
    {
      let objStartDate : any = new Date(this.productToBeAddedToDeal.startDateAndTime);
      let objEndDate : any = new Date(this.productToBeAddedToDeal.endDateAndTime);
  
      let objStartDateInString = this.productToBeAddedToDeal.startDateAndTime.split("T");
      let objEndDateInString = this.productToBeAddedToDeal.endDateAndTime.split("T");
      
      //Get Current Date
      let objCurrentDate = new Date();
      let objDateOneMonthFromToday = new Date(objCurrentDate.getFullYear(),objCurrentDate.getMonth()+1,objCurrentDate.getDate());
    



      if(objStartDate > objCurrentDate && objStartDate < objDateOneMonthFromToday && 
        objStartDateInString[0] == objEndDateInString[0] && objEndDate-objStartDate > 0)
      {
        this.isStartEndDateTimeValid = true;
      }
    }
   
  }
}

//To Close The Add Product To Deal Section
CloseAddToDealSection() 
{
  //Hide Add To Deal Section
  this.addToDealsSection = false;

  //Show Product List Section
  this.displayProducts = true;
}


AddProductToDeals()
{
  debugger;
  this.SellerProductsService.addProductToDealService(this.productToBeAddedToDeal).subscribe((objResponse) => {

    console.log("Response For Add Product To Deal :-"+ JSON.stringify(objResponse));


    //If Response Contains Deal Id To Treat Same As Success
    if(objResponse && objResponse["dealId"])
    {
      let objDealSuccessAddedComponent = document.getElementById("Success_Deal_Added");
      objDealSuccessAddedComponent.setAttribute("style","display:block");
    }


  }, (objError) => {
    console.log("Service Failed For Adding Product Deal To Response");
  });
}





/*
dealValidation(any){
this.addToDealsForm=this.formBuilder.group(
  {
    startDateAndTime:["",[Validators.required]],
    endDateAndTime:["",[Validators.required]],

  } ,{validator: this.dateEquel('startDateAndTime', 'endDatAndTime')}
)
}
dateEquel(from: string, to: string) {
  return (group: FormGroup): {[key: string]: any} => {
    let f = group.controls[from];
    let t = group.controls[to];
    if (f.value != t.value) {
      return {
        dates: "Date should be same"
      };
    }
    return {};
  }
}*/


}
