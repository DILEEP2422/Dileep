$(document).ready(function()
	{
var userDataJson = localStorage.getItem("userData");
 if (userDataJson == undefined || userDataJson == null || userDataJson == '') {
	$.getJSON("/bin/ofr/userdata.json").then(function(response) {
	if (!response['initials'] || response['initials'] == '(null)') {
		localStorage.setItem('userInitials',response.userInitials);
	}
	localStorage.setItem('userData',JSON.stringify(response));
	localStorage.setItem('userInitials',response.userInitials);

	}).fail(function(err) {
	console.log("userdata call failed");
	});
	 }
     });