$(function() {

    $('div.cmp-accordion--expandCollapseAll > .cmp-accordion > .topSectionsWrapper > button.sections-toggler').on( "click touchstart", function(e)  {
        if ($(this).text() === "EXPAND ALL") {
            $(this).parent().closest("div.cmp-accordion--expandCollapseAll > .cmp-accordion").find("> div.cmp-accordion__item").each(function() {
                let button = $(this).find("> .cmp-accordion__header > button.cmp-accordion__button");
                let panel = $(this).find("> div.cmp-accordion__panel");
                $(this).attr("data-cmp-expanded","");
                button.addClass("cmp-accordion__button--expanded");
                button.attr("aria-expanded", true);
                panel.addClass("cmp-accordion__panel--expanded");
                panel.removeClass("cmp-accordion__panel--hidden");
                panel.attr("aria-hidden", false);

            });
            $(this).text('COLLAPSE ALL');
        } else if ($(this).text() === "COLLAPSE ALL") {
            $(this).parent().closest("div.cmp-accordion--expandCollapseAll > .cmp-accordion").find("> div.cmp-accordion__item").each(function() {
                let button = $(this).find("> .cmp-accordion__header > button.cmp-accordion__button");
                let panel = $(this).find("> div.cmp-accordion__panel");
                $(this).removeAttr("data-cmp-expanded");
                button.removeClass("cmp-accordion__button--disabled");
                button.removeClass("cmp-accordion__button--expanded");
                button.removeAttr("aria-disabled");
                button.attr("aria-expanded", false);
                panel.addClass("cmp-accordion__panel--hidden");
                panel.removeClass("cmp-accordion__panel--expanded");
                panel.attr("aria-hidden", true);
            });
            $(this).text('EXPAND ALL');
        }
        return false; 
    });

    $(".cmp-accordion--expandCollapseAll.accordion .cmp-accordion__item").on( "click", function(e)  {
            let allActive = false;
            $(this).parent().closest("div.cmp-accordion--expandCollapseAll > .cmp-accordion").find("> div.cmp-accordion__item").each(function() {                
                if ( typeof $(this).attr("data-cmp-expanded") !== undefined && $(this).attr("data-cmp-expanded") === "") {
                    allActive = true;
                }
            });

            if (allActive) { 
                $(this).parent().closest(".cmp-accordion--expandCollapseAll.accordion").find(">.cmp-accordion > .topSectionsWrapper > button.sections-toggler").text("COLLAPSE ALL");
            } else {
                $(this).parent().closest(".cmp-accordion--expandCollapseAll.accordion").find(">.cmp-accordion > .topSectionsWrapper  > button.sections-toggler").text("EXPAND ALL");
            }
            return true; 
   });
    
});