$(document).ready(function () 
{

$("#account-div-sp").css("display","none");
$("#reqtype").css("display","none");
$("#account-div").css("display","none");


    $('select[id=ACCOUNTTYPE]').change(function () 
	{
		$("select[id=ACCOUNTTYPE] option:selected").each(function ()

        {
             $("#account-div").css("display","none");
             $("#reqtype").css("display","none");
           	 $("#account-div-sp").css("display","none");
             $("#REQUESTTYPE").prop("selectedIndex",0)

             if ($(this).val() === "CB&T"  ) 
			{
                $("#account-div").css("display","none");
                $("#reqtype").css("display","none");
                $("#REQUESTTYPE").prop("selectedIndex",0)

                 $('select[id=REQUESTTYPE]').change(function () 
                {


                    $("select[id=REQUESTTYPE] option:selected").each(function ()

                    {

                        if ($(this).val() != "TRAC"  ) 
                        {
                        $("#account-div-sp").css("display","block");
                    	$("#account-div").css("display","none");

                        }
                        else
                        {
                           $("#account-div-sp").css("display","none");

                        }
                    });
                });
            }
            else
            {
				  $('select[id=REQUESTTYPE]').change(function () 
                    {                                
                        $("select[id=REQUESTTYPE] option:selected").each(function ()

                        {

                            if ($(this).val() != "TRAC"  ) 
                            {
                            $("#account-div").css("display","block");
                            $("#account-div-sp").css("display","none");

                            }
                            else
                            {
                               $("#account-div").css("display","none");
                                $("#account-div-sp").css("display","none");
                            }
                        });
                    });


                       $('select[id=REQUESTTYPE]').change(function () 
                    {


                        $("select[id=REQUESTTYPE] option:selected").each(function ()

                        {

                            if ($(this).val() == "TRAC"  ) 
                            {
                            $("#reqtype").css("display","block");
                            $("#account-div-sp").css("display","none");

                            }
                            else
                            {
                             $("#reqtype").css("display","none");
                             $("#account-div-sp").css("display","none");

                            }
                        });
                    });
            	}
        });
    });
    $('select[id=REQUESTTYPE]').change(function () 
                    {                                
                        $("select[id=REQUESTTYPE] option:selected").each(function ()

                        {

                            if ($(this).val() != "TRAC"  ) 
                            {
                            $("#account-div").css("display","block");
							$("#account-div-sp").css("display","none");
                            }
                            else
                            {
                               $("#account-div").css("display","none");
                               $("#account-div-sp").css("display","none");
                            }
                        });
                    });


                       $('select[id=REQUESTTYPE]').change(function () 
                    {


                        $("select[id=REQUESTTYPE] option:selected").each(function ()

                        {

                            if ($(this).val() == "TRAC"  ) 
                            {
                            $("#reqtype").css("display","block");
                            $("#account-div-sp").css("display","none");

                            }
                            else
                            {
                             $("#reqtype").css("display","none");
                             $("#account-div-sp").css("display","none");

                            }
                        });
                    });
});