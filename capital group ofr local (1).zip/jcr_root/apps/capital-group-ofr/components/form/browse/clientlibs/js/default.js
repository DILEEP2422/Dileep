function fileName(file){
    var name=file.split("\\");
    document.getElementById('form-control').innerHTML=name.pop();

}
function fileName1(file){
    var name=file.split("\\");
    document.getElementById('form-control1').innerHTML=name.pop();

}

function fileName2(file){
    var name=file.split("\\");
    document.getElementById('form-control2').innerHTML=name.pop();

}


