
$(document).ready(function(){
    $('#close').hide();
      $('#close').on("click", function() {
          $('#lobSearch').val('');
         var value = $(this).val().toLowerCase();
    $("#formsRows tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
       $('#close').hide();
    });
      });
});  


