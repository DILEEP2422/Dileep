
$(document).ready(function () {



    function incrementSrno() {
        var rowCount = $("#tracTable > tbody > tr").length;
        for (i = 2; i <= rowCount; i++) {
          $("#tracTable > tbody > tr").eq(i - 1).find("td:first-child").text(i);
          if (rowCount > 1) {
            $("#tracTable > tbody > tr:first-child > td:last-child #Delete1").removeClass('dlt-display');
          }
        }
      }



      $('#NewTracBtn').on('click', function () {
        $("<tr><td  class='srNo'></td><td> <input class='input-fields' type='text' id='PLAN_ID' name='PLAN_ID' maxlength='10'></td><td> <input class='input-fields' type='number' id= 'PROCESSING_AMT' name='PROCESSING_AMT' maxlength='15' placeholder='$'><td><button id='Delete1'>Delete</button></td></tr>").insertAfter('#tracTable > tbody > tr:last-child');
        incrementSrno();
      });

   		$(document).on('click', '#Delete1', function () {
        deleteTracRow($(this).parent().parent());
      });	



      function deleteTracRow(parent) {
        $(parent).remove();
        var rowCount = $("#tracTable > tbody > tr").length;
        if (rowCount == 1) {
          $("#tracTable > tbody > tr:first-child > td:last-child #Delete1").addClass('dlt-display');
        }
        for (i = 1; i <= rowCount; i++) {
          var count = 1;
          $('#tracTable > tbody > tr').each(function () {
            $(this).find('td.srNo').text(count);
            count++;
          })
        }
      }





    });