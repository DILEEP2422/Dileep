$(document).ready(function() {

    function btipMessageHide(id) {
        setTimeout(function() {
            $(id).remove();
        }, 3000);
    }

    function processBriteVerify($formEmailAddress) {
        let regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        let isValidEmail = regex.test($formEmailAddress.val());
        if (!isValidEmail) {
            $formEmailAddress.after("<div id='btipincorrectformat' class='btip -error'><div class='error_content'><span>Incorrect format, please correct.</span></div></div>");
            btipMessageHide('#btipincorrectformat');
        } else {
            $.when(
                $.ajax({
                    type: "POST",
                    url: "https://bpi.briteverify.com/emails.json",
                    data: {
                        address: $formEmailAddress.val(),
                        apikey: "cb43999f-b830-49bf-86d5-4dc16d1f779e"
                    },
                    beforeSend:function(){
                        $formEmailAddress.after("<div id='btipverifying' class='btip -verifying'><div class='btip_logo'></div><div class='btip_content'><span>Verifying Email</span></div></div>");
                    },
                    dataType: "jsonp",
                    success: function(data) {
                        return data;
                    },
                    error: function(error) {
                        return error;
                    }
                })
            ).then(
                function(data) {
                    $('#btipverifying').remove();
                    if (data.status === "valid" || data.status === "accept_all") {
                        $formEmailAddress.after("<div id='btipsuccess' class='btip -success'><div class='btip_logo'></div><div class='btip_content'><span>Valid Email</span></div></div>");
                        btipMessageHide('#btipsuccess');
                    } else {
                        $formEmailAddress.after("<div id='btipinvalidemail' class='btip -error'><div class='btip_logo'></div><div class='btip_content'><span>Invalid Email, please correct.</span></div></div>");
                        btipMessageHide('#btipinvalidemail');
                    }
                },
                function(error) {
                    $('#btipverifying').remove();
                    if (error.error_code) {
                        if (errorCode === "email_domain_invalid") {
                            $formEmailAddress.after("<div id='btipinvaliddomain' class='btip -error'><div class='btip_logo'></div><div class='btip_content'><span>Email domain Invalid, please correct.</span></div></div>");
                            btipMessageHide('#btipinvaliddomain');
                        }
                        if (errorCode === "email_account_invalid") {
                            $formEmailAddress.after("<div id='btipinvalidaccount' class='btip -error'><div class='btip_logo'></div><div class='btip_content'><span>Account Invalid, please correct.</span></div></div>");
                            btipMessageHide('#btipinvalidaccount');
                        }
                    } else {
                        $formEmailAddress.after("<div id='btipunknownerror' class='btip -error'><div class='btip_logo'></div><div class='btip_content'><span>Unknown error occured at briteverify. Please try after some time.</span></div></div>");
                        btipMessageHide('#btipunknownerror');
                    }
                }
            );
        }
    }

    $('form input[type=email]').change(function() {
        processBriteVerify($(this));
    });

    /*
    The commented-out code uses css4 which is not globally supported
     */
    // $("form input[type=text][name*='email' i]").change(function() {
    //     processBriteVerify($(this));
    // });

    $('form input[type="text"]').filter(function() {
        if ($(this).attr('name').match(/^.*email.*$/i)) {
            $(this).change(function() {
                processBriteVerify($(this));
            });
        }
    });

});