$(function() {
  function textLabelInFocus($this) {
    if (!$this.hasClass("cmp-form-text__textarea")) {
      $($this)
        .parent()
        .find("label")
        .animate({
          top: "0px",
          fontSize: "10px",
          letterSpacing: "1px"
        });
      $($this).animate({
        height: "30px",
        marginTop: "14px"
      });
    } else {
      $($this)
        .parent()
        .find("label")
        .animate({
          top: "0px",
          left: "0px",
          fontSize: "10px",
          letterSpacing: "1px"
        });
    }
  }

  function textLabelOutOfFocus($this) {
    if (!$this.hasClass("cmp-form-text__textarea")) {
      $($this)
        .parent()
        .find("label")
        .animate({
          top: "12px",
          fontSize: "14px",
          letterSpacing: "1.5px"
        });
      $($this).animate({
        height: "42px",
        marginTop: "0px"
      });
    } else {
      $($this)
        .parent()
        .find("label")
        .animate({
          top: "18px",
          left: "2px",
          fontSize: "14px",
          letterSpacing: "1.5px"
        });
    }
  }

  function textInputHandler($formContainer) {
    $formContainer.find(".cmp-form-text input").each(function() {
      $(this).on("focus click", function(event) {
        if (this === event.target) {
          textLabelInFocus($(this));
        }
      });
      $(this).on("focusout", function(event) {
        if ($(this).val() === "" && this === event.target) {
          textLabelOutOfFocus($(this));
        }
      });
      if ($(this).val() != "") {
        textLabelInFocus($(this));
      }
    });
  }

  function textAreaHandler($formContainer) {
    $formContainer.find(".cmp-form-text textarea").each(function() {
      $(this)
        .parent()
        .find("label")
        .css("top", "18px");
      $(this)
        .parent()
        .find("label")
        .css("left", "2px");
      $(this).on("focus click", function(event) {
        if (this === event.target) {
          textLabelInFocus($(this));
        }
      });
      $(this).on("focusout", function(event) {
        if ($(this).val() === "" && this === event.target) {
          textLabelOutOfFocus($(this));
        }
      });
      if ($(this).val() != "") {
        textLabelInFocus($(this));
      }
    });
  }

  function textLabelAnimation($formContainer) {
    textInputHandler($formContainer);
    textAreaHandler($formContainer);
  }

  function textLabelPlaceholder($formContainer) {
    $formContainer.find(".cmp-form-text input").each(function() {
      let placeholderText = $(this).attr("placeholder");
      if (placeholderText) {
        $(this)
          .parent()
          .append(
            "<span class='cmp-form-text__placeholder'>" +
              placeholderText +
              "</span>"
          );
      }
    });
  }

  function dropDownOptionIndex($this) {
    let semaphore = 0;
    $this.find("option").each(function() {
      if ($(this).attr("selected")) {
        dropDownLabelAnimationIn($this);
        semaphore = 1;
      }
    });
    if (!semaphore) {
      $this.prop("selectedIndex", -1);
    }
  }

  function dropDownLabelAnimationIn($this) {
    $this
      .parent()
      .find("label")
      .animate({
        top: "0px",
        fontSize: "10px",
        letterSpacing: "1px",
        lineHeight: "14px"
      });
  }

  function dropDownLabelAnimationOut($this) {
    if ($this.prop("selectedIndex") === -1) {
      $this
        .parent()
        .find("label")
        .animate({
          top: "22px",
          fontSize: "18px",
          letterSpacing: "initial",
          lineHeight: "28px"
        });
    }
  }

  function dropDownOptions($formContainer) {
    $formContainer
      .find(".cmp-form-options__field.cmp-form-options__field--drop-down")
      .each(function() {
        dropDownOptionIndex($(this));
        $(this).on("focus click", function() {
          dropDownLabelAnimationIn($(this));
        });
        $(this).on("focusout", function() {
          dropDownLabelAnimationOut($(this));
        });
      });
  }

  function setColorForDisabled($formContainer) {
    $formContainer.find(".options").each(function() {
      let $option = $(this);
      $(this)
        .find("input")
        .each(function() {
          if ($(this).attr("disabled")) {
            $(this)
              .parent()
              .find(".cmp-form-options__field-description")
              .addClass("cmp-form-options__field-description--disabled");
          }
        });
    });
  }
  

  if ($(".cmp-form--default").length > 0) {
    let $formContext = $(".cmp-form--default");
    textLabelAnimation($formContext);
    textLabelPlaceholder($formContext);
    dropDownOptions($formContext);
    // handleDropDownImage($formContext);
    setColorForDisabled($formContext);
    
  }

 
});
