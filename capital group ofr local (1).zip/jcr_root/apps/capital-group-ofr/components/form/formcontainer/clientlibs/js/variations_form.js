$(document).ready(function()
	{
			if (!String.prototype.includes)
{
             String.prototype.includes = function() {
             'use strict';
             return String.prototype.indexOf.apply(this, arguments) !== -1;
            };
               }


	var arr;
	var arrLength=0;


	 $(document).on("focus", "[name='submit-btn']", function () {
		arr=new Array(arrLength);
        $('#html_form').find($('*:hidden')).each(function() 
        {
            if($(this).prop("required"))
            {
                $(this).removeAttr('required');
                arr.push($(this));
            }
        });

    });
	 $(document).on("click", "[name='submit-btn']", function (e) {
		 $(".cmp-form-options__field--drop-down").each(function()
		 {

		 if($(this).prop('nodeName')==='SELECT' && $(this).prop("required") && $(this).val()==null)
		 {

		 alert($(this).parent().children().eq(0).text()+' is a required field');
		 $(this).focus();
		 e.preventDefault() ;
		 return false;
		 }
		 
		 });
$(".cmp-form-options__field--radio").each(function()
		 {
var options=$(this).children();
		     var radio=$(this).children().children();
		 var visible=$(this).children().children().is(':visible');
		     if(visible){
		 $(radio[0]).prop("required",true);
		     }
			  });
		  $(".cmp-form-options--checkbox").each(function(){
		 var options=$(this).children();
		                 var checkbox=$(this).children().children();
		 var visible=$(this).children().children().is(':visible');
		     if(visible){
		 var checkboxValues = [];

		           $("input[name="+name+"]:checked").map(function() {
		                       checkboxValues.push($(this).val());

		           });

		         var checkboxs=$(this).children();
		         
		               var checkboxClicked=false;
		               for(var i=0,l=checkboxs.length;i<l;i++)
		               {
		                   if(checkboxs[i].checked)
		                   {
		                       checkboxClicked=true;
		                       break;
		                   }
		               }


		                               if(!checkboxClicked){
		                                   var label=$(this).parent().parent().parent().prev().eq(0).text();
		                                   var message=label.replace(/\n/g, '');
		                                  
		                                   if(message!='' && message!=undefined){
		                               alert(message+' is a required field');
		                                   }else{
		 alert("1 or more checkbox needs to be checked");
		                                   }
		 $(this).focus();
		 e.preventDefault() ;
		                                   return false;
		                               }
		                               }
		     });




		 });
         $(document).on("change", "select", function () {
              $('#html_form').find($('*:visible')).each(function() 
        	{
                if(jQuery.inArray($(this), arr ))
                {
                	
                	var visible=$(this).is(':visible');
                    var isRequired=$(this).prop("required");

                    if(visible && isRequired){
                    $(this).prop("required",true);
                    }
                }

            });


         });




        $("#ipfields").hide();
        $("#contactpreviousname").parent().parent().css("display","none");
        $("#contactsnewname").parent().parent().css("display","none");
        $("#contactname").parent().parent().css("display","none");

        $('input[name="payroll"]').on('change', function() {
                 $("#ipfields").show();
            });

        $("#clear").click(function() {
           
                location.reload();
            });
			
			$('*').each(function()
            {
			arrLength++; 

            });
			
			$("#html_form").submit(function(e){

            var elementList = document.getElementsByTagName("*");
            var content=document.getElementById("email_body").value;
			var mailSubject=document.getElementById("mailSubject").value;
			var emailAddress=document.getElementById("emailAddr").value;
			var userInitials = "";
    if (localStorage.getItem("userInitials") !== null) {
      userInitials = localStorage.getItem("userInitials");
    } else if (localStorage.getItem("okta-token-storage") !== null) {
      userInitials = JSON.parse(
        localStorage.getItem("okta-token-storage")
      ).idToken.claims.preferred_username.split("@")[0];
    }

            var formData="";
            for (var i in elementList) {

             if (elementList[i].id != '' && elementList[i].id !=undefined ) {    

            var value=elementList[i].id;
            var value = String(value);
                 if(!(elementList[i].id).includes("variations")){
                     var formValue=$("#"+value).val();}
             }

             if (elementList[i].id != '' && String(elementList[i].type)=="radio") {    
                 var name=String(elementList[i].name);
                 var formValue =$("input[name="+name+"]:checked").val();
              }
                          if (elementList[i].id != '' && String(elementList[i].type)=="checkbox") {    
var visible=$("#"+elementList[i].id).is(':visible');
                              if(visible){
                              var name=String(elementList[i].name);

                 var checkboxValues = [];

          $("input[name="+name+"]:checked").map(function() {
                      checkboxValues.push($(this).val());

          });
                              var formValue=checkboxValues.toString();
                             }
              }
                 if(elementList[i].id != '' && elementList[i].id!=undefined){
                    if((elementList[i].id).includes("variations")){
                    var idValue=[];
                 $('#html_form').find($('*:visible')).each(function() 
        	{

                if(jQuery.inArray($(this), arr ))
                {
                    var variationid=$(this).attr('id');
                    if (variationid !='' && variationid!=undefined){
                      idValue.push(variationid);

                    }
                }
               var n= idValue.findIndex(element => element.includes("variations"));
                var variation=[];

                for (i=n;i<idValue.length;i++){
               var value = String(idValue[i]);
                    var hiddenValues=$("#"+value).val();

                    if(hiddenValues!=null && hiddenValues!='' && hiddenValues!=undefined ){
var names=$("#"+value).attr('name');
                        variation.push(names);
                        variation.push(hiddenValues);


                    }

                }
                var perrow = 2, 
      html = "<table><tr>";


  for (var i=0; i<variation.length; i++) {

    html += `<td>${variation[i]}</td>`;


    var next = i+1;
    if (next%perrow==0 && next!=variation.length) {
      html += "</tr><tr>";
    }
  }
  html += "</tr></table>";
 formValue=html;

                });
                    }
                    }

	  var formDynamic=$("#"+value +">thead").length;

                if(formDynamic>0){

 var fundtable="<table>";
    var mytable = "<thead><tr>";
    var headings=[];
    $("#"+value ).find("th").each(function(){
        if($(this).html()!=''){
             mytable += "<th>" + $(this).html() + "</th>";
            headings.push($(this).html());}
    });
                    mytable += "</tr></thead>";

                    fundtable+=mytable;

                    var myTab = document.getElementById(""+value+"");

        var arrValues = new Array();

                    var amounttable="<tbody><tr>";
        //loop through each row of the table.
        for (row = 1; row < myTab.rows.length ; row++) {
        	// loop through each cell in a row.


            for (c = 1; c < myTab.rows[row].cells.length; c++) {  
                var element = myTab.rows.item(row).cells[c].querySelectorAll('*[id]');	
                if( document.getElementById(element[0].id).value !=undefined){
                    amounttable += "<td>" +document.getElementById(element[0].id).value + "</td>";

                }
            }
			 amounttable+="</tr></tbody>";

        }

fundtable+=amounttable;
    fundtable+="</table>";


                    formValue=fundtable;


    }
      var newEmail= content.replace("$"+value+"$",formValue);
      var content=newEmail;
      var formData=String(content);
             }

$.post( "/bin/capital-group-ofr/formemailServlet", { formData: formData,mailSubject:mailSubject,emailAddress:emailAddress})
.done(function( data ) {
alert("Form Submitted Successfully");
location.reload();
    });
        });
		
		function browserSupportsDateInput()
{
var i = document.createElement("input");
i.setAttribute("type", "date");
return i.type !== "text";
}

if(!browserSupportsDateInput())
{
$('input[type=date]').datepicker();
}


        $('select[name=REQUESTTYPE]').change(function () {
                // hide all optional elements

                $("select[name=REQUESTTYPE] option:selected").each(function () {
                    if ($(this).val() == "DELETE OGI ID") {
                        $("#contactname").parent().parent().css("display","block");
                        $("#contactpreviousname").parent().parent().css("display","none");
                        $("#contactsnewname").parent().parent().css("display","none");
                    } else if ($(this).val() == "CONTACT NAME CHANGE") {
                        $("#contactname").parent().parent().css("display","none");
                        $("#contactpreviousname").parent().parent().css("display","block");
                        $("#contactsnewname").parent().parent().css("display","block");
                    }
                });
            });


/*-----------------------------------------------------Davast/transcript request---------------------------------------------*/ 
$("#APPROVALREASON").parent().parent().css("display","none");
$('#APPROVER').on('input', function(){

          if($(this).val().length>0)
          {
         $("#APPROVALREASON").parent().parent().css("display","block");
          }
         else
         {
             $("#APPROVALREASON").parent().parent().css("display","none");

         }
});
/*---------------------------------------------------SPECIAL HANDLE REQUEST-----------------------------------------------------------------------------*/

		if((document.URL).includes("special-handle-request")){ 
            $('select[id=REQUESTTYPE]').change(function () 
					{

				        $("select[id=REQUESTTYPE] option:selected").each(function ()
				        {
				            if ($(this).val() == "TRAC" || $(this).val() == "Special delivery to foreign address") 
				            {
				               $("#AORSITE").prop("selectedIndex", 2);
				            }
				           else{
				                $("#AORSITE").prop("selectedIndex", 0);
				           }
				        });
				});
		$("#ADDITIONAL_COMMENTS").attr("title","30 lines maximum");
        $("#SPECIAL_INSTRUCTIONS").attr("title","6 lines maximum");
    	$("#COURIER").parent().parent().css("display","none");
    	$("#BILLING_NUMBER").parent().parent().css("display","none");
    	$("#SERVICE_REQUESTED").parent().parent().css("display","none");
    	$("#SIGNATURE_REQUIRED").parent().parent().css("display","none");
    	$("#SERVICE_REQUESTED1").parent().parent().css("display","none");
    	$("#COURIER1").parent().parent().css("display","none");
    	$("#SITE_FOR_PICKUP").parent().parent().css("display","none");
    	$("#BILLING_NUMBER1").parent().parent().css("display","none");



    $('select[name=DELIVERY]').change(function () 
	{

        $("select[name=DELIVERY] option:selected").each(function ()
        {
            if ($(this).val() == "Overnight Delivery"  ) 
			{

				$("#COURIER").parent().parent().css("display","block");
                $("#BILLING_NUMBER").parent().parent().css("display","block");
                $("#SERVICE_REQUESTED").parent().parent().css("display","block");
                $("#SIGNATURE_REQUIRED").parent().parent().css("display","block");
                $("#SERVICE_REQUESTED1").parent().parent().css("display","none");
                $("#COURIER1").parent().parent().css("display","none");
                $("#SITE_FOR_PICKUP").parent().parent().css("display","none");
                $("#BILLING_NUMBER1").parent().parent().css("display","none");


            }

            else if ($(this).val() == "Overnight Delivery at AFS Expense") 
			{

				$("#COURIER").parent().parent().css("display","block");
                $("#BILLING_NUMBER").parent().parent().css("display","none");
                $("#SERVICE_REQUESTED").parent().parent().css("display","block");
                $("#SIGNATURE_REQUIRED").parent().parent().css("display","block");
                $("#SERVICE_REQUESTED1").parent().parent().css("display","none");
                $("#COURIER1").parent().parent().css("display","none");
                $("#SITE_FOR_PICKUP").parent().parent().css("display","none");
                $("#BILLING_NUMBER1").parent().parent().css("display","none");


            }
			 else if ($(this).val() == "Overnight Delivery Billed to Third Party") 
			{


				$("#COURIER").parent().parent().css("display","none");
                $("#BILLING_NUMBER").parent().parent().css("display","none");
                $("#SERVICE_REQUESTED").parent().parent().css("display","none");
                $("#SIGNATURE_REQUIRED").parent().parent().css("display","block");
                $("#SERVICE_REQUESTED1").parent().parent().css("display","block");
                $("#COURIER1").parent().parent().css("display","block");
                $("#SITE_FOR_PICKUP").parent().parent().css("display","none");
                $("#BILLING_NUMBER1").parent().parent().css("display","block");

            }

            if ($(this).val() == "Shareholder Pick-up"  ) 
			{


                $("#COURIER").parent().parent().css("display","none");
    			$("#BILLING_NUMBER").parent().parent().css("display","none");
    			$("#SERVICE_REQUESTED").parent().parent().css("display","none");
    			$("#SIGNATURE_REQUIRED").parent().parent().css("display","none");
    			$("#SERVICE_REQUESTED1").parent().parent().css("display","none");
    			$("#COURIER1").parent().parent().css("display","none");
    			$("#SITE_FOR_PICKUP").parent().parent().css("display","block");
    			$("#BILLING_NUMBER1").parent().parent().css("display","none");

            }

             else if ($(this).val() == "Regular Mail") 
			{


				$("#COURIER").parent().parent().css("display","none");
                $("#BILLING_NUMBER").parent().parent().css("display","none");
                $("#SERVICE_REQUESTED").parent().parent().css("display","none");
                $("#SIGNATURE_REQUIRED").parent().parent().css("display","none");
                $("#SERVICE_REQUESTED1").parent().parent().css("display","none");
                $("#COURIER1").parent().parent().css("display","none");
                $("#SITE_FOR_PICKUP").parent().parent().css("display","none");
                $("#BILLING_NUMBER1").parent().parent().css("display","none");


            }

		});
	});
	}
	
/*-----------------------------------------------------Davast/transcript request---------------------------------------------*/ 
	
		if((document.URL).includes("davast-transcript-request")){
		
			$('#APPROVER').on('input', function(){

          if($(this).val().length>0)
          {
         $("#approvalReason").parent().parent().css("display","block");
          }
         else
         {
             $("#approvalReason").parent().parent().css("display","none");

         }
});
}

/*---------------------------------------------------WEB RESOLUTION CHECKLIST(**)-----------------------------------------------------------------------------*/

        $('input[name="onetimepasscode"]').parent().parent().css("display","block");
    	$("#repidsequence").parent().parent().css("display","none");
    	$("#clientaccrepid").parent().parent().css("display","none");
    	$("#clientaccvisionid").parent().parent().css("display","none");
    	$("#otherquickenturbohr").parent().parent().css("display","none");

        $('select[name=WEBSITE]').change(function () 
		{
            $("select[name=WEBSITE] option:selected").each(function ()
        	{
                if ($(this).val() == "Investor Website"  ) 
				{
					$('input[name="onetimepasscode"]').parent().parent().css("display","block");
                    $("#repidsequence").parent().parent().css("display","none");
                    $("#clientaccrepid").parent().parent().css("display","none");
                    $("#clientaccvisionid").parent().parent().css("display","none");
                    $("#otherquickenturbohr").parent().parent().css("display","none");

                }

                else if ($(this).val() == "Advisor Website"  ) 
				{
					$('input[name="onetimepasscode"]').parent().parent().css("display","none");
                    $("#repidsequence").parent().parent().css("display","block");
                    $("#clientaccrepid").parent().parent().css("display","none");
                    $("#clientaccvisionid").parent().parent().css("display","none");
                    $("#otherquickenturbohr").parent().parent().css("display","none");

                }

                else if ($(this).val() == "Client Accounts" || $(this).val() == "DST Vision") 
				{
					$('input[name="onetimepasscode"]').parent().parent().css("display","none");
                    $("#repidsequence").parent().parent().css("display","none");
                    $("#clientaccrepid").parent().parent().css("display","block");
                    $("#clientaccvisionid").parent().parent().css("display","block");
                    $("#otherquickenturbohr").parent().parent().css("display","none");

                }

                else if ($(this).val() == "Other (e.g., Quicken, Turbo Tax, HR Block)") 
				{
					$('input[name="onetimepasscode"]').parent().parent().css("display","none");
                    $("#repidsequence").parent().parent().css("display","none");
                    $("#clientaccrepid").parent().parent().css("display","none");
                    $("#clientaccvisionid").parent().parent().css("display","none");
                    $("#otherquickenturbohr").parent().parent().css("display","block");

                }
            });
        });
	



/*---------------------------------------------------TRAC Web Resolution Checklist-----------------------------------------------------------------------------*/

			if((document.URL).includes("trac-web-resolution-checklist0")){ 
			
		 $("#helpdeskMemberInitials").parent().parent().css("display","none");

		 $('input[name="hidhelpdesk"]').change(function () 
		 {
            $('input[name="hidhelpdesk"]:checked').each(function ()
        	{
                if ($('input[name="hidhelpdesk"]:checked').val()=="Yes" ) 
				{
                    $("#helpdeskMemberInitials").parent().parent().css("display","block");
                }

                else if ($('input[name="hidhelpdesk"]:checked').val()== "No"  ) 
				{
                    $("#helpdeskMemberInitials").parent().parent().css("display","none");
                }

            });
         });
		 }
/*---------------------------------------------------TRAC/OGI WEB RESOLUTION CHECKLIST-----------------------------------------------------------------------------*/

		if((document.URL).includes("trac-ogi-web-resolution-checklist")){ 
		
		 $("#sumdisp").css("display","none");
        $("#accountTable").css("width","100%");
        $("#accountTable1").css("width","90%");
		$("#accountTable2").css("width","100%");
		
		$("#totaldisp").css("display","none");
		$("#sum1disp").css("display","none");

 		$("#COMPLETETASK").attr("title","30 lines maximum");
        $("#EXATSTEPS").attr("title","30 lines maximum");
        $("#CODEANDMESSAGE").attr("title","30 lines maximum");
        $("#DEPARTMENT-2").attr("title","30 lines maximum");
        $("#TROUBLESHOOT").attr("title","30 lines maximum");

		$("#OGIID").attr("maxlength","12");
		$("#ACCOUNT").mask("000000000000");
    	$("#OGIID").parent().parent().css("display","none");
    	$("#ACCOUNT").parent().parent().css("display","none");
		$("#SSN-1").parent().parent().css("display","none");
		$('select[name=PAYROLLPROCESS]').parent().parent().css("display","none");
		
		$("#accountTable").parent().parent().parent().css("display","none");
		
		$("#accountTable1").parent().parent().parent().css("display","none");
		
		$("#OTHERBROWSER").parent().parent().css("display","none");
		$("#OTHEROPERSYSTEM").parent().parent().css("display","none");
		
		
		
		

        $('select[name=WEBSITE]').change(function () 
		{
            $("select[name=WEBSITE] option:selected").each(function ()
        	{
                if ($(this).val() == "FPS OGI Website" ) 
				{
                    $("#OGIID").parent().parent().css("display","block");
    				$("#ACCOUNT").parent().parent().css("display","block");
					$('select[name=PAYROLLPROCESS]').parent().parent().css("display","none");
					$("#SSN-1").parent().parent().css("display","none");
					$("#accountTable1").parent().parent().parent().css("display","none");
					
					$("#accountTable").parent().parent().parent().css("display","block");

                }

                else if ($(this).val() == "TRAC Plan Sponsor Website" ) 
				{
                    $("#OGIID").parent().parent().css("display","none");
    				$("#ACCOUNT").parent().parent().css("display","none");
					$('select[name=PAYROLLPROCESS]').parent().parent().css("display","block");
					$("#SSN-1").parent().parent().css("display","block");
					$("#accountTable1").parent().parent().parent().css("display","block");
					
					$("#accountTable").parent().parent().parent().css("display","none");
					
					

                }

                else if ($(this).val() == "TRAC Participant Website" ) 
				{
                    $("#OGIID").parent().parent().css("display","none");
    				$("#ACCOUNT").parent().parent().css("display","none");
					$('select[name=PAYROLLPROCESS]').parent().parent().css("display","none");
					$("#SSN-1").parent().parent().css("display","none");
					
					$("#accountTable").parent().parent().parent().css("display","none");
		
					$("#accountTable1").parent().parent().parent().css("display","none");
		

                }
             });
         });
		 
		  $('select[name=OPERATINGSYSTEM]').change(function () 
		{
            $("select[name=OPERATINGSYSTEM] option:selected").each(function ()
        	{
                if ($(this).val() == "Other" ) 
				{
                  $("#OTHEROPERSYSTEM").parent().parent().css("display","block");  

                }
				else if ($(this).val() == "MAC OS" ||  $(this).val() == "Windows")  
				
				{
				
				$("#OTHEROPERSYSTEM").parent().parent().css("display","none");
				
				}
				
				});
		});
		
		 $('select[name=BROWSER]').change(function () 
		{
            $("select[name=BROWSER] option:selected").each(function ()
        	{
                if ($(this).val() == "Other" ) 
				{
                  $("#OTHERBROWSER").parent().parent().css("display","block");  

                }
				else if ($(this).val() == "Firefox" ||  $(this).val() == "Internet Explorer" || $(this).val() == "Safari" || $(this).val() == "Chrome")
				
				{
				
				$("#OTHERBROWSER").parent().parent().css("display","none");
				
				}
				
				});
		});


	}




/*------------------------------------------------FD - MULTIFUND RPE Notification / Future Date Request Form -------------------------------------------*/

		if((document.URL).includes("fd-multifund-rpe-notification-future-date-request-form")){ 
		
			$("#sumdisp").css("display","none");
	        $("#accountTable").css("width","100%");

	        $('input[name="rpaproc"]').parent().parent().parent().css("display","none");
	        $('input[name="loantypeRadio"]').parent().parent().parent().css("display","none");
	        $('input[name="currchecked"]').parent().parent().parent().css("display","none");
	        $("#sep2").parent().css("display","none");
	        $('input[name="currchecked1"]').parent().parent().parent().css("display","none");
	        $("#numdays").parent().parent().css("display","none");
	        $("#calcbtn").css("display","none");
	        $("#sep3").parent().css("display","none");
	        $('select[name=prevdef]').parent().parent().css("display","none");
	        $('select[name=newdef]').parent().parent().css("display","none");
			$("#sep4").parent().css("display","none");
	        $("#map").parent().css("display","none");
	        $("#planid1").parent().parent().css("display","none");
	        $("#planname1").parent().parent().css("display","none");
			$('select[name=fsc]').parent().parent().css("display","none");
	        $('select[name=tsc]').parent().parent().css("display","none");
	        $('input[name="liketolike"]').parent().parent().parent().css("display","none");
	        $("#dy1").parent().css("display","none");
	        $("#dy2").parent().css("display","none");
			$("#exyesn").parent().css("display","none");
	        $('input[name="expyesnoRadio"]').parent().parent().parent().css("display","none");
	        $("#sep5").parent().css("display","none");
	        $("#worktype").parent().parent().css("display","none");
	        $("#effdate").parent().parent().css("display","none");
	        $("#edate").parent().css("display","none");
	        $("#edate2").parent().css("display","none");
	        $("#tradedt").parent().parent().css("display","none");
	        $("#tdate").parent().css("display","none");
			
			$("#accountTable").parent().parent().parent().css("display","none");
			
			$("#exyesn1").parent().css("display","none");
	        $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","none");
			
			$("#the").parent().css("display","none");
			
			for(var i=0;i<=11;++i){
				$('#AddFundsBtn').click();
			}


	         $('select[name=reqtype]').change(function () 
			{
	            $("select[name=reqtype] option:selected").each(function ()
	        	{
	                if ($(this).val() == "Money Type Change" ) 
					{
						alert('Please provide the contribution formula in the Comments section when adding SHNE, SHM, and/or Purchase Money.');
	                    $('input[name="rpaproc"]').parent().parent().parent().css("display","none");
	                    $('input[name="loantypeRadio"]').parent().parent().parent().css("display","none");
	        			$('input[name="currchecked"]').parent().parent().parent().css("display","none");
	                    $("#sep2").parent().css("display","none");
	                    $('input[name="currchecked1"]').parent().parent().parent().css("display","none");
	                    $("#numdays").parent().parent().css("display","none");
	                    $("#calcbtn").css("display","none");
	                    $("#sep3").parent().css("display","none");
	                    $('select[name=prevdef]').parent().parent().css("display","none");
	                    $('select[name=newdef]').parent().parent().css("display","none");
	                    $("#sep4").parent().css("display","none");
	                    $("#map").parent().css("display","none");
	                    $("#planid1").parent().parent().css("display","none")
	                    $("#planname1").parent().parent().css("display","none")
	                    $('select[name=fsc]').parent().parent().css("display","none");
	                    $('select[name=tsc]').parent().parent().css("display","none");
	                    $('input[name="liketolike"]').parent().parent().parent().css("display","none");
						$("#dy1").parent().css("display","none");
	        			$("#dy2").parent().css("display","none");
	                    $("#exyesn").parent().css("display","none");
	                    $('input[name="expyesnoRadio"]').parent().parent().parent().css("display","none");
	                    $("#sep5").parent().css("display","none");
	                    $("#worktype").parent().parent().css("display","block");
	                    $("#worktype").prop( "value", "" );
	                    $("#worktype").prop( "disabled", true );
	                    $("#effdate").parent().parent().css("display","none");
	                    $("#edate").parent().css("display","none");
	                    $("#edate2").parent().css("display","none");
	                    $("#tradedt").parent().parent().css("display","none");
	                    $("#tdate").parent().css("display","none");
						
						$("#accountTable").parent().parent().parent().css("display","none");
						
						$("#exyesn1").parent().css("display","none");
						$('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","none");
						$("#the").parent().css("display","none");

	                 }


					else if ($(this).val() == "Printed Fee Disclosure Order" || $(this).val() == "Vesting Schedule Change" || $(this).val() == "Other")
	                {
	                    $('input[name="rpaproc"]').parent().parent().parent().css("display","none");
	                    $('input[name="loantypeRadio"]').parent().parent().parent().css("display","none");
	        			$('input[name="currchecked"]').parent().parent().parent().css("display","none");
	                    $("#sep2").parent().css("display","none");
	                    $('input[name="currchecked1"]').parent().parent().parent().css("display","none");
	                    $("#numdays").parent().parent().css("display","none");
	                    $("#calcbtn").css("display","none");
	                    $("#sep3").parent().css("display","none");
	                    $('select[name=prevdef]').parent().parent().css("display","none");
	                    $('select[name=newdef]').parent().parent().css("display","none");
	                    $("#sep4").parent().css("display","none");
	                    $("#map").parent().css("display","none");
	                    $("#planid1").parent().parent().css("display","none")
	                    $("#planname1").parent().parent().css("display","none")
	                    $('select[name=fsc]').parent().parent().css("display","none");
	                    $('select[name=tsc]').parent().parent().css("display","none");
	                    $('input[name="liketolike"]').parent().parent().parent().css("display","none");
	                    $("#dy1").parent().css("display","none");
	        			$("#dy2").parent().css("display","none");
	                    $("#exyesn").parent().css("display","none");
	                    $('input[name="expyesnoRadio"]').parent().parent().parent().css("display","none");
	                    $("#sep5").parent().css("display","none");
	                    $("#worktype").parent().parent().css("display","block");
	                    $("#worktype").prop( "value", "" );
	                    $("#worktype").prop( "disabled", true );
	                    $("#effdate").parent().parent().css("display","none");
	                    $("#edate").parent().css("display","none");
	                    $("#edate2").parent().css("display","none");
	                    $("#tradedt").parent().parent().css("display","none");
	                    $("#tdate").parent().css("display","none");
						
						$("#accountTable").parent().parent().parent().css("display","none");
						
						$("#exyesn1").parent().css("display","none");
						$('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","none");
						
						$("#the").parent().css("display","none");

	                }

	                else if ($(this).val() == "Investment Option Add - No Mapping" || $(this).val() == "Investment Option Remove - No Mapping")
	                {
						$('input[name="rpaproc"]').parent().parent().parent().css("display","none");
	                    $('input[name="loantypeRadio"]').parent().parent().parent().css("display","none");
	        			$('input[name="currchecked"]').parent().parent().parent().css("display","none");
	                    $("#sep2").parent().css("display","none");
	                    $('input[name="currchecked1"]').parent().parent().parent().css("display","none");
	                    $("#numdays").parent().parent().css("display","none");
	                    $("#calcbtn").css("display","none");
	                    $("#sep3").parent().css("display","none");
	                    $('select[name=prevdef]').parent().parent().css("display","none");
	                    $('select[name=newdef]').parent().parent().css("display","none");
	                    $("#sep4").parent().css("display","none");
	                    $("#map").parent().css("display","none");
	                    $("#planid1").parent().parent().css("display","none")
	                    $("#planname1").parent().parent().css("display","none")
	                    $('select[name=fsc]').parent().parent().css("display","none");
	                    $('select[name=tsc]').parent().parent().css("display","none");
	                    $('input[name="liketolike"]').parent().parent().parent().css("display","none");
	                    $("#dy1").parent().css("display","none");
	        			$("#dy2").parent().css("display","none");
	                    $("#exyesn").parent().css("display","none");
	                    $('input[name="expyesnoRadio"]').parent().parent().parent().css("display","none");
	                    $("#sep5").parent().css("display","none");
	                    $("#worktype").parent().parent().css("display","block");
	                    $("#worktype").prop( "value", "" );
	                    $("#worktype").prop( "disabled", true );
	                    $("#effdate").parent().parent().css("display","block");
	                    $("#edate").parent().css("display","none");
	                    $("#edate2").parent().css("display","none");
	                    $("#tradedt").parent().parent().css("display","none");
	                    $("#tdate").parent().css("display","none");
						
						$("#accountTable").parent().parent().parent().css("display","none");
						
						$("#exyesn1").parent().css("display","none");
						$('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","none");
						
						$("#the").parent().css("display","none");

	                }

	                 else if ($(this).val() == "Investment Option Change - Mapping - Unit Class Change")
	                {
	        			$('input[name="rpaproc"]').parent().parent().parent().css("display","block");
	                    $('input[name="loantypeRadio"]').parent().parent().parent().css("display","none");
	        			$('input[name="currchecked"]').parent().parent().parent().css("display","none");
	                    $("#sep2").parent().css("display","none");
	                    $('input[name="currchecked1"]').parent().parent().parent().css("display","none");
	                    $("#numdays").parent().parent().css("display","none");
	                	$("#calcbtn").css("display","none");
	                    $("#sep3").parent().css("display","none");
	                    $('select[name=prevdef]').parent().parent().css("display","none");
	                    $('select[name=newdef]').parent().parent().css("display","none");
	                    $("#sep4").parent().css("display","none");
	                    $("#map").parent().css("display","block");
	                    $("#planid1").parent().parent().css("display","block");
	                    $("#planname1").parent().parent().css("display","block");
	                    $('select[name=fsc]').parent().parent().css("display","block");
	                    $('select[name=tsc]').parent().parent().css("display","block");
	                    $('input[name="liketolike"]').parent().parent().parent().css("display","block");
	                    $("#dy1").parent().css("display","block");
	        			$("#dy2").parent().css("display","block");
	                    $("#exyesn").parent().css("display","block");
	                    $('input[name="expyesnoRadio"]').parent().parent().parent().css("display","block");
	                    $("#sep5").parent().css("display","block");
	                    $("#worktype").parent().parent().css("display","block");
	                    $("#worktype").prop( "disabled", true );
	                    $("#effdate").parent().parent().css("display","block");
	                    $("#edate").parent().css("display","block");
	                    $("#edate2").parent().css("display","none");
	                    $("#tradedt").parent().parent().css("display","block");
	                    $("#tdate").parent().css("display","block");
						
						$("#accountTable").parent().parent().parent().css("display","block");
						
						$("#exyesn1").parent().css("display","none");
						$('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","none");
						
						$("#the").parent().css("display","none");
						$('#expyesnoRadio1').removeAttr('checked');
						
						$('input[name="expyesnoRadio"]').change(function () 
	                     {
	                        $('input[name="expyesnoRadio"]:checked').each(function ()
	                        {
	                            if ($(this).val() == "Yes") 
	                            {
	                                $("#exyesn1").parent().css("display","none");
	                   				$('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","none");
									
									
									$('input[name="expyesnoRadio1"]').prop('checked', false);
									

	                            }

	                            else if ($(this).val() == "No") 
	                            {
	                                 $("#exyesn1").parent().css("display","block");
	                   				 $('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","block");
								
									 
									 $('input[name="expyesnoRadio1"]').prop('checked', false);

	                            }

	                        });
	                     });



					/* ------- Adding changes for datepicker ---- */

	                    function pastDays(theDate, days) {
						var day = new Date(theDate).getUTCDay();
	                        if(day ==2){
	                            days =3;
	                        }

	                    return new Date(theDate.getTime() - days*24*60*60*1000);

	                    }
	                    
	                    function minDays(theDate, days) {
	                    return new Date(theDate.getTime() - days*24*60*60*1000);
	                    }
	                    function maxDays(theDate, days) {
	                    return new Date(theDate.getTime() + days*24*60*60*1000);
	                    }
	                    
	                    var newDate = pastDays(new Date(),1);
	                    var minDate = minDays(new Date(),5).toISOString().substring(0, 10);
	                    var maxDate = maxDays(new Date(),5).toISOString().substring(0, 10);
	                    var finalDate = newDate.toISOString().substring(0, 10);
	                    var field = document.querySelector('#effdate');
	                    field.value = finalDate ;
	                    field.setAttribute("min",minDate);
	                    field.setAttribute("max",maxDate);
						

	                    function noWeekends(e){

	                    var day = new Date(e.target.value).getUTCDay();
						if( day == 0 || day == 6 ){

	                		
	                        e.preventDefault();
	    					this.value = '';


	                    } 

						}
	                    var dateField = document.querySelector('#tradedt');
	                    dateField.addEventListener('input',noWeekends);

	                    
					}
					
					
					else if ($(this).val() == "Investment Option Change - Mapping - Inv Opt Replacement" )
					
					{
					
						$('input[name="rpaproc"]').parent().parent().parent().css("display","block");
	                    $('input[name="loantypeRadio"]').parent().parent().parent().css("display","none");
	        			$('input[name="currchecked"]').parent().parent().parent().css("display","none");
	                    $("#sep2").parent().css("display","none");
	                    $('input[name="currchecked1"]').parent().parent().parent().css("display","none");
	                    $("#numdays").parent().parent().css("display","none");
	                	$("#calcbtn").css("display","none");
	                    $("#sep3").parent().css("display","none");
	                    $('select[name=prevdef]').parent().parent().css("display","none");
	                    $('select[name=newdef]').parent().parent().css("display","none");
	                    $("#sep4").parent().css("display","none");
	                    $("#map").parent().css("display","block");
	                    $("#planid1").parent().parent().css("display","block");
	                    $("#planname1").parent().parent().css("display","block");
	                    $('select[name=fsc]').parent().parent().css("display","block");
	                    $('select[name=tsc]').parent().parent().css("display","block");
	                    $('input[name="liketolike"]').parent().parent().parent().css("display","block");
	                    $("#dy1").parent().css("display","block");
	        			$("#dy2").parent().css("display","block");
	                    $("#exyesn").parent().css("display","none");
	                    $('input[name="expyesnoRadio"]').parent().parent().parent().css("display","none");
	                    $("#sep5").parent().css("display","block");
	                    $("#worktype").parent().parent().css("display","block");
	                    $("#worktype").prop( "disabled", true );
	                    $("#effdate").parent().parent().css("display","block");
	                    $("#edate").parent().css("display","block");
	                    $("#edate2").parent().css("display","none");
	                    $("#tradedt").parent().parent().css("display","block");
	                    $("#tdate").parent().css("display","block");
						
						$("#accountTable").parent().parent().parent().css("display","block");
						
						$("#exyesn1").parent().css("display","none");
						$('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","none");
						
						$("#the").parent().css("display","none");
						
						
						/* ------- Adding changes for datepicker ---- */

	                    function pastDays(theDate, days) {
						var day = new Date(theDate).getUTCDay();
	                        if(day ==2){
	                            days =3;
	                        }

	                    return new Date(theDate.getTime() - days*24*60*60*1000);

	                    }
	                    
	                    function minDays(theDate, days) {
	                    return new Date(theDate.getTime() - days*24*60*60*1000);
	                    }
	                    function maxDays(theDate, days) {
	                    return new Date(theDate.getTime() + days*24*60*60*1000);
	                    }
	                    
	                    var newDate = pastDays(new Date(),1);
	                    var minDate = minDays(new Date(),5).toISOString().substring(0, 10);
	                    var maxDate = maxDays(new Date(),5).toISOString().substring(0, 10);
	                    var finalDate = newDate.toISOString().substring(0, 10);
	                    var field = document.querySelector('#effdate');
	                    field.value = finalDate ;
	                    field.setAttribute("min",minDate);
	                    field.setAttribute("max",maxDate);
						

	                    function noWeekends(e){

	                    var day = new Date(e.target.value).getUTCDay();
						if( day == 0 || day == 6 ){

	                		
	                        e.preventDefault();
	    					this.value = '';


	                    } 

						}
	                    var dateField = document.querySelector('#tradedt');
	                    dateField.addEventListener('input',noWeekends);

	                    
					}
					
					
					
					
					
					
						 
						 
						 


	                else if ($(this).val() == "Default Investment Option Change - No Mapping" )
	                {

						$('input[name="rpaproc"]').parent().parent().parent().css("display","none");
	                    $('input[name="loantypeRadio"]').parent().parent().parent().css("display","none");
	        			$('input[name="currchecked"]').parent().parent().parent().css("display","none");
	                    $("#sep2").parent().css("display","none");
	                    $('input[name="currchecked1"]').parent().parent().parent().css("display","none");
	                    $("#numdays").parent().parent().css("display","none");
	                	$("#calcbtn").css("display","none");
	                    $("#sep3").parent().css("display","none");
	                    $('select[name=prevdef]').parent().parent().css("display","block");
	                    $('select[name=newdef]').parent().parent().css("display","block");
	                    $("#sep4").parent().css("display","block");
	                    $("#map").parent().css("display","none");
	                    $("#planid1").parent().parent().css("display","none")
	                    $("#planname1").parent().parent().css("display","none")
	                    $('select[name=fsc]').parent().parent().css("display","none");
	                    $('select[name=tsc]').parent().parent().css("display","none");
	                    $('input[name="liketolike"]').parent().parent().parent().css("display","none");
						$("#dy1").parent().css("display","none");
	        			$("#dy2").parent().css("display","none");
	                    $("#exyesn").parent().css("display","none");
	                    $('input[name="expyesnoRadio"]').parent().parent().parent().css("display","none");
	                    $("#sep5").parent().css("display","none");
	                    $("#worktype").parent().parent().css("display","block");
	                    $("#worktype").prop( "disabled", true );
	                    $("#effdate").parent().parent().css("display","block");
	                    $("#edate").parent().css("display","none");
	                    $("#edate2").parent().css("display","none");
	                    $("#tradedt").parent().parent().css("display","none");
	                    $("#tdate").parent().css("display","none");
						
						$("#accountTable").parent().parent().parent().css("display","none");
						
						$("#exyesn1").parent().css("display","none");
						$('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","none");
						
						$("#the").parent().css("display","none");


	                }

	                else if ($(this).val() == "Loan Provision Add / Remove" )
	                {
						$('input[name="rpaproc"]').parent().parent().parent().css("display","none");
	                    $('input[name="loantypeRadio"]').parent().parent().parent().css("display","block");
	        			$('input[name="currchecked"]').parent().parent().parent().css("display","block");
	                    $("#sep2").parent().css("display","block");
	                    $('input[name="currchecked1"]').parent().parent().parent().css("display","block");
	                    $("#numdays").parent().parent().css("display","block");
	                    $("#calcbtn").css("display","block");
	                    $("#sep3").parent().css("display","none");
	                    $('select[name=prevdef]').parent().parent().css("display","none");
	                    $('select[name=newdef]').parent().parent().css("display","none");
	                    $("#sep4").parent().css("display","none");
	                    $("#map").parent().css("display","none");
	                    $("#planid1").parent().parent().css("display","none")
	                    $("#planname1").parent().parent().css("display","none")
	                    $('select[name=fsc]').parent().parent().css("display","none");
	                    $('select[name=tsc]').parent().parent().css("display","none");
	                    $('input[name="liketolike"]').parent().parent().parent().css("display","none");
						$("#dy1").parent().css("display","none");
	        			$("#dy2").parent().css("display","none");
	                    $("#exyesn").parent().css("display","none");
	                    $('input[name="expyesnoRadio"]').parent().parent().parent().css("display","none");
	                    $("#sep5").parent().css("display","block");
	                    $("#worktype").parent().parent().css("display","block");
	                    $("#worktype").prop( "disabled", true );
	                    $("#effdate").parent().parent().css("display","block");
	                    $("#edate").parent().css("display","none");
	                    $("#edate2").parent().css("display","block");
	                    $("#tradedt").parent().parent().css("display","none");
	                    $("#tdate").parent().css("display","none");
						
						$("#accountTable").parent().parent().parent().css("display","none");
						
						$("#exyesn1").parent().css("display","none");
						$('input[name="expyesnoRadio1"]').parent().parent().parent().css("display","none");
						$("#the").parent().css("display","block");
						
						
						
						$("#currchecked").click(function(event) {
						if ($(this).is(":checked")) {
							$("#the").parent().css("display","none");
							$("#sep2").parent().css("display","none");
							 $('input[name="currchecked1"]').parent().parent().parent().css("display","none");
							$("#numdays").parent().parent().css("display","none");
							$("#calcbtn").css("display","none");
							$("#effdate").prop( "value", currDate() );
							
							function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

							var today = new Date();
							var month = today.getMonth() + 1;
							if(month < 10) {
								month = "0" + month;
							}
							var day = today.getDate();
							if(day < 10) {
								day = "0" + day;
							}
							var year = today.getFullYear();
							var dateString = year + "-" + month + "-" + day;
							return dateString;
						}

										}
							else {
							$("#the").parent().css("display","block");
							 $('input[name="currchecked1"]').parent().parent().parent().css("display","block");
							$("#numdays").parent().parent().css("display","block");
							$("#calcbtn").css("display","block");
							$("#sep2").parent().css("display","block");
							
							$("#effdate").prop( "value", "" );
							}
				});
				
				
				
				$("#currchecked1").click(function(event) {
						if ($(this).is(":checked")) {
							$("#the").parent().css("display","none");
							
							 
							$("#numdays").parent().parent().css("display","none");
							$("#calcbtn").css("display","none");
							
							alert('Please select the Effective Date.');
							}
						else {
							$("#the").parent().css("display","block");
							 
							$("#numdays").parent().parent().css("display","block");
							$("#calcbtn").css("display","block");
							
							}
				});

					
				}

	             });
	        });
	}



/*------------------------------------------------SYSTEM ENHANCEMENT REQUEST -------------------------------------------*/

		if((document.URL).includes("system-enhancement-request")){


         $("#DESCRIPTION").attr("title","30 lines maximum");
         $("#EXPECTEDRESULTS").attr("title","30 lines maximum");
		 $("#OTHERMETHODSATTEMPTED").attr("title","30 lines maximum");

         $("#Other_text").parent().parent().css("display","none");

        $('input[name="Other"]').change(function () 
		 {
            $('input[name="Other"]').each(function ()
        	{
                if ($('input[name="Other"]:checked').val()=="Other" ) 
				{
                    $("#Other_text").parent().parent().css("display","block");
                }

                else if ($('input[name="Other"]:checked').val()== undefined) 
				{
                    document.getElementById('Other_text').value = "";
                    $("#Other_text").parent().parent().css("display","none");
                }

            });
         });
	}

/*------------------------------------------------BIRG Referral Form -------------------------------------------*/
		
		if((document.URL).includes("birg-referral-form")){

        $('select[name=Workstream]').parent().parent().css("display","none");


         $('select[name=Dept]').change(function () 
		{
            $("select[name=Dept] option:selected").each(function ()
        	{
                if ($(this).val() == "SHSV" ) 
				{
                     $('select[name=Workstream]').parent().parent().css("display","block");
                }

                else
                {
                     $('select[name=Workstream]').parent().parent().css("display","none");
                     $('#Workstream').prop("selectedIndex" , 0);

                }

			});
         });
	}

/*---------------------------------------------------Adviser Locator Request -----------------------------------------------------------------------------*/

		if((document.URL).includes("adviser-locator-request-form")){
		
        $('input[name=shareholderTypeVerification]').parent().parent().css("display","none");
    	$('input[name=shareholderTypeVerification2]').parent().parent().css("display","none");
    	$("#ACCOUNT").parent().parent().css("display","none");

        $("#acTypeOtherText").prop("disabled",true);

        $("#sample2").parent().css("display","none");
        $("#planTypeDetails").parent().parent().css("display","none");
		
		$("#L1").parent().css("display","none");
        $("#L2").parent().css("display","none");


     $('select[name=SHAREHOLDERTYPE]').change(function () 
		{
            $("select[name=SHAREHOLDERTYPE] option:selected").each(function ()
        	{
                if ($(this).val() == "ps"  ) 
				{
                    $('input[name=shareholderTypeVerification]').parent().parent().css("display","block");
                    $('input[name=shareholderTypeVerification2]').parent().parent().css("display","none");
                    $("#ACCOUNT").parent().parent().css("display","none");
                     
                }

                else if($(this).val() == "os" ) 
		{
	            $('input[name=shareholderTypeVerification2]').parent().parent().css("display","block");
                    $('input[name=shareholderTypeVerification]').parent().parent().css("display","none");
                    $("#ACCOUNT").parent().parent().css("display","block");

                }

               });
           });

    $('input[name=ACCOUNTTYPES3]').change(function () 
		{
            $("input[name=ACCOUNTTYPES3]").each(function ()
        	{
                if ($("input[name=ACCOUNTTYPES3]:checked").val() == "ER SPONSORED") 
				{

                    $("#planTypeDetails").parent().parent().css("display","block");
                   $("#sample2").parent().css("display","block");


                }

                else if ($("input[name=ACCOUNTTYPES3]:checked").val() == undefined)
                    {
                        $("#sample2").parent().css("display","none");
                        $("#planTypeDetails").parent().parent().css("display","none");

                     }

                });
            });


         $('input[name=ACCOUNTTYPES4]').change(function () 
		{
            $("input[name=ACCOUNTTYPES4]").each(function ()
        	{ 
                if ($("input[name=ACCOUNTTYPES4]:checked").val() == "OTHER")
		   
                   {
                    $("#acTypeOtherText").prop("disabled",false);

                   }

                else if ($("input[name=ACCOUNTTYPES4]:checked").val() == undefined)
                    {
                        $("#acTypeOtherText").prop("disabled",true);
                    }

                });
            });
			
			
			$("#L1").parent().css("display","none");
        $("#L2").parent().css("display","none");
         $('select[name=CALLERPREFERENCE]').change(function () 
	{

        $("select[name=CALLERPREFERENCE] option:selected").each(function ()
        {
            if ($(this).val() == "ps"  ) 
			{
                $("#L1").parent().css("display","block");
        $("#L2").parent().css("display","none");
            }

        else if ($(this).val() == "os"  )
        {
            $("#L1").parent().css("display","none");
        $("#L2").parent().css("display","block");
        }
      }); 
     }); 
	}

/*------------------------------------------------------------COST BASIS REFERRAL----------------------------------------------------------------------------------*/

		if((document.URL).includes("cost-basis-referral")){
		
        $("#ADDRESS_DELIVERY2").parent().parent().css("display","none");
    	$("#FAX").parent().parent().css("display","none");
        $("#ATTN").parent().parent().css("display","none");
        $("#EMAIL").parent().parent().css("display","none");

        $('input[name=DELIVERY_METHOD1]').change(function () 
		{
            $("input[name=DELIVERY_METHOD1]").each(function ()
        	{
                if ($("input[name=DELIVERY_METHOD1]:checked").val() == "FAX") 
				{

    	             $("#FAX").parent().parent().css("display","block");
                     $("#ATTN").parent().parent().css("display","block");

                 }

                else if ($("input[name=DELIVERY_METHOD1]:checked").val() == undefined) 
				{

    	             $("#FAX").parent().parent().css("display","none");
                     $("#ATTN").parent().parent().css("display","none");

                 }

              });

            });

       $('input[name=DELIVERY_METHOD2]').change(function () 
		{
            $("input[name=DELIVERY_METHOD2]").each(function ()
        	{
                if ($("input[name=DELIVERY_METHOD2]:checked").val() == "EMAIL") 
                  {

    	             $("#EMAIL").parent().parent().css("display","block");
                  }

                else if($("input[name=DELIVERY_METHOD2]:checked").val() == undefined)
                  {

                   $("#EMAIL").parent().parent().css("display","none");
                  }

               });

            });



        $('input[name=MAIL_TO]').change(function () 
		{
            $("input[name=MAIL_TO]").each(function ()
        	{
                if ($("input[name=MAIL_TO]:checked").val() == "SPECIAL") 
				{

    	             $("#ADDRESS_DELIVERY2").parent().parent().css("display","block");
                     $("#ADDRESS_DELIVERY").parent().parent().css("display","none");


                 }
                if ($("input[name=MAIL_TO]:checked").val() == undefined) 
                   {

    	             $("#ADDRESS_DELIVERY2").parent().parent().css("display","none");
                     $("#ADDRESS_DELIVERY").parent().parent().css("display","block");
                   }


                });
            });
	}
 /*------------------------------------------------------------CALL REVIEW ----------------------------------------------------------------------------------*/

	if((document.URL).includes("call-review-request")){ 
	
    $("#range").parent().css("display","none");
    $("#startdate").parent().parent().css("display","none");
    $("#to").parent().css("display","none");
    $("#enddate").parent().parent().css("display","none");
	
	$('select[name=site]').change(function () 
		{
            $("select[name=site] option:selected").each(function ()
        	{
                if ($(this).val() == "irv") 
				{   
				  alert('You selected IRV. Is that correct?');

				 }
				 else if ($(this).val() == "sno")
				 {   
				  alert('You selected SNO. Is that correct?');
				  
				 }
				  else if ($(this).val() == "ind")
				 {   
				  alert('You selected IND. Is that correct?');
				  
				 }
				  else if ($(this).val() == "hro")
				 {   
				  alert('You selected HRO. Is that correct?');
				  
				 }
			});
			
		  });

    $('input[name=unknown]').change(function () 
		{
            $("input[name=unknown]").each(function ()
        	{
                
                if ($("input[name=unknown]:checked").val() == "Unknown") 
		{
                   $("#dateofcall").prop("disabled", true);
                   $("#dateofcall").prop("value" , '');
                   $("#range").parent().css("display","block");
                   $("#startdate").parent().parent().css("display","block");
                   $("#to").parent().css("display","block");
                   $("#enddate").parent().parent().css("display","block");
                 }

               else if ($("input[name=unknown]:checked").val() == undefined) 
		{          $("#dateofcall").prop("disabled", false);
                   $("#range").parent().css("display","none");
                   $("#startdate").parent().parent().css("display","none");
                    $("#startdate").prop("value" , '');
                   $("#to").parent().css("display","none");
                   $("#enddate").parent().parent().css("display","none");
                   $("#enddate").prop("value" , '');
                 }


                });
            });
			
			$('select[name=siteCall]').change(function () 
		{
            $("select[name=siteCall] option:selected").each(function ()
        	{
                if ($(this).val() == "irv") 
				{   
				  alert('You selected IRV. Is that correct?');

				 }
			  else if ($(this).val() == "pho")
				 {   
				  alert('You selected PHO. Is that correct?');
				  
				 }
				 else if ($(this).val() == "sno")
				 {   
				  alert('You selected SNO. Is that correct?');
				  
				 }
				  else if ($(this).val() == "ind")
				 {   
				  alert('You selected IND. Is that correct?');
				  
				 }
				  else if ($(this).val() == "hro")
				 {   
				  alert('You selected HRO. Is that correct?');
				  
				 }
				 
				 else if ($(this).val() == "unknown")
				 {   
				  alert('You selected Unknown. Is that correct?');
				  
				 }
			});
			
		  });

			
			
			
	}

 /*------------------------------------------------------------TRAC Web resolution ----------------------------------------------------------------------------------*/
		if((document.URL).includes("trac-web-resolution-checklist")){
			
			
		
       $("#prdate").parent().parent().css("display","none");
    	$("#prdate2").parent().parent().css("display","none");
        $("#prdate3").parent().parent().css("display","none");
        $("#prdate4").parent().parent().css("display","none");

        $("#batchnum").parent().parent().css("display","none");
    	$("#batchnum2").parent().parent().css("display","none");
        $("#batchnum3").parent().parent().css("display","none");
        $("#batchnum4").parent().parent().css("display","none");

        $("#pramount").parent().parent().css("display","none");
    	$("#pramount2").parent().parent().css("display","none");
        $("#pramount3").parent().parent().css("display","none");
        $("#pramount4").parent().parent().css("display","none");

        $('select[name=funding]').parent().parent().css("display","none");
        $("#fundcomm").parent().parent().css("display","none");

        $("#text1").parent().css("display","none");
        $("#text2").parent().css("display","none");
        $("#payrolldate").parent().css("display","none");
        $("#batchnumber").parent().css("display","none");
        $("#payrollamount").parent().css("display","none");
        $("#fundingcomments").parent().css("display","none");
		$("#helpdeskMemberInitials").parent().parent().css("display","none");

		 $('input[name="helpdeskRadio"]').change(function () 
		 {
            $('input[name="helpdeskRadio"]:checked').each(function ()
        	{
                if ($('input[name="helpdeskRadio"]:checked').val()=="Yes" ) 
				{
                    $("#helpdeskMemberInitials").parent().parent().css("display","block");
                }

                else if ($('input[name="helpdeskRadio"]:checked').val()== "No"  ) 
				{
                    $("#helpdeskMemberInitials").parent().parent().css("display","none");
                }

            });
         });
		

        $('input[name=inprog]').change(function () 
		{
            $("input[name=inprog]").each(function ()
        	{
                if ($("input[name=inprog]:checked").val() == "inprog") 
				{
                   
                $("#prdate").parent().parent().css("display","block");
    	        $("#prdate2").parent().parent().css("display","block");
                $("#prdate3").parent().parent().css("display","block");
                $("#prdate4").parent().parent().css("display","block");

                $("#batchnum").parent().parent().css("display","block");
    	        $("#batchnum2").parent().parent().css("display","block");
                $("#batchnum3").parent().parent().css("display","block");
                $("#batchnum4").parent().parent().css("display","block");

                $("#pramount").parent().parent().css("display","block");
    	         $("#pramount2").parent().parent().css("display","block");
                 $("#pramount3").parent().parent().css("display","block");
                 $("#pramount4").parent().parent().css("display","block");

                    $('select[name=funding]').parent().parent().css("display","block");
                    $("#payrolldate").parent().css("display","block");
                    $("#batchnumber").parent().css("display","block");
                    $("#payrollamount").parent().css("display","block");

                    $("#text1").parent().css("display","block");
                    $("#issue").prop( "value", "N/A" );

                }

               else if ($("input[name=inprog]:checked").val() == undefined) 
		{
                   $("#prdate").parent().parent().css("display","none");
    	           $("#prdate2").parent().parent().css("display","none");
                   $("#prdate3").parent().parent().css("display","none");
                   $("#prdate4").parent().parent().css("display","none");

                   $("#batchnum").parent().parent().css("display","none");
    	          $("#batchnum2").parent().parent().css("display","none");
                  $("#batchnum3").parent().parent().css("display","none");
                   $("#batchnum4").parent().parent().css("display","none");

                  $("#pramount").parent().parent().css("display","none");
    	          $("#pramount2").parent().parent().css("display","none");
                  $("#pramount3").parent().parent().css("display","none");
                  $("#pramount4").parent().parent().css("display","none");

                $('select[name=funding]').parent().parent().css("display","none");
                $("#fundcomm").parent().parent().css("display","none");

        $("#text1").parent().css("display","none");
        $("#text2").parent().css("display","none");
        $("#payrolldate").parent().css("display","none");
        $("#batchnumber").parent().css("display","none");
        $("#payrollamount").parent().css("display","none");
        $("#fundingcomments").parent().css("display","none");
        $("#issue").prop( "value", "" );


                 }


                });
            });

     $('select[name=funding]').change(function () 
		{
            $("select[name=funding] option:selected").each(function ()
        	{
                if ($(this).val() == "Other"  ) 
				{
                    $("#text2").parent().css("display","block");
                    $("#fundingcomments").parent().css("display","block");
                    $("#fundcomm").parent().parent().css("display","block");


                }
                else
                {

                    $("#text2").parent().css("display","none");
                    $("#fundingcomments").parent().css("display","none");
                    $("#text2").parent().css("display","none");
                    $("#fundcomm").parent().parent().css("display","none");



                }




                });
            });
	}

/*------------------------------------------------FD - RPE Notification / Future Date Request Form -------------------------------------------*/

if((document.URL).includes("fd-rpe-notification-future-date-request-form")){
			
			$("#sumdisp").css("display","none");
        $("#accountTable").css("width","100%");

        	$("#participantname").parent().parent().css("display","none");
        	$("#participantssn").parent().parent().css("display","none");
        	$("#holdtypetext").parent().css("display","none");
        	$('input[name="holdtype"]').parent().parent().parent().css("display","none");
        	$("#holdtypedate").parent().parent().css("display","none");
			
			$("#sep1").parent().css("display","none");
			$("#the").parent().css("display","none");
			$("#enter").parent().css("display","none");
			
			

        	$("#rmdyesnotext").parent().css("display","none");
        	$('input[name="rmdyesno"]').parent().parent().parent().css("display","none");

        	$("#fedtext").parent().css("display","none");
        	$('input[name="fedyesno"]').parent().parent().parent().css("display","none");

        	$("#tractext").parent().css("display","none");
        	$('input[name="tracyesno"]').parent().parent().parent().css("display","none");

        	$("#vestingtext").parent().css("display","none");
        	$('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");

        	$("#exptext").parent().css("display","none");
        	$('input[name="expyesno"]').parent().parent().parent().css("display","none");

        	$("#noticetext").parent().css("display","none");
        	$('input[name="noticeyesno"]').parent().parent().parent().css("display","none");

        	$('select[name=prevdef]').parent().parent().css("display","none");
            $('select[name=newdef]').parent().parent().css("display","none");

        	$("#loantypettext").parent().css("display","none");
        	$('input[name="loantype"]').parent().parent().parent().css("display","none");

        	$("#effectiveDatetext").parent().css("display","none");
        	$('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");

        	$("#moneytext").parent().css("display","none");
        	$('input[name="moneytype"]').parent().parent().parent().css("display","none");

        	$("#effectiveDatetext1").parent().css("display","none");
        	$('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");

			$("#numdays").parent().parent().css("display","none");
        	$("#calcbtn").css("display","none")

            $("#map").parent().css("display","none");

        	$('select[name=fsc]').parent().parent().css("display","none");
            $('select[name=tsc]').parent().parent().css("display","none");
        	$('input[name="likefund"]').parent().parent().parent().css("display","none");

			$("#maxpt").parent().parent().css("display","none");

        	$("#worktype").parent().parent().css("display","block");
            $("#worktype").prop( "disabled", true );
			$("#worktype").prop( "value", "" );

        	$("#effdate").parent().parent().css("display","none");
        	$("#edate").parent().css("display","none");
        	$("#tradedt").parent().parent().css("display","none");
			
			$("#accountTable").parent().parent().css("display","none");
			for(var i=0;i<=11;++i){
				$('#AddFundsBtn').click();
			}








         $('select[name=reqtype]').change(function () 
		 {
            $("select[name=reqtype] option:selected").each(function ()
        	{
                if ($(this).val() == "Money Type Change" ) 
				{	
                    $("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");

                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");

                    $("#holdtypedate").parent().parent().css("display","none");

                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");

                    $("#fedtext").parent().css("display","block");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","block");

                    $("#tractext").parent().css("display","block");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","block");

                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");

                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");

                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");

                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");

                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");

                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");

                    $("#moneytext").parent().css("display","block");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","block");

                    $("#effectiveDatetext1").parent().css("display","block");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","block");

                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
                    $("#map").parent().css("display","none");

                    $('select[name=fsc]').parent().parent().css("display","none");
                    $('select[name=tsc]').parent().parent().css("display","none");
                    $('input[name="likefund"]').parent().parent().parent().css("display","none"); 

                    $("#maxpt").parent().parent().css("display","none");

                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "Non-Fin Plan Maint" );

                    $("#effdate").parent().parent().css("display","block");
                    $("#edate").parent().css("display","block");
                    $("#tradedt").parent().parent().css("display","none");
                    
					$("#accountTable").parent().parent().css("display","none");
					
					$("#sep1").parent().css("display","block");
					
					
					
					
					function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

            var today = new Date();
            var month = today.getMonth() + 1;
            if(month < 10) {
                month = "0" + month;
            }
            var day = today.getDate();
            if(day < 10) {
                day = "0" + day;
            }
            var year = today.getFullYear();
            var dateString = year + "-" + month + "-" + day;
            return dateString;
        }

$('input[name=effectiveDateRadio1]').change(function () 
		 {
             $("input[name=effectiveDateRadio1]").each(function ()
        	{
                  if ($("input[name=effectiveDateRadio1]:checked").val() == "today") 
				{ 
    	             $("#effdate").prop( "value", currDate() );

					}

                else if($("input[name=effectiveDateRadio1]:checked").val() == "provided") 
				{ 
    	             $("#effdate").prop( "value", "" );
					  $('#effdate').focus()
					 

					}
				 
				 });
				 
				 });
				 
		}
				 
                    

                 


				else if ($(this).val() == "Printed Fee Disclosure Order")
                {
                    
                    $("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");
                    $("#holdtypedate").parent().parent().css("display","none");
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");
        
                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");
        
                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");
        
                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");
        
                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");
        
                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");
        
                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");
        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext1").parent().css("display","none");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");
        
                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","none");
        
                    $('select[name=fsc]').parent().parent().css("display","none");
                    $('select[name=tsc]').parent().parent().css("display","none");
                    $('input[name="likefund"]').parent().parent().parent().css("display","none");

                    $("#maxpt").parent().parent().css("display","none");
        
                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "" );
        
                    $("#effdate").parent().parent().css("display","none");
                    $("#edate").parent().css("display","none");
                    $("#tradedt").parent().parent().css("display","none");
					
					$("#accountTable").parent().parent().css("display","none");
					
					$("#sep1").parent().css("display","none");


                }


                else if ($(this).val() == "Vesting Schedule Change")
                {
                    $("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");
                    $("#holdtypedate").parent().parent().css("display","none");
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");
        
                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");
        
                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");
        
                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");

                    $("#vestingtext").parent().css("display","block");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","block");
        
                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");
        
                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");
        
                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");
        
                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");
        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext1").parent().css("display","none");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");
        
                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","none");
        
                    $('select[name=fsc]').parent().parent().css("display","none");
                    $('select[name=tsc]').parent().parent().css("display","none");
                    $('input[name="likefund"]').parent().parent().parent().css("display","none");

                    $("#maxpt").parent().parent().css("display","none");

                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "" );
        
                    $("#effdate").parent().parent().css("display","none");
                    $("#edate").parent().css("display","none");
                    $("#tradedt").parent().parent().css("display","none");
					
					$("#accountTable").parent().parent().css("display","none");
					
					$("#sep1").parent().css("display","none");




                }

                else if ($(this).val() == "Fund Remove - No Mapping")
                {
					$("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");
                    $("#holdtypedate").parent().parent().css("display","none");
					
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");
        
                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");
        
                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");
        
                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");
        
                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");
        
                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");
        
                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");
        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");

                    $("#effectiveDatetext1").parent().css("display","none");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");
        
                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","none");
        
                    $('select[name=fsc]').parent().parent().css("display","none");
                    $('select[name=tsc]').parent().parent().css("display","none");
                    $('input[name="likefund"]').parent().parent().parent().css("display","none");

                    $("#maxpt").parent().parent().css("display","none");
        
                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "Fin Plan Maint" );
        
                    $("#effdate").parent().parent().css("display","block");
                    $("#edate").parent().css("display","none");
                    $("#tradedt").parent().parent().css("display","none");
					
					$("#accountTable").parent().parent().css("display","none");
					
					$("#sep1").parent().css("display","none");

                }

                else if ($(this).val() == "Fund Change - Mapping - SCC")
                {
                    
                    $("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");
                    $("#holdtypedate").parent().parent().css("display","none");
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");
        
                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");
        
                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");
        
                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#exptext").parent().css("display","block");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","block");
					
					$("#accountTable").parent().parent().css("display","block");
					
					$("#sep1").parent().css("display","block");
					
					


                    $('input[name="expyesno"]').change(function () 
                     {
                        $('input[name="expyesno"]:checked').each(function ()
                        {
                            if ($(this).val() == "Yes") 
                            {
                                $("#noticetext").parent().css("display","none");
                   				$('input[name="noticeyesno"]').parent().parent().parent().css("display","none");
								
								$('input[name="noticeyesno"]').prop('checked', false);

                            }

                            else if ($(this).val() == "No") 
                            {
                                 $("#noticetext").parent().css("display","block");
                   				 $('input[name="noticeyesno"]').parent().parent().parent().css("display","block");
								 
								 $('input[name="noticeyesno"]').prop('checked', false);

                            }

                        });
                     });


        

        
                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");

                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");
        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext1").parent().css("display","none");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");

                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","block");
        
                    $('select[name=fsc]').parent().parent().css("display","block");
                    $('select[name=tsc]').parent().parent().css("display","block");
                    $('input[name="likefund"]').parent().parent().parent().css("display","block");

                    $("#maxpt").parent().parent().css("display","none");
        
                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "Fin Plan Maint" );
        
                    $("#effdate").parent().parent().css("display","block");
                    $("#edate").parent().css("display","none");
                    $("#tradedt").parent().parent().css("display","block");


                }

               else if ($(this).val() == "Fund Change - Mapping - FREP")
                {
                    
                    $("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");
                    $("#holdtypedate").parent().parent().css("display","none");
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");
        
                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");
        
                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");
        
                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");
        
                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");
        
                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");
        
                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");
        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext1").parent().css("display","none");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");
        
                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","block");
        
                    $('select[name=fsc]').parent().parent().css("display","block");
                    $('select[name=tsc]').parent().parent().css("display","block");
                    $('input[name="likefund"]').parent().parent().parent().css("display","block");

                    $("#maxpt").parent().parent().css("display","none");
        
                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "Fin Plan Maint" );
        
                    $("#effdate").parent().parent().css("display","block");
                    $("#edate").parent().css("display","none");
                    $("#tradedt").parent().parent().css("display","block");
					$("#accountTable").parent().parent().css("display","block");
					
					$("#sep1").parent().css("display","block");


                }

               else if ($(this).val() == "Default Fund Change - No Mapping")
                {
                    
                    $("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");
                    $("#holdtypedate").parent().parent().css("display","none");
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");
        
                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");
        
                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");
        
                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");
        
                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");
        
                    $('select[name=prevdef]').parent().parent().css("display","block");
                    $('select[name=newdef]').parent().parent().css("display","block");
        
                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");
        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext1").parent().css("display","none");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");
        
                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","none");
        
                    $('select[name=fsc]').parent().parent().css("display","none");
                    $('select[name=tsc]').parent().parent().css("display","none");
                    $('input[name="likefund"]').parent().parent().parent().css("display","none");

                    $("#maxpt").parent().parent().css("display","none");
        
                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "Fin Plan Maint" );
        
                    $("#effdate").parent().parent().css("display","block");
                    $("#edate").parent().css("display","none");
                    $("#tradedt").parent().parent().css("display","none");
					
					$("#accountTable").parent().parent().css("display","none");
					
					$("#sep1").parent().css("display","none");


                }

                else if ($(this).val() == "Loan Provision Add / Remove")
                {

                    $("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");
                    $("#holdtypedate").parent().parent().css("display","none");
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");

                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");

                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");

                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");

                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");

                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");

                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");

                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");

                    $("#loantypettext").parent().css("display","block");
                    $('input[name="loantype"]').parent().parent().parent().css("display","block");


                    $("#effectiveDatetext").parent().css("display","block");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","block");
					
					$("#sep1").parent().css("display","block");


                    $('input[name="effectiveDateRadio"]').change(function () 
                     {
                        $('input[name="effectiveDateRadio"]:checked').each(function ()
                        {
                            if ($(this).val() == "notprovided") 
                            {
                                 $("#numdays").parent().parent().css("display","block");
                    			 $("#calcbtn").css("display","block");
								 
								 $("#the").parent().css("display","block");
								 
								   $("#calcbtn").on('click', function(){
									 alert("Entry in the 'days to calculate' field is not a number.");
								   });
                            }

                         	else if ($(this).val() == "provided") 
                            {
                                 $("#numdays").parent().parent().css("display","none");
								 $("#the").parent().css("display","none");
                                $("#calcbtn").css("display","none");
								$("#effdate").prop( "value", "" );
								 $('#effdate').focus()
                            }

                         else if ($(this).val() == "today") 
                            {
                                var currentDate=currDate();
                                $("#numdays").parent().parent().css("display","none");
								$("#the").parent().css("display","none");
                                $("#calcbtn").css("display","none");
                                $("#effdate").val(currentDate);
                            }
                     });
                });
				
				
				
				function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

            var today = new Date();
            var month = today.getMonth() + 1;
            if(month < 10) {
                month = "0" + month;
            }
            var day = today.getDate();
            if(day < 10) {
                day = "0" + day;
            }
            var year = today.getFullYear();
            var dateString = year + "-" + month + "-" + day;
            return dateString;
        }

$('input[name=effectiveDateRadio1]').change(function () 
		 {
             $("input[name=effectiveDateRadio1]").each(function ()
        	{
                  if ($("input[name=effectiveDateRadio1]:checked").val() == "today") 
				{ 
    	             $("#effdate").prop( "value", currDate() );

					}

                else if($("input[name=effectiveDateRadio1]:checked").val() == "provided") 
				{ 
    	             $("#effdate").prop( "value", "" );

					}
				 
				 });
				 
				 });
				 



        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext1").parent().css("display","none");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");
        
                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","none");
        
                    $('select[name=fsc]').parent().parent().css("display","none");
                    $('select[name=tsc]').parent().parent().css("display","none");
                    $('input[name="likefund"]').parent().parent().parent().css("display","none");

                    $("#maxpt").parent().parent().css("display","none");
        
                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "Fin Plan Maint" );
        
                    $("#effdate").parent().parent().css("display","block");
                    $("#edate").parent().css("display","block");
                    $("#tradedt").parent().parent().css("display","none");


                }

                 else if ($(this).val() == "Fee Payment Authorization")
                {
                    
                    $("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");
                    $("#holdtypedate").parent().parent().css("display","none");
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");
        
                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");
        
                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");
        
                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");
        
                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");
        
                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");
        
                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");
        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext1").parent().css("display","block");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","block");
        
                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","none");
        
                    $('select[name=fsc]').parent().parent().css("display","none");
                    $('select[name=tsc]').parent().parent().css("display","none");
                    $('input[name="likefund"]').parent().parent().parent().css("display","none");

                    $("#maxpt").parent().parent().css("display","block");
        
                    $("#worktype").parent().parent().css("display","none");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "" );
        
                    $("#effdate").parent().parent().css("display","block");
                    $("#edate").parent().css("display","block");
                    $("#tradedt").parent().parent().css("display","none");
					
					$("#accountTable").parent().parent().css("display","none");
					
					$("#sep1").parent().css("display","block");


                }

                 else if ($(this).val() == "Distribution")
                {
                    
                    $("#participantname").parent().parent().css("display","block");
                    $("#participantssn").parent().parent().css("display","block");
                    $("#holdtypetext").parent().css("display","block");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","block");
					
					$("#the").parent().css("display","none");


                    $('input[name="holdtype"]').change(function () 
                     {
                        $('input[name="holdtype"]:checked').each(function ()
                        {
                            if ($(this).val() == "ACH") 
                            {
                                // DATE FIELD TO BE SET TO CURRENT DATE AND EFFECTIVE DATE TO BE SET TO TEN DAYS LATER
								
								 var currentDate=currDate();
                                
                                $("#holdtypedate").val(currentDate);
								$("#enter").parent().css("display","none");
                               

                            }

                    		else if($(this).val() =="Address Change")
                    		{
                        		// TEXT FIELD IS TO BE ADDED TO DATE
                                $("#holdtypedate").prop( "value", "" );
								 $('#holdtypedate').focus()
                               // $("#holdtypedate").val(currDate());
								$("#enter").parent().css("display","block");

                    		}

                        });
                     });
					 
					 function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

						var today = new Date();
						var month = today.getMonth() + 1;
						if(month < 10) {
							month = "0" + month;
						}
						var day = today.getDate();
						if(day < 10) {
							day = "0" + day;
						}
						var year = today.getFullYear();
						var dateString = year + "-" + month + "-" + day;
						return dateString;
					}





                    $("#holdtypedate").parent().parent().css("display","block");
        
                    $("#rmdyesnotext").parent().css("display","block");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","block");
        
                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");
        
                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");
        
                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");
        
                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");
        
                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");
        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext1").parent().css("display","none");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");
        
                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","none");
        
                    $('select[name=fsc]').parent().parent().css("display","none");
                    $('select[name=tsc]').parent().parent().css("display","none");
                    $('input[name="likefund"]').parent().parent().parent().css("display","none");

                    $("#maxpt").parent().parent().css("display","none");
        
                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "Distribution" );
        
                    $("#effdate").parent().parent().css("display","block").prop("disable",true);
                    $("#edate").parent().css("display","none");
                    $("#tradedt").parent().parent().css("display","none");
					
					$("#sep1").parent().css("display","none");


                }

                 else if ($(this).val() == "Other")
                {
                    
                    $("#participantname").parent().parent().css("display","none");
                    $("#participantssn").parent().parent().css("display","none");
                    $("#holdtypetext").parent().css("display","none");
                    $('input[name="holdtype"]').parent().parent().parent().css("display","none");
                    $("#holdtypedate").parent().parent().css("display","none");
					
					$("#the").parent().css("display","none");
					$("#enter").parent().css("display","none");
        
                    $("#rmdyesnotext").parent().css("display","none");
                    $('input[name="rmdyesno"]').parent().parent().parent().css("display","none");
        
                    $("#fedtext").parent().css("display","none");
                    $('input[name="fedyesno"]').parent().parent().parent().css("display","none");
        
                    $("#tractext").parent().css("display","none");
                    $('input[name="tracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#vestingtext").parent().css("display","none");
                    $('input[name="vestingtracyesno"]').parent().parent().parent().css("display","none");
        
                    $("#exptext").parent().css("display","none");
                    $('input[name="expyesno"]').parent().parent().parent().css("display","none");
        
                    $("#noticetext").parent().css("display","none");
                    $('input[name="noticeyesno"]').parent().parent().parent().css("display","none");
        
                    $('select[name=prevdef]').parent().parent().css("display","none");
                    $('select[name=newdef]').parent().parent().css("display","none");
        
                    $("#loantypettext").parent().css("display","none");
                    $('input[name="loantype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext").parent().css("display","none");
                    $('input[name="effectiveDateRadio"]').parent().parent().parent().css("display","none");
        
                    $("#moneytext").parent().css("display","none");
                    $('input[name="moneytype"]').parent().parent().parent().css("display","none");
        
                    $("#effectiveDatetext1").parent().css("display","none");
                    $('input[name="effectiveDateRadio1"]').parent().parent().parent().css("display","none");
        
                    $("#numdays").parent().parent().css("display","none");
                    $("#calcbtn").css("display","none")
        
                    $("#map").parent().css("display","none");
        
                    $('select[name=fsc]').parent().parent().css("display","none");
                    $('select[name=tsc]').parent().parent().css("display","none");
                    $('input[name="likefund"]').parent().parent().parent().css("display","none");

                    $("#maxpt").parent().parent().css("display","none");
        
                    $("#worktype").parent().parent().css("display","block");
                    $("#worktype").prop( "disabled", true );
                    $("#worktype").prop( "value", "" );

                    $("#effdate").parent().parent().css("display","none");
                    $("#edate").parent().css("display","none");
                    $("#tradedt").parent().parent().css("display","none");
					
					$("#sep1").parent().css("display","none");
					
					


                }


             });

        });



function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy)
    		
            var today = new Date();
            var month = today.getMonth() + 1;
            if(month < 10) {
                month = "0" + month;
            }
        
            var day = today.getDate();
            if(day < 10) {
                day = "0" + day;
            }
        
            var year = today.getFullYear() ;
            var dateString = year + "-" + month + "-" + day;
            return dateString;
        }	

	
	

	}




/*---------------------------------------------------RP PHONE-GENERATED RESEARCH / CORRECTION REQUEST-----------------------------------------------------------------------------*/

		if((document.URL).includes("rp-phone-generated-research-correction-request")){
		
        $("#PLANID").parent().parent().css("display","none");
         $("#PLANNAME").parent().parent().css("display","none");
         $("#GROUPPLANNAME").parent().parent().css("display","none");
         $("#PARTICIPANTNAME").parent().parent().css("display","none");
         $("#ACCOUNT").parent().parent().css("display","none");	
         $("#SOCIALSECNO").parent().parent().css("display","none");
		


        $('input[name=system-1]').change(function () 
		 {
            $("input[name=system-1]").each(function ()
        	{
                if ($("input[name=system-1]:checked").val()=="TRAC" ) 
				{
                      $("#PLANID").parent().parent().css("display","block");
                      $("#PLANNAME").parent().parent().css("display","block");

                      $("#PARTICIPANTNAME").parent().parent().css("display","block");

                      $("#SOCIALSECNO").parent().parent().css("display","block");

                }
                   else if ($("input[name=system-1]:checked").val() == undefined && $("input[name=system-2]:checked").val() == "SHARE")
                    {
                       $("#PLANID").parent().parent().css("display","none");
                       $("#PLANNAME").parent().parent().css("display","block");
					   $("#PARTICIPANTNAME").parent().parent().css("display","block");
					   $("#SOCIALSECNO").parent().parent().css("display","block");
					   

                     }
				else if ($("input[name=system-1]:checked").val() == undefined && $("input[name=system-2]:checked").val() == undefined)
                    {
                       $("#PLANID").parent().parent().css("display","none");
                       $("#PLANNAME").parent().parent().css("display","none");
					   $("#PARTICIPANTNAME").parent().parent().css("display","none");
					   $("#SOCIALSECNO").parent().parent().css("display","none");
					   

                     }
              

                });
            });
			
			$('input[name=system-2]').change(function () 
		 {
            $("input[name=system-2]").each(function ()
        	{
                  if ($("input[name=system-2]:checked").val() == "SHARE") 
				{ 
    	             $("#GROUPPLANNAME").parent().parent().css("display","block");
					  $("#ACCOUNT").parent().parent().css("display","block");
					   
                      $("#PLANNAME").parent().parent().css("display","block");

                      $("#PARTICIPANTNAME").parent().parent().css("display","block");

                      $("#SOCIALSECNO").parent().parent().css("display","block");

                 }
                  else if ($("input[name=system-2]:checked").val() == undefined && $("input[name=system-1]:checked").val() == "TRAC")
                    {
                       $("#PLANID").parent().parent().css("display","block");
                       $("#PLANNAME").parent().parent().css("display","block");
					   $("#PARTICIPANTNAME").parent().parent().css("display","block");
					   $("#SOCIALSECNO").parent().parent().css("display","block");
					   $("#GROUPPLANNAME").parent().parent().css("display","none");
					  $("#ACCOUNT").parent().parent().css("display","none");

                     }
				 else if ($("input[name=system-2]:checked").val() == undefined && $("input[name=system-1]:checked").val() == undefined)
                    {
                      
                       $("#PLANNAME").parent().parent().css("display","none");
					   $("#PARTICIPANTNAME").parent().parent().css("display","none");
					   $("#SOCIALSECNO").parent().parent().css("display","none");
					   $("#GROUPPLANNAME").parent().parent().css("display","none");
					  $("#ACCOUNT").parent().parent().css("display","none");
					   

                     }
                 



            });
         });
	}


/*------------------------------------------------UFIDX-----------------------------------------------------------------------------------------------------*/

		if((document.URL).includes("ufidx")){

        $("#dealer").parent().parent().css("display","none");
    	$("#branch").parent().parent().css("display","none");
    	$("#house").parent().parent().css("display","none");
		$("#phone").parent().parent().css("display","none");
		$("#fax").parent().parent().css("display","none");
		$("#houseaccount1").parent().css("display","none");
		$("#repid1").parent().css("display","none");
		$("#house1").parent().css("display","none");
		
		$("#ufidmismatch1").parent().css("display","none");
		$("#dealer2").parent().parent().css("display","none");
    	$("#branch2").parent().parent().css("display","none");
    	$("#repid").parent().parent().css("display","none");
		$("#repname").parent().parent().css("display","none");
		$("#fax2").parent().parent().css("display","none");
		
		 $("#Sep5").parent().css("display","none");
		
		 $('select[name=ufid]').change(function () 
		{
            $("select[name=ufid] option:selected").each(function ()
        	{
                if ($(this).val() == "houseaccount"  ) 
				{   
			        
					$("#houseaccount1").parent().css("display","block");
					$("#dealer").parent().parent().css("display","block");
					$("#branch").parent().parent().css("display","block");
					$("#house1").parent().css("display","block");
					$("#phone").parent().parent().css("display","block");
					$("#fax").parent().parent().css("display","block");
					$("#house").parent().parent().css("display","block");
					
					$("#repid1").parent().css("display","block");
					 $("#Sep5").parent().css("display","block");
					
					$("#ufidmismatch1").parent().css("display","none");
					$("#dealer2").parent().parent().css("display","none");
					$("#branch2").parent().parent().css("display","none");
					$("#repid").parent().parent().css("display","none");
					$("#repname").parent().parent().css("display","none");
					$("#fax2").parent().parent().css("display","none");
								
                     
                }

                else if($(this).val() == "ufidmismatch" ) 
		{
	           
			   $("#ufidmismatch1").parent().css("display","block");
			   $("#dealer2").parent().parent().css("display","block");
				$("#branch2").parent().parent().css("display","block");
				$("#repid").parent().parent().css("display","block");
				$("#repname").parent().parent().css("display","block");
				$("#fax2").parent().parent().css("display","block");
				$("#Sep5").parent().css("display","block");
				
				
			
                $("#dealer").parent().parent().css("display","none");
				$("#branch").parent().parent().css("display","none");
				$("#house").parent().parent().css("display","none");
				$("#phone").parent().parent().css("display","none");
				$("#fax").parent().parent().css("display","none");
				$("#houseaccount1").parent().css("display","none");
				$("#repid1").parent().css("display","none");
				$("#house1").parent().css("display","none");
				
				
		
		

                }

               });
           });
	}

/*------------------------------------------------G-PURCH BATCH TICKET---------------------------------------------------------------------------------------*/

			if((document.URL).includes("g-purch-batch-ticket")){
			
		   $("#accountTable").parent().parent().parent().css("display","none");
				
				 $("#accountTable").css("width","60%");
			
		   $("#wireinvestments").parent().css("display","none");
		   $("#file").parent().parent().css("display","none");
    	
		
		
		 $('select[name=site2]').change(function () 
		{
            $("select[name=site2] option:selected").each(function ()
        	{
                if ($(this).val() == "IRV") 
				{   
				  alert('You selected IRV. Is that correct?');

				 }
				 else if ($(this).val() == "SNO")
				 {   
				  alert('You selected SNO. Is that correct?');
				  
				 }
				  else if ($(this).val() == "IND")
				 {   
				  alert('You selected IND. Is that correct?');
				  
				 }
				  else if ($(this).val() == "HRO")
				 {   
				  alert('You selected HRO. Is that correct?');
				  
				 }
			});
			
		  });
			    
				 $('select[name=SOURCETYPE]').change(function () 
		{
            $("select[name=SOURCETYPE] option:selected").each(function ()
        	{
                if ($(this).val() == "Imaged"  ) 
				{   
				  alert('You selected Imaged. Is that correct?');
				  
				 }
				 else if ($(this).val() == "Paper")
				 {   
				  alert('You selected Paper. Is that correct?');
				  
				 }
			});
			
		  });
			$('select[name=site]').change(function () 
		{
            $("select[name=site] option:selected").each(function ()
        	{
                if ($(this).val() == "IRV") 
				{   
				  alert('You selected IRV. Is that correct?');
				  
				 }
				 else if ($(this).val() == "SNO")
				 {   
				  alert('You selected SNO. Is that correct?');
				  
				 }
				  else if ($(this).val() == "IND")
				 {   
				  alert('You selected IND. Is that correct?');

				 }
				  else if ($(this).val() == "HRO")
				 {   
				  alert('You selected HRO. Is that correct?');
				  
				 }
			});
			
		  });
			$('select[name=PAYMENTTYPE]').change(function () 
		{
            $("select[name=PAYMENTTYPE] option:selected").each(function ()
        	{
                if ($(this).val() == "WIRE") 
				{   
				     $("#wireinvestments").parent().css("display","block");
					 $("#file").parent().parent().css("display","block");
					 
					 $("#accountTable").parent().parent().parent().css("display","none");
				  
				 }
                else if ($(this).val() == "CHECK") 
				{   
				     $("#wireinvestments").parent().css("display","none");
					 $("#file").parent().parent().css("display","none");
					 
					 $("#accountTable").parent().parent().parent().css("display","block");
				  
				 }


			});
			
		});
	}

/*------------------------------------------------RPS Compliance Referral Form--------------------------------------------------------------------------------*/

	if((document.URL).includes("rps-compliance-referral-form")){ 


       $("#fraud").parent().css("display","none");
		$("#RPSNotifiedDate").parent().parent().css("display","none");
    	$("#SCENARIODESCRIPTION").parent().parent().css("display","none");
    	$("#ACTIONTAKEN").parent().parent().css("display","none");
		
		$("#Soni").parent().css("display","none");
		
		
		
		$("#loan").parent().css("display","none");
    	$("#SSN").parent().parent().css("display","none");
		$("#LOANNUMBER").parent().parent().css("display","none");
		$("#LoanOriginationDate").parent().parent().css("display","none");
		$("#LoanMaturityDate").parent().parent().css("display","none");
    	$("#DateLoanDefaulted").parent().parent().css("display","none");
		$("#CurePeriodEndDate").parent().parent().css("display","none");
		$("#NOTCURRENTLOAN").parent().parent().css("display","none");
		$("#LOANCIRCUMSTANCES").parent().parent().css("display","none");
		$("#REFERRALTYPE").find("option[value='Testing']").parent().empty().append('<option value="">Select</option><option value="Account Access/Privacy">Account Access/Privacy</option><option value="Adjustments">Adjustments</option><option value="Bankruptcy, Levy, Garnishments, &amp; Court Orders">Bankruptcy, Levy, Garnishments, &amp; Court Orders</option><option value="Compliance Stop">Compliance Stop</option><option value="Contribution">Contribution</option><option value="Correspondence Review">Correspondence Review</option><option value="Distributions">Distributions</option><option value="Exception Request">Exception Request</option><option value="Fraud/ID Theft">Fraud/ID Theft</option><option value="Loan Default Reversal Request">Loan Default Reversal Request</option><optgroup label="Plan Audit or Plan Year End" value="Plan Audit or Plan Year End"><option value="Testing">Testing</option><option value="Plan Audit or Plan Year End - Other">Other</option></optgroup><optgroup label="Plan Election or Provision" value="Plan Election or Provision"><option value="Describe Line Request">Describe Line Request</option><option value="Plan Document Issue/Question">Plan Document Issue/Question</option></optgroup><option value="Plan Install or Conversion">Plan Install or Conversion</option><option value="Plan Termination">Plan Termination</option><option value="Plan/Participant Maint">Plan/Participant Maint</option><option value="Process Improvement">Process Improvement</option><option value="Tax Withholding or Tax Reporting">Tax Withholding or Tax Reporting</option><option value="Other">Other</option>')
		
		$("#plantesting").parent().css("display","none");
		$("#concern").parent().css("display","none");
		 $('input[name=CONCERNTEST]').parent().parent().parent().css("display","none");
		  $('input[name=CONCERNTEST1]').parent().parent().parent().css("display","none");
        $("#OTHERDESCRIBE").parent().parent().css("display","none");
        $("#PLANSPONSORSTEPS").parent().parent().css("display","none");
        $("#PLANDESCOCCURRED").parent().parent().css("display","none");
        $("#PLANADDITIONALQUE").parent().parent().css("display","none");
        $("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display","none");
        $("#PLANPROPOSEDQUES").parent().parent().css("display","none");



        $("#useof").parent().css("display","none");
    	$("#PLANELECTIONCURRENTPRO").parent().parent().css("display","none");
        $("#PLANAPPEARDESCRIBELINE").parent().parent().css("display","none");
        $("#PLANPURPOSEDESCRIBE").parent().parent().css("display","none");
        $("#PLANDESCRIBELINEREAD").parent().parent().css("display","none");
		
		
        $("#plandocument").parent().css("display","none");
        $("#PLANDOCREQUESTIMPACT").parent().parent().css("display","none");
    	$("#PLANDESCWHATOCCURRED").parent().parent().css("display","none");
        $("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display","none");
        $("#PLANSPONSORADDQUE").parent().parent().css("display","none");
        $("#PLANPROPOSESOLUTION").parent().parent().css("display","none");
        $("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display","none"); 
		
		
		$('input[name=SONI]').change(function () 
                     {
                        $("input[name=SONI]:checked").each(function ()
                        {
                            if ($("input[name=SONI]:checked").val() == "YES") 
                            {
                                $("#Soni").parent().css("display","block");

                            }
							else if ($("input[name=SONI]:checked").val() == "NO") 
                            {
                                $("#Soni").parent().css("display","None");

                            }

                    		
                        });
                     });
        
		$('select[name=REFERRALTYPE]').change(function () 
		 {
            $("select[name=REFERRALTYPE] option:selected").each(function ()
        	{
                if ($(this).val() == "Fraud ID Theft") 
				{	
                   $("#fraud").parent().css("display","block");
				   $("#RPSNotifiedDate").parent().parent().css("display","block");
				   $("#SCENARIODESCRIPTION").parent().parent().css("display","block");
				   $("#ACTIONTAKEN").parent().parent().css("display","block");
				   $('input[name=SONI]').parent().parent().parent().css("display","block");
				   $("#soni").parent().css("display","block");
				   
				   $("#Resolution").parent().parent().css("display","block");
				   
				   $('input[name=SONI]').change(function () 
                     {
                        $("input[name=SONI]:checked").each(function ()
                        {
                            if ($("input[name=SONI]:checked").val() == "YES") 
                            {
                                $("#Soni").parent().css("display","block");

                            }
							else if ($("input[name=SONI]:checked").val() == "NO") 
                            {
                                $("#Soni").parent().css("display","None");

                            }

                    		
                        });
                     });
		                $("#description").parent().parent().css("display","none");
						$("#loan").parent().css("display","none");
						$("#SSN").parent().parent().css("display","none");
						$("#LOANNUMBER").parent().parent().css("display","none");
						$("#LoanOriginationDate").parent().parent().css("display","none");
						$("#LoanMaturityDate").parent().parent().css("display","none");
						$("#DateLoanDefaulted").parent().parent().css("display","none");
						$("#CurePeriodEndDate").parent().parent().css("display","none");
						$("#NOTCURRENTLOAN").parent().parent().css("display","none");
						$("#LOANCIRCUMSTANCES").parent().parent().css("display","none");
						
						
						$("#plantesting").parent().css("display","none");
						$("#concern").parent().css("display","none");
						 $('input[name=CONCERNTEST]').parent().parent().parent().css("display","none");
                         $('input[name=CONCERNTEST1]').parent().parent().parent().css("display","none");
						$("#OTHERDESCRIBE").parent().parent().css("display","none");
						$("#PLANSPONSORSTEPS").parent().parent().css("display","none");
						$("#PLANDESCOCCURRED").parent().parent().css("display","none");
						$("#PLANADDITIONALQUE").parent().parent().css("display","none");
						$("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display","none");
						$("#PLANPROPOSEDQUES").parent().parent().css("display","none");



						$("#useof").parent().css("display","none");
						$("#PLANELECTIONCURRENTPRO").parent().parent().css("display","none");
						$("#PLANAPPEARDESCRIBELINE").parent().parent().css("display","none");
						$("#PLANPURPOSEDESCRIBE").parent().parent().css("display","none");
						$("#PLANDESCRIBELINEREAD").parent().parent().css("display","none");
						
						
						$("#plandocument").parent().css("display","none");
						$("#PLANDOCREQUESTIMPACT").parent().parent().css("display","none");
						$("#PLANDESCWHATOCCURRED").parent().parent().css("display","none");
						$("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display","none");
						$("#PLANSPONSORADDQUE").parent().parent().css("display","none");
						$("#PLANPROPOSESOLUTION").parent().parent().css("display","none");
						$("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display","none");
						
				}






					   else if ($(this).val() == "Loan Default Reversal Request")
						{
							$("#loan").parent().css("display","block");
							$("#SSN").parent().parent().css("display","block");
							$("#LOANNUMBER").parent().parent().css("display","block");
							$("#LoanOriginationDate").parent().parent().css("display","block");
							$("#LoanMaturityDate").parent().parent().css("display","block");
							$("#DateLoanDefaulted").parent().parent().css("display","block");
							$("#CurePeriodEndDate").parent().parent().css("display","block");
							$("#NOTCURRENTLOAN").parent().parent().css("display","block");
							$("#LOANCIRCUMSTANCES").parent().parent().css("display","block");
							$("#Resolution").parent().parent().css("display","block");
							$('input[name=SONI]').parent().parent().parent().css("display","block");
							$("#soni").parent().css("display","block");
							
							$('input[name=SONI]').change(function () 
                       {
                        $("input[name=SONI]:checked").each(function ()
                         {
                              if ($("input[name=SONI]:checked").val() == "YES") 
                            {
                                $("#Soni").parent().css("display","block");

                            }
							else if ($("input[name=SONI]:checked").val() == "NO") 
                            {
                                $("#Soni").parent().css("display","None");

                            }

                    		
                        });
                     });
					 
								$("#fraud").parent().css("display","none");
								$("#RPSNotifiedDate").parent().parent().css("display","none");
								$("#SCENARIODESCRIPTION").parent().parent().css("display","none");
								$("#ACTIONTAKEN").parent().parent().css("display","none");
								$("#description").parent().parent().css("display","none");
						
								$("#plantesting").parent().css("display","none");
								$("#concern").parent().css("display","none");
								 $('input[name=CONCERNTEST]').parent().parent().parent().css("display","none");
								  $('input[name=CONCERNTEST1]').parent().parent().parent().css("display","none");
								$("#OTHERDESCRIBE").parent().parent().css("display","none");
								$("#PLANSPONSORSTEPS").parent().parent().css("display","none");
								$("#PLANDESCOCCURRED").parent().parent().css("display","none");
								$("#PLANADDITIONALQUE").parent().parent().css("display","none");
								$("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display","none");
								$("#PLANPROPOSEDQUES").parent().parent().css("display","none");



								$("#useof").parent().css("display","none");
								$("#PLANELECTIONCURRENTPRO").parent().parent().css("display","none");
								$("#PLANAPPEARDESCRIBELINE").parent().parent().css("display","none");
								$("#PLANPURPOSEDESCRIBE").parent().parent().css("display","none");
								$("#PLANDESCRIBELINEREAD").parent().parent().css("display","none");
								
								
								$("#plandocument").parent().css("display","none");
								$("#PLANDOCREQUESTIMPACT").parent().parent().css("display","none");
								$("#PLANDESCWHATOCCURRED").parent().parent().css("display","none");
								$("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display","none");
								$("#PLANSPONSORADDQUE").parent().parent().css("display","none");
								$("#PLANPROPOSESOLUTION").parent().parent().css("display","none");
								$("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display","none");
						}
						
						else if ($(this).val() == "Testing")
						{
								$("#plantesting").parent().css("display","block");
								$("#concern").parent().css("display","block");
								 $('input[name=CONCERNTEST]').parent().parent().parent().css("display","block");
                                $('input[name=CONCERNTEST1]').parent().parent().parent().css("display","block");

								$("#PLANSPONSORSTEPS").parent().parent().css("display","block");
								$("#PLANDESCOCCURRED").parent().parent().css("display","block");
								$("#PLANADDITIONALQUE").parent().parent().css("display","block");
								$("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display","block");
								$("#PLANPROPOSEDQUES").parent().parent().css("display","block");
								$('input[name=SONI]').parent().parent().parent().css("display","block");
								
								
								$('input[name=SONI]').change(function () 
                         {
                          $("input[name=SONI]:checked").each(function ()
                        {
                              if($("input[name=SONI]:checked") .val() == "YES") 
                            {
                                $("#Soni").parent().css("display","block");

                            }
							else if ($("input[name=SONI]:checked").val() == "NO") 
                            {
                                $("#Soni").parent().css("display","None");

                            }

                    		
                        });
                     });
					 
					 	$('input[name=CONCERNTEST1]').change(function () 
                     {
                        $("input[name=CONCERNTEST1]:checked").each(function ()
                        {
                              if ($("input[name=CONCERNTEST1]:checked").val() == "Other") 
                            {
                                $("#OTHERDESCRIBE").parent().parent().css("display","block");

                            }
							else if ($("input[name=CONCERNTEST1]:checked").val() == undefined) 
                            {
                                $("#OTHERDESCRIBE").parent().parent().css("display","none");

                            }

                    		
                        });
                     });
					 
									$("#fraud").parent().css("display","none");
									$("#RPSNotifiedDate").parent().parent().css("display","none");
									$("#SCENARIODESCRIPTION").parent().parent().css("display","none");
									$("#ACTIONTAKEN").parent().parent().css("display","none");
									
								
									$("#Resolution").parent().parent().css("display","none");
									$("#description").parent().parent().css("display","none");
									
									
									$("#loan").parent().css("display","none");
									$("#SSN").parent().parent().css("display","none");
									$("#LOANNUMBER").parent().parent().css("display","none");
									$("#LoanOriginationDate").parent().parent().css("display","none");
									$("#LoanMaturityDate").parent().parent().css("display","none");
									$("#DateLoanDefaulted").parent().parent().css("display","none");
									$("#CurePeriodEndDate").parent().parent().css("display","none");
									$("#NOTCURRENTLOAN").parent().parent().css("display","none");
									$("#LOANCIRCUMSTANCES").parent().parent().css("display","none");
					 
						
								    $("#useof").parent().css("display","none");
									$("#PLANELECTIONCURRENTPRO").parent().parent().css("display","none");
									$("#PLANAPPEARDESCRIBELINE").parent().parent().css("display","none");
									$("#PLANPURPOSEDESCRIBE").parent().parent().css("display","none");
									$("#PLANDESCRIBELINEREAD").parent().parent().css("display","none");
									
									
									$("#plandocument").parent().css("display","none");
									$("#PLANDOCREQUESTIMPACT").parent().parent().css("display","none");
									$("#PLANDESCWHATOCCURRED").parent().parent().css("display","none");
									$("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display","none");
									$("#PLANSPONSORADDQUE").parent().parent().css("display","none");
									$("#PLANPROPOSESOLUTION").parent().parent().css("display","none");
									$("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display","none");
							
						}
						    else if ($(this).val() == "Describe Line Request")
						{	  
							        $("#useof").parent().css("display","block");
									$("#PLANELECTIONCURRENTPRO").parent().parent().css("display","block");
									$("#PLANAPPEARDESCRIBELINE").parent().parent().css("display","block");
									$("#PLANPURPOSEDESCRIBE").parent().parent().css("display","block");
									$("#PLANDESCRIBELINEREAD").parent().parent().css("display","block"); 
									$('input[name=SONI]').parent().parent().parent().css("display","block");
									$("#soni").parent().css("display","block");
									
										$('input[name=SONI]').change(function () 
								{
								$("input[name=SONI]:checked").each(function ()
							{
								 if ($("input[name=SONI]:checked").val() == "YES") 
                            {
                                $("#Soni").parent().css("display","block");

                             }
								else if ($("input[name=SONI]:checked").val() == "NO") 
                            {
                                $("#Soni").parent().css("display","None");

                             }

                    		
                             });
                            });
						
					                $("#fraud").parent().css("display","none");
									$("#RPSNotifiedDate").parent().parent().css("display","none");
									$("#SCENARIODESCRIPTION").parent().parent().css("display","none");
									$("#ACTIONTAKEN").parent().parent().css("display","none");
									
									
									$("#Resolution").parent().parent().css("display","none");
									$("#description").parent().parent().css("display","none");
									
									
									$("#loan").parent().css("display","none");
									$("#SSN").parent().parent().css("display","none");
									$("#LOANNUMBER").parent().parent().css("display","none");
									$("#LoanOriginationDate").parent().parent().css("display","none");
									$("#LoanMaturityDate").parent().parent().css("display","none");
									$("#DateLoanDefaulted").parent().parent().css("display","none");
									$("#CurePeriodEndDate").parent().parent().css("display","none");
									$("#NOTCURRENTLOAN").parent().parent().css("display","none");
									$("#LOANCIRCUMSTANCES").parent().parent().css("display","none")
									
									$("#plantesting").parent().css("display","none");
									$("#concern").parent().css("display","none");
									 $('input[name=CONCERNTEST]').parent().parent().parent().css("display","none");
									 $('input[name=CONCERNTEST1]').parent().parent().parent().css("display","none");
									$("#OTHERDESCRIBE").parent().parent().css("display","none");
									$("#PLANSPONSORSTEPS").parent().parent().css("display","none");
									$("#PLANDESCOCCURRED").parent().parent().css("display","none");
									$("#PLANADDITIONALQUE").parent().parent().css("display","none");
									$("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display","none");
									$("#PLANPROPOSEDQUES").parent().parent().css("display","none");
									
									$("#plandocument").parent().css("display","none");
									$("#PLANDOCREQUESTIMPACT").parent().parent().css("display","none");
									$("#PLANDESCWHATOCCURRED").parent().parent().css("display","none");
									$("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display","none");
									$("#PLANSPONSORADDQUE").parent().parent().css("display","none");
									$("#PLANPROPOSESOLUTION").parent().parent().css("display","none");
									$("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display","none");
        
						}
						 else if ($(this).val() == "Plan Document Issue Question")
						 {
						            $("#plandocument").parent().css("display","block");
									$("#PLANDOCREQUESTIMPACT").parent().parent().css("display","block");
									$("#PLANDESCWHATOCCURRED").parent().parent().css("display","block");
									$("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display","block");
									$("#PLANSPONSORADDQUE").parent().parent().css("display","block");
									$("#PLANPROPOSESOLUTION").parent().parent().css("display","block");
									$("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display","block");
									$('input[name=SONI]').parent().parent().parent().css("display","block");
									$("#soni").parent().css("display","block");
									
										$('input[name=SONI]').change(function () 
								{
								$("input[name=SONI]:checked").each(function ()
							{
								 if ($("input[name=SONI]:checked").val() == "YES") 
                            {
                                $("#Soni").parent().css("display","block");

                             }
								else if ($("input[name=SONI]:checked").val() == "NO") 
                            {
                                $("#Soni").parent().css("display","None");

                             }

                    		
                             });
                            });
							
							       $("#fraud").parent().css("display","none");
								$("#RPSNotifiedDate").parent().parent().css("display","none");
								$("#SCENARIODESCRIPTION").parent().parent().css("display","none");
								$("#ACTIONTAKEN").parent().parent().css("display","none");
								
								
								$("#Resolution").parent().parent().css("display","none");
								$("#description").parent().parent().css("display","none");
								
								
								$("#loan").parent().css("display","none");
								$("#SSN").parent().parent().css("display","none");
								$("#LOANNUMBER").parent().parent().css("display","none");
								$("#LoanOriginationDate").parent().parent().css("display","none");
								$("#LoanMaturityDate").parent().parent().css("display","none");
								$("#DateLoanDefaulted").parent().parent().css("display","none");
								$("#CurePeriodEndDate").parent().parent().css("display","none");
								$("#NOTCURRENTLOAN").parent().parent().css("display","none");
								$("#LOANCIRCUMSTANCES").parent().parent().css("display","none");
								
								
								$("#plantesting").parent().css("display","none");
								$("#concern").parent().css("display","none");
								 $('input[name=CONCERNTEST]').parent().parent().parent().css("display","none");
								 $('input[name=CONCERNTEST1]').parent().parent().parent().css("display","none");
								$("#OTHERDESCRIBE").parent().parent().css("display","none");
								$("#PLANSPONSORSTEPS").parent().parent().css("display","none");
								$("#PLANDESCOCCURRED").parent().parent().css("display","none");
								$("#PLANADDITIONALQUE").parent().parent().css("display","none");
								$("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display","none");
								$("#PLANPROPOSEDQUES").parent().parent().css("display","none");



								$("#useof").parent().css("display","none");
								$("#PLANELECTIONCURRENTPRO").parent().parent().css("display","none");
								$("#PLANAPPEARDESCRIBELINE").parent().parent().css("display","none");
								$("#PLANPURPOSEDESCRIBE").parent().parent().css("display","none");
								$("#PLANDESCRIBELINEREAD").parent().parent().css("display","none"); 
							}


				   else if ($(this).val() == "Account Access Privacy" || $(this).val() == "Adjustments" || $(this).val() == "Bankruptcy, Levy, Garnishments, & Court Orders" || $(this).val() == "Compliance Stop" || $(this).val() == "Contribution" || $(this).val() == "Correspondence Review" ||  $(this).val() == "Exception Request" || $(this).val() == "Distributions" || $(this).val() == "Other" || $(this).val() == "Plan Install or Conversion" || $(this).val() == "Plan Termination" || $(this).val() == "Plan Participant Maint" || $(this).val() == "Process Improvement" || $(this).val() == "Tax Withholding or Tax Reporting")
						 {
                             $('input[name=SONI]').parent().parent().parent().css("display","block");
							 $("#description").parent().parent().css("display","block");
				   
				   
				              $("#Resolution").parent().parent().css("display","block");
							  
							  
										$('input[name=SONI]').change(function () 
								{
								$("input[name=SONI]:checked").each(function ()
							{
								 if ($("input[name=SONI]:checked").val() == "YES") 
                            {
                                $("#Soni").parent().css("display","block");

                             }
								else if ($("input[name=SONI]:checked").val() == "NO") 
                            {
                                $("#Soni").parent().css("display","None");

                             }

                    		
                             });
                            });
							
									$("#fraud").parent().css("display","none");
									$("#RPSNotifiedDate").parent().parent().css("display","none");
									$("#SCENARIODESCRIPTION").parent().parent().css("display","none");
									$("#ACTIONTAKEN").parent().parent().css("display","none");
									
									
									
									
									
									$("#loan").parent().css("display","none");
									$("#SSN").parent().parent().css("display","none");
									$("#LOANNUMBER").parent().parent().css("display","none");
									$("#LoanOriginationDate").parent().parent().css("display","none");
									$("#LoanMaturityDate").parent().parent().css("display","none");
									$("#DateLoanDefaulted").parent().parent().css("display","none");
									$("#CurePeriodEndDate").parent().parent().css("display","none");
									$("#NOTCURRENTLOAN").parent().parent().css("display","none");
									$("#LOANCIRCUMSTANCES").parent().parent().css("display","none");
									
									
									$("#plantesting").parent().css("display","none");
									$("#concern").parent().css("display","none");
									 $('input[name=CONCERNTEST]').parent().parent().parent().css("display","none");
									  $('input[name=CONCERNTEST1]').parent().parent().parent().css("display","none");
									$("#OTHERDESCRIBE").parent().parent().css("display","none");
									$("#PLANSPONSORSTEPS").parent().parent().css("display","none");
									$("#PLANDESCOCCURRED").parent().parent().css("display","none");
									$("#PLANADDITIONALQUE").parent().parent().css("display","none");
									$("#PLANPROPOSESOLUTIONTESTING").parent().parent().css("display","none");
									$("#PLANPROPOSEDQUES").parent().parent().css("display","none");



									$("#useof").parent().css("display","none");
									$("#PLANELECTIONCURRENTPRO").parent().parent().css("display","none");
									$("#PLANAPPEARDESCRIBELINE").parent().parent().css("display","none");
									$("#PLANPURPOSEDESCRIBE").parent().parent().css("display","none");
									$("#PLANDESCRIBELINEREAD").parent().parent().css("display","none");
									
									
									$("#plandocument").parent().css("display","none");
									$("#PLANDOCREQUESTIMPACT").parent().parent().css("display","none");
									$("#PLANDESCWHATOCCURRED").parent().parent().css("display","none");
									$("#PLANDESCSTEPSTOCORRECT").parent().parent().css("display","none");
									$("#PLANSPONSORADDQUE").parent().parent().css("display","none");
									$("#PLANPROPOSESOLUTION").parent().parent().css("display","none");
									$("#PLANSPONSORADDQUEPROPOSAL").parent().parent().css("display","none");
									
						}


			});												
		});	
	}

/*-----------------------------------------------------Participant Check Stop Payment/Cancellation--------------------------------------------------------*/

				if((document.URL).includes("participant-check-stop-payment-cancellation")){
					
					$("#STOPCANCELHid").change(function(e) {
        $(":checkbox").click(function(e) {
    $(":checkbox").prop('checked', false)
    $(e.target).prop('checked', true);
});
});
				
              $('select[name=site]').change(function () 
		{
            $("select[name=site] option:selected").each(function ()
        	{
                if ($(this).val() == "IRV") 
				{   
				  alert('You selected IRV. Is that correct?');
				  
				 }
				 else if ($(this).val() == "SNO")
				 {   
				  alert('You selected SNO. Is that correct?');
				  
				 }
				  else if ($(this).val() == "IND")
				 {   
				  alert('You selected IND. Is that correct?');
				  
				 }
				  else if ($(this).val() == "HRO")
				 {   
				  alert('You selected HRO. Is that correct?');
				  
				 }
			});
			
		  });
	}
	
/*-------------------------------------------Request for PSW Research----------------------------------------------------------------------------------------*/

			if((document.URL).includes("request-for-psw-research")){
			
			$("#worktypes").prop( "disabled", true );
			$('#worktypes').prop('value' , 'PSW Research');
			}


/*=--------------------------------------------------------------Schedule Adjustment Request Form--------------------------------------------------------------------------------------------*/

		if((document.URL).includes("rp-schedule-adjustment-form")){
		
		$("#start1").prop( "disabled", true );
				$("#end1").prop( "disabled", true );
		
        $('input[name=flex2]').parent().parent().parent().css("display","none");
			$("#type2").parent().parent().css("display","none");
        	$("#flex2").parent().css("display","none");
        	$("#start2").parent().parent().css("display","none");
        	$("#end2").parent().parent().css("display","none");
        	$("#montxt2").parent().css("display","none");
			 $('input[name=montxt2]').parent().parent().parent().css("display","none");
			 $("#addl2").parent().parent().css("display","none");
			  $("#more2").parent().css("display","none");
			 $('input[name=more2]').parent().parent().parent().css("display","none");
			 $("#amt2").parent().css("display","none");
        	$("#hrs2").parent().parent().css("display","none");
        	$("#hr2").parent().css("display","none");
        	$("#mins2").parent().parent().css("display","none");
        	$("#mi2").parent().css("display","none");
			
			$("#start2").prop( "disabled", true );
				$("#end2").prop( "disabled", true );
			 
			 $('input[name=flex3]').parent().parent().parent().css("display","none");
			$("#type3").parent().parent().css("display","none");
        	$("#flex3").parent().css("display","none");
        	$("#start3").parent().parent().css("display","none");
        	$("#end3").parent().parent().css("display","none");
        	$("#montxt3").parent().css("display","none");
			 $('input[name=montxt3]').parent().parent().parent().css("display","none");
			 $("#addl3").parent().parent().css("display","none");
			  $("#more3").parent().css("display","none");
			 $('input[name=more3]').parent().parent().parent().css("display","none");
			 $("#amt3").parent().css("display","none");
        	$("#hrs3").parent().parent().css("display","none");
        	$("#hr3").parent().css("display","none");
        	$("#mins3").parent().parent().css("display","none");
        	$("#mi3").parent().css("display","none");
			
			$("#start3").prop( "disabled", true );
				$("#end3").prop( "disabled", true );
			 
			 $('input[name=flex4]').parent().parent().parent().css("display","none");
			$("#type4").parent().parent().css("display","none");
        	$("#flex4").parent().css("display","none");
        	$("#start4").parent().parent().css("display","none");
        	$("#end4").parent().parent().css("display","none");
        	$("#montxt4").parent().css("display","none");
			 $('input[name=montxt4]').parent().parent().parent().css("display","none");
			 $("#addl4").parent().parent().css("display","none");
			 $("#amt4").parent().css("display","none");
        	$("#hrs4").parent().parent().css("display","none");
        	$("#hr4").parent().css("display","none");
        	$("#mins4").parent().parent().css("display","none");
        	$("#mi4").parent().css("display","none");
			
			$("#start4").prop( "disabled", true );
				$("#end4").prop( "disabled", true );
			
			$("#Sep7").parent().css("display","none");
			$("#Sep8").parent().css("display","none");
			$("#Sep9").parent().css("display","none");
			  
			 
			 
			             
						 
						 $('input[name=flex1]').change(function () 
								{
								$("input[name=flex1]:checked").each(function ()
							{
								 if ($("input[name=flex1]:checked").val() == "YES") 
                            {
                                $("#start1").prop( "disabled", true );
								$("#end1").prop( "disabled", true );
                             }
								else if ($("input[name=flex1]:checked").val() == "NO") 
                            {
                                $("#start1").prop( "disabled", false );
								$("#end1").prop( "disabled", false );

                             }
							 

                    		
                             });
                            });
							
							$('input[name=more1]').change(function () 
								{
								$("input[name=more1]:checked").each(function ()
							{
								 if ($("input[name=more1]:checked").val() == "YES") 
                            {
                                $('input[name=flex2]').parent().parent().parent().css("display","block");
								$("#type2").parent().parent().css("display","block");
								$("#flex2").parent().css("display","block");
								$("#start2").parent().parent().css("display","block");
								$("#end2").parent().parent().css("display","block");
								$("#montxt2").parent().css("display","block");
								 $('input[name=montxt2]').parent().parent().parent().css("display","block");
								 $("#addl2").parent().parent().css("display","block");
								 $("#more2").parent().css("display","block");
								 $('input[name=more2]').parent().parent().parent().css("display","block");
								 
									$("#amt2").parent().css("display","block");
									$("#hrs2").parent().parent().css("display","block");
									$("#hr2").parent().css("display","block");
									$("#mins2").parent().parent().css("display","block");
									$("#mi2").parent().css("display","block");
									
									$("#Sep7").parent().css("display","block");
								 
								 $('input[name=flex2]').change(function () 
								{
								$("input[name=flex2]:checked").each(function ()
							{
								 if ($("input[name=flex2]:checked").val() == "flex2y") 
                            {
                                $("#start2").prop( "disabled", true );
								$("#end2").prop( "disabled", true );
                             }
								else if ($("input[name=flex2]:checked").val() == "flex2n") 
                            {
                                $("#start2").prop( "disabled", false );
								$("#end2").prop( "disabled", false );

                             }

                    		
                             });
                            });

        	
								 
								 
                             }
								else if ($("input[name=more1]:checked").val() == "NO") 
                            {
                                $('input[name=flex2]').parent().parent().parent().css("display","none");
			                    $("#type2").parent().parent().css("display","none");
								$("#flex2").parent().css("display","none");
								$("#start2").parent().parent().css("display","none");
								$("#end2").parent().parent().css("display","none");
								$("#montxt2").parent().css("display","none");
								 $('input[name=montxt2]').parent().parent().parent().css("display","none");
								 $("#addl2").parent().parent().css("display","none");
								  $("#more2").parent().css("display","none");
								 $('input[name=more2]').parent().parent().parent().css("display","none");
								 
								 $("#amt2").parent().css("display","none");
								$("#hrs2").parent().parent().css("display","none");
								$("#hr2").parent().css("display","none");
								$("#mins2").parent().parent().css("display","none");
								$("#mi2").parent().css("display","none");
								
								$("#Sep8").parent().css("display","none");
								$("#Sep9").parent().css("display","none");
								 
								 
			 

                             }
							 

                    		
                             });
                            });
							
							$('input[name=more2]').change(function () 
								{
								$("input[name=more2]:checked").each(function ()
							{
								 if ($("input[name=more2]:checked").val() == "YES") 
                            {
                                $('input[name=flex3]').parent().parent().parent().css("display","block");
								$("#type3").parent().parent().css("display","block");
								$("#flex3").parent().css("display","block");
								$("#start3").parent().parent().css("display","block");
								$("#end3").parent().parent().css("display","block");
								$("#montxt3").parent().css("display","block");
								 $('input[name=montxt3]').parent().parent().parent().css("display","block");
								 $("#addl3").parent().parent().css("display","block");
								 $("#more3").parent().css("display","block");
								 $('input[name=more3]').parent().parent().parent().css("display","block");
								 
								 $("#amt3").parent().css("display","block");
								$("#hrs3").parent().parent().css("display","block");
								$("#hr3").parent().css("display","block");
								$("#mins3").parent().parent().css("display","block");
								$("#mi3").parent().css("display","block");
								
								$("#Sep8").parent().css("display","block");
								
								 
								 $('input[name=flex3]').change(function () 
								{
								$("input[name=flex3]:checked").each(function ()
							{
								 if ($("input[name=flex3]:checked").val() == "flex3y") 
                            {
                                $("#start3").prop( "disabled", true );
								$("#end3").prop( "disabled", true );
                             }
								else if ($("input[name=flex3]:checked").val() == "flex3n") 
                            {
                                $("#start3").prop( "disabled", false );
								$("#end3").prop( "disabled", false );

                             }

                    		
                             });
                            });

        	
								 
								 
                             }
								else if ($("input[name=more2]:checked").val() == "NO") 
                            {
                                $('input[name=flex3]').parent().parent().parent().css("display","none");
			                    $("#type3").parent().parent().css("display","none");
								$("#flex3").parent().css("display","none");
								$("#start3").parent().parent().css("display","none");
								$("#end3").parent().parent().css("display","none");
								$("#montxt3").parent().css("display","none");
								 $('input[name=montxt3]').parent().parent().parent().css("display","none");
								 $("#addl3").parent().parent().css("display","none");
								  $("#more3").parent().css("display","none");
								 $('input[name=more3]').parent().parent().parent().css("display","none");
								 
								 $("#amt3").parent().css("display","none");
								$("#hrs3").parent().parent().css("display","none");
								$("#hr3").parent().css("display","none");
								$("#mins3").parent().parent().css("display","none");
								$("#mi3").parent().css("display","none");
								
								$("#Sep7").parent().css("display","none");
								$("#Sep9").parent().css("display","none");
			 

                             }
							 

                    		
                             });
                            });
							
							
							$('input[name=more3]').change(function () 
								{
								$("input[name=more3]:checked").each(function ()
							{
								 if ($("input[name=more3]:checked").val() == "YES") 
                            {
                                $('input[name=flex4]').parent().parent().parent().css("display","block");
								$("#type4").parent().parent().css("display","block");
								$("#flex4").parent().css("display","block");
								$("#start4").parent().parent().css("display","block");
								$("#end4").parent().parent().css("display","block");
								$("#montxt4").parent().css("display","block");
								 $('input[name=montxt4]').parent().parent().parent().css("display","block");
								 $("#addl4").parent().parent().css("display","block");
								 
								  $("#amt4").parent().css("display","block");
								$("#hrs4").parent().parent().css("display","block");
								$("#hr4").parent().css("display","block");
								$("#mins4").parent().parent().css("display","block");
								$("#mi4").parent().css("display","block");
								
								$("#Sep9").parent().css("display","block");
								 
								 
								 $('input[name=flex4]').change(function () 
								{
								$("input[name=flex4]:checked").each(function ()
							{
								 if ($("input[name=flex4]:checked").val() == "flex4y") 
                            {
                                $("#start4").prop( "disabled", true );
								$("#end4").prop( "disabled", true );
                             }
								else if ($("input[name=flex4]:checked").val() == "flex4n") 
                            {
                                $("#start4").prop( "disabled", false );
								$("#end4").prop( "disabled", false );

                             }

                    		
                             });
                            });

        	
								 
								 
                             }
								else if ($("input[name=more3]:checked").val() == "NO") 
                            {
                                $('input[name=flex4]').parent().parent().parent().css("display","none");
			                    $("#type4").parent().parent().css("display","none");
								$("#flex4").parent().css("display","none");
								$("#start4").parent().parent().css("display","none");
								$("#end4").parent().parent().css("display","none");
								$("#montxt4").parent().css("display","none");
								 $('input[name=montxt4]').parent().parent().parent().css("display","none");
								 $("#addl4").parent().parent().css("display","none");
								 
								  $("#amt4").parent().css("display","none");
									$("#hrs4").parent().parent().css("display","none");
									$("#hr4").parent().css("display","none");
									$("#mins4").parent().parent().css("display","none");
									$("#mi4").parent().css("display","none");
									
									$("#Sep7").parent().css("display","none");
									$("#Sep8").parent().css("display","none");
								  
			 

							}
							 


                             });
                            });
		}

/*-----------------------------------------------------------RPS Announcement Communication Request Form-----------------------------------------*/
 
				if((document.URL).includes("rps-announcement-communication-request-form")){
				
			 $("#site").parent().css("display","none");
			 $('input[name=site1]').parent().parent().parent().css("display","none");
			 $("#Other1").parent().parent().css("display","none");
			$("#txtListContactInitials").parent().parent().css("display","none");
			  $("#txtnonCGEmailAddress").parent().parent().css("display","none"); 
			  $("#txtAnotherDepartment").parent().parent().css("display","none");
				
				$("#npa").parent().css("display","none");
                $("#newOpp").parent().css("display","none");
				$("#txtnewOpportunityTitle").parent().parent().css("display","none");
				$('input[name=newOpportunityIndividualSiteSection]').parent().parent().parent().css("display","none");
				$("#newOpportunityNonRPSAssociates1").parent().css("display","none");
				$('input[name=newOpportunityNonRPSAssociates]').parent().parent().parent().css("display","none");
				$("#hri").parent().parent().css("display","none");
				$("#newOpportunityInternship1").parent().css("display","none");
				$('input[name=newOpportunityInternship]').parent().parent().parent().css("display","none");
				$("#txtNewOpportunityInternshipDuration").parent().parent().css("display","none");
				$("#intern").parent().css("display","none");
				$("#rps").parent().css("display","none");
	            $("#txtSkillsAndCompetencies").parent().parent().css("display","none");
				$("#txtRoleDescription").parent().parent().css("display","none");
				$("#txtDeadline").parent().parent().css("display","none");
				$("#txtContactInitials").parent().parent().css("display","none");
				$("#relaviteComments").parent().parent().css("display","none");
				
				
				$("#filled").parent().css("display","none");
				$("#txtFilledOpportunityTitle").parent().parent().css("display","none");
				$("#txtFilledOpportunityEffectiveDate").parent().parent().css("display","none");
				$("#txtFilledOpportunityAssociateInitials").parent().parent().css("display","none");
				$("#filledOpportunityScenarios1").parent().css("display","none");
				$('input[name=filledOpportunityScenarios]').parent().parent().parent().css("display","none");
				$("#bio").parent().css("display","none");
				$("#txtFilledOpportunityRelevantInformation").parent().parent().css("display","none");
				$("#biot").parent().css("display","none");
				$("#pit").parent().css("display","none");
				$("#txtCompleteBIO").parent().parent().css("display","none");
				$("#sample").parent().css("display","none");
				
				
				$("#oppo").parent().css("display","none");
				$("#txtOpportunityUpdateTitle").parent().parent().css("display","none");
				$("#txtOpportunityUpdateEffectiveDate").parent().parent().css("display","none");
				$("#txtOpportunityUpdateAssociateInitials").parent().parent().css("display","none");
				$("#opportunityUpdatePreviousAnnouncement1").parent().css("display","none");
				$('input[name=opportunityUpdatePreviousAnnouncement]').parent().parent().parent().css("display","none");
				$("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display","none");
				$("#txtOpportunityUpdateRelevantInformation").parent().parent().css("display","none");
                $("#oppo_label").parent().css("display","none");
				 
				 $("#Sep1").parent().css("display","none");
				 $("#Sep2").parent().css("display","none");
				 $("#Sep3").parent().css("display","none");
				 $("#Sep4").parent().css("display","none");
				
				
				 $('input[name=communicationDL1]').change(function () 
		{
            $("input[name=communicationDL1]").each(function ()
        	{
                if ($("input[name=communicationDL1]:checked").val() == "Other") 
				{

                    $("#site").parent().css("display","block");
					$('input[name=site1]').parent().parent().parent().css("display","block");
			         $("#Other1").parent().parent().css("display","block");
                   


                }

                else if ($("input[name=communicationDL1]:checked").val() == undefined)
                    {
                         $("#site").parent().css("display","none");
					     $('input[name=site1]').parent().parent().parent().css("display","none");
			             $("#Other1").parent().parent().css("display","none");

                     }

                });
            });
			
			
			
			    $('input[name=communicationDL]').change(function () 
		{
            $("input[name=communicationDL]").each(function ()
        	{
               if ($("input[name=communicationDL]:checked").val() == "RP Services Implementation Associates" || $("input[name=communicationDL]:checked").val() == "RP Services Operations Associates" || $("input[name=communicationDL]:checked").val() == "ALL RPS PP Includes all of  PlanPremier Dedicated Services" || $("input[name=communicationDL]:checked").val() == "RP Services CS Associates" ) 
				{

                    $("#site").parent().css("display","block");
					$('input[name=site1]').parent().parent().parent().css("display","block");
			        
                   


                }

                else if ($("input[name=communicationDL]:checked").val() == undefined)
                    {
                         $("#site").parent().css("display","none");
					     $('input[name=site1]').parent().parent().parent().css("display","none");
			             
                     }

                });
            });
			
			
			
			   $('input[name=outsideRPS]').change(function () 
		{
            $("input[name=outsideRPS]").each(function ()
        	{
                if ($("input[name=outsideRPS]:checked").val() == "YES") 
				{

                   
					$("#txtListContactInitials").parent().parent().css("display","block");
					 $("#txtnonCGEmailAddress").parent().parent().css("display","block"); 
					
                   


                }

                else if ($("input[name=outsideRPS]:checked").val() == "NO")
                    {
                         
						 $("#txtListContactInitials").parent().parent().css("display","none");
						  $("#txtnonCGEmailAddress").parent().parent().css("display","none"); 
						  

                     }

                });
            });
			
			
			      
			   $('input[name=anotherDepartmentInitials]').change(function () 
		{
            $("input[name=anotherDepartmentInitials]").each(function ()
        	{
                if ($("input[name=anotherDepartmentInitials]:checked").val() == "YES") 
				{

                   
			       $("#txtAnotherDepartment").parent().parent().css("display","block");


                }

                else if ($("input[name=anotherDepartmentInitials]:checked").val() == "NO")
                    {
                        
			             $("#txtAnotherDepartment").parent().parent().css("display","none");

                     }

                });
            });
			 
			 
			 
			  $('input[name=TypeOfAnnouncement]').change(function () 
		{
            $("input[name=TypeOfAnnouncement]").each(function ()
        	{
                if ($("input[name=TypeOfAnnouncement]:checked").val() == "New Opportunity") 
				{

                    $("#npa").parent().css("display","block");
				    $("#txtnewOpportunityTitle").parent().parent().css("display","block");
				    $("#newOpp").parent().css("display","block");
					$('input[name=newOpportunityIndividualSiteSection]').parent().parent().parent().css("display","block");
					$("#newOpportunityNonRPSAssociates1").parent().css("display","block");
					$('input[name=newOpportunityNonRPSAssociates]').parent().parent().parent().css("display","block");
					 $("#Sep1").parent().css("display","block");
					
					
			  $('input[name=newOpportunityNonRPSAssociates]').change(function () 
		{
            $("input[name=newOpportunityNonRPSAssociates]").each(function ()
        	{
                if ($("input[name=newOpportunityNonRPSAssociates]:checked").val() == "YES") 
				{
                           
				           $("#hri").parent().parent().css("display","block");


                }
			  else if ($("input[name=newOpportunityNonRPSAssociates]:checked").val() == "NO") 
			        {
                         
				         $("#hri").parent().parent().css("display","none"); 

                     }

                });
            });
			   $("#newOpportunityInternship1").parent().css("display","block");
				$('input[name=newOpportunityInternship]').parent().parent().parent().css("display","block");
				
				
				
				$('input[name=newOpportunityInternship]').change(function () 
		{
            $("input[name=newOpportunityInternship]").each(function ()
        	{
                if ($("input[name=newOpportunityInternship]:checked").val() == "YES") 
				{
                        

						$("#txtNewOpportunityInternshipDuration").parent().parent().css("display","block");
						$("#intern").parent().css("display","block");
						$("#rps").parent().css("display","block");
						$("#txtSkillsAndCompetencies").parent().parent().css("display","block");
						$("#txtRoleDescription").parent().parent().css("display","block");
						$("#txtDeadline").parent().parent().css("display","block");
						$("#txtContactInitials").parent().parent().css("display","block");
						$("#relaviteComments").parent().parent().css("display","block")

                }
			  else if ($("input[name=newOpportunityInternship]:checked").val() == "NO") 
			        {
                         

						$("#txtNewOpportunityInternshipDuration").parent().parent().css("display","none");
						$("#intern").parent().css("display","none");
						$("#rps").parent().css("display","block");
						$("#txtSkillsAndCompetencies").parent().parent().css("display","block");
						$("#txtRoleDescription").parent().parent().css("display","block");
						$("#txtDeadline").parent().parent().css("display","block");
						$("#txtContactInitials").parent().parent().css("display","block");
						$("#relaviteComments").parent().parent().css("display","block")


                     }

                });
            });
			    $("#filled").parent().css("display","none");
				$("#txtFilledOpportunityTitle").parent().parent().css("display","none");
				$("#txtFilledOpportunityEffectiveDate").parent().parent().css("display","none");
				$("#txtFilledOpportunityAssociateInitials").parent().parent().css("display","none");
				$("#filledOpportunityScenarios1").parent().css("display","none");
				$('input[name=filledOpportunityScenarios]').parent().parent().parent().css("display","none");
				$("#bio").parent().css("display","none");
				$("#txtFilledOpportunityRelevantInformation").parent().parent().css("display","none");
				$("#biot").parent().css("display","none");
				$("#pit").parent().css("display","none");
				$("#txtCompleteBIO").parent().parent().css("display","none");
				$("#sample").parent().css("display","none");
				
				
				$("#oppo").parent().css("display","none");
				$("#txtOpportunityUpdateTitle").parent().parent().css("display","none");
				$("#txtOpportunityUpdateEffectiveDate").parent().parent().css("display","none");
				$("#txtOpportunityUpdateAssociateInitials").parent().parent().css("display","none");
				$("#opportunityUpdatePreviousAnnouncement1").parent().css("display","none");
				$('input[name=opportunityUpdatePreviousAnnouncement]').parent().parent().parent().css("display","none");
				$("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display","none");
				 $("#txtOpportunityUpdateRelevantInformation").parent().parent().css("display","none");
				  $("#oppo_label").parent().css("display","none");
				  $("#Sep2").parent().css("display","none");
				 $("#Sep3").parent().css("display","none");
				 $("#Sep4").parent().css("display","none");
				
			
			}
		
			
			
			
			
				
				

            
        	
                 else if ($("input[name=TypeOfAnnouncement]:checked").val() == "Filled Opportunity") 
				   {
				        $("#filled").parent().css("display","block");
						$("#txtFilledOpportunityTitle").parent().parent().css("display","block");
						$("#txtFilledOpportunityEffectiveDate").parent().parent().css("display","block");
						$("#txtFilledOpportunityAssociateInitials").parent().parent().css("display","block");
						$("#filledOpportunityScenarios1").parent().css("display","block");
						$('input[name=filledOpportunityScenarios]').parent().parent().parent().css("display","block");
						$("#bio").parent().css("display","block");
				        $("#txtFilledOpportunityRelevantInformation").parent().parent().css("display","block");
						$("#Sep2").parent().css("display","block");
						$("#Sep3").parent().css("display","block");
						
								
			  $('input[name=filledOpportunityScenarios]').change(function () 
		{
            $("input[name=filledOpportunityScenarios]").each(function ()
        	{
                if ($("input[name=filledOpportunityScenarios]:checked").val() == "YES") 
				{
                          $("#biot").parent().css("display","block");
				     $("#pit").parent().css("display","block");
				     $("#txtCompleteBIO").parent().parent().css("display","block");
				     $("#sample").parent().css("display","block");
					 $("#Sep3").parent().css("display","block");

                }
			  else if ($("input[name=filledOpportunityScenarios]:checked").val() == "NO") 
			        {
                        $("#biot").parent().css("display","none");
						$("#pit").parent().css("display","none");
						$("#txtCompleteBIO").parent().parent().css("display","none");
						$("#sample").parent().css("display","none");
						$("#Sep3").parent().css("display","none");

                     }

                });
            });
			     $("#npa").parent().css("display","none");
                 $("#newOpp").parent().css("display","none");
				$("#txtnewOpportunityTitle").parent().parent().css("display","none");
				$('input[name=newOpportunityIndividualSiteSection]').parent().parent().parent().css("display","none");
				$("#newOpportunityNonRPSAssociates1").parent().css("display","none");
				$('input[name=newOpportunityNonRPSAssociates]').parent().parent().parent().css("display","none");
				$("#hri").parent().parent().css("display","none");
				$("#newOpportunityInternship1").parent().css("display","none");
				$('input[name=newOpportunityInternship]').parent().parent().parent().css("display","none");
				$("#txtNewOpportunityInternshipDuration").parent().parent().css("display","none");
				$("#intern").parent().css("display","none");
				$("#rps").parent().css("display","none");
	            $("#txtSkillsAndCompetencies").parent().parent().css("display","none");
				$("#txtRoleDescription").parent().parent().css("display","none");
				$("#txtDeadline").parent().parent().css("display","none");
				$("#txtContactInitials").parent().parent().css("display","none");
				$("#relaviteComments").parent().parent().css("display","none");
				
				$("#oppo").parent().css("display","none");
				$("#txtOpportunityUpdateTitle").parent().parent().css("display","none");
				$("#txtOpportunityUpdateEffectiveDate").parent().parent().css("display","none");
				$("#txtOpportunityUpdateAssociateInitials").parent().parent().css("display","none");
				$("#opportunityUpdatePreviousAnnouncement1").parent().css("display","none");
				$('input[name=opportunityUpdatePreviousAnnouncement]').parent().parent().parent().css("display","none");
				$("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display","none");
				 $("#txtOpportunityUpdateRelevantInformation").parent().parent().css("display","none");
				  $("#oppo_label").parent().css("display","none");
				 $("#Sep1").parent().css("display","none");
				 $("#Sep3").parent().css("display","none");
				 $("#Sep4").parent().css("display","none");
				
				
				
			    
			}
			
			 else if ($("input[name=TypeOfAnnouncement]:checked").val() == "Opportunity Updates ")
			  {
			    $("#oppo").parent().css("display","block");
				$("#txtOpportunityUpdateTitle").parent().parent().css("display","block");
				$("#txtOpportunityUpdateEffectiveDate").parent().parent().css("display","block");
				$("#txtOpportunityUpdateAssociateInitials").parent().parent().css("display","block");
				$("#opportunityUpdatePreviousAnnouncement1").parent().css("display","block");
				$('input[name=opportunityUpdatePreviousAnnouncement]').parent().parent().parent().css("display","block");
				
				
				$("#txtOpportunityUpdateRelevantInformation").parent().parent().css("display","block");
				 $("#oppo_label").parent().css("display","block");
				$("#Sep4").parent().css("display","block");
				
				
				
				$('input[name=opportunityUpdatePreviousAnnouncement]').change(function () 
		{
            $("input[name=opportunityUpdatePreviousAnnouncement]").each(function ()
        	{
                if ($("input[name=opportunityUpdatePreviousAnnouncement]:checked").val() == "YES") 
				{
                       
				       $("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display","block");  

                }
			  else if ($("input[name=opportunityUpdatePreviousAnnouncement]:checked").val() == "NO") 
			        {
                        
				        $("#txtOpportunityUpdateAnnouncementMonthYear").parent().parent().css("display","none");

                     }

                });
            });

			  $("#npa").parent().css("display","none");
                  $("#newOpp").parent().css("display","none");
				$("#txtnewOpportunityTitle").parent().parent().css("display","none");
				$('input[name=newOpportunityIndividualSiteSection]').parent().parent().parent().css("display","none");
				$("#newOpportunityNonRPSAssociates1").parent().css("display","none");
				$('input[name=newOpportunityNonRPSAssociates]').parent().parent().parent().css("display","none");
				$("#hri").parent().parent().css("display","none");
				$("#newOpportunityInternship1").parent().css("display","none");
				$('input[name=newOpportunityInternship]').parent().parent().parent().css("display","none");
				$("#txtNewOpportunityInternshipDuration").parent().parent().css("display","none");
				$("#intern").parent().css("display","none");
				$("#rps").parent().css("display","none");
	            $("#txtSkillsAndCompetencies").parent().parent().css("display","none");
				$("#txtRoleDescription").parent().parent().css("display","none");
				$("#txtDeadline").parent().parent().css("display","none");
				$("#txtContactInitials").parent().parent().css("display","none");
				$("#relaviteComments").parent().parent().css("display","none");
				
				
				$("#filled").parent().css("display","none");
				$("#txtFilledOpportunityTitle").parent().parent().css("display","none");
				$("#txtFilledOpportunityEffectiveDate").parent().parent().css("display","none");
				$("#txtFilledOpportunityAssociateInitials").parent().parent().css("display","none");
				$("#filledOpportunityScenarios1").parent().css("display","none");
				$('input[name=filledOpportunityScenarios]').parent().parent().parent().css("display","none");
				$("#bio").parent().css("display","none");
				$("#txtFilledOpportunityRelevantInformation").parent().parent().css("display","none");
				$("#biot").parent().css("display","none");
				$("#pit").parent().css("display","none");
				$("#txtCompleteBIO").parent().parent().css("display","none");
				$("#sample").parent().css("display","none");
				
				 $("#Sep1").parent().css("display","none");
				  $("#Sep2").parent().css("display","none");
				   $("#Sep3").parent().css("display","none");
				 

                
            }
			
	     });
    });

}


/*----------------------------------------RPS SYSTEM ENHANCEMENT - MANAGER BACKLOG SUBMISSION FORM-----------------------------------------*/

			if((document.URL).includes("rps-system-enhancement-manager-backlog-submission-form")){
         
            $("#currentWorkAroundVal").parent().parent().css("display","none");
			 $("#please").parent().css("display","none");
			  $("#isReqTimeSensitiveVal").parent().parent().css("display","none");
			 


				  	$('input[name=currentWorkAround]').change(function () 
		{
            $("input[name=currentWorkAround]").each(function ()
        	{
                if ($("input[name=currentWorkAround]:checked").val() == "No") 
				{
                      $("#currentWorkAroundVal").parent().parent().css("display","none");  

                }
			  else if ($("input[name=currentWorkAround]:checked").val() == "Yes") 
			        {
                         $("#currentWorkAroundVal").parent().parent().css("display","block");
                     }

                });
            });
			
			$('input[name=Requesttimesensitive]').change(function () 
		{
            $("input[name=Requesttimesensitive]").each(function ()
        	{
                if ($("input[name=Requesttimesensitive]:checked").val() == "No") 
				{
                      $("#please").parent().css("display","none");
			  $("#isReqTimeSensitiveVal").parent().parent().css("display","none");

                }
			  else if ($("input[name=Requesttimesensitive]:checked").val() == "Yes") 
			        {
                        $("#please").parent().css("display","block");
			  $("#isReqTimeSensitiveVal").parent().parent().css("display","block");
                     }

                });
            });
			
	}

			
/*----------------------------------------------------TESTING OR SONI CONTENT RESOURCE REQUEST------------------------------------------------------*/

							if((document.URL).includes("testing-or-soni-content-resource-request")){
			
			               $('input[name=soni]').change(function () 
								{
								$("input[name=soni]:checked").each(function ()
							{
								 if ($("input[name=soni]:checked").val() == "no") 
                            {
                                $("#content").prop( "disabled", true );
								$("#soniarticle").prop( "disabled", true );
								 $("#numppl").prop( "disabled", true );
								$("#blocks").prop( "disabled", true );
								 $("#sonihrs").prop( "disabled", true );
								$("#specdates2").prop( "disabled", true );
								 $("#usetest").prop( "disabled", true );
								$("#soniskill").prop( "disabled", true );
								$("#soniother").prop( "disabled", true );
                             }
								else if ($("input[name=soni]:checked").val() == "yes") 
                            {
                                $("#content").prop( "disabled", false );
								$("#soniarticle").prop( "disabled", false );
								 $("#numppl").prop( "disabled", false );
								$("#blocks").prop( "disabled", false );
								 $("#sonihrs").prop( "disabled", false );
								$("#specdates2").prop( "disabled", false );
								 $("#usetest").prop( "disabled", false );
								$("#soniskill").prop( "disabled", false );
								$("#soniother").prop( "disabled", false );


                             }
							 

                    		
                             });
                            });
		}
							
/*-----------------------------------------------------------LOAN RE-AMORTIZATION REQUEST--------------------------------------------------------*/

		if((document.URL).includes("loan-re-amortization-request")){
			
		
		$('input[name=nochg]').change(function () 
         {
             $("input[name=nochg]").each(function ()
            {
                  if ($("input[name=nochg]:checked").val() == "No Change") 
                { 
                     $("#matdate").removeAttr('type');
                     $('#matdate').attr('type', 'text')                      
                     $("#matdate").prop( "value", "No change" );
                    }
               if ($("input[name=nochg]:checked").val() == undefined) 
               {
                  $("#matdate").removeAttr('type');
                     $('#matdate').attr('type', 'date')                      
                     $("#matdate").prop( "value", "" ); 
               }
                 });

                 });
				 
		
				 

		
      $("#interest-rate").parent().parent().css("display","none");
				
				
				$('input[name=samerate]').change(function () 
		{
            $("input[name=samerate]").each(function ()
        	{
                if ($("input[name=samerate]:checked").val() == "No") 
				{
                      $("#interest-rate").parent().parent().css("display","block");

                }
			  else if ($("input[name=samerate]:checked").val() == "Yes") 
			        {
                      $("#interest-rate").parent().parent().css("display","none");
                     }

                });
            });
	}
			
/*------------------------------------------------------New Plan Maintenance Form------------------------------------------------------------------*/

		if((document.URL).includes("plan-maint-form")){

		$("#addMoneyType").parent().parent().css("display","none");
		  $("#removeMoneyType").parent().parent().css("display","none");
		  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
		 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
		 $("#enrollmentBookReorder").parent().parent().css("display","none");
		 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
		 $("#IC").parent().css("display","none");
		 
		 $("#enrollment").parent().css("display","none");
		 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
		 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
		 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
		 $("#shipto").parent().css("display","none");
		 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
		  $("#enrollBooksShipAttn").parent().parent().css("display","none");
		  $("#enrollBooksShipStreet").parent().parent().css("display","none");
		  $("#enrollBooksShipCity").parent().parent().css("display","none");
		 $("#enrollBooksShipState").parent().parent().css("display","none");
		 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
		  $("#enrollBooksNotes").parent().parent().css("display","none");
		  $("#delivery").parent().css("display","none");
		  
		  
		  $("#vestingSchedule").parent().parent().css("display","none");
		  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
		  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
		   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
		   
		   $("#addFunds").parent().parent().css("display","none");
		   $("#removeFunds").parent().parent().css("display","none");
		   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
		    $("#fundChangesChangeNotice").parent().parent().css("display","none");
			$("#fundChangesNotes").parent().parent().css("display","none");
			
			$("#loanReqTypes").parent().parent().css("display","none");
			$("#loansEffectiveDate").parent().parent().css("display","none");
			$("#loansGenPurposeYrs").parent().parent().css("display","none");
			$("#loansPayroleFrequency").parent().parent().css("display","none");
			$("#loansMortageYears").parent().parent().css("display","none");
			$("#loanMinAmount").parent().parent().css("display","none");
			$("#loanMaxAmount").parent().parent().css("display","none");
			$("#loansAllowed").parent().parent().css("display","none");
			$("#loanChangeNoticeReq").parent().parent().css("display","none");
			$("#loanNotes").parent().parent().css("display","none");
			
			
			$("#star").parent().css("display","none");
			$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
			$("#planspon").parent().css("display","none");
			$("#planSponcorName").parent().parent().css("display","none");
			$("#planSponcorPhone").parent().parent().css("display","none");
			$("#planSponcorEmail").parent().parent().css("display","none");
			$("#addcon").parent().css("display","none");
			$("#additionaContactName").parent().parent().css("display","none");
			$("#additionaContactPhone").parent().parent().css("display","none");
			$("#additionaContactEmail").parent().parent().css("display","none");
			$("#pspon").parent().css("display","none");
			$("#planSponsorRemoveName").parent().parent().css("display","none");
			$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
			$("#planContactNotes").parent().parent().css("display","none");
			$("#addfix").parent().css("display","none");
			
		  
		    $("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
			$("#riaServiceProvider").parent().parent().css("display","none");
			$("#riaRepJointName").parent().parent().css("display","none");
			$("#riaRepJointID").parent().parent().css("display","none");
			$("#riaIndividualRepName1").parent().parent().css("display","none");
			$("#riaIndividualRepId1").parent().parent().css("display","none");
			$("#riaIndividualRepName2").parent().parent().css("display","none");
			$("#riaIndividualRepId2").parent().parent().css("display","none");
			$("#star2").parent().css("display","none");
			$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
			$("#riaNotes").parent().parent().css("display","none");
			$("#ria").parent().css("display","none");
			
			
			$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
			$("#tpaFeesLoanFee").parent().parent().css("display","none");
			$("#tpaFeesDistributionFee").parent().parent().css("display","none");
			$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
			$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
			$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
			$("#tpaFeesNotes").parent().parent().css("display","none");	
            $("#rkdfee").parent().css("display","none");

			
			
			$("#star3").parent().css("display","none");
			$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
			$("#star4").parent().css("display","none");
			$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
			$("#closePlanNotes").parent().parent().css("display","none");

			
			$("#fiduciaryServiceLevel").parent().parent().css("display","none");
			$("#rpainfo").parent().css("display","none");
			$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
			$("#fiduciaryServiceNotes").parent().parent().css("display","none");
			$("#sysfee").parent().css("display","none");
			
			
			$("#star5").parent().css("display","none");
			$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
			$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
			$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
			
				
			$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
			$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
			$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
			$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
			$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
			$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
			$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
			$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
			$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
			$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
			$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
			$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
			$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
			$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
			$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
			$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
			$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
			$("#feelevelrecoveryenrol").parent().parent().css("display","none");
			$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
			 
			
			$("#addRemoveAfflAddContact").parent().parent().css("display","none");
            $("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
			 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
			 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
			 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
			 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
			 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
			 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
			 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
			 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
			 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
			 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
			 $("#addRemoveAfflNotes").parent().parent().css("display","none");
			 $("#aff").parent().css("display","none");
			 
			 
			
				$('select[name=requestType]').change(function () 
		 {
            $("select[name=requestType] option:selected").each(function ()
        	{
                if ($(this).val() == "Add/Remove money type") 
				{
					
					  $("#addMoneyType").parent().parent().css("display","block");
					  $("#removeMoneyType").parent().parent().css("display","block");
					  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","block");
					 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","block");
					 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","block");
					 $("#IC").parent().css("display","block");
					 $("#enrollmentBookReorder").parent().parent().css("display","block");
					 
					 
					   $('select[name=enrollmentBookReorder]').change(function () 
		 {
            $("select[name=enrollmentBookReorder] option:selected").each(function ()
        	{
                if ($(this).val() == "YES") 
				{
				    
					
					$("#addRemoveMoneyTypeNotes").parent().parent().css("display","block");
					 $("#IC").parent().css("display","block");
				     $("#enrollment").parent().css("display","block");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","block");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","block");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","block");
					 $("#shipto").parent().css("display","block");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","block");
					  $("#enrollBooksShipAttn").parent().parent().css("display","block");
					  $("#enrollBooksShipStreet").parent().parent().css("display","block");
					  $("#enrollBooksShipCity").parent().parent().css("display","block");
					 $("#enrollBooksShipState").parent().parent().css("display","block");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","block");
					  $("#enrollBooksNotes").parent().parent().css("display","block");
					  $("#delivery").parent().css("display","block");
					  
			     }
				 
				else if ($(this).val() == "NO" || $(this).val() == "No-Please send pdf of revised kit to IC through Genesys")
				  {
				  
				      $("#addRemoveMoneyTypeNotes").parent().parent().css("display","block");
					 $("#IC").parent().css("display","block");
					 $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
								 
					}
					
				});
				
			});
			             
						 
						 $("#enrollment").parent().css("display","none");
							 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
							 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
							 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
							 $("#shipto").parent().css("display","none");
							 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
							  $("#enrollBooksShipAttn").parent().parent().css("display","none");
							  $("#enrollBooksShipStreet").parent().parent().css("display","none");
							  $("#enrollBooksShipCity").parent().parent().css("display","none");
							 $("#enrollBooksShipState").parent().parent().css("display","none");
							 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
							  $("#enrollBooksNotes").parent().parent().css("display","none");
							  $("#delivery").parent().css("display","none");
						
						  $("#vestingSchedule").parent().parent().css("display","none");
						  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
						  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
						   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
						   
						   $("#addFunds").parent().parent().css("display","none");
						   $("#removeFunds").parent().parent().css("display","none");
						   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
							$("#fundChangesChangeNotice").parent().parent().css("display","none");
							$("#fundChangesNotes").parent().parent().css("display","none");
							
							$("#loanReqTypes").parent().parent().css("display","none");
							$("#loansEffectiveDate").parent().parent().css("display","none");
							$("#loansGenPurposeYrs").parent().parent().css("display","none");
							$("#loansPayroleFrequency").parent().parent().css("display","none");
							$("#loansMortageYears").parent().parent().css("display","none");
							$("#loanMinAmount").parent().parent().css("display","none");
							$("#loanMaxAmount").parent().parent().css("display","none");
							$("#loansAllowed").parent().parent().css("display","none");
							$("#loanChangeNoticeReq").parent().parent().css("display","none");
							$("#loanNotes").parent().parent().css("display","none");
							
							
							$("#star").parent().css("display","none");
							$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
							$("#planspon").parent().css("display","none");
							$("#planSponcorName").parent().parent().css("display","none");
							$("#planSponcorPhone").parent().parent().css("display","none");
							$("#planSponcorEmail").parent().parent().css("display","none");
							$("#addcon").parent().css("display","none");
							$("#additionaContactName").parent().parent().css("display","none");
							$("#additionaContactPhone").parent().parent().css("display","none");
							$("#additionaContactEmail").parent().parent().css("display","none");
							$("#pspon").parent().css("display","none");
							$("#planSponsorRemoveName").parent().parent().css("display","none");
							$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
							$("#planContactNotes").parent().parent().css("display","none");
							$("#addfix").parent().css("display","none");
							
						  
							$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
							$("#riaServiceProvider").parent().parent().css("display","none");
							$("#riaRepJointName").parent().parent().css("display","none");
							$("#riaRepJointID").parent().parent().css("display","none");
							$("#riaIndividualRepName1").parent().parent().css("display","none");
							$("#riaIndividualRepId1").parent().parent().css("display","none");
							$("#riaIndividualRepName2").parent().parent().css("display","none");
							$("#riaIndividualRepId2").parent().parent().css("display","none");
							$("#star2").parent().css("display","none");
							$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
							$("#riaNotes").parent().parent().css("display","none");
							$("#ria").parent().css("display","none");
							
							
							$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
							$("#tpaFeesLoanFee").parent().parent().css("display","none");
							$("#tpaFeesDistributionFee").parent().parent().css("display","none");
							$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
							$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
							$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
							$("#tpaFeesNotes").parent().parent().css("display","none");	
							$("#rkdfee").parent().css("display","none");

							
							
							$("#star3").parent().css("display","none");
							$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
							$("#star4").parent().css("display","none");
							$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
							$("#closePlanNotes").parent().parent().css("display","none");

							
							$("#fiduciaryServiceLevel").parent().parent().css("display","none");
							$("#rpainfo").parent().css("display","none");
							$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
							$("#fiduciaryServiceNotes").parent().parent().css("display","none");
							$("#sysfee").parent().css("display","none");
							
							
							$("#star5").parent().css("display","none");
							$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
							$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
							$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
							
								
							$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
							$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
							$("#feelevelrecoveryenrol").parent().parent().css("display","none");
							$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
							 
							
							$("#addRemoveAfflAddContact").parent().parent().css("display","none");
							$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
							 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
							 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
							 $("#addRemoveAfflNotes").parent().parent().css("display","none");
							 $("#aff").parent().css("display","none");
														
				}


                 else if ($(this).val() == "Vesting Schedule update")

				  {
				    
					 $("#vestingSchedule").parent().parent().css("display","block");
					  $("#effectiveDateForVestingSchedule").parent().parent().css("display","block");
					  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","block");
					   $("#vestingScheduleUpdateNotes").parent().parent().css("display","block");
					   
					   
					     $('select[name=vestingScheduleEnrolBookReOrder]').change(function () 
		 {
            $("select[name=vestingScheduleEnrolBookReOrder] option:selected").each(function ()
        	{
                if ($(this).val() == "YES") 
				{
				    
					
					 $("#vestingScheduleUpdateNotes").parent().parent().css("display","block");
				     $("#enrollment").parent().css("display","block");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","block");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","block");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","block");
					 $("#shipto").parent().css("display","block");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","block");
					  $("#enrollBooksShipAttn").parent().parent().css("display","block");
					  $("#enrollBooksShipStreet").parent().parent().css("display","block");
					  $("#enrollBooksShipCity").parent().parent().css("display","block");
					 $("#enrollBooksShipState").parent().parent().css("display","block");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","block");
					  $("#enrollBooksNotes").parent().parent().css("display","block");
					  $("#delivery").parent().css("display","block");
					  
			     }
				 
				else if ($(this).val() == "NO" || $(this).val() == "No-Please send pdf of revised kit to IC through Genesys")
				  {
				  
				     $("#vestingScheduleUpdateNotes").parent().parent().css("display","block");
					 
					 $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
								 
					}
					
				});
				
			});
			
						$("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
			
					  $("#addMoneyType").parent().parent().css("display","none");
					  $("#removeMoneyType").parent().parent().css("display","none");
					  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
					 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
					 $("#enrollmentBookReorder").parent().parent().css("display","none");
					 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
					 $("#IC").parent().css("display","none");
					 
				 
				           $("#addFunds").parent().parent().css("display","none");
						   $("#removeFunds").parent().parent().css("display","none");
						   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
							$("#fundChangesChangeNotice").parent().parent().css("display","none");
							$("#fundChangesNotes").parent().parent().css("display","none");
							
							$("#loanReqTypes").parent().parent().css("display","none");
							$("#loansEffectiveDate").parent().parent().css("display","none");
							$("#loansGenPurposeYrs").parent().parent().css("display","none");
							$("#loansPayroleFrequency").parent().parent().css("display","none");
							$("#loansMortageYears").parent().parent().css("display","none");
							$("#loanMinAmount").parent().parent().css("display","none");
							$("#loanMaxAmount").parent().parent().css("display","none");
							$("#loansAllowed").parent().parent().css("display","none");
							$("#loanChangeNoticeReq").parent().parent().css("display","none");
							$("#loanNotes").parent().parent().css("display","none");
							
							
							$("#star").parent().css("display","none");
							$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
							$("#planspon").parent().css("display","none");
							$("#planSponcorName").parent().parent().css("display","none");
							$("#planSponcorPhone").parent().parent().css("display","none");
							$("#planSponcorEmail").parent().parent().css("display","none");
							$("#addcon").parent().css("display","none");
							$("#additionaContactName").parent().parent().css("display","none");
							$("#additionaContactPhone").parent().parent().css("display","none");
							$("#additionaContactEmail").parent().parent().css("display","none");
							$("#pspon").parent().css("display","none");
							$("#planSponsorRemoveName").parent().parent().css("display","none");
							$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
							$("#planContactNotes").parent().parent().css("display","none");
							$("#addfix").parent().css("display","none");
							
						  
							$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
							$("#riaServiceProvider").parent().parent().css("display","none");
							$("#riaRepJointName").parent().parent().css("display","none");
							$("#riaRepJointID").parent().parent().css("display","none");
							$("#riaIndividualRepName1").parent().parent().css("display","none");
							$("#riaIndividualRepId1").parent().parent().css("display","none");
							$("#riaIndividualRepName2").parent().parent().css("display","none");
							$("#riaIndividualRepId2").parent().parent().css("display","none");
							$("#star2").parent().css("display","none");
							$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
							$("#riaNotes").parent().parent().css("display","none");
							$("#ria").parent().css("display","none");
							
							
							$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
							$("#tpaFeesLoanFee").parent().parent().css("display","none");
							$("#tpaFeesDistributionFee").parent().parent().css("display","none");
							$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
							$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
							$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
							$("#tpaFeesNotes").parent().parent().css("display","none");	
							$("#rkdfee").parent().css("display","none");

							
							
							$("#star3").parent().css("display","none");
							$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
							$("#star4").parent().css("display","none");
							$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
							$("#closePlanNotes").parent().parent().css("display","none");

							
							$("#fiduciaryServiceLevel").parent().parent().css("display","none");
							$("#rpainfo").parent().css("display","none");
							$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
							$("#fiduciaryServiceNotes").parent().parent().css("display","none");
							$("#sysfee").parent().css("display","none");
							
							
							$("#star5").parent().css("display","none");
							$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
							$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
							$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
							
								
							$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
							$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
							$("#feelevelrecoveryenrol").parent().parent().css("display","none");
							$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
							 
							
							$("#addRemoveAfflAddContact").parent().parent().css("display","none");
							$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
							 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
							 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
							 $("#addRemoveAfflNotes").parent().parent().css("display","none");
							 $("#aff").parent().css("display","none");
							 
							 
				}
				
				  else if ($(this).val() == "Fund changes")
				  
				   {
				       $("#addFunds").parent().parent().css("display","block");
					   $("#removeFunds").parent().parent().css("display","block");
					   $("#fundChangesEffectiveDate").parent().parent().css("display","block");
						$("#fundChangesChangeNotice").parent().parent().css("display","block");
						$("#fundChangesNotes").parent().parent().css("display","block");
						
						
	        $('select[name=fundChangesChangeNotice]').change(function () 
		     {
            $("select[name=fundChangesChangeNotice] option:selected").each(function ()
        	{
                if ($(this).val() == "YES") 
				{
				    
					  $("#fundChangesNotes").parent().parent().css("display","block");
					 
				     $("#enrollment").parent().css("display","block");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","block");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","block");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","block");
					 $("#shipto").parent().css("display","block");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","block");
					  $("#enrollBooksShipAttn").parent().parent().css("display","block");
					  $("#enrollBooksShipStreet").parent().parent().css("display","block");
					  $("#enrollBooksShipCity").parent().parent().css("display","block");
					 $("#enrollBooksShipState").parent().parent().css("display","block");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","block");
					  $("#enrollBooksNotes").parent().parent().css("display","block");
					  $("#delivery").parent().css("display","block");
					  
			     }
				 
				else if ($(this).val() == "No,please send a change notice." || $(this).val() == "No,please send pdf of revised kit to IC through Genesys.")
				  {
				  
				     $("#fundChangesNotes").parent().parent().css("display","block");
					 
					 $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
								 
					}
					
				});
				
			});
					 $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
					
					  $("#addMoneyType").parent().parent().css("display","none");
					  $("#removeMoneyType").parent().parent().css("display","none");
					  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
					 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
					 $("#enrollmentBookReorder").parent().parent().css("display","none");
					 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
					 $("#IC").parent().css("display","none");
					 
					 
					 $("#vestingSchedule").parent().parent().css("display","none");
					  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
					  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
					   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
					   
					   
					   $("#loanReqTypes").parent().parent().css("display","none");
							$("#loansEffectiveDate").parent().parent().css("display","none");
							$("#loansGenPurposeYrs").parent().parent().css("display","none");
							$("#loansPayroleFrequency").parent().parent().css("display","none");
							$("#loansMortageYears").parent().parent().css("display","none");
							$("#loanMinAmount").parent().parent().css("display","none");
							$("#loanMaxAmount").parent().parent().css("display","none");
							$("#loansAllowed").parent().parent().css("display","none");
							$("#loanChangeNoticeReq").parent().parent().css("display","none");
							$("#loanNotes").parent().parent().css("display","none");
							
							
							$("#star").parent().css("display","none");
							$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
							$("#planspon").parent().css("display","none");
							$("#planSponcorName").parent().parent().css("display","none");
							$("#planSponcorPhone").parent().parent().css("display","none");
							$("#planSponcorEmail").parent().parent().css("display","none");
							$("#addcon").parent().css("display","none");
							$("#additionaContactName").parent().parent().css("display","none");
							$("#additionaContactPhone").parent().parent().css("display","none");
							$("#additionaContactEmail").parent().parent().css("display","none");
							$("#pspon").parent().css("display","none");
							$("#planSponsorRemoveName").parent().parent().css("display","none");
							$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
							$("#planContactNotes").parent().parent().css("display","none");
							$("#addfix").parent().css("display","none");
							
						  
							$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
							$("#riaServiceProvider").parent().parent().css("display","none");
							$("#riaRepJointName").parent().parent().css("display","none");
							$("#riaRepJointID").parent().parent().css("display","none");
							$("#riaIndividualRepName1").parent().parent().css("display","none");
							$("#riaIndividualRepId1").parent().parent().css("display","none");
							$("#riaIndividualRepName2").parent().parent().css("display","none");
							$("#riaIndividualRepId2").parent().parent().css("display","none");
							$("#star2").parent().css("display","none");
							$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
							$("#riaNotes").parent().parent().css("display","none");
							$("#ria").parent().css("display","none");
							
							
							$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
							$("#tpaFeesLoanFee").parent().parent().css("display","none");
							$("#tpaFeesDistributionFee").parent().parent().css("display","none");
							$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
							$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
							$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
							$("#tpaFeesNotes").parent().parent().css("display","none");	
							$("#rkdfee").parent().css("display","none");

							
							
							$("#star3").parent().css("display","none");
							$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
							$("#star4").parent().css("display","none");
							$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
							$("#closePlanNotes").parent().parent().css("display","none");

							
							$("#fiduciaryServiceLevel").parent().parent().css("display","none");
							$("#rpainfo").parent().css("display","none");
							$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
							$("#fiduciaryServiceNotes").parent().parent().css("display","none");
							$("#sysfee").parent().css("display","none");
							
							
							$("#star5").parent().css("display","none");
							$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
							$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
							$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
							
								
							$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
							$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
							$("#feelevelrecoveryenrol").parent().parent().css("display","none");
							$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
							 
							
							$("#addRemoveAfflAddContact").parent().parent().css("display","none");
							$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
							 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
							 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
							 $("#addRemoveAfflNotes").parent().parent().css("display","none");
							 $("#aff").parent().css("display","none");
							 
							 
					}

                else if ($(this).val() == "Loans")
					
					{
					        
							$("#loanReqTypes").parent().parent().css("display","block");
							$("#loansEffectiveDate").parent().parent().css("display","block");
							$("#loansGenPurposeYrs").parent().parent().css("display","block");
							$("#loansPayroleFrequency").parent().parent().css("display","block");
							$("#loansMortageYears").parent().parent().css("display","block");
							$("#loanMinAmount").parent().parent().css("display","block");
							$("#loanMaxAmount").parent().parent().css("display","block");
							$("#loansAllowed").parent().parent().css("display","block");
							$("#loanChangeNoticeReq").parent().parent().css("display","block");
							$("#loanNotes").parent().parent().css("display","block");
							
			      $('select[name=loanChangeNoticeReq]').change(function () 
					{
				$("select[name=loanChangeNoticeReq] option:selected").each(function ()
        	  {
                if ($(this).val() == "YES") 
				{
				    
					  $("#loanNotes").parent().parent().css("display","block");
					 
				     $("#enrollment").parent().css("display","block");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","block");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","block");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","block");
					 $("#shipto").parent().css("display","block");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","block");
					  $("#enrollBooksShipAttn").parent().parent().css("display","block");
					  $("#enrollBooksShipStreet").parent().parent().css("display","block");
					  $("#enrollBooksShipCity").parent().parent().css("display","block");
					 $("#enrollBooksShipState").parent().parent().css("display","block");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","block");
					  $("#enrollBooksNotes").parent().parent().css("display","block");
					  $("#delivery").parent().css("display","block");
					  
			     }
				 
				else if ($(this).val() == "No,please send a change notice." || $(this).val() == "No,please send pdf of revised kit to IC through Genesys.")
				  {
				  
				     $("#loanNotes").parent().parent().css("display","block");
					 
					 $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
								 
					}
					
				});
				
			});
				
				
				        $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");

						$("#addMoneyType").parent().parent().css("display","none");
					  $("#removeMoneyType").parent().parent().css("display","none");
					  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
					 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
					 $("#enrollmentBookReorder").parent().parent().css("display","none");
					 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
					 $("#IC").parent().css("display","none");
					 
					 $("#vestingSchedule").parent().parent().css("display","none");
					  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
					  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
					   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
					   
					   $("#addFunds").parent().parent().css("display","none");
					   $("#removeFunds").parent().parent().css("display","none");
					   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
						$("#fundChangesChangeNotice").parent().parent().css("display","none");
						$("#fundChangesNotes").parent().parent().css("display","none");
							
						
						$("#star").parent().css("display","none");
							$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
							$("#planspon").parent().css("display","none");
							$("#planSponcorName").parent().parent().css("display","none");
							$("#planSponcorPhone").parent().parent().css("display","none");
							$("#planSponcorEmail").parent().parent().css("display","none");
							$("#addcon").parent().css("display","none");
							$("#additionaContactName").parent().parent().css("display","none");
							$("#additionaContactPhone").parent().parent().css("display","none");
							$("#additionaContactEmail").parent().parent().css("display","none");
							$("#pspon").parent().css("display","none");
							$("#planSponsorRemoveName").parent().parent().css("display","none");
							$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
							$("#planContactNotes").parent().parent().css("display","none");
							$("#addfix").parent().css("display","none");
							
						  
							$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
							$("#riaServiceProvider").parent().parent().css("display","none");
							$("#riaRepJointName").parent().parent().css("display","none");
							$("#riaRepJointID").parent().parent().css("display","none");
							$("#riaIndividualRepName1").parent().parent().css("display","none");
							$("#riaIndividualRepId1").parent().parent().css("display","none");
							$("#riaIndividualRepName2").parent().parent().css("display","none");
							$("#riaIndividualRepId2").parent().parent().css("display","none");
							$("#star2").parent().css("display","none");
							$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
							$("#riaNotes").parent().parent().css("display","none");
							$("#ria").parent().css("display","none");
							
							
							$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
							$("#tpaFeesLoanFee").parent().parent().css("display","none");
							$("#tpaFeesDistributionFee").parent().parent().css("display","none");
							$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
							$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
							$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
							$("#tpaFeesNotes").parent().parent().css("display","none");	
							$("#rkdfee").parent().css("display","none");

							
							
							$("#star3").parent().css("display","none");
							$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
							$("#star4").parent().css("display","none");
							$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
							$("#closePlanNotes").parent().parent().css("display","none");

							
							$("#fiduciaryServiceLevel").parent().parent().css("display","none");
							$("#rpainfo").parent().css("display","none");
							$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
							$("#fiduciaryServiceNotes").parent().parent().css("display","none");
							$("#sysfee").parent().css("display","none");
							
							
							$("#star5").parent().css("display","none");
							$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
							$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
							$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
							
								
							$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
							$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
							$("#feelevelrecoveryenrol").parent().parent().css("display","none");
							$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
							 
							
							$("#addRemoveAfflAddContact").parent().parent().css("display","none");
							$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
							 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
							 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
							 $("#addRemoveAfflNotes").parent().parent().css("display","none");
							 $("#aff").parent().css("display","none");
							 
						}
						
				else if ($(this).val() == "Plan Contacts")
					
					{
					        
											 
							$("#star").parent().css("display","block");
							$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","block"); 
							$("#planspon").parent().css("display","block");
							$("#planSponcorName").parent().parent().css("display","block");
							$("#planSponcorPhone").parent().parent().css("display","block");
							$("#planSponcorEmail").parent().parent().css("display","block");
							$("#addcon").parent().css("display","block");
							$("#additionaContactName").parent().parent().css("display","block");
							$("#additionaContactPhone").parent().parent().css("display","block");
							$("#additionaContactEmail").parent().parent().css("display","block");
							$("#pspon").parent().css("display","block");
							$("#planSponsorRemoveName").parent().parent().css("display","block");
							$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","block");
							$("#planContactNotes").parent().parent().css("display","block");
							$("#addfix").parent().css("display","block");

							
							$('select[name=planSponcorRemoveEnrollmentBookReorder]').change(function () 
					{
				$("select[name=planSponcorRemoveEnrollmentBookReorder] option:selected").each(function ()
        	  {
                if ($(this).val() == "YES") 
				{
				    
					  $("#planContactNotes").parent().parent().css("display","block");
							$("#addfix").parent().css("display","block");
					 
				     $("#enrollment").parent().css("display","block");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","block");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","block");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","block");
					 $("#shipto").parent().css("display","block");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","block");
					  $("#enrollBooksShipAttn").parent().parent().css("display","block");
					  $("#enrollBooksShipStreet").parent().parent().css("display","block");
					  $("#enrollBooksShipCity").parent().parent().css("display","block");
					 $("#enrollBooksShipState").parent().parent().css("display","block");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","block");
					  $("#enrollBooksNotes").parent().parent().css("display","block");
					  $("#delivery").parent().css("display","block");
					  
			     }
				 
				else if ($(this).val() == "NO" || $(this).val() == "No-Please send pdf of revised kit to IC through Genesys")
				  {
				  
				      $("#planContactNotes").parent().parent().css("display","block");
							$("#addfix").parent().css("display","block");
					 
					 $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
								 
					}
					
				});
				
			});
				  
				   $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
				
				  $("#addMoneyType").parent().parent().css("display","none");
					  $("#removeMoneyType").parent().parent().css("display","none");
					  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
					 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
					 $("#enrollmentBookReorder").parent().parent().css("display","none");
					 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
					 $("#IC").parent().css("display","none");
					 
					 
					  $("#vestingSchedule").parent().parent().css("display","none");
					  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
					  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
					   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
					   
					   $("#addFunds").parent().parent().css("display","none");
					   $("#removeFunds").parent().parent().css("display","none");
					   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
						$("#fundChangesChangeNotice").parent().parent().css("display","none");
						$("#fundChangesNotes").parent().parent().css("display","none");
						
						$("#loanReqTypes").parent().parent().css("display","none");
						$("#loansEffectiveDate").parent().parent().css("display","none");
						$("#loansGenPurposeYrs").parent().parent().css("display","none");
						$("#loansPayroleFrequency").parent().parent().css("display","none");
						$("#loansMortageYears").parent().parent().css("display","none");
						$("#loanMinAmount").parent().parent().css("display","none");
						$("#loanMaxAmount").parent().parent().css("display","none");
						$("#loansAllowed").parent().parent().css("display","none");
						$("#loanChangeNoticeReq").parent().parent().css("display","none");
						$("#loanNotes").parent().parent().css("display","none");
						
						$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
						$("#riaServiceProvider").parent().parent().css("display","none");
						$("#riaRepJointName").parent().parent().css("display","none");
						$("#riaRepJointID").parent().parent().css("display","none");
						$("#riaIndividualRepName1").parent().parent().css("display","none");
						$("#riaIndividualRepId1").parent().parent().css("display","none");
						$("#riaIndividualRepName2").parent().parent().css("display","none");
						$("#riaIndividualRepId2").parent().parent().css("display","none");
						$("#star2").parent().css("display","none");
						$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
						$("#riaNotes").parent().parent().css("display","none");
						$("#ria").parent().css("display","none");
						
						
						$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
						$("#tpaFeesLoanFee").parent().parent().css("display","none");
						$("#tpaFeesDistributionFee").parent().parent().css("display","none");
						$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
						$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
						$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
						$("#tpaFeesNotes").parent().parent().css("display","none");	
						$("#rkdfee").parent().css("display","none");

						
						
						$("#star3").parent().css("display","none");
						$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
						$("#star4").parent().css("display","none");
						$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
						$("#closePlanNotes").parent().parent().css("display","none");

						
						$("#fiduciaryServiceLevel").parent().parent().css("display","none");
						$("#rpainfo").parent().css("display","none");
						$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
						$("#fiduciaryServiceNotes").parent().parent().css("display","none");
						$("#sysfee").parent().css("display","none");
						
						
						$("#star5").parent().css("display","none");
						$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
						$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
						$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
						
							
						$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
						$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
						$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
						$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
						$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
						$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
						$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
						$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
						$("#feelevelrecoveryenrol").parent().parent().css("display","none");
						$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
						 
						
						$("#addRemoveAfflAddContact").parent().parent().css("display","none");
						$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
						 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
						 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
						 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
						 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
						 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
						 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
						 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
						 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
						 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
						 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
						 $("#addRemoveAfflNotes").parent().parent().css("display","none");
						 $("#aff").parent().css("display","none");
						 
				}


                 else if ($(this).val() == "RIA- Adding Service Provider/RIA contact")
					
					{
					
					    $("#salesConnectFormDateSubmitted").parent().parent().css("display","block");
						$("#riaServiceProvider").parent().parent().css("display","block");
						$("#riaRepJointName").parent().parent().css("display","block");
						$("#riaRepJointID").parent().parent().css("display","block");
						$("#riaIndividualRepName1").parent().parent().css("display","block");
						$("#riaIndividualRepId1").parent().parent().css("display","block");
						$("#riaIndividualRepName2").parent().parent().css("display","block");
						$("#riaIndividualRepId2").parent().parent().css("display","block");
						$("#star2").parent().css("display","block");
						$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","block"); 
						$("#riaNotes").parent().parent().css("display","block");
						$("#ria").parent().css("display","block");
						
						
						$("#addMoneyType").parent().parent().css("display","none");
						  $("#removeMoneyType").parent().parent().css("display","none");
						  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
						 $("#enrollmentBookReorder").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
						 $("#IC").parent().css("display","none");
						 
						 $("#enrollment").parent().css("display","none");
						 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
						 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
						 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
						 $("#shipto").parent().css("display","none");
						 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
						  $("#enrollBooksShipAttn").parent().parent().css("display","none");
						  $("#enrollBooksShipStreet").parent().parent().css("display","none");
						  $("#enrollBooksShipCity").parent().parent().css("display","none");
						 $("#enrollBooksShipState").parent().parent().css("display","none");
						 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
						  $("#enrollBooksNotes").parent().parent().css("display","none");
						  $("#delivery").parent().css("display","none");
						  
						  
						  $("#vestingSchedule").parent().parent().css("display","none");
						  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
						  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
						   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
						   
						   $("#addFunds").parent().parent().css("display","none");
						   $("#removeFunds").parent().parent().css("display","none");
						   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
							$("#fundChangesChangeNotice").parent().parent().css("display","none");
							$("#fundChangesNotes").parent().parent().css("display","none");
							
							$("#loanReqTypes").parent().parent().css("display","none");
							$("#loansEffectiveDate").parent().parent().css("display","none");
							$("#loansGenPurposeYrs").parent().parent().css("display","none");
							$("#loansPayroleFrequency").parent().parent().css("display","none");
							$("#loansMortageYears").parent().parent().css("display","none");
							$("#loanMinAmount").parent().parent().css("display","none");
							$("#loanMaxAmount").parent().parent().css("display","none");
							$("#loansAllowed").parent().parent().css("display","none");
							$("#loanChangeNoticeReq").parent().parent().css("display","none");
							$("#loanNotes").parent().parent().css("display","none");
							
							
							$("#star").parent().css("display","none");
							$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
							$("#planspon").parent().css("display","none");
							$("#planSponcorName").parent().parent().css("display","none");
							$("#planSponcorPhone").parent().parent().css("display","none");
							$("#planSponcorEmail").parent().parent().css("display","none");
							$("#addcon").parent().css("display","none");
							$("#additionaContactName").parent().parent().css("display","none");
							$("#additionaContactPhone").parent().parent().css("display","none");
							$("#additionaContactEmail").parent().parent().css("display","none");
							$("#pspon").parent().css("display","none");
							$("#planSponsorRemoveName").parent().parent().css("display","none");
							$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
							$("#planContactNotes").parent().parent().css("display","none");
							$("#addfix").parent().css("display","none");
							
							
							$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
						$("#tpaFeesLoanFee").parent().parent().css("display","none");
						$("#tpaFeesDistributionFee").parent().parent().css("display","none");
						$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
						$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
						$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
						$("#tpaFeesNotes").parent().parent().css("display","none");	
						$("#rkdfee").parent().css("display","none");

						
						
						$("#star3").parent().css("display","none");
						$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
						$("#star4").parent().css("display","none");
						$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
						$("#closePlanNotes").parent().parent().css("display","none");

						
						$("#fiduciaryServiceLevel").parent().parent().css("display","none");
						$("#rpainfo").parent().css("display","none");
						$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
						$("#fiduciaryServiceNotes").parent().parent().css("display","none");
						$("#sysfee").parent().css("display","none");
						
						
						$("#star5").parent().css("display","none");
						$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
						$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
						$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
						
							
						$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
						$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
						$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
						$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
						$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
						$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
						$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
						$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
						$("#feelevelrecoveryenrol").parent().parent().css("display","none");
						$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
						 
						
						$("#addRemoveAfflAddContact").parent().parent().css("display","none");
						$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
						 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
						 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
						 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
						 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
						 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
						 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
						 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
						 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
						 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
						 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
						 $("#addRemoveAfflNotes").parent().parent().css("display","none");
						 $("#aff").parent().css("display","none");
						 
						 
				}
					
			else if ($(this).val() == "TPA Fees")
					
					{
							$("#tpaFeesEffectiveDate").parent().parent().css("display","block");
							$("#tpaFeesLoanFee").parent().parent().css("display","block");
							$("#tpaFeesDistributionFee").parent().parent().css("display","block");
							$("#tpaFeesChangeNeeded").parent().parent().css("display","block");
							$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","block"); 
							$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","block");
							$("#tpaFeesNotes").parent().parent().css("display","block");	
							$("#rkdfee").parent().css("display","block");
							
							
							$('select[name=tpaFeesChangeNeeded]').change(function () 
					{
				$("select[name=tpaFeesChangeNeeded] option:selected").each(function ()
        	  {
                if ($(this).val() == "YES") 
				{
				    
					  $("#tpaFeesNotes").parent().parent().css("display","block");	
							$("#rkdfee").parent().css("display","block");
					 
				     $("#enrollment").parent().css("display","block");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","block");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","block");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","block");
					 $("#shipto").parent().css("display","block");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","block");
					  $("#enrollBooksShipAttn").parent().parent().css("display","block");
					  $("#enrollBooksShipStreet").parent().parent().css("display","block");
					  $("#enrollBooksShipCity").parent().parent().css("display","block");
					 $("#enrollBooksShipState").parent().parent().css("display","block");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","block");
					  $("#enrollBooksNotes").parent().parent().css("display","block");
					  $("#delivery").parent().css("display","block");
					  
			     }
				 
				else if ($(this).val() == "No,please send a change notice." || $(this).val() == "No,please send pdf of revised kit to IC through Genesys.")
				  {
				  
				      $("#tpaFeesNotes").parent().parent().css("display","block");	
							$("#rkdfee").parent().css("display","block");
					 
					 $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
								 
					}
					
				});
				
			});
			
			               $("#enrollment").parent().css("display","none");
							 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
							 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
							 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
							 $("#shipto").parent().css("display","none");
							 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
							  $("#enrollBooksShipAttn").parent().parent().css("display","none");
							  $("#enrollBooksShipStreet").parent().parent().css("display","none");
							  $("#enrollBooksShipCity").parent().parent().css("display","none");
							 $("#enrollBooksShipState").parent().parent().css("display","none");
							 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
							  $("#enrollBooksNotes").parent().parent().css("display","none");
							  $("#delivery").parent().css("display","none");
							

							$("#addMoneyType").parent().parent().css("display","none");
						  $("#removeMoneyType").parent().parent().css("display","none");
						  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
						 $("#enrollmentBookReorder").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
						 $("#IC").parent().css("display","none");
						 
						 
						 $("#vestingSchedule").parent().parent().css("display","none");
					  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
					  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
					   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
					   
					   $("#addFunds").parent().parent().css("display","none");
					   $("#removeFunds").parent().parent().css("display","none");
					   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
						$("#fundChangesChangeNotice").parent().parent().css("display","none");
						$("#fundChangesNotes").parent().parent().css("display","none");
						
						$("#loanReqTypes").parent().parent().css("display","none");
						$("#loansEffectiveDate").parent().parent().css("display","none");
						$("#loansGenPurposeYrs").parent().parent().css("display","none");
						$("#loansPayroleFrequency").parent().parent().css("display","none");
						$("#loansMortageYears").parent().parent().css("display","none");
						$("#loanMinAmount").parent().parent().css("display","none");
						$("#loanMaxAmount").parent().parent().css("display","none");
						$("#loansAllowed").parent().parent().css("display","none");
						$("#loanChangeNoticeReq").parent().parent().css("display","none");
						$("#loanNotes").parent().parent().css("display","none");
						
						
						$("#star").parent().css("display","none");
						$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
						$("#planspon").parent().css("display","none");
						$("#planSponcorName").parent().parent().css("display","none");
						$("#planSponcorPhone").parent().parent().css("display","none");
						$("#planSponcorEmail").parent().parent().css("display","none");
						$("#addcon").parent().css("display","none");
						$("#additionaContactName").parent().parent().css("display","none");
						$("#additionaContactPhone").parent().parent().css("display","none");
						$("#additionaContactEmail").parent().parent().css("display","none");
						$("#pspon").parent().css("display","none");
						$("#planSponsorRemoveName").parent().parent().css("display","none");
						$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
						$("#planContactNotes").parent().parent().css("display","none");
						$("#addfix").parent().css("display","none");
						
					  
						$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
						$("#riaServiceProvider").parent().parent().css("display","none");
						$("#riaRepJointName").parent().parent().css("display","none");
						$("#riaRepJointID").parent().parent().css("display","none");
						$("#riaIndividualRepName1").parent().parent().css("display","none");
						$("#riaIndividualRepId1").parent().parent().css("display","none");
						$("#riaIndividualRepName2").parent().parent().css("display","none");
						$("#riaIndividualRepId2").parent().parent().css("display","none");
						$("#star2").parent().css("display","none");
						$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
						$("#riaNotes").parent().parent().css("display","none");
						$("#ria").parent().css("display","none");
						
						$("#star3").parent().css("display","none");
							$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
							$("#star4").parent().css("display","none");
							$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
							$("#closePlanNotes").parent().parent().css("display","none");

							
							$("#fiduciaryServiceLevel").parent().parent().css("display","none");
							$("#rpainfo").parent().css("display","none");
							$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
							$("#fiduciaryServiceNotes").parent().parent().css("display","none");
							$("#sysfee").parent().css("display","none");
							
							
							$("#star5").parent().css("display","none");
							$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
							$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
							$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
							
								
							$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
							$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
							$("#feelevelrecoveryenrol").parent().parent().css("display","none");
							$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
							 
							
							$("#addRemoveAfflAddContact").parent().parent().css("display","none");
							$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
							 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
							 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
							 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
							 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
							 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
							 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
							 $("#addRemoveAfflNotes").parent().parent().css("display","none");
							 $("#aff").parent().css("display","none");
							

			 }


                 else if ($(this).val() == "Close Plan")
					
			{
			            
						$("#star3").parent().css("display","block");
						$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","block"); 
						$("#star4").parent().css("display","block");
						$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","block");
						$("#closePlanNotes").parent().parent().css("display","block");
						
						
						$("#addMoneyType").parent().parent().css("display","none");
						  $("#removeMoneyType").parent().parent().css("display","none");
						  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
						 $("#enrollmentBookReorder").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
						 $("#IC").parent().css("display","none");
						 
						 $("#enrollment").parent().css("display","none");
						 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
						 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
						 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
						 $("#shipto").parent().css("display","none");
						 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
						  $("#enrollBooksShipAttn").parent().parent().css("display","none");
						  $("#enrollBooksShipStreet").parent().parent().css("display","none");
						  $("#enrollBooksShipCity").parent().parent().css("display","none");
						 $("#enrollBooksShipState").parent().parent().css("display","none");
						 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
						  $("#enrollBooksNotes").parent().parent().css("display","none");
						  $("#delivery").parent().css("display","none");
						  
						  
						  $("#vestingSchedule").parent().parent().css("display","none");
						  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
						  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
						   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
						   
						   $("#addFunds").parent().parent().css("display","none");
						   $("#removeFunds").parent().parent().css("display","none");
						   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
							$("#fundChangesChangeNotice").parent().parent().css("display","none");
							$("#fundChangesNotes").parent().parent().css("display","none");
							
							$("#loanReqTypes").parent().parent().css("display","none");
							$("#loansEffectiveDate").parent().parent().css("display","none");
							$("#loansGenPurposeYrs").parent().parent().css("display","none");
							$("#loansPayroleFrequency").parent().parent().css("display","none");
							$("#loansMortageYears").parent().parent().css("display","none");
							$("#loanMinAmount").parent().parent().css("display","none");
							$("#loanMaxAmount").parent().parent().css("display","none");
							$("#loansAllowed").parent().parent().css("display","none");
							$("#loanChangeNoticeReq").parent().parent().css("display","none");
							$("#loanNotes").parent().parent().css("display","none");
							
							
							$("#star").parent().css("display","none");
							$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
							$("#planspon").parent().css("display","none");
							$("#planSponcorName").parent().parent().css("display","none");
							$("#planSponcorPhone").parent().parent().css("display","none");
							$("#planSponcorEmail").parent().parent().css("display","none");
							$("#addcon").parent().css("display","none");
							$("#additionaContactName").parent().parent().css("display","none");
							$("#additionaContactPhone").parent().parent().css("display","none");
							$("#additionaContactEmail").parent().parent().css("display","none");
							$("#pspon").parent().css("display","none");
							$("#planSponsorRemoveName").parent().parent().css("display","none");
							$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
							$("#planContactNotes").parent().parent().css("display","none");
							$("#addfix").parent().css("display","none");
							
						  
							$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
							$("#riaServiceProvider").parent().parent().css("display","none");
							$("#riaRepJointName").parent().parent().css("display","none");
							$("#riaRepJointID").parent().parent().css("display","none");
							$("#riaIndividualRepName1").parent().parent().css("display","none");
							$("#riaIndividualRepId1").parent().parent().css("display","none");
							$("#riaIndividualRepName2").parent().parent().css("display","none");
							$("#riaIndividualRepId2").parent().parent().css("display","none");
							$("#star2").parent().css("display","none");
							$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
							$("#riaNotes").parent().parent().css("display","none");
							$("#ria").parent().css("display","none");
							
							
							$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
							$("#tpaFeesLoanFee").parent().parent().css("display","none");
							$("#tpaFeesDistributionFee").parent().parent().css("display","none");
							$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
							$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
							$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
							$("#tpaFeesNotes").parent().parent().css("display","none");	
							$("#rkdfee").parent().css("display","none");
							
							
							$("#fiduciaryServiceLevel").parent().parent().css("display","none");
								$("#rpainfo").parent().css("display","none");
								$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
								$("#fiduciaryServiceNotes").parent().parent().css("display","none");
								$("#sysfee").parent().css("display","none");
								
								
								$("#star5").parent().css("display","none");
								$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
								$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
								$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
								
									
								$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
								$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
								$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
								$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
								$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
								$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
								$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
								$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
								$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
								$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
								$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
								$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
								$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
								$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
								$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
								$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
								$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
								$("#feelevelrecoveryenrol").parent().parent().css("display","none");
								$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
								 
								
								$("#addRemoveAfflAddContact").parent().parent().css("display","none");
								$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
								 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
								 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
								 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
								 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
								 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
								 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
								 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
								 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
								 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
								 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
								 $("#addRemoveAfflNotes").parent().parent().css("display","none");
								 $("#aff").parent().css("display","none");
								 
								
						}
						
						
						else if ($(this).val() == "Fiduciary Services")
						
						 {
						
						        $("#fiduciaryServiceLevel").parent().parent().css("display","block");
								$("#rpainfo").parent().css("display","block");
								$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","block");
								$("#fiduciaryServiceNotes").parent().parent().css("display","block");
								$("#sysfee").parent().css("display","block");
								
								
								
								$("#addMoneyType").parent().parent().css("display","none");
								  $("#removeMoneyType").parent().parent().css("display","none");
								  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
								 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
								 $("#enrollmentBookReorder").parent().parent().css("display","none");
								 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
								 $("#IC").parent().css("display","none");
						 
								 $("#enrollment").parent().css("display","none");
								 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
								 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
								 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
								 $("#shipto").parent().css("display","none");
								 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
								  $("#enrollBooksShipAttn").parent().parent().css("display","none");
								  $("#enrollBooksShipStreet").parent().parent().css("display","none");
								  $("#enrollBooksShipCity").parent().parent().css("display","none");
								 $("#enrollBooksShipState").parent().parent().css("display","none");
								 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
								  $("#enrollBooksNotes").parent().parent().css("display","none");
								  $("#delivery").parent().css("display","none");
								  
								  
								  $("#vestingSchedule").parent().parent().css("display","none");
								  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
								  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
								   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
								   
								   $("#addFunds").parent().parent().css("display","none");
								   $("#removeFunds").parent().parent().css("display","none");
								   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
									$("#fundChangesChangeNotice").parent().parent().css("display","none");
									$("#fundChangesNotes").parent().parent().css("display","none");
									
									$("#loanReqTypes").parent().parent().css("display","none");
									$("#loansEffectiveDate").parent().parent().css("display","none");
									$("#loansGenPurposeYrs").parent().parent().css("display","none");
									$("#loansPayroleFrequency").parent().parent().css("display","none");
									$("#loansMortageYears").parent().parent().css("display","none");
									$("#loanMinAmount").parent().parent().css("display","none");
									$("#loanMaxAmount").parent().parent().css("display","none");
									$("#loansAllowed").parent().parent().css("display","none");
									$("#loanChangeNoticeReq").parent().parent().css("display","none");
									$("#loanNotes").parent().parent().css("display","none");
									
									
									$("#star").parent().css("display","none");
									$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
									$("#planspon").parent().css("display","none");
									$("#planSponcorName").parent().parent().css("display","none");
									$("#planSponcorPhone").parent().parent().css("display","none");
									$("#planSponcorEmail").parent().parent().css("display","none");
									$("#addcon").parent().css("display","none");
									$("#additionaContactName").parent().parent().css("display","none");
									$("#additionaContactPhone").parent().parent().css("display","none");
									$("#additionaContactEmail").parent().parent().css("display","none");
									$("#pspon").parent().css("display","none");
									$("#planSponsorRemoveName").parent().parent().css("display","none");
									$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
									$("#planContactNotes").parent().parent().css("display","none");
									$("#addfix").parent().css("display","none");
									
								  
									$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
									$("#riaServiceProvider").parent().parent().css("display","none");
									$("#riaRepJointName").parent().parent().css("display","none");
									$("#riaRepJointID").parent().parent().css("display","none");
									$("#riaIndividualRepName1").parent().parent().css("display","none");
									$("#riaIndividualRepId1").parent().parent().css("display","none");
									$("#riaIndividualRepName2").parent().parent().css("display","none");
									$("#riaIndividualRepId2").parent().parent().css("display","none");
									$("#star2").parent().css("display","none");
									$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
									$("#riaNotes").parent().parent().css("display","none");
									$("#ria").parent().css("display","none");
									
									
									$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
									$("#tpaFeesLoanFee").parent().parent().css("display","none");
									$("#tpaFeesDistributionFee").parent().parent().css("display","none");
									$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
									$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
									$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
									$("#tpaFeesNotes").parent().parent().css("display","none");	
									$("#rkdfee").parent().css("display","none");
									
									$("#star3").parent().css("display","none");
									$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
									$("#star4").parent().css("display","none");
									$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
									$("#closePlanNotes").parent().parent().css("display","none");
									
									$("#star5").parent().css("display","none");
									$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
									$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
									$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
									
										
									$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
									$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
									$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
									$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
									$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
									$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
									$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
									$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
									$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
									$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
									$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
									$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
									$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
									$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
									$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
									$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
									$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
									$("#feelevelrecoveryenrol").parent().parent().css("display","none");
									$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
									 
									
									$("#addRemoveAfflAddContact").parent().parent().css("display","none");
									$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
									 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
									 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
									 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
									 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
									 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
									 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
									 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
									 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
									 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
									 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
									 $("#addRemoveAfflNotes").parent().parent().css("display","none");
									 $("#aff").parent().css("display","none");
									 
							
					}

                 else if ($(this).val() == "Plan Setup Errors")

				{
							$("#star5").parent().css("display","block");
							$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","block");
							$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","block");
							$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","block");

								
							
								$('select[name=planSetupErrorsEnrollmentBooksReorder]').change(function () 
					{
				$("select[name=planSetupErrorsEnrollmentBooksReorder] option:selected").each(function ()
        	  {
                if ($(this).val() == "YES") 
				{
				    
					  
					 
				     $("#enrollment").parent().css("display","block");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","block");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","block");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","block");
					 $("#shipto").parent().css("display","block");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","block");
					  $("#enrollBooksShipAttn").parent().parent().css("display","block");
					  $("#enrollBooksShipStreet").parent().parent().css("display","block");
					  $("#enrollBooksShipCity").parent().parent().css("display","block");
					 $("#enrollBooksShipState").parent().parent().css("display","block");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","block");
					  $("#enrollBooksNotes").parent().parent().css("display","block");
					  $("#delivery").parent().css("display","block");
					  
			     }
				 
				else if ($(this).val() == "NO" || $(this).val() == "No-Please send pdf of revised kit to IC through Genesys")
				  {
				  
				      
					 
					 $("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
								 
					}
					
				});
				
			});
			
							
							$("#enrollment").parent().css("display","none");
					 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
					 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
					 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
					 $("#shipto").parent().css("display","none");
					 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
					  $("#enrollBooksShipAttn").parent().parent().css("display","none");
					  $("#enrollBooksShipStreet").parent().parent().css("display","none");
					  $("#enrollBooksShipCity").parent().parent().css("display","none");
					 $("#enrollBooksShipState").parent().parent().css("display","none");
					 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
					  $("#enrollBooksNotes").parent().parent().css("display","none");
					  $("#delivery").parent().css("display","none");
					  
					  
                       $("#addMoneyType").parent().parent().css("display","none");
						  $("#removeMoneyType").parent().parent().css("display","none");
						  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
						 $("#enrollmentBookReorder").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
						 $("#IC").parent().css("display","none");
						 
						 
						 $("#vestingSchedule").parent().parent().css("display","none");
						  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
						  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
						   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
						   
						   $("#addFunds").parent().parent().css("display","none");
						   $("#removeFunds").parent().parent().css("display","none");
						   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
							$("#fundChangesChangeNotice").parent().parent().css("display","none");
							$("#fundChangesNotes").parent().parent().css("display","none");
							
							$("#loanReqTypes").parent().parent().css("display","none");
							$("#loansEffectiveDate").parent().parent().css("display","none");
							$("#loansGenPurposeYrs").parent().parent().css("display","none");
							$("#loansPayroleFrequency").parent().parent().css("display","none");
							$("#loansMortageYears").parent().parent().css("display","none");
							$("#loanMinAmount").parent().parent().css("display","none");
							$("#loanMaxAmount").parent().parent().css("display","none");
							$("#loansAllowed").parent().parent().css("display","none");
							$("#loanChangeNoticeReq").parent().parent().css("display","none");
							$("#loanNotes").parent().parent().css("display","none");
							
							
							$("#star").parent().css("display","none");
							$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
							$("#planspon").parent().css("display","none");
							$("#planSponcorName").parent().parent().css("display","none");
							$("#planSponcorPhone").parent().parent().css("display","none");
							$("#planSponcorEmail").parent().parent().css("display","none");
							$("#addcon").parent().css("display","none");
							$("#additionaContactName").parent().parent().css("display","none");
							$("#additionaContactPhone").parent().parent().css("display","none");
							$("#additionaContactEmail").parent().parent().css("display","none");
							$("#pspon").parent().css("display","none");
							$("#planSponsorRemoveName").parent().parent().css("display","none");
							$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
							$("#planContactNotes").parent().parent().css("display","none");
							$("#addfix").parent().css("display","none");
							
						  
							$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
							$("#riaServiceProvider").parent().parent().css("display","none");
							$("#riaRepJointName").parent().parent().css("display","none");
							$("#riaRepJointID").parent().parent().css("display","none");
							$("#riaIndividualRepName1").parent().parent().css("display","none");
							$("#riaIndividualRepId1").parent().parent().css("display","none");
							$("#riaIndividualRepName2").parent().parent().css("display","none");
							$("#riaIndividualRepId2").parent().parent().css("display","none");
							$("#star2").parent().css("display","none");
							$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
							$("#riaNotes").parent().parent().css("display","none");
							$("#ria").parent().css("display","none");
							
							
							$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
							$("#tpaFeesLoanFee").parent().parent().css("display","none");
							$("#tpaFeesDistributionFee").parent().parent().css("display","none");
							$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
							$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
							$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
							$("#tpaFeesNotes").parent().parent().css("display","none");	
							$("#rkdfee").parent().css("display","none");

							
							
							$("#star3").parent().css("display","none");
							$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
							$("#star4").parent().css("display","none");
							$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
							$("#closePlanNotes").parent().parent().css("display","none");

							
							$("#fiduciaryServiceLevel").parent().parent().css("display","none");
							$("#rpainfo").parent().css("display","none");
							$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
							$("#fiduciaryServiceNotes").parent().parent().css("display","none");
							$("#sysfee").parent().css("display","none");
							
							
							$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
						$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
						$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
						$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
						$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
						$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
						$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
						$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
						$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
						$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
						$("#feelevelrecoveryenrol").parent().parent().css("display","none");
						$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
						 
						
						$("#addRemoveAfflAddContact").parent().parent().css("display","none");
						$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
						 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
						 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
						 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
						 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
						 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
						 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
						 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
						 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
						 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
						 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
						 $("#addRemoveAfflNotes").parent().parent().css("display","none");
						 $("#aff").parent().css("display","none");
						 
				}
				
				else if ($(this).val() == "Fee Level Recovery")
						
				{
							
							$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","block");
								$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","block");
								$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","block");
								$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","block");
								$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","block");
								$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","block");
								$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","block");
								$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","block");
								$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","block");
								$("#feeLevelRecoveryFPProRata").parent().parent().css("display","block");
								$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","block");
								$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","block");
								$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","block");
								$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","block");
								$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","block");
								$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","block");
								$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","block");
								$("#feelevelrecoveryenrol").parent().parent().css("display","block");
								$("#feeLevelRecoveryNotes").parent().parent().css("display","block");
								
								
								$('select[name=feelevelrecoveryenrol]').change(function () 
					{
				$("select[name=feelevelrecoveryenrol] option:selected").each(function ()
        	  {
                if ($(this).val() == "YES") 
				{
				    
					    $("#feeLevelRecoveryNotes").parent().parent().css("display","block");
					 
						 $("#enrollment").parent().css("display","block");
						 $("#enrollBooksDeliveryDate").parent().parent().css("display","block");
						 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","block");
						 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","block");
						 $("#shipto").parent().css("display","block");
						 $("#enrollBooksShipCompanyName").parent().parent().css("display","block");
						  $("#enrollBooksShipAttn").parent().parent().css("display","block");
						  $("#enrollBooksShipStreet").parent().parent().css("display","block");
						  $("#enrollBooksShipCity").parent().parent().css("display","block");
						 $("#enrollBooksShipState").parent().parent().css("display","block");
						 $("#enrollBooksShipZipCode").parent().parent().css("display","block");
						  $("#enrollBooksNotes").parent().parent().css("display","block");
						  $("#delivery").parent().css("display","block");
					  
			     }
				 
				else if ($(this).val() == "No, please send a change notice." || $(this).val() == "No,please send pdf of revised kit to IC through Genesys.")
				  {
				  
				         $("#feeLevelRecoveryNotes").parent().parent().css("display","block");
					 
						 $("#enrollment").parent().css("display","none");
						 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
						 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
						 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
						 $("#shipto").parent().css("display","none");
						 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
						  $("#enrollBooksShipAttn").parent().parent().css("display","none");
						  $("#enrollBooksShipStreet").parent().parent().css("display","none");
						  $("#enrollBooksShipCity").parent().parent().css("display","none");
						 $("#enrollBooksShipState").parent().parent().css("display","none");
						 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
						  $("#enrollBooksNotes").parent().parent().css("display","none");
						  $("#delivery").parent().css("display","none");
								 
					}
					
				});
				
			});
			
							$("#addMoneyType").parent().parent().css("display","none");
							  $("#removeMoneyType").parent().parent().css("display","none");
							  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
							 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
							 $("#enrollmentBookReorder").parent().parent().css("display","none");
							 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
							 $("#IC").parent().css("display","none");
							 
							 $("#enrollment").parent().css("display","none");
							 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
							 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
							 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
							 $("#shipto").parent().css("display","none");
							 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
							  $("#enrollBooksShipAttn").parent().parent().css("display","none");
							  $("#enrollBooksShipStreet").parent().parent().css("display","none");
							  $("#enrollBooksShipCity").parent().parent().css("display","none");
							 $("#enrollBooksShipState").parent().parent().css("display","none");
							 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
							  $("#enrollBooksNotes").parent().parent().css("display","none");
							  $("#delivery").parent().css("display","none");
							  
							  
							  $("#vestingSchedule").parent().parent().css("display","none");
							  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
							  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
							   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
							   
							   $("#addFunds").parent().parent().css("display","none");
							   $("#removeFunds").parent().parent().css("display","none");
							   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
								$("#fundChangesChangeNotice").parent().parent().css("display","none");
								$("#fundChangesNotes").parent().parent().css("display","none");
								
								$("#loanReqTypes").parent().parent().css("display","none");
								$("#loansEffectiveDate").parent().parent().css("display","none");
								$("#loansGenPurposeYrs").parent().parent().css("display","none");
								$("#loansPayroleFrequency").parent().parent().css("display","none");
								$("#loansMortageYears").parent().parent().css("display","none");
								$("#loanMinAmount").parent().parent().css("display","none");
								$("#loanMaxAmount").parent().parent().css("display","none");
								$("#loansAllowed").parent().parent().css("display","none");
								$("#loanChangeNoticeReq").parent().parent().css("display","none");
								$("#loanNotes").parent().parent().css("display","none");
								
								
								$("#star").parent().css("display","none");
								$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
								$("#planspon").parent().css("display","none");
								$("#planSponcorName").parent().parent().css("display","none");
								$("#planSponcorPhone").parent().parent().css("display","none");
								$("#planSponcorEmail").parent().parent().css("display","none");
								$("#addcon").parent().css("display","none");
								$("#additionaContactName").parent().parent().css("display","none");
								$("#additionaContactPhone").parent().parent().css("display","none");
								$("#additionaContactEmail").parent().parent().css("display","none");
								$("#pspon").parent().css("display","none");
								$("#planSponsorRemoveName").parent().parent().css("display","none");
								$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
								$("#planContactNotes").parent().parent().css("display","none");
								$("#addfix").parent().css("display","none");
								
							  
								$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
								$("#riaServiceProvider").parent().parent().css("display","none");
								$("#riaRepJointName").parent().parent().css("display","none");
								$("#riaRepJointID").parent().parent().css("display","none");
								$("#riaIndividualRepName1").parent().parent().css("display","none");
								$("#riaIndividualRepId1").parent().parent().css("display","none");
								$("#riaIndividualRepName2").parent().parent().css("display","none");
								$("#riaIndividualRepId2").parent().parent().css("display","none");
								$("#star2").parent().css("display","none");
								$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
								$("#riaNotes").parent().parent().css("display","none");
								$("#ria").parent().css("display","none");
								
								
								$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
								$("#tpaFeesLoanFee").parent().parent().css("display","none");
								$("#tpaFeesDistributionFee").parent().parent().css("display","none");
								$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
								$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
								$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
								$("#tpaFeesNotes").parent().parent().css("display","none");	
								$("#rkdfee").parent().css("display","none");

								
								
								$("#star3").parent().css("display","none");
								$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
								$("#star4").parent().css("display","none");
								$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
								$("#closePlanNotes").parent().parent().css("display","none");

								
								$("#fiduciaryServiceLevel").parent().parent().css("display","none");
								$("#rpainfo").parent().css("display","none");
								$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
								$("#fiduciaryServiceNotes").parent().parent().css("display","none");
								$("#sysfee").parent().css("display","none");
								
								
								$("#star5").parent().css("display","none");
								$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
								$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
								$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
								
								
								$("#addRemoveAfflAddContact").parent().parent().css("display","none");
								$("#addRemoveAfflCompanyName1").parent().parent().css("display","none");
								 $("#addRemoveAfflCompanyName2").parent().parent().css("display","none");
								 $("#addRemoveAfflAttn1").parent().parent().css("display","none");
								 $("#addRemoveAfflAttn2").parent().parent().css("display","none");
								 $("#addRemoveAfflPhone1").parent().parent().css("display","none");
								 $("#addRemoveAfflPhone2").parent().parent().css("display","none");
								 $("#addRemoveAfflAddress1").parent().parent().css("display","none");
								 $("#addRemoveAfflAddress2").parent().parent().css("display","none");
								 $("#addRemoveAfflTaxId1").parent().parent().css("display","none");
								 $("#addRemoveAfflTaxId2").parent().parent().css("display","none");
								 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","none");
								 $("#addRemoveAfflNotes").parent().parent().css("display","none");
								 $("#aff").parent().css("display","none");
								 
				}



                  else if ($(this).val() == "Add/Remove Affiliate/Location")
						
						 {
							$("#addRemoveAfflAddContact").parent().parent().css("display","block");
								$("#addRemoveAfflCompanyName1").parent().parent().css("display","block");
								 $("#addRemoveAfflCompanyName2").parent().parent().css("display","block");
								 $("#addRemoveAfflAttn1").parent().parent().css("display","block");
								 $("#addRemoveAfflAttn2").parent().parent().css("display","block");
								 $("#addRemoveAfflPhone1").parent().parent().css("display","block");
								 $("#addRemoveAfflPhone2").parent().parent().css("display","block");
								 $("#addRemoveAfflAddress1").parent().parent().css("display","block");
								 $("#addRemoveAfflAddress2").parent().parent().css("display","block");
								 $("#addRemoveAfflTaxId1").parent().parent().css("display","block");
								 $("#addRemoveAfflTaxId2").parent().parent().css("display","block");
								 $("#addRemoveAfflLocationToRemove").parent().parent().css("display","block");
								 $("#addRemoveAfflNotes").parent().parent().css("display","block");
								 $("#aff").parent().css("display","block");
							
								
								
								
                            $("#addMoneyType").parent().parent().css("display","none");
						  $("#removeMoneyType").parent().parent().css("display","none");
						  $("#addRemoveMoneyTypeVestingSchedule").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeEffectiveDate").parent().parent().css("display","none");
						 $("#enrollmentBookReorder").parent().parent().css("display","none");
						 $("#addRemoveMoneyTypeNotes").parent().parent().css("display","none");
						 $("#IC").parent().css("display","none");
						 
						 $("#enrollment").parent().css("display","none");
						 $("#enrollBooksDeliveryDate").parent().parent().css("display","none");
						 $("#enrollBooksEngBooksNeeded").parent().parent().css("display","none");
						 $("#enrollBooksSpanBooksNeeded").parent().parent().css("display","none");
						 $("#shipto").parent().css("display","none");
						 $("#enrollBooksShipCompanyName").parent().parent().css("display","none");
						  $("#enrollBooksShipAttn").parent().parent().css("display","none");
						  $("#enrollBooksShipStreet").parent().parent().css("display","none");
						  $("#enrollBooksShipCity").parent().parent().css("display","none");
						 $("#enrollBooksShipState").parent().parent().css("display","none");
						 $("#enrollBooksShipZipCode").parent().parent().css("display","none");
						  $("#enrollBooksNotes").parent().parent().css("display","none");
						  $("#delivery").parent().css("display","none");
						  
						  
						  $("#vestingSchedule").parent().parent().css("display","none");
						  $("#effectiveDateForVestingSchedule").parent().parent().css("display","none");
						  $("#vestingScheduleEnrolBookReOrder").parent().parent().css("display","none");
						   $("#vestingScheduleUpdateNotes").parent().parent().css("display","none");
						   
						   $("#addFunds").parent().parent().css("display","none");
						   $("#removeFunds").parent().parent().css("display","none");
						   $("#fundChangesEffectiveDate").parent().parent().css("display","none");
							$("#fundChangesChangeNotice").parent().parent().css("display","none");
							$("#fundChangesNotes").parent().parent().css("display","none");
							
							$("#loanReqTypes").parent().parent().css("display","none");
							$("#loansEffectiveDate").parent().parent().css("display","none");
							$("#loansGenPurposeYrs").parent().parent().css("display","none");
							$("#loansPayroleFrequency").parent().parent().css("display","none");
							$("#loansMortageYears").parent().parent().css("display","none");
							$("#loanMinAmount").parent().parent().css("display","none");
							$("#loanMaxAmount").parent().parent().css("display","none");
							$("#loansAllowed").parent().parent().css("display","none");
							$("#loanChangeNoticeReq").parent().parent().css("display","none");
							$("#loanNotes").parent().parent().css("display","none");
							
							
							$("#star").parent().css("display","none");
							$('input[name=updatedPlanContactRPA]').parent().parent().parent().css("display","none"); 
							$("#planspon").parent().css("display","none");
							$("#planSponcorName").parent().parent().css("display","none");
							$("#planSponcorPhone").parent().parent().css("display","none");
							$("#planSponcorEmail").parent().parent().css("display","none");
							$("#addcon").parent().css("display","none");
							$("#additionaContactName").parent().parent().css("display","none");
							$("#additionaContactPhone").parent().parent().css("display","none");
							$("#additionaContactEmail").parent().parent().css("display","none");
							$("#pspon").parent().css("display","none");
							$("#planSponsorRemoveName").parent().parent().css("display","none");
							$("#planSponcorRemoveEnrollmentBookReorder").parent().parent().css("display","none");
							$("#planContactNotes").parent().parent().css("display","none");
							$("#addfix").parent().css("display","none");
							
						  
							$("#salesConnectFormDateSubmitted").parent().parent().css("display","none");
							$("#riaServiceProvider").parent().parent().css("display","none");
							$("#riaRepJointName").parent().parent().css("display","none");
							$("#riaRepJointID").parent().parent().css("display","none");
							$("#riaIndividualRepName1").parent().parent().css("display","none");
							$("#riaIndividualRepId1").parent().parent().css("display","none");
							$("#riaIndividualRepName2").parent().parent().css("display","none");
							$("#riaIndividualRepId2").parent().parent().css("display","none");
							$("#star2").parent().css("display","none");
							$('input[name=riaUpdatedPlanContactsRpa]').parent().parent().parent().css("display","none"); 
							$("#riaNotes").parent().parent().css("display","none");
							$("#ria").parent().css("display","none");
							
							
							$("#tpaFeesEffectiveDate").parent().parent().css("display","none");
							$("#tpaFeesLoanFee").parent().parent().css("display","none");
							$("#tpaFeesDistributionFee").parent().parent().css("display","none");
							$("#tpaFeesChangeNeeded").parent().parent().css("display","none");
							$('input[name=tpaFeesRemoveLoanFee]').parent().parent().parent().css("display","none"); 
							$('input[name=tpaFeesRemoveDistributionFee]').parent().parent().parent().css("display","none");
							$("#tpaFeesNotes").parent().parent().css("display","none");	
							$("#rkdfee").parent().css("display","none");

							
							
							$("#star3").parent().css("display","none");
							$('input[name=closePlanWarningNoteInRpa]').parent().parent().parent().css("display","none"); 
							$("#star4").parent().css("display","none");
							$('input[name=closePlanUpdatedStatus]').parent().parent().parent().css("display","none");
							$("#closePlanNotes").parent().parent().css("display","none");

							
							$("#fiduciaryServiceLevel").parent().parent().css("display","none");
							$("#rpainfo").parent().css("display","none");
							$('input[name=wilshirefiduciaryServiceUpdatedInRpa]').parent().parent().parent().css("display","none");
							$("#fiduciaryServiceNotes").parent().parent().css("display","none");
							$("#sysfee").parent().css("display","none");
							
							
							$("#star5").parent().css("display","none");
							$('input[name=planSetupErrorsUpdatesToRpa]').parent().parent().parent().css("display","none");
							$("#planSetupErrorsCorrectiveAction").parent().parent().css("display","none");
							$("#planSetupErrorsEnrollmentBooksReorder").parent().parent().css("display","none");
							
								
							$('input[name=feeLevelRecoveryCommissionable]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryRecapture]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryDollarAmt").parent().parent().css("display","none");
							$("#feeLevelRecoveryBasisPoint").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryFeeInvoice]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForFP]').parent().parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryForTPA]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryFPBasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPABasisPoint").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAProRata").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerCapita").parent().parent().css("display","none");
							$("#feeLevelRecoveryFPPerParticipant").parent().parent().css("display","none");
							$("#feeLevelRecoveryTPAPerParticipant").parent().parent().css("display","none");
							$('input[name=feeLevelRecoveryExternal]').parent().parent().parent().css("display","none");
							$("#feeLevelRecoveryAdvisoryAccNum").parent().parent().css("display","none");
							$("#feelevelrecoveryenrol").parent().parent().css("display","none");
							$("#feeLevelRecoveryNotes").parent().parent().css("display","none");
								 
					}
					
				});
				
			});
	}

/*--------------------------------------------IMAGED SOURCES / IMAGING PROFILE CHANGE REQUEST-------------------------------------------------------*/

							if((document.URL).includes("imaged-sources-imaging-profile-change-request")){
							
				            $("#MULSOURCES").parent().parent().css("display","none");
							$("#ASSO_INITIALS").parent().parent().css("display","none");
							$("#MULSOURCESUP").parent().parent().css("display","none");
							
							
								$('select[name=REQUESTTYPE]').change(function () 
					{
				$("select[name=REQUESTTYPE] option:selected").each(function ()
        	  {
                if ($(this).val() == "Live sources for training" || $(this).val() == "Reinforcement sources") 
				{
				    
							 $("#MULSOURCES").parent().parent().css("display","block");
							$("#ASSO_INITIALS").parent().parent().css("display","block");
							$("#MULSOURCESUP").parent().parent().css("display","none");
			     }	
					
				else if ($(this).val() == "Temporary profile change" || $(this).val() == "Permanent profile change") 
				{
				    
							 $("#MULSOURCES").parent().parent().css("display","none");
							$("#ASSO_INITIALS").parent().parent().css("display","block");
							$("#MULSOURCESUP").parent().parent().css("display","block");
			     }	
							
							
			});
				
	  });
	 }
					



				
				
				
				





/*------------------------------------------------------------RPS Research/Transaction Request ----------------------------------------------------------------------------------*/

		if((document.URL).includes("rps-research-transaction-request")){
		
        $('input[name=plantypeRadio1]').parent().parent().css("display","none");
        $('input[name=hidhelpdesk]').parent().parent().parent().css("display","none");
        $('input[name=rush]').parent().parent().parent().css("display","none");
        $('input[name=planYear]').parent().parent().parent().css("display","none");
        $('input[name=CBandT_Trustee]').parent().parent().parent().css("display","none");
        $('input[name=documentRequested]').parent().parent().parent().css("display","none");

        $('select[name=worktype2]').parent().parent().css("display","none");
        $('select[name=worktype]').parent().parent().css("display","none");



        $("#helpDeskInitials").parent().parent().css("display","none");
    	$("#reportpwd").parent().parent().css("display","none");
        $("#addtionalComment").parent().parent().css("display","none");
        $("#dollaramount").parent().parent().css("display","none");
        $("#payrolldate").parent().parent().css("display","none");
        $("#batchnumber").parent().parent().css("display","none");

        $("#payrollcomments").parent().parent().css("display","none");
    	$("#planenddate").parent().parent().css("display","none");

        $("#important").parent().css("display","none");
        $("#help-desk").parent().css("display","none");

        $("#report-password").parent().css("display","none");
        $("#plan-year").parent().css("display","none");
        $("#cbandt-trustee").parent().css("display","none");
        $("#documents").parent().css("display","none");

        $("#comment-text").parent().css("display","none");
        $("#nigo").parent().css("display","none");

     $('input[name=hidptype]').change(function () 
		{
            $("input[name=hidptype]").each(function ()
        	{
                if ($("input[name=hidptype]:checked").val() == "AFO" ) 
				{
                    $('input[name=plantypeRadio1]').parent().parent().css("display","block");

                }
                else if ($("input[name=hidptype]:checked").val() == "Multifund")
                {
                    $('input[name=plantypeRadio1]').parent().parent().css("display","block");

                }
                else if ($("input[name=hidptype]:checked").val() == "PP/PPTPA")
                {
                    $('input[name=plantypeRadio1]').parent().parent().css("display","none");

                }
            });
        });


    $('input[name=hiddenresolution]').change(function () 
		{
            $("input[name=hiddenresolution]").each(function ()
        	{
                if ($("input[name=hiddenresolution]:checked").val() == "Research") 
				{ $('#hidhelpdesk').removeAttr('checked'); 
                   $('#worktype2').prop("selectedIndex" , 0);
        $("#passwd").parent().parent().css("display","block");
                        $("#situation").parent().parent().css("display","block");
                        $("#actreq").parent().parent().css("display","block");

        $('input[name=plantypeRadio1]').parent().parent().css("display","none");
        $('input[name=hidhelpdesk]').parent().parent().parent().css("display","block");
        $('input[name=rush]').parent().parent().parent().css("display","block");
        $('input[name=planYear]').parent().parent().parent().css("display","none");
        $('input[name=CBandT_Trustee]').parent().parent().parent().css("display","none");
        $('input[name=documentRequested]').parent().parent().parent().css("display","none");

        $('select[name=worktype2]').parent().parent().css("display","block");
        $('select[name=worktype]').parent().parent().css("display","none");



        $("#helpDeskInitials").parent().parent().css("display","none");
    	$("#reportpwd").parent().parent().css("display","none");
        $("#addtionalComment").parent().parent().css("display","none");
        $("#dollaramount").parent().parent().css("display","none");
        $("#payrolldate").parent().parent().css("display","none");
        $("#batchnumber").parent().parent().css("display","none");

        $("#payrollcomments").parent().parent().css("display","none");
    	$("#planenddate").parent().parent().css("display","none");

        $("#important").parent().css("display","block");
        $("#help-desk").parent().css("display","block");

        $("#report-password").parent().css("display","none");
        $("#plan-year").parent().css("display","none");
        $("#cbandt-trustee").parent().css("display","none");
        $("#documents").parent().css("display","none");

        $("#comment-text").parent().css("display","none");
        $("#nigo").parent().css("display","none");

                    $('input[name=hidhelpdesk]').change(function () 
		      {
                  $("input[name=hidhelpdesk]").each(function ()
        	       {


                    if ($("input[name=hidhelpdesk]:checked").val() == "yes")
                    {
                        $("#helpDeskInitials").parent().parent().css("display","block");

                    }
                    else
                    {
                        $("#helpDeskInitials").parent().parent().css("display","none");

                    }
                   });
              });
                    $('select[name=worktype2]').change(function () 
		      {
                 $("select[name=worktype2] option:selected").each(function ()
        	       {


                    if ($(this).val() == "Audit Report")
                    {
                         $('input[name=rush]').parent().parent().parent().css("display","block");
                         $('input[name=planYear]').parent().parent().parent().css("display","block");
                         $('input[name=CBandT_Trustee]').parent().parent().parent().css("display","block");
                         $('input[name=documentRequested]').parent().parent().parent().css("display","block");
                         $("#reportpwd").parent().parent().css("display","block");
                         $("#addtionalComment").parent().parent().css("display","block");
                         $("#planenddate").parent().parent().css("display","block");
                        $("#report-password").parent().css("display","block");
                         $("#plan-year").parent().css("display","block");
                         $("#cbandt-trustee").parent().css("display","block");
                         $("#documents").parent().css("display","block");

                         $("#comment-text").parent().css("display","block");
                        $("#passwd").parent().parent().css("display","none");
                        $("#situation").parent().parent().css("display","none");
                        $("#actreq").parent().parent().css("display","none");
                         $("#file").parent().parent().parent().css("display","none");
                         $("#attachments").parent().css("display","none");
                    }
                    else
                    {
                         $("#file").parent().parent().parent().css("display","block");
                         $("#attachments").parent().css("display","block");
                         $('input[name=rush]').parent().parent().parent().css("display","none")
                         $('input[name=planYear]').parent().parent().parent().css("display","none")
                         $('input[name=CBandT_Trustee]').parent().parent().parent().css("display","none")
                         $('input[name=documentRequested]').parent().parent().parent().css("display","none");
                         $("#reportpwd").parent().parent().css("display","none");
                         $("#addtionalComment").parent().parent().css("display","none");
                         $("#planenddate").parent().parent().css("display","none");
                        $("#report-password").parent().css("display","none");
                         $("#plan-year").parent().css("display","none");
                         $("#cbandt-trustee").parent().css("display","none");
                         $("#documents").parent().css("display","none");

                         $("#comment-text").parent().css("display","none");
                        $("#passwd").parent().parent().css("display","block");
                        $("#situation").parent().parent().css("display","block");
                        $("#actreq").parent().parent().css("display","block");


                    }
                   });
              });


    }

                else if ($("input[name=hiddenresolution]:checked").val() == "Transaction") 
                { $('#worktype').prop("selectedIndex" , 0);
         $("#attachments").parent().css("display","block");
        $("#file").parent().parent().parent().css("display","block");
        $("#passwd").parent().parent().css("display","block");
                        $("#situation").parent().parent().css("display","block");
                        $("#actreq").parent().parent().css("display","block");
        $('input[name=plantypeRadio1]').parent().parent().css("display","none");
        $('input[name=hidhelpdesk]').parent().parent().parent().css("display","none");
        $('input[name=rush]').parent().parent().parent().css("display","none");
        $('input[name=planYear]').parent().parent().parent().css("display","none");
        $('input[name=CBandT_Trustee]').parent().parent().parent().css("display","none");
        $('input[name=documentRequested]').parent().parent().parent().css("display","none");

        $('select[name=worktype2]').parent().parent().css("display","none");
        $('select[name=worktype]').parent().parent().css("display","block");



        $("#helpDeskInitials").parent().parent().css("display","none");
    	$("#reportpwd").parent().parent().css("display","none");
        $("#addtionalComment").parent().parent().css("display","none");
        $("#dollaramount").parent().parent().css("display","none");
        $("#payrolldate").parent().parent().css("display","none");
        $("#batchnumber").parent().parent().css("display","none");

        $("#payrollcomments").parent().parent().css("display","none");
    	$("#planenddate").parent().parent().css("display","none");

        $("#important").parent().css("display","none");
        $("#help-desk").parent().css("display","none");

        $("#report-password").parent().css("display","none");
        $("#plan-year").parent().css("display","none");
        $("#cbandt-trustee").parent().css("display","none");
        $("#documents").parent().css("display","none");

        $("#comment-text").parent().css("display","none");
        $("#nigo").parent().css("display","none");

         

      }

    });
  });
     $('select[name=worktype]').on('input', function()    
		      {
                 $("select[name=worktype] option:selected").each(function ()
        	       {


                    if ($(this).val() == "Earnings Payroll")
                    {
                    $("#dollaramount").parent().parent().css("display","block");
                    $("#payrolldate").parent().parent().css("display","block");
                    $("#batchnumber").parent().parent().css("display","block");

                     $("#payrollcomments").parent().parent().css("display","block");
                        $("#situation").parent().parent().css("display","none");
                        $("#actreq").parent().parent().css("display","none");
                    }
                    else if ($(this).val() == "NIGO")
                    {


                       $("#dollaramount").parent().parent().css("display","none");
                    $("#payrolldate").parent().parent().css("display","none");
                    $("#batchnumber").parent().parent().css("display","none");

                     $("#payrollcomments").parent().parent().css("display","none");
                            $("#situation").parent().parent().css("display","block");
                        $("#actreq").parent().parent().css("display","block");
                        $("#nigo").parent().css("display","block");

                    }
                     else if ($(this).val() == "Web Walk-Through" )
                     {    
                         alert("For RUSH Web Walk-Through requests, please contact Client Services and do not complete this form.");
                        $("#dollaramount").parent().parent().css("display","none");
                    $("#payrolldate").parent().parent().css("display","none");
                    $("#batchnumber").parent().parent().css("display","none");

                     $("#payrollcomments").parent().parent().css("display","none");
                            $("#situation").parent().parent().css("display","block");
                        $("#actreq").parent().parent().css("display","block");
                       $("#nigo").parent().css("display","none");
                     }
                       else
                       {
                            $("#dollaramount").parent().parent().css("display","none");
                    $("#payrolldate").parent().parent().css("display","none");
                    $("#batchnumber").parent().parent().css("display","none");

                     $("#payrollcomments").parent().parent().css("display","none");
                            $("#situation").parent().parent().css("display","block");
                        $("#actreq").parent().parent().css("display","block");
                       $("#nigo").parent().css("display","none");

                       }

                    });
              });
        }


/*------------------------------------------------------------Share Requirements ----------------------------------------------------------------------------------*/

		
		
    function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

            var today = new Date();
            var month = today.getMonth() + 1;
            if(month < 10) {
                month = "0" + month;
            }
            var day = today.getDate();
            if(day < 10) {
                day = "0" + day;
            }
            var year = today.getFullYear() - 2000;
            var dateString = month + "/" + day + "/" + year;
            return dateString;
        }

     $("#dateSubmitted").prop( "value", currDate() );
	 $("#dateSubmitted").prop('disabled', true);
	 $("#dateSubmitted").css('border','none');
	 

/*------------------------------------------------------------TRAC/OGI request----------------------------------------------------------------------------------*/

	if((document.URL).includes("trac-ogi-web-resolution-checklist")){
	
    $("#OTHEROPEROSHIDDEN").parent().parent().css("display","none");
    $("#OTHERBROWSERHIDE").parent().parent().css("display","none");
    $('select[name=OPERATINGSYSTEM]').change(function () 
		      {
                 $("select[name=OPERATINGSYSTEM] option:selected").each(function ()
        	       {


                    if ($(this).val() == "Other")
                    {
                        $("#OTHEROPEROSHIDDEN").parent().parent().css("display","block");
                    }
                    else
                       {
                           $("#OTHEROPEROSHIDDEN").parent().parent().css("display","none");
                       }
                   });
              });

    $('select[name=BROWSER]').change(function () 
		      {
                 $("select[name=BROWSER] option:selected").each(function ()
        	       {


                    if ($(this).val() == "Other")
                    {
                       $("#OTHERBROWSERHIDE").parent().parent().css("display","block");
                    }
                    else
                       {
                         $("#OTHERBROWSERHIDE").parent().parent().css("display","none");
                       }
                   });
              });
			  
			  }
			  
/*----------------------------------------------------OGI ID REQUEST-----------------------------------------------------------------*/

			if((document.URL).includes("ogi-id-request")){
			
			$("#CONTACTNAME").parent().parent().css("display","none");
			$("#PREVIOUSNAME").parent().parent().css("display","none");
			$("#NEWNAME").parent().parent().css("display","none");
			
			 $('select[name=REQUESTTYPE]').change(function () 
		{
            $("select[name=REQUESTTYPE] option:selected").each(function ()
        	{
                if ($(this).val() == "DELETE OGI ID"  ) 
				{   
			        
					$("#CONTACTNAME").parent().parent().css("display","block");
					
					
					$("#PREVIOUSNAME").parent().parent().css("display","none");
					$("#NEWNAME").parent().parent().css("display","none");
								
                     
                }

                else if($(this).val() == "CONTACT NAME CHANGE" ) 
		{
	           
			       $("#PREVIOUSNAME").parent().parent().css("display","block");
					$("#NEWNAME").parent().parent().css("display","block");
				
				
				$("#CONTACTNAME").parent().parent().css("display","none");
				
		
		

                }

               });
           });
	}
	
/*----------------------------------------------------------------TRAC2000 BATCH TICKET--------------------------------------------------------*/

				if((document.URL).includes("trac2000-batch-ticket")){

                $('[name^="planid_trac"]').attr("maxlength","10");
    			$('[name^="check_trac2"]').attr("maxlength","15");
				$('select[name=site2]').change(function () 
		{
            $("select[name=site2] option:selected").each(function ()
        	{
                if ($(this).val() == "IRV") 
				{   
				  alert('You selected IRV. Is that correct?');

				 }
				 else if ($(this).val() == "SNO")
				 {   
				  alert('You selected SNO. Is that correct?');
				  
				 }
				  else if ($(this).val() == "IND")
				 {   
				  alert('You selected IND. Is that correct?');
				  
				 }
				  else if ($(this).val() == "HRO")
				 {   
				  alert('You selected HRO. Is that correct?');
				  
				 }
			});
			
		  });
		  
		  
		  $('select[name=SOURCETYPE]').change(function () 
		{
            $("select[name=SOURCETYPE] option:selected").each(function ()
        	{
                if ($(this).val() == "Email") 
				{   
				  alert('You selected E-mail. Is that correct?');

				 }
				 else if ($(this).val() == "Imaged")
				 {   
				  alert('You selected Imaged. Is that correct?');
				  
				 }
				  else if ($(this).val() == "Paper")
				 {   
				  alert('You selected Paper. Is that correct?');
				  
				 }
				 
			});
			
		  });
		  
		  
		  	$('select[name=site]').change(function () 
		{
            $("select[name=site] option:selected").each(function ()
        	{
                if ($(this).val() == "IRV") 
				{   
				  alert('You selected IRV. Is that correct?');

				 }
				 else if ($(this).val() == "SNO")
				 {   
				  alert('You selected SNO. Is that correct?');
				  
				 }
				  else if ($(this).val() == "IND")
				 {   
				  alert('You selected IND. Is that correct?');
				  
				 }
				  else if ($(this).val() == "HRO")
				 {   
				  alert('You selected HRO. Is that correct?');
				  
				 }
			});
			
		  });
		  
		  $("#follow").parent().css("display","none");
				
				$("#accountTable").parent().parent().parent().css("display","none");
				
				$("#file").parent().parent().css("display","none");
				
				
				
				 $("#accountTable").css("width","60%");
				
				 $('input[name=PAYMENT_TYPES]').change(function ()
                     {
					
					 $("input[name=PAYMENT_TYPES]:checked").each(function ()
                        {
                            if ($("input[name=PAYMENT_TYPES]:checked").val() == "ACH")
                            {
							
								$("#deposit_total").parent().parent().css("display","block");
								$("#follow").parent().css("display","none");
								$("#file").parent().parent().css("display","none");
				
								$("#accountTable").parent().parent().parent().css("display","none");
                            }
							else if ($("input[name=PAYMENT_TYPES]:checked").val() == "CHECK")
                            {
								$("#follow").parent().css("display","none");
				
								$("#accountTable").parent().parent().parent().css("display","block");
								$("#file").parent().parent().css("display","none");
								
                            }
							
							else if ($("input[name=PAYMENT_TYPES]:checked").val() == "WIRE")
                            {
								$("#follow").parent().css("display","block");
				
								$("#accountTable").parent().parent().parent().css("display","none");
								$("#file").parent().parent().css("display","block");
								
                            }
                    		
                        });
                     });
				
		  
	}

/*---------------------------------------cdsc  fees----------------------------------------------------------------------------------------------*/

			if((document.URL).includes("cdsc-payment-to-funds-form")){
			
			$('select[name=SITE]').change(function () 
		{
            $("select[name=SITE] option:selected").each(function ()
        	{
                if ($(this).val() == "IRV") 
				{   
				  alert('You selected IRV. Is that correct?');

				 }
				 else if ($(this).val() == "SNO")
				 {   
				  alert('You selected SNO. Is that correct?');
				  
				 }
				  else if ($(this).val() == "IND")
				 {   
				  alert('You selected IND. Is that correct?');
				  
				 }
				  else if ($(this).val() == "HRO")
				 {   
				  alert('You selected HRO. Is that correct?');
				  
				 }
			});
			
		  });
		  
	}
	
/*-------------------------------------------------RKD MULTI-FUND LARGE TRADE NOTIFICATION FORM-------------------------------------------------*/

		if((document.URL).includes("rkd-multi-fund-large-trade-notification-form")){

			$("#fund1").parent().parent().css("display","none");
			$("#s1").parent().css("display","none");
			$("#amount1").parent().parent().css("display","none");
			$("#t1").parent().css("display","none");
			$('input[name=addl1]').parent().parent().parent().css("display","none");
			
			$("#fund2").parent().parent().css("display","none");
			$("#s2").parent().css("display","none");
			$("#amount2").parent().parent().css("display","none");
			
			
			$('input[name=addl]').change(function () 
                     {
					 
					 $("input[name=addl]:checked").each(function ()
                       
                        {
                            if ($("input[name=addl]:checked").val() == "no") 
                            {
							
								$("#fund1").parent().parent().css("display","none");
								$("#s1").parent().css("display","none");
								$("#amount1").parent().parent().css("display","none");
								$("#t1").parent().css("display","none");
								$('input[name=addl1]').parent().parent().parent().css("display","none");
								
								$("#fund2").parent().parent().css("display","none");
								$("#s2").parent().css("display","none");
								$("#amount2").parent().parent().css("display","none");
                                

                            }
							else if ($("input[name=addl]:checked").val() == "yes") 
                            {
							
								$("#fund1").parent().parent().css("display","block");
								$("#s1").parent().css("display","block");
								$("#amount1").parent().parent().css("display","block");
								$("#t1").parent().css("display","block");
								$('input[name=addl1]').parent().parent().parent().css("display","block");
								
								
								$("#fund2").parent().parent().css("display","none");
								$("#s2").parent().css("display","none");
								$("#amount2").parent().parent().css("display","none");
                                

                            }

                    		
                        });
                     });
			
			 
			
					$('input[name=addl1]').change(function () 
                     {
                        $("input[name=addl1]:checked").each(function ()
                        {
                            if ($("input[name=addl1]:checked").val() == "no") 
                            {
							
								$("#fund1").parent().parent().css("display","block");
								$("#s1").parent().css("display","block");
								$("#amount1").parent().parent().css("display","block");
								$("#t1").parent().css("display","block");
								$('input[name=addl1]').parent().parent().parent().css("display","block");
								
								$("#fund2").parent().parent().css("display","none");
								$("#s2").parent().css("display","none");
								$("#amount2").parent().parent().css("display","none");
                                

                            }
							else if ($("input[name=addl1]:checked").val() == "yes") 
                            {
							
								$("#fund1").parent().parent().css("display","block");
								$("#s1").parent().css("display","block");
								$("#amount1").parent().parent().css("display","block");
								$("#t1").parent().css("display","block");
								$('input[name=addl1]').parent().parent().parent().css("display","block");
								
								
								$("#fund2").parent().parent().css("display","block");
								$("#s2").parent().css("display","block");
								$("#amount2").parent().parent().css("display","block");
                                

                            }

                    		
                        });
                     });
					 
	}
	
/*------------------------------------------Batch Ticket Investment---------------------------------------------*/

		if((document.URL).includes("batch-ticket-investment")){
		
			$("#MANUALCHECK").parent().parent().css("display","none");
            $("#manualCheckAccount").parent().parent().css("display","none");
            $("#man1").parent().css("display","none");
            $("#manualCheckFund").parent().parent().css("display","none");

        $('#depositTotal').on('blur', function(){ 
        if ( $("#outOfBalanceReadOnly").val() > 0 )
        {
            $("#MANUALCHECK").parent().parent().css("display","block");
            $("#manualCheckAccount").parent().parent().css("display","block");
            $("#man1").parent().css("display","block");
            $("#manualCheckFund").parent().parent().css("display","block");
            $("#MANUALCHECK").attr('checked','true');


        }
        else {

             $("#MANUALCHECK").parent().parent().css("display","none");
            $("#manualCheckAccount").parent().parent().css("display","none");
            $("#man1").parent().css("display","none");
            $("#manualCheckFund").parent().parent().css("display","none");
        }

 });



        $(document).on('blur', '[name^="amtdemo"]', function () {

        if ( $("#outOfBalanceReadOnly").val() > 0 )
        {
            $("#MANUALCHECK").parent().parent().css("display","block");
            $("#manualCheckAccount").parent().parent().css("display","block");
            $("#man1").parent().css("display","block");
            $("#manualCheckFund").parent().parent().css("display","block");
             $("#MANUALCHECK").attr('checked','true');

        }
        else {

             $("#MANUALCHECK").parent().parent().css("display","none");
            $("#manualCheckAccount").parent().parent().css("display","none");
            $("#man1").parent().css("display","none");
            $("#manualCheckFund").parent().parent().css("display","none");
        }

 });
 
 $("#APPROVER").parent().parent().css("display","none");
          $("#L1").parent().css("display","none");
        $('#REASONCODE').on('blur', function(){

          if($(this).val().length>0)
          {
         $("#APPROVER").parent().parent().css("display","block");
          $("#L1").parent().css("display","block");
          }
         else
         {
            $("#APPROVER").parent().parent().css("display","none");
          $("#L1").parent().css("display","none");

         }
});
 }
 
 /*---------------------------------------online batch ticket-------------------------------------------------------------------*/
 
 if((document.URL).includes("online-batch-ticket")){
 
 function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

            var today = new Date();
            var month = today.getMonth() + 1;
            if(month < 10) {
                month = "0" + month;
            }
            var day = today.getDate();
            if(day < 10) {
                day = "0" + day;
            }
            var year = today.getFullYear();
            var dateString = year + "-" + month + "-" + day;
            return dateString;
        }

$('input[name=ucd]').change(function () 
		 {
             $("input[name=ucd]").each(function ()
        	{
                  if ($("input[name=ucd]:checked").val() == "Use Current Date") 
				{ 
    	             $("#payroll").prop( "value", currDate() );

					}

                else if($("input[name=ucd]:checked").val() == undefined) 
				{ 
    	             $("#payroll").prop( "value", "" );

					}
				 
				 });
				 
				 });
				 
		}
		
/*------------------------------------------------------loan-re-amortization-request------------------------------------------------------*/

	if((document.URL).includes("loan-re-amortization-request")){

		function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

            var today = new Date();
            var month = today.getMonth() + 1;
            if(month < 10) {
                month = "0" + month;
            }
            var day = today.getDate();
            if(day < 10) {
                day = "0" + day;
            }
            var year = today.getFullYear();
            var dateString = year + "-" + month+ "-" + day;
            return dateString;
        }

$('input[name=nochg]').change(function () 
		 {
             $("input[name=nochg]").each(function ()
        	{
                  if ($("input[name=nochg]:checked").val() == "No Change") 
				{ 
    	             $("#matdate").prop( "value", currDate() );

					}

                else if($("input[name=nochg]:checked").val() == undefined) 
				{ 
    	             $("#matdate").prop( "value", "" );

					}
				 
				 });
				 
				 });
				 
		}
		
/*-----------------------------------------------------------------RPS Phone Message Form------------------------------------------------------------*/

						if((document.URL).includes("rkd-phone-message-form")){
						
						
$("#to").parent().css("display","none");
$("#wfr").parent().parent().css("display","none");
$("#recipinits").parent().parent().css("display","block");
$("#recipientManager").parent().parent().css("display","block");

$('input[name=thismessage]').change(function () 
		{
            $("input[name=thismessage]").each(function ()
        	{
                if ($("input[name=thismessage]:checked").val() == "normal") 
				{
                                  $("#to").parent().css("display","none");
                                  $("#wfr").parent().parent().css("display","none");
                                 $("#recipinits").parent().parent().css("display","block");
                                  $("#recipientManager").parent().parent().css("display","block");
                                   $('#callType').prop("selectedIndex" , 0);
                                 }
                else if ($("input[name=thismessage]:checked").val() == "Workflow") 
                                 {
                                  $("#to").parent().css("display","block");
                                  $("#wfr").parent().parent().css("display","block");
                                 $("#recipinits").parent().parent().css("display","none");
                                  $("#recipientManager").parent().parent().css("display","none");
                                  $('#callType').prop("selectedIndex" , 0);
                                 }
                else if ($("input[name=thismessage]:checked").val() == "websme") 
                                 {
                                  $("#to").parent().css("display","none");
                                 $("#wfr").parent().parent().css("display","none");
                                 $("#recipinits").parent().parent().css("display","none");
                                  $("#recipientManager").parent().parent().css("display","none");
                                   $('#callType').prop("value" , 'Callback required');
                                
                                 }
                else if ($("input[name=thismessage]:checked").val() == "webPPTPA")
                              {
                                $("#to").parent().css("display","none");
                                 $("#wfr").parent().parent().css("display","none");
                                 $("#recipinits").parent().parent().css("display","none");
                                  $("#recipientManager").parent().parent().css("display","none");
                                 $('#callType').prop("selectedIndex" , 0);
                                   
                               }
  });
});
					 
					 }
					 
	/* -------- Copy of Cashed check Request ------------*/				 
					 
	function deltaDate(input, days, months, years) {
    return new Date(
      input.getFullYear() + years, 
      input.getMonth() + months, 
      Math.min(
        input.getDate() + days,
        new Date(input.getFullYear() + years, input.getMonth() + months + 1, 0).getDate()
      )
    );
}
function currDate() { // THIS FUNCTION RETRIEVES AND RETURNS SYSTEM DATE (mm/dd/yyyy) 

            var today = new Date();
            var month = today.getMonth() + 1;
            if(month < 10) {
                month = "0" + month;
            }
            var day = today.getDate();
            if(day < 10) {
                day = "0" + day;
            }
            var year = today.getFullYear() - 2000;
            var dateString = month + "/" + day + "/" + year;
            return dateString;
        }
       var date = deltaDate(new Date(), 0, 0, -7).toString();
        
        $("#dateSubmitted-2").val(date.substring(4,10) + "," + date.substring(10,15));
         $("#dateSubmitted-1").val(currDate());
        $("#dateSubmitted-2").prop('disabled', true);
	$("#text-date").children().css("color","#8a6d3b").css('font-size', '14px');
        $("#text-date").parent().css('width','152px');
        $("#dateSubmitted-1").prop('disabled', true);
	$("#dateSubmitted-1").css('border','none').css('font-size', '14px').css("padding-left","0px").css("color","#8a6d3b");
					 
    });