$(document).ready(function () {


      function incrementRowsp() {
        var rowCount = $("#accountTablesp > tbody > tr").length;
        for (i = 2; i <= rowCount; i++) {
          $("#accountTablesp > tbody > tr").eq(i - 1).find("td:first-child").text(i);
          if (rowCount > 1) {
            $("#accountTablesp > tbody > tr:first-child > td:last-child #Delete-fundssp").removeClass('dlt-display').addClass('Delete-funds');
          }
        }
      }
      $('#AddFundsBtn-sp').on('click', function () {
          console.log("hi");
        $("<tr><td  class='sNo'></td><td> <input class='input-fields account' type='text' id='account' name='account' maxlength='15' style='width:90px'></td><td> <input class='input-fields' type='text' id= 'funds' name='funds' style='width:90px'></td><td> <input class='input-fields damount' type='text' id='damount' name='damount' maxlength='10' style='width:90px'></td><td> <select name='dType' id='dType' class='select-fields' style='width:114px'><option value=''>-Select-</option><option value='Dollars'>Dollars (Gross)</option><option value='Shares'>Shares</option><option value='Tax'>After Tax(net)</option><option value='All'>All</option></select></td><td> <input class='input-fields federal' type='text' id='federal' name='federal' maxlength='10' style='width:90px'></td><td><select name='fType' id='fType' class='select-fields' style='width:114px'><option value=''>-Select-</option> <option value='None'>None</option><option value='Dollars'>Dollars</option><option value='Percent'>Percent</option><option value='Default W/H'>Default W/H</option></select></td><td> <input class='input-fields state' type='text' id='state' name='state' maxlength='10' style='width:90px'></td><td><select name='sType' id='sType' class='select-fields' style='width:114px'><option value=''>-Select-</option> <option value='None'>None</option><option value='Dollars'>Dollars</option><option value='Percent'>Percent</option><option value='Default W/H'>Default W/H</option></select></td><td><button id='Delete-fundssp' class='Delete-funds' ></button></td></tr>").insertAfter('#accountTablesp > tbody > tr:last-child');
        incrementRowsp();
      });
      $(document).on('click', '#Delete-fundssp', function () {
        deleteAccountRowsp($(this).parent().parent());
      });
      function deleteAccountRowsp(parent) {
        $(parent).remove();
        var rowCount = $("#accountTablesp > tbody > tr").length;
        if (rowCount == 1) {
          $("#accountTablesp > tbody > tr:first-child > td:last-child #Delete-fundssp").addClass('dlt-display').removeClass('Delete-funds');
        }
        for (i = 1; i <= rowCount; i++) {
          var count = 1;
          $('#accountTablesp > tbody > tr').each(function () {
            $(this).find('td.sNo').text(count);
            count++;
          })
        }
      }
    $(document).on('input','.account', function(){
       $(".account").attr("maxlength","15");
       var len = $(this).val().length;

       var ch = $(this).val();
      

       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
    $(document).on('input','.damount', function(){

       var len = $(this).val().length;

       var ch = $(this).val();


       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
$(document).on('input','.federal', function(){

       var len = $(this).val().length;

       var ch = $(this).val();


       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
    $(document).on('input','.state', function(){

       var len = $(this).val().length;

       var ch = $(this).val();


       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
    });
