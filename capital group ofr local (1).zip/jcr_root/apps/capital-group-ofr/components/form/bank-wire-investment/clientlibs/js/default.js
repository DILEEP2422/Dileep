$(document).ready(function () {
    	var selector=document.querySelector(".container-config2");
		var val1=selector.getAttribute("data-properties");

      $(document).on('blur', '#account', function () {
        $(this).parent().parent().parent().parent().parent().parent().find('#accountText').text(($(this).val()));
      });

    	$(window).keydown(function(event){
        if(event.keyCode == 13) {
          event.preventDefault();
          return false;
        }
      });

    $.fn.digits = function(){ 
    return this.each(function(){ 
        $(this).text( $(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") ); 
    })
}
    $(document).on('focus', '[name^="damount"]', function () {
         $(this).maskMoney({ prefix:'$',allowEmpty:false});

    });

    $(document).on('focus', '[name^="dolamount"]', function () {
         $(this).maskMoney({ prefix:'$',allowEmpty:false});

    });


	$(document).on('blur', '[id^="damount"]', function () {
		$(this).maskMoney({ prefix:'$',allowEmpty:false});
        var acct=$(this).attr("id");
        var target=acct[acct.length-3];
        sumData(target);
        sum1Data();
    });

     function sumData(testit) {
        var target=testit;
        var fetchId="damount"+target;
        var total=".totalAmount"+(target);
        var sum1=0;

          $("[id^="+fetchId+"]").each(function () {

              var format = $(this).val().replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '');
              sum1+=Number(format);
              dispSum=(sum1).toFixed(2);
          });
         	$(total).text(dispSum);
         	$(total).digits();
        }

    function sum1Data() {

        var sum1=0;

          $( '[id^="damount"]').each(function () {

              var format = $(this).val().replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '');
              sum1+=Number(format);
              dispSum=(sum1).toFixed(2);
          });
        	$('#totalDisplay').html(dispSum);
        	$('#totalDisplay').digits()
        }

      function incrementSno(parent) {
        if (parent) {

            if(val1 === 'bank_wire') {
                 $("<tr><td  class='sNo'></td><td> <input class='input-fields funds' type='text' name='funds' maxlength='5' required></td><td> <input class='input-fields damount' type='text' name='damount' maxlength='15' required></td><td><select class='select-fields fundtype' type='text' id='fundtype1-1' name='fundtype' style='width:230px' required><option value=''>-Select-</option></select></td><td><button id='Delete' class='Delete-funds1'></button></td></tr>").insertAfter($(parent).find("#fundsTable > tbody > tr:last-child"));
                var rowCount = $(parent).children().find($("#fundsTable > tbody > tr")).length;

				var total=$(parent).find('[id^="totalAmount"]').attr("id");
                var dynId=total[total.length-1];

                for (i = 2; i <= rowCount; i++) {
                    $(parent).find(".funds").eq(i - 1).attr('id', "funds"+dynId+"-" + (i));
                    $(parent).find(".damount").eq(i - 1).attr('id', "damount"+dynId+"-" + (i));
                    $(parent).find(".fundtype").eq(i - 1).attr('id', "fundtype"+dynId+"-" +(i));
                    $(parent).find("#fundsTable > tbody > tr").eq(i - 1).find("td.sNo").text(i);
                    if (rowCount > 1) {
                        $(parent).find("#fundsTable > tbody > tr:first-child > td:last-child #Delete").removeClass('dlt-display').addClass('Delete-funds1');
                    }
                }
            } else {
				$("<tr><td class='sNo'></td><td> <input class='input-fields funds' type='text' id='copyFunds-1' name='funds' maxlength='5' required></td><td> <select class='select-fields bankAccount' type='text' id='bankAccount-1' name='bankAccount' style='width:230px' required><option value=''>Select Account Type</option></select></td><td> <input class='input-fields check' type='text' id='check-1' name='check' required></td><td> <input class='input-fields dolamount' type='text' id='dolamount1-1' name='dolamount' required></td> <td> <input class='input-fields date' type='date' id='date-1' name='date' required></td><td><button id='Delete' class='Delete-funds1'></button></td></tr>").insertAfter($(parent).find("#fundsTable > tbody > tr:last-child"));

                var rowCount = $(parent).children().find($("#fundsTable > tbody > tr")).length;
                var total=$(parent).attr("id");

                var dynId=total[total.length-1];

                for (i = 2; i <= rowCount; i++) {
                    $(parent).find(".funds").eq(i - 1).attr('id', "copyFunds"+dynId + (i));
                    $(parent).find(".bankAccount").eq(i - 1).attr('id', "bankAccount"+dynId+"-" + (i));
                    $(parent).find(".check").eq(i - 1).attr('id', "check"+dynId+"-"  + (i));
                    $(parent).find(".dolamount").eq(i - 1).attr('id', "dolamount" +dynId+"-"+(i));
                    $(parent).find(".date").eq(i - 1).attr('id', "date"+ dynId+"-" + (i));
                    $(parent).find("#fundsTable > tbody > tr").eq(i - 1).find("td.sNo").text(i);
                    if (rowCount > 1) {
                        $(parent).find("#fundsTable > tbody > tr:first-child > td:last-child #Delete").removeClass('dlt-display').addClass('Delete-funds1');
                    }
                }
            }
        }
        if (parent == undefined) {
          var accountTableCount = $('#accountWrapper .accountTable').length;
          for (i = 1; i <= accountTableCount; i++) {
            var count = 1;
            $('#accountWrapper #accountTable-' + i).find('#fundsTable > tbody > tr').each(function () {
              $(this).find('td.sNo').text(count);
              count++;
            })
            if(Number(count-1) == 1) {
                $('#accountWrapper #accountTable-' + i).find('#fundsTable > tbody > tr:first-child > td:last-child #Delete').addClass('dlt-display');
               // $("#fundsTable > tbody > tr:first-child > td:last-child #Delete").addClass('dlt-display').removeClass('Delete-funds1');

			}
          }

        }
      }

      function incrementAcoNo() {
        var rowCount = $(".accountTable > .account-count").length;
        for (i = 1; i <= rowCount; i++) {
          $(".accountTable").eq(i - 1).attr('id', "accountTable-" + (i - 1));
          $(".accountTable > .account-count").eq(i - 1).find(".accountNo").text(i - 1);            
		  $(".account-total").eq(i-1).find('[name^="totalAmount"]').attr("class","totalAmount"+ (i-1)).attr("id","totalAmount"+ (i-1));
          $("#accountTable-" + (i - 1)).find('[name^="acctype"]').attr("id","acctype-" + (i-1));
          $("#accountTable-" + (i - 1)).find('[name^="contribtype"]').attr("id","contribtype" + (i-1));
          $("#accountTable-" + (i - 1)).find('[name^="accountType"]').attr("id","accountType-" + (i-1));

          if (rowCount > 1) {
            $('.accountTable').find('#deleteAccount').removeClass('dlt-display').addClass('Delete-funds1');
          }
            var last=$(".account-total").eq(rowCount-1).find('[name^="totalAmount"]').attr("id");
            var total=$(".account-total").eq(i-1).find('[name^="totalAmount"]').attr("id");
            var dynId=total[total.length-1];
            var temp1="accountTable-"+dynId
            $("#"+temp1).find(".damount").attr('id', "damount"+ dynId +"-"+ (1));
            $("#"+temp1).find(".fundtype").attr('id', "fundtype"+ dynId +"-"+ (1));


            var idAcc=$(".accountTable").eq(rowCount - 1).attr("id");
			if(idAcc!=undefined)
            {
            	var dynId1=idAcc[idAcc.length-1];
            	var temp2="accountTable-"+dynId1;
                $("#"+temp2).find(".dolamount").attr('id', "dolamount"+ dynId1 +"-"+ (1));
                $("#"+temp2).find(".bankAccount").attr('id', "bankAccount"+ dynId1 +"-"+ (1));

            }




        }
          $(".account-total").eq(rowCount-1).find('[name^="totalAmount"]').text("0.00");
      }
      $('#NewAccountBtn').on('click', function () {
        var accountTableMarkup = $('#accountTableCloneWrapper').clone();
        $(accountTableMarkup).find(".accountTable").removeClass('display').appendTo("#accountWrapper");
        incrementAcoNo();
      });
      $(document).on('click', '.Add-Fund-Btn', function () {
        incrementSno($(this).parent().parent().parent());
      });
      $(document).on('click', '#Delete', function () {
        deleteFundsRow($(this).parent().parent());
		var acct=$(this).parent().parent().find(".damount").attr("id");
        if(acct!=undefined)
        {
        	var target=acct[acct.length-3];
        }
        incrementSno();
        if(acct!=undefined)
        {
        	sumData(target)
       	 	sum1Data();
        }
      });
      function deleteFundsRow(parent) {
        $(parent).remove();
      }
      function removeAccount() {
        var accountCount = $('#accountWrapper .accountTable').length;
        for (i = 1; i <= accountCount; i++) {
          $(".accountTable").eq(i).attr('id', "accountTable-" + (i));
          $(".accountTable > .account-count").eq(i).find(".accountNo").text(i);
          $(".account-total").eq(i).find('[name^="totalAmount"]').attr("class","totalAmount"+ (i)).attr("id","totalAmount"+ (i));
		  $("#accountTable-" + (i)).find('[name^="acctype"]').attr("id","acctype-" + (i));
          $("#accountTable-" + (i)).find('[name^="contribtype"]').attr("id","contribtype" + (i));
          $("#accountTable-" + (i)).find('[name^="accountType"]').attr("id","accountType-" + (i));
          if (accountCount  <2) {
          $('.accountTable').find('#deleteAccount').addClass('dlt-display').removeClass('Delete-funds1');

        }
            var total=$(".account-total").eq(i).find('[name^="totalAmount"]').attr("id");
            var dynId=total[total.length-1];
            var temp1="accountTable-"+dynId;
            $("#"+temp1).find(".damount").attr('id', "damount"+ dynId +"-"+ (1));
            $("#"+temp1).find(".fundtype").attr('id', "fundtype"+ dynId +"-"+ (1));

            var idAcc=$(".accountTable").eq(accountCount).attr("id");
            if(idAcc!=undefined)
            {
            	var dynId1=idAcc[idAcc.length-1];
            	var temp2="accountTable-"+dynId1;
                $("#"+temp2).find(".dolamount").attr('id', "dolamount"+ dynId1 +"-"+ (1));
                $("#"+temp2).find(".bankAccount").attr('id', "bankAccount"+ dynId1 +"-"+ (1));

            }
        }
      }

      $(document).on('click', '#deleteAccount', function () {
        deleteAccount($(this).parent().parent());
        removeAccount();
        sum1Data();
      });

      function deleteAccount(parent) {
        $(parent).remove();
      }
    $(document).on('input','.accNumm', function(){

       var len = $(this).val().length;
	$(this).attr("maxlength","12")
       var ch = $(this).val();


       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});
    $(document).on('input','[name=alpha-code]', function(){
    $(this).attr("maxlength","10")
});

    $(document).on('input','.funds', function(){

       var len = $(this).val().length;
	$(this).attr("maxlength","5")
       var ch = $(this).val();


       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});

    $(document).on('input','.check', function(){

       var len = $(this).val().length;
	$(this).attr("maxlength","10")
       var ch = $(this).val();


       var regex = /^[0-9]*$/;

        if(!regex.test(ch))
        {
            $(this).val(ch.substring(0,len-1));
        }

});

     $(document).on("click", "[name='submit-btn']", function (e) {
		if($("#WIRETOTAL").val()!=undefined)
        {
            var totaldisp1=Number($('#WIRETOTAL').val().replace(/[&\/\\#,+()$~%'":*?<>{}]/g, ''));
            var prototal1=Number($("#totalDisplay").text().replace(/[&\/\\#,+()$~%'":*?<>{}]/g, ''));
            if(totaldisp1!=prototal1)
            {
                var check=confirm('The Processing Total does not match the Deposit Total. Are the amounts correct? \n Click OK to SUBMIT FORM \n Click Cancel to GO BACK TO REVIEW');
                if(check==false){
                    e.preventDefault();
                }
            }
        }
	});

    });