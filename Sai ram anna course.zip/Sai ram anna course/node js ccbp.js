https://www.npmjs.com/

https://expressjs.com/

Introduction to Node JS | Cheat Sheet:
-----------------------------------------------------------------------

Concepts in Focus:
----------------------------

MERN Stack

Node JS

Running JavaScript Using Node JS:

Node REPL (Read-Eval-Print-Loop)
Node CLI

Module:

Common JS Module Exports
Modern JS Module Exports

1. MERN Stack
MERN stands for MongoDB, Express JS, React JS and Node JS.

It is a JavaScript Stack that is used for easier & faster deployment of full-stack web applications.

2. Node JS
Node JS is a JavaScript environment that executes JavaScript code outside a web browser.

Why Node JS?

Cross-Platform (Windows, Linux, Mac OS X, etc.)
Huge number of third-party packages
Open Source
Massive Community

3. Running JavaScript Using Node JS
We can run JavaScript using Node JS in 2 ways.

Node REPL (Similar to browser console)
Node CLI

3.1 Node REPL (Read-Eval-Print-Loop)
Type node in the terminal and press Enter.

root@123# node
Welcome to Node.js v12.18.3.
Type ".help" for more information.
> const a = 1
undefined
> const b = 2
undefined
> a+b
3
>

Type .exit and press Enter to exit from the Node REPL.

root@123# node
Welcome to Node.js v12.18.3.
Type ".help" for more information.
> const a = 1
undefined
> const b = 2
undefined
> a+b
3
> .exit
root@123:/home/workspace#

3.2 Node CLI
We can write JavaScript to a file and can run using Node CLI.

//index.js

const greetings = (name) => {
  console.log(`Hello ${name}`);
};

greetings("Raju");
greetings("Abhi");

root@123# node index.js
Hello Raju
Hello Abhi

Note
Save the file whenever the code changes.

4. Module
In Node JS, each JavaScript file is treated as a separate module. These are known as the Common JS/Node JS Modules.

To access one module from another module, we have Module Exports.

Common JS Module Exports:
Default Exports
Named Exports

Modern JS Module Exports:
Default Exports
Named Exports

4.1 Common JS Module Exports
4.1.1 Default Exports
Exporting Module
The module.exports is a special object included in every JavaScript file in the Node JS application by default.

//calculator.js

const add = (a, b) => {
  return a + b;
};
module.exports = add;

Importing Module
To import a module which is the local file, use the require() function with the relative path of the module (file name).

//index.js

const add = require("./calculator");

console.log(add(6, 3));

Output:

root@123# node index.js
9

4.1.2 Named Exports
We can have multiple named exports per module.

Exporting Module

//calculator.js

const add = (a, b) => {
  return a + b;
};
const sub = (a, b) => {
  return a - b;
};

exports.add = add;
exports.sub = sub;

Importing Module

//index.js

const { add, sub } = require("./calculator");

console.log(add(6, 3));

console.log(sub(6, 3));

Output:

root@123# node index.js
9
3

4.2 Modern JS Module Exports
Modern JS Modules are known as ES6 Modules.

The export and import keywords are introduced for exporting and importing one or more members in a module.

4.2.1 Default Exports
Exporting Module

//calculator.mjs

const add = (a, b) => {
  return a + b;
};
export default add;

Importing Module

//index.mjs

import add from "./calculator.mjs";
console.log(add(6, 3));

Output:

root@123# node index.mjs
9

4.2.2 Named Exports
Exporting Module

//calculator.mjs

export const add = (a, b) => {
  return a + b;
};
export const sub = (a, b) => {
  return a - b;
};

Importing Module

//index.mjs

import { add, sub } from "./calculator.mjs";

console.log(add(6, 3));
console.log(sub(6, 3));

Output:

root@123# node index.mjs
9
3

Note
We need to specify .mjs extension while importing ES6 Modules.
We may or may not need to specify .js while importing Common JS Modules.

Introduction to Node JS > Common JS Module Exports | Reading Material
---------------------------------------------------------------------------------------------------

Concepts in Focus:
----------------------------------------------------------

Default Exports:

Exporting a variable while defining
Exporting a variable after defining
Exporting a value or an expression
Exporting a function while defining
Exporting a function after defining
Exporting a class while defining
Exporting a class after defining

Named Exports:

Exporting multiple variables while defining
Exporting multiple variables after defining
Exporting multiple values and expressions
Exporting multiple functions while defining
Exporting multiple functions after defining
Exporting multiple classes while defining
Exporting multiple classes after defining

Let's see different scenarios that we may come across while exporting.

1. Default Exports
With Default Exports, we can import modules with any name.

1.1 Exporting a variable while defining
We cannot export boolean, number, string, null, undefined, objects, and arrays while defining.

Example:

//sample.js

module.exports = let value = 5;

//index.js

const num = require("./sample.js");

Output:

root@123# node index.js
/index.js:3
module.exports = let value = 5;
                     ^

SyntaxError: Unexpected identifier
    at wrapSafe (internal/modules/cjs/loader.js:1053:16)
    ...
	
1.2 Exporting a variable after defining
We can export boolean, number, string, null, undefined, objects, and arrays after defining.

Example:

//sample.js

let value = 5;
module.exports = value;

//index.js

const value = require("./sample.js");

console.log(value);

Output:

root@123# node index.js
5

1.3 Exporting a value or an expression
We can export a value or an expression directly.

Example:

//sample.js

module.exports = 5 * 3;

//index.js

const result = require("./sample.js");

console.log(result);

Output:

root@123# node index.js
15

1.4 Exporting a function while defining
We can export a function while defining.

Example:

//sample.js

module.exports = function (num1, num2) {
  return num1 + num2;
};

//index.js

const sum = require("./sample.js");

console.log(sum(2, 6));

Output:

root@123# node index.js
8

1.5 Exporting a function after defining
We can export a function after defining.

Example:

//sample.js

function sum(num1, num2) {
  return num1 + num2;
}
module.exports = sum;

//index.js

const sum = require("./sample.js");

console.log(sum(2, 6));

Output:

root@123# node index.js
8

1.6 Exporting a class while defining
We can export a class while defining.

Example:

//sample.js

module.exports = class StudentDetails {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
};

//index.js

const StudentDetails = require("./sample.js");

const studentDetails = new StudentDetails("Ram", 15);

console.log(studentDetails);

console.log(studentDetails.name);

Output:

root@123# node index.js
StudentDetails { name: 'Ram', age: 15 }
Ram

1.7 Exporting a class after defining
We can export a class after defining.

Example:

//sample.js

class StudentDetails {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}
module.exports = StudentDetails;

//index.js

const StudentDetails = require("./sample.js");

const studentDetails = new StudentDetails("Ram", 15);

console.log(studentDetails);

console.log(studentDetails.name);

Output:

root@123# node index.js
StudentDetails { name: 'Ram', age: 15 }
Ram

2. Named Exports

2.1 Exporting multiple variables while defining
We cannot export boolean, number, string, null, undefined, objects, and arrays while defining.

Example:

//sample.js

exports.value = let value = 5;
exports.studentName = let studentName = "Rahul";

//index.js

const { value, studentName } = require("./sample");

console.log(value);

console.log(studentName);

Output:

root@123# node index.js
exports.value = let value = 5;
                    ^^^^^

SyntaxError: Unexpected identifier
    at wrapSafe (internal/modules/cjs/loader.js:1053:16)
	
2.2 Exporting multiple variables after defining
We can export multiple variables after defining.

Example:

//sample.js

let value = 5;
exports.value = value;
let studentName = "Rahul";
exports.studentName = studentName;

//index.js

const { value, studentName } = require("./sample");

console.log(value);

console.log(studentName);

Output:

root@123# node index.js
5
Rahul

2.3 Exporting multiple values and expressions
We can export multiple values and expressions.

Example:

//sample.js

let value = 2;
exports.sum = 2 + 3;
exports.sub = 3 - value;

//index.js

const { sum, sub } = require("./sample");

console.log(sum);

console.log(sub);

Output:

root@123# node index.js
5
1

2.4 Exporting multiple functions while defining
We can export multiple functions while defining.

Example:

//sample.js

exports.sum = function (num1, num2) {
  return num1 + num2;
};

exports.sub = function sub(num1, num2) {
  return num1 - num2;
};

//index.js

const { sum, sub } = require("./sample");

console.log(sum(2, 6));

console.log(sub(8, 3));

Output:

root@123# node index.js
8
5

2.5 Exporting multiple functions after defining
We can export multiple functions after defining.

Example:

//sample.js

function sum(num1, num2) {
  return num1 + num2;
}

exports.sum = sum;

function sub(num1, num2) {
  return num1 - num2;
}

exports.sub = sub;

//index.js

const { sum, sub } = require("./sample");

console.log(sum(2, 6));

console.log(sub(8, 3));

Output:

root@123# node index.js
8
5

2.6 Exporting multiple classes while defining
We can export multiple classes while defining.

Example:

//sample.js

exports.studentDetails = class StudentDetails {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
};

exports.carDetails = class CarDetails {
  constructor(name, age) {
    this.name = name;
    this.speed = age;
  }
};

//index.js

const { studentDetails, carDetails } = require("./sample.js");

const newStudentDetails = new studentDetails("Ram", 15);
console.log(newStudentDetails);
console.log(newStudentDetails.name);

const newCarDetails = new carDetails("Alto", "60kmph");
console.log(newCarDetails);
console.log(newCarDetails.name);

Output:

root@123# node index.js
StudentDetails { name: 'Ram', age: 15 }
Ram
CarDetails { name: 'Alto', speed: '60kmph' }
Alto

2.7 Exporting multiple classes after defining
We can export multiple classes after defining.

Example:

//sample.js

class StudentDetails {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}
exports.studentDetails = StudentDetails;

class CarDetails {
  constructor(name, age) {
    this.name = name;
    this.speed = age;
  }
}

exports.carDetails = CarDetails;

//index.js

const { studentDetails, carDetails } = require("./sample.js");

const newStudentDetails = new studentDetails("Ram", 15);
console.log(newStudentDetails);
console.log(newStudentDetails.name);

const newCarDetails = new carDetails("Alto", "60kmph");
console.log(newCarDetails);
console.log(newCarDetails.name);

Output:

root@123# node index.js
StudentDetails { name: 'Ram', age: 15 }
Ram
CarDetails { name: 'Alto', speed: '60kmph' }
Alto

Introduction to Node JS > ES6 Module Exports | Reading Material:
---------------------------------------------------------------------------------------------------
Concepts in Focus:
----------------------------

Default Exports:

Exporting a variable while defining
Exporting a variable after defining
Exporting a value or an expression
Exporting a function while defining
Exporting a function after defining
Exporting a class while defining
Exporting a class after defining

Named Exports:

Exporting multiple variables while defining
Exporting multiple variables after defining
Exporting multiple functions while defining
Exporting multiple functions after defining
Exporting multiple classes while defining
Exporting multiple classes after defining
Let's see different scenarios that we may come across while exporting.

1. Default Exports
With Default Exports, we can import modules with any name.

1.1 Exporting a variable while defining
We cannot export boolean, number, string, null, undefined, objects, and arrays while defining.

Example:

//sample.mjs

export default let value = 5;

//index.mjs

import value from "./sample.mjs";
console.log(value);

Output:

root@123# node index.mjs
(node:31964) ExperimentalWarning: The ESM module loader is experimental.
file:///index.mjs:1
export default let value = 5;
               ^^^
SyntaxError: Unexpected strict mode reserved word

1.2 Exporting a variable after defining
We can export boolean, number, string, null, undefined, objects, and arrays after defining.

Example:

//sample.mjs

let a = 5;
export default a;

//index.mjs

import a from "./sample.mjs";
console.log(a);

Output:

root@123# node index.mjs
(node:32665) ExperimentalWarning: The ESM module loader is experimental.
5

1.3 Exporting a value or an expression
We can export a value or an expression directly.

Example:

//sample.mjs

export default 5 * 3;

//index.mjs

import result from "./sample.mjs";

console.log(result);

Output:

root@123# node index.mjs
(node:4071) ExperimentalWarning: The ESM module loader is experimental.
15

1.4 Exporting a function while defining
We can export a function while defining.

Example:

//sample.mjs

export default function (num1, num2) {
  return num1 + num2;
}

//index.mjs

import sum from "./sample.mjs";

console.log(sum(2, 6));

Output:

root@123# node index.mjs
(node:4278) ExperimentalWarning: The ESM module loader is experimental.
8

1.5 Exporting a function after defining
We can export a function after defining.

Example:

//sample.mjs

function sum(num1, num2) {
  return num1 + num2;
}
export default sum;

//index.mjs

import sum from "./sample.mjs";

console.log(sum(2, 6));

Output:

root@123# node index.mjs
(node:4462) ExperimentalWarning: The ESM module loader is experimental.
8

1.6 Exporting a class while defining
We can export a class while defining.

Example:

//sample.mjs

export default class StudentDetails {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}

//index.mjs

import StudentDetails from "./sample.mjs";

const newStudentDetails = new StudentDetails("Ram", 15);
console.log(newStudentDetails);
console.log(newStudentDetails.name);

Output:

root@123# node index.mjs
(node:1035) ExperimentalWarning: The ESM module loader is experimental.
StudentDetails {name: "Ram", age: 15}
Ram

1.7 Exporting a class after defining
We can export a class after defining.

Example:

//sample.mjs

class StudentDetails {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}
export default StudentDetails;

//index.mjs

import StudentDetails from "./sample.mjs";

const newStudentDetails = new StudentDetails("Ram", 15);
console.log(newStudentDetails);
console.log(newStudentDetails.name);

Output:

root@123# node index.mjs
(node:1575) ExperimentalWarning: The ESM module loader is experimental.
StudentDetails {name: "Ram", age: 15}
Ram

2. Named Exports
2.1 Exporting multiple variables while defining
We can export boolean, number, string, null, undefined, objects, and arrays while defining.

Example:

//sample.mjs

export let value = 5;
export let studentName = "Rahul";

//index.mjs

import { value, studentName } from "./sample.mjs";

console.log(value);

console.log(studentName);

Output:

root@123# node index.mjs
(node:1770) ExperimentalWarning: The ESM module loader is experimental.
5
Rahul

2.2 Exporting multiple variables after defining
We can export multiple variables after defining in an Object format.

Example:

//sample.mjs

let value = 5;
const studentName = "Rahul";

export { value, studentName };

//index.mjs

import { value, studentName } from "./sample.mjs";

console.log(value);
console.log(studentName);

Output:

root@123# node index.mjs
(node:2437) ExperimentalWarning: The ESM module loader is experimental.
5
Rahul

2.3 Exporting multiple functions while defining
We can export multiple functions while defining.

Example:

//sample.mjs

export function sum(num1, num2) {
  return num1 + num2;
}

export function sub(num1, num2) {
  return num1 - num2;
}

//index.mjs

import { sum, sub } from "./sample.mjs";

console.log(sum(4, 2));

console.log(sub(4, 2));

Output:

root@123# node index.mjs
(node:2954) ExperimentalWarning: The ESM module loader is experimental.
6
2

2.4 Exporting multiple functions after defining
We can export multiple functions after defining.

Example:

//sample.mjs

function sum(num1, num2) {
  return num1 + num2;
}

function sub(num1, num2) {
  return num1 - num2;
}

export { sum, sub };

//index.mjs

import { sum, sub } from "./sample.mjs";

console.log(sum(4, 2));

console.log(sub(4, 2));

Output:

root@123# node index.mjs
(node:3276) ExperimentalWarning: The ESM module loader is experimental.
6
2

2.5 Exporting multiple classes while defining
We can export multiple classes while defining.

Example:

//sample.mjs

export class StudentDetails {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}

export class CarDetails {
  constructor(name, speed) {
    this.name = name;
    this.speed = speed;
  }
}

//index.mjs

import { StudentDetails, CarDetails } from "./sample.mjs";

const newStudentDetails = new StudentDetails("Ram", 15);
console.log(newStudentDetails);
console.log(newStudentDetails.name);

const newCarDetails = new CarDetails("Alto", "60kmph");
console.log(newCarDetails);
console.log(newCarDetails.name);

Output:

root@123# node index.mjs
(node:3517) ExperimentalWarning: The ESM module loader is experimental.
StudentDetails { name: 'Ram', age: 15 }
Ram
CarDetails { name: 'Alto', speed: '60kmph' }
Alto

2.6 Exporting multiple classes after defining
We can export multiple classes after defining.

Example:

//sample.mjs

class StudentDetails {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}

class CarDetails {
  constructor(name, speed) {
    this.name = name;
    this.speed = speed;
  }
}

export { StudentDetails, CarDetails };

//index.mjs

import { StudentDetails, CarDetails } from "./sample.mjs";

const newStudentDetails = new StudentDetails("Ram", 15);
console.log(newStudentDetails);
console.log(newStudentDetails.name);

const newCarDetails = new CarDetails("Alto", "60kmph");
console.log(newCarDetails);
console.log(newCarDetails.name);

Output:

root@123# node index.mjs
(node:3841) ExperimentalWarning: The ESM module loader is experimental.
StudentDetails {name: "Ram", age: 15}
Ram
CarDetails {name: "Alto", speed: "60kmph"}
Alto

MCQ:
--------------------------------

//animal.mjs

export const animalName = (name) => {
  console.log(name);
};
export const animalSound = (sound) => {
  console.log(sound);
};

//app.mjs

import { animalName, animalSound } from "./animal.mjs";

animalName("Cat");
animalSound("Meow");

Output:

Cat
Meow

2. //index.js

const { a, b } = ___("./filterEven");

let sum = (a, b) => {
  let result = a + b;
  return result;
};

sum(a, b);

Output:

require

3. //isQualified.mjs

const isQualified = (teamScore, qualifyScore) => {
  let result = teamScore > qualifyScore ? "Qualified" : "Disqualified";
  return result;
};

export default isQualified;

//index.mjs

import isQualified from "./isQualified.mjs";

const teamData = { team: "Rex", score: 10 };

const qualifyScore = 11;

console.log(isQualified(teamData.score, qualifyScore));

Output:

Disqualified

4. //math.mjs

export const sumOfTwoNumbers = (num1, num2) => {
  return num1 + num2;
};

export const productOfTwoNumbers = (num1, num2) => {
  return num1 * num2;
};

//app.mjs

import { sumOfTwoNumbers, productOfTwoNumbers } from "./math.mjs";

console.log(sumOfTwoNumbers(10, 2));

console.log(productOfTwoNumbers(11, 3));

Output:

12
33

5. //company.js

const companyName = "NxtWave";
const companyWebsite = "https://ccbp.in";

exports.companyName = companyName;

// index.js

const company = require("./company");
const { companyName, companyWebsite } = company;

console.log(companyName);
console.log(companyWebsite);

Output:

NxtWave
undefined

6. //number.js

const num1 = 123;
const num2 = 321;

module.exports.num1 = num1;
module.exports.num2 = num2;

//index.js

const numbers = require("./numbers");
const { num1, num2 } = numbers;

const sumOfTwoNumbers = (num1, num2) => {
  return num1 + num2;
};

console.log(sumOfTwoNumbers(num1, num2));

Output:

444

7. //product.mjs

export const product = "Mobile Phone";
export const productPrice = 500;

//index.mjs

import { product, productPrice } from './product.mjs';

console.log(`The price of ${product} is ${productPrice}`);

Output:

The price of Mobile Phone is 500

coding pratice-1:
-------------------------------------------

# Import and Export an Array using ES6 Module Syntax

Create two files `exportArray.mjs`, `importArray.mjs` parallel to `README.md` file.

Write an array with the values as `"countries", 190, "continents", 7, false, 6.2` in the `exportArray.mjs` file and export it using the default export syntax.

Import the array in the `importArray.mjs` file.

<b>Use the ES6 module syntax</b>.

//exportArray.mjs

const myArray = ["countries", 190, "continents", 7, false, 6.2];

export default myArray;

//importArray.mjs

import myArray from "./exportArray.mjs";

2.Import and Export a Boolean using Common JS Module Syntax

Create two files exportBoolean.js, importBoolean.js parallel to README.md file.

Write a boolean with the value as true in the exportBoolean.js file and export it using the default export syntax.

Import the boolean value in the importBoolean.js file.

Use Common JS module syntax.

//exportBoolean.js

const canDance = true;

module.exports = canDance;

//importBoolean.js

const canDance = require("./exportBoolean");

3.Import and Export a Function using Common JS Module Syntax

Create two files exportFunction.js, importFunction.js parallel to README.md file.

Write a JS function that returns the This is a Function text, in the file exportFunction.js and export it using the default export syntax.

Import the function in the importFunction.js file.

Use Common JS module syntax.

//exportFunction.js

const statement = () => {
  return "This is a Function";
};

module.exports = statement;

//importFunction.js

const statement = require("./exportFunction");

4.Import and Export a Function with Parameter using Common JS Module Syntax

Create two files exportFunctionWithParameter.js, importFunctionWithParameter.js parallel to README.md file.

Write a JS function that accepts a number and returns its square, in the file exportFunctionWithParameter.js and export it using the default export syntax.

Import the function in the importFunctionWithParameter.js file.

Use Common JS module syntax.

//exportFunctionWithParameter.js

const square = (num) => {
  return num * num;
};

module.exports = square;

//importFunctionWithParameter.js

const square = require("./exportFunctionWithParameter");

console.log(square(2));

Output:

4

5.Import and Export Multiple Values using ES6 Module Syntax

Create two files exportMultipleValues.mjs, importMultipleValues.mjs parallel to README.md file.

Write an array, object and a function that in the file exportMultipleValues.mjs and export them using the named export syntax.

Import the values in the importMultipleValues.mjs file.

Use ES6 module syntax

The variable names and values are given in the below table,

Variable		Type		Description/Value

myArray			Array		["camel", 265, true, "5.6"]
bulb			Object		{watts: 10, type: "LED"}
multiplyByFour	Function	Should accept a number and return a number multiplied by four

//exportMultipleValues.mjs

export const myArray = ["camel", 265, true, "5.6"];

export const bulb = {
  watts: 10,
  type: "LED",
};

export function multiplyByFour(num) {
  return num * 4;
}

//importMultipleValues.mjs

import { myArray, bulb, multiplyByFour } from "./exportMultipleValues.mjs";

console.log(myArray);
console.log(bulb);
console.log(multiplyByFour(3));

Output:

[ 'camel', 265, true, '5.6' ]
{ watts: 10, type: 'LED' }
12

6.Import and Export a Number using ES6 Module Syntax
Create two files exportNumber.mjs, importNumber.mjs parallel to README.md file.

Write a JS program to export the number 25 from the file exportNumber.mjs and export it using the default export syntax.

Import the number in the importNumber.mjs file.

Use ES6 module syntax

//exportNumber.mjs

const serialNumber = 25;

export default serialNumber;

//importNumber.mjs

import serialNumber from "./exportNumber.mjs";

console.log(serialNumber);

Output:

25

7.Import and Export an Object using Common JS Module Syntax

Create two files exportObject.js, importObject.js parallel to README.md file.

Write an object with keys as firstName and lastName and values as John and Wilson respectively in the file exportObject.js and export it using the default export syntax.

Import the object in the importObject.js file.

Use Common JS module syntax

//exportObject.js

const person = { firstName: "John", lastName: "Wilson" };

module.exports = person;

//importObject.js

const person = require("./exportObject");

console.log(person);

Output:

{ firstName: 'John', lastName: 'Wilson' }

8.Import and Export a String using ES6 Module Syntax

Create two files exportString.mjs, importString.mjs parallel to README.md file.

Write a string Be Happy and Safe in the file exportString.mjs and export it using the default export syntax.

Import the string in the importString.mjs file.

Use ES6 module syntax

//exportString.mjs

const message = "Be Happy and Safe";

export default message;

//importString.mjs

import message from "./exportString.mjs";

console.log(message);

Output:

Be Happy and Safe

Introduction to Node JS | Part 2 | Cheat Sheet:
--------------------------------------------------------------------------------------

Concepts in Focus:

Core Modules
Path

Package
Node Package Manager (NPM)

Steps to create a Node JS Project

Third-Party Packages
date-fns

1. Core Modules
The Core Modules are inbuilt in Node JS.

Some of the most commonly used are:

Module	Description
path	Handles file paths
fs		Handles the file system
url		Parses the URL strings

1.1 Path
The path module provides utilities for working with file and directory paths. It can be accessed using:

const path = require("path");

Example:

//index.js

const path = require("path");
const filePath = path.join("users", "ravi", "notes.txt");

console.log(filePath);

Output:

root@123# node index.js
users/ravi/notes.txt

Note
Many developers prefer Common JS Modules to ES6 syntax as ES6 syntax is in the experimental phase.

2. Package
A package is a directory with one or more modules grouped.

2.1 Node Package Manager (NPM)
NPM is the package manager for the Node JS packages with more than one million packages.

It provides a command line tool that allows you to publish, discover, install, and develop node programs.

2.1.1 CLI
NPM CLI sets up the Node JS Project to organize various modules and work with third-party packages.

Command								Description
npm init -y							Initializes a project and creates a package.json file
npm install <package-name> --save	Installs the third-party packages

3. Steps to create a Node JS Project
Run the below commands in the terminal.

Create a new directory/folder.
mkdir myapp

Move into the created folder.
cd myapp

Initialize the project.
npm init -y

4. Third-Party Packages
https://www.npmjs.com/
The Third-Party Packages are the external Node JS Packages.

They are developed by Node JS developers and are made available through the Node ecosystem.

4.1 date-fns
It is a third-party package for manipulating JavaScript dates in a browser & Node.js.

Installation Command:

npm install date-fns --save

4.1.1 addDays
It adds the specified number of days to the given date.

Example:

//index.js

const addDays = require("date-fns/addDays");
const result = addDays(new Date(2021, 0, 11), 10);

console.log(result);

Output:

root@123# node index.js
2021-01-21T00:00:00.000Z

Note
While creating the Date() object, we have to provide the month index from (0-11), whereas we will get the output considering Jan=1 and Dec=12.

mcq:
-------------

//decision.mjs

export const thirdUmpireDecision = "Out";

//index.mjs

import { thirdUmpireDecision } from "./decision.mjs";

const umpireDecision = (result) => {
  console.log(`The batsman is ${result}`);
};

umpireDecision(thirdUmpireDecision);

Output:

The batsman is Out.

2. //validateUser.mjs

const userName = "alex";

const validateUser = (loggedUser) => {
  let result = userName === loggedUser ? "Welcome!" : "Invalid User Name";
  return result;
};

export default validateUser;

//index.mjs

import validateUser from "./validateUser.mjs";

console.log(validateUser("alexa"));

Output:

Invalid User Name

coding pratice-2:
----------------------------------------------------

1.Get Date After x Days

Given an index.js file parallel to README.md file.

Write a JS function that accepts days as an argument and return the date after given number of days from 22nd Aug 2020 using the date-fns package.

Export the function using the default export syntax.

Date Format

DD-MM-YYYY

Use Common JS module syntax.

//index.js

const addDays = require("date-fns/addDays");

const getDateAfterXDays = (days) => {
  const newDate = addDays(new Date(2020, 7, 22), days);
  return `${newDate.getDate()}-${
    newDate.getMonth() + 1
  }-${newDate.getFullYear()}`;
};

module.exports = getDateAfterXDays;

2.Greeting Message
Create a new file index.js in the message directory.

Write a JS program to export the string Hello Rahul! Have a Great Day using the message from greeting/index.js.

Export the template string using the default export syntax.

Use Common JS module syntax.

//index.js

const greetings = require("../greeting/index");

module.exports = `Hello Rahul! ${greetings}`;

console.log(greetings);

3.First Names of the People
Create a file index.js in the names directory.

Write a JS function in index.js with function name getPeopleInCity that accepts people names list and returns an array of containing the first names of the people.

Export the function using the default export syntax.

Folder Structure

country
    - state
        - city
            - index.js    // contains the people names list
utilities
    - utils
        - index.js        // contains a function that returns the first names of the people
names
    - index.js            // create the file and write your code here
Use the given modules.

Use Common JS module syntax.

country
    - state
        - city
            - index.js
			
module.exports = [
  { firstName: "Dorothy", lastName: "Randall" },
  { firstName: "Victor", lastName: "Abraham" },
  { firstName: "Lillian", lastName: "Short" },
  { firstName: "Owen", lastName: "Rampling" },
  { firstName: "Julia", lastName: "Glover" },
  { firstName: "Donna", lastName: "Wilson" },
  { firstName: "Rose", lastName: "Anderson" },
  { firstName: "Nicholas", lastName: "McGrath" },
  { firstName: "Warren", lastName: "Langdon" },
  { firstName: "Austin", lastName: "Vaughan" },
];

names
    - index.js // create the file and write your code here
	
const peopleNames = require("../country/state/city/index");
const getFirstNames = require("../utilities/utils/index");

const getPeopleInCity = (peopleNames) => {
  return getFirstNames(peopleNames);
};

module.exports = getPeopleInCity;

utilities
    - utils
        - index.js 
		
const getFirstNames = (list) => {
  return list.map((eachPerson) => eachPerson.firstName);
};

module.exports = getFirstNames;

4.Calculate Ratio and Factorial
Create a file index.js in the ratioFactorial directory.

Write a JS function in index.js that accepts 3 numbers as arguments and return the ratio of the first two numbers and factorial of the third number in an object with keys as ratio and factorial.

Export the function using default export syntax.

Folder Structure

utilities
    - factorial
        - index.js         // contains a function that returns the factorial of the given number

    - ratio
        - index.js         // contains a function that returns the ratio of 2 given numbers

    - ratioFactorial
        - index.js         // create the file and write your code here
		
Use the functions provided in the ratio and factorial directories.

Use Common JS module syntax.

utilities
    - factorial
        - index.js  

function factorialOfNumber(num) {
  let factorial = 1;
  while (num !== 0) {
    factorial *= num--;
  }
  return factorial;
}

module.exports = factorialOfNumber;

    - ratio
        - index.js   

function ratioOfTwoNumbers(num1, num2) {
  return num1 / num2;
}

module.exports = ratioOfTwoNumbers;

    - ratioFactorial
        - index.js  

const ratioOfTwoNumbers = require("../ratio/index");
const factorialOfNumber = require("../factorial/index");

const ratioAndFactorial = (num1, num2, num3) => {
  const ratio = ratioOfTwoNumbers(num1, num2);
  const factorial = factorialOfNumber(num3);

  return { ratio, factorial };
};

module.exports = ratioAndFactorial;


Introduction to Express JS | Cheat Sheet:
---------------------------------------------------------------------

Concepts in Focus:

HTTP Server:
Server-side Web Frameworks

Express JS

Network Call using Express JS:
Handling HTTP Request

Testing Network calls

Network Call to get a Today’s Date

Network Call to get HTML content as an HTTP Response:
Sending file as an HTTP Response

1. HTTP Server
Works with the HTTP requests and responses
Handles the different paths
Handles the query parameters
Sends the content as HTML, CSS, etc. as an HTTP response
Works with the databases

1.1 Server-side Web Frameworks
The Server-side Web Frameworks take care of all the above requirements.

Some of the Web Frameworks are:

Express (Node JS)
Django (Python)
Ruby on Rails (Ruby)
Spring Boot (Java)

2. Express JS
It is a free and open-source Server-side Web Application Framework for Node JS.

It provides a robust set of features to build web and mobile applications quickly and easily.

Installation Command:

npm install express --save

3. Network call using Express JS

1.Creating Express server instance

const express = require("express");
const app = express();

2.Assigning a port number

app.listen(3000);

The app starts a server and listens on port 3000 for connections.

3.1 Handling HTTP Request

Syntax:

app.METHOD(PATH, HANDLER)

METHOD is an HTTP request method, in lowercase like get, post, put, and delete.
PATH is a path on the server.
HANDLER is the function executed when the PATH is matched with the requested path.

3.1.1 GET Request

const express = require("express");
const app = express();

app.get("/", (request, response) => {
  response.send("Hello World!");
});
app.listen(3000);

Note
Whenever the code changes, we need to restart the server to reflect the changes we made.

4. Testing Network Calls
We can test the Network calls in two ways.

Browser Network Tab.

5. Network Call to get a Today’s Date

const express = require("express");
const app = express();

app.get("/date", (request, response) => {
  let date = new Date();
  response.send(`Today's date is ${date}`);
});

app.listen(3000);

6. Network Call to get HTML content as an HTTP Response

6.1 Sending file as an HTTP Response
Syntax:

response.sendFile(PATH, {root: __dirname });

PATH is a path to the file which we want to send.
__dirname is a variable in Common JS Modules that returns the path of the folder where the current JavaScript file is present.

const express = require("express");
const app = express();

app.get("/page", (request, response) => {
  response.sendFile("./page.html", { root: __dirname });
});

app.listen(3000);


mcq:
--------------------------------------------

1. //tajMahal.html

<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <h1>Taj Mahal</h1>
  </body>
</html>

//index.js

const express = require("express");
const app = express();

app.get("/html-file", (request, response) => {
  response.sendFile("./tajMahal.html", { root: __dirname });
});

app.listen(3000);

Output:

tajMahal.html file content.

coding pratice-3:
-------------------------------------------------------

1.Get a String
Given an app.js file, write an API with path / using express JS to send Express JS text as a response.

Export the express instance using default export syntax.

Use Common JS module syntax

//app.js

const express = require("express");

const app = express();

app.get("/", (request, response) => {
  response.send("Express JS");
});

module.exports = app;

2.Gadgets Page
Given two files app.js and gadgets.html, write an API in app.js file for the path /gadgets that sends the gadgets.html file as a response.

Export the express instance using default export syntax.

Use Common JS module syntax.

//gadgets.html

<!DOCTYPE html>
<html>
 <body>
   <h1>Gadgets</h1>
   <p>A gadget is a mechanical device or any ingenious article.</p>
 </body>
</html>

//app.js

const express = require("express");

const app = express();

app.get("/gadgets", (request, response) => {
  response.sendFile("./gadgets.html", { root: __dirname });
});

module.exports = app;

3.API Routing
Given an app.js file, write two APIs that sends different strings as responses.

Refer to the below table for paths and responses,

Method	Path	Description
GET		/		Will send the text Home Page as response
GET		/about	Will send the text About Page as response
Export the express instance using default export syntax.

Use Common JS module syntax

//app.js

const express = require("express");

const app = express();

app.get("/about", (request, response) => {
  response.send("About Page");
});

app.get("/", (request, response) => {
  response.send("Home Page");
});

module.exports = app;

4.Today's Date
Given an app.js file, write an API with path / using express JS that sends today's date as a response in DD-MM-YYYY format.

Export the express instance using default export syntax.

Use Common JS module syntax.

const express = require("express");

const app = express();

app.get("/", (request, response) => {
  const dateTime = new Date();
  response.send(
    `${dateTime.getDate()}-${dateTime.getMonth() + 1}-${dateTime.getFullYear()}`
  );
});

module.exports = app;

5.Date after 100 Days from Today
Given an app.js file, write an API with path / using express JS to send the date after 100 days from today as a response in DD/MM/YYYY format.

Export the express instance using default export syntax.

Use the third-party package date-fns.

Use Common JS module syntax

const express = require("express");
const addDays = require("date-fns/addDays");

const app = express();

app.get("/", (request, response) => {
  const dateTime = new Date();
  const result = addDays(
    new Date(dateTime.getFullYear(), dateTime.getMonth(), dateTime.getDate()),
    100
  );
  response.send(
    `${result.getDate()}/${result.getMonth() + 1}/${result.getFullYear()}`
  );
});

module.exports = app;

Package.json:

{
    "name": "date-after-100-days-from-today",
    "version": "1.0.0",
    "description": "",
    "main": "app.js",
    "author": "",
    "license": "ISC",
    "dependencies": {
        "date-fns": "2.19.0",
        "express": "4.17.1"
    }
}


Introduction to Express JS | Part 2 | Cheat Sheet:
---------------------------------------------------------------------------------------

Concepts in Focus:

Application Programming Interface (API)

Database

SQLite:
SQLite CLI

SQLite Methods:
Open
Executing SQL Queries

SQL Third-party packages

Connecting SQLite Database from Node JS to get the books from Goodreads Website:
SQLite Database Initialization
Goodreads Get Books API

1. Application Programming Interface (API)

An API is a software intermediary that allows two applications to talk to each other.

For example, OLA, and UBER use Google Maps API to provide their services.

All the Network calls that we added are also the APIs.

2. Database

Express apps can use any database supported by Node JS.

There are many popular options, including SQLite, PostgreSQL, MySQL, Redis, and MongoDB.

3. SQLite
The SQLite provides a command-line tool sqlite3.

It allows the user to enter and execute SQL statements against an SQLite database.

3.1 SQLite CLI

3.1.1 Listing Existing Tables
The .tables command is used to get the list of tables available in the SQLite database.

3.1.2 Selecting Table Data
Syntax: SELECT * from <table>

4. SQLite Methods

4.1 Open
The SQLite open() method is used to connect the database server and provides a connection object to operate on the database.

Syntax:

open({
  filename: DATABASE_PATH,
  driver: SQLITE_DATABASE_DRIVER,
});

It returns a promise object. On resolving the promise object, we will get the database connection object.

4.2 Executing SQL Queries
SQLite package provides multiple methods to execute SQL queries on a database.

Some of them are:

all()
get()
run()
exec(), etc.

4.2.1 all()
db.all(SQL_QUERY);

The all() method is used to get multiple rows of data.

5. SQL Third-party packages
We can use sqlite and sqlite3 node packages to connect SQLite Database from Node JS.

Installation Commands

npm install sqlite --save
npm install sqlite3 --save

6. Connecting SQLite Database from Node JS to get the books from Goodreads Website
1.Install the SQL third-party packages sqlite and sqlite3.
2.Initialize the SQLite Database

6.1 SQLite Database Initialization

const express = require("express");
const path = require("path");

const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const app = express();

const dbPath = path.join(__dirname, "goodreads.db");

let db = null;

const initializeDBAndServer = async () => {
  try {
    db = await open({
      filename: dbPath,
      driver: sqlite3.Database,
    });
    app.listen(3000, () => {
      console.log("Server Running at http://localhost:3000/");
    });
  } catch (e) {
    console.log(`DB Error: ${e.message}`);
    process.exit(1);
  }
};

initializeDBAndServer();

6.2 Goodreads Get Books API

app.get("/books/", async (request, response) => {
  const getBooksQuery = `
    SELECT
      *
    FROM
      book
    ORDER BY
      book_id;`;
  const booksArray = await db.all(getBooksQuery);
  response.send(booksArray);
});

Introduction to Express JS | Part 3 | Cheat Sheet:
-------------------------------------------------------------------------

Concepts in Focus:

SQLite Methods
get()
run()

Node JS Third-party packages
Nodemon

GoodReads API
Get Book
Add Book
Update Book
Delete Book
Get Author Books

1. SQLite Methods
The SQLite package provides multiple methods to execute SQL queries on a database.

Some of them are:

all()
get()
run()
exec(), etc.

1.1 get()
The get() method is used to get a single row from the table.

Syntax:

db.get(SQL_QUERY);

1.2 run()
The run() method is used to create or update table data.

Syntax:

db.run(SQL_QUERY);

2. Node JS Third-party packages
2.1 Nodemon
The Nodemon is a tool that restarts the server automatically whenever we make changes in the file.

Installation Command:

npm install -g nodemon

Note
The-g indicates that the nodemon will be installed globally in the environment.
While executing the file, replace the node with the nodemon. For example, nodemon index.js.

3. GoodReads APIs
Get Book
Add Book
Update Book
Delete Book
Get Author Books

3.1 Get Book
We can use /books/:bookId/ as a path to identify a single book resource, where bookId is a path parameter.

For example,

In http://localhost:3000/books/1/, the bookId is 1.

app.get("/books/:bookId/", async (request, response) => {
  const { bookId } = request.params;
  const getBookQuery = `
    SELECT
      *
    FROM
      book
    WHERE
      book_id = ${bookId};`;
  const book = await db.get(getBookQuery);
  response.send(book);
});

Note
Any string can be used as a path parameter.

3.2 Add Book
To add a book to the Database, you need to send a request body in JSON format.

The express.json() is used to recognize the incoming request object as JSON Object and parses it.

The request.body is used to get the HTTP Request body.

app.post("/books/", async (request, response) => {
  const bookDetails = request.body;
  const {
    title,
    authorId,
    rating,
    ratingCount,
    reviewCount,
    description,
    pages,
    dateOfPublication,
    editionLanguage,
    price,
    onlineStores,
  } = bookDetails;
  const addBookQuery = `
    INSERT INTO
      book (title,author_id,rating,rating_count,review_count,description,pages,date_of_publication,edition_language,price,online_stores)
    VALUES
      (
        '${title}',
         ${authorId},
         ${rating},
         ${ratingCount},
         ${reviewCount},
        '${description}',
         ${pages},
        '${dateOfPublication}',
        '${editionLanguage}',
         ${price},
        '${onlineStores}'
      );`;

  const dbResponse = await db.run(addBookQuery);
  const bookId = dbResponse.lastID;
  response.send({ bookId: bookId });
});

The dbResponse.lastID provides the primary key of the new row inserted.

3.3 Update Book
We can use /books/:bookId/ as a path to identify a single book resource, where :bookId is the path parameter.

For example, http://localhost:3000/books/1/.

app.put("/books/:bookId/", async (request, response) => {
  const { bookId } = request.params;
  const bookDetails = request.body;
  const {
    title,
    authorId,
    rating,
    ratingCount,
    reviewCount,
    description,
    pages,
    dateOfPublication,
    editionLanguage,
    price,
    onlineStores,
  } = bookDetails;
  const updateBookQuery = `
    UPDATE
      book
    SET
      title='${title}',
      author_id=${authorId},
      rating=${rating},
      rating_count=${ratingCount},
      review_count=${reviewCount},
      description='${description}',
      pages=${pages},
      date_of_publication='${dateOfPublication}',
      edition_language='${editionLanguage}',
      price=${price},
      online_stores='${onlineStores}'
    WHERE
      book_id = ${bookId};`;
  await db.run(updateBookQuery);
  response.send("Book Updated Successfully");
});

The request.params provides the parameters passed through the request.

Note
The strings sent through the APIs must be wrapped in quotes.

3.4 Delete Book

app.delete("/books/:bookId/", async (request, response) => {
  const { bookId } = request.params;
  const deleteBookQuery = `
    DELETE FROM
      book
    WHERE
      book_id = ${bookId};`;
  await db.run(deleteBookQuery);
  response.send("Book Deleted Successfully");
});

3.5 Get Author Books

app.get("/authors/:authorId/books/", async (request, response) => {
  const { authorId } = request.params;
  const getAuthorBooksQuery = `
    SELECT
     *
    FROM
     book
    WHERE
      author_id = ${authorId};`;
  const booksArray = await db.all(getAuthorBooksQuery);
  response.send(booksArray);
});

//goodreads.http

GET http://localhost:3000/books/

###

GET http://localhost:3000/books/1/

###

POST http://localhost:3000/books/
Content-Type: application/json

{
  "title": "Harry Potter and the Order of the Phoenix",
  "authorId": 1,
  "rating": 4.62,
  "ratingCount": 126559,
  "reviewCount": 611,
  "description": "There is a door at the end of a silent corridor.",
  "pages": 352,
  "dateOfPublication": "May 1st 2003",
  "editionLanguage": "English",
  "price": 850,
  "onlineStores": "Amazon,Audible,Indigo,Apple Books,Google Play,IndieBound"
}

###

PUT http://localhost:3000/books/41/
Content-Type: application/json

{
  "title": "Harry Potter and the Order of the Phoenix",
  "authorId": 1,
  "rating": 5,
  "ratingCount": 1000000,
  "reviewCount": 711,
  "description": "There is a door at the end of a silent corridor.",
  "pages": 352,
  "dateOfPublication": "May 1st 2003",
  "editionLanguage": "English",
  "price": 850,
  "onlineStores": "Amazon,Audible,Indigo,Apple Books,Google Play,IndieBound"
}

###

DELETE http://localhost:3000/books/41/

###

GET http://localhost:3000/authors/1/books/


mcq:
----------------------------------------

const express = require("express");
const path = require("path");

const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const app = express();

const dbPath = path.join(__dirname, "goodreads.db");

let db = null;

const initializeDBAndServer = async () => {
  try {
    db = await open({
      filename: dbPath,
      driver: sqlite3.Database,
    });
    app.listen(3000, () => {
      console.log("Server Running at http://localhost:3000/");
    });
  } catch (e) {
    console.log(`DB Error: ${e.message}`);
    process.exit(1);
  }
};

initializeDBAndServer();

app.post("/books/", async (request, response) => {
  const bookDetails = request.body;
  const {
    title,
    authorId,
    rating,
    ratingCount,
    reviewCount,
    description,
    pages,
    dateOfPublication,
    editionLanguage,
    price,
    onlineStores,
  } = bookDetails;
  const addBookQuery = `
    INSERT INTO
      book (title,author_id,rating,rating_count,review_count,description,pages,date_of_publication,edition_language,price,online_stores)
    VALUES
      (
        '${title}',
         ${authorId}
       
      );`;

  const dbResponse = await db.run(addBookQuery);
  const bookId = dbResponse.lastID;
  response.send({ bookId: bookId });
});

coding pratice-4:
----------------------------------------------------

cricket team:

Cricket Team
Given two files app.js and a database file cricketTeam.db consisting a table cricket_team.

Write APIs to perform operations on the table cricket_team containing the following columns,

Columns			Type
player_id		INTEGER
player_name		TEXT
jersey_number	INTEGER
role			TEXT

API 1

Path: /players/
Method: GET
Description:
Returns a list of all players in the team

Response

[
  {
    playerId: 1,
    playerName: "Lakshman",
    jerseyNumber: 5,
    role: "All-rounder"
  },

  ...
]

API 2

Path: /players/
Method: POST
Description:
Creates a new player in the team (database). player_id is auto-incremented

Request

{
  "playerName": "Vishal",
  "jerseyNumber": 17,
  "role": "Bowler"
}

API 3

Path: /players/:playerId/
Method: GET
Description:
Returns a player based on a player ID

Response

{
  playerId: 1,
  playerName: "Lakshman",
  jerseyNumber: 5,
  role: "All-rounder"
}

API 4

Path: /players/:playerId/
Method: PUT
Description:
Updates the details of a player in the team (database) based on the player ID

Request

{
  "playerName": "Maneesh",
  "jerseyNumber": 54,
  "role": "All-rounder"
}

Response

Player Details Updated

API 5

Path: /players/:playerId/
Method: DELETE
Description:
Deletes a player from the team (database) based on the player ID

Response
Player Removed

Use npm install to install the packages.

Export the express instance using the default export syntax.

Use Common JS module syntax.

const express = require("express");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require("path");

const databasePath = path.join(__dirname, "cricketTeam.db");

const app = express();

app.use(express.json());

let database = null;

const initializeDbAndServer = async () => {
  try {
    database = await open({
      filename: databasePath,
      driver: sqlite3.Database,
    });
    app.listen(3000, () =>
      console.log("Server Running at http://localhost:3000/")
    );
  } catch (error) {
    console.log(`DB Error: ${error.message}`);
    process.exit(1);
  }
};

initializeDbAndServer();

const convertDbObjectToResponseObject = (dbObject) => {
  return {
    playerId: dbObject.player_id,
    playerName: dbObject.player_name,
    jerseyNumber: dbObject.jersey_number,
    role: dbObject.role,
  };
};

app.get("/players/", async (request, response) => {
  const getPlayersQuery = `
    SELECT
      *
    FROM
      cricket_team;`;
  const playersArray = await database.all(getPlayersQuery);
  response.send(
    playersArray.map((eachPlayer) =>
      convertDbObjectToResponseObject(eachPlayer)
    )
  );
});

app.get("/players/:playerId/", async (request, response) => {
  const { playerId } = request.params;
  const getPlayerQuery = `
    SELECT 
      * 
    FROM 
      cricket_team 
    WHERE 
      player_id = ${playerId};`;
  const player = await database.get(getPlayerQuery);
  response.send(convertDbObjectToResponseObject(player));
});

app.post("/players/", async (request, response) => {
  const { playerName, jerseyNumber, role } = request.body;
  const postPlayerQuery = `
  INSERT INTO
    cricket_team (player_name, jersey_number, role)
  VALUES
    ('${playerName}', ${jerseyNumber}, '${role}');`;
  const player = await database.run(postPlayerQuery);
  response.send("Player Added to Team");
});

app.put("/players/:playerId/", async (request, response) => {
  const { playerName, jerseyNumber, role } = request.body;
  const { playerId } = request.params;
  const updatePlayerQuery = `
  UPDATE
    cricket_team
  SET
    player_name = '${playerName}',
    jersey_number = ${jerseyNumber},
    role = '${role}'
  WHERE
    player_id = ${playerId};`;

  await database.run(updatePlayerQuery);
  response.send("Player Details Updated");
});

app.delete("/players/:playerId/", async (request, response) => {
  const { playerId } = request.params;
  const deletePlayerQuery = `
  DELETE FROM
    cricket_team
  WHERE
    player_id = ${playerId};`;
  await database.run(deletePlayerQuery);
  response.send("Player Removed");
});

module.exports = app;

coding pratice-5:
--------------------------------------------

Movies:

Given two files app.js and a database file moviesData.db consisting of two tables movie and director.

Write APIs to perform CRUD operations on the tables movie, director containing the following columns,

Movie Table

Columns		Type

movie_id	INTEGER
director_id	INTEGER
movie_name	TEXT
lead_actor	TEXT
Director 	Table

Columns			Type
director_id		INTEGER
director_name	TEXT

API 1

Path: /movies/
Method: GET
Description:
Returns a list of all movie names in the movie table

Response

[
  {
    movieName: "Captain America: The First Avenger",
  },

  ...
]

API 2

Path: /movies/
Method: POST
Description:
Creates a new movie in the movie table. movie_id is auto-incremented

Request

{
  "directorId": 6,
  "movieName": "Jurassic Park",
  "leadActor": "Jeff Goldblum"
}

Response

Movie Successfully Added

API 3

Path: /movies/:movieId/
Method: GET
Description:
Returns a movie based on the movie ID

Response

{
  movieId: 12,
  directorId: 3,
  movieName: "The Lord of the Rings",
  leadActor: "Elijah Wood",
}

API 4

Path: /movies/:movieId/
Method: PUT
Description:
Updates the details of a movie in the movie table based on the movie ID

Request

{
  "directorId": 24,
  "movieName": "Thor",
  "leadActor": "Christopher Hemsworth"
}

Response

Movie Details Updated

API 5

Path: /movies/:movieId/
Method: DELETE
Description:
Deletes a movie from the movie table based on the movie ID

Response

Movie Removed

API 6

Path: /directors/
Method: GET
Description:
Returns a list of all directors in the director table

Response

[
  {
    directorId: 1,
    directorName: "Joe Johnston",
  },

  ...
]

API 7

Path: /directors/:directorId/movies/
Method: GET
Description:
Returns a list of all movie names directed by a specific director

Response

[
  {
    movieName: "Captain Marvel",
  },

  ...
]

Use npm install to install the packages.

Export the express instance using the default export syntax.

Use Common JS module syntax.


const express = require("express");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require("path");

const databasePath = path.join(__dirname, "moviesData.db");

const app = express();

app.use(express.json());

let database = null;

const initializeDbAndServer = async () => {
  try {
    database = await open({
      filename: databasePath,
      driver: sqlite3.Database,
    });
    app.listen(3000, () =>
      console.log("Server Running at http://localhost:3000/")
    );
  } catch (error) {
    console.log(`DB Error: ${error.message}`);
    process.exit(1);
  }
};

initializeDbAndServer();

const convertMovieDbObjectToResponseObject = (dbObject) => {
  return {
    movieId: dbObject.movie_id,
    directorId: dbObject.director_id,
    movieName: dbObject.movie_name,
    leadActor: dbObject.lead_actor,
  };
};

const convertDirectorDbObjectToResponseObject = (dbObject) => {
  return {
    directorId: dbObject.director_id,
    directorName: dbObject.director_name,
  };
};

app.get("/movies/", async (request, response) => {
  const getMoviesQuery = `
    SELECT
      movie_name
    FROM
      movie;`;
  const moviesArray = await database.all(getMoviesQuery);
  response.send(
    moviesArray.map((eachMovie) => ({ movieName: eachMovie.movie_name }))
  );
});

app.get("/movies/:movieId/", async (request, response) => {
  const { movieId } = request.params;
  const getMovieQuery = `
    SELECT 
      *
    FROM 
      movie 
    WHERE 
      movie_id = ${movieId};`;
  const movie = await database.get(getMovieQuery);
  response.send(convertMovieDbObjectToResponseObject(movie));
});

app.post("/movies/", async (request, response) => {
  const { directorId, movieName, leadActor } = request.body;
  const postMovieQuery = `
  INSERT INTO
    movie ( director_id, movie_name, lead_actor)
  VALUES
    (${directorId}, '${movieName}', '${leadActor}');`;
  await database.run(postMovieQuery);
  response.send("Movie Successfully Added");
});

app.put("/movies/:movieId/", async (request, response) => {
  const { directorId, movieName, leadActor } = request.body;
  const { movieId } = request.params;
  const updateMovieQuery = `
            UPDATE
              movie
            SET
              director_id = ${directorId},
              movie_name = '${movieName}',
              lead_actor = '${leadActor}'
            WHERE
              movie_id = ${movieId};`;

  await database.run(updateMovieQuery);
  response.send("Movie Details Updated");
});

app.delete("/movies/:movieId/", async (request, response) => {
  const { movieId } = request.params;
  const deleteMovieQuery = `
  DELETE FROM
    movie
  WHERE
    movie_id = ${movieId};`;
  await database.run(deleteMovieQuery);
  response.send("Movie Removed");
});

app.get("/directors/", async (request, response) => {
  const getDirectorsQuery = `
    SELECT
      *
    FROM
      director;`;
  const directorsArray = await database.all(getDirectorsQuery);
  response.send(
    directorsArray.map((eachDirector) =>
      convertDirectorDbObjectToResponseObject(eachDirector)
    )
  );
});

app.get("/directors/:directorId/movies/", async (request, response) => {
  const { directorId } = request.params;
  const getDirectorMoviesQuery = `
    SELECT
      movie_name
    FROM
      movie
    WHERE
      director_id='${directorId}';`;
  const moviesArray = await database.all(getDirectorMoviesQuery);
  response.send(
    moviesArray.map((eachMovie) => ({ movieName: eachMovie.movie_name }))
  );
});
module.exports = app;

coding pratice-6:
-------------------------------

Covid-19 India:

Given two files app.js and a database file covid19India.db consisting of two tables state and district.

Write APIs to perform CRUD operations on the tables state, district containing the following columns,

State Table

Columns	Type

state_id	INTEGER
state_name	TEXT
population	INTEGER
District 	Table

Columns			Type
district_id		INTEGER
district_name	TEXT
state_id		INTEGER
cases			INTEGER
cured			INTEGER
active			INTEGER
deaths			INTEGER

API 1

Path: /states/
Method: GET
Description:
Returns a list of all states in the state table

Response

[
  {
    stateId: 1,
    stateName: "Andaman and Nicobar Islands",
    population: 380581
  },

  ...
]

API 2

Path: /states/:stateId/
Method: GET
Description:
Returns a state based on the state ID

Response

{
  stateId: 8,
  stateName: "Delhi",
  population: 16787941
}

API 3

Path: /districts/
Method: POST
Description:
Create a district in the district table, district_id is auto-incremented

Request

{
  "districtName": "Bagalkot",
  "stateId": 3,
  "cases": 2323,
  "cured": 2000,
  "active": 315,
  "deaths": 8
}

Response

District Successfully Added

API 4

Path: /districts/:districtId/
Method: GET
Description:
Returns a district based on the district ID

Response

{
  districtId: 322,
  districtName: "Haveri",
  stateId: 36,
  cases: 2816,
  cured: 2424,
  active: 172,
  deaths: 220,
}

API 5

Path: /districts/:districtId/
Method: DELETE
Description:
Deletes a district from the district table based on the district ID

Response

District Removed

API 6

Path: /districts/:districtId/
Method: PUT
Description:
Updates the details of a specific district based on the district ID

Request

{
  "districtName": "Nadia",
  "stateId": 3,
  "cases": 9628,
  "cured": 6524,
  "active": 3000,
  "deaths": 104
}

Response

District Details Updated

API 7

Path: /states/:stateId/stats/
Method: GET
Description:
Returns the statistics of total cases, cured, active, deaths of a specific state based on state ID

Response

{
  totalCases: 724355,
  totalCured: 615324,
  totalActive: 99254,
  totalDeaths: 9777
}

API 8

Path: /districts/:districtId/details/
Method: GET
Description:
Returns an object containing the state name of a district based on the district ID

Response

{
  stateName: "Maharashtra"
}


Use npm install to install the packages.

Export the express instance using the default export syntax.

Use Common JS module syntax.

const express = require("express");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require("path");

const databasePath = path.join(__dirname, "covid19India.db");

const app = express();

app.use(express.json());

let database = null;

const initializeDbAndServer = async () => {
  try {
    database = await open({
      filename: databasePath,
      driver: sqlite3.Database,
    });

    app.listen(3000, () =>
      console.log("Server Running at http://localhost:3000/")
    );
  } catch (error) {
    console.log(`DB Error: ${error.message}`);
    process.exit(1);
  }
};

initializeDbAndServer();

const convertStateDbObjectToResponseObject = (dbObject) => {
  return {
    stateId: dbObject.state_id,
    stateName: dbObject.state_name,
    population: dbObject.population,
  };
};

const convertDistrictDbObjectToResponseObject = (dbObject) => {
  return {
    districtId: dbObject.district_id,
    districtName: dbObject.district_name,
    stateId: dbObject.state_id,
    cases: dbObject.cases,
    cured: dbObject.cured,
    active: dbObject.active,
    deaths: dbObject.deaths,
  };
};

app.get("/states/", async (request, response) => {
  const getStatesQuery = `
    SELECT
      *
    FROM
      state;`;
  const statesArray = await database.all(getStatesQuery);
  response.send(
    statesArray.map((eachState) =>
      convertStateDbObjectToResponseObject(eachState)
    )
  );
});

app.get("/states/:stateId/", async (request, response) => {
  const { stateId } = request.params;
  const getStateQuery = `
    SELECT 
      *
    FROM 
      state 
    WHERE 
      state_id = ${stateId};`;
  const state = await database.get(getStateQuery);
  response.send(convertStateDbObjectToResponseObject(state));
});

app.get("/districts/:districtId/", async (request, response) => {
  const { districtId } = request.params;
  const getDistrictsQuery = `
    SELECT
      *
    FROM
     district
    WHERE
      district_id = ${districtId};`;
  const district = await database.get(getDistrictsQuery);
  response.send(convertDistrictDbObjectToResponseObject(district));
});

app.post("/districts/", async (request, response) => {
  const { stateId, districtName, cases, cured, active, deaths } = request.body;
  const postDistrictQuery = `
  INSERT INTO
    district (state_id, district_name, cases, cured, active, deaths)
  VALUES
    (${stateId}, '${districtName}', ${cases}, ${cured}, ${active}, ${deaths});`;
  await database.run(postDistrictQuery);
  response.send("District Successfully Added");
});

app.delete("/districts/:districtId/", async (request, response) => {
  const { districtId } = request.params;
  const deleteDistrictQuery = `
  DELETE FROM
    district
  WHERE
    district_id = ${districtId} 
  `;
  await database.run(deleteDistrictQuery);
  response.send("District Removed");
});

app.put("/districts/:districtId/", async (request, response) => {
  const { districtId } = request.params;
  const { districtName, stateId, cases, cured, active, deaths } = request.body;
  const updateDistrictQuery = `
  UPDATE
    district
  SET
    district_name = '${districtName}',
    state_id = ${stateId},
    cases = ${cases},
    cured = ${cured},
    active = ${active}, 
    deaths = ${deaths}
  WHERE
    district_id = ${districtId};
  `;

  await database.run(updateDistrictQuery);
  response.send("District Details Updated");
});

app.get("/states/:stateId/stats/", async (request, response) => {
  const { stateId } = request.params;
  const getStateStatsQuery = `
    SELECT
      SUM(cases),
      SUM(cured),
      SUM(active),
      SUM(deaths)
    FROM
      district
    WHERE
      state_id=${stateId};`;
  const stats = await database.get(getStateStatsQuery);
  response.send({
    totalCases: stats["SUM(cases)"],
    totalCured: stats["SUM(cured)"],
    totalActive: stats["SUM(active)"],
    totalDeaths: stats["SUM(deaths)"],
  });
});

app.get("/districts/:districtId/details/", async (request, response) => {
  const { districtId } = request.params;
  const getStateNameQuery = `
    SELECT
      state_name
    FROM
      district
    NATURAL JOIN
      state
    WHERE 
      district_id=${districtId};`;
  const state = await database.get(getStateNameQuery);
  response.send({ stateName: state.state_name });
});

module.exports = app;

coding pratice-7:
------------------------------------------------------

Player Match Scores:

Given two files app.js and a database file cricketMatchDetails.db consisting of three tables player_details, match_details and player_match_score.

Write APIs to perform operations on the tables player_details, match_details and player_match_score containing the following columns,

Player Details Table:

Column			Type
player_id		INTEGER
player_name		TEXT

Match Details Table:

Column		Type
match_id	INTEGER
match		TEXT
year		INTEGER

Player Match Score Table:

Column			Type
player_match_id	INTEGER
player_id		INTEGER
match_id		INTEGER
score			INTEGER
fours			INTEGER
sixes			INTEGER

API 1

Path: /players/
Method: GET
Description:
Returns a list of all the players in the player table

Response

[
  { 
    playerId: 1,
    playerName: "Ram"
  },

  ...
]

API 2

Path: /players/:playerId/
Method: GET
Description:
Returns a specific player based on the player ID

Response

{ 
  playerId: 2,
  playerName: "Joseph"
}

API 3

Path: /players/:playerId/
Method: PUT
Description:
Updates the details of a specific player based on the player ID

Request

{
  "playerName": "Raju"
}

Response

Player Details Updated

API 4

Path: /matches/:matchId/
Method: GET
Description:
Returns the match details of a specific match

Response

{ 
  matchId: 18,
  match: "RR vs SRH",
  year: 2011
}

API 5

Path: /players/:playerId/matches
Method: GET
Description:
Returns a list of all the matches of a player

Response

[
  { 
    matchId: 1,
    match: "SRH vs MI",
    year: 2016
  },

  ...
]

API 6

Path: /matches/:matchId/players
Method: GET
Description:
Returns a list of players of a specific match

Response

[
  { 
    playerId: 2,
    playerName: "Joseph"
  },
  ...
]

API 7

Path: /players/:playerId/playerScores
Method: GET
Description:
Returns the statistics of the total score, fours, sixes of a specific player based on the player ID

Response

{
  playerId: 1,
  playerName: "Ram"
  totalScore: 3453,
  totalFours: 342,
  totalSixes: 98
}

Use npm install to install the packages.

Export the express instance using the default export syntax.

Use Common JS module syntax.

const express = require("express");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require("path");

const databasePath = path.join(__dirname, "cricketMatchDetails.db");

const app = express();

app.use(express.json());

let database = null;

const initializeDbAndServer = async () => {
  try {
    database = await open({
      filename: databasePath,
      driver: sqlite3.Database,
    });

    app.listen(3000, () =>
      console.log("Server Running at http://localhost:3000/")
    );
  } catch (error) {
    console.log(`DB Error: ${error.message}`);
    process.exit(1);
  }
};

initializeDbAndServer();

const convertPlayerDbObjectToResponseObject = (dbObject) => {
  return {
    playerId: dbObject.player_id,
    playerName: dbObject.player_name,
  };
};

const convertMatchDetailsDbObjectToResponseObject = (dbObject) => {
  return {
    matchId: dbObject.match_id,
    match: dbObject.match,
    year: dbObject.year,
  };
};

app.get("/players/", async (request, response) => {
  const getPlayerQuery = `
    SELECT
      *
    FROM
      player_details;`;
  const playersArray = await database.all(getPlayerQuery);
  response.send(
    playersArray.map((eachPlayer) =>
      convertPlayerDbObjectToResponseObject(eachPlayer)
    )
  );
});

app.get("/players/:playerId/", async (request, response) => {
  const { playerId } = request.params;
  const getPlayerQuery = `
    SELECT 
      *
    FROM 
      player_details 
    WHERE 
      player_id = ${playerId};`;
  const player = await database.get(getPlayerQuery);
  response.send(convertPlayerDbObjectToResponseObject(player));
});

app.put("/players/:playerId/", async (request, response) => {
  const { playerId } = request.params;
  const { playerName } = request.body;
  const updatePlayerQuery = `
  UPDATE
    player_details
  SET
    player_name ='${playerName}'
  WHERE
    player_id = ${playerId};`;

  await database.run(updatePlayerQuery);
  response.send("Player Details Updated");
});

app.get("/matches/:matchId/", async (request, response) => {
  const { matchId } = request.params;
  const matchDetailsQuery = `
    SELECT
      *
    FROM
      match_details
    WHERE
      match_id = ${matchId};`;
  const matchDetails = await database.get(matchDetailsQuery);
  response.send(convertMatchDetailsDbObjectToResponseObject(matchDetails));
});

app.get("/players/:playerId/matches/", async (request, response) => {
  const { playerId } = request.params;
  const getPlayerMatchesQuery = `
    SELECT
      *
    FROM player_match_score 
      NATURAL JOIN match_details
    WHERE
      player_id = ${playerId};`;
  const playerMatches = await database.all(getPlayerMatchesQuery);
  response.send(
    playerMatches.map((eachMatch) =>
      convertMatchDetailsDbObjectToResponseObject(eachMatch)
    )
  );
});

app.get("/matches/:matchId/players", async (request, response) => {
  const { matchId } = request.params;
  const getMatchPlayersQuery = `
    SELECT
      *
    FROM player_match_score
      NATURAL JOIN player_details
    WHERE
      match_id = ${matchId};`;
  const playersArray = await database.all(getMatchPlayersQuery);
  response.send(
    playersArray.map((eachPlayer) =>
      convertPlayerDbObjectToResponseObject(eachPlayer)
    )
  );
});

app.get("/players/:playerId/playerScores/", async (request, response) => {
  const { playerId } = request.params;
  const getmatchPlayersQuery = `
    SELECT
      player_id AS playerId,
      player_name AS playerName,
      SUM(score) AS totalScore,
      SUM(fours) AS totalFours,
      SUM(sixes) AS totalSixes
    FROM player_match_score
      NATURAL JOIN player_details
    WHERE
      player_id = ${playerId};`;
  const playersMatchDetails = await database.get(getmatchPlayersQuery);
  response.send(playersMatchDetails);
});

module.exports = app;

REST APIs | Cheat Sheet:
----------------------------------------------------------

Concepts in Focus:

Get Books API:
	Filtering Books

REST APIs:
	Why Rest Principles?
	REST API Principles
	
1. Get Books API
Let's see how to add Filters to Get Books API

1.1 Filtering Books:

Get a specific number of books
Get books based on search query text
Get books in the sorted order

1.1.1 Get a specific number of books

To get specific number of books in certain range we use limit and offset.

Offset is used to specify the position from where rows are to be selected.

Limit is used to specify the number of rows.
and many more...

Query parameters starts with ? (question mark) followed by key value pairs separated by & (ampersand)

Example :

http://localhost:3000/books/?limit=2

http://localhost:3000/books/?offset=2&limit=3

http://localhost:3000/authors/20/books/?offset=2

Note
The query parameters are used to sort/filter resources.

The path parameters are used to identify a specific resource(s)

1.1.2 Get books based on search query text
We provide query text to search_q key

search_q = potter

1.1.3 Get books in the sorted order
We provide sorted order to order key

Ascending: ASC
DESCENDING: DESC

order = ASC
order = DESC

Filtering GET Books API

app.get("/books/", async (request, response) => {
  const {
    offset = 2,
    limit = 5,
    order = "ASC",
    order_by = "book_id",
    search_q = "",
  } = request.query;
  const getBooksQuery = `
    SELECT
      *
    FROM
     book
    WHERE
     title LIKE '%${search_q}%'
    ORDER BY ${order_by} ${order}
    LIMIT ${limit} OFFSET ${offset};`;
  const booksArray = await db.all(getBooksQuery);
  response.send(booksArray);
});

2. REST APIs
REST: Representational State Transfer

REST is a set of principles that define how Web standards, such as HTTP and URLs, are supposed to be used.

2.1 Why Rest Principles?
Using Rest Principles improves application in various aspects like scalability, reliability etc

2.2 REST API Principles
Providing unique ID to each resource
Using standard methods like GET, POST, PUT, and DELETE
Accept and Respond with JSON

and many more...

coding pratice-8:
-------------------------------------

Todo Application:

Given an app.js file and an empty database file todoApplication.db.

Create a table with the name todo with the following columns,

Todo Table:

Column		Type
id			INTEGER
todo		TEXT
priority	TEXT
status		TEXT

and write APIs to perform operations on the table todo,

Note
Replace the spaces in URL with %20.
Possible values for priority are HIGH, MEDIUM, and LOW.
Possible values for status are TO DO, IN PROGRESS, and DONE.

API 1

Path: /todos/
Method: GET
Scenario 1

Sample API /todos/?status=TO%20DO

Description:

Returns a list of all todos whose status is 'TO DO'

Response

[
  {
    id: 1,
    todo: "Watch Movie",
    priority: "LOW",
    status: "TO DO"
  },
  ...
]

Scenario 2

Sample API /todos/?priority=HIGH

Description:

Returns a list of all todos whose priority is 'HIGH'

Response

[
  {
    id: 2,
    todo: "Learn Node JS",
    priority: "HIGH",
    status: "IN PROGRESS"
  },
  ...
]

Scenario 3

Sample API /todos/?priority=HIGH&status=IN%20PROGRESS

Description:

Returns a list of all todos whose priority is 'HIGH' and status is 'IN PROGRESS'

Response

[
  {
    id: 2,
    todo: "Learn Node JS",
    priority: "HIGH",
    status: "IN PROGRESS"
  },
  ...
]

Scenario 4

Sample API /todos/?search_q=Play

Description:

Returns a list of all todos whose todo contains 'Play' text

Response

[
  {
    id: 4,
    todo: "Play volleyball",
    priority: "MEDIUM",
    status: "DONE"
  },
  ...
]

API 2

Path: /todos/:todoId/
Method: GET
Description:
Returns a specific todo based on the todo ID

Response

{
  id: 2,
  todo: "Learn JavaScript",
  priority: "HIGH",
  status: "DONE"
}

API 3

Path: /todos/
Method: POST
Description:
Create a todo in the todo table,

Request

{
  "id": 10,
  "todo": "Finalize event theme",
  "priority": "LOW",
  "status": "TO DO"
}

Response
Todo Successfully Added

API 4

Path: /todos/:todoId/
Method: PUT
Description:
Updates the details of a specific todo based on the todo ID

Scenario 1

Request

{
  "status": "DONE"
}

Response

Status Updated

Scenario 2

Request

{
  "priority": "HIGH"
}

Response

Priority Updated

Scenario 3

Request

{
  "todo": "Some task"
}

Response

Todo Updated

API 5

Path: /todos/:todoId/
Method: DELETE
Description:
Deletes a todo from the todo table based on the todo ID

Response
Todo Deleted

Use npm install to install the packages.

Export the express instance using the default export syntax.

Use Common JS module syntax.

/*
 *  Created a Table with name todo in the todoApplication.db file using the CLI.
 */

const express = require("express");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require("path");

const databasePath = path.join(__dirname, "todoApplication.db");

const app = express();

app.use(express.json());

let database = null;

const initializeDbAndServer = async () => {
  try {
    database = await open({
      filename: databasePath,
      driver: sqlite3.Database,
    });

    app.listen(3000, () =>
      console.log("Server Running at http://localhost:3000/")
    );
  } catch (error) {
    console.log(`DB Error: ${error.message}`);
    process.exit(1);
  }
};

initializeDbAndServer();

const hasPriorityAndStatusProperties = (requestQuery) => {
  return (
    requestQuery.priority !== undefined && requestQuery.status !== undefined
  );
};

const hasPriorityProperty = (requestQuery) => {
  return requestQuery.priority !== undefined;
};

const hasStatusProperty = (requestQuery) => {
  return requestQuery.status !== undefined;
};
app.get("/todos/", async (request, response) => {
  let data = null;
  let getTodosQuery = "";
  const { search_q = "", priority, status } = request.query;

  switch (true) {
    case hasPriorityAndStatusProperties(request.query):
      getTodosQuery = `
      SELECT
        *
      FROM
        todo 
      WHERE
        todo LIKE '%${search_q}%'
        AND status = '${status}'
        AND priority = '${priority}';`;
      break;
    case hasPriorityProperty(request.query):
      getTodosQuery = `
      SELECT
        *
      FROM
        todo 
      WHERE
        todo LIKE '%${search_q}%'
        AND priority = '${priority}';`;
      break;
    case hasStatusProperty(request.query):
      getTodosQuery = `
      SELECT
        *
      FROM
        todo 
      WHERE
        todo LIKE '%${search_q}%'
        AND status = '${status}';`;
      break;
    default:
      getTodosQuery = `
      SELECT
        *
      FROM
        todo 
      WHERE
        todo LIKE '%${search_q}%';`;
  }

  data = await database.all(getTodosQuery);
  response.send(data);
});

app.get("/todos/:todoId/", async (request, response) => {
  const { todoId } = request.params;

  const getTodoQuery = `
    SELECT
      *
    FROM
      todo
    WHERE
      id = ${todoId};`;
  const todo = await database.get(getTodoQuery);
  response.send(todo);
});

app.post("/todos/", async (request, response) => {
  const { id, todo, priority, status } = request.body;
  const postTodoQuery = `
  INSERT INTO
    todo (id, todo, priority, status)
  VALUES
    (${id}, '${todo}', '${priority}', '${status}');`;
  await database.run(postTodoQuery);
  response.send("Todo Successfully Added");
});

app.put("/todos/:todoId/", async (request, response) => {
  const { todoId } = request.params;
  let updateColumn = "";
  const requestBody = request.body;
  switch (true) {
    case requestBody.status !== undefined:
      updateColumn = "Status";
      break;
    case requestBody.priority !== undefined:
      updateColumn = "Priority";
      break;
    case requestBody.todo !== undefined:
      updateColumn = "Todo";
      break;
  }
  const previousTodoQuery = `
    SELECT
      *
    FROM
      todo
    WHERE 
      id = ${todoId};`;
  const previousTodo = await database.get(previousTodoQuery);

  const {
    todo = previousTodo.todo,
    priority = previousTodo.priority,
    status = previousTodo.status,
  } = request.body;

  const updateTodoQuery = `
    UPDATE
      todo
    SET
      todo='${todo}',
      priority='${priority}',
      status='${status}'
    WHERE
      id = ${todoId};`;

  await database.run(updateTodoQuery);
  response.send(`${updateColumn} Updated`);
});

app.delete("/todos/:todoId/", async (request, response) => {
  const { todoId } = request.params;
  const deleteTodoQuery = `
  DELETE FROM
    todo
  WHERE
    id = ${todoId};`;

  await database.run(deleteTodoQuery);
  response.send("Todo Deleted");
});

module.exports = app;


Debugging Common Errors | Cheat Sheet:
---------------------------------------------------------------------------------

Concepts in Focus:
Importing Unknown Modules
Starting Server in Multiple Terminals
Starting Server outside the myapp
Accessing Wrong URL
Missing Function Call
Importing Unknown File

1. Importing Unknown Modules
When we try to import unknown modules

root@123:/.../myapp# nodemon index.js
[nodemon] 2.0.7
[nodemon] to restart at any time, enter `rs`
[nodemon] watching path(s): *.*
[nodemon] watching extensions: js,mjs,json
[nodemon] starting `node index.js`
internal/modules/cjs/loader.js:968
  throw err;
  ^

Error: Cannot find module 'expresses'
Require stack:
- /home/workspace/nodejs/sessions/Introduction-to-Express-JS-Part-2/myapp/index.js
    at Function.Module._resolveFilename (internal/modules/cjs/loader.js:965:15)
    at Function.Module._load (internal/modules/cjs/loader.js:841:27)
    at Module.require (internal/modules/cjs/loader.js:1025:19)
    at require (internal/modules/cjs/helpers.js:72:18)
    at Object.<anonymous> (/home/workspace/nodejs/sessions/Introduction-to-Express-JS-Part-2/myapp/index.js:1:17)
    at Module._compile (internal/modules/cjs/loader.js:1137:30)
    at Object.Module._extensions..js (internal/modules/cjs/loader.js:1157:10)
    at Module.load (internal/modules/cjs/loader.js:985:32)
    at Function.Module._load (internal/modules/cjs/loader.js:878:14)
    at Function.executeUserEntryPoint [as runMain] (internal/modules/run_main.js:71:12) {
  code: 'MODULE_NOT_FOUND',
  requireStack: [
    '/home/workspace/nodejs/sessions/Introduction-to-Express-JS-Part-2/myapp/index.js'
  ]
}
[nodemon] app crashed - waiting for file changes before starting...

2. Starting Server in Multiple Terminals
When we try to start the server in multiple terminals

root@123:/.../myapp# nodemon index.js
[nodemon] 2.0.7
[nodemon] to restart at any time, enter `rs`
[nodemon] watching path(s): *.*
[nodemon] watching extensions: js,mjs,json
[nodemon] starting `node index.js`
events.js:292
      throw er; // Unhandled 'error' event
      ^

Error: listen EADDRINUSE: address already in use :::3000
    at Server.setupListenHandle [as _listen2] (net.js:1313:16)
    at listenInCluster (net.js:1361:12)
    at Server.listen (net.js:1447:7)
    at Function.listen (/home/workspace/nodejs/sessions/Introduction-to-Express-JS-Part-2/myapp/node_modules/.pnpm/express@4.17.1/node_modules/express/lib/application.js:618:24)
    at initializeDBAndServer (/home/workspace/nodejs/sessions/Introduction-to-Express-JS-Part-2/myapp/index.js:16:9)
Emitted 'error' event on Server instance at:
    at emitErrorNT (net.js:1340:8)
    at processTicksAndRejections (internal/process/task_queues.js:84:21) {
  code: 'EADDRINUSE',
  errno: 'EADDRINUSE',
  syscall: 'listen',
  address: '::',
  port: 3000
}
[nodemon] app crashed - waiting for file changes before starting...

When you get address already in use :::3000 error

Step 1: Kill the currently running process in the terminal with Ctrl + C

Step 2: Run lsof -i :port_number in your CCBP IDE Terminal

Step 3: Run kill -9 process_id in your CCBP IDE Terminal

Example :

root@123:/.../...part-3/myapp# nodemon index.js
[nodemon] starting `node index.js`
events.js:292
      throw er; // Unhandled 'error' event
      ^
Error: listen EADDRINUSE: address already in use :::3000
.
.
.
^C

root@123:/.../...part-3# lsof -i :3000

COMMAND  PID USER   FD   TYPE DEVICE SIZE/OFF NODE NAME
node    9841 root   20u  IPv6 345981      0t0  TCP *:3000 (LISTEN)

root@123:/.../...part-3# kill -9 9841
root@123:/.../...part-3#

3. Starting Server outside the myapp
When we try to start the server outside myapp using node

root@123:/.../...part-3# node index.js
internal/modules/cjs/loader.js:968
  throw err;
  ^

Error: Cannot find module '/.../...Part-3/index.js'
root@123:/.../...part-3#

When we try to start the server outside myapp using nodemon

root@123:/.../...part-3# nodemon index.js
Usage: nodemon [nodemon options] [script.js] [args]

  See "nodemon --help" for more.

root@123:/.../...part-3#

Debugging Common Errors | Part 2 | Cheat Sheet:
---------------------------------------------------------------------------------------------------

Concepts in Focus:

Request Methods
Missing colon(:)
Accessing Path Parameters
Query Formatting
Replacing SQLite Methods
HTTP Request URL
Missing '?'
Missing ‘&’ between Query Parameters
Replacing '&' with ',' in Query Parameters
Accessing Unknown Database
Accessing Wrong Port Number

Authentication | Cheat Sheet:
-------------------------------------------------------------

Concepts in Focus:

Installing Third-party package bcrypt

Goodreads APIs for Specified Users
	Register User API
	Login User API
	
1. Installing Third-party package bcrypt
Storing the passwords in plain text within a database is not a good idea since they can be misused, So Passwords should be encrypted

bcrypt package provides functions to perform operations like encryption, comparison, etc

bcrypt.hash() uses various processes and encrypts the given password and makes it unpredictable
bcrypt.compare() function compares the password entered by the user and hash against each other

Installation Command

root@123:~/myapp# npm install bcrypt --save

2. Goodreads APIs for Specified Users
We need to maintain the list of users in a table and provide access only to that specified users

User needs to be registered and then log in to access the books

Register User API
Login User API

2.1 Register User API
Here we check whether the user is a new user or an existing user.
Returns "User Already exists" for existing user else for a new user we store encrypted password in the DB

app.post("/users/", async (request, response) => {
  const { username, name, password, gender, location } = request.body;
  const hashedPassword = await bcrypt.hash(request.body.password, 10);
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}'`;
  const dbUser = await db.get(selectUserQuery);
  if (dbUser === undefined) {
    const createUserQuery = `
      INSERT INTO 
        user (username, name, password, gender, location) 
      VALUES 
        (
          '${username}', 
          '${name}',
          '${hashedPassword}', 
          '${gender}',
          '${location}'
        )`;
    const dbResponse = await db.run(createUserQuery);
    const newUserId = dbResponse.lastID;
    response.send(`Created new user with ${newUserId}`);
  } else {
    response.status = 400;
    response.send("User already exists");
  }
});

2.2 Login User API
Here we check whether the user exists in DB or not.
Returns "Invalid User" if the user doesn't exist else we compare the given password with the DB user password

app.post("/login", async (request, response) => {
  const { username, password } = request.body;
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}'`;
  const dbUser = await db.get(selectUserQuery);
  if (dbUser === undefined) {
    response.status(400);
    response.send("Invalid User");
  } else {
    const isPasswordMatched = await bcrypt.compare(password, dbUser.password);
    if (isPasswordMatched === true) {
      response.send("Login Success!");
    } else {
      response.status(400);
      response.send("Invalid Password");
    }
  }
});

Status Codes

Status Codes	Status Text ID
200					OK
204				No Response
301				Moved Permanently
400				Bad Request
403				Forbidden
401				Unauthorized

coding pratice-9:
-----------------------------------------

Authentication
Given an app.js file and a database file userData.db consisting of a  table user.

Write APIs to perform operations on the table user containing the following columns,

User Table

Column		Type
username	TEXT
name		TEXT
password	TEXT
gender		TEXT
location	TEXT

API 1

Path: /register
Method: POST
Request

{
  "username": "adam_richard",
  "name": "Adam Richard",
  "password": "richard_567",
  "gender": "male",
  "location": "Detroit"
}

Scenario 1

Description:

If the username already exists

Response
Status code
400

Status text
User already exists

Scenario 2

Description:

If the registrant provides a password with less than 5 characters

Response
Status code
400

Status text
Password is too short

Scenario 3

Description:

Successful registration of the registrant

Response
  
Status code
200

Status text
User created successfully

API 2

Path: /login
Method: POST
Request

{
  "username": "adam_richard",
  "password": "richard_567"
}

Scenario 1

Description:

If an unregistered user tries to login

Response
Status code
400

Status text
Invalid user

Scenario 2

Description:

If the user provides incorrect password

Response
Status code
400

Status text
Invalid password

Scenario 3

Description:

Successful login of the user

Response
Status code
200

Status text
Login success!

API 3

Path: /change-password
Method: PUT
Request

{
  "username": "adam_richard",
  "oldPassword": "richard_567",
  "newPassword": "richard@123"
}

Scenario 1

Description:

If the user provides incorrect current password

Response
Status code
400

Status text
Invalid current password

Scenario 2

Description:

If the user provides new password with less than 5 characters

Response
Status code
400

Status text
Password is too short

Scenario 3

Description:

Successful password update

Response
Status code
200

Status text
Password updated


Use npm install to install the packages.

Export the express instance using the default export syntax.

Use Common JS module syntax.

const express = require("express");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require("path");
const bcrypt = require("bcrypt");

const databasePath = path.join(__dirname, "userData.db");

const app = express();

app.use(express.json());

let database = null;

const initializeDbAndServer = async () => {
  try {
    database = await open({
      filename: databasePath,
      driver: sqlite3.Database,
    });

    app.listen(3000, () =>
      console.log("Server Running at http://localhost:3000/")
    );
  } catch (error) {
    console.log(`DB Error: ${error.message}`);
    process.exit(1);
  }
};

initializeDbAndServer();

const validatePassword = (password) => {
  return password.length > 4;
};

app.post("/register", async (request, response) => {
  const { username, name, password, gender, location } = request.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}';`;
  const databaseUser = await database.get(selectUserQuery);

  if (databaseUser === undefined) {
    const createUserQuery = `
     INSERT INTO
      user (username, name, password, gender, location)
     VALUES
      (
       '${username}',
       '${name}',
       '${hashedPassword}',
       '${gender}',
       '${location}'  
      );`;
    if (validatePassword(password)) {
      await database.run(createUserQuery);
      response.send("User created successfully");
    } else {
      response.status(400);
      response.send("Password is too short");
    }
  } else {
    response.status(400);
    response.send("User already exists");
  }
});

app.post("/login", async (request, response) => {
  const { username, password } = request.body;
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}';`;
  const databaseUser = await database.get(selectUserQuery);

  if (databaseUser === undefined) {
    response.status(400);
    response.send("Invalid user");
  } else {
    const isPasswordMatched = await bcrypt.compare(
      password,
      databaseUser.password
    );
    if (isPasswordMatched === true) {
      response.send("Login success!");
    } else {
      response.status(400);
      response.send("Invalid password");
    }
  }
});

app.put("/change-password", async (request, response) => {
  const { username, oldPassword, newPassword } = request.body;
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}';`;
  const databaseUser = await database.get(selectUserQuery);
  if (databaseUser === undefined) {
    response.status(400);
    response.send("Invalid user");
  } else {
    const isPasswordMatched = await bcrypt.compare(
      oldPassword,
      databaseUser.password
    );
    if (isPasswordMatched === true) {
      if (validatePassword(newPassword)) {
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        const updatePasswordQuery = `
          UPDATE
            user
          SET
            password = '${hashedPassword}'
          WHERE
            username = '${username}';`;

        const user = await database.run(updatePasswordQuery);

        response.send("Password updated");
      } else {
        response.status(400);
        response.send("Password is too short");
      }
    } else {
      response.status(400);
      response.send("Invalid current password");
    }
  }
});

module.exports = app;

 Authentication | Part 1:
 ----------------------------------------------------------------------
 
 - Goodreads APIs
   - Register user API
   - Login user API
- bcrypt
  - bcrypt.hash()
  - bcrypt.compare()
  
  
 //index.js
 
 const express = require("express");
const path = require("path");

const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const bcrypt = require('bcrypt');

const app = express();
app.use(express.json());

const dbPath = path.join(__dirname, "goodreads.db");

let db = null;

const initializeDBAndServer = async () => {
  try {
    db = await open({
      filename: dbPath,
      driver: sqlite3.Database,
    });
    app.listen(3000, () => {
      console.log("Server Running at http://localhost:3000/");
    });
  } catch (e) {
    console.log(`DB Error: ${e.message}`);
    process.exit(1);
  }
};
initializeDBAndServer();

// Get Books API
app.get("/books/", async (request, response) => {
  const getBooksQuery = `
  SELECT
    *
  FROM
    book
  ORDER BY
    book_id;`;
  const booksArray = await db.all(getBooksQuery);
  response.send(booksArray);
});


// User Register API
app.post("/users/", async (request, response) => {
  const { username, name, password, gender, location } = request.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const selectUserQuery = `
    SELECT 
      * 
    FROM 
      user 
    WHERE 
      username = '${username}';`;
  const dbUser = await db.get(selectUserQuery);
  if (dbUser === undefined) {
    const createUserQuery = `
     INSERT INTO
      user (username, name, password, gender, location)
     VALUES
      (
       '${username}',
       '${name}',
       '${hashedPassword}',
       '${gender}',
       '${location}'  
      );`;
    await db.run(createUserQuery);
    response.send("User created successfully");
  } else {
    response.status(400);
    response.send("User already exists");
  }
});


// User Login API
app.post("/login/", async (request, response) => {
  const { username, password } = request.body;
  const selectUserQuery = `
    SELECT
      *
    FROM
      user
    WHERE 
      username = '${username}';`;
  const dbUser = await db.get(selectUserQuery);

  if (dbUser === undefined) {
    response.status(400);
    response.send("Invalid User");
  } else {
    const isPasswordMatched = await bcrypt.compare(password, dbUser.password);
    if (isPasswordMatched === true) {
      response.send("Login Success!");
    } else {
      response.status(400);
      response.send("Invalid Password");
    }
  }
});

//goodreads.http

###

GET http://localhost:3000/books/
Authorization: Bearer JWT_TOKEN

###

POST http://localhost:3000/users/
Content-Type: application/json

{   
    "name":"rahul",
    "username":"rahul123",
    "password": "rahul@456",
    "gender": "Male",
    "location":"hyderabad"
}


###

POST http://localhost:3000/login/
Content-Type: application/json

{
    "username":"rahul123",
    "password": "rahul@456"
}

//package.json

{
  "name": "myapp",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "keywords": [],
  "author": "",
  "license": "ISC",
  "dependencies": {
    "bcrypt": "5.0.1",
    "express": "^4.17.1",
    "sqlite": "^4.0.19",
    "sqlite3": "^5.0.2"
  }
}

Authentication | Part 2 | Cheat Sheet:
-----------------------------------------------------------------------------------------------------

Authentication Mechanisms:

Token Authentication mechanism:
	Access Token
	How Token Authentication works?
	
JWT:
	How JWT works?
	JWT Package
	
Login User API by generating the JWT Token

How to pass JWT Token?

Get Books API with Token Authentication

1. Authentication Mechanisms
To check whether the user is logged in or not we use different Authentication mechanisms

Commonly used Authentication mechanisms:

Token Authentication
Session Authentication

2. Token Authentication mechanism
We use the Access Token to verify whether the user is logged in or not

2.1 Access Token
Access Token is a set of characters which are used to identify a user

Example:

It is used to verify whether a user is Valid/Invalid

2.2 How Token Authentication works?
Server generates token and certifies the client
Client uses this token on every subsequent request
Client don’t need to provide entire details every time

3. JWT
JSON Web Token is a standard used to create access tokens for an application
This access token can also be called as JWT Token

3.1 How JWT works?
Client: Login with username and password
Server: Returns a JWT Token
Client: Sends JWT Token while requesting
Server: Sends Response to the client

3.2 JWT Package
jsonwebtoken package provides jwt.sign and jwt.verify functions

jwt.sign() function takes payload, secret key, options as arguments and generates JWTToken out of it
jwt.verify() verifies jwtToken and if it’s valid, returns payload. Else, it throws an error

root@123root@123:.../myapp# npm install jsonwebtoken

4. Login User API by generating the JWT Token
When the user tries to log in, verify the Password.
Returns JWT Token if the password matches else return Invalid Password with status code 400.

JAVASCRIPT

app.post("/login", async (request, response) => {
  const { username, password } = request.body;
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}'`;
  const dbUser = await db.get(selectUserQuery);
  if (dbUser === undefined) {
    response.status(400);
    response.send("Invalid User");
  } else {
    const isPasswordMatched = await bcrypt.compare(password, dbUser.password);
    if (isPasswordMatched === true) {
      const payload = {
        username: username,
      };
      const jwtToken = jwt.sign(payload, "MY_SECRET_TOKEN");
      response.send({ jwtToken });
    } else {
      response.status(400);
      response.send("Invalid Password");
    }
  }
});

5. How to pass JWT Token?
We have to add an authorization header to our request and the JWT Token is passed as a Bearer token

GET http://localhost:3000/books?offset=2&limit=3&search_q=the&order_by=price&order=DESC
Authorization: bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoicmFodWwiLCJnZW5kZXIiOiJNYWxlIiwibG9jYXRpb24iOiJoeWRlcmFiYWQiLCJpYXQiOjE2MTc0MzI0MDd9.Eqevw5QE70ZAVrmOZUc6pflUbeI0ffZUmQLDHYplU8g

6. Get Books API with Token Authentication
Here we check for JWT Token from Headers.
If JWT Token is not present it returns an Invalid Access Token with status code 401 else verify the JWT Token.

app.get("/books/", (request, response) => {
  let jwtToken;
  const authHeader = request.headers["authorization"];
  if (authHeader !== undefined) {
    jwtToken = authHeader.split(" ")[1];
  }
  if (jwtToken === undefined) {
    response.status(401);
    response.send("Invalid Access Token");
  } else {
    jwt.verify(jwtToken, "MY_SECRET_TOKEN", async (error, payload) => {
      if (error) {
        response.send("Invalid Access Token");
      } else {
        const getBooksQuery = `
            SELECT
              *
            FROM
             book
            ORDER BY
              book_id;`;
        const booksArray = await db.all(getBooksQuery);
        response.send(booksArray);
      }
    });
  }
});

Authentication | Part 2:
-------------------------------------------------------------

- Introduction to Authentication
- Authentication Mechanisms
  - Token Authentication
    - JSON Web Token (JWT)
- JWT Methods
  - jwt.sign()
  - jwt.verify()
  
//index.js

const express = require("express");
const path = require("path");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const dbPath = path.join(__dirname, "goodreads.db");
const app = express();

app.use(express.json());

let db = null;

const initializeDBAndServer = async () => {
  try {
    db = await open({ filename: dbPath, driver: sqlite3.Database });
    app.listen(3000, () => {
      console.log("Server Running at http://localhost:3000/");
    });
  } catch (e) {
    console.log(`DB Error: ${e.message}`);
    process.exit(-1);
  }
};
initializeDBAndServer();

//Get Books API
app.get("/books/", (request, response) => {
  let jwtToken;
  const authHeader = request.headers["authorization"];
  if (authHeader !== undefined) {
    jwtToken = authHeader.split(" ")[1];
  }
  if (jwtToken === undefined) {
    response.status(401);
    response.send("Invalid Access Token");
  } else {
    jwt.verify(jwtToken, "MY_SECRET_TOKEN", async (error, payload) => {
      if (error) {
        response.send("Invalid Access Token");
      } else {
        const getBooksQuery = `
            SELECT
              *
            FROM
             book
            ORDER BY
             book_id;`;
        const booksArray = await db.all(getBooksQuery);
        response.send(booksArray);
      }
    });
  }
});

//Get Book API
app.get("/books/:bookId/", async(request, response) => {
    const { bookId } = request.params;
    const getBookQuery = `
      SELECT
       *
      FROM
       book 
      WHERE
       book_id = ${bookId};
    `;
    const book = await db.get(getBookQuery);
    response.send(book);
});


//User Register API
app.post("/users/", async (request, response) => {
  const { username, name, password, gender, location } = request.body;
  const hashedPassword = await bcrypt.hash(request.body.password, 10);
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}'`;
  const dbUser = await db.get(selectUserQuery);
  if (dbUser === undefined) {
    const createUserQuery = `
      INSERT INTO 
        user (username, name, password, gender, location) 
      VALUES 
        (
          '${username}', 
          '${name}',
          '${hashedPassword}', 
          '${gender}',
          '${location}'
        )`;
    await db.run(createUserQuery);
    response.send(`User created successfully`);
  } else {
    response.status(400);
    response.send("User already exists");
  }
});

//User Login API
app.post("/login/", async (request, response) => {
  const { username, password } = request.body;
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}'`;
  const dbUser = await db.get(selectUserQuery);
  if (dbUser === undefined) {
    response.status(400);
    response.send("Invalid User");
  } else {
    const isPasswordMatched = await bcrypt.compare(password, dbUser.password);
    if (isPasswordMatched === true) {
      const payload = {
        username: username,
      };
      const jwtToken = jwt.sign(payload, "MY_SECRET_TOKEN");
      response.send({ jwtToken });
    } else {
      response.status(400);
      response.send("Invalid Password");
    }
  }
});

//goodreads.http

GET http://localhost:3000/books/
Authorization: Bearer JWT_TOKEN

###

GET http://localhost:3000/books/1/

###

POST http://localhost:3000/users/
Content-Type: application/json

{    
    "username": "rahul123",
    "password": "rahul@456",
    "gender":"male",
    "location":"hyderabad"
}

###

POST http://localhost:3000/login/
Content-Type: application/json

{    
    "username": "rahul123",
    "password": "rahul@456"
}

//package.json:

{
  "name": "myapp",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "keywords": [],
  "author": "",
  "license": "ISC",
  "dependencies": {
    "bcrypt": "5.0.1",
    "express": "^4.17.1",
    "jsonwebtoken": "^8.5.1",
    "sqlite": "^4.0.19",
    "sqlite3": "^5.0.2"
  }
}

Authentication | Part 3 | Cheat Sheet:
-----------------------------------------------------------------------------------------

Middleware functions:
	Multiple Middleware functions
	
Logger Middleware Implementation:
	Defining a Middleware Function
	Logger Middleware Function
	Get Books API with Logger Middleware
	
Authenticate Token Middleware

Get Books API with Authenticate Token Middleware

Passing data from Authenticate Token Middleware

Get User Profile API with Authenticate Token Middleware

1. Middleware functions
Middleware is a special kind of function in Express JS which accepts the request from

the user (or)
the previous middleware

After processing the request the middleware function

sends the response to another middleware (or)
calls the API Handler (or)
sends response to the user

app.method(Path, middleware1, handler);

Example:

const jsonMiddleware = express.json();
app.use(jsonMiddleware);

It is a built-in middleware function it recognizes the incoming request object as a JSON object, parses it, and then calls handler in every API call

1.1 Multiple Middleware functions
We can pass multiple middleware functions

app.method(Path, middleware1, middleware2, handler);

2. Logger Middleware Implementation

2.1 Defining a Middleware Function

const middlewareFunction = (request, response, next) => {};

2.2 Logger Middleware Function

const logger = (request, response, next) => {
  console.log(request.query);
  next();
};

The next parameter is a function passed by Express JS which, when invoked, executes the next succeeding function

2.3 Get Books API with Logger Middleware

app.get("/books/", logger, async (request, response) => {
  const getBooksQuery = `
   SELECT
    *
   FROM
    book
   ORDER BY
    book_id;`;
  const booksArray = await db.all(getBooksQuery);
  response.send(booksArray);
});

3. Authenticate Token Middleware
In Authenticate Token Middleware we will verify the JWT Token

const authenticateToken = (request, response, next) => {
  let jwtToken;
  const authHeader = request.headers["authorization"];
  if (authHeader !== undefined) {
    jwtToken = authHeader.split(" ")[1];
  }
  if (jwtToken === undefined) {
    response.status(401);
    response.send("Invalid JWT Token");
  } else {
    jwt.verify(jwtToken, "MY_SECRET_TOKEN", async (error, payload) => {
      if (error) {
        response.status(401);
        response.send("Invalid JWT Token");
      } else {
        next();
      }
    });
  }
};

4. Get Books API with Authenticate Token Middleware
Let's Pass Authenticate Token Middleware to Get Books API

app.get("/books/", authenticateToken, async (request, response) => {
  const getBooksQuery = `
   SELECT
    *
   FROM
    book
   ORDER BY
    book_id;`;
  const booksArray = await db.all(getBooksQuery);
  response.send(booksArray);
});

5. Passing data from Authenticate Token Middleware
We cannot directly pass data to the next handler, but we can send data through the request object

const authenticateToken = (request, response, next) => {
  let jwtToken;
  const authHeader = request.headers["authorization"];
  if (authHeader !== undefined) {
    jwtToken = authHeader.split(" ")[1];
  }
  if (jwtToken === undefined) {
    response.status(401);
    response.send("Invalid JWT Token");
  } else {
    jwt.verify(jwtToken, "MY_SECRET_TOKEN", async (error, payload) => {
      if (error) {
        response.status(401);
        response.send("Invalid JWT Token");
      } else {
        request.username = payload.username;
        next();
      }
    });
  }
};

6. Get User Profile API with Authenticate Token Middleware
We can access request variable from the request object

app.get("/profile/", authenticateToken, async (request, response) => {
  let { username } = request;
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}'`;
  const userDetails = await db.get(selectUserQuery);
  response.send(userDetails);
});

7. Get Login

app.post("/login/", async (request, response) => {
  const { username, password } = request.body;
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}'`;
  const dbUser = await db.get(selectUserQuery);
  if (dbUser === undefined) {
    response.status(400);
    response.send("Invalid User");
  } else {
    const isPasswordMatched = await bcrypt.compare(password, dbUser.password);
    if (isPasswordMatched === true) {
      const payload = {
        username: username,
      };
      const jwtToken = jwt.sign(payload, "MY_SECRET_TOKEN");
      response.send({ jwtToken });
    } else {
      response.status(400);
      response.send("Invalid Password");
    }
  }
});


coding pratice-10:
---------------------------------------------------------------

Covid-19 India Portal
Given two files app.js and a database file covid19IndiaPortal.db consisting of three tables state, district and user.

Write APIs to perform operations on the tables state, district only after authentication of the user.

The columns of the tables are given below,

State Table:

Columns		Type
state_id	INTEGER
state_name	TEXT
population	INTEGER

District Table:

Columns			Type
district_id		INTEGER
district_name	TEXT
state_id		INTEGER
cases			INTEGER
cured			INTEGER
active			INTEGER
deaths			INTEGER
You can use your previous code if required.

Sample Valid User Credentials

{
  "username": "christopher_phillips",
  "password": "christy@123"
}

API 1

Path: /login/
Method: POST
Request

{
  "username": "christopher_phillips",
  "password": "christy@123"
}

Scenario 1

Description:

If an unregistered user tries to login

Response

Status code
400

Body
Invalid user

Scenario 2

Description:

If the user provides an incorrect password

Response

Status code
400

Body
Invalid password

Scenario 3

Description:

Successful login of the user

Response

Return the JWT Token

{
  "jwtToken": "ak2284ns8Di32......"
}

Authentication with Token

Scenario 1

Description:

If the token is not provided by the user or an invalid token

Response

Status code
401

Body
Invalid JWT Token

Scenario 2
After successful verification of token proceed to next middleware or handler

API 2

Path: /states/
Method: GET
Description:
Returns a list of all states in the state table

Response

[
  {
    "stateId": 1,
    "stateName": "Andaman and Nicobar Islands",
    "population": 380581
  },

  ...
]

API 3

Path: /states/:stateId/
Method: GET
Description:
Returns a state based on the state ID

Response

{
  "stateId": 8,
  "stateName": "Delhi",
  "population": 16787941
}

API 4

Path: /districts/
Method: POST
Description:
Create a district in the district table, district_id is auto-incremented

Request

{
  "districtName": "Bagalkot",
  "stateId": 3,
  "cases": 2323,
  "cured": 2000,
  "active": 315,
  "deaths": 8
}

Response
District Successfully Added

API 5

Path: /districts/:districtId/
Method: GET
Description:
Returns a district based on the district ID

Response

{
  "districtId": 322,
  "districtName": "Palakkad",
  "stateId": 17,
  "cases": 61558,
  "cured": 59276,
  "active": 2095,
  "deaths": 177
}

API 6

Path: /districts/:districtId/
Method: DELETE
Description:
Deletes a district from the district table based on the district ID

Response
District Removed

API 7

Path: /districts/:districtId/
Method: PUT
Description:
Updates the details of a specific district based on the district ID

Request

{
  "districtName": "Nadia",
  "stateId": 3,
  "cases": 9628,
  "cured": 6524,
  "active": 3000,
  "deaths": 104
}

Response

District Details Updated

API 8

Path: /states/:stateId/stats/
Method: GET
Description:
Returns the statistics of total cases, cured, active, deaths of a specific state based on state ID

Response

{
  "totalCases": 724355,
  "totalCured": 615324,
  "totalActive": 99254,
  "totalDeaths": 9777
}

Use npm install to install the packages.

Export the express instance using the default export syntax.

Use Common JS module syntax.

const express = require("express");
const { open } = require("sqlite");
const sqlite3 = require("sqlite3");
const path = require("path");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const databasePath = path.join(__dirname, "covid19IndiaPortal.db");

const app = express();

app.use(express.json());

let database = null;

const initializeDbAndServer = async () => {
  try {
    database = await open({
      filename: databasePath,
      driver: sqlite3.Database,
    });

    app.listen(3000, () =>
      console.log("Server Running at http://localhost:3000/")
    );
  } catch (error) {
    console.log(`DB Error: ${error.message}`);
    process.exit(1);
  }
};

initializeDbAndServer();

const convertStateDbObjectToResponseObject = (dbObject) => {
  return {
    stateId: dbObject.state_id,
    stateName: dbObject.state_name,
    population: dbObject.population,
  };
};

const convertDistrictDbObjectToResponseObject = (dbObject) => {
  return {
    districtId: dbObject.district_id,
    districtName: dbObject.district_name,
    stateId: dbObject.state_id,
    cases: dbObject.cases,
    cured: dbObject.cured,
    active: dbObject.active,
    deaths: dbObject.deaths,
  };
};

function authenticateToken(request, response, next) {
  let jwtToken;
  const authHeader = request.headers["authorization"];
  if (authHeader !== undefined) {
    jwtToken = authHeader.split(" ")[1];
  }
  if (jwtToken === undefined) {
    response.status(401);
    response.send("Invalid JWT Token");
  } else {
    jwt.verify(jwtToken, "MY_SECRET_TOKEN", async (error, payload) => {
      if (error) {
        response.status(401);
        response.send("Invalid JWT Token");
      } else {
        next();
      }
    });
  }
}

app.post("/login/", async (request, response) => {
  const { username, password } = request.body;
  const selectUserQuery = `SELECT * FROM user WHERE username = '${username}';`;
  const databaseUser = await database.get(selectUserQuery);
  if (databaseUser === undefined) {
    response.status(400);
    response.send("Invalid user");
  } else {
    const isPasswordMatched = await bcrypt.compare(
      password,
      databaseUser.password
    );
    if (isPasswordMatched === true) {
      const payload = {
        username: username,
      };
      const jwtToken = jwt.sign(payload, "MY_SECRET_TOKEN");
      response.send({ jwtToken });
    } else {
      response.status(400);
      response.send("Invalid password");
    }
  }
});

app.get("/states/", authenticateToken, async (request, response) => {
  const getStatesQuery = `
    SELECT
      *
    FROM
      state;`;
  const statesArray = await database.all(getStatesQuery);
  response.send(
    statesArray.map((eachState) =>
      convertStateDbObjectToResponseObject(eachState)
    )
  );
});

app.get("/states/:stateId/", authenticateToken, async (request, response) => {
  const { stateId } = request.params;
  const getStateQuery = `
    SELECT 
      *
    FROM 
      state 
    WHERE 
      state_id = ${stateId};`;
  const state = await database.get(getStateQuery);
  response.send(convertStateDbObjectToResponseObject(state));
});

app.get(
  "/districts/:districtId/",
  authenticateToken,
  async (request, response) => {
    const { districtId } = request.params;
    const getDistrictsQuery = `
    SELECT
      *
    FROM
     district
    WHERE
      district_id = ${districtId};`;
    const district = await database.get(getDistrictsQuery);
    response.send(convertDistrictDbObjectToResponseObject(district));
  }
);

app.post("/districts/", authenticateToken, async (request, response) => {
  const { stateId, districtName, cases, cured, active, deaths } = request.body;
  const postDistrictQuery = `
  INSERT INTO
    district (state_id, district_name, cases, cured, active, deaths)
  VALUES
    (${stateId}, '${districtName}', ${cases}, ${cured}, ${active}, ${deaths});`;
  await database.run(postDistrictQuery);
  response.send("District Successfully Added");
});

app.delete(
  "/districts/:districtId/",
  authenticateToken,
  async (request, response) => {
    const { districtId } = request.params;
    const deleteDistrictQuery = `
  DELETE FROM
    district
  WHERE
    district_id = ${districtId} 
  `;
    await database.run(deleteDistrictQuery);
    response.send("District Removed");
  }
);

app.put(
  "/districts/:districtId/",
  authenticateToken,
  async (request, response) => {
    const { districtId } = request.params;
    const {
      districtName,
      stateId,
      cases,
      cured,
      active,
      deaths,
    } = request.body;
    const updateDistrictQuery = `
  UPDATE
    district
  SET
    district_name = '${districtName}',
    state_id = ${stateId},
    cases = ${cases},
    cured = ${cured},
    active = ${active}, 
    deaths = ${deaths}
  WHERE
    district_id = ${districtId};
  `;

    await database.run(updateDistrictQuery);
    response.send("District Details Updated");
  }
);

app.get(
  "/states/:stateId/stats/",
  authenticateToken,
  async (request, response) => {
    const { stateId } = request.params;
    const getStateStatsQuery = `
    SELECT
      SUM(cases),
      SUM(cured),
      SUM(active),
      SUM(deaths)
    FROM
      district
    WHERE
      state_id=${stateId};`;
    const stats = await database.get(getStateStatsQuery);
    response.send({
      totalCases: stats["SUM(cases)"],
      totalCured: stats["SUM(cured)"],
      totalActive: stats["SUM(active)"],
      totalDeaths: stats["SUM(deaths)"],
    });
  }
);

module.exports = app;

//Package.json

{
    "name": "covid19-portal",
    "version": "1.0.0",
    "description": "",
    "main": "app.js",
    "author": "",
    "license": "ISC",
    "dependencies": {
        "jsonwebtoken": "8.5.1",
        "bcrypt": "5.0.1",
        "express": "4.17.1",
        "nodemon": "2.0.7",
        "sqlite": "4.0.19",
        "sqlite3": "5.0.2"
    }
}
