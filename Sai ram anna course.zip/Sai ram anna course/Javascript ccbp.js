https://flaviocopes.com/javascript-automatic-semicolon-insertion/

https://betterprogramming.pub/difference-between-regular-functions-and-arrow-functions-f65639aba256

https://javascript.info/bubbling-and-capturing#bubbling

https://www.w3schools.com/js/js_debugging.asp

https://fonts.google.com/icons

HTTP Requests using JS | Cheat Sheet:
-------------------------------------------------------

You can get the ACCESS_TOKEN from this website.

Follow below steps for getting ACCESS_TOKEN:


You can get your unique access token by logging in to https://gorest.co.in/.

JavaScript Variables:
--------------------------------

1.1 Variable Declaration:

Variables are like containers for storing values. We can create a variable using the let keyword.

let message;

1.2 Assigning a Value to the Variable:
-------------------------------------------

let message = 'Hello Rahul';

let message;
message = 'Hello Rahul';

Note:

Printing a variable without assigning a value will give the output undefined.

Document Object Model (DOM):
-------------------------------------

The DOM is the structured representation of the HTML document created by the browser. 
It allows JavaScript to manipulate, structure, and style your website.

<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <h1>Web Technologies</h1>
    <button>Change Heading</button>
  </body>
</html>

Document Object:
------------------------

It is the entry point of the DOM. For accessing any HTML Element, you should always start with accessing the document object first.

HTML DOM Tree:
-----------------------

The DOM tree represents an HTML document as nodes. Each node is referred to as an Object

Methods:
------------

2.3.1 getElementById:
---------------------------

The getElementById() method helps to select the HTML Element with a specific ID.

console.log(document.getElementById("headingElement"))

Properties:
-------------------

2.4.1 textContent:
---------------------------

To manipulate the text within the HTML Element, we use textContent Property.

2.4.2 style:
--------------------
The style property is used to get or set a specific style of an HTML Element using different CSS properties.

Use Camel Case naming convention (starting letter of each word should be in the upper case except for the first word) for naming the Style Object Properties.

For example, color, fontFamily, backgroundColor, etc.

2.5 Events:
------------------

Events are the actions by which the user or browser interacts with the HTML Elements. 
Actions can be anything like clicking a button, pressing keyboard keys, scrolling the page, etc.

2.5.1 onclick Event:
-------------------------

The onclick event occurs when the user clicks on an HTML Element. We will give the name of the function as a value for the HTML onclick attribute.

HTML:

<body>
  <h1 id="headingElement">Web Technologies</h1>
  <button onclick="manipulateStyles()">Change Heading</button>
</body>

JS:

function manipulateStyles() {
  document.getElementById("headingElement").textContent = "4.O Technologies";
  document.getElementById("headingElement").style.color = "blue";
   8
}

cat and light:
------------------------

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="dark-background text-center">
      <div>
        <img
          src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/bulb-go-on-img.png"
          class="bulb-image"
          id="bulbImage"
        />
      </div>
      <div>
        <img
          src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/cat-img.png"
          class="cat-image"
          id="catImage"
        />
      </div>
      <div class="d-flex flex-row justify-content-center pt-5">
        <div class="switch-board">
          <h1 class="switch-status" id="switchStatus">Switched On</h1>
          <button class="off-switch" id="offSwitch" onclick="switchOff()">
            OFF
          </button>
          <button class="on-switch" id="onSwitch" onclick="switchOn()">
            ON
          </button>
        </div>
      </div>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.dark-background {
  background-color: #0b0b0b;
}
.bulb-image {
  width: 150px;
}
.cat-image {
  width: 300px;
}
.switch-board {
  background-color: #7b8794;
  width: 294px;
  height: 139px;
  border-radius: 12px;
  padding-left: 16px;
  padding-right: 16px;
  padding-top: 32px;
  padding-bottom: 32px;
  margin: 16px;
}
.switch-status {
  color: #ffffff;
  font-family: "Roboto";
  font-size: 24px;
  font-weight: 500;
  margin-bottom: 24px;
}
.on-switch {
  color: #ffffff;
  background-color: #cbd2d9;
  font-family: "Roboto";
  font-size: 24px;
  font-weight: bold;
  width: 99px;
  height: 44px;
  border-radius: 8px;
  margin-left: 16px;
}
.off-switch {
  color: #ffffff;
  background-color: #e12d39;
  font-family: "Roboto";
  font-size: 24px;
  font-weight: bold;
  width: 99px;
  height: 44px;
  border-radius: 8px;
}

JS:

function switchOff() {
  document.getElementById("bulbImage").src =
    "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/bulb-go-off-img.png";
  document.getElementById("catImage").src =
    "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/cat-eyes-img.png";
  document.getElementById("switchStatus").textContent = "Switched Off";
  document.getElementById("onSwitch").style.backgroundColor = "#22c55e";
  document.getElementById("offSwitch").style.backgroundColor = "#cbd2d9";
}

function switchOn() {
  document.getElementById("bulbImage").src =
    "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/bulb-go-on-img.png";
  document.getElementById("catImage").src =
    "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/cat-img.png";
  document.getElementById("switchStatus").textContent = "Switched On";
  document.getElementById("offSwitch").style.backgroundColor = "#e12d39";
  document.getElementById("onSwitch").style.backgroundColor = "#cbd2d9";
}

counter:
-------------------

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="bg-container text-center d-flex flex-column justify-content-center">
      <h1 class="counter-heading">Counter</h1>
      <p id="counterValue" class="counter-value">0</p>
      <div>
        <button onClick="onDecrement()" class="button">DECREASE</button>
        <button onClick="onReset()" class="button">RESET</button>
        <button onClick="onIncrement()" class="button">INCREASE</button>
      </div>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
  background-color: #f1f5f8;
  height: 100vh;
}
.counter-heading {
  font-family: "Roboto";
  font-size: 50px;
  font-weight: 800;
}
.counter-value {
  font-size: 75px;
  font-weight: 900;
}
.button {
  background-color: #f1f5f8;
  border-width: 2px;
  border-color: black;
  border-radius: 7px;
  margin: 8px;
  padding: 5px;
}

JS:

let counterElement = document.getElementById("counterValue");

function onIncrement() {
  let previousCounterValue = counterElement.textContent;
  let updatedCounterValue = parseInt(previousCounterValue) + 1;
  if (updatedCounterValue > 0) {
    counterElement.style.color = "green";
  }
  else if (updatedCounterValue < 0) {
    counterElement.style.color = "red";
  }
  else {
    counterElement.style.color = "black";
  }
  counterElement.textContent = updatedCounterValue;
}

function onDecrement() {
  let previousCounterValue = counterElement.textContent;
  let updatedCounterValue = parseInt(previousCounterValue) - 1;
  if (updatedCounterValue > 0) {
    counterElement.style.color = "green";
  }
  else if (updatedCounterValue < 0) {
    counterElement.style.color = "red";
  }
  else {
    counterElement.style.color = "black";
  }
  counterElement.textContent = updatedCounterValue;
}

function onReset() {
  let counterValue = 0;
  counterElement.textContent = counterValue;
  counterElement.style.color = "black";
}


value:
---------------

HTML:

<!DOCTYPE html>
<html>

<head></head>

<body>
    <p>Enter your Name</p>
    <input type="text" id="inputElement" />
    <p>Enter your Password</p>
    <input type="password" />
    <div>
        <button onclick="signIn()">Sign In</button>
    </div>
    <p id="signInText"></p>
</body>

</html>

JS:

let inputElement = document.getElementById("inputElement");
let signInTextElement = document.getElementById("signInText");

function signIn() {
    let inputValue = inputElement.value;
    let verifyText = "Hi " + inputValue + ", verifying your account...";
    signInTextElement.textContent = verifyText;
}

Guessing Game:
---------------------------
HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"/>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="container-fluid bg-container">
      <div class="row bg-white">
        <div class="col-12 col-md-6 m-auto bg-white pt-5 pb-5">
          <img
            class="guess-game-img"
            src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/guess-game-img.png"
          />
          <p class="text-center game-description">
            Find out the right number between 1 to 100
          </p>
        </div>
      </div>
      <div class="row">
        <div class="col-12 guess-bg-container text-center">
          <h1 class="guess-heading">
            Guess The Number
            <img
              class="guess-number-image"
              src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/guess-number-img.png"
            />
          </h1>
          <input type="text" class="user-input" id="userInput" />
          <div>
            <button class="btn btn-info check-guess" onclick="checkGuess()">
              Check
            </button>
          </div>
          <p class="game-result" id="gameResult"></p>
        </div>
      </div>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
  background-color: #246db6;
  height: 100vh;
}

.guess-game-img {
  width: 100%;
}

.game-description {
  color: #323f4b;
  font-family: "Roboto";
  font-size: 24px;
  font-weight: 500;
  margin-top: 20px;
}

.guess-bg-container {
  background-color: #246db6;
  padding-top: 30px;
  padding-bottom: 30px;
}

.guess-heading {
  color: white;
  font-family: "Roboto";
  font-size: 34px;
  font-weight: bold;
}

.guess-number-image {
  width: 50px;
}

.user-input {
  text-align: center;
  color: #1f2933;
  font-family: "Roboto";
  font-size: 30px;
  font-weight: 500;
  width: 300px;
  padding: 10px;
}

.game-result {
  color: #ffffff;
  font-family: "Roboto";
  font-size: 24px;
  font-weight: 500;
  padding: 10px;
}

.check-guess {
  width: 170px;
  border-radius: 5px;
  margin: 20px;
  padding: 10px;
}

JS:

let gameResult = document.getElementById("gameResult");
let userInput = document.getElementById("userInput");
let randomNumber = Math.ceil(Math.random() * 100);
function checkGuess() {
  let guessedNumber = parseInt(userInput.value);
  if (guessedNumber > randomNumber) {
    gameResult.textContent = "Too High! Try Again.";
    gameResult.style.backgroundColor = "#1e217c";
  }
  else if (guessedNumber < randomNumber) {
    gameResult.textContent = "Too Low! Try Again.";
    gameResult.style.backgroundColor = "#1e217c";
  }
  else if (guessedNumber === randomNumber) {
    gameResult.textContent = "Congratulations! You got it right.";
    gameResult.style.backgroundColor = "green";
  }
  else {
    gameResult.textContent = "Please provide a valid input.";
    gameResult.style.backgroundColor = "#1e217c";
  }
}

coding pratice-1:
-------------------------------

Color picker:
------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="color-picker-container d-flex flex-column justify-content-center text-center" id="colorPickerContainer">
        <h1 class="color-picker-heading">Color Picker</h1>
        <div class="mt-3 mb-3">
            <button class="button button-1" id="button1" onclick="changeBgToGreyAndUpdateText()">#e0e0e0</button>
            <button class="button button-2" id="button2" onclick="changeBgToGreenAndUpdateText()">#6fcf97</button>
            <button class="button button-3" id="button3" onclick="changeBgToBlueAndUpdateText()">#56ccf2</button>
            <button class="button button-4" id="button4" onclick="changeBgToPurpleAndUpdateText()">#bb6bd9</button>
        </div>
        <p class="selected-color-text">Background Color : <span class="selected-color-hex-code" id="selectedColorHexCode">#fffff</span></p>
        <p class="color-picker-instruction">Try clicking on one of the colors above to change the background color of this page!</p>
    </div>
</body>

</html>


CSS:

@import url('https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap');

.color-picker-container{
    background-color: #ffffff;
    height: 100vh;
}

.color-picker-heading{
    font-family: "Open Sans";
    font-size: 50px;
    font-weight: 800;
}

.button{
    font-family: "Open Sans";
    font-size: 14px;
    width: 100px;
    height: 100px;
    border-width: 3px;
    border-color: black;
    border-radius: 20px;
    margin-bottom: 10px;
}

.button-1{
    background-color: #e0e0e0;
}

.button-2{
    background-color: #6fcf97;
}

.button-3{
    background-color: #56ccf2;
}

.button-4{
    background-color: #bb6bd9;
}

.selected-color-text{
    background-color: #222222;
    color: white;
    font-family: "Open Sans";
    font-size: 25px;
    font-weight: bold;
    border-radius: 8px;
    padding: 16px;
}

.selected-color-hex-code{
    color: #49a6e9;
}

.color-picker-instruction{
    font-family: "Open Sans";
    font-size: 20px;
}

JS:

let colorPickerContainerElement = document.getElementById("colorPickerContainer");
let selectedColorHexCodeElement = document.getElementById("selectedColorHexCode");

function changeBgToGreyAndUpdateText(){
    colorPickerContainerElement.style.backgroundColor="#e0e0e0";
    selectedColorHexCodeElement.textContent = "#e0e0e0";
    
}

function changeBgToGreenAndUpdateText(){
    colorPickerContainerElement.style.backgroundColor = "#6fcf97";
    selectedColorHexCodeElement.textContent = "#6fcf97";
}

function changeBgToBlueAndUpdateText(){
    colorPickerContainerElement.style.backgroundColor = "#56ccf2";
    selectedColorHexCodeElement.textContent = "#56ccf2";
}

function changeBgToPurpleAndUpdateText(){
    colorPickerContainerElement.style.backgroundColor = "#bb6bd9";
    selectedColorHexCodeElement.textContent = "#bb6bd9";
}

Traffic Light:
------------------------------

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"/>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="traffic-light-container">
      <h1 class="traffic-light-heading text-center">Traffic Light</h1>
      <div class="d-flex flex-row justify-content-center m-5">
        <div class="d-flex flex-column">
          <button id="stopButton" class="button" onclick="turnOnRed()">Stop</button>
          <button id="readyButton" class="button" onclick="turnOnYellow()">Ready</button>
          <button id="goButton" class="button" onclick="turnOnGreen()">Go</button>
        </div>
        <div class="traffic-light">
          <div id="stopLight" class="bulb"></div>
          <div id="readyLight" class="bulb"></div>
          <div id="goLight" class="bulb"></div>
        </div>
      </div>
    </div>
  </body>
</html>


CSS:

@import url('https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap');

.traffic-light-container{
    background-color: #86d2f2;
    padding: 20px;
}

.traffic-light-heading{
    color: #1f1d41;
    font-family: "Roboto";
    font-size: 46px;
    font-weight: bold;
}

.button{
    background-color: #1f1d41;
    color: white;
    font-size: 15px;
    width: 70px;
    height: 40px;
    border-width: 0px;
    border-radius: 10px;
    margin-top: 45px;
}

.traffic-light{
    background-color: #1f1d41;
    width: 100px;
    height: 300px;
    padding: 20px;
    border-radius: 40px;
    margin-left: 30px;
}

.bulb{
    background-color: #4b5069;
    width: 50px;
    height: 50px;
    border-radius: 50px;
    margin-left: 5px;
    margin-top: 25px;
    margin-bottom: 25px;
}

JS:

let stopLightElement = document.getElementById("stopLight");
let readyLightElement = document.getElementById("readyLight");
let goLightElement = document.getElementById("goLight");
let stopButtonElement = document.getElementById("stopButton");
let readyButtonElement = document.getElementById("readyButton");
let goButtonElement = document.getElementById("goButton");

function turnOnRed(){
    stopLightElement.style.backgroundColor ="#cf1124";
    stopButtonElement.style.backgroundColor="#cf1124";
    
    readyLightElement.style.backgroundColor ="#4b5069";
    readyButtonElement.style.backgroundColor="#1f1d41";

    goLightElement.style.backgroundColor ="#4b5069";
    goButtonElement.style.backgroundColor="#1f1d41";
}
function turnOnYellow(){
    stopLightElement.style.backgroundColor ="#4b5069";
    stopButtonElement.style.backgroundColor="#1f1d41";

    readyLightElement.style.backgroundColor ="#f7c948";
    readyButtonElement.style.backgroundColor="#f7c948";
    
    goLightElement.style.backgroundColor ="#4b5069";
    goButtonElement.style.backgroundColor="#1f1d41";
}
function turnOnGreen(){
    stopLightElement.style.backgroundColor ="#4b5069";
    stopButtonElement.style.backgroundColor="#1f1d41";

    readyLightElement.style.backgroundColor ="#4b5069";
    readyButtonElement.style.backgroundColor="#1f1d41";

    goLightElement.style.backgroundColor ="#199473";
    goButtonElement.style.backgroundColor="#199473";

}

seasons switcher:
---------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
   <div>
        <img src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-four-seasons-xs-img.png" class="season-image d-inline d-md-none" id="seasonSmallImage" />
        <img src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-four-seasons-md-img.png" class="season-image d-none d-md-inline" id="seasonMediumImage" />
        <div class="d-flex flex-row justify-content-center mt-4">
            <button class="button spring-button" id="springBtn" onclick="changSeasonToSpring()">Spring</button>
            <button class="button summer-button" id="summerBtn" onclick="changSeasonToSummer()">Summer</button>
            <button class="button autumn-button" id="autumnBtn" onclick="changSeasonToAutumn()">Autumn</button>
            <button class="button winter-button" id="winterBtn" onclick="changSeasonToWinter()">Winter</button>
        </div>
    </div>
</body>

</html>


CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.season-image {
    width: 100%;
    height: 85vh;
}

.button {
    color: white;
    background-color: #cbd2d9;
    font-family: "Roboto";
    font-size: 14px;
    width: 80px;
    height: 32px;
    border-width: 0;
    border-radius: 8px;
    margin-left: 10px;
    margin-right: 10px;
}

.spring-button {
    background-color: #3a7333;
}

.summer-button {
    background-color: #e0bb00;
}

.autumn-button {
    background-color: #b04400;
}

.winter-button {
    background-color: #0f7cb6;
}

JS:

let seasonSmallImageElement = document.getElementById("seasonSmallImage");
let seasonMediumImageElement = document.getElementById("seasonMediumImage");

let springSmallImage = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-spring-xs-img.png";
let springMediumImage = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-spring-md-img.png";
let summerSmallImage = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-summer-xs-img.png";
let summerMediumImage = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-summer-md-img.png";
let autumnSmallImage = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-autumn-xs-img.png";
let autumnMediumImage = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-autumn-md-img.png";
let winterSmallImage = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-winter-xs-img.png";
let winterMediumImage = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/seasons-switcher-winter-md-img.png";

function changSeasonToSpring() {
    seasonSmallImageElement.src = springSmallImage;
    seasonMediumImageElement.src = springMediumImage;
}

function changSeasonToSummer() {
    seasonSmallImageElement.src = summerSmallImage;
    seasonMediumImageElement.src = summerMediumImage;
}

function changSeasonToAutumn() {
    seasonSmallImageElement.src = autumnSmallImage;
    seasonMediumImageElement.src = autumnMediumImage;
}

function changSeasonToWinter() {
    seasonSmallImageElement.src = winterSmallImage;
    seasonMediumImageElement.src = winterMediumImage;
}

Toggle Like and Unlike:
------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/d1c2ea8b80.js" crossorigin="anonymous"></script>
</head>

<body>
  <div>
        <img src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/white-puppy-img.png" class="puppy-image" id="puppyImage" />
        <div class="d-flex flex-row justify-content-center mt-4">
            <i class="fa fa-thumbs-up like-icon" aria-hidden="true" id="likeIcon"></i>
            <button id="likeButton" class="like-button ml-2" onclick="onClickLikeButton()">
                Like
            </button>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.puppy-image {
    width: 100%;
}

.like-icon {
    color: #cbd2d9;
    font-size: 40px;
}

.like-button {
    color: #9aa5b1;
    background-color: #cbd2d9;
    font-family: "Roboto";
    font-size: 14px;
    width: 100px;
    height: 40px;
    border-width: 0;
    border-radius: 8px;
}

JS:

let puppyImageElement = document.getElementById("puppyImage");
let likeIconElement = document.getElementById("likeIcon");
let likeButtonElement = document.getElementById("likeButton");
let isImageLiked = false;

function onClickLikeButton() {
    if (isImageLiked === false) {
        puppyImageElement.src = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/white-puppy-liked-img.png";
        likeButtonElement.style.backgroundColor = "#0967d2";
        likeIconElement.style.color = "#0967d2";
        likeButtonElement.style.color = "#ffffff";
        isImageLiked = true;

    } else {
        puppyImageElement.src = "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/white-puppy-img.png";
        likeButtonElement.style.backgroundColor = "#cbd2d9";
        likeIconElement.style.color = "#cbd2d9";
        likeButtonElement.style.color = "#9aa5b1";
        isImageLiked = false;
    }

}

coding pratice-3:
--------------------------------

Tip Calculate:
----------------------------

HTML:


<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/d1c2ea8b80.js" crossorigin="anonymous"></script>
</head>

<body>
    
    <div class="tip-calculator-container pb-5">
        <img class="tip-calculator-image" src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/tip-calculator-img.png" />
        <h1 class="tip-calculator-heading text-center mt-4 mb-4">Tip Calculator</h1>
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 mb-4">
                    <p class="input-label mb-2">BILL AMOUNT</p>
                    <input type="text" class="user-input" id="billAmount" />
                </div>
                <div class="col-12 col-md-6 mb-4">
                    <p class="input-label mb-2">PERCENTAGE TIP</p>
                    <input type="text" class="user-input" id="percentageTip" />
                </div>
                <div class="col-12 col-md-6 mb-4">
                    <p class="input-label mb-2">TIP AMOUNT</p>
                    <input type="text" class="user-input" id="tipAmount" />
                </div>
                <div class="col-12 col-md-6 mb-4">
                    <p class="input-label mb-2">TOTAL</p>
                    <input type="text" class="user-input" id="totalAmount" />
                </div>
                <div class="col-12 text-center mt-4">
                    <button class="btn btn-info calculate-tip-button" id="calculateButton" onclick="calculateTip()">CALCULATE</button>
                    <p id="errorMessage" class="error-message text-center"></p>
                </div>
            </div>
        </div>
    </div>
 </body>

</html>   

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.tip-calculator-container {
    background-color: #f9fbfe;
}

.tip-calculator-image {
    width: 100%;
}

.tip-calculator-heading {
    color: #264fa2;
    font-family: "Roboto";
    font-size: 48px;
    font-weight: 500;
}

.input-label {
    color: #7b8794;
    font-family: "Roboto";
    font-size: 12px;
    font-weight: bold;
}

.user-input {
    height: 40px;
    width: 100%;
    border-style: solid;
    border-width: 1px;
    border-color: #cbd2d9;
    border-radius: 4px;
    padding-left: 12px;
}

.calculate-tip-button {
    background-color: #264fa2;
    color: white;
    font-family: "Roboto";
    font-size: 18px;
    border-radius: 4px;
}

.error-message {
    color: #cf1124;
    font-family: "Roboto";
    font-size: 14px;
    font-weight: 500;
    margin-top: 10px;
}

JS:

let billAmountInput = document.getElementById("billAmount");
let percentageTipInput = document.getElementById("percentageTip");
let tipAmountInput = document.getElementById("tipAmount");
let totalInput = document.getElementById("totalAmount");
let errorMessageElement = document.getElementById("errorMessage");
let errorMessage = "please Enter a Valid Input.";

function calculateTip() {
    let billAmountInputValue = billAmountInput.value;
    let percentageTipInputValue = percentageTipInput.value;

    if (billAmountInputValue === "") {
        errorMessageElement.textContent = errorMessage;
    } else if (percentageTipInputValue === "") {
        errorMessageElement.textContent = errorMessage;
    } else {
        errorMessageElement.textContent = "";
        let billAmount = parseInt(billAmountInputValue);
        let percentageTip = parseInt(percentageTipInputValue);

        let calculatedTip = (percentageTip / 100) * billAmount;
        let calculatedTotal = billAmount + calculatedTip;
        tipAmountInput.value = calculatedTip;
        totalInput.value = calculatedTotal
    }
}

sizing an image:
-------------------------------

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="bg-container pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 d-flex flex-column justify-content-center text-center text-md-left">
                    <h1 class="sizing-an-image-heading">Sizing an Image</h1>
                    <p class="sizing-an-image-description">Increase the width of an image by clicking the plus button and decrease by clicking the Minus button. For every action, the image increases or decreases by 5px.</p>
                </div>
                <div class="col-12 col-md-6 text-center">
                    <p class="warning-message" id="warningMessage"></p>
                    <img src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/sizing-an-image-img.png" alt="image" id="image">
                    <p class="image-width">Width: <span id="imageWidth"></span></p>
                </div>
                <div class="col-12">
                    <div class="buttons-container d-flex flex-row shadow m-auto">
                        <button class="button" id="decrementButton" onclick="onDecrement()">-</button>
                        <hr class="hr-line" />
                        <span class="width-in-px">5px</span>
                        <hr class="hr-line" />
                        <button class="button" id="incrementButton" onclick="onIncrement()">+</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
  background-color: #f5f7fa;
}

.sizing-an-image-heading {
  color: #1f2933;
  font-family: "Roboto";
  font-size: 48px;
  font-weight: 500;
}

.sizing-an-image-description {
  color: #1f2933;
  font-family: "Roboto";
  font-size: 18px;
  font-weight: 500;
}

.warning-message {
  color: #cf1124;
  font-family: "Roboto";
  font-size: 24px;
  font-weight: 500;
}

.image-width {
  color: #323f4b;
  font-family: "Roboto";
  font-size: 16px;
  font-weight: 500;
  margin-top: 10px;
}

.buttons-container {
  background-color: white;
  width: 140px;
}

.button {
  color: #323f4b;
  background-color: white;
  font-family: "Roboto";
  font-size: 20px;
  font-weight: 700;
  width: 35%;
  height: 50px;
  border-width: 0;
}

.hr-line {
  background-color: black;
  width: 1px;
  height: 20px;
}

.width-in-px {
  color: #323f4b;
  font-family: "Roboto";
  font-size: 20px;
  font-weight: 700;
  margin: 10px;
}

JS:

let imageElement = document.getElementById("image");
let imageWidthElement = document.getElementById("imageWidth");
let warningMessageElement = document.getElementById("warningMessage");


let imageMinWidth = 100;
let imageMaxWidth = 300;
let originalImageWidth = 200;
let maxWidthWarningMessage = "Too big. Decrease the size of the Image.";
let minWidthWarningMessage = "Can't Visible. Increase the size if the Image.";

imageElement.style.width = originalImageWidth + "px";
imageWidthElement.textContent = originalImageWidth + "px";

function onIncrement() {
    if (originalImageWidth >= imageMaxWidth) {
        warningMessageElement.textContent = maxWidthWarningMessage;
    } else {
        originalImageWidth = originalImageWidth + 5;
        let updatedImageWidth = originalImageWidth + "px";

        warningMessageElement.textContent = "";
        imageElement.style.width = updatedImageWidth;
        imageWidthElement.textContent = updatedImageWidth;
    }
}

function onDecrement() {
    if (originalImageWidth <= imageMinWidth) {
        warningMessageElement.textContent = minWidthWarningMessage;
    } else {
        originalImageWidth = originalImageWidth - 5;
        let updatedImageWidth = originalImageWidth + "px";

        warningMessageElement.textContent = "";
        imageElement.style.width = updatedImageWidth;
        imageWidthElement.textContent = updatedImageWidth;
    }

}

More DOM Manipulations:
---------------------------------

4.1 Creating an HTML Element - createElement():

let h1Element = document.createElement("h1");
h1Element.textContent = "Web Technologies";

console.log(h1Element);  // <h1>Web Technologies</h1>

4.2 Appending to an HTML Element - appendChild():

Appending to Document Body Object:

document.body.appendChild(h1Element);

Output:

Web Technologies

Appending to Existing Container Element:

let containerElement = document.getElementById("myContainer");
containerElement.appendChild(h1Element);

Output:

Web Technologies

Try out creating and appending the HTML elements like a paragraph, image, etc. in the below Code Playground.

HTML:

<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <div id="myContainer"></div>
  </body>
</html>

JS:

let h1Element = document.createElement("h1");
h1Element.textContent = "Web Technologies";

let containerElement = document.getElementById("myContainer");
containerElement.appendChild(h1Element);

let btnElement = document.createElement("button");
btnElement.textContent = "Change Heading";
containerElement.appendChild(btnElement);

Functions:
-------------------

3.1 Function Declaration:

function showMessage() {
  console.log("Hello");
}

showMessage();

Output:

Hello

3.2 Function Expression:

There is another syntax for creating a function which is called Function Expression.

let showMessage = function() {
  console.log("Hello");
};

showMessage();

Output:

Hello

4.3 Adding Event Listeners Dynamically:

let btnElement = document.createElement("button");
btnElement.textContent = "Change Heading";
document.getElementById("myContainer").appendChild(btnElement);

btnElement.onclick = function(){
  console.log("click event triggered");
  h1Element.textContent = "4.0 technologies";
};


4.4 Providing Class Names Dynamically - classList.add():

JS:

btnElement.onclick = function(){
  h1Element.textContent = "4.0 Technologies";
  h1Element.classList.add("heading");

  console.log(h1Element);
};

CSS:

.heading {
  color: blue;
  font-family: "Caveat";
  font-size: 40px;
  text-decoration: underline;
}

4.5 Removing Class Names Dynamically - classList.remove():

let removeStylesBtnElement = document.createElement("button");
removeStylesBtnElement.textContent = "Remove Styles";

document.getElementById("myContainer").appendChild(removeStylesBtnElement);

removeStylesBtnElement.onclick = function(){
  h1Element.classList.remove("heading");
};

Example:

HTML:

<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <div id="myContainer"></div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.heading {
  color: blue;
  font-family: "Caveat";
  font-size: 40px;
  text-decoration: underline;
}

JS:

let h1Element = document.createElement("h1");
h1Element.textContent = "Web Technologies";

let containerElement = document.getElementById("myContainer");
containerElement.appendChild(h1Element);

let btnElement = document.createElement("button");
btnElement.textContent = "Change Heading and Add Styles";
containerElement.appendChild(btnElement);

btnElement.onclick = function(){
  h1Element.textContent = "4.0 Technologies";
  h1Element.classList.add("heading");
};

let removeStylesBtnElement = document.createElement("button");
removeStylesBtnElement.textContent = "Remove Styles";
containerElement.appendChild(removeStylesBtnElement);

removeStylesBtnElement.onclick = function(){
  h1Element.classList.remove("heading");
};

OBJECT:
------------

1. Creating an Object

We can add properties into {} as key: value pairs.

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
};

console.log(person);  // Object {firstName: "Rahul", lastName: "Attuluri", age: 28}

1.1 Identifiers:

A valid Identifier should follow the below rules:

It can contain alphanumeric characters, _ and $.
It cannot start with a number.

Valid Identifiers:

firstName;
$firstName;
_firstName;
firstName12;

Invalid Identifiers:

12firstName;
firstName 12;

To use an Invalid identifier as a key, we have to specify it in quotes.

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
  "1": "value1",
  "my choice": "value2",
};

console.log(person);  // Object {1: "value1", firstName: "Rahul", lastName: "Attuluri", age: 28, my choice: "value2"}

2. Accessing Object Properties:

2.1 Dot Notation:

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
  "1": "value1",
  "my choice": "value2",
};

console.log(person.firstName);  // Rahul

2.2 Bracket Notation:

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
  "1": "value1",
  "my choice": "value2",
};

console.log(person["firstName"]);  // Rahul

2.3 Accessing Non-existent Properties

Dot Notation:

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
  "1": "value1",
  "my choice": "value2",
};

console.log(person.gender);  // undefined

Bracket Notation:

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
  "1": "value1",
  "my choice": "value2",
};

console.log(person["gender"]);  // undefined

2.4 Variable as a Key

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
};

let a = "firstName";

console.log(person[a]);  // Rahul

console.log(person.a);  // undefined

2.5 Object Destructuring:

To unpack properties from Objects, we use Object Destructuring. The variable name should match with the key of an object.

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
};

let { gender, age } = person;

console.log(gender);  // undefined

console.log(age);  // 28

3. Modifying Objects

3.1 Modifying Object Property:

Dot Notation:

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
};

person.firstName = "Abhi";

console.log(person.firstName);  // Abhi

Bracket Notation:

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
};

person["firstName"] = "Abhi";

console.log(person["firstName"]);  // Abhi

3.2 Adding Object Property

Dot Notation:

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
};

person.gender = "Male";

console.log(person);  // Object {firstName: "Rahul", lastName: "Attuluri", age: 28, gender: "Male"}

Bracket Notation:

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
};

person["gender"] = "Male";

console.log(person);  // Object {firstName: "Rahul", lastName: "Attuluri", age: 28, gender: "Male"}

4. Property Value

The Value of Object Property can be

Function
Array
Object

Function as a Value:

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
  run: function () {
    console.log("Start Running.");
  },
};

person.run();  // Start Running.

Methods:

A JavaScript method is a property containing a function definition.

For example, in document.createElement();, the document is an Object, createElement is a key and createElement() is a Method.

4.2 Array as a Value

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
  habits: ["Playing Chess", "Singing"],
};

console.log(person.habits);  // ["Playing Chess", "Singing"]

console.log(person.habits[0]);  // Playing Chess

console.log(person["habits"][1]);  // Singing

4.3 Object as a Value

let person = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 28,
  habits: ["Playing Chess", "Singing", "Dancing"],
  car: {
    name: "Audi",
    model: "A6",
    color: "White",
  },
};

console.log(person.car.name);  // Audi

console.log(person.car["model"]);  // A6

coding pratice-4:
-----------------------

Addition Game:
------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="text-center">
        <img src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/sum-of-two-numbers-img.png" class="image" />
        <div class="bg-container pt-5 pb-5">
            <span id="firstNumber" class="number m-2"></span>
            <span class="operator m-1">+</span>
            <span id="secondNumber" class="number m-2"></span>
            <span class="operator m-1">=</span>
            <input id="userInput" class="user-input" type="text" />
            <div class="mt-4 mb-4">
                <button id="checkButton" class="btn btn-primary mr-3" onclick="checkButtonFunction()">
                    Check
                </button>
                <button id="restartButton" class="btn btn-primary" onclick="restartButtonFunction()">
                    Restart
                </button>
            </div>
            <p id = "gameResult" class="game-result"></p>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.image {
    width: 360px;
    height: 280px;
}

.bg-container {
    background-color: #f5f7fa;
}

.number {
    color: #323f4b;
    background-color: #cbd2d9;
    font-family: "Roboto";
    font-size: 30px;
    font-weight: bold;
    border-style: solid;
    border-width: 8px;
    border-color: #e4e7eb;
    border-radius: 12px;
    padding-left: 8px;
    padding-right: 8px;
}

.operator {
    color: #c4c4c4;
    font-family: "Roboto";
    font-size: 40px;
}

.user-input {
    text-align: center;
    color: #323f4b;
    background-color: #cbd2d9;
    font-family: "Roboto";
    font-size: 30px;
    font-weight: bold;
    width: 142px;
    height: 60px;
    border-style: solid;
    border-width: 8px;
    border-color: #e4e7eb;
    border-radius: 12px;
    margin: 20px;
}

.game-result {
    color: #ffffff;
    background-color: #f5f7fa;
    font-family: "Roboto";
    font-size: 24px;
    font-weight: 500;
}

JS:

let firstNumber = document.getElementById("firstNumber");
let secondNumber = document.getElementById("secondNumber");
let userInput = document.getElementById("userInput");
let resultOfGame = document.getElementById("gameResult");

function restartButtonFunction() {
    let firstRandomNumber = Math.random() * 100;
    firstRandomNumber = Math.ceil(firstRandomNumber);
    firstNumber.textContent = firstRandomNumber;

    let secondRandomNumber = Math.random() * 100;
    secondRandomNumber = Math.ceil(secondRandomNumber);
    secondNumber.textContent = secondRandomNumber;

    resultOfGame.textContent = "";
    userInput.value = "";
}

restartButtonFunction();

function checkButtonFunction() {
    let FirstRandomNumber = parseInt(firstNumber.textContent);
    let secondRandomNumber = parseInt(secondNumber.textContent);
    let input = parseInt(userInput.value);

    let sumOfNumbers = FirstRandomNumber + secondRandomNumber;

    if (sumOfNumbers === input) {
        resultOfGame.textContent = "Congratulations! You got it right.";
        resultOfGame.style.backgroundColor = "#028a0f";
    } else {
        resultOfGame.textContent = "Please Try Again!";
        resultOfGame.style.backgroundColor = "#1e217c";
    }
}

Random Color Genarator:
------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-md-6 d-flex flex-column justify-content-center">
                <div class="text-center p-4">
                    <h1 class="instruction">Click the below button to change color</h1>
                    <button id="button" class="button" onclick="onChangeBgColor()">Click Me</button>
                </div>
            </div>
            <div id="bgContainer" class="col-12 col-md-6 bg-container"></div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.instruction {
    font-family: "Open Sans";
}

.button {
    color: white;
    background-color: #0967d2;
    width: 150px;
    height: 40px;
    border-width: 0;
    border-radius: 25px;
    margin: 15px;
}

.bg-container {
    height: 100vh;
}

JS:

let bgContainerElement = document.getElementById("bgContainer");
let buttonElement = document.getElementById("button");

let bgColorsArray = ["#e75d7c", "#b16cef", "#53cca4", "#efc84d", "#628ef0", "#184b73", "#883e7f", "#ed048b"];

bgContainerElement.style.backgroundColor = bgColorsArray[0];

function onChangeBgColor() {
    let numberOfBgColors = bgColorsArray.length;
    let randomBgColorIndex = Math.ceil(Math.random() * numberOfBgColors);

    if (randomBgColorIndex === numberOfBgColors) {
        randomBgColorIndex = numberOfBgColors - 1;
    }
    let randomBgColor = bgColorsArray[randomBgColorIndex];
    bgContainerElement.style.backgroundColor = randomBgColor;
}

Button Maker:
----------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="button-maker-bg-container p-4">
        <h1 class="button-maker-heading text-center mb-4">Button Maker</h1>
        <div class="button-maker-container bg-light pt-4 pb-4">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-7">
                        <p class="input-label">BACKGROUND COLOR</p>
                        <input class="user-input" type="text" id="bgColorInput" />
                        <p class="input-label">FONT COLOR</p>
                        <input class="user-input" type="text" id="fontColorInput" />
                        <p class="input-label">FONT SIZE (in px)</p>
                        <input class="user-input" type="text" id="fontSizeInput" />
                        <p class="input-label">FONT WEIGHT</p>
                        <input class="user-input" type="text" id="fontWeightInput" />
                        <p class="input-label">PADDING (in px)</p>
                        <input class="user-input" type="text" id="paddingInput" />
                        <p class="input-label">BORDER RADIUS (in px)</p>
                        <input class="user-input" type="text" id="borderRadiusInput" />
                        <div class="text-right mt-4">
                            <button id="applyButton" class="btn btn-primary" onclick="apply()">
                                Apply
                            </button>
                        </div>
                    </div>
                    <div class="col-12 col-md-5 mt-4 text-center">
                        <button class="custom-button" id="customButton">Custom Button</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.button-maker-bg-container {
    background-image: linear-gradient(to right, #09203f, #537895);
}

.button-maker-heading {
    color: #ffffff;
    font-family: "Roboto";
    font-size: 32px;
    font-weight: 500;
}

.button-maker-container {
    border-radius: 10px;
}

.input-label {
    color: #7b8794;
    font-family: "Roboto";
    font-size: 12px;
    font-weight: bold;
    margin-top: 12px;
    margin-bottom: 6px;
}

.user-input {
    width: 100%;
    height: 40px;
    border-style: solid;
    border-width: 1px;
    border-color: #cbd2d9;
    border-radius: 4px;
    padding-left: 12px;
}

.custom-button {
    font-family: "Roboto";
}

JS:

let bgColorElement = document.getElementById("bgColorInput");
let fontColorElement = document.getElementById("fontColorInput");
let fontSizeElement = document.getElementById("fontSizeInput");
let fontWeightElement = document.getElementById("fontWeightInput");
let paddingElement = document.getElementById("paddingInput");
let borderRadiusElement = document.getElementById("borderRadiusInput");
let customButtonElement = document.getElementById("customButton");





function apply() {

    let bgColorValue = bgColorElement.value;
    let fontColorValue = fontColorElement.value;
    let fontSizeValue = fontSizeElement.value;
    let fontWeightValue = fontWeightElement.value;
    let paddingValue = paddingElement.value;
    let borderRadiusValue = borderRadiusElement.value;

    customButtonElement.style.backgroundColor = bgColorValue;
    customButtonElement.style.color = fontColorValue;
    customButtonElement.style.fontSize = fontSizeValue;
    customButtonElement.style.fontWeight = fontWeightValue;
    customButtonElement.style.padding = paddingValue;
    customButtonElement.style.borderRadius = borderRadiusValue;

}

Tabs:
-----------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-4">
                    <h1 class="heading">Varanasi</h1>
                    <p class="description">
                        The city is very commonly referred to as City of Temples, Holy
                        City of India, Religious Capital of India, and City of Learning.
                    </p>
                </div>
                <div class="col-12 col-lg-5 mb-4">
                    <img class="w-100" src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/tabs-varanasi-img.png" />
                </div>
                <div class="col-12 col-lg-7">
                    <div class="d-flex flex-row justify-content-between">
                        <button class="p-3 button selected-button" id = "aboutButton" onclick="onClickAboutTab()">
                            About
                        </button>
                        <button class="p-3 button" id = "timeToVisitButton" onclick="onClickTimeToVisitTab()">
                            Time to visit
                        </button>
                        <button class="p-3 button" id ="attractionsButton"  onclick="onClickAttractionsTab()">
                            Attractions
                        </button>
                    </div>
                    <div class="tabs-container">
                        <div class="p-3"  id = "aboutTab">
                            <p class="tab-content">
                                Varanasi is one of the oldest living cities in the world. Its
                                Prominence in Hindu mythology is virtually unrevealed. Mark
                                Twain, the English author and literature, who was enthralled
                                by the legend and sanctity of Benaras, once wrote, ''Benaras
                                is older than history, older than tradition, older even than
                                legend and looks twice as old as all of them put together".
                            </p>
                        </div>
                        <div class="p-3" id = "timeToVisitTab">
                            <p class="tab-content" >
                                October to March is the best time to visit Varanasi because
                                most of the fairs here are held during this time of the year.
                                Festivities begin with Diwali and continue to Dev Diwali
                                celebrated on the 15th day from Diwali. In between, there is
                                also Annakut. During this time, the ghats are lit with lights
                                and diyas. Earthen lamps adorn the staircase of the ghats and
                                are also afloat in the river. Firecrackers burn through the
                                night, and it's a sight no one should miss.
                            </p>
                        </div>
                        <div class="p-3" id="attractionsTab">
                            <p class="tab-content" >
                                When visiting Varanasi, one comes across plenty of ghats, but
                                among them, Dashashwamedh Ghat is said to be one of the oldest
                                and most important. This ghat, leading to the Ganges, is
                                located close to the famous old Vishwanath temple in Kashi
                                (today’s Banaras). Another famous attraction is River Ganges
                                which is the holiest river by the Hindus and many more.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background: #f1f5f8;
}

.heading {
    color: #102a42;
    font-family: "Roboto";
    font-weight: bold;
}

.description {
    font-family: "Roboto";
}

.tabs-container {
    background-color: white;
    border-radius: 8px;
}

.button {
    background-color: #dae2ec;
    font-family: "Roboto";
    font-size: 18px;
    width: 33%;
    border-width: 0;
    border-radius: 8px;
}

.selected-button {
    background-color: white;
}

.tab-content {
    color: #323f4b;
    font-family: "Roboto";
    font-size: 15px;
}

JS:

let aboutButtonEl = document.getElementById("aboutButton");
let timeToVisitButtonEl = document.getElementById("timeToVisitButton");
let attractionsButtonEl = document.getElementById("attractionsButton");


let aboutTabEl = document.getElementById("aboutTab");
let timeToVisitTabEl = document.getElementById("timeToVisitTab");
let attractionsTabEl = document.getElementById("attractionsTab");


timeToVisitTabEl.classList.add("d-none");
attractionsTabEl.classList.add("d-none");


function onClickAboutTab() {
  aboutTabEl.classList.remove("d-none");
  timeToVisitTabEl.classList.add("d-none");
  attractionsTabEl.classList.add("d-none");


  aboutButtonEl.classList.add("selected-button");
  timeToVisitButtonEl.classList.remove("selected-button");
  attractionsButtonEl.classList.remove("selected-button");
}


function onClickTimeToVisitTab() {
  aboutTabEl.classList.add("d-none");
  timeToVisitTabEl.classList.remove("d-none");
  attractionsTabEl.classList.add("d-none");


  aboutButtonEl.classList.remove("selected-button");
  timeToVisitButtonEl.classList.add("selected-button");
  attractionsButtonEl.classList.remove("selected-button");
}


function onClickAttractionsTab() {
  aboutTabEl.classList.add("d-none");
  timeToVisitTabEl.classList.add("d-none");
  attractionsTabEl.classList.remove("d-none");


  aboutButtonEl.classList.remove("selected-button");
  timeToVisitButtonEl.classList.remove("selected-button");
  attractionsButtonEl.classList.add("selected-button");
}

Return a value in the function:
----------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // firstInteger
  let firstInteger = parseInt(readLine());
  // secondInteger
  let secondInteger = parseInt(readLine());

  // function getSumOfTwoIntegers
  function getSumOfTwoIntegers(integer1, integer2) {
    /*
     * Write your code here and return the output.
     */
     let sum = integer1+integer2
     return sum;
  }


  let sumOfTwoIntegers = getSumOfTwoIntegers(firstInteger, secondInteger);
  console.log(sumOfTwoIntegers);
}

Input:

2
3

Output:

5

create a function:
-----------------------------

function getNationalBird(){
    let bird ='Peacock'
    return bird;
}

let nationalBird = getNationalBird();
console.log(nationalBird);

passing an argument to the function:
-----------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // personName
  let personName = readLine();

  // function greetWithName
  function greetWithName(personName) {
    let greetings  = "Hi " + personName;
    return greetings;
  }

  /*
   * Write your code here and log the output.
   */
   let wishes = greetWithName(personName)
   console.log(wishes)
}


Input:

Bharath

Output:

Hi Bharath

creating a function with parameters:
------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // firstInteger
  let firstInteger = parseInt(readLine());
  // secondInteger
  let secondInteger = parseInt(readLine());

  function AverageOfTwoIntegers(integer1, integer2) {
    /*
     * Write your code here and return the output.
     */
     let Average = (integer1+integer2)/2
     return Average;
  }


  let r = AverageOfTwoIntegers(firstInteger, secondInteger);
  console.log(r);
}

create a function expression:
-------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // minutes
  let minutes = parseInt(readLine());

  // Write your code here and return the output
  let convertMinutesToSeconds = function(minutes){
      let seconds = minutes*60;
      return seconds;
  }

  let result = convertMinutesToSeconds(minutes);
  console.log(result);
}

Input:

1

Output:

60

JS coding pratice-4:
--------------------------------------

Make a person object:
--------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // id
  let id = parseInt(readLine());
  // name
  let name = readLine();
  // email
  let email = readLine();

  /*
   * Write your code here and return the output.
   */
   function makePersonObject(pid, pname, pemail){
       let person = {
           id:pid,
           name:pname,
           email:pemail
       };
       return person;
       }
       
 

  let personObject = makePersonObject(id, name, email);
  console.log(personObject);
}


Input:

1
Shiva
shiva@gmail.com

Output:

{ id: 1, name: 'Shiva', email: 'shiva@gmail.com' }

calculate the total score of a crickter:
--------------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // arrayOfScores
  let arrayOfScores = JSON.parse(readLine().replace(/'/g, '"'));

  /*
   * Write your code here and return the output.
   */
   function calculateTotalScore(arrayOfScores){
       let [firstScore,secondScore,thirdScore] = arrayOfScores;
       let totalScore = firstScore+secondScore+thirdScore;
       return totalScore;
   }

  let totalScore = calculateTotalScore(arrayOfScores);
  console.log(totalScore);
}

Input:

[25, 55, 30]

Output:

110

Make an array:
---------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // num1
  let num1 = parseInt(readLine());
  // num2
  let num2 = parseInt(readLine());
  // num3
  let num3 = parseInt(readLine());

  function makeAnArray(num1, num2, num3) {
    let myArray = [num1,num2,num3];
    return myArray;
  }

  let createdArray = makeAnArray(num1, num2, num3);
  console.log(createdArray);
}

Input:

1
2
3

Output:

[1,2,3]

Eligiblity:
------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // person
  let person = JSON.parse(readLine().replace(/'/g, '"'));

  function isEligibleForNextLevel(person) {
    /** Write your code here and return the output */
    let scoreOfPerson = person.score;
    let isEligible = scoreOfPerson > 5;
    return isEligible;
  }

  let isPersonEligible = isEligibleForNextLevel(person);
  console.log(isPersonEligible);
}

Input:

{'name':'preethi', 'score': 10}

Output:

true


Game Mode:
--------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // arrayOfFriends
  let arrayOfFriends = JSON.parse(readLine().replace(/'/g, '"'));

  /*
   * Write your code here and return the output.
   */
   let noOfFriends = arrayOfFriends.length;
   function getPreferredGameMode(noOfFriends){
       if(noOfFriends === 0){
           return 'Solo';
       }
       else if(noOfFriends === 1){
           return 'Dual';
       }else{
           return 'Squad';
       }
       
   }

  let gameMode = getPreferredGameMode(noOfFriends)
  console.log(gameMode);
}

Input:

['Anand']

Output:

Dual

1. HTML Input Element:
------------------------------------

1.1 Checkbox:

The HTML input element can be used to create a Checkbox. To define a Checkbox, 
you need to specify the HTML type attribute with the value checkbox for an HTML input element.

1.2 The HTML Label Element:

The HTML label element defines a Label.

<label for="myCheckbox">Graduated</label>

1.2.1 The HTML for Attribute:

The HTML for attribute associates the HTML label element with an HTML input element.

<input type="checkbox" id="myCheckbox" />
<label for="myCheckbox">Graduated</label>

2. DOM Manipulations:
---------------------------------------

2.1 The htmlFor Property:

We can use htmlFor property to add HTML for attribute to the HTML label element.

let labelElement = document.createElement("label");
labelElement.htmlFor = "myCheckbox";

2.2 The setAttribute() Method:

We can use setAttribute() method to set any HTML attribute name and its corresponding value. If the attribute already exists, the value is updated. Otherwise, a new attribute is added with the specified name and value.

Syntax: Element.setAttribute(name, value);


let labelElement = document.createElement("label");
labelElement.setAttribute("for", "myCheckbox");

3. Loops:
--------------------------------
Loops allow us to execute a block of code several times.

for...of Loop
for...in Loop
for Loop
while Loop and many more.

3.1 The for...of Loop

let myArray = [1, 2, 3, 4];

for (let eachItem of myArray) {
   console.log(eachItem);
}

The HTML Code for creating a Todo Item:

<li class="todo-item-container d-flex flex-row">
  <input type="checkbox" id="checkboxInput" class="checkbox-input" />
  <div class="d-flex flex-row label-container">
    <label for="checkboxInput" class="checkbox-label">
      Learn HTML
    </label>
    <div class="delete-icon-container">
      <i class="far fa-trash-alt delete-icon"></i>
    </div>
  </div>
</li>

4. CSS Box Properties:
--------------------------------

4.1 Border
The CSS border property is a shorthand property for:

border-width
border-style (required)
border-color
For example,

.button {
  border-style: dashed;
  border-width: 2px;
  border-color: #e4e7eb;
}

Syntax: border: border-width border-style border-color

.button {
  border: 2px dashed #e4e7eb;
}

Try out creating the multiple Todo Items dynamically in the below Code Playground:
---------------------------------------------------------------------------------------------------------

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/5f59ca6ad3.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="todos-bg-container">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <h1 class="todos-heading">Todos</h1>
            <h1 class="create-task-heading">
              Create <span class="create-task-heading-subpart">Task</span>
            </h1>
            <input type="text" id="todoUserInput" class="todo-user-input" />
            <button class="add-todo-button">Add</button>
            <h1 class="todo-items-heading">
              My <span class="todo-items-heading-subpart">Tasks</span>
            </h1>
            <ul class="todo-items-container" id="todoItemsContainer"></ul>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.todos-bg-container {
  background-color: #f9fbfe;
  height: 100vh;
}

.todos-heading {
  text-align: center;
  font-family: "Roboto";
  font-size: 46px;
  font-weight: 500;
  margin-top: 20px;
  margin-bottom: 20px;
}

.create-task-heading {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 700;
}

.create-task-heading-subpart {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 500;
}

.todo-items-heading {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 700;
}

.todo-items-heading-subpart {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 500;
}

.todo-items-container {
  margin: 0px;
  padding: 0px;
}

.todo-item-container {
  margin-top: 15px;
}

.todo-user-input {
  background-color: white;
  width: 100%;
  border-style: solid;
  border-width: 1px;
  border-color: #e4e7eb;
  border-radius: 10px;
  margin-top: 10px;
  padding: 15px;
}

.add-todo-button {
  color: white;
  background-color: #4c63b6;
  font-family: "Roboto";
  font-size: 18px;
  border-width: 0px;
  border-radius: 4px;
  margin-top: 20px;
  margin-bottom: 50px;
  padding-top: 5px;
  padding-bottom: 5px;
  padding-right: 20px;
  padding-left: 20px;
}

.label-container {
  background-color: #e6f6ff;
  width: 100%;
  border-style: solid;
  border-width: 5px;
  border-color: #096f92;
  border-right: none;
  border-top: none;
  border-bottom: none;
  border-radius: 4px;
}

.checkbox-input {
  width: 20px;
  height: 20px;
  margin-top: 12px;
  margin-right: 12px;
}

.checkbox-label {
  font-family: "Roboto";
  font-size: 16px;
  font-weight: 400;
  width: 82%;
  margin: 0px;
  padding-top: 10px;
  padding-bottom: 10px;
  padding-left: 20px;
  padding-right: 20px;
  border-radius: 5px;
}

.delete-icon-container {
  text-align: right;
  width: 18%;
}

.delete-icon {
  padding: 15px;
}

JS:

let todoItemsContainer = document.getElementById("todoItemsContainer");
let todoList = [
  {
    text: "Learn HTML"
  },
  {
    text: "Learn CSS"
  },
  {
    text: "Learn JavaScript"
  }
];

function createAndAppendTodo(todo) {
  let todoElement = document.createElement("li");
  todoElement.classList.add("todo-item-container", "d-flex", "flex-row");
  todoItemsContainer.appendChild(todoElement);

  let inputElement = document.createElement("input");
  inputElement.type = "checkbox";
  inputElement.id = "checkboxInput";
  inputElement.classList.add("checkbox-input");
  todoElement.appendChild(inputElement);

  let labelContainer = document.createElement("div");
  labelContainer.classList.add("label-container", "d-flex", "flex-row");
  todoElement.appendChild(labelContainer);

  let labelElement = document.createElement("label");
  labelElement.setAttribute("for", "checkboxInput");
  labelElement.classList.add("checkbox-label");
  labelElement.textContent = todo.text;
  labelContainer.appendChild(labelElement);

  let deleteIconContainer = document.createElement("div");
  deleteIconContainer.classList.add("delete-icon-container");
  labelContainer.appendChild(deleteIconContainer);

  let deleteIcon = document.createElement("i");
  deleteIcon.classList.add("far", "fa-trash-alt", "delete-icon");
  deleteIconContainer.appendChild(deleteIcon);
}

for (let todo of todoList) {
  createAndAppendTodo(todo);
}

1. Most Commonly Made Mistakes:
----------------------------------------------

1.1 Most of the JS properties and methods should be in the Camel case.

Most of the JS properties and methods are in the Camel case (the starting letter of each word should be in uppercase except for the first word).

Code						Mistake	Correct 					Syntax
document.CreateElement()	C in Uppercase				document.createElement()
document.getElementbyId()	b in Lowercase				document.getElementById()
element.textcontent			c in Lowercase				element.textContent
element.classlist.add()		l in Lowercase				element.classList.add()

Sum of the values of an array:
-------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // myArray
  let myArray = JSON.parse(readLine().replace(/'/g, '"'));

  /*
   *Write your code here and log the output.
   */
   let sumOfvalueinArray = 0;
   
   for(let value of myArray){
       sumOfvalueinArray = sumOfvalueinArray +value;
   }
   console.log(sumOfvalueinArray)
}

Input:

[12, 1, 2, 4, 1]

Output:

20

Eligiblity:
------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // arrayOfPersons
  let arrayOfPersons = JSON.parse(readLine().replace(/'/g, '"'));

  /*
   *Write your code here and log the output.
   */
   for(let person of arrayOfPersons){
       let each = person.age;
       if(each >= 18){
           console.log(person.name)
       }
   }
}

Input:

[{'name': 'Rahul', 'age': 19 },{'name': 'Vinod', 'age': 10 }, {'name':'Pavan', 'age': 11 },{'name': 'Geetha', 'age': 17 }]

Output:

Rahul

Indian car brand names:
---------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  // arrayOfCarBrands
  let arrayOfCarBrands = JSON.parse(readLine().replace(/'/g, '"'));

  /*
   *Write your code here and log the output.
   */
   let arrayOfIndianCarBrandNames = [];     //taking an empty array

 for (let carBrand of arrayOfCarBrands) {  //using loops to iterate over the objects of array
  let eachCarBrandCountry = carBrand.country;  //accessing the key 'country' of each object

  //checking if each brand country is 'India'. 
  if (eachCarBrandCountry === "India") { 
   //if the brand country is 'India' pushing the name of the car brand name into empty array that was created
   let nameOfCarBrand = carBrand.name;
   arrayOfIndianCarBrandNames.push(nameOfCarBrand);  
  }
 }
 //logging the final array in the console
 console.log(arrayOfIndianCarBrandNames);

}

Input:

[{'name': 'Chevrolet', 'country': 'America' },{'name': 'Maruti Suzuki', 'country': 'India' },{'name': 'Audi', 'country': 'Germany' }, {'name': 'Tata', 'country': 'India' },{'name': 'Honda', 'country': 'Japan' }]

Output:

[ 'Maruti Suzuki', 'Tata' ]

1. HTML Input Element:

1.1 Placeholder:

Placeholder is the text that appears in the HTML input element when no value is set. We can specify it using the HTML attribute  placeholder.

<input type="text" placeholder="Enter your name" />

2. JavaScript Built-in Functions:
--------------------------------------

2.1 alert():

The alert() function displays an alert box with a specified message and an OK button.

alert("Enter Valid Text");

3. DOM Properties:
-------------------------------

3.1 Checked

The checked property sets or returns the checked status of an HTML checkbox input element as a boolean value.

let checkboxElement = document.getElementById(checkboxId);
checkboxElement.checked = true;

4. DOM Manipulations:
----------------------------------

4.1 The removeChild() Method

The removeChild() method removes an HTML child element of the specified HTML parent element from the DOM and returns the removed HTML child element.

function onDeleteTodo(todoId) {
  let todoElement = document.getElementById(todoId);

  todoItemsContainer.removeChild(todoElement);
}

4.2 The classList.toggle() Method

The classList.toggle() method is used to toggle between adding and removing a class name from an HTML element.

function onTodoStatusChange(checkboxId, labelId) {
  let checkboxElement = document.getElementById(checkboxId);
  let labelElement = document.getElementById(labelId);

  labelElement.classList.toggle('checked');
}

We can replace classList.add() and classList.remove() methods with classList.toggle() method.

Try out adding the placeholder to the HTML input elements, deleting the HTML child elements, 
adding alerts and toggling the class names in the below Code Playground.

Todo-2:
------------------

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/5f59ca6ad3.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="todos-bg-container">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <h1 class="todos-heading">Todos</h1>
            <h1 class="create-task-heading">
              Create <span class="create-task-heading-subpart">Task</span>
            </h1>
            <input type="text" id="todoUserInput" class="todo-user-input" placeholder="What needs to be done?"/>
            <button class="add-todo-button" id="addTodoButton">Add</button>
            <h1 class="todo-items-heading">
              My <span class="todo-items-heading-subpart">Tasks</span>
            </h1>
            <ul class="todo-items-container" id="todoItemsContainer"></ul>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.todos-bg-container {
  background-color: #f9fbfe;
  height: 100vh;
}

.todos-heading {
  text-align: center;
  font-family: "Roboto";
  font-size: 46px;
  font-weight: 500;
  margin-top: 20px;
  margin-bottom: 20px;
}

.create-task-heading {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 700;
}

.create-task-heading-subpart {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 500;
}

.todo-items-heading {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 700;
}

.todo-items-heading-subpart {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 500;
}

.todo-items-container {
  margin: 0px;
  padding: 0px;
}

.todo-item-container {
  margin-top: 15px;
}

.todo-user-input {
  background-color: white;
  width: 100%;
  border-style: solid;
  border-width: 1px;
  border-color: #e4e7eb;
  border-radius: 10px;
  margin-top: 10px;
  padding: 15px;
}

.add-todo-button {
  color: white;
  background-color: #4c63b6;
  font-family: "Roboto";
  font-size: 18px;
  border-width: 0px;
  border-radius: 4px;
  margin-top: 20px;
  margin-bottom: 50px;
  padding-top: 5px;
  padding-bottom: 5px;
  padding-right: 20px;
  padding-left: 20px;
}

.label-container {
  background-color: #e6f6ff;
  width: 100%;
  border-style: solid;
  border-width: 5px;
  border-color: #096f92;
  border-right: none;
  border-top: none;
  border-bottom: none;
  border-radius: 4px;
}

.checkbox-input {
  width: 20px;
  height: 20px;
  margin-top: 12px;
  margin-right: 12px;
}

.checkbox-label {
  font-family: "Roboto";
  font-size: 16px;
  font-weight: 400;
  width: 82%;
  margin: 0px;
  padding-top: 10px;
  padding-bottom: 10px;
  padding-left: 20px;
  padding-right: 20px;
  border-radius: 5px;
}

.delete-icon-container {
  text-align: right;
  width: 18%;
}

.delete-icon {
  padding: 15px;
}

.checked {
  text-decoration: line-through;
}

JS:

let todoItemsContainer = document.getElementById("todoItemsContainer");
let addTodoButton = document.getElementById("addTodoButton");

let todoList = [
  {
    text: "Learn HTML",
    uniqueNo: 1
  },
  {
    text: "Learn CSS",
    uniqueNo: 2
  },
  {
    text: "Learn JavaScript",
    uniqueNo: 3
  }
];

let todosCount = todoList.length;

function onTodoStatusChange(checkboxId, labelId) {
  let checkboxElement = document.getElementById(checkboxId);
  let labelElement = document.getElementById(labelId);

  labelElement.classList.toggle('checked');
}

function onDeleteTodo(todoId) {
  let todoElement = document.getElementById(todoId);

  todoItemsContainer.removeChild(todoElement);
}

function createAndAppendTodo(todo) {
  let todoId = 'todo' + todo.uniqueNo;
  let checkboxId = 'checkbox' + todo.uniqueNo;
  let labelId = 'label' + todo.uniqueNo;

  let todoElement = document.createElement("li");
  todoElement.classList.add("todo-item-container", "d-flex", "flex-row");
  todoElement.id = todoId;
  todoItemsContainer.appendChild(todoElement);

  let inputElement = document.createElement("input");
  inputElement.type = "checkbox";
  inputElement.id = checkboxId;

  inputElement.onclick = function() {
    onTodoStatusChange(checkboxId, labelId);
  }

  inputElement.classList.add("checkbox-input");
  todoElement.appendChild(inputElement);

  let labelContainer = document.createElement("div");
  labelContainer.classList.add("label-container", "d-flex", "flex-row");
  todoElement.appendChild(labelContainer);

  let labelElement = document.createElement("label");
  labelElement.setAttribute("for", checkboxId);
  labelElement.id = labelId;
  labelElement.classList.add("checkbox-label");
  labelElement.textContent = todo.text;
  labelContainer.appendChild(labelElement);

  let deleteIconContainer = document.createElement("div");
  deleteIconContainer.classList.add("delete-icon-container");
  labelContainer.appendChild(deleteIconContainer);

  let deleteIcon = document.createElement("i");
  deleteIcon.classList.add("far", "fa-trash-alt", "delete-icon");

  deleteIcon.onclick = function () {
    onDeleteTodo(todoId);
  };

  deleteIconContainer.appendChild(deleteIcon);
}

for (let todo of todoList) {
  createAndAppendTodo(todo);
}

function onAddTodo() {
  let userInputElement = document.getElementById("todoUserInput");
  let userInputValue = userInputElement.value;

  if(userInputValue === ""){
    alert("Enter Valid Text");
    return;
  }

  todosCount = todosCount + 1;

  let newTodo = {
    text: userInputValue,
    uniqueNo: todosCount
  };

  createAndAppendTodo(newTodo);
  userInputElement.value = "";
}

addTodoButton.onclick = function(){
  onAddTodo();
}

user profile:
-----------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="profile-container" id="profileContainer">
        <div id="imgContainer"></div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.profile-container {
    color: white;
    background-color: #b990ff;
    height: 100vh;
}

JS:

let profileDetails = {
    imgSrc: "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/user-profile-img.png",
    name: "RAHUL ATTULURI",
    age: 25
};

let profileContainerE1 = document.getElementById('profileContainer');
profileContainerE1.classList.add('text-center', 'd-flex', 'flex-column', 'justify-content-ceneter');

let imgContainerE1 = document.getElementById('imgContainer')

let imgE1 = document.createElement('img');
imgE1.setAttribute('src', profileDetails.imgSrc)
imgE1.classList.add('profile-img')
imgContainerE1.appendChild(imgE1)

let nameE1 = document.createElement('h1');
nameE1.classList.add('profile-name');
nameE1.textContent = profileDetails.name;
profileContainerE1.appendChild(nameE1)

let ageE1 = document.createElement('p');
ageE1.classList.add('age');
ageE1.textContent = 'Age: ' + profileDetails.age;
profileContainerE1.appendChild(ageE1)

Recipe Page:
-----------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="pt-5 pb-5">
        <div class="container">
            <div class="row">
                <h1 class="col-12 recipe-title" id='recipeTitle'></h1>
                <div class="col-12 col-md-6 d-flex flex-column justify-content-center" id='imgContainer'>
                    <img id='img' />
                </div>
                <div class="col-12 col-md-5 mt-3">
                    <div class="ingredients-container">
                        <h1 class="ingredients-title">Ingredients</h1>
                        <ul id='ingredientsListContainer'></ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.recipe-title {
    text-align: center;
    color: #de3a11;
    font-family: "Lobster";
    font-size: 60px;
}

.ingredients-container {
    background-image: linear-gradient(#09203f, #537895);
    border-radius: 16px;
    padding: 10px;
}

.ingredients-title {
    text-align: center;
    color: #ffffff;
    font-family: "Roboto";
    font-size: 32px;
    font-weight: 500;
}

.ingredient {
    color: #ffffff;
    font-family: 'Roboto';
    font-size: 24px;
}

JS:

let recipeObj = {
    title: "Tomato Pasta",
    imgSrc: "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/recipe-img.png",
    ingredients: ["Pasta", "Oil", "Onions", "Salt", "Tomato Pasta Sauce", "Cheese"]
};

let ingredientList = recipeObj.ingredients;

let recipeTitleE1 = document.getElementById('recipeTitle');
let imgContainerE1 = document.getElementById('imgContainer');
let imgE1 = document.getElementById('img');
let ingredientListContainerE1 = document.getElementById('ingredientsListContainer');

recipeTitleE1.textContent = recipeObj.title;

imgE1.setAttribute('src', recipeObj.imgSrc);
imgE1.classList.add('w-100');
imgContainerE1.appendChild(imgE1);

for (let ingredient of ingredientList) {
    let ingredientE1 = document.createElement('li');
    ingredientE1.textContent = ingredient;
    ingredientE1.classList.add('ingredient');
    ingredientListContainerE1.appendChild(ingredientE1);
}

coding pratice-7:
--------------------------------

Grocery List:
----------------------------

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div id="groceryListContainer"></div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.grocery-list-container{
    background-color: #03254c;
    height: 100vh;
    padding: 30px;
}

.grocery-list-heading{
    text-align: center;
    color: #ffffff;
    font-family: 'Roboto';
    font-size: 36px;
    font-weight: 500;
    margin-bottom: 20px;
}
.list-items-container{
    background-color: #f5f9fd;
    border-radius: 6px;
    padding: 30px;
}

JS:

let groceryList = ["Apples", "Boost Drink", "Butterscotch Ice Cream", "Tomato Ketchup", "Dairy Milk Chocolates", "Pasta"];

let groceryListContainerEl = document.getElementById("groceryListContainer");
groceryListContainerEl.classList.add("grocery-list-container");

let maniHeadingEl = document.createElement("h1");
maniHeadingEl.classList.add("grocery-list-heading");
maniHeadingEl.textContent = "Grocery List";
groceryListContainerEl.appendChild(maniHeadingEl);

let unorderListEl = document.createElement("ul");
unorderListEl.classList.add("list-items-container");
groceryListContainerEl.appendChild(unorderListEl);

for (let GroceryItem of groceryList) {
    let listItemsEl = document.createElement("li");
    listItemsEl.classList.add("list");
    listItemsEl.textContent = GroceryItem;
    unorderListEl.appendChild(listItemsEl);
}

checkbox with label:
---------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div id="checkboxWithLabelContainer"></div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg {
    text-align: center;
    padding-top: 25px;
}

JS:

let checkboxWithLabelContainerEl = document.getElementById("checkboxWithLabelContainer");
checkboxWithLabelContainerEl.classList.add("bg");
let inputEl = document.createElement("input");
inputEl.type = "checkbox";
inputEl.id = "checkbox";

checkboxWithLabelContainerEl.appendChild(inputEl);

let lableEl = document.createElement("label");
lableEl.setAttribute("for", "checkbox");
lableEl.classList.add("me");
lableEl.textContent = "Click Me!";
lableEl.id = "checkboxLabel";
checkboxWithLabelContainerEl.appendChild(lableEl);

Add to Cart:
--------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container pt-4">
        <div class="row">
        <h1 class="col-12 heading">Add to Cart</h1>
        <div class='col-12 d-flex flex-row justify-content-center mt-4 mb-4'>
            <input type='text' class='w-50' id='cartItemTextInput' />
            <button class="btn btn-primary ml-3" id='addBtn' onclick="onAddCartItem()">Add</button>
        </div>
    
    <h1 class='col-12 heading cart-items-heading'>My Cart items</h1>
    <ul class="col-12 d-flex flex-column mt-4 cart-items-container" id='cartItemsContainer'></ul>
    </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.heading {
    font-family: "Roboto";
    text-align: center;
}

.cart-items-heading {
    font-size: 20px;
}

.cart-items-container {
    text-align: center;
    list-style-type: none;
}

JS:

let cartItemTextInputEl = document.getElementById("cartItemTextInput");
let cartItemsContainerEl = document.getElementById("cartItemsContainer");

function onAddCartItem() {
    let cartItemText = cartItemTextInputEl.value;

    let cartItemEl = document.createElement("li");
    cartItemEl.textContent = cartItemText;

    cartItemTextInputEl.value = "";
    cartItemsContainerEl.appendChild(cartItemEl);
}

coding pratice-8:
--------------------------------

Toggle the strike through:
-----------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="p-5" id="checkBoxWithLabelContainer"></div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.checkbox-label{
    font-family: 'Roboto';
    margin-left: 5px;
}

.strike-through{
    text-decoration: line-through;
}

JS:

let checkBoxWithLabelContainerEl = document.getElementById("checkBoxWithLabelContainer");

let inputEl = document.createElement("input");
inputEl.id = "checkbox";
inputEl.type = "checkbox";
checkBoxWithLabelContainerEl.appendChild(inputEl);

function onCheckboxStatusChange() {
    lableEl.classList.toggle("strike-through");
}

inputEl.onclick = function() {
    onCheckboxStatusChange();
};

let lableEl = document.createElement("label");
lableEl.setAttribute("for", "checkbox");
lableEl.textContent = "I am a label";
lableEl.id = "checkboxLabel";
lableEl.classList.add("am");
checkBoxWithLabelContainerEl.appendChild(lableEl);

Mark Your Skills:
---------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="p-5" id="skillsContainer">
        <h1 class="heading">Mark your Skills</h1>
        <ul class="skill-list-container" id="skillListContainer"></ul>
    </div>

</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.heading {
    font-family: 'Roboto';
    font-size: 24px;
}

.selected {
    color: green;
}

.skill-list-container {
    margin: 0;
    padding: 0;
    list-style-type: none;
}

.checkbox-label {
    font-family: 'Roboto';
    font-size: 16px;
    margin-left: 10px;
}

JS:

let skillsList = [{
        skillName: "HTML",
        uniqueNo: 1,
    },
    {
        skillName: "CSS",
        uniqueNo: 2,
    },
    {
        skillName: "JavaScript",
        uniqueNo: 3,
    }
];

let skillListContainerEl = document.getElementById("skillListContainer");

function onMarkSkill(labelId) {
    let labelEl = document.getElementById(labelId);
    labelEl.classList.toggle("selected");
}

function createAndAppendSkill(skill) {
    let checkboxId = "checkbox" + skill.uniqueNo;
    let labelId = "label" + skill.uniqueNo;

    let skillEl = document.createElement("li");
    skillEl.classList.add("p-1");
    skillListContainerEl.appendChild(skillEl);

    let checkboxEl = document.createElement("input");
    checkboxEl.type = "checkbox";
    checkboxEl.id = checkboxId;
    
    checkboxEl.onclick = function() {
        onMarkSkill(labelId);

    };
    skillEl.appendChild(checkboxEl);

    let labelEl = document.createElement("label");
    labelEl.setAttribute("for", checkboxId);
    labelEl.id = labelId;
    labelEl.textContent = skill.skillName;
    skillEl.appendChild(labelEl);
}
for (let skill of skillsList) {
    createAndAppendSkill(skill);
}

your ordered items:
-----------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="pt-5" id="orderedItemsContainer">
        <h1 class="main-heading">Your Ordered Items</h1>
        <ul class="item-list-container" id="itemListContainer"></ul>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.main-heading {
    font-size: 25px;
    text-align: center;
}

.order-item {
    font-size: 14px;
    padding: 10px;
    font-family: Roboto;
}

.item-list-container {
    list-style-type: none;
}

JS:

let itemList = [{
        itemName: "Veg Biryani",
        uniqueNo: 1,
    },
    {
        itemName: "Chicken 65",
        uniqueNo: 2,
    },
    {
        itemName: "Paratha",
        uniqueNo: 3,
    }
];

let itemListContainerEl = document.getElementById("itemListContainer");

function onDeleteItem(itemId) {
    let itemEl = document.getElementById(itemId);
    itemListContainerEl.removeChild(itemEl);
}

function createAndAppendItem(item) {
    let itemId = "item" + item.uniqueNo;
    let buttonId = "button" + item.uniqueNo;

    let itemEl = document.createElement("li");
    itemEl.id = itemId;
    itemEl.classList.add("order-item");
    itemEl.textContent = item.itemName;
    itemListContainerEl.appendChild(itemEl);

    let buttonEl = document.createElement("button");
    buttonEl.id = buttonId;
    buttonEl.classList.add("btn", "btn-danger", "ml-3");
    buttonEl.textContent = "Cancel";

    buttonEl.onclick = function() {
        onDeleteItem(itemId);
    };
    itemEl.appendChild(buttonEl);


}
for (let item of itemList) {
    createAndAppendItem(item);
}


1. Execution Context:
------------------------------------

The environment in which JavaScript Code runs is called Execution Context.

Execution context contains all the variables, objects, and functions.

Execution Context is destroyed and recreated whenever we reload an Application.

2. Storage Mechanisms:
-------------------------------

2.1 Client-Side Data Storage

Client-Side Data Storage is storing the data on the client (user's machine).

Local Storage
Session Storage
Cookies
IndexedDB and many more.

2.2 Server-Side Data Storage

Server-Side Data Storage is storing the data on the server.

3. Local Storage

It allows web applications to store data locally within the user's browser.

It is a Storage Object. Data can be stored in the form of key-value pairs.

Please note that both key and value must be strings. If their type is other than a string, they get converted to strings automatically.

Key	        Value
fullName	Rahul Attuluri
gender	    Male
city	    Delhi

To access and work with Local Storage we have below methods:

setItem()
getItem()
clear()
removeItem()

3.1 The setItem() Method:

The setItem() method can be used for storing data in the Local Storage.

Syntax: localStorage.setItem("Key", "Value");

3.2 The getItem() Method:

The getItem() method can be used for getting data from the Local Storage.

Syntax: localStorage.getItem("Key");

Try out the setItem() and getItem() methods in the below Code Playground.

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    Your HTML code goes here. Write JavaScript code in JAVASCRIPT tab.
  </body>
</html>

JS:

localStorage.setItem("fullName", "Rahul Attuluri");

localStorage.setItem("gender", "Male");

localStorage.setItem("city", "Delhi");

let fullName = localStorage.getItem("fullName");

let gender = localStorage.getItem("gender");

let city = localStorage.getItem("city");

console.log(fullName);
console.log(gender);
console.log(city);

4. Values:
-------------------

4.1 null
We use null in a situation where we intentionally want a variable but don't need a value to it.

JS:

let selectedColor = null;

console.log(selectedColor);  // null
console.log(typeof(selectedColor));  // object

5. HTML Elements:
--------------------------

5.1 The textarea Element
The HTML textarea element can be used to write the multiline text as an input.

HTML:

<textarea rows="8" cols="55"></textarea>

The HTML rows attribute specifies the number of lines.
The HTML cols attribute specifies the number of characters per each line.
Try out the HTML textarea element, setItem() and getItem() methods in the below Code Playground.

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <textarea rows="8" cols="55" id="message"></textarea>
    <br />
    <button class="btn btn-primary mt-1" id="saveButton">Save</button>
  </body>
</html>

JS:

let textAreaElement = document.getElementById("message");
let saveButton = document.getElementById("saveButton");

saveButton.onclick = function() {
  let userEnteredText = textAreaElement.value;
  localStorage.setItem("userEnteredText", userEnteredText);
};

let storedUserInputValue = localStorage.getItem("userEnteredText");

if (storedUserInputValue === null) {
  textAreaElement.value = "";
}
else {
  textAreaElement.value = storedUserInputValue;
}

coding pratice-9:
-----------------------------------------

movie reviews:
---------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container pt-4" id="movieReviewsContainer">
        <div class="row">
            <h1 class="col-12 text-center reviews-heading">
                Movie Reviews
            </h1>
            <div class="col-12 mb-4">
                <label for='titleInput' class='input-label'>MOVIE TITLE </label>
                <input type="text" class="w-100 title-input" id="titleInput" placeholder="Enter a movie title" />
                <label for="reviewTextarea" class="input-label">YOUR REVIEW</label>
                <textarea class="w-100 p-2 review-textarea" id="reviewTextarea" rows="5" placeholder="Enter your review"></textarea>
                <div class="d-flex flex-row justify-content-end mt-3">
                    <button class="btn btn-primary" id="addBtn" onclick="onAddReview()">Add</button>
                </div>
            </div>
            <div class="col-12 mt-4" id="reviewsContainer"> </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.reviews-heading {
    color: #2d3a35;
    font-family: "Roboto";
    font-size: 36px;
    font-weight: 700;
}

.input-label {
    color: #7b8794;
    font-family: "Roboto";
    font-weight: bold;
    font-size: 12px;
    margin-top: 16px;
    margin-bottom: 6px;
}

.title-input {
    font-family: "Roboto";
    height: 40px;
    border-style: solid;
    border-width: 1px;
    border-color: #cbd2d9;
    border-radius: 4px;
    padding-left: 12px;
}

.review-textarea {
    font-family: "Roboto";
    color: #2d3a35;
    border-style: solid;
    border-width: 1px;
    border-color: #cbd2d9;
    border-radius: 4px;

}

.movie-title {
    font-weight: bold;
    font-size: 18px;
    margin-bottom: 14px;
}

JS:

let reviewsContainerEl = document.getElementById('reviewsContainer');
let titleInputEl = document.getElementById('titleInput');
let reviewTextareaEl = document.getElementById('reviewTextarea');

function onAddReview() {
    let movieTitle = titleInputEl.value;
    let movieReview = reviewTextareaEl.value;

    if (movieTitle === '') {
        alert('please enter a movie title');
        return;
    }

    let movieTitleEl = document.createElement('h1');
    movieTitleEl.textContent = "movieTitle: " + movieTitle;
    movieTitleEl.classList.add('movie-title');
    reviewsContainerEl.appendChild(movieTitleEl);

    let movieReviewEl = document.createElement('p');
    movieReviewEl.textContent = 'Review: ' + movieReview;
    reviewsContainerEl.appendChild(movieReviewEl);

    let horizontalLineEl = document.createElement('hr');
    reviewsContainerEl.appendChild(horizontalLineEl);

    titleInputEl.value = '';
    reviewTextareaEl.value = '';
}

click Counter:
----------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container d-flex flex-column justify-content-center text-center" id="clickCounterContainer">
        <h1 class="counter-heading">The Button has been clicked
            <br /> <span id="counterValue" class="counter-value">0</span>
            times
        </h1>
        <div class="mt-2 text-center">
            <p class="description">Click the button to increase the count!</p>
            <button class="button btn btn-primary" id="incrementBtn" onclick="onIncrementCount()">Click Me!</button>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-color: #f1f5f8;
    height: 100vh;
}

.counter-heading{
    text-align: center;
    color: #2d3a35;
    font-family: "Roboto";
    font-size: 50px;
    font-weight: 800;
}

.description{
    color: #2d3a35;
    font-family: "Roboto";
}

.button{
    font-family: "Roboto";
    padding-top: 12px;
    padding-bottom: 12px;
}
.counter-value{
    color: #c20a72;
    font-weight: 900;
}

JS:

let counterValueEl = document.getElementById('counterValue');
let clickCounterContainerEl = document.getElementById('clickCounterContainer');

localStorage.clear();
let clickCount = localStorage.getItem('clickCount');

if (clickCount === null) {
    counterValueEl.textContent = 0;

} else {
    counterValueEl.textContent = clickCount;
}

function onIncrementCount() {
    let previousCounterValue = counterValueEl.textContent;
    let updatedCounterValue = parseInt(previousCounterValue) + 1;

    localStorage.setItem('clickCount', updatedCounterValue);
    counterValueEl.textContent = updatedCounterValue;
}

localStorage.clear();

1. JavaScript Object Notation (JSON):

JSON is a data representation format used for:

Storing data (Client/Server)
Exchanging data between Client and Server

1.1 Supported Types:

Number
String
Boolean
Array
Object
Null

1.2 JS Object vs JSON Object:

In JSON, all keys in an object must be enclosed with double-quotes. While in JS, this is not necessary.

JS:

let profile = {
  name: "Rahul",
  age: 29,
  designation: "Web Developer"
};

JSON:

let profile = {
  "name": "Rahul",
  "age": 29,
  "designation": "Web Developer"
};

1.3 JSON Methods:

1.3.1 JSON.stringify()
It converts the given value into JSON string.

Syntax: JSON.stringify( value )

1.3.2 JSON.parse()
It parses a JSON string and returns a JS object.

Syntax: JSON.parse( string )

Try out the JSON Methods in the below Code Playground.

let profile = {
  name: "Rahul",
  age: 29,
  designation: "Web Developer"
};
console.log(profile);
let stringifiedProfile = JSON.stringify(profile);
let parsedProfile = JSON.parse(stringifiedProfile);

console.log(stringifiedProfile);
console.log(parsedProfile);


console.log(typeof(stringifiedProfile));
console.log(typeof(parsedProfile));

console window:

Object {name: "Rahul", age: 29, designation: "Web Developer"}
{"name":"Rahul","age":29,"designation":"Web Developer"} 
Object {name: "Rahul", age: 29, designation: "Web Developer"}
string 
object 

LocalStorage:
---------------------

let profile = {
  name: "Rahul",
  age: 29,
  designation: "Web Developer"
};

let stringifiedProfile = JSON.stringify(profile);
localStorage.setItem('profileDetails',stringifiedProfile);

let stringifiedProfileFromlocalStorage = localStorage.getItem('profileDetails');
let parsedProfile = JSON.parse(stringifiedProfileFromlocalStorage);
console.log(parsedProfile)
console.log(typeof(parsedProfile))

console window:

Object {name: "Rahul", age: 29, designation: "Web Developer"}
object 


Todo-3:
--------------

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/5f59ca6ad3.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="todos-bg-container">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <h1 class="todos-heading">Todos</h1>
            <h1 class="create-task-heading">
              Create <span class="create-task-heading-subpart">Task</span>
            </h1>
            <input type="text" id="todoUserInput" class="todo-user-input" placeholder="What needs to be done?"/>
            <button class="button" id="addTodoButton">Add</button>
            <h1 class="todo-items-heading">
              My <span class="todo-items-heading-subpart">Tasks</span>
            </h1>
            <ul class="todo-items-container" id="todoItemsContainer"></ul>
            <button class="button" id="saveTodoButton">Save</button>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.todos-bg-container {
  background-color: #f9fbfe;
  height: 100vh;
}

.todos-heading {
  text-align: center;
  font-family: "Roboto";
  font-size: 46px;
  font-weight: 500;
  margin-top: 20px;
  margin-bottom: 20px;
}

.create-task-heading {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 700;
}

.create-task-heading-subpart {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 500;
}

.todo-items-heading {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 700;
}

.todo-items-heading-subpart {
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 500;
}

.todo-items-container {
  margin: 0px;
  padding: 0px;
}

.todo-item-container {
  margin-top: 15px;
}

.todo-user-input {
  background-color: white;
  width: 100%;
  border-style: solid;
  border-width: 1px;
  border-color: #e4e7eb;
  border-radius: 10px;
  margin-top: 10px;
  padding: 15px;
}

.button {
  color: white;
  background-color: #4c63b6;
  font-family: "Roboto";
  font-size: 18px;
  border-width: 0px;
  border-radius: 4px;
  margin-top: 20px;
  margin-bottom: 50px;
  padding-top: 5px;
  padding-bottom: 5px;
  padding-right: 20px;
  padding-left: 20px;
}

.label-container {
  background-color: #e6f6ff;
  width: 100%;
  border-style: solid;
  border-width: 5px;
  border-color: #096f92;
  border-right: none;
  border-top: none;
  border-bottom: none;
  border-radius: 4px;
}

.checkbox-input {
  width: 20px;
  height: 20px;
  margin-top: 12px;
  margin-right: 12px;
}

.checkbox-label {
  font-family: "Roboto";
  font-size: 16px;
  font-weight: 400;
  width: 82%;
  margin: 0px;
  padding-top: 10px;
  padding-bottom: 10px;
  padding-left: 20px;
  padding-right: 20px;
  border-radius: 5px;
}

.delete-icon-container {
  text-align: right;
  width: 18%;
}

.delete-icon {
  padding: 15px;
}

.checked {
  text-decoration: line-through;
}

JS:

let todoItemsContainer = document.getElementById("todoItemsContainer");
let addTodoButton = document.getElementById("addTodoButton");
let saveTodoButton = document.getElementById("saveTodoButton");

function getTodoListFromLocalStorage() {
  let stringifiedTodoList = localStorage.getItem("todoList");
  let parsedTodoList = JSON.parse(stringifiedTodoList);
  if (parsedTodoList === null) {
    return [];
  } else {
    return parsedTodoList;
  }
}

let todoList = getTodoListFromLocalStorage();
let todosCount = todoList.length;

saveTodoButton.onclick = function () {
  localStorage.setItem("todoList", JSON.stringify(todoList));
};

function onTodoStatusChange(checkboxId, labelId) {
  let checkboxElement = document.getElementById(checkboxId);
  let labelElement = document.getElementById(labelId);
  labelElement.classList.toggle("checked");
}

function onDeleteTodo(todoId) {
  let todoElement = document.getElementById(todoId);
  todoItemsContainer.removeChild(todoElement);
}

function createAndAppendTodo(todo) {
  let todoId = "todo" + todo.uniqueNo;
  let checkboxId = "checkbox" + todo.uniqueNo;
  let labelId = "label" + todo.uniqueNo;

  let todoElement = document.createElement("li");
  todoElement.classList.add("todo-item-container", "d-flex", "flex-row");
  todoElement.id = todoId;
  todoItemsContainer.appendChild(todoElement);

  let inputElement = document.createElement("input");
  inputElement.type = "checkbox";
  inputElement.id = checkboxId;

  inputElement.onclick = function() {
    onTodoStatusChange(checkboxId, labelId);
  };

  inputElement.classList.add("checkbox-input");
  todoElement.appendChild(inputElement);

  let labelContainer = document.createElement("div");
  labelContainer.classList.add("label-container", "d-flex", "flex-row");
  todoElement.appendChild(labelContainer);

  let labelElement = document.createElement("label");
  labelElement.setAttribute("for", checkboxId);
  labelElement.id = labelId;
  labelElement.classList.add("checkbox-label");
  labelElement.textContent = todo.text;
  labelContainer.appendChild(labelElement);

  let deleteIconContainer = document.createElement("div");
  deleteIconContainer.classList.add("delete-icon-container");
  labelContainer.appendChild(deleteIconContainer);

  let deleteIcon = document.createElement("i");
  deleteIcon.classList.add("far", "fa-trash-alt", "delete-icon");

  deleteIcon.onclick = function () {
    onDeleteTodo(todoId);
  };

  deleteIconContainer.appendChild(deleteIcon);
}

for (let todo of todoList) {
  createAndAppendTodo(todo);
}

function onAddTodo() {
  let userInputElement = document.getElementById("todoUserInput");
  let userInputValue = userInputElement.value;

  if (userInputValue === "") {
    alert("Enter Valid Text");
    return;
  }

  todosCount = todosCount + 1;

  let newTodo = {
    text: userInputValue,
    uniqueNo: todosCount,
  };
  todoList.push(newTodo);
  createAndAppendTodo(newTodo);
  userInputElement.value = "";
}

addTodoButton.onclick = function () {
  onAddTodo();
};

coding pratice-10:
----------------------------

JSON Stringify Practice:
----------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="json-container" id="jsonContainer">
        <h1 class="heading">JSON Stringified Values</h1>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.json-container {
    padding: 30px;
}

.heading {
    font-family: "Roboto";
    font-size: 24px;
    font-weight: 600;
}

.value-container{
    background-color: #f3f3f3;
    border-radius: 12px;
    margin-top: 20px;
    padding: 10px;
}

.value{
    font-family: "Roboto";
    font-size: 14px;
}

JS:

let bikes = ["Hero", "Honda", "Bajaj", "Suzuki", "Yamaha"];
let person = {
    name: "Rahul",
    age: 25,
    gender: "Male",
};
let todos = [{
        todo: "Attending CCBP sessions",
        todoStatus: "Completed",
    },
    {
        todo: "Completing practice sets",
        todoStatus: "Not Completed",
    },
    {
        todo: "Asking doubts",
        todoStatus: "Completed",
    },
];
let valuesToStringify = [bikes, person, todos];

let jsonContainerEl = document.getElementById('jsonContainer')

function createAndAppendValue(stringifiedValue) {
    let valueContainerEl = document.createElement("div");
    valueContainerEl.classList.add('value-container');
    jsonContainerEl.appendChild(valueContainerEl);
    
    let valueEl = document.createElement('span');
    valueEl.classList.add('value');
    valueContainerEl.appendChild(valueEl);
    valueEl.textContent = stringifiedValue;
}

function converttoJSONString(value){
    let stringifiedValue = JSON.stringify(value);
    createAndAppendValue(stringifiedValue);

    
}

for(let value of valuesToStringify){
    converttoJSONString(value);
}


Greeting card:
--------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="greeting-card-container">
        <div class="text-right">
            <p class="greet" id='greetFrom'></p>
            <p class="greet" id="greetTo"></p>
        </div>
        <div class="greet-text-container d-flex flex-column justify-content-center" id="wishTextContainer">
            <h1 class="heading">Happy <br /><span class="new-year">New Year</span></h1>
            <p class="greet-text mt-4" id="greetText"></p>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.greeting-card-container {
    background-image: url("https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/greeting-card-1-bg.png");
    background-size: cover;
    height: 100vh;
    padding: 20px;
}

.greet {
    color: #1f2933;
    font-family: "DM Sans";
    font-weight: bold;
}

.heading {
    color: #1f2933;
    font-family: "Playfair Display";
    font-size: 50px;
    font-weight: 500;
}

.new-year {
    font-size: 75px;
}

.greet-text-container {
    text-align: center;
    height: 80vh;
}

.greet-text {
    color: #323f4b;
    font-family: "Roboto";
    font-size: 24px;
}

JS:

let greeting = '{"greetText":"Wishing that the new year will bring joy, love, peace, and happiness to you.","from":"Rahul","to":"Varakumar"}';

let parsedValue = JSON.parse(greeting);

let greetTextEl = document.getElementById('greetText');
let greetFromEl = document.getElementById('greetFrom');
let greetToEl = document.getElementById('greetTo');

greetTextEl.textContent = parsedValue.greetText;
greetFromEl.textContent = "From: " + parsedValue.from;
greetToEl.textContent = "To: " + parsedValue.to;


1. Array Methods:

Method															Functionality

includes, indexOf, lastIndexOf, find, findIndex()				Finding Elements
push, unshift, splice											Adding Elements
pop, shift, splice												Removing Elements
concat, slice													Combining & Slicing Arrays
join															Joining Array Elements
sort															Sorting Array Elements

1.1 splice():

The splice() method changes the contents of an array.

Using splice() method, we can

Remove existing items
Replace existing items
Add new items

1.1.1 Removing existing items:

Syntax: arr.splice(Start, Delete Count)

Start: Starting Index
Delete Count: Number of items to be removed, starting from the given index

let myArray = [5, "six", 2, 8.2];
myArray.splice(2, 2);

console.log(myArray);  // [5, "six"]

let deletedItems = myArray.splice(2, 2);

console.log(deletedItems);  // [2, 8.2]

The splice() method returns an array containing the deleted items.

1.1.2 Adding new items:

Syntax: arr.splice(Start, Delete Count, Item1, Item2 ... )

Here the Item1, Item2 ... are the items to be added, starting from the given index.

let myArray = [5, "six", 2, 8.2];
myArray.splice(2, 0, "one", false);

console.log(myArray);  // [5, "six", "one", false, 2, 8.2]

1.1.3 Replacing existing items:

Syntax: arr.splice(Start, Delete Count, Item1, Item2 ... )


let myArray = [5, "six", 2, 8.2];
myArray.splice(2, 1, true);

console.log(myArray);  // [5, "six", true, 8.2]

1.2 findIndex():

The findIndex() method returns the first item's index that satisfies the provided testing function. If no item is found, it returns -1.

Syntax: arr.findIndex(Testing Function)

Here Testing Function is a function to execute on each value in the array.

let myArray = [5, 12, 8, 130, 44];
let itemIndex = myArray.findIndex(function(eachItem) {
  console.log(eachItem);
});

In the above code snippet, the below function is a Testing Function.

function(eachItem) {
  console.log(eachItem);
}
----------

1.3 includes()
The includes() method returns true if the provided item exists in the array. If no item is found, it returns false.

Syntax: arr.includes(item)

1.4 indexOf()
The indexOf() method returns the first index at which a given item can be found in the array. If no item is found, it returns -1.

Syntax: arr.indexOf(item)

1.5 lastIndexOf()
The lastIndexOf() method returns the last index at which a given item can be found in the array. If no item is found, it returns -1.

Syntax: arr.lastIndexOf(item)

1.6 find()
The find() method returns the first item's value that satisfies the provided testing function. If no item is found, it returns undefined.

Syntax: arr.find(Testing Function)

1.7 unshift()
The unshift() method adds one or more items to the beginning of an array and returns the new array length.

Syntax: arr.unshift(item1,item2, ..., itemN)

1.8 shift()
The shift() method removes the first item from an array and returns that removed item.

Syntax: arr.shift()

1.9 concat()
The concat() method can be used to merge two or more arrays.

This method does not change the existing arrays but instead returns a new array.

Syntax: let newArray = arr1.concat(arr2);

1.10 slice()
The slice() method returns a portion between the specified start index and end index(end index not included) of an array into a new array.

Syntax: arr.slice(startIndex, endIndex)

1.11 join()
The join() method creates and returns a new string by concatenating all of the items in an array, separated by commas or a specified separator string.

If the array has only one item, then it will be returned without using the specified separator.

Syntax: arr.join(separator)

Here separator is a string used to separate each item of the array. If omitted, the array items are separated with a comma.

1.12 sort()
The sort() method sorts the items of an array and returns the sorted array. The default sort order is ascending.

Syntax: arr.sort()

let arr = ["Wind", "Water", "Fire"];
let combinedString = arr.join(",");
console.log(combinedString); // Wind,Water,Fire 

Todo-4: Deleting a Todo and updating Local Storage:
--------------------------------------------------------------------------------
JS:

let todoItemsContainer = document.getElementById("todoItemsContainer");
let addTodoButton = document.getElementById("addTodoButton");
let saveTodoButton = document.getElementById("saveTodoButton");

function getTodoListFromLocalStorage() {
  let stringifiedTodoList = localStorage.getItem("todoList");
  let parsedTodoList = JSON.parse(stringifiedTodoList);
  if (parsedTodoList === null) {
    return [];
  } else {
    return parsedTodoList;
  }
}

let todoList = getTodoListFromLocalStorage();
let todosCount = todoList.length;

saveTodoButton.onclick = function () {
  localStorage.setItem("todoList", JSON.stringify(todoList));
};

function onAddTodo() {
  let userInputElement = document.getElementById("todoUserInput");
  let userInputValue = userInputElement.value;

  if (userInputValue === "") {
    alert("Enter Valid Text");
    return;
  }

  todosCount = todosCount + 1;

  let newTodo = {
    text: userInputValue,
    uniqueNo: todosCount,
  };
  todoList.push(newTodo);
  createAndAppendTodo(newTodo);
  userInputElement.value = "";
}

addTodoButton.onclick = function () {
  onAddTodo();
};

function onDeleteTodo(todoId) {
  let todoElement = document.getElementById(todoId);
  todoItemsContainer.removeChild(todoElement);

  let deleteElementIndex = todoList.findIndex(function(eachTodo) {
    let eachTodoId = "todo" + eachTodo.uniqueNo;
    if (eachTodoId === todoId) {
      return true;
    } else {
      return false;
    }
  });

  todoList.splice(deleteElementIndex, 1);
}

function onTodoStatusChange(checkboxId, labelId) {
  let checkboxElement = document.getElementById(checkboxId);
  let labelElement = document.getElementById(labelId);
  labelElement.classList.toggle("checked");
}

function createAndAppendTodo(todo) {
  let todoId = "todo" + todo.uniqueNo;
  let checkboxId = "checkbox" + todo.uniqueNo;
  let labelId = "label" + todo.uniqueNo;

  let todoElement = document.createElement("li");
  todoElement.classList.add("todo-item-container", "d-flex", "flex-row");
  todoElement.id = todoId;
  todoItemsContainer.appendChild(todoElement);

  let inputElement = document.createElement("input");
  inputElement.type = "checkbox";
  inputElement.id = checkboxId;

  inputElement.onclick = function() {
    onTodoStatusChange(checkboxId, labelId);
  };

  inputElement.classList.add("checkbox-input");
  todoElement.appendChild(inputElement);

  let labelContainer = document.createElement("div");
  labelContainer.classList.add("label-container", "d-flex", "flex-row");
  todoElement.appendChild(labelContainer);

  let labelElement = document.createElement("label");
  labelElement.setAttribute("for", checkboxId);
  labelElement.id = labelId;
  labelElement.classList.add("checkbox-label");
  labelElement.textContent = todo.text;
  labelContainer.appendChild(labelElement);

  let deleteIconContainer = document.createElement("div");
  deleteIconContainer.classList.add("delete-icon-container");
  labelContainer.appendChild(deleteIconContainer);

  let deleteIcon = document.createElement("i");
  deleteIcon.classList.add("far", "fa-trash-alt", "delete-icon");

  deleteIcon.onclick = function () {
    onDeleteTodo(todoId);
  };

  deleteIconContainer.appendChild(deleteIcon);
}

for (let todo of todoList) {
  createAndAppendTodo(todo);
}

JS coding pratice-6:
--------------------------------------------

Find the First Occurence of string:
-------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function findFirstStringOccurrence(myArray) {
  /*
   * Write your code here and return the output.
   */
   let r = myArray.find(function(eachVal){
       if (typeof(eachVal) === "string"){
           return true;
       }else{
           return false;
       }
   });
   return r;
}

/* Please do not modify anything below this line */

function main() {
  let myArray = JSON.parse(readLine().replace(/'/g, '"'));
  
  let firstStringVal = findFirstStringOccurrence(myArray);
  console.log(firstStringVal);
}

Input:

[23, 4.5, 'Asia', 7, 'Europe']

Output:

Asia

JS coding pratice-7:
--------------------------------------------------

JOIN:
------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function joinArrayValues(myArray, separator) {
  /*
   * Write your code here and return the output.
   */
   let r = myArray.join(separator);
   return r;
}

/* Please do not modify anything below this line */

function main() {
  let myArray = JSON.parse(readLine().replace(/'/g, '"'));
  let separator =  readLine();
  
  let newString = joinArrayValues(myArray, separator);
  
  console.log(newString);
}

Input:

[ 1, 2, 3, 4, 5 ]
+

Output:

1+2+3+4+5


coding pratice-11:
-----------------------------------

splice playground:
-----------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container pt-5">
        <div class="row">
            <h1 class="playground-heading col-12 text-center">Splice Playground</h1>
            <div class="col-4 mt-4 mb-4">
                <label class="input-label">START INDEX</label>
                <input type="text" class="user-input" id="startIndexInput" placeholder="1" />
            </div>
            <div class="col-4 mt-4 mb-4">
                <label class="input-label">DELETE COUNT</label>
                <input type="text" class="user-input" id="deleteCountInput" placeholder="0" />
            </div>
            <div class="col-4 mt-4 mb-4">
                <label class="input-label">ITEM TO ADD</label>
                <input type="text" class="user-input" id="itemToAddInput" placeholder="2" />
            </div>
            <div class="col-12 text-center mb-4">
                <button class="btn btn-primary" id='spliceBtn'>Splice</button>
            </div>
            <h1 class="col-12 updated-array-heading">Updated Array</h1>
            <div class="col-12 updated-array-container">
                <span class="updated-array" id="updatedArray"></span>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.playground-heading {
    color: #2d3a35;
    font-family: "Roboto";
    font-size: 36px;
    font-weight: 700;
}

.input-label {
    text-align: center;
    color: #7b8794;
    font-family: "Roboto";
    font-size: 12px;
    font-weight: bold;
}

.user-input {
    text-align: center;
    height: 40px;
    width: 100%;
    border-style: solid;
    border-width: 1px;
    border-color: #cbd2d9;
    border-radius: 4px;
}

.updated-array-heading {
    font-family: "Roboto";
    font-weight: 600;
    font-size: 18px;
}

.updated-array-container {
    background-color: #f3f3f3;
    padding: 20px;
}

.updated-array {
    font-family: "Bree Serif";
    font-size: 16px;
}

JS:

let arr = [1, 7, 3, 1, 0, 20, 77];

let startIndexInputEl = document.getElementById('startIndexInput');
let deleteCountInputEl = document.getElementById('deleteCountInput');
let itemToAddInputEl = document.getElementById('itemToAddInput');
let updatedArrayEl = document.getElementById('updatedArray');
let spliceBtnEl = document.getElementById('spliceBtn');

function convertArrtoJSONStringAndAppend() {
    const stringifiedArr = JSON.stringify(arr);
    updatedArrayEl.textContent = stringifiedArr;
}
convertArrtoJSONStringAndAppend();

spliceBtnEl.onclick = function spliceArray() {
    let startIndex = startIndexInputEl.value;
    let deleteCount = deleteCountInputEl.value;
    let itemToAdd = itemToAddInputEl.value;


    if (startIndex === '') {
        alert('please enter start Index');
        return;
    }

    if (deleteCount === '') {
        deleteCount = 0;
    }

    if (itemToAdd === '') {
        arr.splice(parseInt(startIndex), parseInt(deleteCount));

    } else {
        arr.splice(parseInt(startIndex), parseInt(deleteCount), itemToAdd);
    }

    startIndexInputEl.value = '';
    deleteCountInputEl.value = '';
    itemToAddInputEl.value = '';
    convertArrtoJSONStringAndAppend();

}

Find the Index of the Numbers:
----------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container pt-5">
        <div class="row">
            <h1 class="playground-heading col-12 text-center">Find the Index of the Numbers</h1>
            <div class="col-12 mt-4 mb-4">
                <p class="default-array text-center">[ 17, 31, 77, 20, 63 ]</p>
            </div>
            <div class="col-12 d-flex flex-row justify-content-center mb-5">
                <input type="text" class="user-input w-50 pl-2" id="userInput" placeholder="Enter a number" />
                <button class="btn btn-primary ml-3" id="findBtn" onclick="findIndexOfNumber()">Find</button>
            </div>
            <h1 class="index-of-number-heading">Index of number:</h1>
            <div class="col-12 index-of-number-container text-center">
                <span class="index-of-number" id="indexOfNumber"></span>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.playground-heading {
    color: #2d3a35;
    font-family: "Roboto";
    font-size: 36px;
    font-weight: 700;
}

.default-array {
    color: #2d3a35;
    font-family: "Bree Serif";
    font-size: 24px;
}

.user-input {
    height: 40px;
    width: 100%;
    border-style: solid;
    border-width: 1px;
    border-color: #cbd2d9;
    border-radius: 4px;
}

.index-of-number-heading {
    font-family: "Roboto";
    font-size: 22px;
    font-weight: 600;
}

.index-of-number-container {
    color: #795e26;
    background-color: #f3f3f3;
    padding: 20px;
    margin-top: 10px;
}

.index-of-number {
    color: #795e26;
    font-family: "Bree Serif";
    font-size: 36px;
    font-weight: 800;
}

JS:

let numbers = [17, 31, 77, 20, 63];

let userInputEl = document.getElementById('userInput');
let indexOfNumberEl = document.getElementById('indexOfNumber');

function findIndexOfNumber() {
    let number = parseInt(userInput.value);
    let itemIndex = numbers.findIndex(function(eachItem) {
        if (eachItem === number) {
            return true;

        } else {
            return false;
        }
    });

    indexOfNumberEl.textContent = itemIndex;
}

1. Local Storage:

1.1 The removeItem() Method:

The removeItem() method removes the specified storage object item based on the key.

Syntax: localStorage.removeItem(key)

Key - Name of the key to be removed

JS:

localStorage.removeItem("todoList");

Todo-5: persisting the todo checked status
------------------------------------------------------------------------------

let todoItemsContainer = document.getElementById("todoItemsContainer");
let addTodoButton = document.getElementById("addTodoButton");
let saveTodoButton = document.getElementById("saveTodoButton");

function getTodoListFromLocalStorage() {
  let stringifiedTodoList = localStorage.getItem("todoList");
  let parsedTodoList = JSON.parse(stringifiedTodoList);
  if (parsedTodoList === null) {
    return [];
  } else {
    return parsedTodoList;
  }
}

let todoList = getTodoListFromLocalStorage();
let todosCount = todoList.length;

saveTodoButton.onclick = function() {
  localStorage.setItem("todoList", JSON.stringify(todoList));
};

function onAddTodo() {
  let userInputElement = document.getElementById("todoUserInput");
  let userInputValue = userInputElement.value;

  if (userInputValue === "") {
    alert("Enter Valid Text");
    return;
  }

  todosCount = todosCount + 1;

  let newTodo = {
    text: userInputValue,
    uniqueNo: todosCount,
    isChecked: false
  };
  todoList.push(newTodo);
  createAndAppendTodo(newTodo);
  userInputElement.value = "";
}

addTodoButton.onclick = function() {
  onAddTodo();
};

function onTodoStatusChange(checkboxId, labelId, todoId) {
  let checkboxElement = document.getElementById(checkboxId);
  let labelElement = document.getElementById(labelId);
  labelElement.classList.toggle("checked");

  let todoObjectIndex = todoList.findIndex(function(eachTodo) {
    let eachTodoId = "todo" + eachTodo.uniqueNo;

    if (eachTodoId === todoId) {
      return true;
    } else {
      return false;
    }
  });

  let todoObject = todoList[todoObjectIndex];

  if(todoObject.isChecked === true){
    todoObject.isChecked = false;
  } else {
    todoObject.isChecked = true;
  }

}

function onDeleteTodo(todoId) {
  let todoElement = document.getElementById(todoId);
  todoItemsContainer.removeChild(todoElement);

  let deleteElementIndex = todoList.findIndex(function(eachTodo) {
    let eachTodoId = "todo" + eachTodo.uniqueNo;
    if (eachTodoId === todoId) {
      return true;
    } else {
      return false;
    }
  });

  todoList.splice(deleteElementIndex, 1);
}

function createAndAppendTodo(todo) {
  let todoId = "todo" + todo.uniqueNo;
  let checkboxId = "checkbox" + todo.uniqueNo;
  let labelId = "label" + todo.uniqueNo;

  let todoElement = document.createElement("li");
  todoElement.classList.add("todo-item-container", "d-flex", "flex-row");
  todoElement.id = todoId;
  todoItemsContainer.appendChild(todoElement);

  let inputElement = document.createElement("input");
  inputElement.type = "checkbox";
  inputElement.id = checkboxId;
  inputElement.checked = todo.isChecked;

  inputElement.onclick = function () {
    onTodoStatusChange(checkboxId, labelId, todoId);
  };

  inputElement.classList.add("checkbox-input");
  todoElement.appendChild(inputElement);

  let labelContainer = document.createElement("div");
  labelContainer.classList.add("label-container", "d-flex", "flex-row");
  todoElement.appendChild(labelContainer);

  let labelElement = document.createElement("label");
  labelElement.setAttribute("for", checkboxId);
  labelElement.id = labelId;
  labelElement.classList.add("checkbox-label");
  labelElement.textContent = todo.text;
  if (todo.isChecked === true) {
    labelElement.classList.add("checked");
  }
  labelContainer.appendChild(labelElement);

  let deleteIconContainer = document.createElement("div");
  deleteIconContainer.classList.add("delete-icon-container");
  labelContainer.appendChild(deleteIconContainer);

  let deleteIcon = document.createElement("i");
  deleteIcon.classList.add("far", "fa-trash-alt", "delete-icon");

  deleteIcon.onclick = function () {
    onDeleteTodo(todoId);
  };

  deleteIconContainer.appendChild(deleteIcon);
}

for (let todo of todoList) {
  createAndAppendTodo(todo);
}

coding pratice-12:
-----------------------------------------

Remove Item in Local Storage Practice:
-------------------------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="p-5">
        <div class="mt-3 mb-3 text-center">
            <input type="text" id="input" />
            <button class="btn btn-primary" id="saveBtn">Save</button>
            <button class="btn btn-primary" id="clearBtn">Clear</button>
        </div>
        <h1 class="heading text-center">Click on clear to remove the text in the HTML input element.</h1>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.heading {
    font-family: "Roboto";
    font-size: 24px;
}

JS:

let inputEl = document.getElementById("input");
let saveBtnEl = document.getElementById("saveBtn");
let clearBtnEl = document.getElementById("clearBtn");
let storageKey = "userInput";

let storageVal = localStorage.getItem(storageKey);

if (storageVal === null) {
    localStorage.setItem(storageKey, "Hello");
}

inputEl.value = localStorage.getItem(storageKey);

saveBtnEl.onclick = function() {
    let inputVal = inputEl.value;
    localStorage.setItem(storageKey, inputVal);
};

// Write your code here
clearBtnEl.onclick = function() {
    inputEl.value = '';
    localStorage.removeItem(storageKey);
};

Local Storage Practice:
---------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <textarea rows="8" cols="55" id="msg"></textarea>
    <br />
    <button class="btn btn-primary mt-1" id="saveBtn">Save</button>
    <button class="btn btn-primary mt-1" id="clearBtn">Clear</button>
</body>

</html>

JS:

let msgEl = document.getElementById("msg");
let saveBtnEl = document.getElementById("saveBtn");
let clearBtnEl = document.getElementById("clearBtn");
let storageKey = "userInput";

saveBtnEl.onclick = function() {
    let msgVal = msgEl.value;
    localStorage.setItem(storageKey, msgVal);
};

clearBtnEl.onclick = function() {
    msgEl.value = '';
    localStorage.removeItem(storageKey);
};

let storedUserInputVal = localStorage.getItem(storageKey);

if (storedUserInputVal !== null) {
    msgEl.value = storedUserInputVal;
} else{
    msgEl.value = "";
}

coding pratice-13:
-----------------------------------

chatbot:
------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/5f59ca6ad3.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="p-2">
        <h1 class="text-center chatbot-heading">Meet our Chatbot</h1>
        <img class="image" src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/chatbot-bot-img.png" />
        <div id="chatContainer" class="chat-container"></div>
        <div class="d-flex flex-row justify-content-end">
            <img class="image" src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/chatbot-boy-img.png" />
        </div>
        <div class="d-flex flex-row justify-content-center fixed-bottom">
            <input class="user-input" id="userInput"/>
            <button class="send-msg-btn" id="sendMsgBtn" onclick="sendMsgToChatbot()">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.chatbot-heading {
    color: #323f4b;
    font-family: "Roboto";
    font-size: 30px;
}

.image {
    width: 150px;
}

.chat-container {
    padding: 10px;
}

.msg-to-chatbot-container {
    text-align: right;
    margin-top: 10px;
    margin-bottom: 10px;
}

.msg-to-chatbot {
    background-color: #cbd2d9;
    font-family: "Roboto";
    font-weight: 900;
    border-radius: 16px;
    padding: 10px;
}

.msg-from-chatbot-container {
    margin-top: 10px;
    margin-bottom: 10px;
}

.msg-from-chatbot {
    color: white;
    background-color: #e57742;
    font-family: "Roboto";
    font-weight: 900;
    border-radius: 16px;
    padding: 10px;
}

.user-input {
    background-color: #cbd2d9;
    font-family: "Roboto";
    font-weight: 900;
    height: 52px;
    border-width: 0;
    border-radius: 5px;
    margin: 8px;
    padding: 15px;
}

.send-msg-btn {
    background-color: #cbd2d9;
    font-family: "Roboto";
    height: 52px;
    border-width: 0;
    border-radius: 10px;
    margin: 8px;
    padding-left: 25px;
    padding-right: 25px;
}

JS:

let chatbotMsgList = ["Hi", "Hey", "Good Morning", "Good Evening", "How can I help you?", "Thank You"];

let chatContainerEl = document.getElementById('chatContainer');
let userInputEl = document.getElementById('userInput');

function sendMsgToChatbot(){
    let userMsg = userInputEl.value;
    
    let msgContainerEl = document.createElement('div');
    msgContainerEl.classList.add('msg-to-chatbot-container');
    chatContainerEl.appendChild(msgContainerEl);
    
    let userMsgEl = document.createElement('span');
    userMsgEl.textContent = userMsg;
    msgContainerEl.classList.add('msg-to-chatbot');
    msgContainerEl.appendChild(userMsgEl);
    
    userInputEl.value = "";
    getReplyFromChatbot();
    
}

function getReplyFromChatbot() {
    
    let noOfChatbotMsgs = chatbotMsgList.length;
    let chatbotMsg = chatbotMsgList[Math.ceil(Math.random() * noOfChatbotMsgs) - 1];
    
     let msgContainerEl = document.createElement('div');
    msgContainerEl.classList.add('msg-to-chatbot-container');
    chatContainerEl.appendChild(msgContainerEl);
    
    let chatbotMsgEl = document.createElement('span');
    chatbotMsgEl.textContent = chatbotMsg;
    chatbotMsgEl.classList.add('msg-from-chatbot');
    msgContainerEl.appendChild(chatbotMsgEl);
    
}


word cloud:
----------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container word-cloud-container d-flex flex-column justify-content-between">
        <div class="row" id="wordsContainer"></div>
        <div class="row">
            <div class="col-12 text-center">
                <p class="error-msg" id="errorMsg"></p>
                <input type="text" class="user-input" id="userInput" />
                <button id="addBtn" class="add-btn ml-1" onclick="onAddWordToWordCloud()">
                    Add
                </button>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.word-cloud-container {
    height: 100vh;
    padding: 20px;
}

.user-input {
    width: 60%;
}

.add-btn {
    color: white;
    background-color: #565b6e;
    border-width: 0;
    border-radius: 5px;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 5px;
    padding-bottom: 5px;
}

.error-msg {
    color: #f62c3b;
    font-size: 14px;
}

JS:

let wordCloud = ["Hello", "hii", "how", "what", "you", "yourself", "name", "victory", "food", "lovely", "beautiful", "written", "where", "who", "awesome"];

let wordsContainerEl = document.getElementById('wordsContainer');
let userInputEl = document.getElementById('userInput');
let errorMsgEl = document.getElementById('errorMsg');

let errorMsg = "please enter a word";

function createAndAddWordToWorldCloud(word) {
    let randomFontSize = Math.ceil(Math.random() * 40) + "px";
    let wordEl = document.createElement("span")

    wordEl.textContent = word;
    wordEl.style.fontSize = randomFontSize;
    wordEl.classList.add("m-3");

    wordsContainerEl.appendChild(wordEl);
}

for (let word of wordCloud) {
    createAndAddWordToWorldCloud(word)
}

function onAddWordToWordCloud() {
    let userEnteredWord = userInputEl.value;

    if (userEnteredWord !== "") {
        userInputEl.value = "";
        errorMsgEl.textContent = "";
        createAndAddWordToWorldCloud(userEnteredWord);
    } else {
        errorMsgEl.textContent = errorMsg;
    }
}

1. Callback function:

A Callback is a function that is passed as an argument to another function.

1.1 Passing a function as an argument:

function displayGreeting(displayName) {
  console.log("Hello");
  displayName();
  console.log("Good Morning!");
}

displayGreeting(function() {
  console.log("Rahul");
});

1.2 Passing a function name as an argument

function displayGreeting(displayName) {
  console.log("Hello");
  displayName();
  console.log("Good Morning!");
}
function displayRahul() {
  console.log("Rahul");
}
displayGreeting(displayRahul);

1.3 Passing a function expression as an argument:

function displayGreeting(displayName) {
  console.log("Hello");
  displayName();
  console.log("Good Morning!");
}
let displayRam = function() {
  console.log("Ram");
};
displayGreeting(displayRam);

2. Schedulers:

The Schedulers are used to schedule the execution of a callback function.

There are different scheduler methods.

setInterval()
clearInterval()
setTimeout()
clearTimeout(), etc.

2.1 setInterval():

The setInterval() method allows us to run a function at the specified interval of time repeatedly.

Syntax: setInterval(function, delay);

function - a callback function that is called repeatedly at the specified interval of time (delay).
delay - time in milliseconds. (1 second = 1000 milliseconds)

JS:

let counter = 0;
setInterval(function() {
  console.log(counter);
  counter = counter+1;
}, 1000);

In the setInterval() method, the callback function repeatedly executes until the browser tab is closed or the scheduler is cancelled.

When we call the setInterval() method, it returns a unique id. This unique Id is used to cancel the callback function execution.

2.2 clearInterval():

The clearInterval() method cancels a schedule previously set up by calling setInterval().

To execute clearInterval() method, we need to pass the uniqueId returned by setInterval() as an argument.

Syntax: clearInterval(uniqueId);

JS:

let counter = 0;
let uniqueId = setInterval(function() {
  console.log(counter);
  counter = counter+1;
}, 1000);

clearInterval(uniqueId);

Try out the setInterval() and clearInterval() methods and check the output in the below Code Playground console.

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <button id="setIntervalBtn">
      Set Interval
    </button>
    <button id="clearIntervalBtn">
      Clear Interval
    </button>
  </body>
</html>

JS:

let setIntervalBtnEl = document.getElementById("setIntervalBtn");
let clearIntervalBtnEl = document.getElementById("clearIntervalBtn");

let uniqueId = null;

setIntervalBtnEl.onclick = function() {
  let counter = 0;
  uniqueId = setInterval(function() {
    console.log(counter);
    counter = counter + 1;
  }, 1000);
};

clearIntervalBtnEl.onclick = function() {
  clearInterval(uniqueId);
  console.log("Interval cleared");
};

2.3 setTimeout():

The setTimeout() method executes a function after the specified time.

Syntax: setTimeout(function, delay);

function - a callback function that is called after the specified time (delay).
delay - time in milliseconds.

JS:

let counter = 0;
setTimeout(function() {
  console.log(counter);
  counter = counter + 1;
}, 1000);

2.4 clearTimeout()
We can cancel the setTimeout() before it executes the callback function using the clearTimeout() method.

To execute clearTimeout(), we need to pass the uniqueId returned by setTimeout() as an argument.

Syntax: clearTimeout(uniqueId);

JS:

let counter = 0;
let uniqueId = setTimeout(function() {
  console.log(counter);
  counter = counter+1;
}, 1000);

clearTimeout(uniqueId);

Try out the setTimeout() and clearTimeout() methods and check the output in the below Code Playground console.

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <button id="setTimeoutBtn">
      Set Timeout
    </button>
  </body>
</html>

JS:

let setTimeoutBtnEl = document.getElementById("setTimeoutBtn");

let uniqueId = null;

setTimeoutBtnEl.onclick = function() {
  setTimeout(function() {
    console.log("Hello");
  }, 3000);
};

Event Listeners and More Events | Cheat Sheet
1. Event Listeners:

JavaScript offers three ways to add an Event Listener to a DOM element.

Inline event listeners
onevent listeners
addEventListener()

1.1 Inline event listeners:

HTML:

<button onclick="greeting()">Greet</button>

JS:

function greeting() {
  console.log("Hi Rahul");
}

1.2 onevent listeners:

<button id="greetBtn">Greet</button>

JS:

let greetBtnEl = document.getElementById("greetBtn");

greetBtnEl.onclick = function() {
  console.log("Hi Rahul");
};

1.3 addEventListener():

It is a modern approach to add an event listener.

Syntax: element.addEventListener(event, function);

element - HTML element
event - event name
function - Callback function

HTML:

<button id="greetBtn">Greet</button>

JS:

let greetBtn = document.getElementById("greetBtn");

greetBtn.addEventListener("click", function() {
  console.log("Hi Rahul");
});

2. Operators:

2.1 Comparison Operators:

Operator						Usage	Description
Equal ( == )					a == b	returns true if both a and b values are equal.
Not equal ( != )				a != b	returns true if both a and b values are not equal.
Strict equal ( === )			a === b	returns true if both a and b values are equal and of the same type.
Strict not equal ( !== )		a !== b	returns true if either a and b values are not equal or of the different type.
Greater than ( > )				a > b	returns true if a value is greater than b value.
Greater than or equal ( >= )	a >= b	returns true if a value is greater than or equal to b value.
Less than ( < )					a < b	returns true if a value is less than b value.
Less than or equal ( <= )		a <= b	returns true if a value is less than or equal to b value.

2.2 Logical Operators:

Operator	Usage	Description
AND ( && )	a && b	returns true if both a and b values are true.
OR ( | | )	a | | b	returns true if either a or b value is true.
NOT ( ! )	!a		returns true if a value is not true.

3. More Events:

Events are the actions by which the user or browser interact with HTML elements.

There are different types of events.

Keyboard Events
Mouse Events
Touch Events, and many more.

3.1 Keyboard Events:

Keyboard Event is the user interaction with the keyboard.

The keyboard events are

keydown
keyup

3.1.1 Keydown event:

The keydown event occurs when a key on the keyboard is pressed.

Syntax: element.addEventListener("keydown", function);

JS:

let inputEl = document.createElement("input");

function printKeydown() {
  console.log("key pressed");
}

inputEl.addEventListener("keydown", printKeydown);
document.body.appendChild(inputEl);

3.1.2 Keyup event:

The keyup event occurs when a key on the keyboard is released.

Syntax: element.addEventListener("keyup", function);

3.2 Event Object:

Whenever an event happens, the browser creates an event object.

It consists of information about the event that has happened.

It consists of many properties and methods.

type
target
key
timeStamp
stopPropagation, and many more.

3.2.1 Properties & Methods:

For any event, event-specific properties and methods will be present.

For Example,

The keydown event has key property, whereas the onclick event doesn't have it.

event.type
The event.type property contains the type of event occurred like click, keydown, etc.

JS:

let inputEl = document.createElement("input");

function printKeydown(event) {
  console.log(event.type);  // keydown
}

inputEl.addEventListener("keydown", printKeydown);
document.body.appendChild(inputEl);

event.target:

The event.target property contains the HTML element that triggered the event.

let inputElement = document.createElement("input");

function printKeydown(event) {
  console.log(event.target);  // <input></input>
}

inputElement.addEventListener("keydown", printKeydown);
document.body.appendChild(inputElement);

event.key:

The event.key property contains the value of the key pressed by the user.

let inputElement = document.createElement("input");

function printKeydown(event) {
  console.log(event.key);
}

inputElement.addEventListener("keydown", printKeydown);
document.body.appendChild(inputElement);

Keyboard key	event.key value
	
a				a
A				A
1				1
*				*
<				<

Defuse timer:
---------------------

HTML:


<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="timer-container">
      <input type="text" class="user-input" id="defuser" />
      <br />
      <img src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/time-bomb-img.png" class="bomb-image"/>
      <p class="timer-display" id="timer">10</p>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Monoton&family=Open+Sans:wght@400;700&family=Playfair+Display+SC:wght@400;700&family=Playfair+Display:wght@400;700&family=Roboto:wght@400;700&family=Source+Sans+Pro:wght@400;700&family=Work+Sans:wght@400;700&display=swap");

.timer-container {
  text-align: center;
  background-color: #00bafc;
  height: 100vh;
  padding: 20px;
}

.timer-display {
  color: white;
  font-size: 50px;
}

.user-input {
  text-align: center;
  border-width: 0px;
  border-radius: 4px;
  padding: 6px;
}

.bomb-image {
  width: 150px;
  margin-top: 40px;
}

JS:

let timerEl = document.getElementById("timer");
let defuserEl = document.getElementById("defuser");
let countdown = 10;

let intervalId = setInterval(function() {
  countdown = countdown - 1;
  timerEl.textContent = countdown;
  if (countdown === 0) {
    timerEl.textContent = "BOOM";
    clearInterval(intervalId);
  }
}, 1000);

defuserEl.addEventListener("keydown", function(event) {
  let bombDefuserText = defuserEl.value;
  if (event.key === "Enter" && bombDefuserText === "defuse" && countdown !== 0) {
    timerEl.textContent = "You did it!";
    clearInterval(intervalId);
  }
});

Hypertext Transfer Protocol (HTTP) | Cheat Sheet:

1. Web Resources:

A Web Resource is any data that can be obtained via internet.

A resource can be

HTML document
CSS document
JSON Data or Plain text
Image, Video, etc.

2. Uniform Resource Locator (URL):

URL is a text string that specifies where a resource can be found on the internet.

We can access web resources using the URL.

Syntax: protocol://domainName/path?query-parameters

In the URL http://www.flipkart.com/watches?type=digital&rating=4,

http is a Protocol
www.flipkart.com is a Domain Name
/watches is a Path
type=digital&rating=4 is the Query Parameters

2.1 Protocol:

A protocol is a standard set of rules that allow electronic devices to communicate with each other.

There are different types of protocols.

Hypertext Transfer Protocol (HTTP)
Hypertext Transfer Protocol Secure (HTTPS)
Web Sockets, etc.

2.1.1 HTTP:

The Hypertext Transfer Protocol (HTTP), is a protocol used to transfer resources over the web.

Examples: Internet forums, Educational sites, etc.

HTTP Request: Message sent by the client

HTTP Response: Message sent by the server

2.1.2 HTTPS:

In Hypertext Transfer Protocol Secure (HTTPS), information is transferred in an
encrypted format and provides secure communication.

Examples: Banking Websites, Payment gateway, Login Pages, Emails and Corporate Sector Websites, etc.

2.2 Domain Name:

It indicates which Web server is being requested.

2.3 Path:

The path is to identify the resources on the server.

Examples:

/watches in http://www.flipkart.com/watches
/electronics/laptops/gaming in http://www.flipkart.com/electronics/laptops/gaming

2.4 Query Parameters:

Query parameters add some criteria to the request for the resource.

Multiple query parameters can be added by using an & ( ampersand ) symbol.

For example,

http://www.flipkart.com/watches?type=digital&rating=4

3. HTTP:

3.1 HTTP Requests:

HTTP requests are messages sent by the client to initiate an action on the server.

HTTP request includes

Start Line
Headers
Body

3.1.1 Start Line:

A Start Line specifies a

URL
HTTP Method
HTTP Version
HTTP Methods

The HTTP Request methods indicate the desired action to be performed for a given resource.

Methods						Description
GET (Read)			Request for a resource(s) from the server
POST (Create)		Submit data to the server
PUT (Update)		The data within the request must be stored at the URL supplied, replacing any existing data
DELETE (Delete)		Delete a resource(s)

HTTP Version

Year	Version
1991	HTTP/0.9
1994	HTTPS
1996	HTTP/1.0
1997	HTTP/1.1
2015	HTTP/2
2019	HTTP/3

3.1.2 Headers
HTTP Headers let the client and the server to pass additional information with an HTTP request or response.

3.1.3 Body
We place the data in the Request body when we want to send data to the server.

For example, form details filled by the user.

HTTP Requests

Start Line
	URL
		Protocol
			HTTP
			HTTPS
		Domain Name
		Path
		Query Parameters
	HTTP Method
		GET (Read)
		POST (Create)
		PUT (Update)
		DELETE (Delete)
	HTTP Version
Headers
Body

3.2 HTTP Responses
HTTP responses are messages sent by the server as an answer to the clients request.

HTTP Response includes

Status Line
Headers
Body

3.2.1 Status Line
A Status line specifies a

HTTP version
Status code
Status text
Status code

Status codes Indicate whether an HTTP request has been successfully completed or not.

Status Code Series		Indicates
1XX						Information
2XX						Success
3XX						Redirection
4XX						Client Error
5XX						Server Error

200 ( Success ) - Indicates that the request has succeeded

201 ( Created ) - The request has succeeded and a new resource has been created as a result

Status text

Status Code			Status Text
200						OK
204					No Response
301					Moved Permanently
401					Unauthorized
403					Forbidden
404					Not Found

3.2.2 Body
Response Body contains the resource data that was requested by the client.

HTTP Responses

Status Line
	HTTP version
	Status code
		1XX
		2XX
		3XX
		4XX
		5XX
	Status text
Headers
Body

coding practice-14:
--------------------------------

clear the counter timer:
----------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="text-center pt-5">
        <h1 class="heading text-center">Clear the counter timer</h1>
        <p class="counter-value" id="counterValue"></p>
        <button class="btn btn-danger" id="clearBtn">Clear</button>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.heading {
    font-family: "Roboto";
    font-size: 24px;
}

.counter-value {
    font-size: 36px;
    font-weight: bold;
}

JS:

let clearBtnEl = document.getElementById("clearBtn");
let counterValue = document.getElementById("counterValue");

let counter = 0;

let counterTimer = function() {
    counter = counter + 1;
    counterValue.textContent = counter;
};

let intervalId = setInterval(counterTimer, 1000);

// Write your code here
clearBtnEl.onclick = function() {
    clearInterval(intervalId);
};

Custom Range Counter:
-------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container pt-3">
        <div class="row">
            <h1 class="col-12 heading text-center">Custom Range Counter</h1>
            <div class="col-12 text-center">
                <input type="text" placeholder="Enter From Value" class="w-50 mt-3 pl-2" id="fromUserInput" />
                <input type="text" placeholder="Enter To Value" class="w-50 mt-3 pl-2" id="toUserInput" />
                <br />
                <button class="btn btn-primary mt-4" id="startBtn" onclick="onClickStart()">
                    Start
                </button>
                <p class="counter mt-4" id="counterText"></p>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.heading {
    color: #3e4c59;
    font-family: "Bree Serif";
    font-size: 24px;
}

.counter {
    font-size: 32px;
}

JS:

let fromUserInputEl = document.getElementById('fromUserInput');
let toUserInputEl = document.getElementById('toUserInput');
let counterTextEl = document.getElementById('counterText');

function displayNumbers(fromcount, tocount) {
    let currentCount = fromcount;
    counterTextEl.textContent = currentCount;

    let timerId = setInterval(function() {
        if (currentCount < tocount) {
            currentCount += 1;
            counterTextEl.textContent = currentCount;
        } else {
            clearInterval(timerId);
        }
    }, 1000);
}

function onClickStart() {

    let fromVal = fromUserInputEl.value;
    let toVal = toUserInputEl.value;

    if (fromVal === '') {
        alert('Enter the from value');
    } else if (toVal === '') {
        alert('Enter the to value');
    } else {
        let fromValInteger = parseInt(fromVal);
        let toValInteger = parseInt(toVal);

        displayNumbers(fromValInteger, toValInteger);
    }

}

Peace timer:
------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container d-flex flex-column justify-content-center">
        <div class="container peace-page-container">
            <div class="row text-center pt-3">
                <h1 class="col-12 peace-page-heading">A Moment of Peace</h1>
                <p class="col-12 peace-page-description">
                    Turn off your phone, put on your headphones and take a moment for
                    yourself.
                </p>
                <hr class="col-10" />
                <h1 class="col-12 heading">
                    How long would you like your moment to be?
                </h1>
                <ul class="col-12 buttons-list-container d-flex flex-row justify-content-center">
                    <li><button class="button" id="twentySecondsBtn">20 Seconds</button></li>
                    <li><button class="button" id="thirtySecondsBtn">30 Seconds</button></li>
                    <li><button class="button" id="fortySecondsBtn">40 Seconds</button></li>
                    <li><button class="button" id="oneMinuteBtn">1 Minute</button></li>
                </ul>
                <p class="col-12 text-center" id="timerText"></p>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background: linear-gradient(#189ffd, #29f39c);
    height: 100vh;
}

.peace-page-container {
    background-color: #ffffff;
    border-radius: 12px;
}

.peace-page-heading {
    color: #323f4b;
    font-family: "Roboto";
    font-size: 32px;
}

.peace-page-description {
    color: #616e7c;
    font-family: "Roboto";
}

.heading {
    color: #323f4b;
    font-family: "Bree Serif";
    font-size: 28px;
}

.buttons-list-container {
    margin-top: 10px;
    list-style-type: none;
}

.button {
    font-family: "Roboto";
    font-size: 15px;
    background-color: #05a8f2;
    color: white;
    border-width: 0;
    border-radius: 8px;
    width: 70px;
    height: 75px;
    margin: 5px;
}

JS:

let twentySecondsBtnEl = document.getElementById('twentySecondsBtn')
let thirtySecondsBtnEl = document.getElementById('thirtySecondsBtn')
let fortySecondsBtnEl = document.getElementById('fortySecondsBtn')
let oneMinuteBtnEl = document.getElementById('oneMinuteBtn')
let timerTextEl = document.getElementById('timerText')

let secondsLeft = 0;
let timeCompletedText = "Your moment is complete";
let timerId;

function clearPreviousTimers() {
    clearInterval(timerId);
}

function setTimerAndShow() {
    timerTextEl.textContent = secondsLeft + " seconds left";
    timerId = setInterval(startTimer, 1000);
}

twentySecondsBtnEl.onclick = function() {
    secondsLeft = 20;
    clearPreviousTimers();
    setTimerAndShow();

};

thirtySecondsBtnEl.onclick = function() {
    secondsLeft = 30;
    clearPreviousTimers();
    setTimerAndShow();

};

fortySecondsBtnEl.onclick = function() {
    secondsLeft = 40;
    clearPreviousTimers();
    setTimerAndShow();

};

oneMinuteBtnEl.onclick = function() {
    secondsLeft = 60;
    clearPreviousTimers();
    setTimerAndShow();

};

function startTimer() {
    if (secondsLeft > 1) {
        secondsLeft = secondsLeft - 1;
        timerTextEl.textContent = secondsLeft + 'seconds left';
    } else {
        clearPreviousTimers();
        timerTextEl.textContent = timeCompletedText;
    }
}

coding practice-15:
--------------------------------

Theme Switcher:
------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container d-flex flex-column justify-content-center text-center" id="bgContainer">
        <h1 class="heading" id="heading">Dark or Light</h1>
        <div class="mt-3">
            <input type="text" class="user-input pl-2" id="themeUserInput" />
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-image: url("https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-light-bg.png");
    height: 100vh;
    background-size: cover;
}

.heading {
    color: #014d40;
    font-size: 48px;
    font-family: "Lobster";
}

.user-input {
    width: 150px;
}

JS:

let bgContainerEl = document.getElementById("bgContainer");
let themeUserInputEl = document.getElementById("themeUserInput");
let headingEl = document.getElementById("heading");

let darkImage = "url('https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-dark-bg.png')";
let lightImage = "url('https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/change-theme-light-bg.png')";

function changeTheme(event) {
    if (event.key === "Enter") {
        let themeUserInputValue = themeUserInputEl.value;

    if (themeUserInputValue === "Dark") {
        bgContainerEl.style.backgroundImage = darkImage;
        bgContainerEl.style.color = "#fffff";
    } else if (themeUserInputValue === "Light") {
        bgContainerEl.style.backgroundImage = lightImage;
        bgContainerEl.style.color = "#014d40";
    } else {
        alert("Enter the valid theme");
    }
}

}
themeUserInputEl.addEventListener("keydown", changeTheme);

Key code practice:
-----------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="p-5">
        <h1 class="heading mb-3">Enter Keys to display the Key codes</h1>
        <input type="text" placeholder="Enter the keys" class="pl-1" id="userInput" />
        <p class="mt-3">KeyCodes: </p>
        <ul class="key-code-list mt-3" id="keyCodeList"></ul>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Monoton&family=Open+Sans:wght@400;700&family=Playfair+Display+SC:wght@400;700&family=Playfair+Display:wght@400;700&family=Roboto:wght@400;700&family=Source+Sans+Pro:wght@400;700&family=Work+Sans:wght@400;700&display=swap");

.heading {
    color: #3e4c59;
    font-family: "Bree Serif";
    font-size: 28px;
}

.key-code-list {
    list-style-type: none;
}

JS:

let userInputEl = document.getElementById("userInput");
let keyCodeListEl = document.getElementById("keyCodeList");

function createAndAppendKeyCode(keyCode) {
    let listItemEl = document.createElement("li");
    listItemEl.classList.add("mt-1");
    listItemEl.textContent = keyCode;
    keyCodeListEl.appendChild(listItemEl);


}

function onKeydown(event) {
    createAndAppendKeyCode(event.keyCode);
}

userInputEl.addEventListener("keydown", onKeydown);

coding Assignment-1:
------------------------------

Time converter:
--------------------------

HTML:
<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container p-4">
        <h1 class="main-heading">Time Converter</h1>
        <p class="main-para">Enter hours and minutes values to convert into seconds</p>
        <div class="mb-3">
            <label for="hoursInput" class="input-label">Hours *</label>
            <input type="text" class="form-control" id="hoursInput" />
        </div>
        <div class="mb-3">
            <label for="minutesInput" class="input-label">Minutes *</label>
            <input type="text" class="form-control" id="minutesInput" />
        </div>
        <div>
            <button class="btn btn-secondary" id="convertBtn">Convert to Seconds</button>
        </div>
        <div class="mt-4 ">
            <p id="TimeInSeconds" class="sec-convert-para"></p>
            <p id="errorMsg" class="error-msg"></p>
        </div>
        <div class="">
            <p id="timeInSeconds" class=""></p>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-image: url('https://assets.ccbp.in/frontend/dynamic-webapps/time-converter-bg.png');
    height: 100vh;
}

.main-heading {
    color: #ffffff;
    font-family: "Open Sans";
    font-size: 30px;
    font-weight: 600;
}

.main-para {
    color: #ffffff;
    font-family: "Open Sans";
    font-size: 18px;
    font-weight: 300;
}

.input-label {
    color: #ffffff;
    font-family: "Open Sans";
    font-size: 12px;
    font-weight: bold;
}

.error-msg {
    color: #f5f7fa;
    font-family: "Open Sans";
    font-size: 10px;
    font-weight: 200;
}

.sec-convert-para {
    color: #ffffff;
    font-size: 18px;
    font-weight: bold;
}

.button {
    color: #000000;
    border-radius: 5px;
    height: 40px;

}

.result {
    font-family: "Roboto";
    font-size: 22px;
    font-weight: 500;
    color: #ffffff;
    border-style: solid;
    background-color: transparent;
    border-radius: 5px;
    padding: 5px;
    width: 140px;
    border-color: #f5f7fa;
    border-width: 1px;
}

JS:

let convertBtnEl = document.getElementById("convertBtn");
let timeInSecondsEl = document.getElementById("timeInSeconds");


convertBtnEl.addEventListener("click", function getSeconds() {
    let hoursInputEl = parseInt(document.getElementById("hoursInput").value);
    let minutesInputEl = parseInt(document.getElementById("minutesInput").value);
    let seconds = ((hoursInputEl) * 60 + minutesInputEl) * 60;

    let errMsgEl = document.getElementById("errorMsg");
    let showSeconds = document.getElementById("timeInSeconds");

    if (isNaN(hoursInputEl) || isNaN(minutesInputEl)) {
        errMsgEl.textContent = "please enter any value";
        showSeconds.textContent = '';
        errMsgEl.style.color = "#f7faf5";
        timeInSecondsEl.classList.remove("result");
    } else {

        errMsgEl.textContent = '';
        showSeconds.textContent = seconds;
        showSeconds.style.color = "#ffffff";
        timeInSecondsEl.classList.add("result");
        timeInSecondsEl.textContent = seconds + "S";

    }
});

HTTP Requests using JS | Cheat Sheet:
-------------------------------------------------------

You can get the ACCESS_TOKEN from this website.

Follow below steps for getting ACCESS_TOKEN:


You can get your unique access token by logging in to https://gorest.co.in/.

1. Fetch:
The fetch() method is used to fetch resources across the Internet.

Syntax: fetch(URL, OPTIONS)

URL - URL of the resource
OPTIONS - Request Configuration

1.1 Request Configuration:
We can configure the fetch request with many options like,

Request Method
Headers
Body
Credentials
Cache, etc.
We can configure a request by passing an options object with required properties and their values.

For example,

JS:

let options = {
  method: "GET",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify(data)
};

2. Making HTTP Requests using Fetch
The method property value in the options object can be GET, POST, PUT, DELETE, etc. The default method is GET.

2.1 GET
The GET method can be used to retrieve (get) data from a specified resource.

For example,

JS:

let options = {
  method: "GET"
};

fetch("https://gorest.co.in/public-api/users", options);

2.2 POST
The POST method can be used to send data to the server.

JS:

let data = {
  name: "Rahul",
  gender: "Male",
  email: "rahul@gmail.com",
  status: "Active"
};

let options = {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
    Authorization: "Bearer ACCESS-TOKEN"
  },
  body: JSON.stringify(data)
};

fetch("https://gorest.co.in/public-api/users", options)
  .then(function(response) {
    return response.json();
  })
  .then(function(jsonData) {
    console.log(jsonData);
  });
  
Output:
  
Object {code: 401, meta: null, data: Object}
code: 401
meta: null
data: Object


2.3 PUT
The PUT method can be used to update the existing resource.

JS:

let data = {
  name: "Rahul Attuluri"
};

let options = {
  method: "PUT",
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
    Authorization: "Bearer ACCESS-TOKEN"
  },
  body: JSON.stringify(data)
};

fetch("https://gorest.co.in/public-api/users/1359", options)
  .then(function(response) {
    return response.json();
  })
  .then(function(jsonData) {
    console.log(jsonData);
  });
  
Output:

Object {code: 401, meta: null, data: Object}
code: 401
meta: null
data: Object

2.4 DELETE
The DELETE method can be used to delete the specified resource.

let options = {
  method: "DELETE",
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
    Authorization: "Bearer ACCESS-TOKEN"
  }
};

fetch("https://gorest.co.in/public-api/users/1359", options)
  .then(function(response) {
    return response.json();
  })
  .then(function(jsonData) {
    console.log(jsonData);
  });
  
Try out the different HTTP Request Methods and check the output in the below Code Playground console.

JS:

let data = {
  name: "Rahul",
  gender: "Male",
  email: "rahul@gmail.com",
  status: "Active"
};

let options = {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
    Authorization: "Bearer 5b8faa3592569928a8aa07468fac524e3255d48825a42c698da9b7eb99ef1415"
  },
  body: JSON.stringify(data)
};

fetch("https://gorest.co.in/public-api/users", options)
  .then(function(response) {
    return response.json();
  })
  .then(function(jsonData) {
    console.log(jsonData);
  });
  
Output:

bject {code: 422, meta: null, data: Array[1]}
code: 422
meta: null
data: Array[1]
0: Object


3. HTTP Response Object Properties and Methods
Response Object provides multiple properties to give more information about the HTTP Response.

status (number) - HTTP status code
statusText (string) - Status text as reported by the server, e.g. "Unauthorized"
headers
url
text() - Getting text from response
json() - Parses the response as JSON

For example,

let options = {
  method: "GET"
};

fetch("https://gorest.co.in/public-api/users", options)
  .then(function(response) {
    return response.status;
  })
  .then(function(status) {
    console.log(status);  // 200
  });


Wikipedia Search Application | Cheat Sheet:
-------------------------------------------------------

1. HTML Input Element
1.1 Search
The HTML input element with the type search is designed for the user to enter the search queries.

<input type="search" />

2. Bootstrap Components
2.1 Spinner
The Spinners can be used to show the loading state of the page.

<div class="spinner-border" role="status">
  <span class="sr-only">Loading...</span>
</div>

3. Wikipedia Search Application

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="main-container">
      <div class="wiki-search-header text-center">
        <img class="wiki-logo" src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/wiki-logo-img.png" />
        <br />
        <input placeholder="Type a keyword and press Enter to search" type="search" class="search-input w-100" id="searchInput" />
      </div>
      <div class="d-none" id="spinner">
        <div class="d-flex justify-content-center">
          <div class="spinner-border" role="status">
            <span class="sr-only">Loading...</span>
          </div>
        </div>
      </div>
      <div class="search-results" id="searchResults"></div>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.main-container {
  font-family: "Roboto";
}

.wiki-search-header {
  border-style: solid;
  border-width: 1px;
  border-color: #d5cdcd;
  padding-top: 30px;
  padding-right: 20px;
  padding-bottom: 30px;
  padding-left: 20px;
  margin-bottom: 40px;
}

.wiki-logo {
  margin-bottom: 30px;
  width: 150px;
}

.search-input {
  font-size: 18px;
  border-style: solid;
  border-width: 1px;
  border-color: #d5cdcd;
  border-radius: 3px;
  padding: 10px;
}

.search-results {
  width: 100%;
  padding-left: 20px;
}

.result-item {
  margin-bottom: 20px;
}

.result-title {
  font-size: 22px;
}

.link-description {
  color: #444444;
  font-size: 15px;
}

.result-url {
  color: #006621;
  text-decoration: none;
}

JS:

let searchInputEl = document.getElementById("searchInput");

let searchResultsEl = document.getElementById("searchResults");

let spinnerEl = document.getElementById("spinner");

function createAndAppendSearchResult(result) {
  let { link, title, description } = result;

  let resultItemEl = document.createElement("div");
  resultItemEl.classList.add("result-item");

  let titleEl = document.createElement("a");
  titleEl.href = link;
  titleEl.target = "_blank";
  titleEl.textContent = title;
  titleEl.classList.add("result-title");
  resultItemEl.appendChild(titleEl);

  let titleBreakEl = document.createElement("br");
  resultItemEl.appendChild(titleBreakEl);

  let urlEl = document.createElement("a");
  urlEl.classList.add("result-url");
  urlEl.href = link;
  urlEl.target = "_blank";
  urlEl.textContent = link;
  resultItemEl.appendChild(urlEl);

  let linkBreakEl = document.createElement("br");
  resultItemEl.appendChild(linkBreakEl);

  let descriptionEl = document.createElement("p");
  descriptionEl.classList.add("link-description");
  descriptionEl.textContent = description;
  resultItemEl.appendChild(descriptionEl);

  searchResultsEl.appendChild(resultItemEl);
}

function displayResults(searchResults) {
  spinnerEl.classList.add("d-none");

  for (let result of searchResults) {
    createAndAppendSearchResult(result);
  }
}

function searchWikipedia(event) {
  if (event.key === "Enter") {

    spinnerEl.classList.remove("d-none");
    searchResultsEl.textContent = "";

    let searchInput = searchInputEl.value;
    let url = "https://apis.ccbp.in/wiki-search?search=" + searchInput;
    let options = {
      method: "GET"
    };

    fetch(url, options)
      .then(function (response) {
        return response.json();
      })
      .then(function (jsonData) {
        let { search_results } = jsonData;
        displayResults(search_results);
      });
  }
}

searchInputEl.addEventListener("keydown", searchWikipedia);

coding pratice-16:
------------------------------------

HTTP Get Method Practice Page:
----------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="p-3 bg-container">
        <h1 class="heading mb-4">Get method practice</h1>
        <p class="request-url-text">REQUEST URL: <span class="request-url">https://gorest.co.in/public-api/users</span></p>
        <button class="mt-3 p-2 button" id="sendGetRequestBtn" >Send Get Request</button>
        <hr />
        <div class="p-2 mt-4">
            <p>Request Status</p>
            <p class="request-status" id="requestStatus"></p>
            <p class="d-none" id="loading">Loading....</p>
        </div>
        <hr />
        <div class="p-2 mt-4">
            <p>Response Body</p>
            <p class="http-response" id="httpResponse"></p>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-image: linear-gradient(to right, #4188da, #2be3c6);
}

.heading {
    color: #ffffff;
    font-weight: bold;
    font-size: 32px;
}

.request-url-text {
    color: #ffffff;
    font-weight: bold;
}

.request-url {
    font-weight: 300;
}

.button {
    color: #ffffff;
    background-color: #0967d2;
    font-size: 14px;
    border-width: 0;
    border-radius: 4px;
}

.request-status {
    color: #ffffff;
    font-family: "Roboto";
    font-size: 24px;
}

.http-response {
    color: #ffffff;
    font-family: "Roboto";
    font-size: 14px;
}

JS:

let sendGetRequestBtnEl = document.getElementById("sendGetRequestBtn");
let loadingEl = document.getElementById("loading");
let requestStatusEl = document.getElementById("requestStatus");
let httpResponseEl = document.getElementById("httpResponse");

function sendGetHTTPRequest() {
    let url = "https://gorest.co.in/public-api/users";
    let options = {
        method: "GET",
    };

    loadingEl.classList.remove("d-none");
    requestStatusEl.classList.add("d-none");
    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            requestStatusEl.classList.remove("d-none");
            loadingEl.classList.add("d-none");

            let requestStatus = data.code;
            let httpResponse = JSON.stringify(data);
            requestStatusEl.textContent = requestStatus;
            httpResponseEl.textContent = httpResponse;
        });
}
sendGetRequestBtnEl.addEventListener("click", sendGetHTTPRequest);

HTTP Post Method Practice Page:
------------------------------------------------

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="p-3 bg-container">
        <h1 class="heading mb-4">Post method practice</h1>
        <p class="request-url-text">REQUEST URL: <span class="request-url">https://gorest.co.in/public-api/users</span></p>
        <textarea placeholder="Enter Request Body" rows="5" class="w-100 p-2 request-body" id="requestBody"></textarea>
        <button class="mt-3 p-2 button" id="sendPostRequestBtn">Send Post Request</button>
        <hr />
        <div class="p-2 mt-4">
            <p>Request Status</p>
            <p class="request-status" id="requestStatus"></p>
            <p class="d-none" id="loading">Loading....</p>
        </div>
        <hr />
        <div class="p-2 mt-4">
            <p>Response Body</p>
            <p class="http-response" id="httpResponse"></p>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-image: linear-gradient(to right, #1cc8ef, #4fa5b2);
}

.heading {
    color: #ffffff;
    font-weight: bold;
    font-size: 32px;
}

.request-url-text {
    color: #ffffff;
    font-weight: bold;
}

.request-url {
    font-weight: 300;
}

.request-body {
    background-color: #ffffff;
    border-radius: 4px;
}

.button {
    color: #ffffff;
    background-color: #0552b5;
    font-size: 14px;
    border-width: 0;
    border-radius: 4px;
}

.request-status {
    color: #ffffff;
    font-family: "Roboto";
    font-size: 24px;
}

.http-response {
    color: #ffffff;
    font-family: "Roboto";
    font-size: 14px;
}

JS:

let requestBodyEl = document.getElementById("requestBody");
let sendPostRequestBtnEl = document.getElementById("sendPostRequestBtn");
let loadingEl = document.getElementById("loading");
let requestStatusEl = document.getElementById("requestStatus");
let httpResponseEl = document.getElementById("httpResponse");

function sendPostHTTPRequest() {
    let requestUrl = "https://gorest.co.in/public-api/users";
    let requestBody = requestBodyEl.value;
    let options = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 5b8faa3592569928a8aa07468fac524e3255d48825a42c698da9b7eb99ef1415"
        },
        body: requestBody
    };

    loadingEl.classList.remove("d-none");
    requestStatusEl.classList.add("d-none");
    fetch(requestUrl, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            requestStatusEl.classList.remove("d-none");
            loadingEl.classList.add("d-none");

            let requestStatus = data.code;
            let httpResponse = JSON.stringify(data);
            requestStatusEl.textContent = requestStatus;
            httpResponseEl.textContent = httpResponse;
        });
}
sendPostRequestBtnEl.addEventListener("click", sendPostHTTPRequest);

Textarea Body: 

{
 "name":"Sam",
 "gender":"Male",
 "status":"Active",
 "email":"abc@xyz.com"
}

Request Status

201

Response Body

{"code":201,"meta":null,"data":{"id":4274,"name":"Sam","email":"abc@xyz.com","gender":"male","status":"active"}}

HTTP Put Method Practice Page:
----------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="p-3 bg-container">
        <h1 class="heading mb-4">Put method practice</h1>
        <p class="request-url-text">REQUEST URL: <span class="request-url">https://gorest.co.in/public-api/users</span></p>
        <input placeholder="Enter id" class="w-75 p-1 user-input" id="userInput" />
        <textarea placeholder="Enter Request Body" rows="5" class="w-100 mt-4 p-2 request-body" id="requestBody"></textarea>
        <button class="mt-3 p-2 button" id="sendPutRequestBtn">Send Put Request</button>
        <hr />
        <div class="request-status-container p-2 mt-4">
            <p>Request Status</p>
            <p class="request-status" id="requestStatus"></p>
            <p class="d-none" id="loading">Loading....</p>
        </div>
        <hr />
        <div class="response-body-container p-2 mt-4">
            <p>Response Body</p>
            <p class="http-response" id="httpResponse"></p>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-image: linear-gradient(to right, #7275bf, #358ac7);
}

.heading {
    color: #ffffff;
    font-weight: bold;
    font-size: 32px;
}

.request-url-text {
    color: #ffffff;
    font-weight: bold;
}

.request-url {
    font-weight: 300;
}

.user-input {
    background-color: #ffffff;
    border-width: 1px;
    border-style: solid;
    border-color: #ffffff;
}

.request-body {
    background-color: #ffffff;
    border-radius: 4px;
    border-width: 1px;
    border-style: solid;
    border-color: #ffffff;
}

.button {
    color: white;
    background-color: #0967d2;
    font-size: 14px;
    border-width: 0;
    border-radius: 4px;
}

.request-status-container {
    color: #ffffff;
}

.request-status {
    font-family: "Roboto";
    font-size: 24px;
}

.response-body-container {
    color: #ffffff;
}

.http-response {
    font-family: "Roboto";
    font-size: 14px;
}

JS:

let userInputEl = document.getElementById("userInput");
let requestBodyEl = document.getElementById("requestBody");
let sendPutRequestBtnEl = document.getElementById("sendPutRequestBtn");
let loadingEl = document.getElementById("loading");
let requestStatusEl = document.getElementById("requestStatus");
let httpResponseEl = document.getElementById("httpResponse");

function sendPutHTTPRequest() {
    let userId = userInputEl.value;
    let requestUrl = "https://gorest.co.in/public-api/users/" + userId;
    let requestBody = requestBodyEl.value;
    let options = {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 5b8faa3592569928a8aa07468fac524e3255d48825a42c698da9b7eb99ef1415"
        },
        body: requestBody
    };

    loadingEl.classList.remove("d-none");
    requestStatusEl.classList.add("d-none");
    fetch(requestUrl, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            requestStatusEl.classList.remove("d-none");
            loadingEl.classList.add("d-none");

            let requestStatus = data.code;
            let httpResponse = JSON.stringify(data);
            requestStatusEl.textContent = requestStatus;
            httpResponseEl.textContent = httpResponse;
        });
}
sendPutRequestBtnEl.addEventListener("click", sendPutHTTPRequest);

ID:

4178

Body:

{
	"name":"Girindra "
}

Request Status

200

Response Body

{"code":200,"meta":null,"data":{"name":"Girindra ","id":4178,"email":"girindra_kocchar@bartoletti-kuvalis.net","gender":"male","status":"active"}}

HTTP Delete Method Practice Page:
----------------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="p-3 bg-container">
        <h1 class="heading mb-4">Delete method practice</h1>
        <p class="request-url-text">REQUEST URL: <span class="request-url">https://gorest.co.in/public-api/users</span></p>
        <input placeholder="Enter id" class="w-75 user-input p-1"  id="userInput"/>
        <br />
        <button class="mt-3 p-2 button"  id="sendDeleteRequestBtn">Send Delete Request</button>
        <div class="request-status-container p-2 mt-4">
            <p>Request Status</p>
            <p class="request-status" id="requestStatus"></p>
            <p class="d-none" id="loading">Loading....</p>
        </div>
        <div class="response-body-container p-2 mt-4">
            <p>Response Body</p>
            <p class="http-response" id="httpResponse"></p>
        </div>
    </div>
</body>

</html>

JS:

let userInputEl = document.getElementById("userInput");
let sendDeleteRequestBtnEl = document.getElementById("sendDeleteRequestBtn");
let loadingEl = document.getElementById("loading");
let requestStatusEl = document.getElementById("requestStatus");
let httpResponseEl = document.getElementById("httpResponse");

function sendDeleteHTTPRequest() {
    let userId = userInputEl.value;
    let requestUrl = "https://gorest.co.in/public-api/users/" + userId;
    let options = {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 5b8faa3592569928a8aa07468fac524e3255d48825a42c698da9b7eb99ef1415"
        },
    };

    loadingEl.classList.remove("d-none");
    requestStatusEl.classList.add("d-none");
    fetch(requestUrl, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            requestStatusEl.classList.remove("d-none");
            loadingEl.classList.add("d-none");

            let requestStatus = data.code;
            let httpResponse = JSON.stringify(data);
            requestStatusEl.textContent = requestStatus;
            httpResponseEl.textContent = httpResponse;
        });
}
sendDeleteRequestBtnEl.addEventListener("click", sendDeleteHTTPRequest);


Delete method practice
REQUEST URL: https://gorest.co.in/public-api/users

4158

Send Delete Request

Request Status

204

Response Body

{"code":204,"meta":null,"data":null}


coding practice-17:
-------------------------------------

Random Joke Page:
---------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container p-3 d-flex flex-column justify-content-center text-center">
        <img src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/random-joke-img.png" class="w-25 ml-auto mr-auto" />
        <p class="joke-text mt-4" id="jokeText">Click the button below to get a random Joke!</p>
        <div class="d-none mt-5 mb-5" id="spinner">
            <div class="d-flex flex-row justify-content-center">
                <div class="spinner-border" role="status">
                </div>
            </div>
        </div>
        <button class="joke-button p-1 ml-auto mr-auto mt-3" id="jokeBtn">Joke</button>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-image: linear-gradient(to right, #49c4ee, #6e87d6);
    height: 100vh;
}

.joke-text {
    color: #ffffff;
    font-size: 24px;
    font-weight: 700;
}

.joke-button {
    color: #6c8bd8;
    background-color: #ffffff;
    font-size: 24px;
    width: 120px;
    border-width: 0;
    border-radius: 4px;
}

JS:

let jokeTextEl = document.getElementById("jokeText");
let spinnerEl = document.getElementById("spinner");
let jokeBtnEl = document.getElementById("jokeBtn");

let options = {
        method: "GET",
};

function getRandomJoke() {
    spinnerEl.classList.remove("d-none");
    jokeTextEl.classList.add("d-none");


fetch("https://apis.ccbp.in/jokes/random", options)
  .then(function(response) {
      return response.json();
  })
  .then(function(Data) {
      let randomJoke  = Data.value;
      
       spinnerEl.classList.add("d-none");
       jokeTextEl.classList.remove("d-none");
       
       jokeTextEl.textContent = randomJoke;
       
    });
}

jokeBtnEl.addEventListener("click", getRandomJoke);


Forms | Cheat Sheet:
-------------------------------
1. HTML Forms:
The HTML Forms can be used to collect data from the user.

Forms are of different kinds:

Login/Sign in Form
Registration Form
Contact Us Form, etc.

1.1 HTML Form Element:
The HTML form element can be used to create HTML forms. 
It is a container that can contain different types of Input elements like Text Fields, Checkboxes, etc.

HTML:

<form></form>

Note:

Whenever we click a button or press Enter key while editing any input field in the form, the submit event will be triggered.

2. Event Object Methods:

2.1 preventDefault
The preventDefault() method prevents the occurrence of default action.

Here in the form, it prevents the default behaviour of the submit event.

JS:

let myFormEl = document.getElementById("myForm");

myFormEl.addEventListener("submit", function(event) {
  event.preventDefault();
});

3. Event Types
There are different types of events.

Keyboard Events
Mouse Events
Touch Events
Form Events, etc.

3.1 Form Events
A Form Event is an event that can occur within a form.

Some of the form events are:

blur
focus
change, etc.

3.1.1 Blur Event
The blur event happens when an HTML element has lost focus.

JS:

let nameEl = document.getElementById("name");

nameEl.addEventListener("blur", function(event) {
  console.log("blur event triggered");
});

Try out the preventDefault method and blur event in the below Code Playground.

Add user-1:

HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="container">
      <h1 class="form-heading">Add User</h1>
      <form id="myForm">
        <div class="mb-3">
          <label for="name">Name</label>
          <input type="text" class="form-control" id="name" />
          <p id="nameErrMsg" class="error-message"></p>
        </div>
        <div class="mb-3">
          <label for="email">Email</label>
          <input type="text" class="form-control" id="email" />
          <p id="emailErrMsg" class="error-message"></p>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.form-heading {
  font-family: "Roboto";
  font-size: 36px;
  padding-top: 40px;
  padding-bottom: 20px;
}

.error-message {
  color: #dc3545;
  font-family: "Roboto";
  font-size: 14px;
}

JS:

let myFormEl = document.getElementById("myForm");

let nameEl = document.getElementById("name");
let nameErrMsgEl = document.getElementById("nameErrMsg");

let emailEl = document.getElementById("email");
let emailErrMsgEl = document.getElementById("emailErrMsg");

nameEl.addEventListener("blur", function(event) {
  if (event.target.value === "") {
    nameErrMsgEl.textContent = "Required*";
  } else {
    nameErrMsgEl.textContent = "";
  }
});

emailEl.addEventListener("blur", function(event) {
  if (event.target.value === "") {
    emailErrMsgEl.textContent = "Required*";
  } else {
    emailErrMsgEl.textContent = "";
  }
});

myFormEl.addEventListener("submit", function(event) {
  event.preventDefault();
});

Forms | Part-2 | Cheat Sheet:
-----------------------------------------

1. HTML Select Element:
The HTML select element is used to create a drop-down list.

HTML:

<select></select>

1.1 HTML Option Element:
The HTML option element is used to create the menu option of a drop-down list.

The text content of the HTML option element is used as a label.

HTML:

<select>
  <option>Active</option>
</select>

1.1.1 The value Attribute
Every HTML option element should contain the HTML value attribute.

<option value="Active">Active</option>

2. HTML Input Element:

2.1 Radio
The HTML input radio element is used to select one option among a list of given options.

HTML:

<input type="radio" id="genderMale" value="Male" />
<input type="radio" id="genderFemale" value="Female" />

2.1.1 HTML name attribute
The HTML name Attribute specifies the name for an HTML Element.

HTML:

<input type="radio" value="Male" name="gender" />

2.1.2 Radio Group
All the radio buttons with same name collectively called as a radio group.

We can select only one radio button within a radio group.

HTML:

<input type="radio" value="Male" name="gender" />
<input type="radio" value="Female" name="gender" />

3. Boolean Attributes
For the HTML Boolean attributes, we only specify the name of the HTML attribute.

The presence of a boolean attribute represents the true value, and the absence represents the false value.

3.1 HTML selected attribute
The selected attribute specifies that an option should be pre-selected when the page loads.

<option value="Active" selected>Active</option>

3.2 HTML checked attribute
The checked attribute specifies that an input element should be pre-selected (checked) when the page loads.

<input type="radio" id="genderMale" value="Male" name="gender" checked />

Try out the HTML select element, input radio element and the boolean attributes in the below Code Playground.

Add user-2:


HTML:

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="container">
      <h1 class="form-heading">Add User</h1>
      <form id="myForm">
        <div class="mb-3">
          <label for="name">Name</label>
          <input type="text" class="form-control" id="name" />
          <p id="nameErrMsg" class="error-message"></p>
        </div>
        <div class="mb-3">
          <label for="email">Email</label>
          <input type="text" class="form-control" id="email" />
          <p id="emailErrMsg" class="error-message"></p>
        </div>
        <div class="mb-3">
          <label for="status">Working Status</label>
          <select id="status" class="form-control">
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
        <div class="mb-3">
          <h1 class="gender-field-heading">Gender</h1>
          <input type="radio" name="gender" id="genderMale" value="Male" checked />
          <label for="genderMale">Male</label>
          <input type="radio" name="gender" id="genderFemale" value="Female" class="ml-2"/>
          <label for="genderFemale">Female</label>
        </div>
        <button class="btn btn-primary">Submit</button>
      </form>
    </div>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.form-heading {
  font-family: "Roboto";
  font-size: 36px;
  padding-top: 40px;
  padding-bottom: 20px;
}

.error-message {
  color: #dc3545;
  font-family: "Roboto";
  font-size: 14px;
}

.gender-field-heading {
  color: #212529;
  font-size: 18px;
  margin-bottom: 10px;
}

JS:

let nameEl = document.getElementById("name");
let nameErrMsgEl = document.getElementById("nameErrMsg");

let emailEl = document.getElementById("email");
let emailErrMsgEl = document.getElementById("emailErrMsg");

let workingStatusEl = document.getElementById("status");
let genderMaleEl = document.getElementById("genderMale");
let genderFemaleEl = document.getElementById("genderFemale");

let myFormEl = document.getElementById("myForm");

let formData = {
  name: "",
  email: "",
  status: "Active",
  gender: "Male"
};

nameEl.addEventListener("change", function(event) {
  if (event.target.value === "") {
    nameErrMsgEl.textContent = "Required*";
  } else {
    nameErrMsgEl.textContent = "";
  }

  formData.name = event.target.value;
});

emailEl.addEventListener("change", function(event) {
  if (event.target.value === "") {
    emailErrMsgEl.textContent = "Required*";
  } else {
    emailErrMsgEl.textContent = "";
  }

  formData.email = event.target.value;
});

workingStatusEl.addEventListener("change", function(event) {
  formData.status = event.target.value;
});

genderMaleEl.addEventListener("change", function(event) {
  formData.gender = event.target.value;
});

genderFemaleEl.addEventListener("change", function(event) {
  formData.gender = event.target.value;
});

function validateFormData(formData) {
  let {name, email} = formData;
  if (name === "") {
    nameErrMsgEl.textContent = "Required*";
  }
  if (email === ""){
    emailErrMsgEl.textContent = "Required*";
  }
}

function submitFormData(formData) {
  let options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization:
        "Bearer 00f3f8fde06120db02b587cc372c3d85510896e899b45774068bb750462acd9f",
    },
    body: JSON.stringify(formData)
  };

  let url = "https://gorest.co.in/public-api/users";

  fetch(url, options)
    .then(function(response) {
      return response.json();
    })
    .then(function(jsonData) {
      console.log(jsonData);
      if (jsonData.code === 422) {
        if (jsonData.data[0].message === "has already been taken") {
          emailErrMsgEl.textContent = "Email Already Exists";
        }
      }
    });
}

myFormEl.addEventListener("submit", function(event){
  event.preventDefault();
  validateFormData(formData);
  submitFormData(formData);
});

coding practice-18:
----------------------------------

Countries Search Page:
---------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container pt-5">
        <div class="row">
            <h1 class="col-12 heading text-center">Find the Countries Population</h1>
            <div class="col-12 text-center mt-3">
                <input type="search" placeholder="Search for a Country" class="form-control search-input" id="searchInput" />
            </div>
            <div class="col-12 d-none mt-5" id="spinner">
                <div class="d-flex flex-row justify-content-center">
                    <div class="spinner-border" role="status"></div>
                </div>
            </div>
        </div>
        <div class="row result-countries" id="resultCountries"></div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.heading {
    color: #3e4c59;
    font-size: 28px;
    font-weight: bold;
}

.search-input {
    height: 50px;
}

.result-countries {
    margin-top: 18px;
}

.country-card {
    background-color: #ebf2fc;
    border-radius: 24px;
    margin-top: 15px;
    margin-bottom: 15px;
    padding: 15px;
}

.country-flag {
    width: 70px;
    height: 70px;
}

.country-name {
    color: #183b56;
    font-family: "Roboto";
    font-size: 22px;
    font-weight: bold;
    margin-bottom: 8px;
}

.country-population {
    font-family: "Roboto";
    font-size: 14px;
    font-weight: 300;
}

JS:

let searchInputEl = document.getElementById("searchInput");
let resultCountriesEl = document.getElementById("resultCountries");
let spinnerEl = document.getElementById("spinner");

let searchInputVal = "";
let countriesList = [];

function createAndAppendCountry(country) {
    // Creating and appending countryEl to the resultCountriesEl
    let countryEl = document.createElement("div");
    countryEl.classList.add("country-card", "col-11", "col-md-5", "mr-auto", "ml-auto", "d-flex", "flex-row");
    resultCountriesEl.appendChild(countryEl);

    // Creating and appending countryFlagEl to the countryEl
    let countryFlagEl = document.createElement("img");
    countryFlagEl.src = country.flag;
    countryFlagEl.classList.add("country-flag", "mt-auto", "mb-auto");
    countryEl.appendChild(countryFlagEl);

    // Creating and appending countryInfoEl to the countryEl
    let countryInfoEl = document.createElement("div");
    countryInfoEl.classList.add("d-flex", "flex-column", "ml-4");
    countryEl.appendChild(countryInfoEl);

    // Creating and appending countryNameEl to the countryInfoEl
    let countryNameEl = document.createElement("p");
    countryNameEl.textContent = country.name;
    countryNameEl.classList.add("country-name");
    countryInfoEl.appendChild(countryNameEl);

    // Creating and appending countryPopulationEl to the countryInfoEl
    let countryPopulationEl = document.createElement("p");
    countryPopulationEl.textContent = country.population;
    countryPopulationEl.classList.add("country-population");
    countryInfoEl.appendChild(countryPopulationEl);
}

function displaySearchResults() {
    resultCountriesEl.textContent = "";
    for (let country of countriesList) {
        let countryName = country.name;
        // If the searchInputVal includes in the countryName, creating and appending it to the resultCountriesEl
        if (countryName.includes(searchInputVal)) {
            createAndAppendCountry(country);
        }
    }
}

function getCountries() {
    let url = "https://apis.ccbp.in/countries-data";
    let options = {
        method: "GET",
    };

    spinnerEl.classList.remove("d-none");


    //Making an HTTP request (GET method) using fetch
    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            spinnerEl.classList.add("d-none");
            countriesList = jsonData;
            displaySearchResults();
        });
}

function onChangeSearchInput(event) {
    searchInputVal = event.target.value;
    displaySearchResults();
}

getCountries();
searchInputEl.addEventListener("keyup", onChangeSearchInput);

Know Fact About the Number:
-------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
   <div class="p-2 bg-container d-flex flex-column justify-content-center text-center">
        <h1 class="heading">Enter a number to know interesting facts about the number</h1>
        <input id="userInput" type="search" class="form-control user-input ml-auto mr-auto mt-4" placeholder="Enter a Number" />
        <div class="d-none spinner" id="spinner">
            <div class="d-flex flex-row justify-content-center mt-4">
                <div class="spinner-border" role="status"></div>
            </div>
        </div>
        <p id="fact" class="fact-text mt-4">0 is the atomic number of the theoretical element tetraneutron.</p>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-image: url("https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/numbers-fact-bg.png");
    background-size: cover;
    height: 100vh;
}

.heading {
    color: #ffffff;
    font-size: 28px;
    font-weight: bold;
}

.user-input {
    width: 320px;
}

.spinner {
    color: #ffffff;
}

.fact-text {
    color: #ffffff;
    font-size: 18px;
    font-weight: bold;
}

JS:

let userInputEl = document.getElementById("userInput");
let factEl = document.getElementById("fact");
let spinnerEl = document.getElementById("spinner");

function getFactOfEnterNumber(event) {
    if (event.key === "Enter") {
        let userInputVal = userInputEl.value;
        if (userInputVal === "") {
            alert("Enter a Number");
            return;
        }
        let url = "https://apis.ccbp.in/numbers-fact?number=" + userInputVal;
        let options = {
            method: "GET"
        };
        spinnerEl.classList.remove("d-none");
        factEl.classList.add("d-none");

        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                factEl.classList.remove("d-none");
                spinnerEl.classList.add("d-none");
                let { fact } = jsonData;
                factEl.textContent = fact;
            });
    }
}

userInputEl.addEventListener("keyup", getFactOfEnterNumber);

coding pratice-19:
-------------------------------

Subscribe to Us:
-------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container pt-4">
        <img src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/subscribe-to-us-img.png" class="w-100" />
        <div class="subscribe-form-container d-flex flex-row justify-content-center">
            <form id="subscribeForm" class="pt-4 pb-4 w-75">
                <div class="mb-3">
                    <label for="name" class="input-label">Name</label>
                    <input type="text" class="form-control" id="name" />
                    <p id="nameErrMsg" class="error-message"></p>
                </div>
                <div class="mb-3">
                    <label for="email" class="input-label">Email</label>
                    <input type="text" class="form-control" id="email" />
                    <p id="emailErrMsg" class="error-message"></p>
                </div>
                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary">Subscribe</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-color: #d5e5ff;
}

.subscribe-form-container {
    background-color: #ffffff;
    border-bottom-left-radius: 8px;
    border-bottom-right-radius: 8px;
}

.input-label {
    color: #7b8794;
    font-family: "Roboto";
    font-size: 12px;
    font-weight: bold;
}

.error-message {
    color: #dc3545;
    font-family: "Roboto";
    font-size: 14px;
}

JS:

let subscribeFormEl = document.getElementById("subscribeForm");

let nameEl = document.getElementById("name");
let nameErrMsgEl = document.getElementById("nameErrMsg");

let emailEl = document.getElementById("email");
let emailErrMsgEl = document.getElementById("emailErrMsg");

let errorMsg = "Required*";


nameEl.addEventListener("blur", function(event) {
    if (event.target.value === "") {
        nameErrMsgEl.textContent = errorMsg;
    } else {
        nameErrMsgEl.textContent = "";
    }
});

emailEl.addEventListener("blur", function(event) {
    if (event.target.value === "") {
        emailErrMsgEl.textContent = errorMsg;
    } else {
        emailErrMsgEl.textContent = "";
    }
});

subscribeFormEl.addEventListener("submit", function(event) {
    event.preventDefault();
});

Update Password:
--------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container p-4">
        <h1 class="form-heading text-center">Update Password</h1>
        <form id="updatePasswordForm" class="p-4">
            <div class="mb-3">
                <label for="newPassword" class="input-label">NEW PASSWORD</label>
                <input type="password" class="form-control" id="newPassword" />
                <p id="newPasswordErrMsg" class="error-message mt-1"></p>
            </div>
            <div class="mb-3">
                <label for="confirmPassword" class="input-label">CONFIRM PASSWORD</label>
                <input type="password" class="form-control" id="confirmPassword" />
                <p id="confirmPasswordErrMsg" class="error-message mt-1"></p>
            </div>
            <div class="text-center mt-3">
                <button id="updateBtn" type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-image: linear-gradient(to bottom, #ffa6b7, #1e2ad2);
    height: 100vh;
}

.form-heading {
    color: #ffffff;
    font-family: "Roboto";
    font-size: 36px;
    font-weight: bold;
}

.input-label {
    color: #ffffff;

    font-size: 12px;
    font-weight: bold;
}

.error-message {
    color: #ff0000;
    font-family: "Roboto";
    font-size: 14px;
}

JS:

let updatePasswordFormEl = document.getElementById("updatePasswordForm");

let newPasswordEl = document.getElementById("newPassword");
let newPasswordErrMsgEl = document.getElementById("newPasswordErrMsg");

let confirmPasswordEl = document.getElementById("confirmPassword");
let confirmPasswordErrMsgEl = document.getElementById("confirmPasswordErrMsg");

let validateNewPassword = function() {
    if (newPasswordEl.value === "") {
        newPasswordErrMsgEl.textContent = "Required*";
    } else {
        newPasswordErrMsgEl.textContent = "";
    }
};

let validateConfirmPassword = function() {
    let newPassword = newPasswordEl.value;
    let confirmPassword = confirmPasswordEl.value;

    if (newPassword !== confirmPassword) {
        confirmPasswordErrMsgEl.textContent = "Password must be same";
    } else {
        confirmPasswordErrMsgEl.textContent = "";
    }

};

newPasswordEl.addEventListener("blur", validateNewPassword);
confirmPasswordEl.addEventListener("blur", validateConfirmPassword);

updatePasswordFormEl.addEventListener("submit", function(event) {
    event.preventDefault();
    validateNewPassword();
    validateConfirmPassword();
});

coding pratice-20:
-----------------------------

select your pet:
-------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-12 bg-container pt-4 pb-4 mt-4">
                <h1 class="text-center mb-3 heading">Select your Pet</h1>
                <select id="petSelect" class="form-control">
                    <option value="dog">Dog</option>
                    <option value="cat">Cat</option>
                    <option value="parrot">Parrot</option>
                    <option value="spider">Spider</option>
                    <option value="rabbit">Rabbit</option>
                </select>
                <div class="mt-4">
                    <img id="petImg" class="w-100" src="https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/select-your-pet-dog-img.png" />
                </div>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container{
    background-image: linear-gradient(to right, #d3d3d3, #e0e0e0);
    border-radius: 36px;
}

.heading{
    color: #2d3a35;
    font-family: 'Roboto';
    font-size: 36px;
    font-weight: 700;
}

.selected-pet{
    font-family: "Roboto";
    font-weight: 600;
}

JS:

let petsImageUrls = {
    dog: "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/select-your-pet-dog-img.png",
    cat: "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/select-your-pet-cat-img.png",
    parrot: "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/select-your-pet-parrot-img.png",
    spider: "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/select-your-pet-spider-img.png",
    rabbit: "https://d1tgh8fmlzexmh.cloudfront.net/ccbp-dynamic-webapps/select-your-pet-rabbit-img.png"
};

let petSelectEl = document.getElementById("petSelect");
let petImgEl = document.getElementById("petImg");

petSelectEl.addEventListener("change", function(event) {
  let selectedPet = event.target.value;
  let selectedPetImgUrl = petsImageUrls[selectedPet];
  petImgEl.src = selectedPetImgUrl;
});

Answer the question:
-----------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container p-4">
         <h1 class="mb-4 text-center heading">Answer the Question</h1>
         <div class="bg-container d-flex flex-row justify-content-center">
              <form id="questionsForm" class="p-4 question-form">
                  <h1 class="question">What is capital of India</h1>
                   <div class="d-flex flex-column ml-4" id="cities">
                       <div class="mt-2 mb-2">
                           <input id="cityHyderabad" class="form-control" value="Hyderabad" type="radio" name="city" />
                           <label for="cityHyderabad" class="ml-2 option-label">Hyderabad</label>
                       </div>
                       <div class="mb-2">
                           <input id="cityChennai" class="form-control" value="Chennai" type="radio" name="city" />
                           <label for="cityChennai" class="ml-2 option-label">Chennai</label>
                       </div>
                       <div class="mb-2">
                           <input id="cityDelhi" class="form-control" value="Delhi" type="radio" name="city" />
                           <label for="cityDelhi" class="ml-2 option-label">Delhi</label>
                       </div>
                       <div class="mb-2">
                           <input id="cityMumbai" class="form-control" value="Mumbai" type="radio" name="city" />
                            <label for="cityMumbai" class="ml-2 option-label">Mumbai</label>
                       </div>
                       <div class="ml-4">
                           <button id="submitBtn" type="submit" class="btn btn-primary">Submit</button>
                           <p class="result-msg mt-4" id="resultMsg"></p>
                       </div>
  
                   </div>
              </form>
         </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Monoton&family=Open+Sans:wght@400;700&family=Playfair+Display+SC:wght@400;700&family=Playfair+Display:wght@400;700&family=Roboto:wght@400;700&family=Source+Sans+Pro:wght@400;700&family=Work+Sans:wght@400;700&display=swap");


.bg-container {
    background-color: #f97576;
}

.heading {
    color: #ffffff;
    font-family: "Roboto";
    font-size: 36px;
    font-weight: 700;
}

.question-form {
    background-color: #ffffff;
    border-radius: 20px;
}

.question {
    color: #2d3a35;
    font-family: "Bree Serif";
    font-size: 24px;
}

.option-label {
    color: #2d3a35;
    font-family: "Roboto";
}

.result-msg {
    font-family: "Bree Serif";
    font-size: 18px;
}

JS:

let questionsFormEl = document.getElementById("questionsForm");

let cityHyderabadEl = document.getElementById("cityHyderabad");
let cityChennaiEl = document.getElementById("cityChennai");
let cityDelhiEl = document.getElementById("cityDelhi");
let cityMumbaiEl = document.getElementById("cityMumbai");

let resultMsgEl = document.getElementById("resultMsg");

let capitalCity = "Delhi";
let selectedCity = null;

cityHyderabadEl.addEventListener("change", function(event) {
    selectedCity = event.target.value;
});

cityChennaiEl.addEventListener("change", function(event) {
    selectedCity = event.target.value;
});

cityDelhiEl.addEventListener("change", function(event) {
    selectedCity = event.target.value;
});

cityMumbaiEl.addEventListener("change", function(event) {
    selectedCity = event.target.value;
});

questionsFormEl.addEventListener("submit", function(event) {
    event.preventDefault();

    if (selectedCity === capitalCity) {
        resultMsgEl.textContent = "Correct Answer";
        resultMsgEl.style.color = "#2b9a40";
    } else if (selectedCity === null) {
        resultMsgEl.textContent = "please Enter The value";
        resultMsgEl.style.color = "#dc3545";
    } else {
        resultMsgEl.textContent = "Wrong Answer";
        resultMsgEl.style.color = "#dc3545";
    }
});

Go Rest Console:
-----------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container">
        <div class="container pt-5 pb-5">
            <div class="row pt-4 pb-4 d-flex flex-row justify-content-center console-container">
                <h1 class="col-12 mb-2 text-center heading">GO REST CONSOLE</h1>
                <form class="col-11" id="consoleForm">
                    <div class="mb-2">
                        <label for="requestUrl">Request URL</label>
                        <input id="requestUrl" class="form-control" type="text" value="https://gorest.co.in/public-api/users" />
                        <p id="requestUrlErrMsg" class="error-message"></p>
                    </div>
                    <div class="mb-2">
                        <label for="requestMethod">Request Method</label>
                        <select id="requestMethod" class="form-control mb-2">
                            <option value="POST">POST</option>
                            <option value="PUT">PUT</option>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label for="requestBody">Request Body</label>
                        <textarea id="requestBody" class="form-control w-100" rows="5"></textarea>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="p-2 btn btn-primary" id="sendRequestBtn">Send Request</button>
                    </div>
                </form>
                <div class="col-11 mt-4">
                    <label for="responseStatus">Response Status</label>
                    <input id="responseStatus" class="form-control" type="text" />
                </div>
                <div class="col-11 mt-2">
                    <label for="responseBody">Response Body</label>
                    <textarea id="responseBody" class="form-control w-100" rows="6"></textarea>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-color: #52606d;
}

.console-container {
    background-color: #ffffff;
    border-radius: 36px;
}

.heading {
    color: #1f2933;
    font-size: 32px;
    font-weight: bold;
}

.error-message {
    color: #dc3545;
    font-family: "Roboto";
    font-size: 14px;
}

JS:

let consoleFormEl = document.getElementById("consoleForm");

let requestUrlEl = document.getElementById("requestUrl");
let responseStatusEl = document.getElementById("responseStatus");

let requestUrlErrMsgEl = document.getElementById("requestUrlErrMsg");
let requestMethodEl = document.getElementById("requestMethod");
let requestBodyEl = document.getElementById("requestBody");
let responseBodyEl = document.getElementById("responseBody");

let formData = {
    requestUrl: "https://gorest.co.in/public-api/users",
    requestMethod: "POST",
    requestBody: ""
};
requestUrlEl.addEventListener("change", function(event) {
    formData.requestUrl = event.target.value;
});
requestMethodEl.addEventListener("change", function(event) {
    formData.requestMethod = event.target.value;
});
requestBodyEl.addEventListener("change", function(event) {
    formData.responseBody = event.target.value;
});

function validateRequestUrl(formData) {
    let {requestUrl} = formData;
    if (requestUrl === "") {
        requestUrlErrMsgEl.textContent = "Required*";
    } else {
        requestUrlErrMsgEl.textContent = "";
    }
}

function sendRequest(formData) {
    let { requestUrl, requestMethod, requestBody} = formData;

    let options = {
        method: requestMethod,
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 5b8faa3592569928a8aa07468fac524e3255d48825a42c698da9b7eb99ef1415"
        },
        body: requestBody
    };
    fetch(requestUrl, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            let responseStatus = jsonData.code;
            let responseBody = JSON.stringify(jsonData);
            responseStatusEl.value = responseStatus;
            responseBodyEl.value = responseBody;
        });
}

consoleFormEl.addEventListener("submit", function(event) {
    event.preventDefault();
    validateRequestUrl(formData);
    sendRequest(formData);
});

Mcq pratice-1:
--------------------

let people = [
  {
    name: "Tarzan",
    isHealthy: false
  },
  {
    name: "Mowgli",
    isHealthy: false
  }
];

for (let eachItem of people) {
  eachItem.isHealthy = true;
}

let person = people[1];

console.log(person.isHealthy);

output:

true

HTML:

<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <div id="myContainer">         
      <h1 id="mainHeading">CSS</h1>
    </div>
  </body>
</html>

JS:

let btnElement = document.createElement("button");

btnElement.textContent = "Change Heading";

btnElement.onclick = function() {
  document.getElementById("mainHeading").textContent = "JavaScript";
};

document.getElementById("myContainer").appendChild(btnElement);

coding assignment-2:
---------------------------------

Bookmark Maker:
--------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container">
        <h1 class="Hello-heading pt-3 pl-2">Hello</h1>
        <h1 class="main-heading pb-3 pl-2">Jane Doe</h1>
        <div class="container pt-3">
            <h1 class="site-heading text-center">Bookmark Your Favorite Sites</h1>
            <div class="form-containner shadow pt-3">
                <form id="bookmarkForm">
                    <div class="ml-5 mr-3 mt-2 mb-2">
                        <label class="form-name" for="siteNameInput">SITE NAME</label>
                        <input type="text" id="siteNameInput" class="form-control" />
                        <p id="siteNameErrMsg" class="error"></p>
                    </div>
                    <div class="ml-5 mr-3 mt-2 mb-5">
                        <label class="form-name" for="siteUrlInput">SITE URL</label>
                        <input type="text" id="siteUrlInput" class="form-control" />
                        <p id="siteUrlErrMsg" class="error"></p>
                    </div>
                    <div class="text-right mr-3 ">
                        <button type="submit" id="submitBtn" class="button">Submit</button>
                    </div>
                </form>
                <ul class=" ml-5 d-none" id="bookmarksList"></ul>
                

            </div>


        </div>

    </div>
</body>

</html>

Coding Assignment-3:
-------------------------------

Speed Typing Text:
-------------------------------

HTML:

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>

<body>
    <div class="bg-container pt-5 pl-4" id="speedTypingTest">
        <h1 class="main-heading mb-3">Speed Typing Test</h1>
        <p class="paragraph">On your fingers lets set Go!</p>
        <div class="d-flex flex-row justify-content-start">
            <img src="https://assets.ccbp.in/frontend/dynamic-webapps/clock-img.png" class="image pt-3" />
            <p class="timer-display" id="timer"></p>
        </div>
        <div class="container mt-3 ">
            <div class="d-none" id="spinner">
                <div class="d-flex flex-row justify-content-center">
                    <div class="spinner-border" role="status">

                    </div>
                </div>

            </div>
            <p id="quoteDisplay" class="text"></p>
            <textarea rows="4" cols="40" class="text " id="quoteInput">

               </textarea>
        </div>
        <p id="result"></p>
        <div class="text-left">
            <button class="submit-btn ml-4" id="submitBtn" onclick="submit()">Submit</button>
            <button class="reset-btn" id="resetBtn" onclick="reset()">Reset</button>
        </div>
    </div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.bg-container {
    background-color: #dac0ff;
    height: 200vh;
    width: 200vw;
}

.main-heading {
    font-size: 45px;
    color: #690cb0;
    font-weight: bold;
    width: 250px;
}

.paragraph {
    font-size: 18px;

}

.image {
    height: 60px;
}

.timer-display {
    font-size: 16px;
    padding-left: 5px;
}

.container {
    background-color: #f3eaff;
    height: 120vh;
    width: 120vw;
    border-radius: 15px;
}

.text {
    width: 55vw;
    height: 15vh;

}

.submit-btn {
    background-color: #690cb0;
    color: #ffffff;
    border-radius: 8px;
    margin-left: 15px;
}

.reset-btn {
    background-color: #ffffff;
    color: #3e4c59;
    border-radius: 8px;
    margin-left: 15px;
}

JS:

let speedTypingTestEl = document.getElementById("speedTypingTest");
let timerEl = document.getElementById("timer");
let quoteDisplayEl = document.getElementById("quoteDisplay");
let resultEl = document.getElementById("result");
let quoteInputEl = document.getElementById("quoteInput");
let submitBtnEl = document.getElementById("submitBtn");
let resetBtnEl = document.getElementById("resetBtn");
let spinnerEl = document.getElementById("spinner");

let count = 0;
let intervalId;

function startTimeInterval() {
    intervalId = setInterval(function() {
        count = count + 1;
        timerElement.textContent = count + " seconds";
    }, 1000);
}

function onReset() {
    clearInterval(intervalId);
    count = 0;
    startTimeInterval();
}

let url = "https://apis.ccbp.in/random-quote";
let options = {
    method: "GET"
};

function reset() {
    spinnerEl.classList.remove("d-none");
    quoteDisplayEl.classList.add("d-none");
    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            spinnerEl.classList.remove("d-none");
            quoteDisplayEl.classList.add("d-none");
            let {
                content
            } = jsonData;
            quoteDisplayEl.textContent = content;
        });
    resultEl.textContent = "";
    quoteInputEl.value = "";
}

function submit() {
    if (quoteDisplayEl.textContent === quoteInputEl.value) {

        let timerVal = timerEl.textContent;
        resultEl.textContent = "your type in" + timerVal;
    } else {
        resultEl.textContent = "your typed incoredt sentence";
    }
}
reset();



Coding Test-1:
---------------------

DOM Manipulations:
---------------------------------

HTML:

<!DOCTYPE html>
<html>

<head></head>

<body>
    <h1 id="mainHeading">Welcome to HTML</h1>
</body>

</html>

JS:

let mainHeadingEl = document.getElementById("mainHeading");
mainHeadingEl.style.backgroundColor = "#000000";
mainHeadingEl.style.color = "#b942f5";
mainHeadingEl.textContent = "Welcome to JS";
mainHeadingEl.style.fontFamily = "Roboto";

DOM Manipulations and Events:
-------------------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head></head>

<body>
    <h1 id="heading1">Responsive</h1>
    <h1 id="heading2">Static</h1>
    <button id="clickHereBtn" class="button" onclick="changeText()">click here</button>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.button {
    color: #ffffff;
    background-color: #0967d2;
    font-size: 14px;
    border-width: 0;
    border-radius: 4px;
    padding: 10px;
}

JS:

let heading1El = document.getElementById("heading1");
let heading2El = document.getElementById("heading2");

function changeText() {
    heading2El.style.backgroundColor = "#197030";
    heading2El.textContent = "Responsive";
    heading1El.style.color = "#eb34c0";
    heading1El.textContent = "Static";
}

Sign In Page:
----------------------

HTML:

<!DOCTYPE html>
<html>

<head></head>

<body>
    <p>Enter your Name</p>
    <input type="text" id="inputElement" />
    <p>Enter your Password</p>
    <input type="password" id="passwordElement" />
    <div>
        <button class="button" id="signInBtn" onclick="signIn()">Sign In</button>
    </div>
    <p id="messageText"></p>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.button {
    color: #ffffff;
    background-color: #0967d2;
    font-size: 14px;
    border-width: 0;
    border-radius: 4px;
    margin: 10px;
    padding: 10px;
}

JS:

let inputElementEl = document.getElementById("inputElement");
let passwordElementEl = document.getElementById("passwordElement");
let messageTextEl = document.getElementById("messageText");


function signIn() {
    let inputElementElValue = inputElementEl.value;
    let passwordElementElValue = passwordElementEl.value;

    if (inputElementElValue === "") {
        messageTextEl.textContent = "Please Enter Username";

    } else if (passwordElementElValue === "") {
        messageTextEl.textContent = "Please Enter Password";
    } else {
        messageTextEl.textContent = "Welcome";

    }
}

Appending Elements Dynamically:
----------------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head></head>

<body>
    <div id="myContainer"></div>
</body>

</html>

JS:

let h1El = document.createElement("h1");
let CE = document.getElementById("myContainer");
let buttonEl = document.getElementById("createBtn");

    h1El.textContent = "Main Heading Element";
    CE.appendChild(h1El);
    h1El.style.color = "blue";
	
Dynamic Event Listeners:
-----------------------------------

HTML:

<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <div id="myContainer">
      <p>Create h1 Element dynamically by adding event listeners dynamically</p>
      <button class="button" id="createBtn">Create</button>
    </div>
  </body>
</html>

JS:

let h1El = document.createElement("h1");
let CE = document.getElementById("myContainer");
let buttonEl = document.getElementById("createBtn");
function greet(){
h1El.textContent = "Main Heading Element";
CE.appendChild(h1El);
h1El.style.color = "blue";
}

buttonEl.onclick = function(){
    greet();
}

Remove and Add Class Names:
-------------------------------------------

HTML:

<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <h1 class="heading-old-styles" id="heading">h1 Element</h1>
    <button id="btnEl" class="button">Remove old styles and add new styles</button>
  </body>
</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.heading-old-styles {
  color: #00ff00;
  background-color: #000000;
}

.button {
  color: #ffffff;
  background-color: #0967d2;
  font-size: 14px;
  border-width: 0;
  border-radius: 4px;
  padding: 10px;
}

.heading-new-styles {
  color: #ff0000;
  background-color: #ffffff;
}

JS:

let headingEl = document.getElementById("heading");
let btnEl = document.getElementById("btnEl");

btnEl.onclick = function() {
    headingEl.classList.add("heading-new-styles");
    headingEl.classList.remove("heading-old-styles");
};	

coding Test-2:
---------------------

for...of loop:
---------------------

HTML:

<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <div>
      <h1>Cars</h1>
      <ul id="listContainer"></ul>
    </div>
  </body>
</html>

JS:

let carBrands = ["Benz", "Ferrari", "Audi", "BMW"];

let listContainerEl = document.getElementById("listContainer");

for(let item of carBrands) {
    let listItem = document.createElement("li");
    listItem.textContent = item;
    listContainerEl.appendChild(listItem);
}

DOM Manipulations - 2:
---------------------------------------

HTML:

<!DOCTYPE html>
<html>

<head></head>

<body>
    <div id="myContainer"></div>
</body>

</html>

CSS:

@import url("https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap");

.checked {
    color: #7a0ecc;
    background-color: #f2ebfe;
}

JS:

let myContainerEl = document.getElementById("myContainer");

let input = document.createElement("input");
input.type = "checkbox";
input.id = "checkbox";
myContainerEl.appendChild(input);

let label = document.createElement("label");
label.setAttribute("for", "checkbox");
label.textContent = "color the heading";
label.id = "text";
myContainerEl.appendChild(label);

let hEl = document.createElement("h1");
hEl.textContent = "heading";
myContainerEl.appendChild(hEl);

input.onclick = function() {
    hEl.classList.toggle("checked");
    label.textContent="uncolor";
}

----------------------------------------------------------------------------------------------------------------------------------------------------------

More Modern JS Concepts | Cheat Sheet:
--------------------------------------------------------

1. Spread Operator:
---------------------------------

The Spread Operator is used to unpack an iterable (e.g. an array, object, etc.) into individual elements.

1.1 Spread Operator with Arrays:

let arr1 = [2, 3];
let arr2 = [1, ...arr1, 4];

console.log(arr2);  // [1, 2, 3, 4]

1.1.1 Creating a Copy:

let arr1 = [2, 3];
let arr2 = [...arr1];

console.log(arr2);  // [2, 3]

1.1.2 Concatenation:

let arr1 = [2, 3];
let arr2 = [4, 5];
let arr3 = [...arr1, ...arr2];

console.log(arr3);  // [2, 3, 4, 5]

1.2 Spread Operator with Objects:

let person = { name: "Rahul", age: 27 };
let personDetails = { ...person, city: "Hyderabad" };

console.log(personDetails);  // Object {name: "Rahul", age: 27, city: "Hyderabad"}

1.2.1 Creating a Copy:

let person = { name: "Rahul", age: 27 };
let personDetails = { ...person };

console.log(personDetails);  // Object {name: "Rahul", age: 27}

1.2.2 Concatenation:

let person = { name: "Rahul", age: 27 };
let address = { city: "Hyderabad", pincode: 500001 };
let personDetails = { ...person, ...address };

console.log(personDetails);  // Object {name: "Rahul", age: 27, city: "Hyderabad", pincode: 500001}

1.3 Spread Operator with Function Calls:

The Spread Operator syntax can be used to pass an array of arguments to the function.
 Extra values will be ignored if we pass more arguments than the function parameters.
 
 function add(a, b, c) {
  return a + b + c;
}
let numbers = [1, 2, 3, 4, 5];

console.log(add(...numbers));  // 6

2. Rest Parameter:
-------------------------------------
With Rest Parameter, we can pack multiple values into an array.

function numbers(...args) {
  console.log(args);  // [1, 2, 3]
}

numbers(1, 2, 3);

2.1 Destructuring arrays and objects with Rest Parameter Syntax
2.1.1 Arrays

let [a, b, ...rest] = [1, 2, 3, 4, 5];

console.log(a);  // 1
console.log(b);  // 2
console.log(rest);  // [3, 4, 5]

2.1.2 Objects

let { firstName, ...rest } = {
  firstName: "Rahul",
  lastName: "Attuluri",
  age: 27
};

console.log(firstName);  // Rahul
console.log(rest);  // Object {lastName: "Attuluri", age: 27}

Note:
The Rest parameter should be the last parameter.

function numbers(a, b, ...rest) {
  console.log(a);  // 1
  console.log(b);  // 2
  console.log(rest);  // [3, 4, 5]
}
numbers(1, 2, 3, 4, 5);

function numbers(a, ...rest, b) {
  console.log(a);
  console.log(rest);
  console.log(b);
}
numbers(1, 2, 3, 4, 5);  // Uncaught SyntaxError: Rest parameter must be last formal parameter

3. Functions:
----------------------------

3.1 Default Parameters
The Default Parameters allow us to give default values to function parameters.

function numbers(a = 2, b = 5) {
  console.log(a);  // 3
  console.log(b);  // 5
}

numbers(3);

4. Template Literals (Template Strings):
--------------------------------------------------------

The Template Literals are enclosed by the backticks.

They are used to:
1. Embed variables or expressions in the strings
2. Write multiline strings

We can include the variables or expressions using a dollar sign with curly braces ${ }.

let firstName = "Rahul";

console.log(`Hello ${firstName}!`);  // Hello Rahul!

More Modern JS Concepts Part 2  | Cheat Sheet:
---------------------------------------------------------------

1. Operators:
-----------------------------
1.1 Ternary Operator:
A Ternary Operator can be used to replace if...else statements in some situations.

Syntax: condition ? expressionIfTrue : expressionIfFalse

let speed = 70;
let message = speed >= 100 ? "Too Fast" : "OK";

console.log(message);  // OK

2. Conditional Statements:
-----------------------------------------------
2.1 Switch Statement
A Switch statement is a conditional statement like if...else statement used in decision making.

Syntax:

switch (expression) {
  case value1:
    /*Statements executed when the
    result of expression matches value1*/
    break;
  case value2:
    /*Statements executed when the
    result of expression matches value2*/
    break;
  ...
  case valueN:
    /*Statements executed when the
    result of expression matches valueN*/
    break;
  default:
    /*Statements executed when none of
    the values match the value of the expression*/
    break;
}

JS:

let day = 1;
switch (day) {
  case 0:
    console.log("Sunday");
    break;
  case 1:
    console.log("Monday");  // Monday
    break;
  case 2:
    console.log("Tuesday");
    break;
  case 3:
    console.log("Wednesday");
    break;
  case 4:
    console.log("Thursday");
    break;
  case 5:
    console.log("Friday");
    break;
  case 6:
    console.log("Saturday");
    break;
  default:
    console.log("Invalid");
    break;
}

3. Defining Functions:
---------------------------------------

There are multiple ways to define a function.

Function Declaration
Function Expression
Arrow Functions
Function Constructor, etc.

3.1 Arrow Functions:
An Arrow function is a simple and concise syntax for defining functions.

It is an alternative to a function expression.

Syntax:

let sum = (param1, param2, …) => {
  // statement(s)
};
sum();

EX:

let sum = (a, b) => {
  let result = a + b;
  return result;
};
console.log(sum(4, 3));

3.1.1 Simple Expressions
In arrow functions, the return statement and curly braces are not required for simple expressions.

let sum = (a, b) => a + b;

console.log(sum(4, 3));  // 7

3.1.2 One parameter
If there is only one parameter, then parentheses are not required.

let greet = name => `Hi ${name}!`;

console.log(greet("Rahul"));  // Hi Rahul!

3.1.3 No parameters
If there are no parameters, parentheses will be empty, but they should be present.

let sayHi = () => "Hello!";

console.log(sayHi());  // Hello!

3.1.4 Returning Objects

let createUser = name => {
  return {
    firstName: name
  };
};

console.log(createUser("Rahul"));  // Object {firstName: "Rahul"}

Simple Expression

let createUser = name => { firstName: "Rahul" };

console.log(createUser());  // undefined

JavaScript considers the two curly braces as a code block, but not as an object syntax.

So, wrap the object with parentheses to distinguish with a code block.

let createUser = name => ({ firstName: "Rahul" });

console.log(createUser());  // Object {firstName: "Rahul"}

Factory and Constructor Functions | Cheat Sheet:
------------------------------------------------------------

1. Factory Function:
A Factory function is any function that returns a new object for every function call.

The Function name should follow the camelCase naming convention.

Syntax:

function functionName(parameter1, parameter2, ...) {
  return {
    property1: parameter1,
    property2: parameter2,
    ...
    ...
  }
}
let myObject = functionName(arg1, arg2, ...)

JS:

function createCar(color, brand) {
  return {
    color: color,
    brand: brand,
    start: function() {
      console.log("started");
    }
  };
}

let car1 = createCar("blue", "Audi");
let car2 = createCar("red", "Tata");
let car3 = createCar("green", "BMW");

console.log(car1);  // Object { color: "blue", brand: "Audi", start: ƒ() }
console.log(car2);  // Object { color: "red", brand: "Tata", start: ƒ() }
console.log(car3);  // Object { color: "green", brand: "BMW", start: ƒ() }

1.1 Shorthand Notations:

function createCar(color, brand) {
  return {
    color,
    brand,
    start() {
      console.log("started");
    }
  };
}

let car1 = createCar("blue", "Audi");
let car2 = createCar("red", "Tata");
let car3 = createCar("green", "BMW");

console.log(car1);  // Object { color: "blue", brand: "Audi", start: ƒ() }
console.log(car2);  // Object { color: "red", brand: "Tata", start: ƒ() }
console.log(car3);  // Object { color: "green", brand: "BMW", start: ƒ() }

2. Constructor Function:
A regular function that returns a new object on calling with the new operator. The created new object is called an Instance.

The Function name should follow the PascalCase naming convention.

Syntax:

function FunctionName(parameter1, parameter2, ...) {
  this.property1 = parameter1;
  this.property2 = parameter2;
  ...
  ...
}
let myObject = new FunctionName(arg1, arg2, ...)

2.1 The new Operator:
When a function is called with the new operator, it does the following steps:

Creates an empty object and assigns it to this
Return this

function Car(color, brand) {
  this.color = color;
  this.brand = brand;
  this.start = function() {
    console.log("started");
  };
}

let car1 = new Car("blue", "Audi");
console.log(car1);  // Car { }

Here,

car1 is instance
car1.start() is instance method
car1.color, car1.brand are instance properties

2.2 Factory vs Constructor Functions:

Factory Functions																Constructor Functions
Follows camelCase notation													Follows PascalCase notation
Doesn't need new operator for function calling							Needs new operator for function calling
Explicitly need to return the object									Created object returns implicitly

3. JS Functions:
-----------------------------
Similar to Objects, Functions also have properties and methods.

3.1 Default Properties:
name
length
constructor
prototype, etc.

3.2 Default Methods:
apply()
bind()
call()
toString(), etc.

3.3 Function Properties:

3.3.1 The name Property:
This property returns the name of the function.

function Car(color, brand) {
  this.color = color;
  this.brand = brand;
  this.start = function() {
    console.log("started");
  };
}
console.log(Car.name);  // Car

3.3.2 The length Property
This property returns the number of parameters passed to the function.

function Car(color, brand) {
  this.color = color;
  this.brand = brand;
  this.start = function() {
    console.log("started");
  };
}
console.log(Car.length);  // 2

3.3.3 The typeof function

function Car(color, brand) {
  this.color = color;
  this.brand = brand;
  this.start = function() {
    console.log("started");
  };
}
console.log(typeof(Car));  // function

4. The Constructor Property:
------------------------------------------
Every object in JavaScript has a constructor property.

The constructor property refers to the constructor function that is used to create the object.

JS:

function Car(color, brand) {
  this.color = color;
  this.brand = brand;
  this.start = function() {
    console.log("started");
  };
}
let car1 = new Car("blue", "Audi");
console.log(car1.constructor);  // f Car(color, brand) {}

5. Built-in Constructor Function:
-----------------------------------------------
These are the Constructor functions provided by JavaScript.

function Date()
function Error()
function Promise()
function Object()
function String()
function Number(), etc.

In JavaScript, date and time are represented by the Date object. The Date object provides the date and time information and also provides various methods.

5.1 Creating Date Objects:
There are four ways to create a date object.

new Date()
new Date(milliseconds)
new Date(datestring)
new Date(year, month, day, hours, minutes, seconds, milliseconds)

5.1.1 new Date()
You can create a date object without passing any arguments to the new Date() constructor function.

For example,

let now = new Date();

console.log(now);  // Tue Feb 02 2021 19:10:29 GMT+0530 (India Standard Time) { }
console.log(typeof(now));  // object

Here, new Date() creates a new date object with the current date and local time.

Note:
1.Coordinated Universal Time (UTC) - It is the global standard time defined by the World Time Standard. 
(This time is historically known as Greenwich Mean Time, as UTC lies along the meridian that includes London and nearby Greenwich in the United Kingdom.)
2.Local Time - The user's device provides the local time.

5.1.2 new Date(milliseconds)
The Date object contains a number that represents milliseconds since 1 January 1970 UTC.

The new Date(milliseconds) creates a new date object by adding the milliseconds to zero time.

For example,

let time1 = new Date(0);
console.log(time1);  // Thu Jan 01 1970 05:30:00 GMT+0530 (India Standard Time) { }

// 100000000000 milliseconds from 1 Jan 1970 UTC
let time2 = new Date(100000000000);
console.log(time2);  // Sat Mar 03 1973 15:16:40 GMT+0530 (India Standard Time) { }

Note:
1000 milliseconds is equal to 1 second.

5.1.3 new Date(date string)
The new Date(date string) creates a new date object from a date string.

Syntax: new Date(datestring);

let date = new Date("2021-01-28");

console.log(date);  // Thu Jan 28 2021 05:30:00 GMT+0530 (India Standard Time) { }

You can also pass only the year and month or only the year. For example,

let date = new Date("2020-08");
console.log(date);  // Sat Aug 01 2020 05:30:00 GMT+0530 (India Standard Time) { }

let date1 = new Date("2020");
console.log(date1);  // Wed Jan 01 2020 05:30:00 GMT+0530 (India Standard Time) { }

Short date format:
// short date format "MM/DD/YYYY"
let date = new Date("03/25/2015");
console.log(date);  // Wed Mar 25 2015 00:00:00 GMT+0530 (India Standard Time) { }

Long date format:
// long date format "MMM DD YYYY"
let date1 = new Date("Jul 1 2021");
console.log(date1);  // Thu Jul 01 2021 00:00:00 GMT+0530 (India Standard Time) { }

Month and Day can be in any order:

let date2 = new Date("1 Jul 2021");
console.log(date2);  // Thu Jul 01 2021 00:00:00 GMT+0530 (India Standard Time) { }

The month can be full or abbreviated. Also, month names are case insensitive:

let date3 = new Date("July 1 2021");
console.log(date3);  // Thu Jul 01 2021 00:00:00 GMT+0530 (India Standard Time) { }

// commas are ignored
let date4 = new Date("JULY, 1, 2021");
console.log(date4);  // Thu Jul 01 2021 00:00:00 GMT+0530 (India Standard Time) { }

5.1.4 new Date(year, month, day, hours, minutes, seconds, milliseconds)
It creates a new date object by passing a specific date and time.

For example,

let time1 = new Date(2021, 1, 20, 4, 12, 11, 0);
console.log(time1);  // Sat Feb 20 2021 04:12:11 GMT+0530 (India Standard Time) { }

Here, months are counted from 0 to 11. January is 0 and December is 11.

The passed argument has a specific order.

If four numbers are passed, it represents the year, month, day and hours.

For example,

let time1 = new Date(2021, 1, 20, 4);
console.log(time1);  // Sat Feb 20 2021 04:00:00 GMT+0530 (India Standard Time) { }

Similarly, if two arguments are passed, it represents year and month.

For example,

let time1 = new Date(2020, 1);
console.log(time1);  // Sat Feb 20 2021 04:00:00 GMT+0530 (India Standard Time) { }

Warning:
If you pass only one argument, it is treated as milliseconds. Hence, you have to pass two arguments to use this date format.

5.2 AutoCorrection in Date Object
When you assign out of range values in the Date object, it auto-corrects itself.

For example,

let date = new Date(2008, 0, 33);
// Jan does not have 33 days
console.log(date);  // Sat Feb 02 2008 00:00:00 GMT+0530 (India Standard Time) { }

33 days are auto corrected to 31 (jan) + 2 days in feb.

5.3 Instance Methods
There are methods to access and set values like a year, month, etc. in the Date Object.

Method	Description
now()	Returns the numeric value corresponding to the current time (the number of milliseconds passed since January 1, 1970, 00:00:00 UTC)
getFullYear()	Gets the year according to local time
getMonth()	Gets the month, from 0 to 11 according to local time
getDate()	Gets the day of the month (1–31) according to local time
getDay()	Gets the day of the week (0-6) according to local time
getHours()	Gets the hour from 0 to 23 according to local time
getMinutes	Gets the minute from 0 to 59 according to local time
getUTCDate()	Gets the day of the month (1–31) according to universal time
setFullYear()	Sets the full year according to local time
setMonth()	Sets the month according to local time
setDate()	Sets the day of the month according to local time
setUTCDate()	Sets the day of the month according to universal time

let date1 = new Date(1947, 7, 15, 1, 3, 15, 0);

console.log(date1.getFullYear());  // 1947
console.log(date1.getMonth());  // 7

5.3.1 Setting Date Values:

let date1 = new Date(1947, 7, 15);
date1.setYear(2021);
date1.setDate(1);

console.log(date1);  // Sun Aug 01 2021 00:00:00 GMT+0530 (India Standard Time) { }

JS CODING PRACTICE 1:
-------------------------------------

creating a copy of an array:
----------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  let myArray = JSON.parse(readLine().replace(/'/g, '"'));
/* Please do not modify anything above this line */

  let newArray = [...myArray]; // Write your code here. 
  
/* Please do not modify anything below this line */  
  console.log(newArray);
}

Input:

[ 'x', 'y', 'z' ]

Output:

[ 'x', 'y', 'z' ]

Function calling with spread operator:
---------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function getProductOfTheIntegers(...args) {
  let productOfAllValues = 1;
  for (let value of args) {
    productOfAllValues = productOfAllValues * value;
  }
  
  return productOfAllValues;
}

function main() {
  let integersArray = JSON.parse(readLine().replace(/'/g, '"'));
/* Please do not modify anything above this line */
let num = getProductOfTheIntegers(...integersArray)
console.log(num);
  /*
   * Write your code here and log the output.
   */
}

Input:

[1, 2, 3]

Output:

6

Concatenate arrays with spread operator:
---------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  let myArray = JSON.parse(readLine().replace(/'/g, '"'));
  let numbersArray = [1, 5];
/* Please do not modify anything above this line */
numbersArray = [1, ...myArray, 5];
  /*
   * Write your code here.
   */
  
/* Please do not modify anything below this line */  
  console.log(numbersArray);
}

Input:

[ 2, 3, 4 ]

Output:

[ 1, 2, 3, 4, 5 ]

Concatenate object with spread operator:
---------------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function main() {
  let model = JSON.parse(readLine().replace(/'/g, '"'));
  let engine = JSON.parse(readLine().replace(/'/g, '"'));
  let carDetails = {};
/* Please do not modify anything above this line */
  carDetails = {...model, ...engine};
  /*
   * Write your code here.
   */
  
/* Please do not modify anything below this line */  
  console.log(`${carDetails.model} is powered with ${carDetails.engineCapacity}cc engine.`);
}

Input:

{'model':'Amaze'}
{'engineCapacity':4000}

Output:

Amaze is powered with 4000cc engine.

Rest Parameter:
-------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

function logFamily(father, mother, ...children) {
    let formatedChildren = children.join();
    
    console.log(`${father} ${mother}`);
    console.log(formatedChildren);
}
/* Please do not modify anything above this line */

/*
 * Write the function here and log the output. Use function name "logFamily".
 */

/* Please do not modify anything below this line */

function main() {
  let familyArray = JSON.parse(readLine().replace(/'/g, '"'));

  logFamily(...familyArray);
}

Input:

[ 'John', 'Martha', 'Nikky', 'Boby' ]

Output:

John Martha
Nikky,Boby

OTP message:
------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function getOtpMessage(name, otp) {
  /*
   * Write your code here and return the output.
   */ 
   return `Hi! ${name}, ${otp} is your OTP.`
}

/* Please do not modify anything below this line */

function main() {
  let customerName = readLine();
  let otp = JSON.parse(readLine());

  let otpMessage = getOtpMessage(customerName, otp);

  console.log(otpMessage);
}

Input:

Raju
89898

Output:

Hi! Raju, 89898 is your OTP.

Destructuring Arrays:
---------------------------------

function readLine() {
  return inputString[currentLine++];
}

function main() {
  let numbersArray = JSON.parse(readLine());
let[f,s,...rest] = numbersArray;
let sum = 0;
for (let eachnumber of rest) {
    sum += eachnumber;
}
console.log(sum);
/* Please do not modify anything above this line */

  /*
   * Write your code here and log the output.
   */
}

Input:

[ 1, 2, 3, 4, 5 ]

Output:

12

simple interest:
-------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString
    .trim()
    .split("\n")
    .map((str) => str.trim());

  main();
});

function readLine() {
  let input = inputString[currentLine++]; 
  return input === undefined ? undefined : JSON.parse(input);
}

function calculateTotalAmountWithInterest(p, t=1, r= 10) {
    let total = p*(1+t*r/100);
    return total;
}
/* Please do not modify anything above this line */

/*
 * Write the function here and return the output. Use function name "calculateTotalAmountWithInterest".
 */

/* Please do not modify anything below this line */

function main() {
  let p = readLine();
  let t = readLine();
  let r = readLine();

  let finalValue = calculateTotalAmountWithInterest(p, t, r);

  console.log(finalValue);
}

Input:

1000
12
2

Output:

1240

JS CODING PRACTICE 2:
--------------------------------------------

predict the winner:
-----------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function getWinnerOfTheRace(averageSpeedOfRacer1, averageSpeedOfRacer2) {
  /*
   * Write your code here and return the output.
   */
   let winner = averageSpeedOfRacer1 > averageSpeedOfRacer2 ? 'Racer 1' : 'Racer 2';
   return winner;
}

/* Please do not modify anything below this line */

function main() {
  let averageSpeedOfRacer1 = JSON.parse(readLine());
  let averageSpeedOfRacer2 = JSON.parse(readLine());

  let winner = getWinnerOfTheRace(averageSpeedOfRacer1, averageSpeedOfRacer2);
  
  console.log(winner);
}

Input:

98.80
92.39

Output:

Racer1

simple calculator:
-----------------------------------------

function readLine() {
  return inputString[currentLine++];
}

function main() {
  let operator = readLine();
  let number1 = JSON.parse(readLine());
  let number2 = JSON.parse(readLine());

  /* Please do not modify anything above this line */

  /*
   * Write your code here and log the output.
   */
   let r;
   
   switch (operator) {
       case '+':
           r = number1 + number2;
           break;
        case '-':
            r = number1 - number2;
            break;
        case '*':
            r = number1*number2;
            break;
        case '/':
            r = number1/number2;
            break;
        default:
        r = 'Invalid operator';
        break;
     
   }
   console.log(r);
}

Input:

+
2
3

Output:

5

calculate area of square:
----------------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

function main() {
  let side = JSON.parse(readLine());

  /* Please do not modify anything above this line */

  /*
   * Write the arrow function here and log the output.
   */
   let calculate = (side) => side * side;
   let area = calculate(side);
   console.log(area);
}

Input:

4

Output:

16

Discounted Fare:
---------------------------------

function readLine() {
  return inputString[currentLine++];
}

function main() {
  let fare = JSON.parse(readLine());
  let discountPercentage = JSON.parse(readLine());

  /* Please do not modify anything above this line */

  /*
   * Write the arrow function here and log the output.
   */
   let getTotal = (fare,discountPercentage) => fare - (fare*discountPercentage)/100;
   let discountedFare = getTotal(fare,discountPercentage);
   console.log(discountedFare)
}

Input:

200
10

Output:

180

Quote:
--------------------

function readLine() {
  return inputString[currentLine++];
}

function main() {
  /* Please do not modify anything above this line */
  
  /*
   * Write the arrow function here and log the output.
   */
   let getQuote = () => "Make it work, make it right, make it fast.";
   console.log(getQuote());
}

Output:

Make it work, make it right, make it fast.

JS CODING PRACTICE 3:
-------------------------------------------

Passanger ticket conformation status:
-------------------------------------------------------


function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function createPassengerTicket(name, isTicketConfirmed) {
  /*
   * Write your code here and return output.
   */
   return{
       name,
       isTicketConfirmed
   };
}

/* Please do not modify anything below this line */

function main() {
  let firstPassengerName = readLine();
  let firstPassengerTicketStatus = JSON.parse(readLine());
  let secondPassengerName = readLine();
  let secondPassengerTicketStatus = JSON.parse(readLine());

/* Please do not modify anything above this line */ 
  
  /*
   * Write your code here and log the output.
   */
   let p1 = createPassengerTicket(firstPassengerName,firstPassengerTicketStatus);
   let p2 = createPassengerTicket(secondPassengerName,secondPassengerTicketStatus);
   console.log(p1)
   console.log(p2)
}

Input:

Madhav
true
Amith
false

Output:

{ name: 'Madhav', isTicketConfirmed: true }
{ name: 'Amith', isTicketConfirmed: false }

user online status:
---------------------------------


function User(username, isOnline) {
  /*
   * Write your code here.
   */
   this.username = username;
   this.isOnline = isOnline;
}

/* Please do not modify anything below this line */

function main() {
  let firstUserName = readLine();
  let firstUserOnlineStatus = JSON.parse(readLine());
  let secondUserName = readLine();
  let secondUserOnlineStatus = JSON.parse(readLine());

/* Please do not modify anything above this line */ 
  
  /*
   * Write your code here and log the output.
   */
   let user1 = new User(firstUserName,firstUserOnlineStatus);
   let user2 = new User(secondUserName,secondUserOnlineStatus);
   
   console.log(user1);
   console.log(user2);
}


Input:

Raghav
true
Vikas
true

Output:

User { username: 'Raghav', isOnline: true }
User { username: 'Vikas', isOnline: true }

Person object using factory function:
----------------------------------------------------------


function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function createPerson(firstName, lastName) {
  /*
   * Write your code here and return output.
   */
   return{
       firstName,
       lastName,
       getFullName(firstName,lastName) {
           return `${firstName} ${lastName}`;
       }
   };
}

/* Please do not modify anything below this line */

function main() {
  let firstName = readLine();
  let lastName = readLine();
/* Please do not modify anything above this line */ 
  
  /*
   * Write your code here and log output.
   */
   let person = createPerson(firstName,lastName);
   let fullName = person.getFullName(firstName,lastName);
   console.log(fullName);
}

Input:

Tom
Chandler

Output:

Tom Chandler

Person object using constructor function:
---------------------------------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Person(firstName, lastName) {
  /*
   * Write your code here.
   */
   this.firstName = firstName;
   this.lastName = lastName;
   this.getFullName = function getFullName(firstName,lastName) {
           return `${firstName} ${lastName}`;
       };
}

/* Please do not modify anything below this line */

function main() {
  let firstName = readLine();
  let lastName = readLine();
/* Please do not modify anything above this line */ 
  
  /*
   * Write your code here and log output.
   */
   let person1 = new Person(firstName,lastName);
   let fullName = person1.getFullName(firstName,lastName);
   console.log(fullName);
}

Input:

Kylie
Grant

Output:

Kylie Grant

Reschdule Event:
---------------------------------

function readLine() {
  return inputString[currentLine++];
}

function main() {
  let scheduledDate = new Date("2020-2-15");
  let rescheduledDate = JSON.parse(readLine());
  let rescheduledMonth = JSON.parse(readLine());
  let rescheduledYear = JSON.parse(readLine());
/* Please do not modify anything above this line */

  /*
   * Write your code here.
   */
   
   scheduledDate.setDate(rescheduledDate);
   scheduledDate.setMonth(rescheduledMonth);
   scheduledDate.setYear(rescheduledYear);
  
/* Please do not modify anything below this line */  
  console.log(`${scheduledDate.getDate()}-${scheduledDate.getMonth() + 1}-${scheduledDate.getFullYear()}`);
}

Input:

12
2
2022

Output:

12-3-2022

Expiry Date:
------------------------

function readLine() {
  return inputString[currentLine++];
}

function main() {
  let manufacturingDate = new Date(readLine());
  let monthsToExpiry = parseInt(readLine());
/* Please do not modify anything above this line */
 
  let expiryDate = new Date(manufacturingDate);
  expiryDate.setMonth(manufacturingDate.getMonth() + monthsToExpiry );
  //Write your code here.
  
/* Please do not modify anything below this line */  
  console.log(`${expiryDate.getDate()}-${expiryDate.getMonth() + 1}-${expiryDate.getFullYear()}`);
}

Input:

2020-01-21
8

Output:

21-9-2020



More Modern JS Concepts | Part 3  | Cheat Sheet:
--------------------------------------------------------

1. this:
The this is determined in three ways.

In Object methods, it refers to the object that is executing the current function.
In Regular functions, it refers to the window object.
In Arrow functions, it refers to the context in which the code is defined.

1.1 this in Object Methods

let car = {
  color: "blue",
  brand: "Audi",
  start: function() {
    console.log(this);  // Object { color: "blue", brand: "Audi", start: ƒ() }
  }
};

car.start();

In the above example, this refers to the car object as it's executing the method start.

1.2 this in Regular Functions:

function start() {
  console.log(this);  // Window { }
}
start();

In the above example, this refers to the window object.

1.3 this in Arrow Functions
In Arrow functions, this depends on two aspects:

When the code is defined
Context

Arrow function inherits this from the context in which the code is defined.

1.3.1 Object Methods

let car = {
  color: "blue",
  brand: "Audi",
  start: () => {
    console.log(this);  // Window { }
  }
};

car.start();

Arrow Functions with Callbacks

let car = {
  color: "blue",
  brand: "Audi",
  start: function() {
    setTimeout(() => {
      console.log(this);  // Object { color: "blue", brand: "Audi", start: ƒ() }
    }, 1000);
  }
};

car.start();

1.4 this in Constructor Functions
In Constructor Function, this refers to the instance object.

function Car(color, brand) {
  this.color = color;
  this.brand = brand;
  this.start = function() {
    console.log(this);  // Car { }
  };
}

let car1 = new Car("blue", "Audi");
car1.start();

In the above example, this refers to the object car1.

1.4.1 Arrow Functions

function Car(color, brand) {
  this.color = color;
  this.brand = brand;
  this.start = () => {
    console.log(this);  // Car { }
  };
}

let car1 = new Car("blue", "Audi");
car1.start();

Try out the this in different functions like Object Methods, Arrow Functions, and Constructor Functions etc. in the JavaScript Code Playground.

2. Immutable and Mutable Values:
--------------------------------------------

2.1 Immutable
All the primitive type values are immutable.

Number
String
Boolean
Symbol
Undefined, etc.

let x = 5;
let y = x;
y = 10;

console.log(x);  // 5
console.log(y);  // 10

2.2 Mutable
All the Objects are mutable.

Object
Array
Function

let x = { value: 5 };
let y = x;
let z = { value: 20 };

y.value = 10;

console.log(x);  // Object { value: 10 }
console.log(y);  // Object { value: 10 }

y = z;

console.log(x);  // Object { value: 10 }
console.log(y);  // Object { value: 20 }

3. Declaring Variables:
---------------------------------------------
In JavaScript, a variable can be declared in 3 ways.

Using let
Using const
Using var

3.1 let
While declaring variables using let,

Initialization is not mandatory
Variables can be reassigned

let x;
x = 10;

console.log(x);  // 10

x = 15;
console.log(x);  // 15

3.2 const
While declaring variables using const,

Initialization is mandatory
Once a value is initialized, then it can't be reassigned

Without Initialization:

const x;

x = 7;  // SyntaxError {"Const declarations require an initialization value (1:21)"}

Reassignment:

const x = 7;

x = 9;  // TypeError {"Assignment to constant variable."}

3.2.1 Mutating Object properties

const car = {
 color : "blue",
 brand : "Audi"
};
car.color = "red";

console.log(car.color);  // red

But objects can't be reassigned.

const car = {
 color : "blue",
 brand : "Audi"
};
car.color = "red";

car = {};  // TypeError {"Assignment to constant variable."}

JS CODING PRACTICE 4:
------------------------

Change brand name:
----------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Company(brandName) {
  this.brandName = brandName;
  /* Write your code here. */
  this.updateBrandName = function (proposedBrandName) {
      this.brandName = proposedBrandName;
  }
}

/* Please do not modify anything below this line */

function main() {
  const proposedBrandName  = readLine();

  const company1 = new Company("Blue Royal");
  company1.updateBrandName(proposedBrandName);
  
  console.log(company1.brandName);   
}

Input:

Royal Blue

Output:

Royal Blue

Update person's address:
-----------------------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function createPersonAddress(city, state) {
  return {
    city,
    state,
    /* Write your code here. */
    updateAddress(currentCity, currentState) {
        this.city = currentCity;
        this.state = currentState;
    }
  };
}

/* Please do not modify anything below this line */

function main() {
  const currentCity = readLine();
  const currentState = readLine();
  
  const personAddress = createPersonAddress("Mumbai", "Maharashtra");
  personAddress.updateAddress(currentCity, currentState);

  console.log(`${personAddress.city} ${personAddress.state}`);
}

Input:

Amritsar
Punjab

Output:

Amritsar Punjab

Ratio of numbers:
------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function NumberPair(firstNumber, secondNumber) {

  /* Write your code here. */
  this.firstNumber = firstNumber;
  this.secondNumber = secondNumber;
  this.getRatio = function() {
      const ratio = this.firstNumber/this.secondNumber;
      return ratio;
  };

}

/* Please do not modify anything below this line */

function main() {
  const firstNumber  = JSON.parse(readLine());
  const secondNumber = JSON.parse(readLine());
  
  const numberPair1 = new NumberPair(firstNumber, secondNumber);  

  console.log(numberPair1.getRatio()); 
}

Input:

5
2

Output:

2.5

Prototypal Inheritance | Cheat Sheet:
--------------------------------------------------------

1. Built-in Constructor Functions:
These are the built-in constructor functions provided by JavaScript.

function Array()
function Function()
function Promise()
function Object()
function String()
function Number(), etc.

2. Built-in Array Constructor Function:

2.1 Default Properties and Methods

Properties:

constructor
length
prototype, etc.

Methods:

push()
pop()
splice()
shift(), etc.

2.2 Creating an Array with the new Operator (Older way of writing)

Syntax: let myArray = new Array(item1, item2, ...);

let myArray = new Array("a", 2, true);
myArray.push("pen");

console.log(myArray);  // Array (4)["a", 2, true, "pen"]
console.log(myArray.length);  // 4

3. Prototype Property:

The Prototype property will be shared across all the instances of their constructor function.

3.1 Accessing the Prototype of a Constructor Function

console.log(Array.prototype);

3.2 Accessing the shared Prototype of an Instance

let myArray = new Array("a", 2, true);
console.log(Object.getPrototypeOf(myArray));

3.3 Prototypal Inheritance
On calling the new() operator, all the properties and methods defined on the prototype will become accessible to the instance objects. This process is called Prototypal Inheritance.

4. Built-in Function Constructor Function:

4.1 Default Properties and Methods

Properties:

name
length
constructor
prototype, etc.

Methods:

apply()
bind()
call()
toString(), etc.

4.2 Creating a Function with the new Operator (Older way of writing):

Syntax: let myFunction = new Function("param1, param2, ...", function body);

let Car = new Function("color, brand",
  `this.color = color;
   this.brand = brand;
   this.start = function() {
     console.log("started");
  };`);

console.log(Function.prototype);

5. Instance Specific and Prototype Properties:

5.1 Prototype Properties/ Methods
The Prototype Properties/ Methods are the properties or methods common across the instance objects.

Examples:

calculateAge
displayGreetings
displayProfileDetails
calculateIncome

5.1.1 Adding a Method to the prototype

function Person(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
}

Person.prototype.displayFullName = function() {
  return this.firstName + " " + this.lastName;
};

let person1 = new Person("Virat", "Kohli");
let person2 = new Person("Sachin", "Tendulkar");

console.log(Object.getPrototypeOf(person1) === Object.getPrototypeOf(person2));

5.2 Instance Specific Properties/ Methods

The Instance Specific Properties/ Methods are the properties or methods specific to the instance object.

Examples:

gender
yearOfBirth
friendsList
name

function Person(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
}

Person.prototype.displayFullName = function() {
  return this.firstName + " " + this.lastName;
};

let person1 = new Person("Virat", "Kohli");
console.log(Object.getOwnPropertyNames(person1));

JS Classes | Cheat Sheet:
----------------------------------

1. Class
 The class is a special type of function used for creating multiple objects.

1.1. Constructor Method
The constructor method is a special method of a class for creating and initializing an object of that class.

Syntax:

class MyClass {
  constructor(property1, property2) {
    this.property1 = property1;
    this.property2 = property2;
  }
  method1() { ... }
  method2() { ... }
}

1.1.1 Creating a Single Object

Syntax :

class MyClass {
  constructor(property1, property2) {
    this.property1 = property1;
    this.property2 = property2;
  }
  method1() { ... }
  method2() { ... }
}
let myObject = new MyClass(property1, property2);

Example:

class Person {
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
 }
 displayFullName() {
   return this.firstName + " " + this.lastName;
 }
}
let person1 = new Person("Virat", "Kohli");

console.log(person1);  // Person {...}

1.1.2 Creating Multiple Objects

class Person {
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }
}
let person1 = new Person("Virat", "Kohli");
let person2 = new Person("Sachin", "Tendulkar");

console.log(person1);  // Person {...}
console.log(person2);  // Person {...}

1.2 Prototype property of a Class

class Person {
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }
  displayFullName() {
   return this.firstName + " " + this.lastName;
  }
}
let person1 = new Person("Virat", "Kohli");

console.log(Person.prototype);  // Person {...}

1.3 Prototype of an Instance
The Instance Prototype refers to the prototype object of the constructor function.

class Person {
  constructor(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
  }
  displayFullName() {
   return this.firstName + " " + this.lastName;
  }
}
let person1 = new Person("Virat", "Kohli");

console.log(Object.getPrototypeOf(person1));  // Person {...}

Note
The Type of a class is a function

2.Inheritance in JS Classes
The Inheritance is a mechanism by which a class inherits methods and properties from another class.

2.1 Extends
The extends keyword is used to inherit the methods and properties of the superclass.

2.2 Super
Calling super() makes sure that SuperClass constructor() gets called and initializes the instance.

Syntax :

class SuperClass {
}
class SubClass extends SuperClass{
  constructor(property1, property2){
    super(property1);
    this.property2 = property2;
  }
  method1() {  }
}
let myObject = new SubClass(property1, property2);

Here, SubClass inherits methods and properties from a SuperClass.

2.3 Method Overriding
Here the constructor method is overridden. If we write the SuperClass methods in SubClass, it is called method overriding.

Syntax :

class SuperClass {
}
class SubClass extends SuperClass{
  constructor(property1, property2){
    super(property1);
    this.property2 = property2;
  }
}
let myObject = new SubClass(property1, property2);

Example :

class Animal {
  constructor(name) {
    this.name = name;
  }
  eat() {
    return `${this.name} is eating`;
  }
  makeSound() {
    return `${this.name} is shouting`;
  }
}
class Dog extends Animal {
  constructor(name, breed) {
    super(name);
    this.breed = breed;
  }
  sniff() {
    return `${this.name} is sniffing`;
  }
}
class Cat extends Animal {
  constructor(name, breed) {
    super(name);
    this.breed = breed;
  }
  knead() {
    return `${this.name} is kneading`;
  }
}
let animal1 = new Animal("gorilla");
let someDog = new Dog("someDog", "German Shepherd");
let persianCat = new Cat("someCat", "Persian Cat");

console.log(animal1);  // Animal {...}
console.log(animal1.eat());  // gorilla is eating

console.log(someDog);  // Dog {...}
console.log(someDog.eat());  // someDog is eating 
console.log(someDog.sniff());  // someDog is sniffing

console.log(persianCat);  // Cat {...}
console.log(persianCat.knead());  // someCat is kneading
console.log(persianCat.eat());  // someCat is eating
console.log(persianCat.makeSound());  // someCat is shouting

Try out creating superclass and subclass with multiple objects in the JavaScript Code Playground.


3.this in classes
3.1 Super Class
In class, this refers to the instance object.

class Animal {
  constructor(name) {
    this.name = name;
 }
 eat() {
   return this;  
 }
 makeSound() {
   return `${this.name} is shouting!`;
 }
}
let animal1 = new Animal("dog");

console.log(animal1.eat());  // Animal {...}

Here this refers to the animal1.

3.2 Sub Class

class Animal {
    constructor(name) {
    this.name = name;
  }
}

class Dog extends Animal {
  constructor(name, breed) {
    super(name);
    this.breed = breed;
  }
  sniff() {
    return this;
  }
}
let dog = new Dog("dog", "german Shepherd");

JS CODING PRACTICE 5:
--------------------------------------

Advanced Technologies:
------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function AdvancedTechnologies(technology1, technology2,technology3) {

  /* Write your code here */
  this.technology1 = technology1;
  this.technology2 = technology2;
  this.technology3 = technology3;

}

/* Please do not modify anything below this line */  

function main() {
  const technology1 = readLine();
  const technology2 = readLine();
  const technology3 = readLine();
    
  const inDemandTechnologies = new AdvancedTechnologies(technology1, technology2, technology3);
    
  console.log(inDemandTechnologies);
}

Input:

Artificial Intelligence
Virtual Reality
Cyber Security

Output:

AdvancedTechnologies {
  technology1: 'Artificial Intelligence',
  technology2: 'Virtual Reality',
  technology3: 'Cyber Security'
}

Spacecraft launch:
-----------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Spacecraft(name) {
  this.name = name;
  /* Write your code here */
  this.launch = function() {
      console.log(`${this.name} launched`);
  };
}

/* Please do not modify anything below this line */

function main() {
  const spacecraftName = readLine();
  const spacecraft = new Spacecraft(spacecraftName);
  spacecraft.launch();
}

Input:

Chandrayaan-2

Output:

Chandrayaan-2 launched

Area and perimeter of rectangle:
-----------------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Rectangle(length, breadth) {
  
  /* Write your code here */
  this.l = length;
  this.b = breadth;
  this.getArea = function() {
      return this.l * this.b
  }
  this.getPerimeter = function() {
      return 2*(this.l + this.b)
  }
  

}

/* Please do not modify anything below this line */

function main() {
  const l = JSON.parse(readLine());
  const b = JSON.parse(readLine());
  
  const rectangle = new Rectangle(l, b);
  
  console.log(rectangle.getArea());
  console.log(rectangle.getPerimeter());
}

Input:

10
50

Output:

500
120

wage per hour:
-------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */
function Employee(income, workingHours) {
  
  /* Write your code here */
  this.income = income;
  this.workingHours =workingHours;
  this.getWagePerHour = function () {
  const wagePerHour = this.income / this.workingHours
  return wagePerHour;
  
  };

}

/* Please do not modify anything below this line */

function main() {
  const income = readLine();
  const workingHours = readLine();
  
  const employee1 = new Employee(income, workingHours);
  
  console.log(employee1.getWagePerHour());
}

Input:

120
6

Output:

20

Bride and groom:
----------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Marriage(couple) {
  /* Write your code here */
  let {bride, groom} = couple;

  this.bride = bride;
  this.groom = groom;
  this.family = function() {  
    console.log(`Mr & Mrs ${this.groom}`);
  };
}

/* Please do not modify anything below this line */

function main() {
  const couple = JSON.parse(readLine().replace(/'/g, '"'));
  
  const marriedCouple = new Marriage(couple);
  marriedCouple.family();
}

Input:

{'bride':'Sita', 'groom':'Ram'}

Output:

Mr & Mrs Ram

JS CODING PRACTICE 6:
-----------------------------------------------

Arithmetic Operations:
----------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString.trim().split("\n").map((str) => str.trim());
  main();
});

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function ArithmeticOperations(firstNumber, secondNumber) {
  this.firstNumber = firstNumber;
  this.secondNumber = secondNumber;
}

function main() {
  const firstNumber = JSON.parse(readLine());
  const secondNumber = JSON.parse(readLine());
  
  const operation1 = new ArithmeticOperations(firstNumber, secondNumber);
  
  ArithmeticOperations.prototype.sumOfNumbers = function() {
      const sum = this.firstNumber + this.secondNumber
      return sum
  }
  ArithmeticOperations.prototype.productOfNumbers = function() {
      const product = this.firstNumber * this.secondNumber
      return product
  }
  ArithmeticOperations.prototype.differenceOfNumbers = function() {
      const difference = this.firstNumber - this.secondNumber
      return difference
  }
  /* Write your code here */

  console.log(operation1.sumOfNumbers());
  console.log(operation1.productOfNumbers());
  console.log(operation1.differenceOfNumbers());
}

Input:

8
4

Output:

12
32
4

Travel Kit:
------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Travel(kit, item) {
  this.kit = kit;
  this.item = item;
}

function main() {
  const travelBag = {
    ticket : "Hyderabad-Vizag",
    clothes: ["Shirt", "T-Shirt","Jeans"],
    medicines: "Paracetamol",
    waterBottle: true,
    snacks:true
  };
  
  const item = readLine();
  
  const travelKit = Object.getOwnPropertyNames(travelBag);    
  const travel = new Travel(travelKit, item);
  Travel.prototype.isKitContainsItem = function() {
      return this.kit.includes(this.item)
  }
  console.log(travel.isKitContainsItem())

  /* Write your code here */
}

Input:

ticket

Output:

true

Object with given shape:
-------------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {

  const objectEntities = [
    {
      shape: "circle",
      color: "Green"
    },
    {
      shape: "circle",
      color: "White"
    },
    {
      shape: "triangle", 
      color: "Orange"
    }
  ];
  
  const shape = readLine();
  
  /* Write your code here and log the output */
  const arrayOfObject = []
  for (let object of objectEntities) {
      if (object.shape === shape) {
          arrayOfObject.push(object);
      }
  }
  console.log(arrayOfObject)
}

Input:

circle

Output:

[
  { shape: 'circle', color: 'Green' },
  { shape: 'circle', color: 'White' }
]

Object with given color:
--------------------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {

  const objectEntities = [
    {
      shape: "circle",
      color: "Green"
    },
    {
      shape: "circle",
      color: "White"
    },
    {
      shape: "triangle", 
      color: "Orange"
    }
  ];

  const color = readLine();
  const arrayOfObject = []
  for (let object of objectEntities) {
      if (object.color === color) {
          arrayOfObject.push(object)
      }
  }
  console.log(arrayOfObject)
  /* Write your code here and log the output */
}

Input:

Green

Output:

[ { shape: 'circle', color: 'Green' } ]

Airplane:
----------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Airplane(name, inAir) {
  this.name = name;
  this.isFlying = inAir;
}

function main() {
  const airplaneName = readLine();
  const inAir = JSON.parse(readLine());
  
  const airplane = new Airplane(airplaneName, inAir);
  Airplane.prototype.takeOff = function() {
      this.isFlying = true;
      console.log(`${this.name} is taking off`)
  }
  Airplane.prototype.land = function() {
      this.isFlying = false;
      console.log(`${this.name} is landing`)
  }
  if (inAir === true) {
      airplane.land();
  }else{
      airplane.takeOff()
  }

  /* Write your code here */
  console.log(`Is Airplane flying? ${airplane.isFlying}`);
}

Input:

Boeing Air Bus
true

Output:

Boeing Air Bus is landing
Is Airplane flying? false

JS CODING PRACTICE 7:
------------------------------------

Laptop:
--------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

class Laptop {
  constructor(color,brand,battery,notifications) {
      this.color = color
      this.brand = brand
      this.battery = battery
      this.notifications = notifications
      
  }
  /* Write your code here */

}

/* Please do not modify anything below this line */

function main() {
  const color = readLine();
  const brand = readLine();
  const battery = parseInt(readLine());
  const notifications = parseInt(readLine());
  
  const laptop1 = new Laptop(color, brand, battery, notifications);
  
  console.log(laptop1.color); 
  console.log(laptop1.brand); 
  console.log(laptop1.battery);
  console.log(laptop1.notifications);
}

Input:

White
Apple
100
0

Output:

White
Apple
100
0

Laptop Turn - ON/OFF:
-----------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

class Laptop {
  /* Write your code here */
  constructor(color, brand, battery, notifications, turnOn) {
      this.color = color
      this.brand = brand
      this.battery = battery
      this.notifications = notifications
      this.isTurnOn = turnOn
  }
  turnOn() {
      this.isTurnOn = true;
  }
  turnOff() {
      this.isTurnOn = false;
      
  }

}

/* Please do not modify anything below this line */

function main() {
  const color = readLine();
  const brand = readLine();
  const battery = parseInt(readLine());
  const notifications = parseInt(readLine());
  const turnOn = JSON.parse(readLine());
  
  const laptop1 = new Laptop(color, brand, battery, notifications, turnOn);
  
  console.log(laptop1.isTurnOn); // As Laptop is not yet turned on, it should print false.
  laptop1.turnOn(); //The Laptop is turned on.
  console.log(laptop1.isTurnOn); // As Laptop is turned on, it should print true.
  laptop1.turnOff(); //The Laptop is turned off.
  console.log(laptop1.isTurnOn) // As Laptop is turned on, it should print false.
}

Input:

Silver
Lenovo
80
2
true

Output:

true
true
false

Laptop charging:
-----------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

class Laptop {
  constructor(color, brand, battery, notifications) {
    this.color = color;
    this.brand = brand;
    this.battery = battery;
    this.notifications = notifications;
    this.isTurnOn = false;
  }

  turnOn() {
    this.isTurnOn = true;
  }

  turnOff() {
    this.isTurnOn = false;
  }
  
  /* Write your code here */
  
  charging() {
      if (this.battery < 100){
          this.battery = 100
          console.log(`Laptop Charged ${this.battery}%`)
      }else{
          console.log(`Laptop Fully Charged`)
      }
  }
}

/* Please do not modify anything below this line */

function main() {
  const color = readLine();
  const brand = readLine();
  const battery = parseInt(readLine());
  const notifications = parseInt(readLine());

  const laptop1 = new Laptop(color, brand, battery, notifications);
  
  laptop1.turnOn(); // The Laptop Turned On.
 
  console.log(`Laptop Charged ${laptop1.battery}%`); // The Laptop battery charged percentage.
  
  laptop1.charging(); // The Laptop charging.
}

Input:

Gold
Lenovo
75
1

Output:

Laptop Charged 75%
Laptop Charged 100%

Laptop charger Removal:
---------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

class Laptop {
  constructor(color, brand, battery, notifications) {
    this.color = color;
    this.brand = brand;
    this.battery = battery;
    this.notifications = notifications;
    this.isTurnOn = false;
  }

  turnOn() {
    this.isTurnOn = true;
  }

  turnOff() {
    this.isTurnOn = false;
  }

  /* Write your code here */
   removeCharging() {
      console.log(`Please remove charger`)
  }

  charging() {
    if (this.battery < 100) {
      this.battery = 100;
      console.log(`Laptop Charged ${this.battery}%`);
    } else {
      console.log(`Laptop Fully Charged`);
      /* Write your code here */ 
       this.removeCharging()
    }
  }
}

/* Please do not modify anything below this line */

function main() {
  const color = readLine();
  const brand = readLine();
  const battery = parseInt(readLine());
  const notifications = parseInt(readLine());

  const laptop1 = new Laptop(color, brand, battery, notifications);
  
  laptop1.turnOn(); // Laptop Turned On
 
  console.log(`Laptop Charged ${laptop1.battery}%`); // Laptop battery charged percentage.
  
  laptop1.charging(); // Laptop charging
}


Input:

Rose Gold
Apple
100
0

Output:

Laptop Charged 100%
Laptop Fully Charged
Please remove charger

Laptop Notifications:
--------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

class Laptop {
  constructor(color, brand, battery, notifications) {
    this.color = color;
    this.brand = brand;
    this.battery = battery;
    this.notifications = notifications;
    this.isTurnOn = false;
  }

  turnOn() {
    this.isTurnOn = true;
  }

  turnOff() {
    this.isTurnOn = false;
  }
 /* Write your code here */
 message() {
     console.log("You got a message")
 }
 getNotification() {
     this.notifications = this.notifications + 1 
     console.log(`You have ${this.notifications} notifications`)
 }
 clearNotifications() {
     console.log("Notifications are cleared")
 }

}

/* Please do not modify anything below this line */

function main() {
  const color = readLine();
  const brand = readLine();
  const battery = parseInt(readLine());
  const notifications = parseInt(readLine());

  const laptop1 = new Laptop(color, brand, battery, notifications);
  
  laptop1.turnOn(); //The Laptop is turned on.
  laptop1.getNotification(); // Increment the notifications by 1.
  laptop1.message(); // 'You got a message' will be logged.
  laptop1.getNotification(); // Increment the notifications by 1.
  laptop1.clearNotifications(); // 'Notifications are cleared' will be logged.
}

Input:

Black
Apple
50
0

Output:

You have 1 notifications
You got a message
You have 2 notifications
Notifications are cleared

Tiger:
------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

class Animal {
  /* Write your code here */
  constructor(species) {
      this.species = species
      
  }
  eat() {
      console.log(`${this.species} is eating`)
  }

}

class Tiger extends Animal {
  constructor(species, age) {
    super(species);
    this.age = age;
  }

  hunt() {
    console.log(`A ${this.age} years old ${this.species} is hunting`);
  }

  roar() {
    console.log(`${this.species} is roaring`);
  }
}

/* Please do not modify anything below this line */

function main() {
  const species = readLine();
  const age = parseInt(readLine());
  
  const tiger1 = new Tiger(species, age);

  tiger1.eat();
}

Input:

Bengal tiger
10

Output:

Bengal tiger is eating

Fighter Jet:
---------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

class Aircraft {
  constructor() {
    this.flying = false;
  }

  takeOff() {
    this.flying = true;
  }

  land() {
    this.flying = false;
  }
}

class FighterJet extends Aircraft {

  /* Write your code here */
  constructor (missilesLoaded, missilesFired) {
      super();
      this.missiles = missilesLoaded;
      this.missilesFired = missilesFired;
  }
  fireMissiles() {
      this.missiles = this.missiles - this.missilesFired;
      console.log(`${this.missilesFired} Missiles Fired`)
  }

}

/* Please do not modify anything below this line */

function main() {
  const missilesLoaded = parseInt(readLine());
  const missilesFired = parseInt(readLine());  
  
  const fighterJet = new FighterJet(missilesLoaded, missilesFired);
  
  fighterJet.takeOff();
  fighterJet.fireMissiles();
  console.log(`${fighterJet.missiles} Missiles Left`);
  fighterJet.land();
}

Input:

5
2

Output:

2 Missiles Fired
3 Missiles Left


JS Promises | Cheat Sheet:
----------------------------------------------------

1. Synchronous Execution
Example :

alert("First Line");
alert("Second Line");
alert("Third Line");

The code executes line by line. This behavior is called synchronous behavior, in JS alert works synchronously.

2. Asynchronous Execution
Example 1:

const url = "https://apis.ccbp.in/jokes/random";

fetch(url)
  .then((response) => {
    return response.json();
  })
  .then((jsonData) => {
    //statement-1
    console.log(jsonData); // Object{ value:"The computer tired when it got home because it had a hard drive" }
  });

//statement-2
console.log("fetching done"); // fetching done

In the above example, the second statement won’t wait until the first statement execution. In JS, fetch() works asynchronously.

3. JS Promises
Promise is a way to handle Asynchronous operations.

A promise is an object that represents a result of operation that will be returned at some point in the future.

Example :

const url = "https://apis.ccbp.in/jokes/random";
let responseObject = fetch(url);

console.log(responseObject); // Promise{ [[PromiseStatus]]:pending, [[PromiseValue]]:undefined }
console.log("fetching done"); // fetching done

Note:
A promise will be in any one of the three states:

Pending : Neither fulfilled nor rejected
Fulfilled : Operation completed successfully
Rejected : Operation failed

3.1 Resolved State
When a Promise object is Resolved, the result is a value.

const url = "https://apis.ccbp.in/jokes/random";
let responsePromise = fetch(url);

responsePromise.then((response) => {
  console.log(response); // Response{ … }
});

3.2 Rejected State
Fetching a resource can be failed for various reasons like:

URL is spelled incorrectly
Server is taking too long to respond
Network failure error, etc.

const url = "https://a.ccbp.in/random";
let responsePromise = fetch(url);

responsePromise.then((response) => {
  return response;
});
responsePromise.catch((error) => {
  console.log(error); // TypeError{ "Failed to fetch" }
});

3.3 Promise Chaining
Combining multiple .then()s or .catch()s to a single promise is called promise chaining.

Syntax :

const url = "INCORRECT_RESOURCE_URL";
let responsePromise = fetch(url);

responsePromise
  .then((response) => {
    console.log(response);
  })
  .catch((error) => {
    console.log(error);
  });
  
3.3.1 OnSuccess Callback returns Promise
Here, log the response in JSON format.

const url = "RESOURCE_URL";
let responsePromise = fetch(url);

responsePromise.then((response) => {
  console.log(response.json());
});

3.3.2 Chaining OnSuccess Callback again

const url = "https://apis.ccbp.in/jokes/random";
let responsePromise = fetch(url);

responsePromise
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    console.log(data);
  });
  
3.4 Fetch with Error Handling
Check the behavior of code with valid and invalid URLs.

const url = "https://apis.ccbp.in/jokes/random";
let responsePromise = fetch(url);

responsePromise
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    console.log(data); // Object { value: "They call it the PS4 because there are only 4 games worth playing!"
  })
  .catch((error) => {
    console.log(error);
  });
  
JS Promises | Part 2 | Cheat Sheet:
-------------------------------------------------------------

1. Asynchronous JS code style
There are two main types of asynchronous code style you'll come across in JavaScript:

Callback based
Example : setTimeout(), setInterval()

Promise based
Example : fetch()

2. Creating your own Promises
Promises are the new style of async code that you'll see used in modern JavaScript.

Syntax :

const myPromise = new Promise((resolveFunction, rejectFunction) => {
      //Async task
});

In the above syntax:

The Promise constructor takes a function (an executor) that will be executed immediately and passes in two functions: resolve, which must be called when the Promise is resolved (passing a result), and reject when it is rejected (passing an error).
The executor is to be executed by the constructor, during the process of constructing the new Promise object.
resolveFunction is called on promise fulfilled.
rejectFunction is called on promise rejection.

Example :

const myPromise = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve();
    }, 1000);
  });
};

console.log(myPromise());

2.1 Accessing Arguments from Resolve
When resolve() is excuted, callback inside then() will be executed.

Example :

const myPromise = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve("Promise Resolved");
    }, 1000);
  });
};

myPromise().then((fromResolve) => {
  console.log(fromResolve); // Promise Resolved
});

2.2 Accessing Arguments from Reject
When reject() is excuted, callback inside catch() will be executed.

Example :

const myPromise = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      reject("Promise Rejected");
    }, 2000);
  });
};

myPromise()
  .then((fromResolve) => {
    console.log(fromResolve);
  })
  .catch((fromReject) => {
    console.log(fromReject); // Promise Rejected
  });
  
3. Async/Await
The Async/Await is a modern way to consume promises.
The Await ensures processing completes before the next statement executes.

Syntax :

const myPromise = async () => {
  let promiseObj1 = fetch(url1);
  let response1 = await promiseObj1;
  let promiseObj2 = fetch(url2);
  let response2 = await promiseObj2;
};

myPromise();

Note
Use async keyword before the function only if it is performing async operations.
Should use await inside an async function only.

3.1 Fetch with Async and Await
Example :

const url = "https://apis.ccbp.in/jokes/random";

const doNetworkCall = async () => {
  const response = await fetch(url);
  const jsonData = await response.json();
  console.log(jsonData);
};

doNetworkCall();

3.2 Error Handling with Async and Await
Example :

const url = "https://a.ccbp.in/jokes/random";

const doNetworkCall = async () => {
  try {
    const response = await fetch(url);
    const jsonData = await response.json();
    console.log(jsonData);
  } catch (error) {
    console.log(error);
  }
};

doNetworkCall();

3.3 Async Function always returns Promise
Example :

const url = "https://apis.ccbp.in/jokes/random";

const doNetworkCall = async () => {
  const response = await fetch(url);
  const jsonData = await response.json();
  console.log(jsonData);
};

const asyncPromise = doNetworkCall();
console.log(asyncPromise);

4. String Manipulations
There are methods and properties available to all strings in JavaScript.

String Methods							Functionality
toUpperCase(), toLowerCase()			Converts from one case to another
includes(), startsWith(), endsWith()	Checks a part of the string
split()									Splits a string
toString()								Converts number to a string
trim(), replace()						Updates a string
concat(), slice(), substring()			Combines & slices strings
indexOf()								Finds an index

4.1 trim()
The trim( ) method removes whitespace from both ends of a string.

Syntax : string.trim()

const greeting = "   Hello world!  ";
console.log(greeting);
console.log(greeting.trim());

4.2 slice()
The slice() method extracts a section of a string and returns it as a new string, without modifying the original string.

Syntax : string.slice(start, end)
const text = "The quick brown fox";
console.log(text.slice(0, 3)); // The
console.log(text.slice(2, 3)); // e

4.3 toUpperCase()
The toUpperCase() method converts a string to upper case letters.

Syntax : string.toUpperCase()

const text = "The quick brown fox";
console.log(text.toUpperCase()); // THE QUICK BROWN FOX

4.4 toLowerCase()
The toLowerCase() method converts a string to lower case letters.

Syntax : string.toLowerCase()

const text = "Learn JavaScript";
console.log(text.toLowerCase()); // learn javascript

4.5 split()
The split() method is used to split a string into an array of substrings and returns the new array.

Syntax : string.split(separator, limit)

const str = "He-is-a-good-boy";
const words = str.split("-");

console.log(words); // ["He", "is", "a", "good", "boy"]

4.6 replace()
The replace() method searches a string for a specified value, or a regular expression, and returns a new string where the specified values are replaced.

Syntax : string.replace(specifiedvalue, newvalue)

const str = "Welcome to Hyderabad";
const words = str.replace("Hyderabad", "Guntur");

console.log(words); // Welcome to Guntur

4.7 includes()
The includes() method determines whether a string contains the characters of a specified string.

It returns true if the string contains the value, otherwise it returns false.

Syntax : string.includes(searchvalue, start)

const str = "Learn 4.0 Technologies";
const word = str.includes("Tech");
const number = str.includes("5.0");

console.log(word); // true
console.log(number); // false

4.8 concat()
The concat() method is used to join two or more strings.

Syntax : string.concat(string1, string2, ..., stringX)

const str1 = "Hello";
const str2 = "World";
console.log(str1.concat(str2)); // HelloWorld
console.log(str1.concat(" Pavan", ". Have a nice day.")); // Hello Pavan. Have a nice day.

4.9 indexOf()
The indexOf() method returns the position of the first occurrence of a specified value in a string.

Syntax : string.indexOf(searchvalue, start)

const str = "Building Global Startups";
console.log(str.indexOf("Global")); // 9
console.log(str.indexOf("up")); // 21

4.10 startsWith()
The startsWith() method determines whether a string begins with the characters of a specified string, returning true or false as appropriate.

Syntax : string.startsWith(searchvalue, start)

const str = "World-class Products";
console.log(str.startsWith("rld")); // false
console.log(str.startsWith("World")); // true

4.11 endsWith()
The endsWith() method determines whether a string ends with the characters of a specified string, returning true or false as appropriate.

Syntax : string.endsWith(searchvalue, length)

const str = "How are you?";
console.log(str.endsWith("you?")); // true
console.log(str.endsWith("re")); // false

4.12 toString()
The toString() method returns the value of a string object.

Syntax : string.toString()

const number = 46;
const newNumber = number.toString();

console.log(newNumber); // 46
console.log(typeof newNumber); // string

4.13 substring()
The substring() method returns the part of the string between the start and end indexes, or to the end of the string.

Syntax : string.substring(start, end)

const str = "I am learning JavaScript";
console.log(str.substring(2, 9)); // am lear
console.log(str.substring(6)); // earning JavaScript

4.14 Length
The length property returns the length of a string (number of characters).

Syntax : string.length

const str = "Upgrade to CCBP Tech 4.0 Intensive";
console.log(str.length); // 34

JS CODING PRACTICE 8:
--------------------------------------

Resolve with pin:
---------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const pin = parseInt(readLine());
  
  const myPromise = () => {
      return new Promise((resolve, reject) => {
          resolve(pin);
      });
  } ;
  
  /* Write your code here */
  myPromise().then(response => console.log(response))
}

Input:

200

Output:

200

Reject with message:
-------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const errorMessage = readLine();
  /* Write your code here */
   const myPromise = () => {
      return new Promise((resolve, reject) => {
          reject(errorMessage);
      });
  } ;
  
  /* Write your code here */
  myPromise().catch(error => console.log(error))
}

Input:

Request Rejected

Output:

Request Rejected

Validate user pin:
-----------------------------

function main() {
  const userInput = parseInt(readLine());
  const correctPin = 9372;
  /* Write your code here */
  const myPromise = () => {
      return new Promise((resolve, reject) => {
          if (userInput === correctPin) {
              resolve('Success');
          }
          else {
              reject('Please enter valid pin')
          }
      });
  } ;
   myPromise()
   .then(response => console.log(response))
   .catch(error => console.log(error))
}

Input:

9372

Output:

Success

Tree Planting:
---------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const isResourceAvailable = JSON.parse(readLine());
  
  /* Write your code here */
  const plantTree = () => {
      return new Promise((resolve, reject) => {
          if (isResourceAvailable) {
              resolve('Tree Planted');
          }
          else {
              reject('Resource not available')
          }
      });
  } ;
  
  const myPromise = async () => {
      try{
          const plantingStatus = await plantTree();
          console.log(plantingStatus);
      } catch(error) {
          console.log(error)
      }
  };
  myPromise();
}

Input:

true

Output:

Tree Planted

Search user:
-----------------------

function main() {
  const userName = readLine();
  const users = ["Abhiram", "Gabrill", "Mosh", "Alia", "Rehman", "Manoj"];
  
  /* Write your code here */
  const searchUser = () => {
      return new Promise((resolve, reject) => {
          let isUserFound = users.includes(userName);
          
          if (isUserFound) {
              resolve('User Found');
          }
          else {
              reject('User Not Found')
          }
      });
  };
  
  const myPromise = async () => {
      try{
          const result = await searchUser();
          console.log(result);
      } catch(error) {
          console.log(error)
      }
  };
  myPromise();
}

Input:

Abhiram

Output:

User Found

search employee in a company:
----------------------------------------

function main() {
  const companyId = readLine();
  const employeeId = parseInt(readLine());

  const companies = [
    {
      companyCode:"PY234",
      employees: [293, 730, 637]
    },
    {
      companyCode:"GR023",
      employees:[823, 563]
    }, 
    {
      companyCode:"HC754",
      employees: [511, 529, 943]
    }, 
    {
      companyCode:"PA439",
      employees: [276, 188, 333]
    }, 
    {
      companyCode:"CX536",
      employees: [431, 923]
    },
    {
      companyCode:"RD310",
      employees: [356, 901]
    }
  ];
  
  /* Write your code here */
  const companyDetails = ()=> {
      return new Promise((resolve,reject)=>{
          const companyObject = companies.find(eachComapny=>eachComapny.companyCode === companyId);
		  
          if (companyObject !== undefined) {
              const isEmployeeFound = companyObject.employees.includes(employeeId);
              if(isEmployeeFound) {
                  resolve("Employee Found");
              }else{
                  reject("Employee Not Found");
              }
              }else{
                  reject("Company Not Found");
          }
      }) 
  }
  const myPromise = async () => {
      try{
          let result = await companyDetails();
          console.log(result);
      } catch (rejection) {
          console.log(rejection);
      }
  }
  myPromise();
}

Input:

YR001
293

Output:

Company Not Found

campfire: => Ternary
----------------------------

function main() {
  const isSticksFound = JSON.parse(readLine());
  const isLighterFound = JSON.parse(readLine());

  /* Write your code here */
  const gatherSticks = () => {
      return new Promise((resolve, reject) =>{
          isSticksFound ? resolve("Sticks Gathered") : reject("Sticks Not Found")
      })
      
  }
 const arrangeStivks = () => {
    return new Promise((resolve,reject)=>{
        resolve("Sticks Arranged")
    })
    
}
 const arrangeLighter = () => {
    return new Promise((resolve,reject)=>{
        isLighterFound ? resolve("Campfire Lighted") : reject("Lighter Not Found")
    })
 }
 const myPromise = async () => {
     try {
         const firstTask = await gatherSticks();
         console.log(firstTask);
         const secondTask = await arrangeStivks();
         console.log(secondTask);
         const thiredTask = await arrangeLighter();
         console.log(thiredTask);
     } catch (error) {
         console.log(error)
     }
 }
myPromise()
}

Input:

true
true

Output:

Sticks Gathered
Sticks Arranged
Campfire Lighted

JS CODING PRACTICE 9:
-------------------------------------------------------------

Trim the string:
---------------------------

function main() {
  const inputString = JSON.parse(readLine().replace(/'/g, '"'));
  /* Write your code here */
  const lengthBeforeTrim = inputString.length;
  const trimmedString = inputString.trim();
  const lengthAfterTrim = trimmedString.length;
  
  console.log(lengthBeforeTrim);
  console.log(lengthAfterTrim);
  
}

Input:

"      JavaScript"

Output:

16
10

Ends with a substring:
--------------------------------

function main() {
  const inputString = readLine();
  const searchString = readLine();
  /* Write your code here */
  const r = inputString.endsWith(searchString)
  console.log(r);
}

Input:

Iron man
man

Output:

true

string starting with vowel:
---------------------------------------------

function main() {
  const inputString = readLine();
  const vowels = ['a', 'e', 'i', 'o', 'u'];
  
  /* Write your code here */
  let isStartsWithVowels = false;
  const lowerCaseString = inputString.toLowerCase()
  for (let letter of vowels) {
      const result = lowerCaseString.startsWith(letter);
      if (result) {
          isStartsWithVowels = true;
      }
  }
  if (isStartsWithVowels) {
      console.log(isStartsWithVowels);
      
  }else {
      console.log(false)
  }

}

Input:

India

Output:

true

Array of Substrings in uppercase:
-----------------------------------------------

function main() {
  const inputString = readLine();

  /* Write your code here */
  const word = inputString.toUpperCase()
  console.log(word.split(" "))
}

Input:

The Twilight Saga

Output:

[ 'THE', 'TWILIGHT', 'SAGA' ]

Concatenate strings:
------------------------------------

function main() {
  const firstString = readLine();
  const secondString = readLine();

  /* Write your code here */
  const word = firstString.concat(secondString);
  console.log(word.length);

}

Input:

Hawaii
islands

Output:

13

whether string includes:
------------------------------------------

function main() {
  const inputString = readLine();
  const searchString = readLine();
   
  /* Write your code here */
  const lS = inputString.toLowerCase();
  const newWord = lS.includes(searchString)
 
  console.log(newWord)
}

Input:

JavaScript
script

Output:

true

substring start with given string:
---------------------------------------------

function main() {
  const inputString = readLine();
  const searchString = readLine();
  const startIndex = parseInt(readLine());
  const endIndex = parseInt(readLine());

  /* Write your code here */
  const word = inputString.substring(startIndex,endIndex);
  const newWord = word.startsWith(searchString);
  console.log(newWord);

}

Input:

White microwave
White
0
5

Output:

true

Find and Replace:
-----------------------------------

function main() {
  const inputString = readLine();
  const searchString = readLine();
  const replaceString = readLine();
  
  /* Write your code here */
   let nweString = inputString;
  const index = inputString.indexOf(searchString);
  const isEvenIndex = index % 2 === 0
  if (isEvenIndex) {
      nweString = inputString.replace(searchString,replaceString);
  }
  console.log(nweString)

}

Input:

The cup is on the table
is
was

Output:

The cup was on the table

More JS Concepts | Cheat Sheet:
-----------------------------------------------------

1. Scoping
The Scope is the region of the code where a certain variable can be accessed.

In JavaScript there are two types of scope:

Block scope
Global scope

1.1 Block Scope
If a variable is declared with const or let within a curly brace ({}), then it is said to be defined in the Block Scope.

if..else
function (){}
switch
for..of, etc.

Example :

let age = 27;
if (age > 18) {
  let x = 0;
  console.log(x); // 0
}
console.log(x); //  ReferenceError{"x is not defined"}

1.2 Global Scope

If a variable is declared outside all functions and curly braces ({}), then it is said to be defined in the Global Scope.
When a variable declared with let or const is accessed, Javascript searches for the variable in the block scopes first followed by global scopes.

const x = 30;
function myFunction() {
  if (x > 18) {
    console.log(x); // 30
  }
}

myFunction();

2. Hoisting

2.1 Function Declarations
Hoisting is a JavaScript mechanism where function declarations are moved to the top of their scope before code execution.

let x = 15;
let y = 10;
let result = add(x, y);
console.log(result); // 25

function add(a, b) {
  return a + b;
}

2.2 Function Expressions
Function expressions in JavaScript are not hoisted.

myFunction();
let myFunction = function () {
  let x = 5;
  console.log(x); // ReferenceError{"Cannot access 'myFunction' before initialization"}
};

2.3 Arrow Functions
Arrow Functions in JavaScript are not hoisted.

myFunction();
let myFunction = () => {
  let x = 5;
  console.log(x); // ReferenceError{"Cannot access 'myFunction' before initialization"}
};

3. More Array Methods
The map(), forEach(), filter() and reverse() are some of the most commonly used array methods in JavaScript.

3.1 Map()
The map() method creates a new array with the results of calling a function for every array element.
The map() method calls the provided function once for each element in an array, in order.

Syntax : array.map(callback(currentValue, index, arr))

Here the callback is a function that is called for every element of array.
currentValue is the value of the current element and index is the array index of the current element. Here index and arr are optional arguments.

const numbers = [1, 2, 3, 4];
const result = numbers.map((number) => number * number);

console.log(result); // [1, 4, 9, 16]

3.2 forEach()
The forEach() method executes a provided function once for each array element. It always returns undefined.

Syntax : array.forEach(callback(currentValue, index, arr))

Here index and arr are optional arguments.

let fruits = ["apple", "orange", "cherry"];

fruits.forEach((fruit) => console.log(fruit));

3.3 filter()
The filter() method creates a new array filled with all elements that pass the test (provided as a function).

A new array with the elements that pass the test will be returned. If no elements pass the test, an empty array will be returned.

Syntax : array.filter(function(currentValue, index, arr))

Here index and arr are optional arguments.

const numbers = [1, -2, 3, -4];
const positiveNumbers = numbers.filter((number) => number > 0);

console.log(positiveNumbers); // [1, 3]

3.4 reduce()
The reduce() method executes a reducer function (that you provide) on each element of the array, resulting in single output value.

Syntax : array.reduce(function(accumulator, currentValue, index, arr), initialValue)

Here accumulator is the initialValue or the previously returned value of the function and currentValue is the value of the current element,
 index and arr are optional arguments.

const array1 = [1, 2, 3, 4];
const reducer = (accumulator, currentValue) => accumulator + currentValue;

console.log(array1.reduce(reducer)); // 10

3.5 every()
The every() method tests whether all elements in the array pass the test implemented by the provided function. It returns a Boolean value.

Syntax : array.every(function(currentValue, index, arr))

Here index and arr are optional arguments.

let array1 = [32, 33, 16, 20];
const result = array1.every((array1) => array1 < 40);

console.log(result); // true

3.6 some()
The some() method tests whether at least one element in the array passes the test implemented by the provided function. It returns a Boolean value.

Syntax : array.some(function(currentValue, index, arr))

Here index and arr are optional arguments.

const myAwesomeArray = ["a", "b", "c", "d", "e"];
const result = myAwesomeArray.some((alphabet) => alphabet === "d");

console.log(result); // true

3.7 reverse()
The reverse() method reverses the order of the elements in an array.The first array element becomes the last, and the last array element becomes the first.

Syntax : array.reverse()

const myArray = ["iBHubs", "CyberEye", "ProYuga"];
const reversedArray = myArray.reverse();

console.log(reversedArray); // ["ProYuga", "CyberEye", "iBHubs"]

3.8 flat()
The flat() method creates a new array with all sub-array elements concatenated into it recursively up to the specified depth.

Syntax : let newArray = arr.flat([depth]);

const arr1 = [0, 1, 2, [3, 4]];
const arr2 = [0, 1, 2, [[[3, 4]]]];

console.log(arr1.flat()); // [ 0,1,2,3,4 ]
console.log(arr2.flat(2)); // [0, 1, 2, [3, 4]]

4. Mutable & Immutable methods
Mutable methods will change the original array and Immutable methods won't change the original array.

Mutable methods	Immutable methods
shift()				map()
unshift()			filter()
push()				reduce()
pop()				forEach()
sort()				slice()
reverse()			join()
splice(), etc.		some(), etc.

Try out Mutable and Immutable methods in the JavaScript Code Playground.

Clean Code Guidelines:
---------------------------------------

1. Variable and Function names
1.1 Use intention-revealing names

Bad Code

const a = "Rahul";
const b = "Attuluri";
console.log(a);
console.log(b);

Clean Code

const firstName = "Rahul";
const lastName = "Attuluri";
console.log(firstName);
console.log(lastName);

1.2 Make your variable names easy to pronounce
Bad Code

let fName, lName;
let cntr;
let full = false;
if (cart.size > 100) {
 full = true;
}

Clean Code

let firstName, lastName;
let counter;
const maxCartSize = 100;
const isFull = cart.size > maxCartSize;

2. Better Functions
2.1 Less arguments are better
Bad Code

function Circle(x, y, radius) {
  this.x = x;
  this.y = y;
  this.radius = radius;
}

Clean Code

function Circle(center, radius) {
  this.x = center.x;
  this.y = center.y;
  this.radius = radius;
}

2.2 Use Arrow Functions when they make code cleaner
Bad Code

const count = 0;
function incrementCount(num) {
 return num + 1;
}

Clean Code

const count = 0;
const incrementCount = (num) => num + 1;

2.3 Use Async await for asynchronous code
Bad Code

myPromise
  .then(() => {
    return func1();
  })
  .then(() => {
    return func2();
  });
  
Clean Code

const doAllTasks = async () => {
  await myPromise;
  await func1();
  await func2();
};
doAllTasks();

JS CODING PRACTICE 10:
------------------------------------------

Multiply each value of an array by ten:
-------------------------------------------------

function main() {
  const myArray = JSON.parse(readLine());

  /* write your code here */
  const result = myArray.map((number) => number * 10);
  console.log(result);
}

Input:

[12, 2, 2, 4, 1]

Output:

[ 120, 20, 20, 40, 10 ]

Length of each string in array:
-----------------------------------------------

function main() {
  const myArray = JSON.parse(readLine().replace(/'/g,'"'));

   /* write your code here */
    const result = myArray.map((number) => number.length);
   console.log(result);
}

Input:

[ 'apple', 'mango', 'orange' ]

Output:

[ 5, 5, 6 ]

Filter the array values with even string length:
--------------------------------------------------------------

function main() {
  const myArray = JSON.parse(readLine().replace(/'/g, '"'));

  /* write your code here */
  const stringWithEvenLength = myArray.filter((number)=> number.length %2 === 0);
  console.log(...stringWithEvenLength);
}

Input:

[ 'apple', 'cherry', 'orange' ]

Output:

cherry orange

unique values in array:
----------------------------------------

function main() {
  const myArray = JSON.parse(readLine().replace(/'/g,'"'));
 
  /* Write your code here */
  const result = myArray.filter((value,index,array)=>array.indexOf(value) === index);
  console.log(result);
}

Input:

['3', '2', '3', '3', '4', '2', '5', '4', '3', '5', '10']

Output:

[ '3', '2', '4', '5', '10' ]

Average:
------------------------

function main() {
  const myArray = JSON.parse(readLine());

  /* Write your code here */ 
   const reducer = myArray.reduce((accumlator, currentValue) => (accumlator + currentValue));
  const result = reducer/myArray.length;
  console.log(result);
}

Input:

[12, 2, 2, 4, 1]

Output:

4.2

product:
----------------------

function main() {
  const myArray = JSON.parse(readLine()); 
  
  /* Write your code here */
  const result = myArray.reduce((acc, currentValue) => acc * currentValue);
  console.log(result);
}

Input:

[2, 2, 4, 1]

Output:

16

Filter the array values with odd string length:
---------------------------------------------------------------------------

function main() {
  const myArray = JSON.parse(readLine().replace(/'/g, '"'));

  /* Write your code here */
  const result = myArray.filter((number)=> number.length%2 === 1);
  const newResult = result.map((number)=> number.toUpperCase())
  
  console.log(...newResult);
}

Input:

['apple', 'cherry', 'orange']

Output:

APPLE

JS CODING PRACTICE 11:
-------------------------------------------

Average of values at even indices of array:
-------------------------------------------------------

function main() {
  const integers = JSON.parse(readLine());

  /* Write your code here */
  let sumOfValues = 0;
  integers.forEach((value,index)=>{
      if (index % 2 === 0 ) {
          sumOfValues = sumOfValues + value;
      }
  }) 
  const lengthOfArray = integers.length;
  const noOfevenIndices = Math.ceil(lengthOfArray/2);
  const average = sumOfValues / noOfevenIndices;
  console.log(average)
}

Input:

[ 12, 2, 2, 4, 1 ]

Output:

5

Flattening an array of arrays:
-------------------------------------------

function main() {
  const myArray = JSON.parse(readLine().replace(/'/g,'"'));

  /* Write your code here */
  const result = myArray.reduce((acc,currentValue)=>{
      return[...acc,...currentValue];
  });
  console.log(...result);
}

Input:

[  [ 'a', 'b' ],  [ 2, 3 ],  [ 'B', 'a' ],  [ 3, 4, 2,  5, 4, 3, 5, 10 ],  [ 'b' ]]

Output:

a b 2 3 B a 3 4 2 5 4 3 5 10 b

series of operations:
-------------------------------

function main() {
  const myArray = JSON.parse(readLine());

  /* Write your code here */
  const result = myArray.map((number)=> ((((number)*-4)+10)*3));
  console.log(...result);
}

Input:

[ 12, 2, 2, 4, 1 ]

Output:

-114 6 6 -18 18

people above the given age:
----------------------------------------

function main() {
  const ageLimit = parseInt(readLine());
  const peopleAge = JSON.parse(readLine());

  /* Write your code here */
  function eachAgeFromArray(eachArray) {
      return eachArray.every((age)=> age >ageLimit);
  }
  const result = peopleAge.map((number)=> eachAgeFromArray(number));
  console.log(result);
}

Input:

11
[ [ 12, 1, 2, 4, 1 ], [ 18, 20, 30, 45 ], [ 49, 12, 13, 24 ] ]

Output:

[ false, true, true ]

check the length of strings:
----------------------------------------

function main() {
  const min = parseInt(readLine());
  const max = parseInt(readLine());
  const words = JSON.parse(readLine().replace(/'/g,'"'));

  /* Write your code here */
  const wordLength = words.every((word) =>
  word.length >= min && word.length<=max
  
  )
  console.log(wordLength);
}

Input:

1
5
[ 'Koushik', 'Eshwar', 'Sai', 'Vinay' ]

Output:

false

sum of values in sub array:
------------------------------------------

function main() {
  const nestedArray = JSON.parse(readLine());

  /* Write your code here */
  function arraySum(arr) {
      let sum = arr.reduce((acc,currentValue) => acc + currentValue);
      return sum;
  }
  function findArrayLength(arr) {
      return arr.some((num)=> num%2 ===0);
  }
  const sumArray = nestedArray.map((eachArray)=> 
  findArrayLength(eachArray)?arraySum(eachArray):0)
  console.log(sumArray)
}

Input:

[ [ 12, 1, 2, 4, 1 ], [ 18, 20, 30, 45 ], [ 49, 11, 13, 21 ] ]

Output:

[ 20, 113, 0 ]

Find the ripen fruit:
---------------------------------

function main() {
  const fruits = JSON.parse(readLine().replace(/'/g,'"'));

  /* Write your code here */
  const result = fruits.some((each)=> each.state === "ripen");
  console.log(result?"Yes":"No");
}

Input:

[ { 'fruitName': 'apple', 'state': 'ripen' },  { 'fruitName': 'banana', 'state': 'rotten' } ]

output:

Yes

JS coding Assignment-1:
----------------------------------------------------------------

Final value with appreciation:
------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString.trim().split("\n").map((str) => str.trim());
  main();
});

function readLine() {
  let input = inputString[currentLine++]; 
  return input === undefined ? undefined : JSON.parse(input);
}

/* Please do not modify anything above this line */
  
  /* Write your code here */ 
  function calculateFinalValueWithAppreciation(principal,time=2,apprPercentage=5){
      return principal*(1+time*apprPercentage/100);
  }

/* Please do not modify anything below this line */

function main() {
  const principal = readLine();
  const time = readLine();
  const appreciation = readLine();

  const finalValue = calculateFinalValueWithAppreciation(principal, time, appreciation);

  console.log(finalValue);
}

Input:

1000
2
3

Output:

1060

Hotel Bill:
------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const dayCharge = JSON.parse(readLine());
  const days = parseInt(readLine());
 
  /* Write your code here */
  let bill,discount;
  bill = dayCharge*days;
  if (days>5) {
      discount = bill -(bill*15)/100;
  } else if (days>2) {
      discount = bill -(bill*5)/100;
  } else {
      discount = bill;
  }
  console.log(discount);
}

Input:

200
3

Output:

570

Manufacturing Date:
-----------------------------------------------

function main() {
  const expiryDate = new Date(readLine());
  const monthsBeforeExpiry = parseInt(readLine());

  const manufacturingDate = /* Write your code here */ expiryDate
  expiryDate.setMonth(expiryDate.getMonth()-monthsBeforeExpiry);
  

/* Please do not modify anything below this line */
  console.log(`${manufacturingDate.getDate()}-${manufacturingDate.getMonth() + 1}-${manufacturingDate.getFullYear()}`);
}

Input:

2020-01-21
8

Output:

21-5-2019

Update pickup point:
---------------------------------

function createCabBooking(area, city) {

  /* Write your code here */
  return{
      area,
      city,
      updatePickupPoint(newArea,newCity){
          this.area = newArea;
          this.city = newCity;
      }
  }

}

/* Please do not modify anything below this line */

function main() {
  const newArea = readLine();
  const newCity = readLine();
  
  const cabBooking1 = createCabBooking("Abids", "Hyderabad");
  cabBooking1.updatePickupPoint(newArea, newCity);

  console.log(`${cabBooking1.area} ${cabBooking1.city}`);
}

Input:

Kukatpally
Hyderabad

Output:

Kukatpally Hyderabad

Unite Family:
-------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const father = JSON.parse(readLine().replace(/'/g, '"'));
  const mother = JSON.parse(readLine().replace(/'/g, '"'));
  const child = JSON.parse(readLine().replace(/'/g, '"'));
 
  /* Write your code here */ 
  let family = {...father,...mother,...child}

/* Please do not modify anything below this line */
  console.log(`Mr and Mrs ${family.surname} went to a picnic in ${family.city} with a boy and a pet ${family.pet}. Mrs ${family.surname} made a special dish "${family.dish}"`);
}

Input:

{'surname' : 'Jones', 'city': 'Los Angeles'}
{'dish': 'puddings'}
{'pet': 'Peter'}

Output:

Mr and Mrs Jones went to a picnic in Los Angeles with a boy and a pet Peter. Mrs Jones made a special dish "puddings"

Objects with given fruit:
--------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const fruit = readLine();
  const objectEntities = [
    {
      fruit: "apple",
      vegetable: "broccoli"
    },
    {
      fruit: "kiwi",
      vegetable: "broccoli"
    },
    {
      fruit: "apple", 
      vegetable: "cauliflower"
    },
    {
      fruit: "orange", 
      vegetable: "mushrooms"
    },
  ];
  
  /* Write your code here */
  const fruitAndVegetable = []
  for(let each of objectEntities){
      if(each.fruit === fruit) {
          fruitAndVegetable.push(each);
      }
  }
    console.log(fruitAndVegetable);
}

Input:

apple

Output:

[
  { fruit: 'apple', vegetable: 'broccoli' },
  { fruit: 'apple', vegetable: 'cauliflower' }
]

JS coding Assignment-2:
---------------------------------------------------------

Area and circumference of circle:
--------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Circle(radius) {
  
  /* Write your code here */
  this.getArea = function() {
      const getArea = 3.14 * radius * radius;
      return getArea;
  };
  this.getCircumference = function() {
      const Circumference = 2 * 3.14 * radius;
      return Circumference;
  }

}

/* Please do not modify anything below this line */

function main() {
  const radius = JSON.parse(readLine());
  
  const circle1 = new Circle(radius);

  console.log(circle1.getArea());
  console.log(circle1.getCircumference());
}

Input:

7

Output:

153.86
43.96

Fare Per Kilometer:
----------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Ride(fare, distance) {
  
  /* Write your code here */
  this.fare = fare;
  this.distance = distance;
  this.getFarePerKilometer = function() {
      const farePerKilometer = fare/distance;
      return farePerKilometer;
  }

}

/* Please do not modify anything below this line */

function main() {
  const fare = JSON.parse(readLine());
  const distance = JSON.parse(readLine());
  
  const ride1 = new Ride(fare, distance);
  
  console.log(ride1.getFarePerKilometer());
}

Input:

120
6

Output:

20

Arithmetic Operations:
----------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function ArithmeticOperations(firstNumber, secondNumber) {
  this.firstNumber = firstNumber;
  this.secondNumber = secondNumber;
}

function main() {
  const firstNumber = JSON.parse(readLine());
  const secondNumber = JSON.parse(readLine());
  
  const operation1 = new ArithmeticOperations(firstNumber, secondNumber);

  /* Write your code here */
  ArithmeticOperations.prototype.ratioOfNumbers = function() {
      const ratio = firstNumber / secondNumber;
      return ratio;
  }
  ArithmeticOperations.prototype.sumOfCubesOfNumbers = function() {
      const cubes = (firstNumber*firstNumber*firstNumber) + (secondNumber*secondNumber*secondNumber);
      return cubes;
  };
  ArithmeticOperations.prototype.productOfSquaresOfNumbers= function() {
      const squares = ((firstNumber * firstNumber) * (secondNumber * secondNumber));
      return squares;
  }

  console.log(operation1.ratioOfNumbers());
  console.log(operation1.sumOfCubesOfNumbers());
  console.log(operation1.productOfSquaresOfNumbers());
}

Input:

8
4

Output:

2
576
1024

Trekking Kit:
-------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function Trekking(kit, item) {
  this.kit = kit;
  this.item = item;
}

function main() {
  const item = readLine();
  const trekkingKit = {
    ruckSackBag : true,
    clothes: ["Shirt", "T-Shirt/Full sleeves","Jeans"],
    firstAid: true,
    waterBottle: "2 liters",
    sunGlasses: "UV Protection",
    headTorch: true,
    medicines: true,
    footWear: "Non-skid",
    food: ["dry fruits", "nuts", "chocolate bars"]
  };
  
  /* Write your code here */
   function Trekking(item) {
    this.item = item;
}
 
Trekking.prototype.isKitContains = function(obj) {
    return Object.getOwnPropertyNames(obj).some( item => item === this.item );
};

const trekking = new Trekking(item);
const restTrekking = trekking.isKitContains(trekkingKit);

console.log(restTrekking)
}

Input:

ruckSackBag

Output:

true

submarine:
---------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

class Submarine {
  constructor() {
    this.isSubmerged = false;
  }

  /* Write your code here */
  dive(){
      this.isSubmerged = true;
      console.log("Submarine Submerged");
  }
  surface(){
      this.isSubmerged = false;
      console.log("Submarine Surfaced");
  }
  
}

class WeaponUnit extends Submarine {
  
  /* Write your code here */
  constructor(totalTorpedos,torpedosFired) {
      super();
      this.torpedoes = totalTorpedos;
      this.torpedosFired = torpedosFired;
  }
  fireTorpedos() {
      this.torpedoes = this.torpedoes - this.torpedosFired;
      console.log(`${this.torpedosFired} Torpedos Fired, ${this.torpedoes} Left`)
  }
}

/* Please do not modify anything below this line */

function main() {
  const totalTorpedos = parseInt(readLine());
  const torpedosFired = parseInt(readLine());  
  
  const weaponUnit1 = new WeaponUnit(totalTorpedos, torpedosFired);
  
  weaponUnit1.dive();
  weaponUnit1.fireTorpedos();
  weaponUnit1.surface();
}

Input:

5
2

Output:

Submarine Submerged
2 Torpedos Fired, 3 Left
Submarine Surfaced

Search item in mart:
----------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const categoryOfItem = readLine();
  const item = readLine();

  const mart = [
    {
      category:"pulses",
      items: ["green gram", "green peas", "Turkish gram"]
    },
    {
      category:"soaps",
      items:["santoor", "dove", "lux", "pears"]
    }, 
    {
      category:"oil",
      items: ["sunflower oil", "grapeseed oil", "soybean oil"]
    }, 
    {
      category:"cereals",
      items: ["wheat", "rice", "maize", "oat"]
    }, 
    {
      category:"spices",
      items: ["cumin", "coriander", "black pepper", "clove"]
    }
  ];
  
  /* Write your code here */
  const martDetails = () => {
      return new Promise((resolve,reject)=>{
          const martObject = mart.find(eachItem=>eachItem.category === categoryOfItem);
          if(martObject !== undefined) {
              const isItemsFound = martObject.items.includes(item);
              if(isItemsFound) {
                  resolve("Item Found");
              }else {
                  reject("Item Not Found")
              }
        
              }else{
                  reject("Category Not Found")
          }
      })
  }
  
  const myPromise = async () => {
      try{
          let result = await martDetails()
          console.log(result);
      } catch(reject){
          console.log(reject);
      }
  }
  myPromise();
}

Input:

pulses
green gram

Output:

Item Found

Gardening:
--------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const isGrassTrimmerFound = JSON.parse(readLine());
  const isWaterHosePipeFound = JSON.parse(readLine());

  /* Write your code here */
   const grassTrim = () => {
      return new Promise((resolve,reject)=>{
          isGrassTrimmerFound? resolve("Grass Trimmed") : reject("Grass Trimmer Not Found")
      })
  }
 const gardenClean = () => {
     return new Promise((resolve,reject)=>{
         resolve("Garden Cleaned")
     })
 }
 const waterhouse = () => {
     return new Promise((resolve,reject)=>{
         isWaterHosePipeFound?resolve("Watered Plants") : reject("Water Hose Pipe Not Found")
     })
 }     

  const myPromise = async () => {
    try {
     
      /* Write your code here */
       const firstTask = await grassTrim();
      console.log(firstTask);
      const secondTask = await gardenClean();
      console.log(secondTask);
      const thiredTask = await waterhouse()
      console.log(thiredTask);
    } catch(error) {

      /* Write your code here */
      console.log(error);
      
    }
  };
  
  myPromise();
}

Input:

true
true

Output:

Grass Trimmed
Garden Cleaned
Watered Plants

JS CODING ASSIGNMENT 3:
---------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString.trim().split("\n").map((str) => str.trim());
  main();
});

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

class Mobile {
    constructor(brand, ram, battery, isOnCall, song) {
        this.brand = brand;
        this.ram = ram;
        this.battery = battery;
        this.song = song;
        this.isOnCall = isOnCall;
    }

    charging() {
        if (this.battery < 100) {
            this.battery = 100;
            console.log('Mobile Fully Charged');
        } else {
            console.log('Mobile Already Fully Charged');
        }
    }
    
    playMusic() {
        console.log(`Playing ${this.song} Song`);
    }

    stopMusic() {
        console.log('Music Stopped');
    }

    endCall() {
        if (this.isOnCall) {
            this.isOnCall = false;
            console.log('Call Ended');
        } else {
            console.log('No Ongoing Call to End');
        }
    }
    
    makeCall() {
        this.isOnCall = true;
        console.log('Calling...');
    }

    removeChargingremoveChargingIt() {
        return console.log('Please remove charging');
    }

}

/* Please do not modify anything below this line */

function main() {
  const brand = readLine();
  const ram = readLine();
  const battery = parseInt(readLine());
  const song = readLine();
  const isOnCall = JSON.parse(readLine());
  
  const myMobile = new Mobile(brand, ram, battery, isOnCall, song);
  
     //  The Mobile battery charged percentage
  myMobile.charging();  // The Mobile charging
  
  myMobile.playMusic(); // The Mobile will start playing a song
  myMobile.stopMusic(); // The Mobile will stop playing a song
  
  myMobile.endCall(); // The Mobile will end a call.
  myMobile.makeCall(); // The Mobile will make a call.
  myMobile.endCall(); // The Mobile will end a call.
}

Input:

Apple
2 GB
90
Waka Waka
false

Output:

Mobile Fully Charged
Playing Waka Waka Song
Music Stopped
No Ongoing Call to End
Calling...
Call Ended

JS CODING ASSIGNMENT 4:
--------------------------------------------------

String Ending with vowel:
-----------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const inputString = readLine();
  const vowels = ['A', 'E', 'I', 'O', 'U'];
  
  /* Write your code here */
  const word = inputString.toUpperCase();
  let isStartWithVowel = false;
  for (let letter of vowels) {
      const result = word.endsWith(letter);
      if (result) {
          isStartWithVowel = true;
      }
  }
  if (isStartWithVowel) {
      console.log(isStartWithVowel);
  }else{
      console.log(false);
  }
}

Input:

Five

Output:

true

split and replace:
--------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const inputString = readLine();
  const separator = readLine();
  const replaceString = readLine();
  
  /* Write your code here */
  function seperator(inputString,separator,replaceString){
      let separate = inputString.split(separator);
      let result = separate.map((item)=> item.length > 7 ? item = replaceString : item = item);
      
      console.log(...result);
  }
    seperator(inputString,separator,replaceString);
}

Input:

JavaScript-is-amazing
-
Programming

Output:

Programming is amazing

product of values in sub-array(s):
----------------------------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const nestedArray = JSON.parse(readLine());

  /* Write your code here */
   function array(arr){
      let sum = arr.reduce((acc,curentValue)=> acc * curentValue);
      return sum;
  }
  function findArrayLength(arr){
      return arr.some((num)=> num%2 === 0);
  }
  const someArray = nestedArray.map((eachArrar)=>
  findArrayLength(eachArrar)?array(eachArrar):0);
  console.log(someArray);
}

Input:

[ [ 12, 1, 2, 4, 1 ], [ 18, 20, 30, 45 ], [ 49, 11, 13, 21 ] ]

Output:

[ 96, 486000, 0 ]

series of operations:
-----------------------------------------

function main() {
  const myArray = JSON.parse(readLine());

  /* Write your code here */
  const result = myArray.map((number)=> (((number)*9)-20)*7);
  console.log(...result);
}

Input:

[ 12, 2, 2, 4, 1 ]

Output:

616 -14 -14 112 -77

string slicing:
----------------------------------

function main() {
  const inputString = readLine();
  const subString = readLine();
  
  /* Write your code here */
   if(inputString.includes(subString)){
     let index = inputString.indexOf(subString);
     const slicedString = inputString.slice(index,inputString.length);
     console.log(slicedString);
 }else{
     console.log(inputString);
 }
}

Input:

JavaScript
S

Output:

Script

string starts or ends with given string:
----------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString.trim().split("\n").map((str) => str.trim());
  main();
});

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const stringsArray = JSON.parse(readLine().replace(/'/g, '"'));
  const startString = readLine();
  const endString = readLine();

  /* Write your code here */
  const result = stringsArray.filter((number)=> number.startsWith(startString) || number.endsWith(endString));
  console.log(result);
}

Input:

['teacher', 'friend', 'cricket', 'farmer', 'rose', 'talent', 'trainer']
t
r

Output:

[ 'teacher', 'farmer', 'talent', 'trainer' ]

unique characters in a string:
--------------------------------------------

function main() {
  const myString = readLine();

  /* Write your code here */
  const string = myString.split("");
  const result = string.filter((value,index,array)=>array.indexOf(value) === index);
  console.log(result);
}

Input:

Was it a cat I saw?

Output:

[
  'W', 'a', 's', ' ',
  'i', 't', 'c', 'I',
  'w', '?'
]

Array of strings to uppercase:
-------------------------------------------------

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const myArray = JSON.parse(readLine().replace(/'/g, '"'));
  
  /* Write your code here */
  const result = myArray.map((word)=> word.toUpperCase())
  console.log(result);
}

Input:

[ 'book', 'table', 'strawberries', 'lemons' ]

Output:

[ 'BOOK', 'TABLE', 'STRAWBERRIES', 'LEMONS' ]

square at Alternate indices:
---------------------------------------------------

 let square = [];
  myArray.map((value,index)=>{
      if(index%2 === 0){
          square.push(value*value); 
      }else{
          square.push(value);
      }
      
  })
  console.log(square);
}

Input:

[ 1, 2, 3, 4, 5 ]

Output:

[ 1, 2, 9, 4, 25 ]

check values in the array is String:
--------------------------------------------------------------

"use strict";

process.stdin.resume();
process.stdin.setEncoding("utf-8");

let inputString = "";
let currentLine = 0;

process.stdin.on("data", (inputStdin) => {
  inputString += inputStdin;
});

process.stdin.on("end", (_) => {
  inputString = inputString.trim().split("\n").map((str) => str.trim());
  main();
});

function readLine() {
  return inputString[currentLine++];
}

/* Please do not modify anything above this line */

function main() {
  const myArray = JSON.parse(readLine().replace(/'/g, '"'));

  /* Write your code here */
  let result = myArray.every(function(value){
      return "string"=== typeof value;
  });
  console.log(result);
}

Input:

[ 'frozen', 'rock', 'stained', 'basket' ]

Output:

true

