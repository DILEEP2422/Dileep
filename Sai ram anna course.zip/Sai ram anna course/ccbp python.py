1

https://docs.python.org/3/tutorial/index.html

https://docs.python.org/3/library/



Intro to Programming with Python:
-----------------------------------

Software:

Software is a set of instructions to the hardware.

Programming:

Programming means writing the instructions to create a software.

Code:

The instructions that we write to create software is called Code.

Syntax:

Similar to Grammar rules in English, Hindi, each programming language has a unique set of rules. 
These rules are called the Syntax of a Programming Language.

Java:
---------

class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}

Python:
-------------

print("Hello World")

------------------------------------------------------------------------------------------------------------------

Applications of Python:
--------------------------
Python is a versatile language which has applications in almost every field

Artificial intelligence (AI)
Machine Learning (ML)
Big Data
Smart Devices/Internet of Things (IoT)
Cyber Security
Game Development
Backend Development, etc.


Career Opportunities:
------------------------------

Python developers have plenty of opportunities across the world

DevOps Engineer
Software Developer
Data Analyst
Data Scientist
Machine Learning (ML) Engineer
AI Scientist, etc.


Possible Mistakes:
------------------------

Spelling Mistake in print --    prnt("Hello World!")
Uppercase ‘P’ in Print --       Print("Hello World!")
Missing quotes          --      print(Hello World!)
Missing parentheses     --      print("Hello World!"

Arthemetic operators:
--------------------------
-;+;*;/

Variables and Data Types:
-------------------------------

Variables:

Variables are like containers for storing values.
Values in the variables can be changed.

Values:

Consider that variables are like containers for storing information.
In context of programming, this information is often referred to as value.

Data Type:

In programming languages, every value or data has an associated type to it known as data type.
Some commonly used data types

String
Integer
Float
Boolean

This data type determines how the value or data can be used in the program.
 For example, mathematical operations can be done on Integer and Float types of data.
 
 String:
 --------------

A String is a stream of characters enclosed within quotes.
Stream of Characters

Capital Letters ( A – Z )
Small Letters ( a – z )
Digits ( 0 – 9 )
Special Characters (~ ! @ # $ % ^ . ?,)
Space

Some Examples

"Hello World!"
"some@example.com"
"1234"

Integer:
-------------

All whole numbers (positive, negative and zero) without any fractional part come under Integers.
Examples

...-3, -2, -1, 0, 1, 2, 3,...

Float:
-----------------

Any number with a decimal point
24.3, 345.210, -321.86

Boolean:
=----------------

In a general sense, anything that can take one of two possible values is considered a Boolean. Examples include the data that can take values like 

True or False
Yes or No
0 or 1
On or Off, etc.
As per the Python Syntax, True and False are considered as Boolean values.
Notice that both start with a capital letter.

Assigning Value to Variable:
-------------------------------------
The following is the syntax for assigning an integer value 10 to a variable age

age = 10

PYTHON
Here the equals to = sign is called as Assignment Operator as it is used to assign values to variables.

Sequence of Instructions:
----------------------------
age = 10
print(age)

output:
10
-------------------------------
age = 10
print("age")

output:
age

----------------------------------------------------------

Possible Mistakes:
---------------------

Order of Instructions:
-----------------------

Python executes the code line-by-line.

print(age)
age = 10

output:

NameError: name 'age' is not d

Spacing in Python:
----------------------

Having spaces at the beginning of line causes errors.

a = 10 * 5
b = 5 * 0.5
 b = a + b
 
 output:
 
 File "main.py", line 3
    b = a + b
    ^
IndentationError: unexpected indent

---------------------------------------------------------------------------

Variable Assignment:
-----------------------

a = 1
print(a)
a = 2
print(a)

output:

1
2

Examples of Variable Assignment:
-----------------------------------

a = 2
print(a)
a = a + 1
print(a)

output:

2
3

-----------------

a = 1
b = 2
a = b + 1
print(a)
print(b)

output:

3
2

-------------------------------------------------------

Expression:
-------------
An expression is a valid combination of values, variables and operators.

Examples 

a*b
a+b

BODMAS:
---------

The standard order of evaluating an expression
- Brackets (B)
- Orders (O)
- Division (D)
- Multiplication (M)
- Addition (A)
- Subtraction (S)

print(10 / 2 + 3)
print(10 / (2 + 3))

output:

8.0
2.0

--------------------------------------------------------------------

Inputs and Outputs Basics:
----------------------------

Take Input From User

input() allows flexibility to take the input from the user.
Reads a line of input as a string.

username = input()
print(username)

Input:

Ravi

Output:

Ravi



Working with Strings:
--------------------------

String Concatenation:
---------------------

Joining strings together is called string concatenation.

a = "Hello" + " " + "World"
print(a)

Output:

Hello World

Concatenation Errors:
------------------------

String Concatenation is possible only with strings.

a = "*" + 10
print(a)

Output:

File "main.py", line 1
    a = "*" + 10
    ^
TypeError: 
can only concatenate str (not "int") to str

String Repetition:
----------------------

* operator is used for repeating strings any number of times as required.

a = "*" * 10
print(a)

Output:

**********

Code:

s = "Python"
s = ("* " * 3) + s + (" *" * 3)
print(s)

Output:

* * * Python * * *

Length of String:
-------------------

len() returns the number of characters in a given string

username = input()
length = len(username)
print(length)

Input:

Ravi

Output:

4

String Indexing:
------------------

We can access an individual character in a string using their positions (which start from 0) .
These positions are also called as index.

username = "Ravi"
first_letter = username[0]
print(first_letter)

Output:

R

IndexError:
-------------------

Attempting to use an index that is too large will result in an error:

username = "Ravi"
print(username[4])

Output:

IndexError: string index out of range.

------------------------------------------------------------------------------------

Examples:

spacing:
---------

a = input()
b = a + ' '
print(b*3)

Input:

An

Output:

An An An

Reverse the Digits:
-----------------------

num = input()

first_digit = num[0]
second_digit = num[1]

reverse_num = second_digit + first_digit

print(reverse_num)

Input:

21

Output:

12

-------------------------------------------------------------------------------------------

Type Conversion:
---------------------

String Slicing:
----------------

Obtaining a part of a string is called string slicing.

variable_name[start_index:end_index]

Code:

message = "Hi Ravi"
part = message[3:7]
print(part)

Output:

Ravi

Slicing to End:
-----------------

If end index is not specified, slicing stops at the end of the string.

Code:

message = "Hi Ravi"
part = message[3:]
print(part)

Output:

Ravi

Slicing from Start:
----------------------

If start index is not specified, slicing starts from the index 0.

Code:

message = "Hi Ravi"
part = message[:2]
print(part)

Output:

Hi

---------------------------------------------------------------------------------------------------------

Printing Data Type:
-----------------------

Code:

print(type(10))
print(type(4.2))
print(type("Hi"))

Output:

<class 'int'>
<class 'float'>
<class 'str'>

----------------------------------------------------------------------------------------------------------

Type Conversion:
----------------------

int() -> Converts to integer data type
float() -> Converts to float data type
str() -> Converts to string data type
bool() -> Converts to boolean data type

a = input()
a = int(a)
b = input()
b = int(b)
result = a + b
print("Sum: " + str(result))

input:
2
3

Output:
sum: 5

------------------------------------------------------------------------------------------

coding pratice:
----------------------

Indexing:
---------

word = input()
n = input()
n = int(n)
print(word[n])

Input:

word	"Chocolate"
n	1

output:

h.

Half string:
--------------

username = input()
length = len(username)
last_index = int(length) - int(length/2)
first_half = username[0:last_index]
print (first_half)

Input:

Song

Output:

SO.

String Repetition 2:
----------------------

word=input()

n=input()
n=int(n)
print(word*n)

Input:

An

Output:

AnAn

Last Character:
-----------------------

username = input()
length = len(username)
last_index = int(length-1)
first_half = username[last_index]
print (first_half)

Input:

August

Output:

t

string Repetition3:
-----------------------

username = input()
n=int(input())

length = len(username)
last_index = int(length-3)

first_half = username[last_index:]
print (first_half*n)

Input:

Transport
2

Output:

ortort

sum of digits:
------------------

word = input()

first_digit = int(word[0])

second_digit = int(word[1])

third_digit = int(word[2])

sum_of_digits = (first_digit+second_digit+third_digit)

print(sum_of_digits)

----------------------------------------------------------------------------------------

Relational Operators:
----------------------------

Operator	Name
>	Is greater than
<	Is less than
==	Is equal to
<=	Is less than or equal to
>=	Is greater than or equal to
!=	Is not equal to

Python is case sensitive. 
It means X (Capital letter) and x (small letter) are not the same in Python.

Logical Operators:
------------------------

The logical operators are used to perform logical operations on Boolean values.
Gives True or False as the result.  

Following are the logical operators  

and
or
not

Coding pratice - 1c :
-----------------------

Area of Rectangle:
------------------------

length = input()
breath=input()

length=int(length)
breath=int(breath)

Area_of_rectangle = length*breath

print(Area_of_rectangle)

Input:

3
4

Output:

12

First three characters:
-----------------------------

username = input()


length = len(username)
last_index = int(length)

first_half = username[0:3]
print (first_half)

Input:

Four

Output:

Fou

Compare first three characters:
---------------------------------------

a=input()
b=input()
f=a[0:3]
s=b[0:3]
result = f == s
print(result)

Input:

Apple
Anchor

Output:

False

is greater than 5:
-------------------------

first_number=input()
first_number=int(first_number)

second_number=input()
second_number=int(second_number)

is_positive = (first_number>0) and (second_number>0)
is_greater = (first_number>5)  or (second_number > 5)

result = is_positive and is_greater

print(result)

Input:

10
1

Output:

True

comparing digits:
------------------------


first_number=input()



first_digit =int(first_number[0])
second_digit=int(first_number[1])
first_number=int(first_number)

print((first_number>25) and (first_digit>second_digit))

Input:

24

Output:

False

--------------------------------------------------------------------------------------------------------

Assignment-1:
------------------

Compare Last three characters:
---------------------------------

username = input()
word = input()

length = len(username)
last_index = int(length-3)

length1 =len (word)
last_index1 = int(length1-3)

first_half = username[last_index:]
second_half = word[last_index1:]
print(first_half==second_half)

Input:

king
ring

Output:

True

First Letters:
----------------------

a=input()
b=input()
c=input()

first = a[0]
second=b[0]
third=c[0]

print(a[0]+b[0]+c[0])

Input:

apple
banana
carrot

Output:

abc

Half string - 2 -- Last 4 characters:
-------------------------------------------

username = input()
length = len(username)
last_index = int(length/2)
first_half = username[last_index:]
print (first_half)

Input:

Messages

Output:

ages

Area and Perimeter of square:
-----------------------------------

s=input()
s=int(s)
result=s*s
result1=4*s
print("Area of the square is: " + str(result) )
print("Perimeter of the square is: " + str(result1))

Input:

3

Output:

Area of the square is: 9
Perimeter of the square is: 12

First and Last digits:
--------------------------------

a=input()


first_digit=a[0]
last_digit=a[3]
a=int(a)
print(first_digit)
print(last_digit)

Input:

1456

Output:

1
6

String Repetition - 4:
-------------------------

a=input()
n=input()
n=int(n)
b = a + ' '
print(b*n)

Input:

message
3

Output:

message message message

Print in Reverse Order - 2:
---------------------------------

a=input()

b=input()

c="---"

print(b)
print(c)
print(a)

Input:

Apple
---
Banana

Output:
----

Banana
---
Apple

Elements in Range:
------------------------

a=input()
a=int(a)

b=input()
b=int(b)

c=input()
c=int(c)

any_of_number = ((10<=a<=20) or (10<=b<=20) or (10<=c<=20))

print(any_of_number)

Input:

2
4
6

Output:
False

Women population:
---------------------

Men 52% Womwen 48%

a=input()
a=int(a)



population = int(a*(48/100))

print(population)

Input:

8000

Output:

3400

**
years,weeks,days:
--------------------

num = int(input())

years = int(num/365)
weeks = int((num%365)/7)
days = int((num%365)%7)

print(years)
print(weeks)
print(days)

Input:

1329

Output:

3
33
3

**Dividend = Divisor x Quotient + Remainder.

---------------------------------------------------------------------------------------

Conditional Statement:
-------------------------

if-syntax:
-----------

if condition:
    Block of code
    
if True:
    print("If Block")
    print("Inside If")
    
If - Else Syntax:
-------------------

a = int(input())
if a > 0:  
    print("Positive")  
else:  
    print("Not Positive")  
print("End")

-------------------------------------------------------------------------------------------

coding pratice-2:
-------------------

Skipping Letters:
---------------------

word = input()
n = int (input())
before = word[:n]
after = word[n+1:]
result = before + after
print(result)

Input:

combine
4

Output:

combne

Validate Password:
--------------------

a=input()

length=len(a)

if (length>7):
    print("True")
else:
    print("False")
    
Input:

psswd

Output:

False

Masking:
-------------

word = input()
lenth_word = len(word)
number_of_mask = lenth_word - 2
masked = word[0] + "*" * number_of_mask + word[lenth_word - 1] 
print(masked)

Input:

king@2020

Output:

k*******0

---------------------------------------------------------------------------------------------------

Assignment-2:
--------------

Masking-2:
-----------

word = input()

if len(word)>4:
    number_of_mask=len(word)-4
    word=word[:2]+"*"*number_of_mask+word[len(word)-2:]
print(word)

Input:

message

Output:

me***ge

Eligiblity Creteria-1:
-------------------------

M=int(input())
P=int(input())
C=int(input())
if ((M>=70)and(P>=60)and(C>=60)or(M+P+C>=180)):
    print("True")
else:
    print("False")
    
Input:    Input:
          
0          35
100        45
100        65

Output:    Output:

True        False

Eligiblity Creteria-2:
-----------------------

M=int(input())
P=int(input())
C=int(input())
S=(M+P>=100)or(M+C>=100)or(P+C>=100)
if (S and (M+P+C>=180)):
    print("True")
else:
    print("False")
    
Eligiblity Creteria-3:
-------------------------

M=int(input())
P=int(input())
C=int(input())
S=(M+P>=90)or(M+C>=90)or(P+C>=90)
M=(M>=35)and(P>=35)and(C>=35)
if(M and C):
    print("True")
else:
    print("False")
    
Eligiblity Creteria-4:
------------------------

M=int(input())
P=int(input())
C=int(input())
S=(M>=60)and(P>=50)and(C>=45)and (M+P+C>=180)
K=(M+P>=120)or(C+P>=110)
if (S or K):
    print("True")
else:
    print("False")
    
---------------------------------------------------------------------------------------
 
Coding pratice-3:
-------------------
 
Greatest Amoung two Numbers:
------------------------------
 
a=int(input())
b=int(input())
if(a>b):
    print(a)
else:
    print(b)

Input:

70
90

Output:

90

Bonus Salary:
----------------

salary=int(input())
years=int(input())
bonus = float(salary*5/100)
if(years>5):
    print(bonus)
else:
    print("No Bonus")
    
Input:      Input:

25000       50000
3           6

output:     Output:

No Bonus    2500.0

Lucky Number:
--------------

a=int(input())
b=int(input())


s= ((a==6)or(b==6)or(a-b==6)or(a+b==6)or(b-a==6))
 
if s:
    print("Lucky")
else:
    print("Not Lucky")
    
 
 Greatest amoung three numbers:
 --------------------------------
 
num1=int(input())
num2=int(input())
num3=int(input())

if (num1 > num2) and (num1 > num3):
   largest = num1
elif (num2 > num1) and (num2 > num3):
   largest = num2
else:
   largest = num3
print(largest)

Input:

2
5
7

output:

7

2nd apporoach:

num1=int(input())
num2=int(input())
num3=int(input())

if (num1 > num2):
   largest = num1
else:
   largest = num2
if(num3>largest):
   largest = num3
print(largest)

---------------------------------------------------------------------------------------

Modulus:
---------

To find the remainder, we use Modulus operator %

a % b

code:

print(6 % 3)

Output:

0

Exponent:
----------
To calculate a power b, we use Exponent Operator **

a ** b  

Code:

print(2**3)

Output:

8

coding pratice-4:
--------------------

Even or Odd:
-------------

num = int(input())
if num%2==0:
    print("Even")
else:
    print("Odd")
    
Input:

2

output:

Even

Special Number:
------------------
1.Sum of digits 7
2.multiple of 7
3.any digit is 7

number=int(input())
is_multiple_of_7 = ((number%7)==0)
number_str=str(number)

first_digit = int(number_str[0])
second_digit= int(number_str[1])

is_first_digit_7 = (first_digit == 7)
is_second_digit_7 = (second_digit == 7)

sum_of_digit_7=(first_digit+second_digit == 7)
is_any_digit_7 = (is_first_digit_7 or is_second_digit_7)
condition = is_multiple_of_7 or sum_of_digit_7 or is_any_digit_7

if condition:
    print("Special Number")
else:
    print("Normal Number")

Input:

67

Output:

Special Number

Special eleven:
-----------------

number=int(input())
is_mulitiple_of_11 = ((number%11) == 0)
is_mulitiple_of_11_1 = ((number%11) == 1)

condition = (is_mulitiple_of_11 or is_mulitiple_of_11_1)

if condition:
    print("Special Eleven")
else:
    print("Normal Number")
    
Input:                  Input:

22                      23

Output:                 Output:

Special Eleven          Special Eleven

Lucky Number - 2:
--------------------

Divisiblity Rules

a=int(input())

if a%6==0:
    print("Number is divisible by 6")

if a%3==0 and a%6!=0:
    print("Number is divisible by 3")

if a%2==0 and a%6!=0:
    print("Number is divisible by 2")

if a%2 != 0 and a%3 != 0:
    print("Number is not divisible by 2, 3 or 6")
    
Power of Number:
-----------------

a=int(input())
b=int(input())

a_power_of_b = a**b
b_power_of_a = b**a

condition = a>b

if condition:
    print(a_power_of_b)
else:
    print(b_power_of_a)
    
Input:

5
3

Output:

125

Greatest Amoung the Powers:
--------------------------------

a=int(input())
b=int(input())

a_power_of_b = a**b
b_power_of_a = b**a

condition = a_power_of_b>b_power_of_a

if condition:
    print(a_power_of_b)
else:
    print(b_power_of_a)
    
Input:

2
3

Output:

9

Lucky Number - 3:
------------------
1.Multiple of 9
2.any digit 9

number=int(input())
is_multiple_of_9 = ((number%9)==0)
number_str=str(number)

first_digit = int(number_str[0])
second_digit= int(number_str[1])

is_first_digit_9 = (first_digit == 9)
is_second_digit_9 = (second_digit == 9)

is_any_digit_9 = (is_first_digit_9 or is_second_digit_9)
condition = is_multiple_of_9 or is_any_digit_9

if condition:
    print("Lucky Number")
else:
    print("Unlucky Number")
    
-------------------------------------------------------------------------------------------------------------
    
Assignment-4:
------------------
    
Compute Hypotenuse:
---------------------

h**2 = a**2 + b**2


a=int(input())
b=int(input())

square_of_a= a**2
square_of_b=  b**2


square_of_h= (square_of_a+square_of_b)
value_of_h = int(square_of_h**(1/2))

print(value_of_h)

Input:

3
4

Output:

5

Uncommon Number:
------------------
primes:2,3,5,7

N=int(input())

if N%2 != 0 and N%3 != 0 and N%5 != 0 and N%7 != 0:
    print("True")
else:
    print("False")
    
Smallest Remainder:
--------------------

a=int(input())
b=int(input())

a_divisible_of_b = a%b
b_divisible_of_a = b%a

condition = a_divisible_of_b>b_divisible_of_a

if condition:
    print(b_divisible_of_a)
else:
    print(a_divisible_of_b)
    
Calculate Double or Triple:
-----------------------------

a=int(input())
is_multiple_of_3 = ((a%3)==0)

if is_multiple_of_3:
    print(a*3)
else:
    print(a*2)

3-digit armstrong Number:
---------------------------

number=int(input())
number_str=str(number)

first_digit = int(number_str[0])
second_digit= int(number_str[1])
third_digit = int(number_str[2])

condition = (first_digit**3 + second_digit**3 + third_digit**3) == number

if condition:
    print("True")
else:
    print("False")

3**3+5**3+1**3 == 351

------------------------------------------------------------------------------

Elif Statement:
-----------------

Use the elif statement to have multiple conditional statements between if and else.

The elif statement is optional.

number = 5
is_divisible_by_10 = (number % 10 == 0)
is_divisible_by_5 = (number % 5 == 0)
if is_divisible_by_10:
    print("Divisible by 10")
elif is_divisible_by_5:
    print("Divisible by 5")
else:
   print("Not Divisible by 10 or 5")

Output:

Divisible by 5   

coding pratice-5:
-----------------------

Get Grades:
--------------

 marks = float(input())

if marks > 85:
    print("A")
elif marks > 70:
    print("B")
elif marks >=60:
    print("C")
else:
    print("F")
    
Perimission to attempt exam:
-------------------------------

atten = input()
medi = input()
b = (int(atten[0:-1])>=(75))
if (b):
  print("Allowed to write exam")
elif (medi == "Y"):
  print("Allowed to write exam")
else:
  print("Cannot write exam")  

75% ---> 75

another apporoach:
-------------------

a=input()
b=input()
a=int(a[:len(a)-1])
if a>=(75):
  print("Allowed to write exam")
elif a<(75) and b=="Y":
  print("Allowed to write exam")
else:
  print("Cannot write exam")
  
Electricity Bill:
---------------------

units = int(input())

if units < 50:
    bill = 2 * units
elif units < 150:
    bill = (2*50) + (3*(units - 50))
elif units < 250:
    bill = (2*50) + (3*100) + (5*(units - 150))
elif units >= 250:
    bill = (2*50) + (3*100) + (5*100) + (8*(units - 250))
    
surcharge = (0.2 * bill)

total_bill = (bill + surcharge)

print(total_bill)

Simple Calculator:
---------------------

operater = input()
a = int(input())
b = int(input())

if(operater == "+"):
    print(a+b)
elif(operater == "-"):
    print(a-b)
elif(operater == "*"):
    print(a*b)
elif(operater == "/"):
    print(a/b)
elif(operater == "%"):
    print(a%b)

Get Season:
--------------

month = int(input())
January = 1
February = 2
March = 3
April = 4
May = 5
June = 6
July = 7
August = 8
September = 9
October = 10
November = 11
December = 12
if month in [January,November,December] :
    print("Winter")
elif month in [February,March] :
    print("Spring")
elif month in [April,May,June] :
    print("Summer")
elif month in [July,August] :
    print("Rainy")
else :
    print("Autumn")
    

Assignment-5:
-----------------

Leap year:
-----------


y = int(input())

if y%4==0 and y%100!=0:
    print("True")
else:
    print("False")
    
------------------------------------------------------------------------------------------------------------------------
    
coding pratice-6:
---------------------

Sum of digits:
----------------


num = int(input())
sum = 0
while num>0:
    rem = num%10
    sum = sum+rem
    num = int(num/10)
print(sum)

Input:

123

Output:

6

Denominations:
----------------

amount = int(input())
note_100 = 0
note_50 = 0
note_10 = 0
note_1=0
if amount >= 100:
    note_100 = int(amount/100)
    amount = (amount%100)
if amount >= 50:
    note_50=int(amount/50)
    amount= (amount%50)
if amount >= 10:
    note_10 = int(amount / 10)
    amount = (amount % 10)
if amount >=1:
    note_1 = int(amount /1)
    amount= (amount%1)


print("100:" + str(note_100))
print("50:" + str(note_50))
print("10:" + str(note_10))
print("1:" + str(note_1))

Input:

893

Output:

100:8
50:1
10:4
1:3

Assignment-6:
----------------

Maximum Number of handshakes:
---------------------------------

N=int(input())
total = N * (N-1) / 2
print(int(total))

Input:

5

Output:

10

Denominations-2:
------------------

amount = int(input())
note_100 = 0
note_50 = 0
note_20 = 0
note_10=0
if amount >= 100:
    note_100 = int(amount/100)
    amount = (amount%100)
if amount >= 50:
    note_50=int(amount/50)
    amount= (amount%50)
if amount >= 20:
    note_20 = int(amount / 20)
    amount = (amount % 20)
if amount >=10:
    note_10 = int(amount /10)
    amount= (amount%10)


print("100 Notes: " + str(note_100))
print("50 Notes: " + str(note_50))
print("20 Notes: " + str(note_20))
print("10 Notes: " + str(note_10))

Input:

370

Output:

100 Notes: 3
50 Notes: 1
20 Notes: 1
10 Notes: 0

Denominations-4:
-----------------

amount = int(input())
note_2000 = 0
note_500 = 0
note_200 = 0
note_50 = 0
note_20 = 0
note_5=0
note_2=0
note_1=0
if amount >= 2000:
    note_2000 = int(amount/2000)
    amount = (amount%2000)
if amount >= 500:
    note_500=int(amount/500)
    amount= (amount%500)
if amount >= 200:
    note_200 = int(amount / 200)
    amount = (amount % 200)
if amount >=50:
    note_50 = int(amount /50)
    amount= (amount%50)
if amount >= 20:
    note_20 = int(amount/20)
    amount = (amount%20)
if amount >= 5:
    note_5 =int(amount/5)
    amount= (amount%5)
if amount >=2:
    note_2=int(amount/2)
    amount=(amount%2)
if amount >=1:
     note_1=int(amount/1)
     amount=(amount%1)


print("2000:" + str(note_2000) + " 500:" + str(note_500) + " 200:" + str(note_200)
+ " 50:" + str(note_50) + " 20:" + str(note_20) + " 5:" + str(note_5)
+ " 2:" + str(note_2) + " 1:" + str(note_1))

Input:

2257

Output:

2000:1 500:0 200:1 50:1 20:0 5:1 2:1 1:0

Denominations-3:
-------------------

amount = int(input())
note_500 = 0
note_50 = 0
note_10 = 0
note_1=0
if amount >= 500:
    note_500 = int(amount/500)
    amount = (amount%500)
if amount >= 50:
    note_50=int(amount/50)
    amount= (amount%50)
if amount >= 10:
    note_10 = int(amount / 10)
    amount = (amount % 10)
if amount >= 1:
    note_1 = int(amount /1)
    amount= (amount%1)


print("500: " + str(note_500) + " 50: " + str(note_50) + " 10: " + str(note_10) + " 1: " + str(note_1))

Input:

1543

output:

500: 3 50: 0 10: 4 1: 3

Day Name-2:
--------------

d = str(input())
number = int(input())
list1 = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
i = number % 7-1
if d in list1 :
    j = list1.index(d)+i 
    if j >= 7 :
        j = j - 7 
    print(list1[j])

Grand Assignment-1:
----------------------

Triangles:
-------------

a=int(input())
b=int(input())
c=int(input())

if(a == b == c):
    print("Equilateral")
elif((a==b)or(a==c)or(b==c)):
    print("Isosceles")
elif(a != b != c):
    print("Scalene")
    
Input:

3
2
3

Output:

Isosceles

Finding Difference:
-----------------------

num1 = int(input())
num2 = int(input())

if num1 > num2:
    diff = num1 - num2
else:
     diff = num2 - num1
print(diff)

Input:

200
500

Output:

300

***
days conversion:
-----------------

num = int(input())

years = int(num/365)
weeks = int((num%365)/7)
days = int((num%365)%7)

print(str(years) + " years" + " " + str(weeks) + " weeks" + " " + str(days) + " days")

Input:

1329

Output:

3 years 33 weeks 3 days

***
Last digit:
-------------

num=int(input())
last_digit = num%10
print(last_digit)

Input:

25

Output:

5

--------------------------------------------------------------------------------------

Loops:
-------

while loop ; for loop

while loop:
-------------

a = int(input())  
counter = 0  
while counter < 3:  
    a = a + 1  
    print(a)  
    counter = counter + 1
    
Input:

2

Output:

3
4
5

common mistakes:
----------------------

1. Missing Initialization:

Code:

a = int(input())  
while counter < 3:  
    a = a + 1  
    print(a)  
    counter = counter + 1  
print("End")

2. Incorrect Termination Condition:  -- While block will keep repeating as the value in condition variable is True.
 
 a = int(input())  
counter = 0  
condition = (counter < 3)  
while condition:  
    a = a + 1  
    print(a)  
    counter = counter + 1
    
Input:

10

Output:

Infinite Loop

3. Not Updating Counter Variable:  --  As the value of counter is not updating.

a = int(input())  
counter = 0  
while counter < 3:  
    a = a + 1  
    print(a)  
print("End")

Input:

10

Output:

Infinite Loop

Examples:
-------------

a = 10
i = 1 
count = 0
while i <= a:
    if(i%2 == 0):
        count = (count+i)
    i = i+1
print(count)

Output:

30

Code:

a = 4
count = 0
while a>0:
    a=a-1
    if(a<3)or(a>9):
        count = (count+1)
    
print(count)

Output:

3

Code:

word = "python"
counter=0
length_of_the_word = len(word)

while counter<length_of_the_word:
    print(word[counter])
    counter=counter+1
    
Output:

p
y
t
h
o
n

coding pratice-7:  -- 1 to n
---------------------

num =int(input())
i=1
while i<=num:
    print(i)
    i=i+1

Input:

3

Output:

1
2
3

m to n:
---------------

m = int(input())
n=int(input())
i = m
while i<=n:
    print(i)
    i=i+1
    
Input:

2
6

Output:

2
3
4
5
6

Solid square:
----------------

n=int(input())
counter = 0
while counter<n:
    print("* "*n)
    counter=counter+1
    
Input:

4

Output:

* * * * 
* * * * 
* * * * 
* * * * 

Solid Rectangle:
-----------------------

1st apporach:
------------------

rows = int(input())
columns = int(input())

i = 0
while(i < rows):
    print("* " * columns)
    i = i + 1
   
2nd:
------
rows = int(input())
columns = int(input())

i = 0
while(i < rows):
    j = 0
    while(j < columns):
        print("*", end = ' ')
        j = j + 1
    i = i + 1
    print()
    
For Loop:
-----------

rows = int(input())
columns = int(input())


for i in range(rows):
    for j in range(columns):
        print('*', end = ' ')
    print()
    
    
Input:

2
3

Output:

* * * 
* * * 

Note: print() -- to print in new line

Solid Right Angled Triangle:
------------------------------

N=int(input())

counter=1 

while counter <= N:
    print("* "*counter)
    counter=counter+1
    
For:
----
N=int(input())

for i in range(N):
    for j in range(i+1):
        print("* ", end="")
    print()
    
Input:

4

Output:

* 
* * 
* * * 
* * * * 

Sum of 1st n natural numbers:
--------------------------------

n=int(input())

counter = 1 
sum = 0 
while counter <= n:
    sum = (sum+counter)
    counter=counter+1 
print(sum)

Input:

6

Output:

21

Sum of given numbers:
------------------------

number_of_inputs = int(input())

counter = 0 
sum = 0 
while counter < number_of_inputs:
    number=int(input())
    sum = (sum+number)
    counter=counter+1 
print(sum)

Input:

2
20
7

Output:

27

Read N inputs:
------------------

number_of_inputs = int(input())
counter = 0
while counter < number_of_inputs:
  number = int(input())
  print(number)
  counter = (counter + 1)
  
Input:

3
8
11
25

Output:

8
11
25

Assignment-7:
-------------------------
N to 1:
---------

number = int(input())

counter = number
while counter>=1:
    print(counter)
    counter=counter-1
    
Input:

5

Output:

5
4
3
2
1

Solid Rectangle-2:
---------------------

rows = int(input())
columns = int(input())

counter = 0
while(counter < rows):
    print("+ " * columns)
    counter = counter + 1
    
Input:

2

Output:

+ +
+ +

Product of the given numbers:
-----------------------------------

N=int(input())
product=1
for i in range(N):
    num=int(input())
    product*=num
print(product)

Input:

3
2
3
7

Output:
42

----------------------------------------------------------------------------------------------------------

For Loop:
-----------

Syntax:

word = "Python"  
for each_char in word:  
    print(each_char)
    
Output:

p
y
t
h
o
n

Range:

for number in range(3):  
    print(number)
    
Input:

3

Output:

0
1
2

for number in range(5, 8):  
    print(number)
    
Output:
5
6
7

coding pratice-8:
----------------------

Solid Rectangle:
-----------------

rows = int(input())
columns = int(input())


for i in range(rows):
    for j in range(columns):
        print('*', end = ' ')
    print()
      

Solid square:
------------------

n=int(input())

for counter in range(n):
    print("* "*n)
    
Solid Right Angled Triangle:
-----------------------------

n=int(input())

for counter in range(1,n+1):
    print("* "*counter)
    
styled word:
--------------

a = input()
len_of_a = len(a)
b = a[0]
for i in range(1,len_of_a):
    b = b + "-" + a[i]
print(b)

Input:

python

Output:

p-y-t-h-o-n    

m to n:
---------

m = int(input())
n=int(input())

for counter in range(m,n+1):
    print(counter)
   
    
1 to n:
-----------

n = int(input())

for counter in range(1,n+1):
    print(counter)
    
Sum of the Natural Numbers:
------------------------------

n=int(input())


sum = 0 
for counter in range(1,n+1):
    sum = (sum+counter)
print(sum)
  
Sum of the given numbers:
----------------------------

number_of_inputs = int(input())

sum = 0 
for counter in range(number_of_inputs):
    number=int(input())
    sum = (sum+number)
     
print(sum)

Read N inputs:
--------------------

number_of_inputs = int(input())


for counter in range(number_of_inputs):
    number=int(input())
    print(number)

Assignment-8:
--------------

N to 1 :
---------

n=int(input())
for i in range(n):
   
    print(n-i)
    
    
 Solid Right Angled Triangle-2:
 ------------------------------------
 
 N = int(input())
for number in range (1,N+1) :
    print(number * "* ")
for number in range (1,N+1) :
    print(number * "* ")

--------------------------------------------------------------------------------------------------------------------------
    
coding pratice-9:
----------------------

Factorial:                          
-----------

number = int(input())               
factorial = 1 
for i in range(1, number + 1):
    factorial = factorial * i 
print(factorial)

Input:

4

Output:

24

using while:
---------------

number = int(input())
factorial = 1 
counter = 1 

while counter<=number:
    factorial=factorial*counter
    counter=counter+1 
print(factorial)

sum of given numbers m to n:
-----------------------------------

m = int(input())
n = int(input())

sum = 0 
for i in range(m,n+1):
    sum = (sum+i)
    
     
print(sum)

Input:

2
6

Output:

20

using while:
-----------------

m = int(input())
n = int(input())

sum=0
while m<=n:
    sum=sum+m
    m=m+1
print(sum)

sum of first n even numbers:
----------------------------------

num = int(input())

sum = 0

for i in range(1, num + 1):

    if((i % 2) == 0):
        sum = sum + i

print(sum)

Input:

6

Output:

12

sum of first n odd numbers:
--------------------------------

num = int(input())

sum = 0

for i in range(1, num + 1):

    if((i % 2) != 0):
        sum = sum + i

print(sum)

Input:

6

Output:

9

sum of odd numbers from m to n:
------------------------------------

m = int(input())
n = int(input())

sum = 0

for i in range(m,n+1):

    if((i % 2) != 0):
        sum = sum + i

print(sum)

Input:

5
13

output:

45

sum of squares :
-------------------

n = int(input())
sum=0
for i in range(1,n+1):
    sum = sum+i*i
print(sum)

Input:

6

Output:

91

sum of cubes:
------------------

n = int(input())
sum=0
for i in range(1,n+1):
    sum = sum+i*i*i
print(sum)

Input:

3

output:
36

sum and average of 10 numbers:
-----------------------------------

total = 0
for i in range(10):
  number = int(input())
  total = total + number

average = total / 10
print(total)
print(average)

sum of digits:
--------------------

number = (input())
sum = 0 
for digit in number:
    sum = sum+int(digit)
print(sum)

Input:

151893

output:

27

sum of numbers divisible by T:
-----------------------------------

t = int(input())
m = int(input())
n = int(input())


sum = 0
for i in range(m, n+1):
    if(i % t) == 0:
        sum = sum + i
print(sum)

Input:

2
5
9

Output:

14

Assignment-9:
--------------------

product of numbers from m to n:
-------------------------------------

m = int(input())
n = int(input())
product=1
for i in range(m,n+1):
    product = product*i
print(product)

Input:

2
5

Output:

120

sum of K powers:
--------------------

n = int(input())
k = int(input())

sum=0
for i in range(1,n+1):
    sum=sum+pow(i,k)
print(sum)

Input:

5
3

output:

225

Find Power of number:
-------------------------

number = int(input())
exponent = int(input())
power = 1

for i in range(1, exponent + 1):
    power = power * number
    
print(power)

Input:

3
1

Output:

3

Number of digits untill N:
--------------------------------

n = int(input())
count = 0
for i in range(1,n+1):
    count = len(str(i))+count
print(count)

-----------------------------------------------------------------------------------------------------------------

coding pratice-10:
---------------------

Multiplication Table:
-------------------------

n=int(input())
count=1
for i in range(1,11):
    t=str(i)
    count=n*i
    count=str(count)
    table=(str(n) + " x " + t +  " = "+ count)
    print(table)
    
Input:

3

Output:

3 x 1 = 3
3 x 2 = 6
3 x 3 = 9
3 x 4 = 12
3 x 5 = 15
3 x 6 = 18
3 x 7 = 21
3 x 8 = 24
3 x 9 = 27
3 x 10 = 30

Reverse String:
-------------------

a = input()

reverse_a = ""
for char in a:
    reverse_a = char+reverse_a
print(reverse_a)

Input:

Hurray! We have won the match.

Output:

.hctam eht now evah eW !yarruH

Palindrome:
---------------

a = input()
a = a.lower()
reverse_a = ""
for char in a:
    reverse_a = char+reverse_a
if a == reverse_a:
    print("Palindrome")
else:
    print("Not a Palindrome")

Input:      Input:

Madam       ROVER

Output:     Output:

Palindrome      Not a Palindrome

Greatest Amoung N numbers:
----------------------------

number_of_inputs = int(input())

first_input = int(input())
greatest_number = first_input

for i in range(number_of_inputs - 1):
    number = int(input())
    if number > greatest_number:
        greatest_number = number
print(greatest_number)

Input:

5
8
11
96
49

Output:

96

Smallest Amoung N numbers:
------------------------------

number_of_inputs = int(input())

first_input = int(input())
smallest_number = first_input

for i in range(number_of_inputs - 1):
    number = int(input())
    if number < smallest_number:
        smallest_number = number
print(smallest_number)

Input:

5
8
11
96
49

Output:

8

Sum of series:
------------------

n = int(input())
term_number = "2"
sum = 0
for i in range(1, n+1):
  term = term_number * i
  sum = sum + int(term)
print(sum)

Input:

3

Output:

246

Factors of number:
-----------------------

n =int(input())

for i in range(1,n+1):
    if(n%i) == 0:
        print(i)
    
Input:

6

Output:

1
2
3
6

Sum of All Factors:
-----------------------

n =int(input())
sum = 0
for i in range(1,n+1):
    if(n%i) == 0:
        sum =sum+i
print(sum)
    
Input:

12

Output:

28

Perfect Number:
--------------------

n =int(input())
sum = 0
for i in range(1,n):
    if(n%i) == 0:
        sum =sum+i
if sum == n:
    print("Perfect Number")
else:
    print("Not a Perfect Number")
   
Input:

6

Output:

Perfect Number

Armstrong Number:
--------------------

number = input()
length = len(number) # which is 3 total = 0 + int('1') ** 3 = 1
sum = 0

for digit in number:
    power_value = (int(digit) ** length) 
    sum = sum + power_value
    
if sum == int(number):
    print("Armstrong Number")
else:
    print("Not an Armstrong Number")
    
#total = total + (int(digit) ** length) # total = 0 + int('1') ** 3 = 1
#total = total + (int(digit) ** length) # total = 1 + int('5') ** 3 = 125
#total = total + (int(digit) ** length) # total = 126 + int('3') ** 3 = 153

Hollow square:
------------------

number = int(input())

for i in range(number):
  if (i == 0) or (i == (number - 1)):
    print("* " * number)
  else:
    number_of_spaces = ("  " * (number - 2))
    print("* " + number_of_spaces + "* ")
    
    
Assignment-10:
--------------------

Hollow Right Triangle:
-----------------------

totalrows = int(input())

for rowno in range(1,totalrows+1):
    for colno in range(1,totalrows+1):
        if(colno == totalrows) or (rowno == 1) or (colno == rowno):
            print("*",end=" ")
        else:
            print(" ",end=" ")
    print()
    
Input:

4

Output:

* * * * 
  *   * 
    * * 
      * 
      
Hollow Right Triangle-2:
----------------------------

n = int(input())

for rowno in range(n):
    for colno in range(n):
        if(colno == n-1) or (rowno == n-1) or (colno+rowno == n-1):
            print("*",end=" ")
        else:
            print(" ",end=" ")
    print()
    
 Input:
 
 4
 
 Output:
 
      *
    * * 
  *   * 
* * * * 

Solid Right Angled Triangle-2:
------------------------------------

n = int(input())

for i in range(n):
    for j in range(n-i-1):
        print(" ",end=" ")
    for j in range(i+1):
        print("*",end=" ")
    print()
    
Input:

4

Output:

      *
    * * 
  * * * 
* * * * 

Inverted Solid Right Triangle:
-----------------------------------

n = int(input())

for i in range(n):
    for j in range(i):
        print(" ",end=" ")
    for j in range(n-i):
        print("*",end=" ")
    print()
  
Input:

4

Output:

* * * * 
  * * * 
    * * 
      * 
      
Perfect squares in a range:
------------------------------------

a=int(input())
b=int(input())
count=0
for i in range(a,b+1):
    if (i**0.5==int(i**0.5)):
        count+=1
print(count)

sum of the series:
-------------------------------

x = int(input())
N = int(input())
S = 0
k = 1
for i in range(N):
	S += k*(x**(2*i+1))
	k *= -1
print(S)

Right angle triangle-3:
-----------------------------

n=int(input())
for i in range(n+1):
    print('_',end='')
print()
for i in range(n):
    print('|',end='')
    print(' '*(n-i-1),end='')
    print('/')
    
Input:

5

Output:

______
|    /
|   /
|  /
| /
|/

Right angle triangle-4:
---------------------------

n = int(input())
for i in range(n-1):
    print(' '*(n-1-i),'/',' '*i,'|',sep ='')
# last line print
print('/','_'*(n-1),'|',sep ='')

Input:

5

Output:

    /|
   / |
  /  |
 /   |
/____|

      
Foundation exam - 1:
--------------------------

Date Format:
-----------------

totalSeconds = int(input())

secondsPerMinute = 60
secondsPerHour = 60 * secondsPerMinute
secondsPerDay = 24 * secondsPerHour

days = totalSeconds // secondsPerDay
hours = (totalSeconds - days * secondsPerDay) // secondsPerHour
minutes = (totalSeconds - days * secondsPerDay - hours * secondsPerHour) // secondsPerMinute
seconds = totalSeconds - days * secondsPerDay - hours * secondsPerHour - minutes * secondsPerMinute

if days > 0:
    print(days, 'Days', end=' ')
if hours > 0:
    print(hours, 'Hours', end=' ')
if minutes > 0:
    print(minutes, 'Minutes', end=' ')
if seconds > 0:
    print(seconds, 'Seconds', end=' ')
print()

Input:                  Input:

200                     86400

Output:                 Output:

3 Minutes 20 Seconds    1 Days

-------------------------------------------------------------------------------------------------------------------------

String Methods:
--------------------

Extended Slicing:
--------------------

Syntax:  variable[start_index:end_index:step]

Code:

a = "Waterfall"  
part = a[1:6:3]  
print(part)

Output:

ar

String Methods:

isdigit()
strip()
lower()
upper()
startswith()
endswith()
replace() and more...

Isdigit:
--------------

Syntax: str_var.isdigit()

Gives True if all the characters are digits. Otherwise, False

Code:

is_digit = "4748".isdigit()  
print(is_digit)

Output:

True

Strip:
------------

Syntax: str_var.strip()  

Removes all the leading and trailing spaces from a string.  

Code:

mobile = " 9876543210 "  
mobile = mobile.strip()  
print(mobile)

Output:
9876543210

Strip - Multiple Characters:
---------------------------------------

Removes all spaces, comma(,) and full stop(.) that lead or trail the string.  

Code:

name = ", .. ,, ravi ,, .. ."  
name = name.strip(" ,.")  
print(name)

Output:

ravi

Replace:
--------------

Syntax: str_var.replace(old,new)  

Gives a new string after replacing all the occurrences of the old substring with the new substring.  

Code:

sentence = "teh cat and teh dog"  
sentence = sentence.replace("teh","the")  
print(sentence)

Output:

the cat and the dog

Startswith:
----------------

Syntax: str_var.startswith(value)  

Gives True if the string starts with the specified value. Otherwise, False  

Code:

url = "https://onthegomodel.com"  
is_secure_url = url.startswith("https://")  
print(is_secure_url)

Output:

True

Endswith:
--------------

Syntax: str_var.endswith(value)  

Gives True if the string ends with the specified value. Otherwise, False 

Code:

gmail_id = "rahul123@gmail.com"  
is_gmail = gmail_id.endswith("@gmail.com")  
print(is_gmail)

Output:

True

Upper:
-------------

Syntax: str_var.upper()  

Gives a new string by converting each character of the given string to uppercase.  

Code:

name = "ravi"  
print(name.upper())

Output:

RAVI

Lower:
-------------------

Syntax: str_var.lower()  

Gives a new string by converting each character of the given string to lowercase.  

Code:

name = "RAVI"  
print(name.lower())

Output:

ravi

Coding Pratice-11:
--------------------------

Valid password:
---------------------

password = input()
contains_digit = False

for character in password:
  is_digit = character.isdigit()
  
  if is_digit:
    contains_digit = True
    
if contains_digit:
  print("Valid Password")
else:
  print("Invalid Password")
  
Input:

Qwerty00

Output:

Valid Password

Valid password-2:
------------------------

password = input()
contains_digit = False

for character in password:
  
  if not password.islower():
    contains_digit = True
    
if contains_digit:
  print("Valid Password")
else:
  print("Invalid Password")
  
  
Input:

stadium

Output:

Invalid Password

Valid Password-3: -- one uppercase & one lowercase & one digit

password = input()
contains_digit = False

for character in password:
  is_digit = character.isdigit()
  
  if is_digit:
    contains_digit = True

is_all_lower = (password.lower() == password)
is_all_upper = (password.upper() == password)
contains_lower_and_upper = (not is_all_lower) and (not is_all_upper)

is_valid_password = (contains_digit and contains_lower_and_upper)

if is_valid_password:
  print("Valid Password")
else:
  print("Invalid Password")
  
Assignment-11:
-----------------

Palindrome-2:
-----------------

word = input()
word = word.upper()
word = word.lower()
word = word.replace(" ","")   # replace spaces
word = word.replace("'","")   # replace single quotes
revrves_word = ""
for i in word:
    revrves_word = i +revrves_word

if revrves_word == word:
    print("True")
else:
    print("False")
    
Input:

No lemon no melon

True

 Remove vowels in a sentence: -- a,e,i,o,u 
------------------------------

s= input()
vowels="aeiouAEIOU"
new_s=s
for x in s:
    if x in vowels:
       new_s=new_s.replace(x,"")
print (new_s)

Letter or digit or special character:
---------------------------------------------

ch = input()
if ch.isupper():
    print('Uppercase Letter')
elif ch.islower():
    print('Lowercase Letter')
elif ch.isdigit():
    print('Digit')
else:
    print('Special Character') 
    
--------------------------------------------------------------------------------------------------------------------------
    
Coding Pratice-12:
----------------------

Word pattern:

s = input()
length = len(s)
for i in range(1,length+1):
    print(s[:i])
    
Output:

R
Ra
Rah
Rahu
Rahul

shuffle string:
--------------------

s =input()
len_s = len(s)
shuffled_s = ""

for i in range(len_s):
    index=int(input())
    shuffled_s=shuffled_s+s[index]
print(shuffled_s)

Prime Number:
------------------

n=int(input())
factors = 0

for i in range(2,n):
    if(n%i==0):
        factors=factors+1 

if factors == 0:
    print("Prime Number")
else:
    print("Not a Prime Number")
    
solid square:
---------------

n=int(input())

for i in range(1,n+1,1):
    for j in range(1,n+1,1):
        print(j,end=" ")
    print()
    
Input:

5

Output:

1 2 3 4 5 
1 2 3 4 5 
1 2 3 4 5 
1 2 3 4 5 
1 2 3 4 5 

Numbers in square pattern-2:
----------------------------------

n=int(input())

for i in range(1,n+1,1):
    for j in range(1,n+1,1):
        print(i,end=" ")
    print()
    
Input:

5

Output:

1 1 1 1 1 
2 2 2 2 2 
3 3 3 3 3 
4 4 4 4 4 
5 5 5 5 5 

numbers in rectangular pattern-1:
------------------------------------------

r = int(input())
c = int(input())


for i in range(1,r+1,1):
    for j in range(1,c+1,1):
        print(j, end = ' ')
    print()
    
Input:

2
3

Output:

1 2 3
1 2 3

numbers in rectangular pattern-2:
------------------------------------------

r = int(input())
c = int(input())


for i in range(1,r+1,1):
    for j in range(1,c+1,1):
        print(i, end = ' ')
    print()
    
Input:

2
3

Output:

1 1 1
2 2 2

Solid Diamond:
----------------------

n = int(input())

for i in range(n-1):
    for j in range(n-i-1):
        print(" ",end="")
    for j in range(i+1):
        print("*",end=" ")
    print()
for i in range(n):
        for j in range(i):
            print(" ",end="")
        for j in range((n-i)):
            print("*",end=" ")
        print()
        
Input:

3

Output:

  * 
 * * 
* * * 
 * * 
  * 
  
 Assignment-12:
 ----------------------
 
 Half-Pyrmid-3:
 -------------------
 
r = int(input())
c = int(input())
num=r
for i in range(c):
    for j in range(i+1):
         print(num,end=" ")
         num = num+1
    print()
    
    
Input:

10
5

Output:

10 
11 12 
13 14 15 
16 17 18 19 
20 21 22 23 24 

 Half-Pyrmid-4:
 ----------------------
 
r = int(input())
c = int(input())
k=r-1
for i in range(c):
    k=k+i
m=c+k


for i in range(c):
    for j in range(i+1):
        print(format(m,"<1"),end=" ")
        m=m-1
    print()
    
Input:

10
5

Output:

24 
23 22 
21 20 19 
18 17 16 15 
14 13 12 11 10 

sum of even numbers:
---------------------------

n = int(input())
i=2
sum = 0

while i<=n:
    sum = sum+i
    i=i+2
print(sum)

For:
------

n=int(input())
sum=0
for i in range(2,n+1,2):
    sum+=i
print(sum)

Input:

5

Output:

6
         
sum of odd numbers:
--------------------------

n=int(input())
sum=0
for i in range(1,n+1,2):
    sum+=i
print(sum)

Input:

10

Output:

25

composite number:   -- divisible by 1,2,3,4,6,12
-----------------------

n = int(input())
count = 0

for i in range(1, n+1):
    if(n % i == 0):
        count += 1

if(count > 2):
   print("True")
else:
   print("False")
   
Input:

12

Output:

True

Striped rectangle:
--------------------------

M=int(input())
N=int(input())


for i in range(M):
    for j in range(N):
        if (i%2==0):
            print("+",end=" ")
        else:
            print("-",end=" ")
    print()
    
Input:

5
7

Output:

+ + + + + + + 
- - - - - - - 
+ + + + + + + 
- - - - - - - 
+ + + + + + + 

Hollow Rectangle-2:
--------------------------

M = int(input())
N = int(input())


horizontal_border = f'+{"-" * N}+'
line = f'|{" " * N}|'


output = horizontal_border
for row in range(M):
    output += f'\n{line}'
output += f'\n{horizontal_border}'
print(output)

Input:

3
10

Output:

+----------+
|          |
|          |
|          |
+----------+

-----------------------------------------------------------------------------------------------

coding pratice-13:
--------------------------

Half-Pyrmid-2:
---------------------

r = int(input())
num=1
for i in range(r):
    for j in range(i+1):
         print(num,end=" ")
         num = num+1
    print()
    
Input:

5

Output:

1 
2 3 
4 5 6 
7 8 9 10 
11 12 13 14 15

prime numbers from 1 to N:
-----------------------------------

n=int(input())
for i in range(2,n+1):
    for j in range(2,i):
        if(i%j == 0):
            break
    else:
        print(i)
        
Input:

10

Output:

2
3
5
7

prime numbers from M to N:
------------------------------

low = int(input())
high = int(input())
for num in range(low, high+1):
    if(num>1):
        for i in range(2,num):
            if(num%i)==0:
                break
        else:
            print(num)
            
Input:

5
11

Output:

5
7
11

Pythagoras triplets:
----------------------------

L=int(input())
count=0
for a in range(1,L-1):
    for b in range(a+1,L):
        for c in range(b+1,L+1):
            x=a*a
            y=b*b
            z=c*c
            if (x+y==z):
                count+=1


print(count)

Input:

5

Output:

1

Indivisible Numbers:
--------------------------

n = int(input())
number = 0
for i in range(1,n+1):
    if i % 2 != 0 and i % 3 != 0 and i % 4 != 0 and i % 5 != 0 and i % 6 != 0 and i % 7 != 0 and i % 8 != 0 and i % 9 != 0 and i % 10 != 0:
        number += 1
print(number)

Input:

11

Output:

2

Inverted Full pyramid:
----------------------------------

n = int(input())

for i in range(n):
    for j in range(i):
        print(" ",end="")
    for j in range((n-i)):
        print(j+1,end=" ")
    print()
    
Input:

5
    
Output:

1 2 3 4 5 
 1 2 3 4 
  1 2 3 
   1 2
    1
    
Butterfly:
---------------------

n =int(input())

for i in range(1, n+1):
    stars = "* " * i
    middle_spaces = "  " * (2*(n-i))
    print(stars + middle_spaces + stars)
    
for i in range(n):
    stars = "* " * (n-i)
    middle_spaces = "  " * (2*i)
    print(stars + middle_spaces + stars)
    
 
Input:

5

Output:

*                 * 
* *             * * 
* * *         * * * 
* * * *     * * * * 
* * * * * * * * * * 
* * * * * * * * * * 
* * * *     * * * * 
* * *         * * * 
* *             * * 
*                 * 

LCM:
----------

n1 = int(input())
n2 = int(input())

if n1>n2:
    higher = n1
else:
    higher = n2
    
value = higher
while True:
    if higher%n1 == 0 and higher%n2 == 0:
        print(higher)
        break
    else:
        higher = higher+value
        
Input:

12
8

Output:

24

GCD:
-------

def hcf(a, b):
    if(b == 0):
        return a
    else:
        return hcf(b, a % b)

n1 = int(input())
n2 = int(input())
  
print(hcf(n1,n2))

Input:

4
6

Output:

2

Digit-8:
-----------

n = int(input())


no_of_rows = (2*n) + 1
for i in range(1, no_of_rows+1):
    if (i == 1) or (i == (n+1)) or (i == no_of_rows):
        print("* " * n)
    else:
        spaces = "  " * (n-2)
        print("* " + spaces + "* ")


Input:

5

Output:

* * * * * 
*       * 
*       * 
*       * 
*       * 
* * * * * 
*       * 
*       * 
*       * 
*       * 
* * * * * 

Full pyramid-3:
-------------------

n = int(input())

for i in range(1,n+1):
    zeroes = "0 " * (n-i)
    ones = "1 " * ((2*i)-1)
    print(zeroes + ones + zeroes)
    
Input:

5

Output:

0 0 0 0 1 0 0 0 0 
0 0 0 1 1 1 0 0 0 
0 0 1 1 1 1 1 0 0 
0 1 1 1 1 1 1 1 0 
1 1 1 1 1 1 1 1 1 

Kth Largest Factor:
----------------------

n = int(input())
k = int(input())
factors = []
for i in range(n):
	if (n % (i+1)) == 0:
		factors.append(i+1)
if k > len(factors):
	print(1)
else:
	print(factors[-k])
    
Input:

12
2

Output:

6

pyramid:
-----------

n = int(input())

for i in range(1,n+1):
    zeroes = ". " * (n-i)
    ones = "0 " * ((2*i)-1)
    print(zeroes + ones + zeroes)
    
Input:

5

Output:

. . . . 0 . . . . 
. . . 0 0 0 . . . 
. . 0 0 0 0 0 . . 
. 0 0 0 0 0 0 0 . 
0 0 0 0 0 0 0 0 0 

W pattern with *:
-----------------------

N = int(input())

print('* ' * (2 * N - 1))

for i in range(1, N):
    print(' ' * i, end='')
    print('* ' * (N - i), end='')
    print('  ' * (i - 1), end='')
    print('* ' * (N - i), end='')
    print()
    
Input:

5

Output:

* * * * * * * * * 
 * * * * * * * * 
  * * *   * * * 
   * *     * * 
    *       *
    
Digit - 9:
--------------

n = int(input())
rows = 2 * n - 1
line = '* ' * n
dline = '* ' + '  ' * (n - 2) + '* '
oline = '  ' * (n - 1) + '* '
for n in range(rows):
    if n == 0:
        print(line)
    elif n < (rows - 1) / 2:
        print(dline)
    elif n == (rows - 1) / 2:
        print(line)
    elif (rows - 1) / 2 < n < (rows - 1):
        print(oline)
    elif n == (rows - 1):
        print(line)
        
Input:

4

Output:

* * * * 
*     * 
*     * 
* * * * 
      * 
      * 
* * * * 

Armstrong number between two intervals:
--------------------------------------------

A=int(input())
B=int(input())
count = 0
for i in range(A, B+1):
   n = len(str(i))
   sum = 0
   temp = i
   while temp > 0:
       digit = temp % 10
       sum += digit ** n
       temp //= 10
   if i == sum:
    print(i,end=" ")
    count+=1                #increment count
if count==0:               #if no Armstrong Number is found print -1
    print(-1)
  
Input:

150
200

Output:

153
    
Number Diamond:
-------------------

n = int(input())

for i in range(n):
    for j in range(n-i-1):
        print(" ",end="")
    for j in range(i+1):
        print(j+1,end=" ")
    print()
for i in range(n-1):
    for j in range(i+1):
        print(" ",end="")
    for j in range(n-i-1):
        print(j+1,end=" ")
    print()
    
Input:

5

Output:

    1 
   1 2 
  1 2 3 
 1 2 3 4 
1 2 3 4 5 
 1 2 3 4 
  1 2 3 
   1 2 
    1 
    
Shade Diamond:
--------------------

n = int(input())

for i in range(n):
    for j in range(n-i-1):
        print(" ",end="")
    for j in range(i+1):
        print("*",end=" ")
    print()

for j in range(n-1):
    stars = ' ' * (j+1) + '*' +' ' * (n*2 - 2*j -5) + '*'
    if j == (n-2):
        stars = ' ' * (n-1) + '*'
    
    print(stars)
    
    
Input:

5

Output:

    * 
   * * 
  * * * 
 * * * * 
* * * * * 
 *     *
  *   *
   * *
    *
    
Numbers in Rectangular Pattern - 3:
----------------------------------------

r = int(input())
c = int(input())

number = 1
for i in range(r):
    pattern = ""
    
    for j in range(c):
        pattern = pattern +(str(number) + " ")
        number = number+1
    print(pattern)
    
Input:

2
3

Output:

1 2 3
4 5 6

Numbers in Square Pattern - 3:
------------------------------------

n = int(input())

number = 1
for i in range(n):
    pattern = ""
    
    for j in range(n):
        pattern = pattern +(str(number) + " ")
        number = number+1
    print(pattern)

Input:

3

Output:

1 2 3 
4 5 6 
7 8 9   

coding pratice-14:
---------------------------

Hollow Full pyramid-2:
--------------------------

n = int(input())

for i in range(1, n+1):
    
    if i == 1 :
        a = " "*(n - i) + str(i) + " "
        print(a)
    elif i == n:
        a = ""
        for count in range(1,n+1):
            a = a + str(count) + " "
        print(a)
    else:
        a = " " * (n-i) + str(1) + " " + " " * (2*n - (4 + 2*len(" " * (n-i)))) + str(i) + " "
        print(a)

Input:

5

Output:

    1 
   1 2 
  1   3 
 1     4 
1 2 3 4 5

Hollow Inverted Full Pyrmid-2:
--------------------------------------

n = int(input())

for i in range(n):
    
    if i == 0 :
        a = ""
        for count in range(1,n+1):
            a = a + str(count) + " "
        print(a)
      
    elif i == n-1:
        a = " " * i + str(1) +" "
        print(a)
        
    else:
        a = " " * i + str(1) + " " + " " * (2*n - (4 + 2*len(" " * i))) + str(n - i) + " "
        print(a)
        
Input:

5

Output:

1 2 3 4 5 
 1     4 
  1   3 
   1 2 
    1



--------------------------------------------------------------------------------------------------------------

Break:
----------

for i in range(5):
  if i == 3:
    break
  print(i)
print("END")

Output:

0
1
2
END

Continue:
--------------

for i in range(5):
  if i == 3:
    continue
  print(i)
print("END")

Output:

0
1
2
4
END

coding pratice-16:
-------------------------

First Negative Number:
----------------------------

n = int(input())

for i in range(n):
    number = int(input())
    if number < 0:
        print(number)
        break
        
Input:

5
8
11
-96
49

Output:

-96

First Uppercase Letter:
-----------------------------

word=input()

for i in word:
    if (i==i.upper()) and not i.isdigit():
        print(i)
        break
        
Input:

100Meters

Output:

M

First word in uppercase:
--------------------------------

sentence = input()

first_word_end_index = 0

for char in sentence:
    if char == " ":
        break
    else:
        first_word_end_index = first_word_end_index + 1
    

first_word = sentence[0:first_word_end_index]
first_word_uppercase = first_word.upper()

output = first_word_uppercase + sentence[first_word_end_index:]

print(output)

Input:

Python is a programming language.

Output:

PYTHON is a programming language.

prime number or not:
----------------------------

n = int(input())
is_prime = True
for i in range(2, n):
    if (n % i) == 0:
        is_prime = False
        break
print(is_prime)

Input:

22

Output:

False

First Prime Number in the range:
-------------------------------------

m = int(input())
n = int(input())

if not (m > 1):
  m = 2
  
no_primes = True
for i in range(m, n+1):
  is_prime = True
  for j in range(2, i):
    if i % j == 0:
      is_prime = False
      break
  if is_prime:
    print(i)
    no_primes = False
    break
if no_primes:
  print("No prime numbers in the given range")


Input:

25
50

Output:

25



Assignment-16:
------------------

composite numbers in the range:
--------------------------------------

M = int(input())
N = int(input())

for number in range(M,N+1):
    count = 0
    #divisor search, do not count the number itself and 1
    for divider in range(2,number//2+1):
        if number%divider == 0:
            count+=1
    if count >= 1:
        print(number)
        
Input:

2
9

Output:

4
6
8
9

Multiples of 5:
---------------------

N = int(input())
numbers=[]

for i in range(0,N):
    n = int(input())
    if n % 5 != 0:
        numbers.append(n)
    else:
        break
        
for n in numbers:
    print(n)
 
Input:

6
1
2
3
5
9
6

Output:

1
2
3

Multiples of 3:
-----------------------

list1 = []
n = int(input(''))
for i in range(n):
  n1 = int(input(''))
  if n1 % 3 == 0:
    list1.append(n1)
for j in list1:
  print(j)
  
Input:

6
1
2
3
5
9
6

Output:

3
9
6

Kth largest factor of N:
-----------------------------

n = int(input())
k = int(input())
factors = []
for i in range(n):
	if (n % (i+1)) == 0:
		factors.append(i+1)
if k > len(factors):
	print(1)
else:
	print(factors[-k])
    
Input:

12
3

Output:

4

First Prime number:
-----------------------

n = int(input())

for i in range(1,n+1):
    count = 0
    a = int(input())
    
    for j in range(2,a+1):
        if(a % j == 0):
            count = count+1 
    if count == 1:
        print(a)
        break
        

Input:

1
10
4
3
2

Output:

3
----------------------------------------------------------------------------------------------------------------------------------------

Grand Assignment-2:
----------------------------

solid diamond:
---------------------

n = int(input())

for i in range(n-1):
    for j in range(n-i-1):
        print(" ",end="")
    for j in range(i+1):
        print("*",end=" ")
    print()
for i in range(n):
        for j in range(i):
            print(" ",end="")
        for j in range((n-i)):
            print("*",end=" ")
        print()
        
Input:

5

Output:

    * 
   * * 
  * * * 
 * * * * 
* * * * * 
 * * * * 
  * * * 
   * * 
    * 
    
Sandglass star:
--------------------

n = int(input())

for i in range(n-1):
    for j in range(i):
        print(" ",end="")
    for j in range(n-i):
        print("*",end=" ")
    print()
for i in range(n):
    for j in range(n-i-1):
         print(" ",end="")
    for j in range((i+1)):
        print("*",end=" ")
    print()
    
Input:

5

Output:

* * * * * 
 * * * * 
  * * * 
   * * 
    * 
   * * 
  * * * 
 * * * * 
* * * * * 

Alphabetic Symbol:
----------------------

n = int(input())

for i in range(n):
    for j in range(i+1):
        print(chr(65+j),end=" ")
    print()
    
Input:

4

Output:

A 
A B 
A B C 
A B C D 

Right triangle pattern:
----------------------------

n = int(input())
for i in range(1, n+1):
    space = " " * (i-n)
    left_nums = ""
    right_nums = ""
    for j in range(1,i+1):
        left_nums =  left_nums + str(j) 
        right_nums = str(j) + right_nums
    print(space+left_nums+right_nums[1:])
    
    
Input:

4

Output:

1
121
12321
1234321

Evens and Odds:
-------------------

M = int(input())
N = int(input())

count_odds = 0
count_even = 0

for i in range(M, N+1):
    if i % 2 == 0:
        count_even += 1
    else:
        count_odds += 1

print(count_odds)
print(count_even)

Input:

2
11

Output:

5
5

count vowels and consonants:
--------------------------------------

s= input()

vowel="aeiouAEIOU"
s = s.replace(" ","")
vowels = 0
consonants = 0

for x in s:
    if x in vowel:
        vowels = vowels + 1
    else:
        consonants = consonants + 1
print(vowels)
print(consonants)

Input:

Good Morning

Output:

4
7

One Color:
-------------------

s = input()

g = "G"
r = "R"
c_g = 0
c_r = 0

for ch in s:
	if ch == g:
		c_g += 1
	elif ch == r:
		c_r += 1
if c_g <= c_r:
	print(c_g)
else:
	print(c_r)
    
Input:

RGG

Output:

1

camelcase to snakecase:
---------------------------------

s = input()

s = s[0].lower() + s[1:]

for i in s:
    if i.isupper():
        s = s.replace(i, f"_{i.lower()}")
        #s = s.replace(i,"-"+str(i.lower()))
print(s)

Input:

PythonLearning

Output:

python_learning

sum of non-primes:
------------------------

n = int(input())

is_primes = []  # list of potential prime numbers(contains primes and non primes)

for count in range(n):
    read = int(input(""))
    is_primes.append(read)

non_primes = []

for num in is_primes:
    if num == 2 or num == 3:
        pass
    else:
        for i in range(2, num):
            if num % i == 0:
                non_primes.append(num)
                break
            else:
                pass

print(sum(non_primes))

Input:

5
8
11
96
49
25

Output:

178

----------------------------------------------------------------------------------------------------------------

Ord:
----------

To find the Unicode value of a character, we use the ord()

ord(character) gives unicode value of the character.

Code:

unicode_value = ord("A")
print(unicode_value)

Output:
65

chr:
---------

To find the character with the given Unicode value, we use the chr()

chr(unicode) gives character with the unicode value.  

Code:

char = chr(75)
print(char)

Output:

K 

Unicode Ranges:
-------------------

48 - 57 -> Number Digits (0 - 9)

65 - 90 -> Capital Letters (A - Z)

97 - 122 -> Small Letters (a - z)

Rest -> Special Characters, Other Languages

Printing Characters:
-------------------------

The below code will print the characters from A to Z

Code:

for unicode_value in range(65,91):
    print(chr(unicode_value))
    
Comparing Strings:
--------------------

print("A" < "B")

Output:

True

print("BAD" >= "BAT")

Output:

False

print("98" < "984")

Output:

True

Best Practices:
----------------------

Naming Variables Rule #1:
----------------------------

Use only the below characters  

Capital Letters ( A – Z )
Small Letters ( a – z )
Digits ( 0 – 9 )
Underscore(_)

Examples:
age, total_bill

Naming Variables Rule #2:
---------------------------------

Below characters cannot be used  

Blanks ( )
Commas ( , )
Special Characters
( ~ ! @ # $ % ^ . ?, etc. )

Naming Variables Rule #3:
---------------------------------------

Variable name must begin with  

Capital Letters ( A – Z )
Small Letters ( a – z )
Underscore( _ )

Naming Variables Rule #4:
-----------------------------

Cannot use Keywords, which are reserved for special meaning  

int
str
print etc.,

Keywords:
-------------------------

Words which are reserved for special meaning      

help("keywords")

Case Styles
Camel case: totalBill
Pascal case: TotalBill
Snake case: total_bill
Snake case is preferred for naming the variables in Python.


Round:
-----------------

Rounding Numbers

round(number, digits(optional))  Rounds the float value to the given number of decimal digits.

digits -> define the number of decimal digits to be considered for rounding.

when not specified default is 0

code:

a = round(3.14,1)
print(a)
a = round(3.14)
print(a)

Output:

3.1
3

Floating Point Approximation:
--------------------------------------

Float values are stored approximately.

Code:

print(0.1 + 0.2)

Output:

0.30000000000000004

Floating Point Errors:
----------------------------

Sometimes, floating point approximation gives unexpected results.

Code:

print((0.1 + 0.2) == 0.3)

Output:

False

To avoid these unexpected results, we can use round()

Code:

a = round((0.1 + 0.2), 1)
print(a)
print(a == 0.3)

Output:

0.3
True

Comments:
------------------

Comment starts with a hash #  

It can be written in  its own line next to a statement of code.

Code:

n = 5
# Finding if Even
even = (n % 2 == 0)
print(even) # prints boolean value

Output:

False

------------------------------------------------------------------------------------------------------------------------

Coding pratice-17:
-----------------------------

Hallow Diamond:
------------------------

n = int(input())

for i in range(1,n):
    for j in range(1,2*n):
        if i+j == n+1 or j-i == n-1:
            print("*",end="")
        else:
            print(" ",end="")
    print()
for i in range(1,n+1):
    for j in range(1,2*n):
        if i == j or i+j == 2*n:
            print("*",end="")
        else:
            print(" ",end="")
    print()
    
Input:

5

Output:

    *    
   * *   
  *   *  
 *     * 
*       *
 *     * 
  *   *  
   * *   
    *  

Hollow Diamond-2:
---------------------------

n = int(input())

for i in range(n,0,-1):
    for j in range(i,0,-1):
        print("*",end = " ")
    for j in range(2*(n-i)):
        print(" ",end=" ")
    for j in range(i,0,-1):
        print("*",end= " ")
    print()
    
for i in range(n):
    for j in range(i+1):
        print("*",end = " ")
    for j in range(2*(n-i-1)):
        print(" ",end=" ")
    for j in range(i+1):
        print("*",end= " ")
    print()

Input:

3

Output:

* * * * * * 
* *     * * 
*         * 
*         * 
* *     * * 
* * * * * * 

pattern mistake:
-------------------

n = int(input())
for i in range(0, n):
    row_out = " " * (n-i-1)
    row_out = row_out + "$" * n
    print(row_out)

Input:

3

Output:

  $$$
 $$$
$$$    

Assignment-17:
-----------------

Hollow Diamond:
----------------------

n = int(input())

for i in range(1,n):
    for j in range(1,2*n):
        if i+j == n+1 or j-i == n-1:
            print(chr(64+i),end="")
        else:
            print(" ",end="")
    print()
for i in range(1,n+1):
    for j in range(1,2*n):
        if i == j or i+j == 2*n:
            print(chr(65+n-i),end="")
        else:
            print(" ",end="")
    print()
        
        
Input:

5

Output:

    A    
   B B   
  C   C  
 D     D 
E       E
 D     D 
  C   C  
   B B   
    A    
    
As you are using comma , as separator in print statements, it will print space by default for every comma. So try to use string concatenation instead of a comma , .,

Assignment-17:
-------------------

sum of N terms in harmonic series:
------------------------------------------

N = int(input())
j = 0
for i in range(1,N+1):
  j = j + 1/i
print(round(j,2))

Input:

5

Output:

2.28

roots of quadratic equation:
-------------------------------------

a, b, c = [int(input()) for _ in range(3)]
if a == 0:
    print(round(-c / b, 2))
else:
    d = b * b - 4 * a * c
    if d < 0:
        print('no roots')
    elif d == 0:
        print(round(-b / 2 / a, 2))
    else:
        print(round((-b + d ** 0.5) / 2 / a, 2))
        print(round((-b - d ** 0.5) / 2 / a, 2))
        
Input:

1
-5
6

Output:

3.0
2.0

Temperature conversion:
-----------------------------------

n = input()
Dc = n[-1]
num = n[:-1]
fv = float(num)

if Dc == "C":
    c = fv
    c_string = str(c)
    F = ((9/5)*c+32)
    F_string = str(F)
    K = c + 273
    K_string = str(K)
    print(c_string + "C")
    print(F_string + "F")
    print(K_string + "K")

elif Dc == "F":
    f = (fv)
    f_string = str(f)
    c = ((f-32) * 5/9)
    c = round(c,2)
    c_string = str(c)
    K = c + 273
    K = round(K,2)
    K_string = str(K)
    print(c_string + "C")
    print(f_string + "F")
    print(K_string + "K")
    
elif Dc == "K":
    k = (fv)
    k_string = str(k)
    c = (k - 273)
    c = round(c,2)
    c_string = str(c)
    f = ((9/5)*c+32)
    f = round(f,2)
    f_string = str(f)
    print(c_string + "C")
    print(f_string + "F")
    print(k_string + "K")
    
Input:

25C

Output:

25.0C
77.0F
298.0K

Replacing characters of sentence:
----------------------------------------

word = input()
new_word = ''


for c in word:
    asci = ord(c) #a,97
    if c==" ": #correct the if condition
        new_word = new_word + " "
    else:
        new_word = new_word + chr(asci+1) #98,b
print(new_word)

Input:

Hello World

Output:

Ifmmp Xpsme

Diamond:
------------

n = int(input())

for i in range(1,n+1):
    spaces = ". " * (n-i)
    zeroes = "0 " * ((2*i)-1)
    print(spaces + zeroes  + spaces)

for j in range(1,i):
    zeroes = "0 " * ((2*n) - (2*j) -1)
    spaces = ". " * j
    print(spaces + zeroes  + spaces)
    
Input:

5

Output:

. . . . 0 . . . . 
. . . 0 0 0 . . . 
. . 0 0 0 0 0 . . 
. 0 0 0 0 0 0 0 . 
0 0 0 0 0 0 0 0 0 
. 0 0 0 0 0 0 0 . 
. . 0 0 0 0 0 . . 
. . . 0 0 0 . . . 
. . . . 0 . . . . 

-----------------------------------------------------------------------------------------

Floor Division Operator
To find integral part of quotient we use Floor Division Operator //

a // b  

Code:

print(3 // 2)

Output:

1

Compound Assignment Operators:
------------------------------------------

Different compound assignment operators are +=, -=, *=, /=, %=

a += 1 is similar to a = a + 1

Single And Double Quotes:
-----------------------------

sport = 'Cricket'
print(type(sport))
sport = "Cricket"
print(type(sport))

Output:

<class 'str'>
<class 'str'>

Examples - Escape Characters
Escape Characters start with a backslash in Python

\n -> New Line
\t -> Tab Space
\\ -> Backslash
\' -> Single Quote
\" -> Double Quote

coding pratice-18:
-------------------------

cumulative sum:

n = int(input())

sum = 0
for i in range(n):
    number = int(input())
    sum =sum+number
    print(sum)
    
Input:

5
8
11
-96
49
85

Output:

8
19
-77
-28
57

Average:
---------------

n = int(input())

sum = 0
for i in range(1,n+1):
    number = int(input())
    sum =sum+number
    avg = sum / i
    print(round(avg,3))
    
Input:

5
8
11
-96
49

Output:

8.0
9.5
-25.667
-7.0
11.4

Double char:
-------------------

word = input()

new_word = ""

for char in word:
    new_word = new_word+ (char*2)
    
print(new_word)

Input:

The

Output:

TThhee

subsquence:
-----------------

full_string = input()
subsequence = input()

subseq_index = 0 #red arrow
subseq_len = len(subsequence)

for char in full_string: #blue arrow
    #checking if blue and red arrow characters are equal
    if char == subsequence[subseq_index]:
        subseq_index += 1 #red arrow moving a step further
        if subseq_index == subseq_len: #End of second string
            break

if subseq_index == subseq_len:
    print("Yes")
else:
    print("No")
    
Input:

abcde
ace

Output:

Yes

Number pyramid:
-------------------

n = int(input())
for i in range(1, n+1):
    spaces = " "*(n - i)
    left_nums = ""
    right_nums = ""
    for j in range(1, i+1):
        left_nums = str(j) + left_nums
        right_nums = right_nums + str(j)
    print(spaces + left_nums + right_nums[1:])


Input:

5

Output:

    1
   212
  32123
 4321234
543212345

Assignment-18:
---------------------

Hyphanate Letters:
-------------------------

W = input()
W = '-'.join(W[i:i+ 1] for i in range(0, len(W), 1))
print(W)

Input:

Hello

Output:

H-e-l-l-o

Maximum:
---------------

list1 = []
N = int(input())
for i in range(N):
    s = eval(input())
    list1.append(s)
    print(max(list1))
    
Input:

6
1
0
3
2
9
8

Output:

1
1
3
3
9
9

Diamond crystal:
-----------------------

N = int(input())

for i in range(0,N):
    print(' '*(N-i-1)+'/'+' '*(2*i)+'\\')
for i in range(0,N):
    print(' '*(i)+'\\'+' '*(2*(N-i-1))+'/')
    
Input:

5

Output:

    /\
   /  \
  /    \
 /      \
/        \
\        /
 \      /
  \    /
   \  /
    \/
    
-----------------------------------------------------------------------------------------------------------------------

Data Structures:
----------------------

Data Structures allow us to store and organize data efficiently.
This will allow us to easily access and perform operations on the data.

In Python, there are four built-in data structures

List
Tuple
Set
Dictionary

List:
---------

List is the most versatile python data structure.
Holds an ordered sequence of items.

Creating a List:
------------------------

Created by enclosing elements within [square] brackets.
Each item is separated by a comma.

Code:

a = 2
list_a = [5, "Six", a, 8.2]
print(type(list_a))
print(list_a)

Output:

<class 'list'>
[5, 'Six', 2, 8.2]

Creating a List of Lists:
---------------------------

Code:

a = 2
list_a = [5, "Six", a, 8.2]
list_b = [1, list_a]
print(list_b)

Output:

[1, [5, 'Six', 2, 8]]

Length of a List:
----------------------

Code:

a = 2
list_a = [5, "Six", a, 8.2]
print(len(list_a))

Output:

4

Accessing List Items:
----------------------------

To access elements of a list, we use Indexing.

Code:

a = 2
list_a = [5, "Six", a, 8.2]
print(list_a[1])

Output:

Six

Iterating Over a List:
---------------------------

Code:

a = 2
list_a = [5, "Six", a, 8.2]
for item in list_a:
    print(item)
    
Output:

5
Six
2
8.2

List Concatenation:
---------------------------

Similar to strings, + operator concatenates lists.

Code:

list_a = [1, 2, 3]
list_b = ["a", "b", "c"]
list_c = list_a + list_b
print(list_c)

Output:


[1, 2, 3, 'a', 'b', 'c']

Adding Items to List:
----------------------------
Code:

list_a = []
print(list_a)
for i in range(1,4):
    list_a += [i]
print(list_a)

Output:

[]
[1, 2, 3]

Repetition:
-----------------

* Operator repeats lists.

code:

list_a = [1, 2]
list_b = list_a * 3
print(list_b)

Output:

[1, 2, 1, 2, 1, 2]

List Slicing:
--------------------

list_a = [5, "Six", 2, 8.2]
list_b = list_a[:2]
print(list_b)

Output:

[5, 'Six']

Extended Slicing:
---------------------

Similar to string extended slicing, we can extract alternate items using step.

Code:

list_a = ["R", "B", "G", "O", "W"]
list_b = list_a[0:5:3]
print(list_b)

Output:

['R', 'O']

Converting to List:
------------------------

list(sequence) takes a sequence and converts it into list.

Code:

color = "Red"
list_a = list(color)
print(list_a)

Output:

['R' , 'e' , 'd']

Lists are Mutable:
------------------------

Lists can be modified.
Items at any position can be updated.

Code:

list_a = [1, 2, 3, 5]
print(list_a)
list_a[3] = 4
print(list_a)

Output:

[1, 2, 3, 5]
[1, 2, 3, 4]

Strings are Immutable:
-----------------------------

Strings are Immutable (Can’t be modified).

Code:

message = "sea you soon"
message[2] = "e"
print(message)

Output:

TypeError: 'str' object does not support item assignment

coding pratice-19:
-----------------------

List concatenation:
---------------------

num_list =  [10, 20, 40, 100]
n = int(input())
first_list = [n] + num_list # Add the number in the beginning
second_list = num_list + [n]# Add the number at the end

print(first_list)
print(second_list)

Input:

20

Output:

[20, 10, 20, 40, 100]
[10, 20, 40, 100, 20]

convert string to list:
------------------------

word = input()
word_list = list(word)
print(word_list)

Input:

python

Output:

['P', 'y', 't', 'h', 'o', 'n']

List indexing:
-------------------

color_list = ["Red", "Orange", "Yellow", "Pink", "Green", "Blue", "Purple", "Black", "White"]
# Write your code here
index = int(input())
print(color_list[index])

Input:

3

Output:

Pink

List indexing-2:
---------------------

programming_languages_list = ["Python", "Java", "Ruby", "C", "C++", "Go", "R", "JavaScript", "Swift", "PHP", "Kotlin", "Perl"]
# Write your code here
m = int(input())

for i in range(m):
    index = int(input()) # Read the list indexes
    print(programming_languages_list[index]) #print
    
Input:

2
1
4

Output:

Java
C++

List Repetition:
---------------------

n = int(input())
m = int(input())

list_a = [n] * m 
print(list_a)

Input:

5
4

Output:

[5, 5, 5, 5]

Greater than N:
---------------------

num_list = [1, 6, 32, 93, 71, -20, 30, -90, 50]
# Write your code here
n = int(input())
new_list = []

for number in num_list:
    if number>n:
        new_list += [number]
        
print(new_list)

Input:

50

Output:

[93,71]

create & print list -2:
---------------------------

n = int(input())

list_a = []

for i in range(n):
    value = input()
    list_a += [value]
    
print(list_a)

Input:

5
20
Tiger
Cinema
5.5
93

Output:

['20', 'Tiger', 'Cinema', '5.5', '93']

Reverse order:
--------------------

n = int(input())
m = []

for i in range(n):
  s = input()
  m = [s] + m
  
new = m
mod = ""
for j in new:
  mod = j
  print(mod)
  
Input:

8
Anjali
Ravi
Akbar
Suresh
Gopal
Latha
Mohan
Ashok

Output:

Ashok
Mohan
Latha
Gopal
Suresh
Akbar
Ravi
Anjali

List concatenation-2:
--------------------------

n = int(input())
m = []

for i in range(n):
  s = input()
  m += [s]
  
new_list = m[:3] + m[n-3:]
print(new_list)

Input:

8
Anjali
Ravi
Akbar
Suresh
Gopal
Latha
Mohan
Ashok

Output:

['Anjali', 'Ravi', 'Akbar', 'Latha', 'Mohan', 'Ashok']

Assignment-19:
------------------

N = int(input())
L = []
for _ in range(N):
    L.append(int(input()))
print(L)

Input:

4
1
2
3
4

Output:

[1,2,3,4]

List indexing-3:
----------------------

n = int(input())
t = int(input())
numbers = [int(input()) for _ in range(n)]
for _ in range(t):
    print(numbers[int(input())])
    
Input:

4
2
1
2
3
4
0
3

Output:

1
4

First and last elements of a list:
-------------------------------------

n = int(input())
l = []

for i in range(n):
    x = int(input())
    l.append(x)
    
ans = [l[0], l[1], l[-2], l[-1]]
print(ans)

Input:

6
1
2
3
4
5
6

Output:

[1, 2, 5, 6]

Last half of list:
----------------------

n=int(input())
numbers=input().split()
Length=len(numbers)
for i in range(n):
    numbers[i]=int(numbers[i])
if n%2!=0:                         #should be outside for-loop
    half_list=numbers[(n+1)//2:]  #braces are missing for (n+1)
else:
    half_list=numbers[n//2:]
print(half_list)

Input:

6
1 2 3 4 5 6

Output:

[4, 5, 6]

-------------------------------------------------------------------------------------------

Splitting:
-------------

str_var.split(separator)

Splits a string into a list at every specified separator.
If no separator is specified, default separator is whitespace.

Code:

nums = "1 2 3 4"
num_list = nums.split()
print(num_list)

Output:

['1', '2', '3', '4']

Multiple WhiteSpaces:
-----------------------------

Multiple whitespaces are considered as single when splitting. 

Code:

nums = "1  2 3 4 "
num_list = nums.split()
print(num_list)

Output:

['1', '2', '3', '4']

New line \n and tab space \t are also whitespace.

Code:

nums = "1\n2\t3 4"
num_list = nums.split()
print(num_list)

Output:

['1', '2', '3', '4']

Using Separator:
--------------------

Breaks up a string at the specified separator.

Example -1

Code:

nums = "1,2,3,4"
num_list = nums.split(',')
print(num_list)

Output:

['1', '2', '3', '4']

Example -2:
--------------

Code:

nums = "1,2,,3,4,"
num_list = nums.split(',')
print(num_list)

Output:

['1', '2', '', '3', '4', '']

Space as Separator:
-----------------------

Code:

nums = "1  2 3 4 "
num_list = nums.split(" ")
print(num_list)

Output:

['1', '', '2', '3', '4', '']

String as Separator:
---------------------------

Example - 1

Code:

string_a = "Python is a programming language"
list_a = string_a.split('a')
print(list_a)

Output:


['Python is ', ' progr', 'mming l', 'ngu', 'ge']

Example-2:
-----------

string_a = "step-by-step execution of code"
list_a = string_a.split('step')
print(list_a)

Output:

['', '-by-', ' execution of code']

--------------------------------------------------------------------------------------------------

Joining:
-----------

str.join(sequence) 

Code:

list_a = ['Python is ', ' progr', 'mming l', 'ngu', 'ge']
string_a = "a".join(list_a)
print(string_a)

Output:

Python is a programming language

Joining Non String Values:
--------------------------------

Sequence should not contain any non-string values.

Code:

list_a = list(range(4))
string_a = ",".join(list_a)
print(string_a)

Output:

TypeError: sequence item 0: expected str instance, int found

---------------------------------------------------------------------------------------------------------

Negative Indexing:
---------------------

Reversing a List:
-----------------------

-1 for step will reverse the order of items in the list.

Code

list_a = [5, 4, 3, 2, 1]
list_b = list_a[::-1]
print(list_b)

Output:

[1, 2, 3, 4, 5]

Accessing List Items:
------------------------

Example-1

list_a = [5, 4, 3, 2, 1]
item = list_a[-1]
print(item)

Output:

1

Slicing With Negative Index:
-----------------------------------

You can also specify negative indices while slicing a List.  

Code:

list_a = [5, 4, 3, 2, 1]
list_b = list_a[-3:-1]
print(list_b)

Output:

[3,2]

Out of bound:
----------------------

Code:

list_a = [5, 4, 3, 2, 1]
list_b = list_a[-6:-2]
print(list_b)

Output:

[5,4,3]


Negative Step Size:
------------------------------

variable[start:end:negative_step]

Negative Step determines the decrement between each index for slicing.

Start index should be greater than the end index in this case

start > end

Negative Step Size Examples:
---------------------------------

Example - 1

Code:

list_a = [5, 4, 3, 2, 1]
list_b = list_a[4:2:-1]
print(list_b)

Output:

[1,2]

Example - 2

Negative step requires the start to be greater than end.

Code:

list_a = [5, 4, 3, 2, 1]
list_b = list_a[2:4:-1]
print(list_b)

Output:

[]

Reversing a String:
-------------------------

-1 for step will reverse the order of the characters.

Code:

string_1 = "Program"
string_2 = string_1[::-1]
print(string_2)

Output:

margorP

Code:

string_1 = "Program"
string_2 = string_1[6:0:-2]
print(string_2)

Output:

mro

----------------------------------------------------------------------------------------------

Coding pratice-20:
----------------------

Split the sentence:
--------------------------

n = input()
l = n.split()
for word in l:
    print(word)
    
Input:

Banana Apple Pomegranate Strawberry Grapes Orange

Output:

Banana
Apple
Pomegranate
Strawberry
Grapes
Orange

List Reverse:
----------------------

n = input()
L = n.split()

reverse_word_list = L[::-1]
print(reverse_word_list)

Input:

Banana Apple Pomegranate Strawberry Grapes Orange

Output:

['Orange', 'Grapes', 'Strawberry', 'Pomegranate', 'Apple', 'Banana']

Sum of list elements:
----------------------------

n = input()
num_list = n.split()

list_sum = 0
for number in num_list:
    list_sum = list_sum + int(number)
    
print(list_sum)

Input:

2 5 10 -15 3

Output:

5

Reverse the letters in word of sentence:
---------------------------------------------

user_str = input()
word_list = user_str.split()

modified_sentence = []

for word in word_list:
    modified_sentence += [word[::-1]]
print(modified_sentence)

reversed_letter_setence = " ".join(modified_sentence)
print(reversed_letter_setence)

Input:

The cat is on the mat.

Output:

['ehT', 'tac', 'si', 'no', 'eht', '.tam']
ehT tac si no eht .tam

Reverse Order-2:
---------------------

list_a = input().split(",")
list_b = input().split(",")


len_of_list_a = len(list_a)
n = len_of_list_a - 1

for i in range(len_of_list_a):
    num_1 = list_a[i]
    num_2 = list_b[n-i]
    result = str(num_1) + " " + str(num_2)
    print(result)

Input:

1,2,3
4,5,6

Output:

1 6
2 5
3 4

Assignment-20:
----------------------

Reverse the sentence:
-------------------------

## initializing the string
string = input()
## splitting the string on space
words = string.split()
## reversing the words using reversed() function
words = list(reversed(words))
## joining the words and printing
print(" ".join(words))

Input:

This is Python

Output:

Python is This

Product of list elements:
-----------------------------

n = input()
num_list = n.split()

list_pro = 1
for number in num_list:
    list_pro = list_pro * int(number)
    
print(list_pro)

Input:

1 2 3 4 5 6

Output:

720

Largest number in the list:
----------------------------------

numbers = [int(i) for i in input().split()]
max = numbers[0]
for i in numbers[1:]:
    if max < i:
        max = i
print(max)

Input:

1 0 3 2 9 8

Output:

9

Acronyms:
----------------

result=''
for w in input().split():
    result +=w[0] + '.'
result=result[:-1]
print(result)

Input:

Indian Administrative Service

Output:

I.A.S

Average of the given numbers:
-------------------------------------

def get_numbers():
    list = [int(x) for x in input().split(' ')]
    return list

def get_average(list):
    average = sum(list)/len(list)
    return average

def main():
    list = get_numbers()
    print(round(get_average(list), 2))

if __name__ == "__main__":
    main()
    
Input:

1 0 2 5 9 8

Output:

4.17

----------------------------------------------------------------------------------------

Functions:
--------------

Block of reusable code to perform a specific action.

Reusing Code:
-----------------

Using an existing code without writing it every time we need.

Code:

def greet():
    print("Hello")

name = input()
print(name)

Input:

Teja

Output:

Teja

Calling a Function:
---------------------------

The functional block of code is executed only when the function is called.

Code:

def greet():
    print("Hello")

name = input()
greet()
print(name)

Input:

Teja

Output:

Hello
Teja

Defining & Calling a Function:
----------------------------------

A function should be defined before it is called.

Code:

name = input()
greet()
print(name)

def greet():
    print("Hello")
    
Input:

Teja

Output:

NameError: name 'greet' is not defined.

Function With Arguments:
--------------------------------

We can pass values to a function using an Argument.

Code:

def greet(word):
    msg = "Hello " + word
    print(msg)

name = input()
greet(word=name)

Input:

Teja

Output:

Hello Teja

Variables Inside a Function:
-------------------------------------

A variable created inside a function can only be used in it.

Code:

def greet(word):
    msg = "Hello " + word

name = input()
greet(word=name)
print(msg)

Input:

Teja

Output:

NameError: name 'msg' is not defined.

Returning a Value:
--------------------------

To return a value from the function use return keyword.

Exits from the function when return statement is executed.

def greet(word):
    msg = "Hello " + word
    return msg

name = input()
greeting = greet(word=name)
print(greeting)

Input:

Teja

Output:

Hello Teja

Code written after return statement will not be executed.

Built-in Functions:
-----------------------------

We are already using functions which are pre-defined in Python.
Built-in functions are readily available for reuse

print()
int()
str()
len()

Mutable & Immutable:
----------------------------

Usually, the words objects and values are used interchangeably in the beginner context. But there are certain subtler differences which can be ignored for now.



Immutable Objects: These are of in-built types like int, float, bool, string. In simple words, an immutable object can’t be changed after it is created. For example,

a = "Hello"
a[0] = "I"﻿
The output for the above code will be an error. However the variables containing these immutable objects can be assigned a new objects.

a = "Hello"
a = "Cello" 


Mutable Objects : These are of type list, dict, set. These can be changed after they are created. For example,

color = ["red", "blue", "green"] 
color[0] = "pink"
print(color)


Output:

['pink', 'blue', 'green']

Keyword Arguments:
------------------------

Passing values by their names.

Code:

def greet(arg_1, arg_2):
  print(arg_1 + " " + arg_2)

greeting = input()
name = input()
greet(arg_1=greeting,arg_2=name)

Input:

Good Morning
Ram

Output:

Good Morning Ram

Possible Mistakes - Keyword Arguments:
-----------------------------------------

Code:

def greet(arg_1, arg_2):
    print(arg_1 + " " + arg_2)

greeting = input()
name = input()
greet(arg_2=name)

Input:

Good Morning
Ram

Output:

TypeError: greet() missing 1 required positional argument : 'arg_1'

Positional Arguments:
--------------------------------

Values can be passed without using argument names.

These values get assigned according to their position.
Order of the arguments matters here.

Code:

def greet(arg_1, arg_2):
    print(arg_1 + " " + arg_2)

greeting = input()
name = input()
greet(greeting,name)

Input:

Good Morning
Ram

Output:

Good Morning Ram

Possible Mistakes - Positional Arguments:
-----------------------------------------------

Mistake - 1

Code:

def greet(arg_1, arg_2):
 print(arg_1 + " " + arg_2)

greeting = input()
name = input()
greet(greeting)

Input:

Good Morning
Ram

Output:

TypeError: greet() missing 1 required positional argument : 'arg_2'

Mistake - 2

Code:

def greet(arg_1, arg_2):
 print(arg_1 + " " + arg_2)

greeting = input()
name = input()
greet()

Input:

Good Morning
Ram

Output:

TypeError: greet() missing 2 required positional arguments.

Default Values:
--------------------------

Example - 1

Code:

def greet(arg_1="Hi", arg_2="Ram"):
    print(arg_1 + " " + arg_2)

greeting = input()
name = input()
greet()

Input:

Hello
Teja

Output:

Hi Ram

Passing Immutable Objects:
-----------------------------------

Even though variable names are same, they are referring to two different objects.
Changing the value of the variable inside the function will not affect the variable outside.

Code:

def increment(a):
    a += 1
    
a = int(input())
increment(a)
print(a)

Input:

5

Output:

5

------------------------------------------------------------------------------------------------------

Coding pratice-21:
-------------------------

Return the given argument:
---------------------------------

def func(arg_1):
    # Write your code here
    return arg_1


n = int(input())
result = func(n)
print(result)

Input:

20

Output:

20

Welcome message:
-------------------------

def say_wishes(arg_1):
    # Write your code here
    wishes = "Welcome " + arg_1
    print(wishes)

name = input()
say_wishes(name)

Input:

Preethi

Output:

Welcome Preethi

Multiply with three:
-------------------------

def multiply_with_three(arg_1):
    # Write your code here
    result = arg_1 * 3
    print(result)

n = int(input())
multiply_with_three(n)

Input:

2

Output:

6

Divisible by 7:
-------------------------

def divisible_by_seven(arg_1):
    # Write your code here
    if (n%7 == 0):
        print("True")
    else:
        print("False")


n = int(input())
divisible_by_seven(n)

Input:

14

Output:

True

Perimeter of Square:
----------------------------

def perimeter_of_square(arg_1):
    # Write your code here
    perimeter = arg_1 * 4
    return perimeter

side = int(input())
result = perimeter_of_square(side)
print(result)


Input:

3

Output:

12

Add two numbers:
----------------------

def add(arg_1, arg_2):
    # Complete this function
    r = arg_1+arg_2
    return r


a = int(input())
b = int(input())
# Call the add function
r = add(a,b)
print(r)

Input:

5
8

Output:

13

Second character of the word:
---------------------------------------

def second_character(arg_1):
    # Complete this function
    character = arg_1[1]
    return character

word = input()
# Call the second_character function
r = second_character(word)
print(r)


Input:

MATHS

Output:

A

Indexing-2:
---------------------

def indexing(arg_1, arg_2):
    # Complete this function
    character = arg_1[index]
    return character
    
word = input()
index = int(input())
# Call the indexing function
r = indexing(word,index)
print(r)

Input:

Chocolate
2

Output:

o

Printing message:
-----------------------
def message(arg_1, arg_2):
    # Complete this function
    print(arg_1 + " is " + str(arg_2) + " years old." )

name = input()
age = int(input())
# Call the message function
message(name,age)

Input:

Akhil
15

Output:

Akhil is 15 years old.

Number of upper and lowercase letters:
-----------------------------------------------

def count_of_lowercase_and_uppercase_letters(arg_1):
    # Complete this function
    count_of_lowercase = 0
    count_of_uppercase = 0

    for character in arg_1:
        if character.upper() == character:
            count_of_uppercase += 1
      
        else:
            count_of_lowercase += 1
    

    print(count_of_uppercase)
    print(count_of_lowercase)


word = input()
# Call the count_of_lowercase_and_uppercase_letters function
count_of_lowercase_and_uppercase_letters(word)

Input:

MasTer

Output:

2
4

List of squares:
-----------------------

def get_list(string_a):
    list_a = string_a.split(',')
    len_list_a = len(list_a) 
    for i in range(len_list_a):
        list_a[i] = int(list_a[i]) ** 2
    return list_a


string_a = input()
numbers_list = get_list(string_a)
print(numbers_list)

Input:

1,2,3,4

Output:

[1, 4, 9, 16]

Coding pratice-22:
---------------------------

Team points:
----------------

def calculate_league_points(wins, draws, losses):
    # Complete this function
    win_points = wins * 4
    draw_points = draws * 2
    loss_points = losses * -1
    total_points = win_points + draw_points +loss_points
    return total_points


statistics = input().split(",")
wins = int(statistics[0])
draws = int(statistics[1])
losses = int(statistics[2])
# Call the calculate_league_points function
total_points = calculate_league_points(wins,draws,losses)
print(total_points)

Input:

4,1,2

Output:

16

speed meter:
-----------------

def get_speed_status(speed):
    # Complete this function
    if speed < 60:
        print("Normal")
    elif (speed >= 60) and (speed < 80):
        print("Warning")
    else:
        print("Over Speed")


speed = int(input())
# Call the get_speed_status function
r = get_speed_status(speed)

Input:

75

Output:

Warning

Weather Report:
------------------

def get_weather_report(temperature):
    # Complete this function
    if temperature < 22:
        report ="Cold"
    elif (temperature >= 22) and (temperature < 35):
        report = "Warm"
    else:
        report = "Hot"
    return report


temperature = int(input())
# Call the get_weather_report function
r = get_weather_report(temperature)
print(r)


Calculate bill:
---------------------

def calculate_bill(amount):
    # Complete this function
      if amount < 500:
          bill = amount - (amount * 0.05)
      elif (amount>= 500) and (amount < 2500):
          bill = amount - (amount * 0.1)
      else:
          bill = amount - (amount * 0.2)
      bill = round(bill,3)
     
      return bill


amount = int(input())
# Call the calculate_bill function
result = calculate_bill(amount)
print(result)

Input:

1500

Output:

1350.0

Fizz Buzz:
------------------

def fizz_buzz(number):
    # Complete this function
    if ((number%3==0) and (number%5==0)):
        result="FizzBuzz"
    elif (number%5==0): 
	    result="Buzz"            
    elif (number%3==0): 
        result="Fizz"
    else: 
        result=number
    return result


number = int(input())
# Call the fizz_buzz function
r = fizz_buzz(number)
print(r)

coding pratice-23:
-----------------------------

Sum of squares from M to N:
----------------------------------

def sum_of_squares_m_to_n(m, n):
    # Complete this function
    sum =0
    for i in range(m,n+1):
        sum += (i ** 2)
    return sum


m = int(input())
n = int(input())
# Call the sum_of_squares_m_to_n function
r = sum_of_squares_m_to_n(m,n)
print(r)

Input:

3
5

Output:

50

Sum of cubes from M to N:
-------------------------------

def sum_of_cubes_m_to_n(m, n):
    # Complete this function
    sum =0
    for i in range(m,n+1):
        sum += (i ** 3)
    return sum


m = int(input())
n = int(input())
# Call the sum_of_cubes_m_to_n function
r = sum_of_cubes_m_to_n(m,n)
print(r)

Input:

3
5

Output:

216

Labelling numbers:
--------------------------

def show_numbers(number):
    # Complete this Function
    for i in range(number+1):
        if(i%2 == 0):
            print(str(i) + " EVEN")
        else:
            print(str(i) + " ODD")


number = int(input())
# Call the show_numbers function
show_numbers(number)

Input:

3

Output:

0 EVEN
1 ODD
2 EVEN
3 ODD

Uppercase and Lowercase letters:
-----------------------------------------

def get_lower_and_upper_case_letters(word):
    # Complete this function
    uppercase_letters = ""
    lowercase_letters = ""
    for letter in word:
        if letter.upper() == letter:
            uppercase_letters += letter
        else:
            lowercase_letters += letter
    print(uppercase_letters)
    print(lowercase_letters)


word = input()
# Call the get_lower_and_upper_case_letters function
get_lower_and_upper_case_letters(word)

Input:

PreMium

Output:

PM
reium

Count the vowels:
-----------------------------

def count_the_vowels(word):
    # Complete this function
    count=0
    for char in word:
        if char =='a' or char=='e' or char=='i' or char=='o' or char=='u':
            count=(count)+1
    return count
  
word = input()
# Call the count_the_vowels function
count=count_the_vowels(word)
print(count)

Input:

Suggestions

Output:

4

Four Passangers and a driver:
---------------------------------------

def number_of_cars_needed(no_of_people):
    # Complete this function
    number_of_cars = no_of_people // 5
    remaining_people = no_of_people % 5

    if remaining_people > 0:
        number_of_cars += 1
        
    return number_of_cars
            
no_of_people = int(input())
# Call the number_of_cars_needed function
r = number_of_cars_needed(no_of_people)
print(r)

Input:

11

Output:

3

ATM Pin validation:
------------------------

def validate_atm_pin_code(pin):
    # Complete this function
    is_valid=True
    is_having_four_or_six_char=(len(pin)==4) or (len(pin)==6)
    
    if is_having_four_or_six_char:
        is_all_digits=pin.isdigit()
        if not is_all_digits:
            is_valid=False
    else:
        is_valid=False
    if is_valid:
        print("Valid PIN Code")
    else:
        print("Invalid PIN Code")


pin = input()
# Call the validate_atm_pin_code function
validate_atm_pin_code(pin)


Input:              Input:

9837                473k3h

Output:             Output:

Valid PIN Code      Invalid PIN Code    

Foundation Exam-2:
----------------

Sum of Prime Numbers In the Input
Given a list of integers, write a program to print the sum of all prime numbers in the list of integers.
Note: One is neither prime nor composite number.

https://www.assignmentexpert.com/homework-answers/programming-and-computer-science/python/question-179153

Shift Numbers:
----------------------------

https://www.assignmentexpert.com/homework-answers/programming-and-computer-science/python/question-176604

# get the string from the user
inputString =input("");
digits=""
letters=""
symbols=""
# Looping through a string.
for letter in inputString:
    if (letter.isdigit()):
        digits+=letter
    elif (letter.isalpha()):
        letters+= letter
    else:
        symbols+= letter
# Display a new string.
print(letters+digits+symbols)

Input:

1good23morning456,

Output:

goodmorning123456,

Index of Last Occurence:
-----------------------------

a = [int(i) for i in input("Enter list of numbers: ").split()]
b = int(input("Search number: "))
index = 0
for i in range(len(a)):
    if a[i] == b:
        index = i
print("Index of Last Occurrence: ", index)

Sample Input 1

2 4 5 6 7 8 2 4 5 2 3 8

2

Sample Output 1

9

Sample Input 2

65 87 96 31 32 86 57 69 20 42 32 32

32

Sample Output 2

11

Mean,medin,Mode :
-----------------------

https://www.assignmentexpert.com/homework-answers/programming-and-computer-science/python/question-179548

Sum of prime numbers from m to n:
----------------------------------------

m, n = int(input()), int(input())  # numbers m and n
sum = 0  # sup of primes
for i in range(m, n + 1):
    flag = False
    for j in range(2, i):
        if i % j == 0:
            flag = True  # composite number
    if flag == False and i != 1:  # if isn't composite number
        sum += i
print(sum)

Sample Input 1

5
11

Sample Output 1

23

Sample Input 2

18
40

Sample Output 2

139

------------------------------------------------------------------------------------------------------------------

Passing Mutable Objects:
-------------------------------

def add_item(list_x):
    list_x += [3]

list_a = [1,2]
add_item(list_a)
print(list_a)

Output:

[1,2,3]

Code:
---------

def add_item(list_x):
    list_x = list_x + [3]

list_a = [1,2]
add_item(list_a)
print(list_a)

Output:

[1, 2]

Code:
-----------

def add_item(list_x=[]):
    list_x += [3]
    print(list_x)

add_item()
add_item([1,2])
add_item()

Output:

[3]
[1, 2, 3]
[3, 3]

Coding pratice-24:
--------------------------

str_1 = input()
d_l = []

for char in str_1:
    if char.isdigit():
        d_l += [int(char)]
        
s = sum(d_l)
print(s)
m = min(d_l)
print(m)
ma = max(d_l)
print(ma)

Input:

C0d1n8

Output:

9
0
8

sort and sequare the list it:
----------------------------------

list_a = input().split(",")
list_x = []

for num in list_a:
    list_x += [int(num)**2]
    
list_x = sorted(list_x)
print(list_x)

Input:

2,4,1,3,5

Output:

[1, 4, 9, 16, 25]

difference between max and min:
----------------------------------------

s = input().split(",")
n = []
length = len(s)

for i in range(length):
    s[i] = int(s[i])
    
print(s[i])

ma = max(s)
m = min(s)

difference = ma - m
print(difference)

Input:

2,3,-1,5

Output:

5
6

Largest number in the list:
----------------------------------

n = input().split(",")

length = len(n)

for i in range(length):
    n[i] = int(n[i])
    
n = sorted(n)
largest_number = n[-1]
print(largest_number)

Input:

2,3,-1,5

Output:

5

smallest number in the list:
------------------------------

n = input().split(",")

length = len(n)

for i in range(length):
    n[i] = int(n[i])
    
n = sorted(n)
largest_number = n[0]
print(largest_number)

Input:

2,3,-1,5

Output:

-1

kth smallest number:
----------------------------------

l1 = input().split(",")
b = int(input())
l2 = []

for i in l1:
    temp = int(i)
    l2.append(temp)

l2 = sorted(l2)
kth_smallest_number = l2[b-1]
print(kth_smallest_number)
    

Input:

2,3,-1,5
2

Output:

2

kth largest number:
------------------------------

l1 = input().split(",")
b = int(input())
l2 = []

for i in l1:
    temp = int(i)
    l2.append(temp)

l2 = sorted(l2)
kth_largest_number = l2[-b]
print(kth_largest_number)
    
-----------------------------------------------------------------------------------------------------

Function Call Stack & Recursion:
-----------------------------------------

Stack:
---------

Stack is a data structure that stores items in an Last-In/First-Out manner.  

Code:

def get_largest_sqr(list_x):  
    len_list = len(list_x)  
    for i in range(len_list):  
        x = list_x[i]
        list_x[i] = x * x
    largest = max(list_x)  
    return largest  

list_a = [1,-3,2]  
result = get_largest_sqr(list_a)  
print(result)

Output:

9

In the above code calling functions are len() and max() inside get_largest_sqr()

Code:

def get_sqrd_val(x): 
    return (x * x) 
  
def get_sum_of_sqrs(list_a): 
    sqrs_sum = 0
    for i in list_a: 
        sqrs_sum += get_sqrd_val(i) 
    return sqrs_sum

list_a = [1, 2, 3] 
sum_of_sqrs = get_sum_of_sqrs(list_a) 
print(sum_of_sqrs)

Output:

14

Recursion:
-----------------

A function calling itself is called a Recursion

Multiply N numbers:
-----------------------

def factorial(n):  # Recursive Function
   if n == 1:  # Base Case
       return 1
   return n * factorial(n - 1)  # Recursion
num = int(input())
result = factorial(num)
print(result)

Note:

Base Case

A recursive function terminates when base condition is met

Input:

3

Output:

6

Without Base case:
-------------------------

Code:

def factorial(n):
    return n * factorial(n - 1)
num = int(input())
result = factorial(num)
print(result)

Input:

3

Output:

Recursion error

MCQ doubt:
-----------------

def function_1(a, b):
    a = a + b    # a changes to a+b i.e. 4+5 = 9
    result = function_2(a, b) # a=9,b=5
    print(result) # "5 4" is printed


def function_2(a, b):
    b = a - b   # b changes to a-b i.e. 9-5 = 4 
    a = a - b   # a changes to a-b i.e. 9-4 = 5
    result = str(a) + " " + str(b)   # result is str(5) + " " + str(4) = "5 4"
    return result


function_1(4, 5)  

Output:

5 4

Coding pratice-25:
------------------------

sum of first n natural numbers:
-------------------------------------

def sum_of_numbers(n):
    if n == 1:  # Base case
        return 1
    else:
        return n + sum_of_numbers(n-1)  # Recursion


num = int(input())
result = sum_of_numbers(num)
print(result)

Input:

4

Output:

10

Factorial:
-----------------

def compute_factorial(n):
    # Complete this recursive function
    if n <= 0:  # Base case 
        return 1
    else:
        return n* compute_factorial(n-1) #Recursive function
        
    


num = int(input())
# Call the compute_factorial function
r = compute_factorial(num)
print(r)

Input:

4

Output:

24

Sum of the digits:
----------------------------

def sum_of_the_digits(number):
    # Complete this recursive function
    if number < 10:
        return number
    else:
        return (number % 10) + sum_of_the_digits(number//10)


number = int(input())
# Call the sum_of_the_digits function
r = sum_of_the_digits(number)
print(r)

Explaination:

-> (158 % 10) + sum_of_the_digits(158//10)
-> 8 + sum_of_the_digits(15)
-> 8 + (15%10 + sum_of_the_digits(15//10))
-> 8 + (5 + sum_of_the_digits(1))
-> 8 + 5 + 1
-> 14

Input:

158

Output:

14

A Power B:
---------------

def calculate_power(x, y):
    # Complete this recursive function
    if y == 1:  # Base case
        return x
    else:
        y -= 1
        return x * calculate_power(x, y)  # Recursion


a = int(input())
b = int(input())
# Call the calculate_power function
result = calculate_power(a, b)
print(result)

Input:

2
3

Output:

8

-------------------------------------------------------------------------------------------------------------------

List Methods:
-----------------------

Python provides list methods that allow us to work with lists.

Let’s learn few among them

append()
extend()
insert()
pop()
clear()
remove()
sort()
index()

Append:
------------

list.append(value) Adds an element to the end of the list.

Extend:
---------------

list_a.extend(list_b)  Adds all the elements of a sequence to the end of the list.

Insert:
----------

list.insert(index,value) Element is inserted to the list at specified index.

Pop:
---------

list.pop() Removes last element.

Remove:
--------------

list.remove(value) Removes the first matching element from the list.

Clear:
-----------

list.clear() Removes all the items from the list.

Index:
-------------

list.index(value) Returns the index at the first occurrence of the specified value.

Count:
--------------

list.count(value)  Returns the number of elements with the specified value.

Coding pratice-26:
-------------------------

Remove the last items:
---------------------------------

programming_languages = ['Python', 'C', 'Java', 'Ruby', 'C++', 'CSS', 'HTML', 'Bash', 'Perl', 'R', 'Swift', 'SQL', 'PHP', 'JavaScript']
# Write your code here
n = int(input())
for i in range(n):
    programming_languages.pop()
print(programming_languages)

Input:

3

Output:

['Python', 'C', 'Java', 'Ruby', 'C++', 'CSS', 'HTML', 'Bash', 'Perl', 'R', 'Swift']

Remove all the occurrences:
--------------------------------

nums_list = [5, 10, 20, 35, 5, 50, 20, 100, 200, 10, 150, 100, 100]
# Write your code here
n = int(input())

count = nums_list.count(n)

for i in range(count):
    nums_list.remove(n)

print(nums_list)

Input:

5

Output:

[10, 20, 35, 50, 20, 100, 200, 10, 150, 100, 100]

Nth term in fibbonaci series:
-------------------------------------

def fibonacci(n):
    # Complete this function
    if n <= 1:
        return n 
    return fibonacci(n-1) + fibonacci(n-2)

n = int(input())
# call the fibonacci function
r = fibonacci(n)
print(r)

Input:

9

Output:

34

N terms in fibbonaci series:
------------------------------------

def fibonacci(n):
    # Complete this function to return nth term in fibonacci series
     if n <= 1:
        return n 
     else:
         return fibonacci(n-1) + fibonacci(n-2)
        
         

def get_fibonacci_series(n):
    # Complete this function to return list of n terms of fibonacci series
    fibonacci_series = []
    for i in range(n):
        term = fibonacci(i)
        fibonacci_series.append(term)
    return fibonacci_series

n = int(input())
# Call the get_fibonacci_series function
r = get_fibonacci_series(n)
print(r)

Input:

5

Output:

[0, 1, 1, 2, 3]

List Methods:
----------------------

n = int(input())
nums_list = []

for i in range(n):
  command = input().split()
  
  if command[0] == 'insert':
    index = int(command[1])
    value = int(command[2])
    nums_list.insert(index, value)

  elif command[0] == 'append':
    value = int(command[1])
    nums_list.append(value)
    
  elif command[0] == 'pop':
    nums_list.pop()

  elif command[0] == "remove":
    value = int(command[1])
    nums_list.remove(value)

  elif command[0] == "sort":
    nums_list.sort()

  elif command[0] == "print":
    print(nums_list)

Input:
----------

5
append 5
insert 0 2
append 1
sort
prints

Output:

[1, 2, 5]

coding pratice-27:
---------------------------

Replace the element:
-----------------------

num_list = [(10, 20, 30), (1, 2), (5, 10, 15, 45)]

n = int(input())

new_list = []
for tuple_a in num_list:
    update_tuple = tuple_a[:-1] + (n,)
    new_list.append(update_tuple)

print(new_list)

Input:

50

Output:

[(10, 20, 50), (1, 50), (5, 10, 15, 50)]

1)We cannot update elements of tuple directly. Because it is not mutable.

2)So we create a new tuple update_tuple and we are considering all element except last and then we are adding last element as 'n' using (n,)

3)To help you understand better below are couple of examples. Please try them in Play Ground to understand better.

print((1,2) + (3,))
print((5,6,7) + (8,9,))

Output:
(1, 2, 3)
(5, 6, 7, 8, 9)

Alternative:
--------------------

lst = [(10, 12, 43), (54, 0, 77), (3, 24, 81, 99), (19, 36)]
n = int(input())
lst = [el[0:-1] + (n,) for el in lst]
print(lst)

Remove duplicates:
------------------------

num_list = input() . split()

new_list = []

for item in num_list:
    num = int(item)
    new_list.append(num)
    
num_set = set(new_list)
num_list = list(num_set)
num_list.sort()
print(num_list)

Input:

5 10 15 20 10 30 15

Output:

[5, 10, 15, 20, 30]


Remove multiple items:
-----------------------------

num_set = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100}
# Write your code here
num_list = input() . split()

for item in num_list:
    num = int(item)
    num_set.discard(num)
    
nums_list = list(num_set)
nums_list.sort()
print(nums_list)

Input:

20 40 80

Output:

[10, 30, 50, 60, 70, 90, 100]

Common Elements:
-------------------

Understanding the problem:

Here we need to print the common elements from the given two strings. For example, if the two strings are 1,2,3,4,5,6 and 2,4,5,9,10,. 
In the given two strings the common elements are 2, 4, and 5. So the output should be [2, 4, 5]. 
Another thing here is we need to print the output in ascending order.

How to solve:

Read the inputs and split them into lists by using the split() method.
Convert the list elements from string to integer format.
Find the common elements in both lists by using the set intersection() method.
Sort the resultant list and print the list.


Explanation:

Reading the inputs and splitting them into lists by using the split() method in lines 9 and 10. 
Now converting the list of elements from string to integer format by calling the function convert_string_to_int(). 
The convert_string_to_int() function returns the list which contains integer elements in it. 
Here we are converting these lists into sets to eliminate the duplicate elements in each list in lines 15 and 16. 
Finding the common elements from both the lists by using the set intersection() method in line 18. 
Next, the set is converting into a list. Finally sorting the list and printing it.

Code:

def convert_string_to_int(num_list):
    new_list = []
    for item in num_list:
        num = int(item)
        new_list.append(num)
    return new_list


list_a = input().split(",") # reading first line of input and splitting into list
list_b = input().split(",") # reading second line of input and splitting into list

list_a = convert_string_to_int(list_a)
list_b = convert_string_to_int(list_b)

set_a = set(list_a)
set_b = set(list_b)

result_set = set_a.intersection(set_b)
result_list = list(result_set)
result_list.sort()
print(result_list)

Multiples of 2 and 3:
----------------------------

n = int(input())

multiples_of_2 = set()
multiples_of_3 = set()

for i in range(1,n+1):
    multiples_of_2.add(2*i)
    multiples_of_3.add(3*i)
print(multiples_of_2)
print(multiples_of_3)

diff = multiples_of_2.difference(multiples_of_3)
symmetric_diff = multiples_of_2.symmetric_difference(multiples_of_3)

diff = list(diff)
symmetric_diff=list(symmetric_diff)

diff.sort()
symmetric_diff.sort()

print(diff)
print(symmetric_diff)

Input:

5

Output:

{2, 4, 6, 8, 10}
{3, 6, 9, 12, 15}
[2, 4, 8, 10]
[2, 3, 4, 8, 9, 10, 12, 15]

Coding pratice-28:
-----------------------

Rotate D times:
-------------------

def convert_string_to_int(num_list):
    new_list = []
    for item in num_list:
        num = int(item)
        new_list.append(num)
    return new_list
    
str_num_list = input().split(",")
rotate_times = int(input())

int_list = convert_string_to_int(str_num_list)
len_of_list = len(int_list)
val = rotate_times % len_of_list

f_p = int_list[0:val]
s_p = int_list[val:]
s_p.extend(f_p)
print(s_p)

Input:

1,2,3,4,5
2

Output:

[3, 4, 5, 1, 2]

Same elements:
--------------------

def convert_string_to_int(num_list):
    new_list = []
    for item in num_list:
        num = int(item)
        new_list.append(num)
    return new_list

num_list = input().split(" ")
num_list = convert_string_to_int(num_list)

num_set = set(num_list)     # converting the list to set
if len(num_set) == 1:       # checking if the length of set is 1
  print("True")
else:                       # else we need to print the unique values in the sorted order
  num_list = list(num_set)  # converting it to list (as sets do not have sort method) 
  num_list.sort()           # sorting the list
  print(num_list)   
  
Input:

45 45 45

Output:

True

Exact Numbers:
--------------------

a = input().split(",")

num_list = []
for item in a:
    is_digit = item.isdigit()
    if is_digit:
        number = int(item)
        num_list.append(number)
        
print(num_list)

Input:

1,2,3,#,4

Output:

[1,2,3,4]

Missing Numbers:
------------------------

def convert_string_to_int(num_list):
    new_list = []
    for item in num_list:
        num = int(item)
        new_list.append(num)
    return new_list

num_list = input().split(" ")
num_list = convert_string_to_int(num_list)
maximum = max(num_list)
num_set = set(num_list)

first_n_num_set = set(range(1, maximum+1)) # set(range(1, 8))
missing_num_set = first_n_num_set.difference(num_set)     # {1, 2, 3, 4, 5, 6, 7}.difference({1, 2, 3 5, 6, 7}) => {4}
missing_num_list = list(missing_num_set) # converting into list 
missing_num_list.sort()
print(missing_num_list)

Input:

1 2 3 5 6 7

Output:

[4]

Set Relation:
-------------------

def convert_string_to_int(num_list):
    new_list = []
    for item in num_list:
        num = int(item)
        new_list.append(num)
    return new_list


num_set = {1, 2, 3, 4, 5, 6, 7, 8, 9}
# Write your code here
num_list = input().split(" ")
num_list = convert_string_to_int(num_list)
set_a = set(num_list)

if num_set.issubset(set_a):
    print("Subset")
elif num_set.issuperset(set_a):
    print("Superset")
elif num_set.isdisjoint(set_a):
    print("Disjoint Set")

Input:

2 3 4

Output:

Superset

common elements in three sets:
-----------------------------------

def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list
    
num_list = []
for i in range(3):
    values_list = input().split()
    values_list = convert_string_to_int(values_list)
    values_set = set(values_list)
    num_list.append(values_set)
    print(num_list)
    
intersection_a = num_list[0].intersection(num_list[1])
intersection_b = intersection_a.intersection(num_list[2])

r = list(intersection_b)
r.sort()
print(r)

Input:

2 4 6 8 10
4 8 10 12 16
5 10 15 20

Output:

[{2, 4, 6, 8, 10}]
[{2, 4, 6, 8, 10}, {4, 8, 10, 12, 16}]
[{2, 4, 6, 8, 10}, {4, 8, 10, 12, 16}, {10, 20, 5, 15}]
[10]

common elements in n sets:
-------------------------------------

def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list
    
def get_intersection_of_n_sets(num_set_list):
    result = num_set_list[0]
    for num_set in num_set_list:
        result = result.intersection(num_set)
    return result
    
n = int(input())    
num_set_list = []
for i in range(n):
    values_list = input().split()
    values_list = convert_string_to_int(values_list)
    values_set = set(values_list)
    num_set_list.append(values_set)
    
    

result_set = get_intersection_of_n_sets(num_set_list)
r = list(result_set)
r.sort()
print(r)

Input:

3
2 4 6 8 10
4 8 10 12 16
5 10 15 20

Output:

[10]

K sum pairs:
----------------

def get_unique_pairs(int_list,pair_sum):
    stop_index = len(int_list) - 1 
    unique_pairs_set = set()
    for cur_index in range(stop_index):
        num_1 = int_list[cur_index]
        num_2 = pair_sum - num_1
        remaining_list = int_list[cur_index+1:]
        if num_2 in remaining_list:
            pair = (num_1,num_2)
            #avoid duplicates like (5,7) and (7,5)
            sorted_pair = tuple(sorted(pair))
            unique_pairs_set.add(sorted_pair)
    return unique_pairs_set
    
def convert_string_to_int(str_num_list):
    new_list = []
    for item in str_num_list:
        num = int(item)
        new_list.append(num)
    return new_list
    
str_num_list = input().split(",")
pair_sum = int(input())
int_list = convert_string_to_int(str_num_list)
unique_pairs = get_unique_pairs(int_list, pair_sum)
unique_pairs = list(unique_pairs)
unique_pairs.sort()

for pair in unique_pairs:
    print(pair)
    
Input:

5,3,7,9,5
12

Output:

(3, 9)
(5, 7)

N greatest numbers:
---------------------------

list_a = [5, 20, 3, 7, 6, 8]
n = int(input())
list_a = sorted(list_a)

list_len = len(list_a)
res = list_a[list_len - n:]

for i in range(n):
    res[i] = str(res[i])
    
print(" ".join(res))

Input:

2

Output:

8 20

Coding pratice-29:
--------------------------

Nested List:
------------------

def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list

    
n = int(input())    
num_set_list = []
for i in range(n):
    values_list = input().split()
    values_list = convert_string_to_int(values_list)
    values_set = list(values_list)
    num_set_list.append(values_set)
print(num_set_list)

Input:

3
1 2 3 4
10 20 30
5 10 15 20

Output:

[[1, 2, 3, 4], [10, 20, 30], [5, 10, 15, 20]]

List of maximum values:
---------------------------------

def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list

    
n = int(input())    
max_list = []

for i in range(n):
    list_a = input().split()
    list_a = convert_string_to_int(list_a)
    max_num = max(list_a)
    max_list.append(max_num)
    
print(max_list)
    
Input:

3
1 2 3 4
10 20 30
5 10 15 20

Output:

[4, 30, 20]

List of lists to list of tuples:
---------------------------------------

def convert_nested_list_to_list_of_tuples(nested_list):
    # Complete this function
    new_tuple = []
    for each_list in nested_list:
        tuple_a = tuple(each_list)
        new_tuple.append(tuple_a)
    return new_tuple


def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list


n = int(input())
num_list = []

for i in range(n):
    list_a = input().split()
    list_a = convert_string_to_int(list_a)
    num_list.append(list_a)


tuples_list = convert_nested_list_to_list_of_tuples(num_list)
print(tuples_list)

Input:

3
1 2 3 4
10 20 30
5 10 15 20

Output:

[(1, 2, 3, 4), (10, 20, 30), (5, 10, 15, 20)]

Nested list indexing:
----------------------------

num_list = [(2, 4, 6, 8), (5, 15, 25, 35), (7, 14, 21)]
# Write your code here
n = int(input())

for tuple_a in num_list:
    is_contain = n in tuple_a
    if is_contain:
        tuple_index = num_list.index(tuple_a)
        n_index = tuple_a.index(n)
        print(str(tuple_index) + " " + str(n_index))
        break
        
Input:

4

Output:

0 1

Accessing nested lists:
------------------------------

list_a = [('apple', 'banana', 'orange', 'grapes'), ('cricket', 'football', 'hockey'), ('car', 'bicycle', 'bus')]
# Write your code here
n = int(input())
new_list = []

for i in range(n):
    index = input().split()
    print(index)
    tuple_index = int(index[0])
    value_index = int(index[1])
    value = list_a[tuple_index][value_index]
    new_list.append(value)
    
print(new_list)

Input:

3
1 2
0 3
0 1

Output:

['hockey', 'grapes', 'banana']

Remove N in all tuples:
------------------------------

num_list = [(1, 2, 3, 4, 5, 6), (2, 4, 6, 8), (1, 3, 5, 7)]
# Write your code here
n = int(input())
new_list = []
for tuple_a in num_list:
    new_tuple = tuple_a
    print(new_tuple)
    is_contain = n in tuple_a
    if is_contain:
        n_index = tuple_a.index(n)
        print(n_index)
        new_tuple1 = tuple_a[:n_index]+ tuple_a[n_index+1:]
        print(new_tuple1)
    new_list.append(new_tuple)
    
print(new_list)

Input:

3

Output:

(1, 2, 3, 4, 5, 6)
2
(1, 2, 4, 5, 6)
(2, 4, 6, 8)
(1, 3, 5, 7)
1
(1, 5, 7)
[(1, 2, 3, 4, 5, 6), (2, 4, 6, 8), (1, 3, 5, 7)]

Max and min value in list of tuplets:
---------------------------------------------

Understanding the problem:

Here, We need to print the maximum and minimum of all the values at index zero and index one in the given list of tuples.

How to approach:

Separate the list into two different lists, one list contains the values at index 0 and another list contains the values at index 1. 
Calculate the Maximum and Minimum values. 

Code:

n = int(input())  
zero_index_list = []
first_index_list = []


for i in range(n):
   values_list = input().split()
   first_value = int(values_list[0])
   zero_index_list.append(first_value)
   second_value = int(values_list[1])
   first_index_list.append(second_value)

zero_index_min_max_tuple = (max(zero_index_list), min(zero_index_list))
first_index_min_max_tuple = (max(first_index_list), min(first_index_list))
print(zero_index_min_max_tuple)
print(first_index_min_max_tuple)

Input:

3
1 5
3 2
5 8

Output:

(5, 1)
(8, 2)

character frequency:
--------------------------

def print_char_count(line):
    line = line.lower()
    unique_chars = set(line)
    unique_chars.discard(" ")
    for char in sorted(unique_chars):
        print("{}: {}".format(char,line.count(char)))
        
line = input()
print_char_count(line)

Input:

pop up

Output:

o: 1
p: 3
u: 1

List of unique tuples:
-------------------------------

def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list
    
n = int(input())
num_list = []
for i in range(n):
    values_list = input().split()
    values_list = convert_string_to_int(values_list)
    values_set = set(values_list)
    is_equal = len(values_list) == len(values_set)
    if is_equal:
         num_list.append(values_list)
   
   
print(num_list)

Input:

4
1 2 3 3 4
2 3 4 5
10 20 30
3 6 9 12 3

Output:

[[2, 3, 4, 5], [10, 20, 30]]

Coding pratice-30:
------------------------

max,min and sum of matrix:
-----------------------------

def get_sum_of_matrix(nested_list):
  total = 0
  for each_list in nested_list:
    total += sum(each_list)
  return total
  
def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list


m, n = input().split()
m, n = int(m), int(n)
num_list = []

for i in range(m):
    list_a = input().split()
    list_a = convert_string_to_int(list_a)
    num_list.append(list_a)
    print(num_list)

# Write your code here

print(max(max(num_list)))
print(min(min(num_list)))
total = get_sum_of_matrix(num_list)
print(total)

Input:

3 3
1 2 3
10 20 30
5 10 15

Output:

[[1, 2, 3]]
[[1, 2, 3], [10, 20, 30]]
[[1, 2, 3], [10, 20, 30], [5, 10, 15]]
30
1
96

List comprehension:
-----------------------------

example:
list1 = [1,2,3]
list2 = ['a','b','c']
list3 = []
#if i want print all the combination of list1 and list2

#using for loops:
for i in list1:
  for j in list2:
    list3.append((i,j))

print(list3)


using list comprehension
list3 = [(i,j) for i in list1 for j in list2]
print(list3)

Lower triangle:
------------------------

def print_lower_triangle(matrix):
    # Complete this function
    for i in range(len(matrix)):
        row_list = matrix[i][:i+1]
        print(row_list)
        
For 1st iteration:
i =0 ,
row = matrix[0][:0+1] => matrix[0][:1]
so it prints the numbers at the index matrix[0][0]

For 2nd iteration:
i =1 ,
row = matrix[1][:1+1] => matrix[1][:2]
so it prints the numbers at the index matrix[1][0], matrix[1][1].
        

def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list


m, n = input().split()
m, n = int(m), int(n)
num_list = []

for i in range(m):
    list_a = input().split()
    list_a = convert_string_to_int(list_a)
    num_list.append(list_a)

# Call the print_lower_triangle function
print_lower_triangle(num_list)

Input:

3 3
1 2 3
10 20 30
5 10 15

Output:

[1]
[10, 20]
[5, 10, 15]

Elements of principal diagonal:
-----------------------------------------

def get_principal_diagonal_elements(matrix, m, n):
    # Write your code here
    diagonal_result_matrix = []
    for i in range(m):
        if i < n:
            element = matrix[i][i]
            diagonal_result_matrix.append(element)
    return diagonal_result_matrix  
    
def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list


m, n = input().split()
m, n = int(m), int(n)
num_list = []

for i in range(m):
    list_a = input().split()
    list_a = convert_string_to_int(list_a)
    num_list.append(list_a)

# Call the get_principal_diagonal_elements function

diagonal_elements = get_principal_diagonal_elements(num_list,m,n)
print(diagonal_elements)

Input:

3 3
1 2 3
10 20 30
5 10 15

Output:

[1, 20, 15]

Transpose Matrix:
------------------------

def get_transpose_of_matrix(matrix, m, n):
    # Complete this function
     transpose_matrix = []
     for i in range(n):
         row = []
         for j in range(m):
             row.append(matrix[j][i])
         transpose_matrix.append(row)
     return transpose_matrix

def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list


m, n = input().split()
m, n = int(m), int(n)
num_list = []

for i in range(m):
    list_a = input().split()
    list_a = convert_string_to_int(list_a)
    num_list.append(list_a)

# Call the get_transpose_of_matrix function
transpose_matrix = get_transpose_of_matrix(num_list, m, n)
for row in transpose_matrix:
  print(row)
  
Explaination:

n the 1st iteration in Outer for loop:
i = 0
transpose_matrix = []

1st iteration in inner for loop:
row = []
j = 0
row.append(matrix[j][i]) => row.append( matrix[0][0]) i.e., row = [-50]

2nd iteration in inner for loop:
i = 0
j = 1
row = [-50]
row.append(matrix[j][i] ) => row.append(matrix[1][0]) i.e., row = [-50, 88]
inner for loop breaks at j = 2
transpose_matrix.append(row) => transpose_matrix.append([-50, 88]) => transpose_matrix = [[-50, 88]]


In the 2nd iteration in Outer for loop:
i = 1
transpose_matrix = [[-50, 88]]

1st iteration in inner for loop:
row = []
j = 0
row.append(matrix[j][i] ) => row.append(matrix[0][1])i.e., row = [20]

2nd iteration in inner for loop:
j = 1
row.append(matrix[j][i] ) => row .append(matrix[1][1]) i.e., row = [20, 17]
inner for loop breaks at j = 2
transpose_matrix.append(row) => transpose_matrix.append([20, 17]) => transpose_matrix = [[-50, 88], [20, 17]]

Similarly for remaining iteration and return from the get_transpose_of_matrix as below

[[-50, 88], [20, 17], [3, 38], [25, 72], [-20, -10]]

Input:

3 3
1 2 3
10 20 30
5 10 15

Output:

[1, 10, 5]
[2, 20, 10]
[3, 30, 15]

Input:

2 5
-50 20 3 25 -20
88 17 38 72 -10

Output:

[-50, 88]
[20, 17]
[3, 38]
[25, 72]
[-20, -10]

Add two matrices:
------------------------

def add_two_matrices(first_matrix, second_matrix, m, n):
    # Complete this function
    result_matrix = []
    for i in range(m):
        row_result = []
        for j in range(n):
            value = first_matrix[i][j] + second_matrix[i][j]
            row_result.append(value)
        result_matrix.append(row_result)
    return result_matrix


def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list


def read_matrix_inputs(m):
    num_list = []
    for i in range(m):
        list_a = input().split()
        list_a = convert_string_to_int(list_a)
        num_list.append(list_a)
    return num_list


m, n = input().split()
m, n = int(m), int(n)

first_matrix = read_matrix_inputs(m)
second_matrix = read_matrix_inputs(m)

# call the add_two_matrices matrices
result_matrix = add_two_matrices(first_matrix, second_matrix, m, n)
for row in result_matrix:
    print(row)

Input:

3 3
1 2 3
10 20 30
5 10 15
2 4 6
11 22 33
7 14 21

Output:

[3, 6, 9]
[21, 42, 63]
[12, 24, 36]

Row - max,min and sum:
---------------------------

def print_max_min_sum_for_row_wise(num_list):
    # Complete this function
    max_list = []
    min_list = []
    sum_list = []
    for each_row in num_list:
        max_list.append(max(each_row))
        min_list.append(min(each_row))
        sum_list.append(sum(each_row))
        
    print(max_list)
    print(min_list)
    print(sum_list)

def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list


m, n = input().split()
m, n = int(m), int(n)
num_list = []

for i in range(m):
    list_a = input().split()
    list_a = convert_string_to_int(list_a)
    num_list.append(list_a)

print_max_min_sum_for_row_wise(num_list)

Input:

3 3
1 2 3
10 20 30
5 10 15

Output:

[3, 30, 15]
[1, 10, 5]
[6, 60, 30]

Column - max,min and sum:
---------------------------------

def get_transpose_of_matrix(matrix, m, n):
    # Complete this function
    transpose_matrix = []
    for i in range(n):
        row = []
        for j in range(m):
            row.append(matrix[j][i])
        transpose_matrix.append(row)
    return transpose_matrix
    


def print_max_min_sum_for_row_wise(num_list):
    # Complete this function
    max_list = []
    min_list = []
    sum_list = []
    for each_row in num_list:
        max_list.append(max(each_row))
        min_list.append(min(each_row))
        sum_list.append(sum(each_row))
        
    print(max_list)
    print(min_list)
    print(sum_list)


def convert_string_to_int(list_a):
    new_list = []
    for item in list_a:
        num = int(item)
        new_list.append(num)
    return new_list


m, n = input().split()
m, n = int(m), int(n)
num_list = []

for i in range(m):
    list_a = input().split()
    list_a = convert_string_to_int(list_a)
    num_list.append(list_a)


# Write your code here
# Call the get_transpose_of_matrix function
num_list = get_transpose_of_matrix(num_list, m, n)
# Call the print_max_min_sum_for_row_wise function
print_max_min_sum_for_row_wise(num_list)

Input:

3 3
1 2 3
10 20 30
5 10 15

Output:

[10, 20, 30]
[1, 2, 3]
[16, 32, 48]

Coding pratice-31:
--------------------------

Add a key:
------------

students_dict = {
    "Ram": "Cricket",
    "Naresh": "Football",
    "Vani": "Tennis",
    "Rahim": "Cricket"
}

# Write your code here
key,value = input().split()
students_dict[key] = value
print(students_dict)

Input:

Ramesh Cricket

Output:

{'Ram': 'Cricket', 'Naresh': 'Football', 'Vani': 'Tennis', 'Rahim': 'Cricket', 'Ramesh': 'Cricket'}

Sports drama:
---------------------

students_dict = {
    "Ram": "Cricket",
    "Naresh": "Football",
    "Vani": "Tennis",
    "Rahim": "Cricket"
}

# Write your code here
n = int(input())

for i in range(n):
    key_value_pair = input().split()
    key,value = key_value_pair[0],key_value_pair[1]
    students_dict[key] = value
    
print(students_dict)

Input:

3
Gopal Hockey
Jyothi Cricket
Akhil Football

Output:

{'Ram': 'Cricket', 'Naresh': 'Football', 'Vani': 'Tennis', 'Rahim': 'Cricket', 'Gopal': 'Hockey', 'Jyothi': 'Cricket', 'Akhil': 'Football'}

squares:
------------

n = int(input())

square_dict = {}
for num in range(1,n+1):
    square_dict[num] = num*num
    
print(square_dict)

Input:

3

Output:

{1: 1, 2: 4, 3: 9}

Remove N keys:
--------------------

alphabets = {
    'a': 97,
    'b': 98,
    'c': 99,
    'd': 100,
    'e': 101,
    'f': 102,
    'g': 103,
    'h': 104,
}

# Write your code here
keys = input().split()
for key in keys:
    if key in alphabets:
        del alphabets[key]
        
print(alphabets)

Input:

a d g

Output:

{'b': 98, 'c': 99, 'e': 101, 'f': 102, 'h': 104}

student ID Map:
------------------

def convert_to_key_value_pairs(keys_list, values_list):
   dict_a = {}
   number_of_keys = len(keys_list)
   
   for i in range(number_of_keys):
       key = keys_list[i]
       value = values_list[i]
       dict_a[key] = value
   return dict_a

student_names = input().split(",")
student_ids = input().split(",")

student_details = convert_to_key_value_pairs(student_names, student_ids)
student_details_items = student_details.items()
student_details = sorted(student_details_items)
print(student_details_items)
print(student_details)

for item in student_details:
   print(*item)
   
Input:

Anand,Ramesh,Kiran
ID102,ID101,ID100

Output:

dict_items([('Anand', 'ID102'), ('Ramesh', 'ID101'), ('Kiran', 'ID100')])
[('Anand', 'ID102'), ('Kiran', 'ID100'), ('Ramesh', 'ID101')]
Anand ID102
Kiran ID100
Ramesh ID101

Rename Key:
----------------

fruits = {
    "apples": 10,
    "bananas": 20,
    "mangoes": 15,
    "oranges": 200,
    "watermelons": 50
}

# Write your code here
key = input()
new_key = input()

fruit_items = list(fruits.items())
fruit_items_copy = fruit_items.copy()
fruits_count = len(fruit_items)

for i in range(fruits_count):
    if fruit_items[i][0] == key:
        updated_tuple = (new_key,fruit_items[i][1])
        fruit_items_copy[i] = updated_tuple
        
print(fruit_items_copy)

Input:

apples
pomegranates

Output:

[('pomegranates', 10), ('bananas', 20), ('mangoes', 15), ('oranges', 200), ('watermelons', 50)]

Combine two dictionaries:
---------------------------------

def convert_string_to_int(str_num_list):
  int_list = []
  for str_num in str_num_list:
    num = int(str_num)
    int_list.append(num)
  return int_list

def convert_to_key_value_pairs(keys_list, values_list):
  dict_a = {}
  number_of_keys = len(keys_list)
  for i in range(number_of_keys):
    key = keys_list[i]
    value = values_list[i]
    dict_a[key] = value
  return dict_a

dict_a_keys = input().split()
dict_a_values = input().split()
dict_b_keys = input().split()
dict_b_values = input().split()

dict_a_values = convert_string_to_int(dict_a_values)
dict_b_values = convert_string_to_int(dict_b_values)

student_details_1 = convert_to_key_value_pairs(dict_a_keys, dict_a_values)
student_details_2 = convert_to_key_value_pairs(dict_b_keys, dict_b_values)


student_details_1.update(student_details_2)
student_details = student_details_1.items()
student_details = sorted(student_details)

print(student_details)

Input:

Akhil Ram Raju Mohan
1 10 15 18
Gopal Krishna Vani Ram
21 22 19 20

Output:

[('Akhil', 1), ('Gopal', 21), ('Krishna', 22), ('Mohan', 18), ('Raju', 15), ('Ram', 20), ('Vani', 19)]

conecutive sum triangle: - 3 def function
------------------------------

def get_con_sum_list(int_list):
    con_sum_list = []
    end_index = len(int_list) - 1 
    for i in range(end_index):
        con_sum = int_list[i] + int_list[i+1]
        con_sum_list.append(con_sum)
    return con_sum_list
    
def print_sum_triangle(int_list):
    while len(int_list) > 1:
        con_sum_list = get_con_sum_list(int_list)
        print(con_sum_list)
        int_list = con_sum_list
    
    
def convert_string_to_int(str_num_list):
  int_list = []
  for str_num in str_num_list:
    num = int(str_num)
    int_list.append(num)
  return int_list
  
str_num_list = input().split(",")
int_list = convert_string_to_int(str_num_list)
print(int_list)
print_sum_triangle(int_list)

Input:

3,5,7,9

Output:

[3, 5, 7, 9]
[8, 12, 16]
[20, 28]
[48]

Grouping of scores:
----------------------------

def get_scores(ball_and_score_list):
    ball_score_dict = {}
    for item in ball_and_score_list:
        pair = item.split(":")
        print(pair)
        key,value = pair[0], int(pair[1])
        print(key,value)
        if key in ball_score_dict:
            score = ball_score_dict[key]
            ball_score_dict[key]  = score + value
        else:
            ball_score_dict[key] = value
    return ball_score_dict
    
ball_score_list = input().split(",")
ball_score_pairs = get_scores(ball_score_list)
ball_scores_items = ball_score_pairs.items()
ball_scores_items = sorted(ball_scores_items)
print(ball_scores_items)

Input:

r:1,b:2,r:3

Output:

['r', '1']
r 1
['b', '2']
b 2
['r', '3']
r 3
[('b', 2), ('r', 4)]

Grand Assignment-3:
-----------------------

Tic - Tac - Toe game:
----------------------------

def check_win(board):
 """
 Check if somebody win.
 Return winning symbol or None in case of tie
 """
 for r in range(3):
  if board[r][0] == board[r][1] == board[r][2]:
    return board[r][0]
 
 for c in range(3):
  if board[0][c] == board[1][c] == board[2][c]:
    return board[0][c]


  if board[0][0] == board [1][1] == board [2][2]:
    return board[0][0]
 
  if board[0][2] == board [1][1] == board [2][0]:
    return board[0][2]


board = []
for r in range(3):
 line = input()
 board.append(line.split())


res = check_win(board)
if res is None:
 print("Tie")
elif res.upper() == 'X':
 print('Anjali Wins')
elif res.upper() == 'O':
 print('Abhinav Wins')
 
Input:
 
O X O
O X X
O O X

Output:

Abhinav Wins

Remove Words:
---------------------

def toString(s): 
    str1 = "" 
    for ele in s: 
        str1 += ele  
    return str1 

def remove(sentence, n):
    n_words = []
    words = sentence.split(" ")
    for word in words:
        if not len(word) == n:
            n_words.append(word)
            n_words.append(" ")
    return toString(n_words)


a = str(input())
n = int(input())
print(remove(a, n))

Input:

Tea is good for you
3

Output:

is good

Word count:
---------------

def freq(sentence):
    sentence = sentence.split()
    wordlist = []
    for i in sentence:
        if i not in wordlist:
            wordlist.append(i)
            
    s=(wordlist)
    for i in range(0,len(s)):
        print(s[i] + ':',sentence.count(s[i]))
            
def main():
    s = input()
    freq(s)
    
if __name__ == "__main__":
    main()
    
Input:

This is my book

Output:

This: 1
is: 1
my: 1
book: 1

Word count - 2: sort()
----------------

def freq(sentence):
    sentence = sentence.split()
    wordlist = []
    for i in sentence:
        if i not in wordlist:
            wordlist.append(i)
            wordlist.sort()
    s=(wordlist)
    for i in range(0,len(s)):
        print(s[i] + ':',sentence.count(s[i]))
            
def main():
    s = input()
    freq(s)
    
if __name__ == "__main__":
    main()
    
Input:

This is my book

Output:

This: 1
book: 1
is: 1
my: 1

sample calculator-2:
-----------------------

n = input().split()
first_word = n[0]
second_word = n[1]
third_word = n[2]
first_word = int(first_word)
third_word = int(third_word)

if second_word == '+' :
    print(first_word + third_word)
elif second_word == '-':
    print(first_word - third_word)
elif second_word == '*':
    print(first_word * third_word)
elif second_word == '/':
    print(first_word / third_word)
elif second_word == '%':
    print(first_word % third_word)

Input:

3 + 5

Output:

8

prefix suffix:
-----------------------

full_string = input()
subsequence = input()
first_word = full_string[-4:]
second_word = subsequence[:4]

if first_word == second_word:
    print(first_word)
elif full_string[-2:] == subsequence[:2]:
    print(full_string[-2:])
elif full_string[-3:] == subsequence[:3]:
    print(full_string[-3:])
elif first_word != second_word:
    print("No overlapping")
    

Input:

ramisgood
goodforall

Output:

good

Anti-Diagonals:
--------------------------

m, n = map(int, input().split())
matrix = [list(map(int, input().split())) for _ in range(m)]

max_sum = m + n - 2
for sum in range(max_sum+1):
    for i in range(sum+1):
        if i < m and sum - i < n:
            print(matrix[i][sum - i], end=" ")
    print()
    
 Input:
 
 2 3
1 5 5
2 7 8

Output:

1 
5 2 
5 7 
8 

Grand Assignment-5:
--------------------------

secret message-1:
----------------------

string = input()
lower_string = string.lower()
#print(lower_string)

alpha_dict = {'a':'z', 'b':'y', 'c':'x', 'd':'w', 'e':'v', 'f':'u', 'g':'t', 'h':'s', 'i':'r', 
                'j':'q', 'k':'p', 'l':'o', 'm':'n', 'n':'m', 'o':'l', 'p':'k', 'q':'j', 'r':'i', 
                's':'h', 't':'g', 'u':'f', 'v':'e', 'w':'d', 'x':'c', 'y':'b', 'z':'a', ' ' : ' '}

s=""
for i in lower_string:
    if i in alpha_dict.keys():
        s=s+alpha_dict[i]
    elif i==" ":
        s=s+" "
print(s)

Input:

python

Output:

kbgslm

secret message-2:
---------------------------

string = input()
lower_string = string.lower()
#print(lower_string)

alpha_dict = {'a':'1', 'b':'2', 'c':'3', 'd':'4', 'e':'5', 'f':'6', 'g':'7', 'h':'8', 'i':'9', 
                'j':'10', 'k':'11', 'l':'12', 'm':'13', 'n':'14', 'o':'15', 'p':'16', 'q':'17', 'r':'18', 
                's':'19', 't':'20', 'u':'21', 'v':'22', 'w':'23', 'x':'24', 'y':'25', 'z':'26', ' ' : ' '}

s=""
for i in lower_string:
    if i==" ":
        s=s[:-1]+" "
    elif i in alpha_dict.keys():
        s=s+alpha_dict[i]+"-"
        
print(s[0:-1:1])

Input:

python

Output:

16-25-20-8-15-14

weekends:
----------------

import datetime

date_start_str = input()
date_end_str = input()
# convert string to date format 
date_start = datetime.datetime.strptime(date_start_str, '%d %b %Y')
date_end = datetime.datetime.strptime(date_end_str, '%d %b %Y')
# initialization of the initial number of weekends
day = datetime.timedelta(days=1)
count_saturday = 0
count_sunday = 0
# iteration over all dates in the range
while date_start <= date_end:
    if date_start.isoweekday() == 6:
        count_saturday += 1
    if date_start.isoweekday() == 7:
        count_sunday += 1
    date_start += day
# output a single line containing two space-separated integers
print("Saturday:",count_saturday)
print("Sunday:",count_sunday)

Input:

25 Jan 2021
14 Feb 2021

Output:

Saturday: 3
Sunday: 3

New year countdown:
------------------------

from datetime import datetime

line = input()
D = datetime.strptime(line, '%b %d %Y %I:%M %p') 
NY = datetime(D.year+1, 1, 1)
dt = NY - D
h = dt.days*24 + dt.seconds//3600
m = (dt.seconds // 60) % 60
print(f'{h} hours {m} minutes')

Input:

Dec 30 2020 02:43 PM

Output:

33 hours 17 minutes

smallest missing number:
-----------------------------

def convert_string_to_int(list_a):
  new_list = []
  for item in list_a:
    num = int(item)
    new_list.append(num)
  return new_list
  
num_list = input().split()
num_list = convert_string_to_int(num_list)
maximum = len(num_list)
num_set = set(num_list)

first_n_num_set = set(range(1,maximum+1))
missing_num_set = first_n_num_set.difference(num_set)
missing_num_list = list(missing_num_set)
missing_num_list.sort()
r = min(missing_num_list)
print(r)


Input:

3 1 2 5 3 7 7

Output:

4

Grand Assignment-4:
-----------------------------

String Rotation:
-------------------

#Get the given strings S1 and S2
s1=input("")
s2=input("")
numberRotation =0
tmp=s1
NoMatch=False
#Check two strings
while tmp!=s2:
    numberRotation+=1
    #Right rotation 
    tmp = s1[len(s1) - numberRotation:] + s1[0 : len(s1) - numberRotation]
    if(numberRotation>=len(s1)):
        tmp=s2
        NoMatch=True


#If string S2 is a rotation of another string S1,
#print number of right rotations made by string
#S1 to match the string S2. Otherwise, print "No Match".
if NoMatch:
    print("No Match")
else:
    print(str(numberRotation))
    
Input:

python
onpyth

Output:

2

Number String-1:
-------------------

# get the string from the user
inputString =input("");
sumDigits =0
numberDigits=0
# Looping through a string.
for character in inputString:
    if (character.isdigit()):
        # Calculate the sum of the digits of all numbers that appear in the string
        sumDigits+=int(character)
        numberDigits+=1
# Calculate the average of the digits of all numbers that appear in the string
average=sumDigits/numberDigits
# Print the sum of all digits(8) 
print(str(sumDigits))
# Print the average of all digits(2.0) in the new line.
print(round(average,2))

Input:

I am 25 years and 10 months old

Output:

8
2.0

Number String-2:
--------------------------

def SumAndAverage(str1):
    # A temporary string
    temp = "0"
    # holds sum of all numbers present in the string
    Sum = 0
    #counter of numbers in row
    count=0
    # read each char
    for ch in str1:
        # if  char is a digit
        if (ch.isdigit()):
            temp += ch
        # if current character is not digit
        else:
            if temp!="0":
                count+=1
            Sum += int(temp)
            # reset temporary string
            temp = "0"
    if str1[-1].isdigit():
        count+=1
    Sum += int(temp)
    # print sum of numbers
    print(Sum)
    # print average of nubers
    print(round((Sum / count),2))


# Main code

# input the string

str1 = input()
# Function call
SumAndAverage(str1)

Input:

I am 25 years and 10 months old

Output:

35
17.5

First Perfect square:
----------------------------

a = int(input())
b = int(input())
list_a = []
count = 0
for i in range(2,b):
    for num in range(a, b + 1):
        if i*i == num:
            list_a += [int(num)]
            
            count += 1
            break
    
if count == 0:
    print("No Perfect Square")
elif count != 0:
    print(list_a[0])
    
Input:

4
16

Output:

4

Ordered Matrix:
--------------------

m,n = input().split()
m,n = int(m),int(n)

matrix = []
for i in range(m):
    row = input().split()
    numbers = [int(number) for number in row]
    matrix.append(numbers)
    print(matrix)
    
matrix_to_list = []
for numbers in matrix:
    for number in numbers:
        matrix_to_list.append(number)
        print(matrix_to_list)
        
matrix_to_list.sort()
index_of_number = 0

for i in range(m):
    for j in range(n):
        matrix[i][j] = matrix_to_list[index_of_number]
        index_of_number += 1
for numbers in matrix:
    for number in numbers:
        print(number,end=' ')
    print()
    
Input:

3 3
1 20 3
30 10 2
5 11 15

Output:

[[1, 20, 3]]
[[1, 20, 3], [30, 10, 2]]
[[1, 20, 3], [30, 10, 2], [5, 11, 15]]
[1]
[1, 20]
[1, 20, 3]
[1, 20, 3, 30]
[1, 20, 3, 30, 10]
[1, 20, 3, 30, 10, 2]
[1, 20, 3, 30, 10, 2, 5]
[1, 20, 3, 30, 10, 2, 5, 11]
[1, 20, 3, 30, 10, 2, 5, 11, 15]
1 2 3 
5 10 11 
15 20 30

Class and objects:
-----------------------

Modeling Class:
----------------------

Let’s model the scenario of shopping cart of ecommerce site.

The features a cart should have

can add an item
can remove an item from cart
update quantity of an item
to show list of items in cart
to show total price for the items in the cart

class Cart:
    def __init__(self):
        self.items = {}
        self.price_details = {"book": 500, "laptop": 30000}

    def add_item(self, item_name, quantity):
        self.items[item_name] = quantity

    def remove_item(self, item_name):
        del self.items[item_name]

    def update_quantity(self, item_name, quantity):
        self.items[item_name] = quantity

    def get_cart_items(self):
        cart_items = list(self.items.keys())
        return cart_items

    def get_total_price(self):
        total_price = 0
        for item, quantity in self.items.items():
            total_price += quantity * self.price_details[item]
        return total_price


cart_obj = Cart()
cart_obj.add_item("book", 3)
cart_obj.add_item("laptop", 1)
print(cart_obj.get_total_price())
cart_obj.remove_item("laptop")
print(cart_obj.get_cart_items())
cart_obj.update_quantity("book", 2)
print(cart_obj.get_total_price())

Output:

31500
['book']
1000

Coding Pratice-32:
-------------------------

Car:
-------

class Car:
    def __init__(self,color,max_speed,acceleration,tyre_friction):
        self.color = color
        self.max_speed = max_speed
        self.acceleration = acceleration
        self.tyre_friction = tyre_friction


# You need not change any code below.
# Do not call this function anywhere. It will automatically be called internally during tests.
def default_test():
    car = Car(color="Red", max_speed=250, acceleration=10, tyre_friction=3)
    print(car.color)
    print(car.max_speed)
    print(car.acceleration)
    print(car.tyre_friction)
    
Input:

Checking Default Tests

Output:

Red
250
10
3

Car-2:
------------


class Car:
    def __init__(self, color, max_speed, acceleration, tyre_friction):
        self.color = color
        self.max_speed = max_speed
        self.acceleration = acceleration
        self.tyre_friction = tyre_friction
        self.is_engine_started = False

    def start_engine(self):
        self.is_engine_started = True

    def stop_engine(self):
        self.is_engine_started = False


# You need not change any code below.
# Do not call this function anywhere. It will automatically be called internally during tests.
def default_test():
    car = Car(color="Red", max_speed=250, acceleration=10, tyre_friction=3)
    print(car.is_engine_started)  # As car is not yet started, it should print False
    car.start_engine()  # Starting the engine
    print(car.is_engine_started)  # As engine is on, it should print True
    car.stop_engine()  # Stopping the engine
    print(car.is_engine_started)  # As engine is off, it should print False
    
Input:

Checking Default Tests

Output:

False
True
False

Car-3:
----------

class Car:
    def __init__(self, color, max_speed, acceleration, tyre_friction):
        self.color = color
        self.max_speed = max_speed
        self.acceleration = acceleration
        self.tyre_friction = tyre_friction
        self.is_engine_started = False
        self.current_speed = 0

    def start_engine(self):
        self.is_engine_started = True

    def stop_engine(self):
        self.is_engine_started = False

    def accelerate(self):
        if not self.is_engine_started:
            print("Car has not started yet")
        else:
            self.current_speed += self.acceleration
            if self.current_speed > self.max_speed:
                self.current_speed = self.max_speed


# You need not change any code below.
# Do not call this function anywhere. It will automatically be called internally during tests.
def default_test():
    car = Car(color="Red", max_speed=50, acceleration=10, tyre_friction=3)
    car.accelerate()  # Calling the accelerate method when the is_engine_started is False
    # The above line will print "Car has not started yet"
    print(car.current_speed)
    car.start_engine()  # Starting the car engine
    print(car.current_speed)  # Car engine is started but not yet accelerated => 0
    car.accelerate()  # Calling the accelerate method when the is_engine_started is True
    print(car.current_speed)  # current_speed value has increased by acceleration value (0 + 10 => 10)
    car.accelerate()
    print(car.current_speed)  # current_speed value is 10 and increasing again by acceleration value (10 + 10 => 20)
    car.accelerate()
    car.accelerate()
    car.accelerate()
    print(car.current_speed)
    car.accelerate()  # Accelerating the car more than its max_speed
    print(car.current_speed)  # Any car cannot accelerate more than its max_speed => 50

Output:

Car has not started yet
0
0
10
20
50
50

Car-4:
-----------


class Car:
    def __init__(self, color, max_speed, acceleration, tyre_friction):
        self.color = color
        self.max_speed = max_speed
        self.acceleration = acceleration
        self.tyre_friction = tyre_friction
        self.is_engine_started = False
        self.current_speed = 0

    def start_engine(self):
        self.is_engine_started = True

    def stop_engine(self):
        self.is_engine_started = False

    def accelerate(self):
        if not self.is_engine_started:
            print("Car has not started yet")
        else:
            self.current_speed += self.acceleration
            if self.current_speed > self.max_speed:
                self.current_speed = self.max_speed

    def apply_brakes(self):
        self.current_speed -= self.tyre_friction
        if self.current_speed < 0:
            self.current_speed = 0


# You need not change any code below.
# Do not call this function anywhere. It will automatically be called internally during tests.
def default_test():
    car = Car(color="Red", max_speed=250, acceleration=10, tyre_friction=3)
    car.start_engine()
    car.accelerate()  # Calling the accelerate method when the is_engine_started is True
    print(car.current_speed)  # 10
    car.apply_brakes()  # Calling the apply_brakes method
    # current_speed of the car should decrease according to the tyre_friction value.
    print(car.current_speed)   # (10 - 3 => 7)
    car.apply_brakes()
    print(car.current_speed)  # 7 - 3 => 4
    car.apply_brakes()
    print(car.current_speed)  # 4 - 3 => 1
    car.apply_brakes()
    print(car.current_speed)  # 1 - 3 => 0 (current_speed should never go behind 0.)

Output:

10
7
4
1
0

Explaination:

Let us consider an object car. The car has different types of properties like color, max-speed, tyre friction, and so on. Let us define the class called Car with color as Red, max_speed as 50, acceleration as 10 and tyre_friction as 3.When a new car is created, the engine should be off by default and current speed should be 0.

class Car:
    ﻿def __init__(self,color,max_speed,acceleration,tyre_friction):
        self.color = color
        self.max_speed = max_speed
        self.acceleration = acceleration
        self.tyre_friction = tyre_friction
        self.is_engine_started = False
        self.current_speed = 0

﻿car = Car(color="Red", max_speed=50, acceleration=10, tyre_friction=3)
Now the car can perform different types of actions like we can stop the engine or start the engine we can accelerate the speed of the car, we can apply breaks. Now we will define every action 

Start engine and Stop engine:

By default the engine is in the rest condition ie., is_engine_started is False.So when we call the function start_engine() then the engine will get started i.e., is_engine_started is Trueand when we all the function stop_engine() then the engine will get stoped i.e., is_engine_started is False .

def start_engine(self):
    self.is_engine_started = True
def stop_engine(self):
    self.is_engine_started = False
Accelerate:

Here we can accelerate the car speed up to the maximum speed. Whenever the car's current speed is less than the maximum_speed and when the car engine is started then we can add both the acceleration speed and current speed. When this method is called when the car engine is off, the current_speed of the car should not increase, print the message "Car has not started yet" .

def accelerate(self):if not self.is_engine_started:
        print("Car has not started yet")
    else:
        self.current_speed += self.acceleration
        if self.current_speed > self.max_speed:
            self.current_speed = self.max_speed
Sound Horn:

if the engine is in started it will print "Beep Beep" else it will print "Car has not started yet".

Car-5:
--------------


class Car:
    def __init__(self, color, max_speed, acceleration, tyre_friction):
        self.color = color
        self.max_speed = max_speed
        self.acceleration = acceleration
        self.tyre_friction = tyre_friction
        self.is_engine_started = False
        self.current_speed = 0

    def start_engine(self):
        self.is_engine_started = True

    def stop_engine(self):
        self.is_engine_started = False

    def accelerate(self):
        if not self.is_engine_started:
            print("Car has not started yet")
        else:
            self.current_speed += self.acceleration
            if self.current_speed > self.max_speed:
                self.current_speed = self.max_speed

    def apply_brakes(self):
        self.current_speed -= self.tyre_friction
        if self.current_speed < 0:
            self.current_speed = 0

    def sound_horn(self):
        if self.is_engine_started:
            print("Beep Beep")
        else:
            print("Car has not started yet")


# You need not change any code below.
# Do not call this function anywhere. It will automatically be called internally during tests.
def default_test():
    car = Car(color="Red", max_speed=250, acceleration=10, tyre_friction=3)
    car.sound_horn()  # Calling the accelerate method when the is_engine_started is False
    car.start_engine()  # Starting the engine
    car.sound_horn()  # Calling the accelerate method when the is_engine_started is True

Output:

Car has not started yet
Beep Beep

Attributes & Methods:
---------------------------

Attributes:
-------------

Broadly, attributes can be categorized as 

Instance Attributes
Class Attributes

Instance Attributes:
----------------------------

Attributes whose value can differ for each instance of class are modeled as instance attributes.

Ex: Items in Cart


Class Attributes:
-------------------------

Attributes whose values stay common for all the objects are modelled as Class Attributes.

Ex:  Minimum Cart Bill,
       Flat Discount

Accessing Instance Attributes:
--------------------------------------

Code:

class Cart:
  flat_discount = 0
  min_bill = 100
  def __init__(self):
      self.items = {}
  def add_item(self,..):
      self.items[item_name] = quantity
  def display_items(self):
      print(items)
a = Cart()
a.display_items()

Output:

NameError: name 'items' is not d

Accessing Using Self:
--------------------------
Code:

class Cart:
   flat_discount = 0
   min_bill = 100
   def __init__(self):
       self.items = {}
   def add_item(self, item_name,quantity):
       self.items[item_name] = quantity
   def display_items(self):
       print(self.items)
a = Cart()
a.add_item("book", 3)
a.display_items()

Output:

{"book": 3}

Accessing Using Object:
-------------------------------

Code:

class Cart:
   flat_discount = 0
   min_bill = 100
   def __init__(self):
       self.items = {}
   def add_item(self, item_name,quantity):
       self.items[item_name] = quantity
   def display_items(self):
       print(self.items)
a = Cart()
a.add_item("book", 3)
print(a.items)

Output:

{"book": 3}

Accessing Using Class:
------------------------------

Code:

class Cart:
   flat_discount = 0
   min_bill = 100
   def __init__(self):
       self.items = {}
   def add_item(self, item_name,quantity):
       self.items[item_name] = quantity
   def display_items(self):
       print(self.items)
print(Cart.items)

Output:

AttributeError: type object 'Cart' has no attribute 'items'

Accessing Class Attributes:
------------------------------------

Example 1
Code:

class Cart:
   flat_discount = 0
   min_bill = 100
   def __init__(self):
       self.items = {}

print(Cart.min_bill)

Output:

100

Example 2

Code:

class Cart:
   flat_discount = 0
   min_bill = 100
   def __init__(self):
       self.items = {}
   def print_min_bill(self):
       print(Cart.min_bill)

a = Cart()
a.print_min_bill()

Output:

100

Updating Class Attribute:
----------------------------------

Code:

class Cart:
   flat_discount = 0
   min_bill = 100
   def print_min_bill(self):
       print(Cart.min_bill)
a = Cart()
b = Cart()
Cart.min_bill = 200
print(a.print_min_bill())
print(b.print_min_bill())

Output:

200
200

Method:
----------------

Broadly, methods can be categorized as 

Instance Methods
Class Methods
Static Methods

Instance Methods:
------------------------

Instance methods can access all attributes of the instance and have self as a parameter.

Example 1
Code:

class Cart:
   def __init__(self):
       self.items = {}
   def add_item(self, item_name,quantity):
      self.items[item_name] = quantity
   def display_items(self):
      print(self.items)

a = Cart()
a.add_item("book", 3)
a.display_items()

Output:

{"book": 3}

Example 2
Code:

class Cart:
  def __init__(self):
      self.items = {}
  def add_item(self, item_name,quantity):
     self.items[item_name] = quantity
     self.display_items()
  def display_items(self):
     print(self.items)

a = Cart()
a.add_item("book", 3)

Output:

{"book": 3}

Class Methods:
-----------------------------

Methods which need access to class attributes but not instance attributes are marked as Class Methods.
For class methods, we send cls as a parameter indicating we are passing the class.

Code:

class Cart:
   flat_discount = 0
   min_bill = 100
   @classmethod
   def update_flat_discount(cls, 
                          new_flat_discount):
       cls.flat_discount = new_flat_discount

Cart.update_flat_discount(25)
print(Cart.flat_discount)

Output:

25

@classmethod decorator marks the method below it as a class method.

We will learn more about decorators in upcoming sessions.

Accessing Class Method:
-------------------------------
Code:

class Cart:
  flat_discount = 0
  min_bill = 100
  @classmethod
  def update_flat_discount(cls, new_flat_discount):
      cls.flat_discount = new_flat_discount

  @classmethod
  def increase_flat_discount(cls, amount):
      new_flat_discount = cls.flat_discount + amount
      cls.update_flat_discount(new_flat_discount)

Cart.increase_flat_discount(50)
print(Cart.flat_discount)

Output:

50

Static Method:
------------------------

We might need some generic methods that don’t need access to either instance or class attributes. These type of methods are called Static Methods. 

Usually, static methods are used to create utility functions which make more sense to be part of the class.

@staticmethod decorator marks the method below it as a static method.

We will learn more about decorators in upcoming sessions.

Code:

class Cart:

   @staticmethod
   def greet():
       print("Have a Great Shopping")

Cart.greet()

Output:

Have a Great Shopping

Overview of Instance, Class & Static Methods:
---------------------------------------------------------

Instance Methods	        Class Methods	                    Static Methods
self as parameter	        cls as parameter	                No cls or self as parameters
No decorator required	    Need decorator @classmethod	        Need decorator @staticmethod
Can be accessed through     Can be accessed through class       Can be accessed through class
object(instance of class)	        	


Inheritence:
-----------------

Advantages of Modelling Classes as above:
----------------------------------------------

Reusability
Clear Separation
More Organized
Inheritance

Inheritance is a mechanism by which a class inherits attributes and methods from another class.
With Inheritance, we can have ElectronicItem inherit the attributes & methods from Product instead of defining them again.
Product is Super/Base/Parent Class and ElectronicItem is Sub/Derived/Child Class.

Super Class:
--------------------

Code:

class Product:
    def __init__(self, name, price, deal_price, ratings):
        self.name = name
        self.price = price
        self.deal_price = deal_price
        self.ratings = ratings
        self.you_save = price - deal_price
    def display_product_details(self):
        print("Product: {}".format(self.name))
        print("Price: {}".format(self.price))
        print("Deal Price: {}".format(self.deal_price))
        print("You Saved: {}".format(self.you_save))
        print("Ratings: {}".format(self.ratings))

p = Product("Shoes",500, 250, 3.5)
p.display_product_details()

Output:

Product: Shoes
Price: 500
Deal Price: 250
You Saved: 250
Ratings: 3.5

Sub Class:
------------------

The subclass automatically inherits all the attributes & methods from its superclass.

Example 1

Code:

class Product:
    def __init__(self, name, price, deal_price, ratings):
        self.name = name
        self.price = price
        self.deal_price = deal_price
        self.ratings = ratings
        self.you_save = price - deal_price
    def display_product_details(self):
        print("Product: {}".format(self.name))
        print("Price: {}".format(self.price))
        print("Deal Price: {}".format(self.deal_price))
        print("You Saved: {}".format(self.you_save))
        print("Ratings: {}".format(self.ratings))

class ElectronicItem(Product):
    pass
class GroceryItem(Product):
    pass

e = ElectronicItem("TV",45000, 40000, 3.5)
e.display_product_details()

e = GroceryItem("milk", 25, 20, 3)
e.display_product_details()

Output:

Product: TV
Price: 45000
Deal Price: 40000
You Saved: 5000
Ratings: 3.5
Product: milk
Price: 25
Deal Price: 20
You Saved: 5
Ratings: 3

Example 2

Code:

class Product:
   def __init__(self, name, price, deal_price, ratings):
       self.name = name
       self.price = price
       self.deal_price = deal_price
       self.ratings = ratings
       self.you_save = price - deal_price
   def display_product_details(self):
       print("Product: {}".format(self.name))
       print("Price: {}".format(self.price))
       print("Deal Price: {}".format(self.deal_price))
       print("You Saved: {}".format(self.you_save))
       print("Ratings: {}".format(self.ratings))

class ElectronicItem(Product):
   def set_warranty(self, warranty_in_months):
       self.warranty_in_months = warranty_in_months
      
   def get_warranty(self):
       return self.warranty_in_months

e = ElectronicItem("TV",45000, 40000, 3.5)
e.set_warranty(24)
print(e.get_warranty())

Output:

24

Super Class & Sub Class:
---------------------------------

Superclass cannot access the methods and attributes of the subclass.

Code:

class Product:
   def __init__(self, name, price, deal_price, ratings):
       self.name = name
       self.price = price
       self.deal_price = deal_price
       self.ratings = ratings
       self.you_save = price - deal_price
   def display_product_details(self):
       print("Product: {}".format(self.name))
       print("Price: {}".format(self.price))
       print("Deal Price: {}".format(self.deal_price))
       print("You Saved: {}".format(self.you_save))
       print("Ratings: {}".format(self.ratings))

class ElectronicItem(Product):
   def set_warranty(self, warranty_in_months):
       self.warranty_in_months = warranty_in_months
      
   def get_warranty(self):
       return self.warranty_in_months

p = Product("TV",45000, 40000, 3.5)
p.set_warranty(24)

Output:

AttributeError: 'Product' object has no attribute 'set_warranty'

Sub Class Method:
-----------------------

Code:

class Product:
   def __init__(self, name, price, deal_price, ratings):
       self.name = name
       self.price = price
       self.deal_price = deal_price
       self.ratings = ratings
       self.you_save = price - deal_price
   def display_product_details(self):
       print("Product: {}".format(self.name))
       print("Price: {}".format(self.price))
       print("Deal Price: {}".format(self.deal_price))
       print("You Saved: {}".format(self.you_save))
       print("Ratings: {}".format(self.ratings))

class ElectronicItem(Product):
   def set_warranty(self, warranty_in_months):
       self.warranty_in_months = warranty_in_months
      
   def get_warranty(self):
       return self.warranty_in_months

e = ElectronicItem("TV",45000, 40000, 3.5)
e.set_warranty(24)
e.display_product_details()

Output:

Product: TV
Price: 45000
Deal Price: 40000
You Saved: 5000
Ratings: 3.5

Calling Super Class Method:
---------------------------------

We can call methods defined in superclass from the methods in the subclass. 

Code:

class Product:
   def __init__(self, name, price, deal_price, ratings):
       self.name = name
       self.price = price
       self.deal_price = deal_price
       self.ratings = ratings
       self.you_save = price - deal_price
   def display_product_details(self):
       print("Product: {}".format(self.name))
       print("Price: {}".format(self.price))
       print("Deal Price: {}".format(self.deal_price))
       print("You Saved: {}".format(self.you_save))
       print("Ratings: {}".format(self.ratings))

class ElectronicItem(Product):
   def set_warranty(self, warranty_in_months):
       self.warranty_in_months = warranty_in_months
      
   def get_warranty(self):
       return self.warranty_in_months
   
   def display_electronic_product_details(self):
       self.display_product_details()
       print("Warranty {} months".format(self.warranty_in_months))

e = ElectronicItem("TV",45000, 40000, 3.5)
e.set_warranty(24)
e.display_electronic_product_details()

Output:

Product: TV
Price: 45000
Deal Price: 40000
You Saved: 5000
Ratings: 3.5
Warranty 24 months

Composition:
------------------

Modelling instances of one class as attributes of another class is called Composition

Code:

class Product:
  
    def __init__(self, name, price, deal_price, ratings):
       self.name = name
       self.price = price
       self.deal_price = deal_price
       self.ratings = ratings
       self.you_save = price - deal_price

    def display_product_details(self):
           print("Product: {}".format(self.name))
           print("Price: {}".format(self.price))
           print("Deal Price: {}".format(self.deal_price))
           print("You Saved: {}".format(self.you_save))
           print("Ratings: {}".format(self.ratings))
    
    def get_deal_price(self):
        return self.deal_price

class ElectronicItem(Product):
   def set_warranty(self, warranty_in_months):
       self.warranty_in_months = warranty_in_months
      
   def get_warranty(self):
       return self.warranty_in_months

class GroceryItem(Product):
    def set_expiry_date(self, expiry_date):
       self.expiry_date = expiry_date
      
    def get_expiry_date(self):
        return self.expiry_date
        
    def display_grocery_item_details(self):
        self.display_product_details()
        print('Expiry Date: {}'.format(self.expiry_date))
    
   
class Order:
    def __init__(self, delivery_speed, delivery_address):
         self.items_in_cart = []
         self.delivery_speed = delivery_speed
         self.delivery_address = delivery_address 
         
    def add_item(self, product, quantity):
        self.items_in_cart.append((product, quantity))

    def display_order_details(self):
        for product, quantity in self.items_in_cart:
            product.display_product_details()
            print("Quantity: {}".format(quantity))
            print("")
          
    def display_total_bill(self):
        total_bill = 0
        for product, quantity in self.items_in_cart:
             price = product.get_deal_price() * quantity
             total_bill += price
        print("Total Bill: {}".format(total_bill))

milk = GroceryItem("Milk",40, 25, 3.5)
milk.set_expiry_date('2024')

tv = ElectronicItem("TV",45000, 40000, 3.5)
tv.set_warranty(24)

order = Order("Prime Delivery", "Hyderabad")

order.add_item(milk, 2)
order.add_item(tv, 1)

order.display_order_details()
order.display_total_bill()

Output:

PProduct: Milk
Price: 40
Deal Price: 25
You Saved: 15
Ratings: 3.5
Quantity: 2

Product: TV
Price: 45000
Deal Price: 40000
You Saved: 5000
Ratings: 3.5
Quantity: 1

Total Bill: 40050

Method Overriding:
--------------------------

class Product:
  
    def __init__(self, name, price, deal_price, ratings):
       self.name = name
       self.price = price
       self.deal_price = deal_price
       self.ratings = ratings
       self.you_save = price - deal_price

    def display_product_details(self):
           print("Product: {}".format(self.name))
           print("Price: {}".format(self.price))
           print("Deal Price: {}".format(self.deal_price))
           print("You Saved: {}".format(self.you_save))
           print("Ratings: {}".format(self.ratings))
    
    def get_deal_price(self):
        return self.deal_price

class ElectronicItem(Product): 
   def set_warranty(self, warranty_in_months): 
       self.warranty_in_months = warranty_in_months
      
   def get_warranty(self):
       return self.warranty_in_months
   
   def display_product_details(self): x
        self.display_product_details() x
        print("Warranty {} months".format(self.warranty_in_months)) x
       
class GroceryItem(Product):
    def set_expiry_date(self, expiry_date):
       self.expiry_date = expiry_date
      
    def get_expiry_date(self):
        return self.expiry_date
        
    def display_grocery_item_details(self):
        self.display_product_details()
        print('Expiry Date: {}'.format(self.expiry_date))
    
   
class Order:
    def __init__(self, delivery_speed, delivery_address):
         self.items_in_cart = []
         self.delivery_speed = delivery_speed
         self.delivery_address = delivery_address 
         
    def add_item(self, product, quantity):
        self.items_in_cart.append((product, quantity))

    def display_order_details(self):
        for product, quantity in self.items_in_cart:
            product.display_product_details()
            print("Quantity: {}".format(quantity))
            print("")
          
    def display_total_bill(self):
        total_bill = 0
        for product, quantity in self.items_in_cart:
             price = product.get_deal_price() * quantity
             total_bill += price
        print("Total Bill: {}".format(total_bill))

milk = GroceryItem("Milk",40, 25, 3.5)
milk.set_expiry_date('2024')

tv = ElectronicItem("TV",45000, 40000, 3.5)
tv.set_warranty(24)

order = Order("Prime Delivery", "Hyderabad")

order.add_item(milk, 2)
order.add_item(tv, 1)

order.display_order_details()
order.display_total_bill()


Code:

class Product:
  
  def __init__(self, name, price, deal_price, ratings):
    self.name = name
    self.price = price
    self.deal_price = deal_price
    self.ratings = ratings
    self.you_save = price - deal_price

  def display_product_details(self):
      print("Product: {}".format(self.name))
      print("Price: {}".format(self.price))
      print("Deal Price: {}".format(self.deal_price))
      print("You Saved: {}".format(self.you_save))
      print("Ratings: {}".format(self.ratings))
   
  def get_deal_price(self):
    return self.deal_price

class ElectronicItem(Product):
   
  def display_product_details(self):
    self.display_product_details()    
    print("Warranty {} months".format(self.warranty_in_months))
    
  def set_warranty(self, warranty_in_months):
    self.warranty_in_months = warranty_in_months
    
  def get_warranty(self):
    return self.warranty_in_months

e = ElectronicItem("Laptop",45000, 40000,3.5)
e.set_warranty(10)
e.display_product_details()

Output:

RecursionError: maximum recursion depth exceeded

Because self.display_product_details() in ElectronicItem class does not call the method in the superclass.

Accessing Super Class’s Method:
---------------------------------------

super() allows us to call methods of the superclass (Product) from the subclass.

Instead of writing and methods to access and modify warranty we can override __init__

Let's add warranty of ElectronicItem.

class Product:
  
    def __init__(self, name, price, deal_price, ratings):
       self.name = name
       self.price = price
       self.deal_price = deal_price
       self.ratings = ratings
       self.you_save = price - deal_price

    def display_product_details(self):
           print("Product: {}".format(self.name))
           print("Price: {}".format(self.price))
           print("Deal Price: {}".format(self.deal_price))
           print("You Saved: {}".format(self.you_save))
           print("Ratings: {}".format(self.ratings))
    
    def get_deal_price(self):
        return self.deal_price

class ElectronicItem(Product):
   def set_warranty(self, warranty_in_months):
       self.warranty_in_months = warranty_in_months
      
   def get_warranty(self):
       return self.warranty_in_months
   
   def display_product_details(self):
        super().display_product_details()
        print("Warranty {} months".format(self.warranty_in_months))
       
class GroceryItem(Product):
    def set_expiry_date(self, expiry_date):
       self.expiry_date = expiry_date
      
    def get_expiry_date(self):
        return self.expiry_date
        
    def display_grocery_item_details(self):
        self.display_product_details()
        print('Expiry Date: {}'.format(self.expiry_date))
    
   
class Order:
    def __init__(self, delivery_speed, delivery_address):
         self.items_in_cart = []
         self.delivery_speed = delivery_speed
         self.delivery_address = delivery_address 
         
    def add_item(self, product, quantity):
        self.items_in_cart.append((product, quantity))

    def display_order_details(self):
        for product, quantity in self.items_in_cart:
            product.display_product_details()
            print("Quantity: {}".format(quantity))
            print("")
          
    def display_total_bill(self):
        total_bill = 0
        for product, quantity in self.items_in_cart:
             price = product.get_deal_price() * quantity
             total_bill += price
        print("Total Bill: {}".format(total_bill))

milk = GroceryItem("Milk",40, 25, 3.5)
milk.set_expiry_date('2024')

tv = ElectronicItem("TV",45000, 40000, 3.5)
tv.set_warranty(24)

order = Order("Prime Delivery", "Hyderabad")

order.add_item(milk, 2)
order.add_item(tv, 1)

order.display_order_details()
order.display_total_bill()

Output:

Product: Milk
Price: 40
Deal Price: 25
You Saved: 15
Ratings: 3.5
Quantity: 2

Product: TV
Price: 45000
Deal Price: 40000
You Saved: 5000
Ratings: 3.5
Warranty 24 months
Quantity: 1

Total Bill: 40050

Code:

class Product:
  
  def __init__(self, name, price, deal_price, ratings):
    self.name = name
    self.price = price
    self.deal_price = deal_price
    self.ratings = ratings
    self.you_save = price - deal_price

  def display_product_details(self):
      print("Product: {}".format(self.name))
      print("Price: {}".format(self.price))
      print("Deal Price: {}".format(self.deal_price))
      print("You Saved: {}".format(self.you_save))
      print("Ratings: {}".format(self.ratings))
   
  def get_deal_price(self):
    return self.deal_price

class ElectronicItem(Product):
   
  def display_product_details(self):
    super().display_product_details()    
    print("Warranty {} months".format(self.warranty_in_months))
    
  def set_warranty(self, warranty_in_months):
    self.warranty_in_months = warranty_in_months
    
  def get_warranty(self):
    return self.warranty_in_months

e = ElectronicItem("Laptop",45000, 40000,3.5)
e.set_warranty(10)
e.display_product_details()

Output:

Product: Laptop
Price: 45000
Deal Price: 40000
You Saved: 5000
Ratings: 3.5
Warranty 10 months

using __init__:
------------------

class Product:
  
    def __init__(self, name, price, deal_price, ratings):
       self.name = name
       self.price = price
       self.deal_price = deal_price
       self.ratings = ratings
       self.you_save = price - deal_price

    def display_product_details(self):
           print("Product: {}".format(self.name))
           print("Price: {}".format(self.price))
           print("Deal Price: {}".format(self.deal_price))
           print("You Saved: {}".format(self.you_save))
           print("Ratings: {}".format(self.ratings))
    
    def get_deal_price(self):
        return self.deal_price

class ElectronicItem(Product):
   def __init__(self,name,Price,deal_price,ratings,warranty_in_months):
       super().__init__(name,Price,deal_price,ratings)
       self.warranty_in_months = warranty_in_months
      
   
   def display_product_details(self):
        super().display_product_details()
        print("Warranty {} months".format(self.warranty_in_months))
       
class GroceryItem(Product):
   def __init__(self,name,Price,deal_price,ratings,expiry_date):
       super().__init__(name,Price,deal_price,ratings)
       self.expiry_date = expiry_date
      
    
        
    def display_grocery_item_details(self):
        self.display_product_details()
        print('Expiry Date: {}'.format(self.expiry_date))
    
   
class Order:
    def __init__(self, delivery_speed, delivery_address):
         self.items_in_cart = []
         self.delivery_speed = delivery_speed
         self.delivery_address = delivery_address 
         
    def add_item(self, product, quantity):
        self.items_in_cart.append((product, quantity))

    def display_order_details(self):
        for product, quantity in self.items_in_cart:
            product.display_product_details()
            print("Quantity: {}".format(quantity))
            print("")
          
    def display_total_bill(self):
        total_bill = 0
        for product, quantity in self.items_in_cart:
             price = product.get_deal_price() * quantity
             total_bill += price
        print("Total Bill: {}".format(total_bill))

milk = GroceryItem("Milk",40, 25, 3.5,'2024')


tv = ElectronicItem("TV",45000, 40000, 3.5,3)


order = Order("Prime Delivery", "Hyderabad")

order.add_item(milk, 2)
order.add_item(tv, 1)

order.display_order_details()
order.display_total_bill()

Coding Pratice-33:
-----------------------------

Truck:
-------------

class Car:
    def __init__(self, color, max_speed, acceleration, tyre_friction):
        self.color = color
        self.max_speed = max_speed
        self.acceleration = acceleration
        self.tyre_friction = tyre_friction
        self.is_engine_started = False
        self.current_speed = 0

    def start_engine(self):
        self.is_engine_started = True

    def stop_engine(self):
        self.is_engine_started = False

    def accelerate(self):
        if not self.is_engine_started:
            print("Car has not started yet")
        else:
            self.current_speed += self.acceleration
            if self.current_speed > self.max_speed:
                self.current_speed = self.max_speed

    def apply_brakes(self):
        self.current_speed -= self.tyre_friction
        if self.current_speed < 0:
            self.current_speed = 0

    def sound_horn(self):
        if self.is_engine_started:
            print("Beep Beep")
        else:
            print("Car has not started yet")

class Truck(Car):
    def __init__(self, color, max_speed, acceleration, tyre_friction, max_cargo_weight):
        super().__init__(color,max_speed,acceleration,tyre_friction)
        self.max_cargo_weight = max_cargo_weight
        self.load = 0

    def load_cargo(self,cargo_weight):
        if self.is_engine_started:
            print('Cannot load cargo during motion')
        elif cargo_weight + self.load > self.max_cargo_weight:
            print("Cannot load cargo more than max limit: {}".format(self.max_cargo_weight))
        else:
            self.load += cargo_weight

    def unload_cargo(self,cargo_weight):
        if self.is_engine_started:
            print('Cannot unload cargo during motion')
        else:
            self.load -= cargo_weight
            if self.load < 0:
                self.load = 0

    def sound_horn(self):
        if self.is_engine_started:
            print('Honk Honk')
        else:
            print('Car has not started yet')


# You need not change any code below.
# Do not call this function anywhere. It will automatically be called internally during tests.
def default_test():
    truck = Truck(color="Red", max_speed=250, acceleration=10, tyre_friction=3, max_cargo_weight=100)
    print(truck.is_engine_started)
    truck.load_cargo(cargo_weight=50)  # Loading cargo_weight 50 to the truck
    print(truck.load)  # 0 + 50 => 50
    truck.unload_cargo(cargo_weight=25)  # Unloading cargo_weight 25 from the truck
    print(truck.load)  # 50 - 25 => 25
    truck.unload_cargo(cargo_weight=70)  # Unloading cargo_weight 70 (more than load in the truck)
    print(truck.load)  # 25 - 75 => 0 as load never be negative
    truck.load_cargo(cargo_weight=120)  # Prints "Cannot load cargo more than max limit: 100"

    truck.load_cargo(cargo_weight=20)  # Loading cargo_weight 20 to the truck
    truck.start_engine()
    print(truck.is_engine_started)  # True
    truck.load_cargo(cargo_weight=40)  # Prints "Cannot load cargo during motion"
    truck.unload_cargo(cargo_weight=10)  # Prints "Cannot unload cargo during motion"

    truck.sound_horn()  # Prints "Honk Honk"
    truck.stop_engine()
    truck.sound_horn()  # Prints "Car has not started yet"

Output:

False
50
25
0
Cannot load cargo more than max limit: 100
True
Cannot load cargo during motion
Cannot unload cargo during motion
Honk Honk
Car has not started yet

RaceCar:
----------------


class Car:
    def __init__(self, color, max_speed, acceleration, tyre_friction):
        self.color = color
        self.max_speed = max_speed
        self.acceleration = acceleration
        self.tyre_friction = tyre_friction
        self.is_engine_started = False
        self.current_speed = 0

    def start_engine(self):
        self.is_engine_started = True

    def stop_engine(self):
        self.is_engine_started = False

    def accelerate(self):
        if not self.is_engine_started:
            print("Car has not started yet")
        else:
            self.current_speed += self.acceleration
            if self.current_speed > self.max_speed:
                self.current_speed = self.max_speed

    def apply_brakes(self):
        self.current_speed -= self.tyre_friction
        if self.current_speed < 0:
            self.current_speed = 0

    def sound_horn(self):
        if self.is_engine_started:
            print("Beep Beep")
        else:
            print("Car has not started yet")


class RaceCar(Car):
    def __init__(self, color, max_speed, acceleration, tyre_friction, nitro):
        super().__init__(color,max_speed,acceleration,tyre_friction)
        self.nitro = nitro

    def accelerate(self):
        if self.nitro > 0 and self.is_engine_started:
            self.current_speed += 20 
            self.nitro -= 1 
        super().accelerate()

    def sound_horn(self):
        if self.is_engine_started:
            print('Peep Peep\nBeep Beep')
        else:
            print('Car has not started yet')


# You need not change any code below.
# Do not call this function anywhere. It will automatically be called internally during tests.
def default_test():
    racecar = RaceCar(color="Red", max_speed=250, acceleration=50, tyre_friction=30, nitro=4)
    racecar.start_engine()
    racecar.accelerate()  # Calling the accelerate method when the is_engine_started is True
    print(racecar.current_speed)  # 0 + (50 + 20) => 70
    print(racecar.nitro)  # 4 - 1 => 3
    racecar.accelerate()  # 70 + (50 + 20) => 140
    print(racecar.current_speed)  # 140
    print(racecar.nitro)  # 3 - 1 => 2
    racecar.accelerate()  # 140 + (50 + 20) => 210
    print(racecar.current_speed)  # 210
    print(racecar.nitro)  # 2 - 1 => 1
    racecar.apply_brakes()  # 210 - 30 => 180
    print(racecar.current_speed)  # 180
    print(racecar.nitro)  # 1
    racecar.accelerate()  # 180 + (50 + 20) => 250
    print(racecar.current_speed)  # 250
    print(racecar.nitro)  # 1 - 1 => 0
    racecar.sound_horn()

Output:

70
3
140
2
210
1
180
1
250
0
Peep Peep
Beep Beep

E-commerce:
-------------------

class Product:


 def __init__(self, name, price, deal_price, ratings):
  self.name = name
  self.price = price
  self.deal_price = deal_price
  self.ratings = ratings
  self.you_save = price - deal_price


 def display_product_details(self):
   print("Product: {}".format(self.name))
   print("Price: {}".format(self.price))
   print("Deal Price: {}".format(self.deal_price))
   print("You Saved: {}".format(self.you_save))
   print("Ratings: {}".format(self.ratings))


 def get_deal_price(self):
   return self.deal_price


    
class ElectronicItem(Product):
  def __init__(self, name, price, deal_price, ratings, warranty_in_months):
    super().__init__(name, price, deal_price, ratings)
    self.warranty_in_months = warranty_in_months
    print("")


  def display_product_details(self):
    super().display_product_details()
    print('Warrant : {} months'. format(self.warranty_in_months))


class GroceryItem(Product):
  def __init__(self, name, price, deal_price, ratings, expiry_date):
    super().__init__(name, price, deal_price, ratings)
    self.expiry_date = expiry_date
    print("")


  def display_product_details(self):
    super().display_product_details()
    print('Expiry Date : {} '. format(self.expiry_date))


class Laptop(ElectronicItem):
  def __init__(self, name, price,deal_price,ratings,warranty_in_months,ram,storage):
    super().__init__(name, price,deal_price,ratings,warranty_in_months)
    self.ram = ram
    self.storage = storage


  def display_product_details(self):
    super().display_product_details()
    print('Ram : {}'.format(self.ram))
    print('Storage : {}'.format(self.storage))


class Order:
  delivery_charges = { 'Normal' : 10, 'Prime Delivery' : 100}


  def __init__(self,delivery_method, delivery_address):
    self.items_in_cart = []
    self.delivery_address = delivery_address
    self.delivery_method = delivery_method




  def add_item(self, product, quantity):
    item = (product, quantity)
    self.items_in_cart.append(item)


     
  def display_order_details(self):
    print('Delivery Method : {} '. format(self.delivery_method))
    print('Delivery Address : {} '. format(self.delivery_address))
    print('Products')
    print('---------------------------------------')
    for product,quantity in self.items_in_cart:
      product.display_product_details()
      print('Quantity : {} '. format(quantity))
      print("")
    print('----------------------------------------')
    total_bill = self.get_total_bill()
    print('Total Bill : {} '. format(total_bill))


      
  def get_total_bill(self):
    total_bill = 0
    for product, quantity in self.items_in_cart:
      total_bill = total_bill + product.get_deal_price() * quantity
    order_delivery_charges = Order.delivery_charges[self.delivery_method]
    total_bill = total_bill + order_delivery_charges
    return total_bill


  @classmethod
  def update_delivery_charges(cls, delivery_method, charges):
    cls.delivery_charges[delivery_method] = charges


P = Product('TV', 40000, 25000, 3.5)
p=P.display_product_details()

tv = ElectronicItem('Fridge', 25000, 15000, 4.5, 24)
tv.display_product_details()

Milk = GroceryItem('Milk', 40, 30, 4.5, 'Jan 2022')
Milk.display_product_details()

my_order = Order('Normal', 'Hyderabad')
my_order.add_item(tv,1)
my_order.add_item(Milk,3)
my_order.display_order_details()

Order.update_delivery_charges('Normal', 50)
my_order.display_order_details()

lenovo_lap = Laptop('Lenovo 123', 45000, 30000, 4.5, 24, '16 GB', '1 TB SSD')
lenovo_lap.display_product_details()

Output:

Product: TV
Price: 40000
Deal Price: 25000
You Saved: 15000
Ratings: 3.5

Product: Fridge
Price: 25000
Deal Price: 15000
You Saved: 10000
Ratings: 4.5
Warrant : 24 months

Product: Milk
Price: 40
Deal Price: 30
You Saved: 10
Ratings: 4.5
Expiry Date : Jan 2022 
Delivery Method : Normal 
Delivery Address : Hyderabad 
Products
---------------------------------------
Product: Fridge
Price: 25000
Deal Price: 15000
You Saved: 10000
Ratings: 4.5
Warrant : 24 months
Quantity : 1 

Product: Milk
Price: 40
Deal Price: 30
You Saved: 10
Ratings: 4.5
Expiry Date : Jan 2022 
Quantity : 3 

----------------------------------------
Total Bill : 15100 
Delivery Method : Normal 
Delivery Address : Hyderabad 
Products
---------------------------------------
Product: Fridge
Price: 25000
Deal Price: 15000
You Saved: 10000
Ratings: 4.5
Warrant : 24 months
Quantity : 1 

Product: Milk
Price: 40
Deal Price: 30
You Saved: 10
Ratings: 4.5
Expiry Date : Jan 2022 
Quantity : 3 

----------------------------------------
Total Bill : 15140 

Product: Lenovo 123
Price: 45000
Deal Price: 30000
You Saved: 15000
Ratings: 4.5
Warrant : 24 months
Ram : 16 GB
Storage : 1 TB SSD


Errors & Exceptions:
------------------------------------------

There are two major kinds of errors:   

Syntax Errors
Exceptions

Exceptions:
------------------

Even when a statement or expression is syntactically correct, it may cause an error when an attempt is made to execute it.   
Errors detected during execution are called exceptions.   

Example Scenario:

We wrote a program to download a Video over the Internet.  

1. Internet is disconnected during the download
2. We do not have space left on the device to download the video

Example 1:

Division Example
Input given by the user is not within expected values.  

Code:

def divide(a, b):  
    return  a / b  

divide(5, 0)

Output:

ZeroDivisionError: division by zero

Example 2:

  
def divide(a, b):  
    return  a / b  

divide("5", "10")

Output:

TypeError: unsupported operand type(s) for /: 'str' 

Example 3:

Consider the following code, which is used to update the quantity of items in store.  

Code:

class Store:  
    def __init__(self):  
        self.items = {  
        "milk" : 20, "bread" : 30, }  
    
    def add_item(self, name, quantity):  
       self.items[name] += quantity  
 
s = Store()  
s.add_item('biscuits', 10)

Output:

KeyError: 'biscuit'

Working With Exceptions:
-----------------------------------

class BankAccount:
    def __init__(self, account_number):
        self.account_number = str(account_number)
        self.balance = 0

    def get_balance(self):
        return self.balance

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
        else:
            print("Insufficient Funds")

    def deposit(self, amount):
        self.balance += amount


def transfer_amount(acc_1, acc_2, amount):
    acc_1.withdraw(amount)
    acc_2.deposit(amount)


user_1 = BankAccount("001")
user_2 = BankAccount("002")
user_1.deposit(250)
user_2.deposit(100)

print("User 1 Balance: {}/-".format(user_1.get_balance()))
print("User 2 Balance: {}/-".format(user_2.get_balance()))
transfer_amount(user_1, user_2, 50)
print("Transferring 50/- from User 1 to User 2")
print("User 1 Balance: {}/-".format(user_1.get_balance()))
print("User 2 Balance: {}/-".format(user_2.get_balance()))

Output:

User 1 Balance: 250/-
User 2 Balance: 100/-
Transferring 50/- from User 1 to User 2
User 1 Balance: 200/-
User 2 Balance: 100/-

Example 2

class BankAccount:
    def __init__(self, account_number):
        self.account_number = str(account_number)
        self.balance = 0

    def get_balance(self):
        return self.balance

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
        else:
            print("Insufficient Funds")

    def deposit(self, amount):
        self.balance += amount


def transfer_amount(acc_1, acc_2, amount):
    acc_1.withdraw(amount)
    acc_2.deposit(amount)


user_1 = BankAccount("001")
user_2 = BankAccount("002")
user_1.deposit(25)
user_2.deposit(100)

print("User 1 Balance: {}/-".format(user_1.get_balance()))
print("User 2 Balance: {}/-".format(user_2.get_balance()))
transfer_amount(user_1, user_2, 50)
print("Transferring 50/- from User 1 to User 2")
print("User 1 Balance: {}/-".format(user_1.get_balance()))
print("User 2 Balance: {}/-".format(user_2.get_balance()))

Output:

User 1 Balance: 25/-
User 2 Balance: 100/-
Insufficient Funds
Transferring 50/- from User 1 to User 2
User 1 Balance: 25/-
User 2 Balance: 150/-

Raising Exceptions:
------------------------------------------

When your code enters an unexpected state, raise an exception to communicate it.

raise ValueError("Unexpected Value!!")

Output:
  
ValueError:Unexpected Value!!

Example 1:

class BankAccount:
    def __init__(self, account_number):
        self.account_number = str(account_number)
        self.balance = 0

    def get_balance(self):
        return self.balance

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
        else:
            raise ValueError("Insufficient Funds")

    def deposit(self, amount):
        self.balance += amount


def transfer_amount(acc_1, acc_2, amount):
    acc_1.withdraw(amount)
    acc_2.deposit(amount)


user_1 = BankAccount("001")
user_2 = BankAccount("002")
user_1.deposit(25)
user_2.deposit(100)

print("User 1 Balance: {}/-".format(user_1.get_balance()))
print("User 2 Balance: {}/-".format(user_2.get_balance()))
transfer_amount(user_1, user_2, 50)
print("Transferring 50/- from User 1 to User 2")
print("User 1 Balance: {}/-".format(user_1.get_balance()))
print("User 2 Balance: {}/-".format(user_2.get_balance()))

Output:

User 1 Balance: 25/-
User 2 Balance: 100/-

ValueError: Insufficient Funds

Handling Exceptions:
---------------------------------

class BankAccount:
    def __init__(self, account_number):
        self.account_number = str(account_number)
        self.balance = 0

    def get_balance(self):
        return self.balance

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
        else:
            raise ValueError("Insufficient Funds")

    def deposit(self, amount):
        self.balance += amount


def transfer_amount(acc_1, acc_2, amount):  
    try:
        acc_1.withdraw(amount)
        acc_2.deposit(amount)
        return True
    except ValueError as e:
        print(str(e))  
        print(type(e))  
        print(e.args)  
        return False

user_1 = BankAccount("001")
user_2 = BankAccount("002")
user_1.deposit(25)
user_2.deposit(100)

print("User 1 Balance: {}/-".format(user_1.get_balance()))
print("User 2 Balance: {}/-".format(user_2.get_balance()))
print(transfer_amount(user_1, user_2, 50))
print("Transferring 50/- from User 1 to User 2")
print("User 1 Balance: {}/-".format(user_1.get_balance()))
print("User 2 Balance: {}/-".format(user_2.get_balance()))

Output:

User 1 Balance: 25/-
User 2 Balance: 100/-
Insufficient Funds
<class 'ValueError'>
('Insufficient Funds',)
False
Transferring 50/- from User 1 to User 2
User 1 Balance: 25/-
User 2 Balance: 100/-

telusuko (yt):
--------------------------

a = 5
b = 2

try:
    print("resource Open")
    print(a/b)
    k = int(input("Enter a number"))
    print(k)

except ZeroDivisionError as e:
    print("Hey, You cannot divide a Number by Zero" , e)

except ValueError as e:
    print("Invalid Input")

except Exception as e:
    print("Something went Wrong...")

finally:
    print("resource Closed")
    
------------

try:
    a,b = input().split()
    a = int(a)  
    b = int(b)  
    c = a/b
    print(c)  
except ZeroDivisionError:  
    print("Denominator can't be 0")  
except ValueError:  
    print("Input should be an integer")
    
Input:

12 a 

Output:

Input should be an integer
    
    
Formatting Datetime:
--------------------------

from datetime import datetime

now = datetime.now()
formatted_datetime_1 = now.strftime("%d %b %Y %I:%M:%S %p")
print(formatted_datetime_1)

formatted_datetime_2 = now.strftime("%d/%m/%Y, %H:%M:%S")
print(formatted_datetime_2)

Output:

05 Feb 2021 09:26:50 AM
05/02/2021, 09:26:50

Parsing Datetime:
----------------------------------

The class method strptime() creates a datetime object from a given string representing date and time.

Code:

from datetime import datetime

date_string = "28 November, 2018"
print(date_string)

date_object = datetime.strptime(date_string, "%d %B, %Y")
print(date_object)

Output:

28 November, 2018
2018-11-28 00:00:00

Coding pratice-34:
------------------------------

Parsing Datetime:
-----------------------------

from datetime import datetime

date_string = input()

date_object = datetime.strptime(date_string, "%d %b %Y")
print(date_object)

Input:

2 Jul 2000

Output:

2000-07-02 00:00:00

Formatting Datetime:
-------------------------------

from datetime import datetime

dt_format = '%b %d %Y %I:%M%p'
dt_object = datetime.strptime(input(), dt_format)
print(dt_object)

output_format = datetime.strftime(dt_object, '%d/%m/%Y %H:%M:%S')
print(output_format)

Input:

Jul 01 2014 02:43PM

Output:

2014-07-01 14:43:00
01/07/2014 14:43:00

Print Dates:
---------------------------

from datetime import datetime, timedelta

date = input()
date_string = '%d %b %Y'
today = datetime.strptime(date, date_string)

yes = today - timedelta(days = 1)
next_day = today + timedelta(days = 1)

print(yes)
print(today)
print(next_day)

Input:

26 Jan 2021

Output:

2021-01-25 00:00:00
2021-01-26 00:00:00
2021-01-27 00:00:00

Add Years:
-----------------

from datetime import datetime,timedelta

# string to datetime
date_time_string = input()
n = int(input())
date_object = datetime.strptime(date_time_string, '%b %d %Y' )

d_2 = date_object + timedelta(days = n*365)
print(d_2)

Input:

Jul 11 2014
5

Output:

2019-07-10 00:00:00

List of dates:
---------------------------------------

from datetime import datetime,timedelta

start_dt_string = input()
end_dt_string = input()

start_dt = datetime.strptime(start_dt_string, '%b %d %Y' )
end_dt = datetime.strptime(end_dt_string, '%b %d %Y' )

number_of_days = (end_dt - start_dt).days
for i in range(number_of_days+1):
    print(start_dt + timedelta(days=i))
    
Input:

Jul 11 2014
Jul 19 2014

Output:

2014-07-11 00:00:00
2014-07-12 00:00:00
2014-07-13 00:00:00
2014-07-14 00:00:00
2014-07-15 00:00:00
2014-07-16 00:00:00
2014-07-17 00:00:00
2014-07-18 00:00:00
2014-07-19 00:00:00

Name of the weekday:
----------------------------------

from datetime import datetime

date = input()
date_string = '%d %b %Y'
datetime_object = datetime.strptime(date,date_string)
name_of_day = datetime_object.strftime('%A')
print(name_of_day)

Input:

2 Jul 2000

Output:

Sunday

Count of mondays:
-----------------------------------------

from datetime import datetime

A,B=input().split()
monday=0
months=range(1,13)

for year in range(int(A),int(B)+1):
  for month in months:
    dt_object=datetime(year,month,1)
    day=datetime.strftime(dt_object,"%A")
    if day=="Monday":
      monday=monday+1
print(monday)       

Input:

2015 2017

Output:

4
    
UNIX Timestamp to datetime:
---------------------------------------------

import datetime

zero = datetime.datetime(1970,1,1)
seconds = datetime.timedelta(seconds = int(input()))
dt_format = "%Y-%m-%d %H:%M:%S"
result_time = zero + seconds

print(result_time.strftime(dt_format))

Input:

1284105682

Output:

2010-09-10 08:01:22

Item:
--------------

class Item:
    def __init__(self, name, price, category):
        if price <= 0:
            raise ValueError("Invalid value for price, got {}".format(price))
        self.name = name
        self.price = price
        self.category =category

    def get_detail(self):
        return "{}@{}-{}".format(self.name, self.price, self.category)


# You need not change any code below.
# Do not call this function anywhere. It will automatically be called internally during tests.
def default_test():
    item = Item(name="Oreo Biscuits", price=30, category="Food")
    print(item.name)  # prints "Oreo Biscuits"
    print(item.price)  # prints '30'
    print(item.category)  # prints "Food"
    print(item.get_detail())  # prints "Oreo Biscuits@30-Food"

Output:

Oreo Biscuits
30
Food
Oreo Biscuits@30-Food

Coding pratice-35:
-----------------------------

Max contiguous subarray:
-----------------------------------

a=list(map(int,input().split()))

if not a:
    print(0)
else:
    sum_dict={} 
    for i in range(len(a)):
        for j in range(i+1,len(a)+1):
            sum_dict[tuple(a[i:j])]=sum(a[i:j])
    keys=list(sum_dict.keys())
    values=list(sum_dict.values())
    max_sum=values.index(max(values))
    print(*keys[max_sum])
    
Input:

2 -4 5 -1 2 -3

Output:

5 -1 2

Two words combination:
----------------------------------------

def genarate_2_combinations(words):
    
    words = sorted(words)
    items = list(range(len(words)))
    combinations_1 = []
    for item in items:
        combinations_1.append([item])
        print(combinations_1)
    
    combinations_2 = []
    for combination in combinations_1:
        for item in items:
            if item > combination[-1]:
                combinations_2.append(combination + [item])
                print(combinations_2)
                
    word_combinations = []
    for combination in combinations_2:
        word_combination = []
        for index in combination:
            word_combination.append(words[index])
        word_combinations.append(tuple(word_combination))
    return sorted(set(word_combinations))
    
words = input().split()
all_combinations = genarate_2_combinations(words)
for combination in all_combinations:
    print(' '.join(combination))
    
Input:

raju plays cricket

Output:

[[0]]
[[0], [1]]
[[0], [1], [2]]
[[0, 1]]
[[0, 1], [0, 2]]
[[0, 1], [0, 2], [1, 2]]
cricket plays
cricket raju
plays raju

N words combination:
-------------------------------

def all_unique_combinations(words,n):
    words = sorted(words)
    items = list(range(len(words)))
    old_combinations = [[]]
    new_combinations = []
    for i in range(n):
        new_combinations = []
        for combination in old_combinations:
            for item in items:
                if (combination and item > combination[-1]) or len(combination) == 0:
                    new_combinations.append(combination + [item])
            old_combinations = new_combinations
    
    word_combinations = []
    for combination in new_combinations:
        word_combination = []
        for index in combination:
            word_combination.append(words[index])
        word_combinations.append(tuple(word_combination))
    return sorted(set(word_combinations))    
    
words = input().split()
n = int(input())
all_combinations = all_unique_combinations(words,n)
for combination in all_combinations:
    print(' '.join(combination))
    
Input:

apple is a fruit
3

Output:

a apple fruit
a apple is
a fruit is
apple fruit is

Explaination:

We need to print all the unique combinations of N words in lexicographical order.

For example, if the given sentence is 

raju plays cricket 

The possible N(i.e.,2) unique combinations are (cricket, plays), (cricket, raju), (plays, raju).

So the output should be

cricket plays
cricket raju
plays raju


Code Explanation:

Firstly read the input

words = input().split() # input = raju plays cricket
n = int(input()) # Number of combinations i.e.,N﻿
all_combinations = all_unique_combinations(words, n)
After the calling of function, we will sort the words in the given sentence by using the sorted() method. 
After sorting the words we will get the sorted list without containing any duplicates. 

words = sorted(words) # which gives you the List of sorted words
After that, we will calculate the range of words 

items = list(range(len(words))) # which will gives the list of ranges i.e [0, 1, 2] where the length of the word is 3
Here, we are initializing one nested list i.e.,old_combinations and one list new_combinations as given below to store the combinations to these lists

old_combinations = [[]]
new_combinations = []


Now append the combinations into the empty list new_combinations by using the below code snippet

for i in range(n):
    new_combinations = []
    for combination in old_combinations:
        for item in items:
            if (combination and item > combination[-1]) or len(combination) == 0:
                new_combinations.append(combination + [item])
        old_combinations = new_combinations
items = [0, 1, 2]

First iteration of outer for loop:

old_combinations = [[]]

new_combinations = []

First iteration of combination for loop:

combination = []

First iteration of item for loop:

item = 0

if (combination and item > combination[-1]) or len(combination) == 0: ---> if ([] and 0 > combination[-1]) or 0 == 0: ---> if [] or True:

The if condition satisfies and the if block executes

new_combinations.append(combination + [item]) ---> new_combinations.append([] + [0]) ---> new_combinations = [[0]]

Second iteration of item for loop:

item = 1

if (combination and item > combination[-1]) or len(combination) == 0: ---> if ([] and 1 > combination[-1]) or 0 == 0: ---> if [] or True:

The if condition satisfies and the if block executes

new_combinations.append(combination + [item]) ---> new_combinations.append([] + [1]) ---> new_combinations = [[1]]

Similarly for the iteration item = 2

After all the iterations of the item for loop

old_combinations = [[0], [1], [2]]

Second iteration of combination for loop:

combination = [0]

First iteration of item for loop:

item = 0

if (combination and item > combination[-1]) or len(combination) == 0: ---> if ([0] and 0 > 0) or 1 == 0: ---> if False or False:

The if condition fails and the if block does not executes

Second iteration of item for loop:

item = 1

if (combination and item > combination[-1]) or len(combination) == 0: ---> if ([0] and 1 > 0) or 1 == 0: ---> if (1 > 0 ) or False ---> if True or False:

The if condition satisfies and the if block executes

new_combinations.append(combination + [item]) ---> new_combinations.append([0] + [1]) ---> new_combinations = [[0, 1]]

Similarly for the iteration item = 2

After all the iterations of the item for loop

old_combinations = [[0, 1], [0, 2]]

After all the iterations of outer for loop

new_combinations = [[0, 1], [0, 2], [1, 2]] 

In the above lines of code we made the N Combinations of range 3. Now we have to form the N Words Combinations by using the obtained combinations(i.e.,new_combinations)of numbers. We use below code to N Words Combinations

word_combinations = []
for combination in new_combinations:
    word_combination = []
    for index in combination:
        word_combination.append(words[index])
    word_combinations.append(tuple(word_combination))
return sorted(set(word_combinations))
Inner for loop:

In the inner for loop we are appending the words from the list words to the word_combination list by using the index values obtained in 
the previous code i.e.,new_combinations and after all the iterations of inner for loop we are appending the word_combination list to the 
list word_combinations.

Outer for loop:

The outer for loop is used to iterate the combinations present in the new_combinations list. 
For every iteration we are appending the word_combination list obtained in the inner for loop as a tuple to the list word_combinations.



After all the iterations of outer for loop,

word_combinations = [('cricket', 'plays'), ('cricket', 'raju'), ('plays', 'raju')] 



Now we are converting the obtained list i.e.,word_combinations into set and then sorting the resultant set by using sorted() function. Finally returning the sorted list with N Words Combinations.



Finally we are printing the all_combinations by using for loop

for combination in all_combinations:
    print(' '.join(combination))
    

Foundation Exam-3:
-------------------------------------

First and Last digit:
---------------------------------

n = int(input())
m = int(input())
count = len([1 for item in range(n,m+1) if str(item)[0] == str(item)[-1]])
print ('The quanity of numbers with the same first and last digit:', count)

Input:

5
30

Output:

7

Interleave Strings:
-----------------------------


s1 = input()
s2 = input()

n = min(len(s1), len(s2))
res = ''
for i in range(n):
    res += s1[i] + s2[i]
if n < len(s1):
    res += s1[n:]
else:
    res += s2[n:]

print(res)

Input:

abc
pqr

Output:

apbqcr

Elements of Anti Diagonal:
-----------------------------------

n = int(input())
a = []
for i in range(n):
    b = list(map(int, input().split()))
    a.append(b[n - 1 - i])
            
print(a)

Input:

3
1 2 3
4 5 6
7 8 9

Output:

[3, 5, 7]

Max Contiguous Subarray:
----------------------------------

numbers = [int(item) for item in input().split()]
maxSum = 0
maxTemp = 0
for i in range(0, len(numbers)):
    maxTemp += numbers[i]
    if maxTemp < 0:
        maxTemp = 0
    elif (maxSum < maxTemp):
        maxSum = maxTemp
print(f'{maxSum}')

Input:

2 -4 5 -1 2 -3

Output:

6

Area of square:
---------------------------------

def square_area(matrix, l_x, l_y, side_length):
    count = 0
    for i in range(l_x, l_x+side_length):
        for j in range(l_y, l_y+side_length):
            if matrix[i][j] == 1:
                count += 1 
            else:
                return 0
    return count
    
m,n = map(int,input().split())
markers = {'X' : 1, 'O' : 0}
matrix = [[markers[i] for i in input().split()] for _ in range(m)]

areas = []

for l_x in range(m):
    for l_y in range(n):
        for side_length in range(1, min(n - l_y+1,m - l_x+1)):
            areas.append(square_area(matrix, l_x, l_y, side_length))
        
        
print(max(areas))

Input:

4 5
X O X O O
X O X X X
X X O X X
X O O X O

Output:

4

Foundation Exam -4:
-------------------------------------

rotate words longer than given length L by K letters:
---------------------------------------------------------------------

sentences = input('Enter string: ')
L, K = [int(i) for i in input().split()]
source = [i for i in sentences.split()] 


result = []
def rotate(strings, k):
    for i in range(k):
        c = strings[-1]
        strings = strings[0:-1]
        c += strings
        strings = c
    return strings


for cha in source:
    if len(cha) > L:
        result.append(rotate(cha, K))
    else:
        result.append(cha)
final = result[0]


for cha in result[1:]:
    final += ' '
    final += cha


print(final)