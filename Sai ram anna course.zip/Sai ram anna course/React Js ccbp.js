View and change CSS:
https://developer.chrome.com/docs/devtools/css/

View logged messages in the console:
https://developer.chrome.com/docs/devtools/console/log/#javascript

Run JavaScript in the console:
https://developer.chrome.com/docs/devtools/console/javascript/

Check the responsiveness of an application, etc:
https://developer.chrome.com/docs/devtools/device-mode/#viewport

react icons:
https://react-icons.github.io/react-icons/

React Developer Tools
For React Developer Tools, we can install the React Developer Tools Extension for Google Chrome.

https://chrome.google.com/webstore/detail/react-developer-tools/fmkadmapgofadopljbjfkapdkoienihi?hl=en

https://reactjsexample.com/password-manager-app-for-react/
https://github.com/Pavan-Kiran-Chidirala/reactpasswordmanagerappjs

for installing third party packages:
https://www.npmjs.com/
	- sort packages based on popularity(No of stars).
	- Go through description . check whether the package is suitable for project or not.
	- Things to Consider
		- Users Satisfaction
		- Popularity (number of stars)
		- Maintenance
		- Documentation
		- Number of unresolved issues
https://www.npmjs.com/package/react-player
	- charts, dates, graphs, React chrono, popups, slick, Material UI.
	
https://github.com/recharts/recharts
https://recharts.org/en-US/

https://www.npmjs.com/package/react-chrono

https://react-slick.neostack.com/docs/get-started/

https://react-popup.elazizi.com/component-api/
	
---------------------

https://reactjsexample.com/a-match-game-built-with-react-js/
https://github.com/Pavan-Kiran-Chidirala/reactmatchgameappjs

--------------------------

https://github.com/ManirathnamKuruma/ -- for all codes

https://github.com/harsha3072 -- most correct


https://github.com/pradeep-coding/browser_history

https://styled-components.com/
https://styled-components.com/docs/tooling
https://styled-components.com/docs/api#helpers
https://styled-components.com/docs/basics#extending-styles

---------------------------------------------------------------------------------------

youtube:
--------------


https://reactjs.org/docs/hooks-overview.html -- useState hook it is similar to this.setState.

https://getbootstrap.com/

https://console.firebase.google.com/?pli=1


Introduction to React JS | Cheat Sheet:
-----------------------------------------------------------------------

Concepts in Focus:

React JS:
	Why React JS?
	Advantages of React JS

Running JavaSript in HTML

Creating Elements using React JS:
	React CDN
	React.createElement()
	ReactDOM.render()

JSX:
	Babel
	Embedding Variables and Expressions in JSX
	Nesting JSX elements
	
1. React JS
React JS is an open-source JavaScript library used to build user interfaces. It was developed by Facebook.

1.1 Why React JS?

Performant websites
Fewer lines of code
Improves readability of code
Less time consuming
Open Source
Reusable code

1.2 Advantages of React JS

Easy to Learn
Large Community
Developer Toolset

2. Running JavaScript in HTML
We can run JavaScript in HTML using the HTML script element. It is used to include JavaScript in HTML.

HTML:

<body>
  <div id="root"></div>
  <script type="text/javascript">
    const rootElement = document.getElementById("root");
    const element = document.createElement("h1");
    element.textContent = "Hello World!";
    element.classList.add("greeting");
    rootElement.appendChild(element);
  </script>
</body>

Here the type attribute specifies the type of the script.

To include an external JavaScript file, we can use the HTML script element with the attribute src. The src attribute specifies the path of an external JS file.

HTML:

<script type="text/javascript" src="PATH_TO_JS_FILE.js"></script>

Note:
When the browser comes across a script element while loading the HTML, it must wait for the script to download, execute it, and only then can it process the rest of the page.

So, we need to put a script element at the bottom of the page. Then the browser can see elements above it and doesn’t block the page content from showing.

If more than one script elements are in the HTML, the script elements will be executed in the order they appear.

3. Creating Elements using React JS

3.1 React CDN

<script src="https://unpkg.com/react@17.0.0/umd/react.development.js"></script>
<script src="https://unpkg.com/react-dom@17.0.0/umd/react-dom.development.js"></script>
<script src="https://unpkg.com/@babel/standalone@7.12.4/babel.js"></script>

3.2 React.createElement()
The React.createElement() method is used to create an element using React JS. It is similar to the document.createElement() method in regular JavaScript.

Syntax:

React.createElement(type, props);

type - Tag names like div, h1 and p, etc.
props - Properties like className, onClick and id, etc.

Props are shorthand for properties. It is an optional argument.

HTML:

<script type="module">
  const elementProps = { className: "greeting", children: "Hello world!" };
  const elementType = "h1";
  const element = React.createElement(elementType, elementProps);
</script>

Note
The type attribute value of the HTML script element should be module to run React JS.

3.3 ReactDOM.render()
The ReactDOM.render() method is used to display the React element.

Syntax:

ReactDOM.render(reactElement, container);

reactElement - What to render
container - Where to render

HTML:

<body>
  <div id="root"></div>
  <script type="module">
    const elementProps = { className: "greeting", children: "Hello world!" };
    const elementType = "h1";
    const element = React.createElement(elementType, elementProps);
    ReactDOM.render(element, document.getElementById("root"));
  </script>
</body>

4. JSX
React JS introduced a new HTML like syntax named JSX to create elements.

JSX:

const element = <h1 className="greeting">Hello World</h1>;

The above JSX element compiles to,

JS:

const elementProps = { className: "greeting", children: "Hello world!" };
const element = React.createElement("h1", elementProps);

Warning
In JSX, HTML tags always need to be closed. For example, <br />, <img />.

4.1 Babel
JSX is not JavaScript. We have to convert it to JavaScript using a code compiler. Babel is one such tool.

It is a JavaScript compiler that translates JSX into regular JavaScript.

HTML:

<script type="text/babel">
  const elementProps = { className: "greeting", children: "Hello world!" };
  const element = React.createElement("h1", elementProps);
  const element = <h1 className="greeting">Hello World</h1>;
  ReactDOM.render(element, document.getElementById("root"));
</script>

Note
For JSX, the type attribute value of the HTML script element should be text/babel.
For providing class names in JSX, the attribute name should be className.

Differences between HTML and JSX:

HTML	JSX
class	className
for		htmlFor

4.2 Embedding Variables and Expressions in JSX
We can embed the variables and expressions using the flower brackets {}.

Embedding variables in JSX:

HTML:

<body>
  <div id="root"></div>
  <script type="text/babel">
    const name = "Rahul";
    const className = "greeting";
    const element = <h1 className="greeting">Hello World</h1>;
    const element = <h1 className={className}>Hello {name}!</h1>;
    ReactDOM.render(element, document.getElementById("root"));
  </script>
</body>

Embedding Expressions in JSX:

HTML:

<body>
  <div id="root"></div>
  <script type="text/babel">
    const fullName = (user) => user.firstName + " " + user.lastName;
    const user = { firstName: "Rahul ", lastName: "Attuluri" };
    const element = <h1 className="greeting"> Hello, {fullName(user)}!</h1>;
    ReactDOM.render(element, document.getElementById("root"));
  </script>
</body>

4.3 Nesting JSX elements
The ReactDOM.render() method returns only one element in render. So, we need to wrap the element in parenthesis when writing the nested elements.

<body>
  <script type="text/babel">
    const element = (
      <div>
        <h1 className="greeting">Hello!</h1>
        <p>Good to see you here.</p>
      </div>
    );
    ReactDOM.render(element, document.getElementById("root"));
  </script>
</body>

coding pratice-1:
-------------------------------------------------------------------

Super Over League:
----------------------------------

https://github.com/ManirathnamKuruma/ReactJS-SuperOverLeague

index.html:

<!DOCTYPE html>
<html lang="en">
  <head>
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;1,100;1,300;1,400;1,500;1,700&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="index.css" />
    <script src="https://unpkg.com/react@17.0.0/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@17.0.0/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone@7.12.4/babel.js"></script>
  </head>
  <body>
    <div id="root"></div>
    <script type="text/babel" src="./index.js"></script>
  </body>
</html>

index.js:

const element = (
//   Write your code here.

const element = (
  <div className="super-over-league-container">
    <h1 className="heading">Super Over League</h1>
    <div className="teams-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/rcb-img.png"
        className="logo-image"
      />
      <img
        src="https://assets.ccbp.in/frontend/react-js/csk-img.png"
        className="logo-image"
      />
    </div>
  </div>
)

ReactDOM.render(element, document.getElementById('root'))

)

index.css:

/* Write your code here. */

* {
  box-sizing: border-box;
}

body {
  margin: 0px;
}

.super-over-league-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #0f172a;
  min-height: 100vh;
}

.heading {
  color: #f8fafc;
  font-family: "Roboto";
  font-size: 32px;
  font-weight: 700;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 64px;
  }
}

.logo-image {
  width: 150px;
  height: 150px;
}

@media screen and (min-width: 768px) {
  .logo-image {
    width: 300px;
    height: 300px;
  }
}

congrats card:
--------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-CongratsCardApp

index.html:

<!DOCTYPE html>
<html lang="en">
  <head>
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="index.css" />
    <script src="https://unpkg.com/react@17.0.0/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@17.0.0/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone@7.12.4/babel.js"></script>
  </head>
  <body>
    <div id="root"></div>
    <script type="text/babel" src="./index.js"></script>
  </body>
</html>

index.js:

const element = (
  <div className="congrats-card-container">
    <h1 className="heading">Congratulations</h1>
    <div className="card">
      <img
        src="https://assets.ccbp.in/frontend/react-js/congrats-card-profile-img.png"
        className="profile-image"
      />
      <h1 className="card-title">Kiran V</h1>
      <p className="card-description">
        Vishnu Institute of Computer Education and Technology, Bhimavaram
      </p>
      <img
        src="https://assets.ccbp.in/frontend/react-js/congrats-card-watch-img.png"
        className="watch-image"
      />
    </div>
  </div>
)

ReactDOM.render(element, document.getElementById('root'))

index.css:

* {
  box-sizing: 0px;
}

body {
  margin: 0px;
}

.congrats-card-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-image: url('https://assets.ccbp.in/frontend/react-js/congrats-card-bg.png');
  background-size: cover;
  min-height: 100vh;
}

.heading {
  color: #0f172a;
  font-family: 'Roboto';
  font-weight: 500;
  font-size: 32px;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 64px;
  }
}

.card {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #cffafe;
  width: 80%;
  border-radius: 12px;
  padding: 24px;
  margin-top: 18px;
}

@media screen and (min-width: 768px) {
  .card {
    width: 50%;
    padding: 48px;
    margin-top: 24px;
  }
}

@media screen and (min-width: 992px) {
  .card {
    width: 40%;
  }
}

@media screen and (min-width: 1200px) {
  .card {
    width: 30%;
  }
}

.profile-image {
  width: 145px;
  height: 145px;
}

.card-title {
  color: #1e293b;
  font-family: 'Roboto';
  font-weight: 500;
  font-size: 24px;
  margin-top: 24px;
}

@media screen and (min-width: 768px) {
  .card-title {
    font-size: 32px;
  }
}

.card-description {
  text-align: center;
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 14px;
}

@media screen and (min-width: 768px) {
  .card-description {
    font-size: 18px;
  }
}

.watch-image {
  margin-top: 24px;
}

Components & Props | Cheat Sheet:
-----------------------------------------------------------------------

Concepts in Focus:

Component:
	Properties (Props)
	Component is Reusable
	Component is Composable
	
Third-party Packages:
	create-react-app
	Pre-Configured tools
	
1. Component
A Component is a JS function that returns a JSX element.

JSX:

const Welcome = () => <h1 className="message">Hello, User</h1>;

The component name should always start with a capital letter as react treats the components starting with lowercase letters as HTML elements.

HTML:

<script type="text/babel">
  const Welcome = () => <h1 className="message">Hello, User</h1>;
  ReactDOM.render(<Welcome />, document.getElementById("root"));
</script>

We can call the function with self-closing tags as shown above <Welcome />.

1.1 Properties (Props)
React allows us to pass information to a component using props.

1.1.1 Passing Props
We can pass props to any component as we declare attributes for any HTML element.

Syntax:

JSX:

<Component propName1="propValue1" propName2="propValue2" />

JSX:

const Welcome = () => <h1 className="message">Hello, User</h1>;

ReactDOM.render(
  <Welcome name="Rahul" greeting="Hello" />,
  document.getElementById("root")
);

1.1.2 Accessing Props
The components accept props as parameters and can be accessed directly.

Syntax:

const Component = (props) => {
  // We can access props here
};

JSX:

const Welcome = (props) => {
  const { name, greeting } = props;
  return (
    <h1 className="message">
      {greeting}, {name}
    </h1>
  );
};

ReactDOM.render(
  <Welcome name="Rahul" greeting="Hello" />,
  document.getElementById("root")
);

1.2 Component is Reusable
A Component is a piece of reusable code that can be used in various parts of an application.

Example:

JSX:

const Welcome = (props) => {
  const { name, greeting } = props;
  return (
    <h1 className="message">
      {greeting}, {name}
    </h1>
  );
};

ReactDOM.render(
  <div>
    <Welcome name="Rahul" greeting="Hello" />
    <Welcome name="Ram" greeting="Hi" />
  </div>,
  document.getElementById("root")
);

1.3 Component is Composable
We can include a component inside another component.

const Welcome = (props) => {
  const { name, greeting } = props;
  return (
    <h1 className="message">
      {greeting}, {name}
    </h1>
  );
};
const Greetings = () => (
  <div>
    <Welcome name="Rahul" greeting="Hello" />
    <Welcome name="Ram" greeting="Hi" />
  </div>
);

ReactDOM.render(<Greetings />, document.getElementById("root"));

2. Third-party Packages
Creating a real-world app involves lot of setup because a large number of components need to be organised.

Facebook has created a third-party package, create-react-app, to generate a ready-made React application setup.

2.1 create-react-app
Installation Command:

npm install -g create-react-app

It installs create-react-app globally in our environment.

2.1.1 Creating a React Application

create-react-app myapp --use-npm

2.1.2 React Application Folder Structure

public/folder: Where we will keep assets like images, icons, videos etc
src/folder: Where we will do the majority of our work. All of our React components will placed here.
node_modules
package-lock.json
node_modules:

This directory contains dependencies and sub-dependencies of packages used by the current react app, as specified by package.json.

package-lock.json:

This file contains the exact dependency tree installed in node_modules. This provides a way to ensure every team member have the same version of dependencies and sub-dependencies.

The index.js in the path src/folder/ is a starting point to the application. App.js, App.css are imported in this file.

2.1.3 Starting a React Application
Run the below command from the React application directory.

npm start

You can view the application in the URL http://localhost:3000 in your browser.

Note
All the ES6 Modules should be named with .js extension.

2.2 Pre-Configured tools
The create-react-app comes pre-configured with:

Live editing: Allows React components to be live reloaded.
ESLint: Analyzes source code to report programming errors, bugs, and syntax errors.
Prettier: Enforces a consistent style for indentation, spacing, semicolons and quotes, etc.
Babel: Compiles JSX into Regular JavaScript
Webpack: Stitches together a group of modules into a single file (or group of files). This process is called Bundling.

coding pratice-2:
-------------------------------------------------------

Social Buttons:
----------------------

https://github.com/ManirathnamKuruma/ReactJS-SocialButtons

index.html:

<!DOCTYPE html>
<html lang="en">
  <head>
    <link
      href="https://fonts.googleapis.com/css2?family=Bree+Serif&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="index.css" />
    <script src="https://unpkg.com/react@17.0.0/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@17.0.0/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone@7.12.4/babel.js"></script>
  </head>
  <body>
    <div id="root"></div>
    <script type="text/babel" src="./index.js"></script>
  </body>
</html>

index.js:

const Button = (props) => {
  const { className, buttonText } = props;

  return <button className={`button ${className}`}>{buttonText}</button>;
};

const element = (
  <div className="social-buttons-container">
    <div className="content-container">
      <h1 className="heading">Social Buttons</h1>
      <div className="buttons-container">
        <Button buttonText="Like" className="like-button" />
        <Button buttonText="Comment" className="comment-button" />
        <Button buttonText="Share" className="share-button" />
      </div>
    </div>
  </div>
);

ReactDOM.render(element, document.getElementById("root"));

index.css:

* {
  box-sizing: border-box;
}

body {
  margin: 0px;
}

.social-buttons-container {
  display: flex;
  justify-content: center;
  background-image: url("https://assets.ccbp.in/frontend/react-js/social-buttons-bg.png");
  background-size: cover;
  min-height: 100vh;
}

.content-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 80%;
  max-width: 700px;
}

@media screen and (min-width: 768px) {
  .content-container {
    width: 60%;
  }
}

@media screen and (min-width: 992px) {
  .content-container {
    width: 50%;
  }
}

.heading {
  color: #ffffff;
  font-family: "Bree Serif";
  font-size: 32px;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 64px;
  }
}

.buttons-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

@media screen and (min-width: 768px) {
  .buttons-container {
    flex-direction: row;
  }
}

.button {
  font-family: "Roboto";
  font-size: 14px;
  font-weight: 500;
  border: none;
  border-radius: 12px;
  height: 40px;
  margin-top: 16px;
  margin-bottom: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-left: 24px;
  padding-right: 24px;
}

@media screen and (min-width: 768px) {
  .button {
    margin-top: 0px;
    margin-bottom: 0px;
    margin-left: 16px;
    margin-right: 16px;
  }
}

.like-button {
  color: #ffffff;
  background-color: #eab308;
}

.comment-button {
  color: #323f4b;
  background-color: #ffffff;
}

.share-button {
  color: #ffffff;
  background-color: #1d4ed8;
}

Notifications:
----------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-Notifications

index.html:

<!DOCTYPE html>
<html lang="en">
  <head>
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;1,100;1,300;1,400;1,500;1,700&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="index.css" />
    <script src="https://unpkg.com/react@17.0.0/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@17.0.0/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone@7.12.4/babel.js"></script>
  </head>
  <body>
    <div id="root"></div>
    <script type="text/babel" src="./index.js"></script>
  </body>
</html>

index.js:

const Notification = (props) => {
  const { className, iconUrl, message } = props;
  const containerClassName = `notification-container ${className}`;

  return (
    <div className={containerClassName}>
      <img className="icon" src={iconUrl} />
      <p className="message">{message}</p>
    </div>
  );
};

const element = (
  <div className="notifications-app-container">
    <h1 className="title">Notifications</h1>
    <div className="notifications-list-container">
      <Notification
        className="primary-bg-color"
        iconUrl="https://assets.ccbp.in/frontend/react-js/primary-icon-img.png"
        message="Information Message"
      />
      <Notification
        className="success-bg-color"
        iconUrl="https://assets.ccbp.in/frontend/react-js/success-icon-img.png"
        message="Success Message"
      />
      <Notification
        className="warning-bg-color"
        iconUrl="https://assets.ccbp.in/frontend/react-js/warning-icon-img.png"
        message="Warning Message"
      />
      <Notification
        className="danger-bg-color"
        iconUrl="https://assets.ccbp.in/frontend/react-js/danger-icon-img.png"
        message="Error Message"
      />
    </div>
  </div>
);

ReactDOM.render(element, document.getElementById("root"));

index.css:

* {
  box-sizing: border-box;
}

body {
  margin: 0;
}

.notifications-app-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

.title {
  color: #0f172a;
  font-family: "Roboto";
  font-size: 32px;
  font-weight: bold;
  margin-bottom: 48px;
}

@media screen and (min-width: 768px) {
  .title {
    font-size: 48px;
  }
}

.notifications-list-container {
  display: flex;
  flex-direction: column;
  width: 80%;
  max-width: 500px;
}

@media screen and (min-width: 768px) {
  .notifications-list-container {
    width: 60%;
  }
}

.notification-container {
  display: flex;
  align-items: center;
  border-radius: 4px;
  margin-bottom: 32px;
  padding-top: 12px;
  padding-right: 8px;
  padding-bottom: 12px;
  padding-left: 18px;
}

@media screen and (min-width: 768px) {
  .notification-container {
    margin-bottom: 48px;
    padding-top: 16px;
    padding-right: 12px;
    padding-bottom: 16px;
    padding-left: 24px;
  }
}

.primary-bg-color {
  background-color: #0b69ff;
}

.success-bg-color {
  background-color: #2dca73;
}

.warning-bg-color {
  background-color: #ffb800;
}

.danger-bg-color {
  background-color: #ff0b37;
}

.icon {
  width: 24px;
  height: 24px;
  margin-right: 16px;
}

.message {
  color: #ffffff;
  font-family: "Roboto";
  font-size: 16px;
  font-weight: 500;
}

Boxes:
----------------------------------

https://github.com/ManirathnamKuruma/ReactJS-Boxes

index.html:

<!DOCTYPE html>
<html lang="en">
  <head>
    <link
      href="https://fonts.googleapis.com/css2?family=Bree+Serif&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="index.css" />
    <script src="https://unpkg.com/react@17.0.0/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@17.0.0/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone@7.12.4/babel.js"></script>
  </head>
  <body>
    <div id="root"></div>
    <script type="text/babel" src="./index.js"></script>
  </body>
</html>

index.js:

const Box = (props) => {
  const { text, className } = props;

  return (
    <div className={`box ${className}`}>
      <p className="box-title">{text}</p>
    </div>
  );
};

const element = (
  <div className="boxes-app-container">
    <h1 className="heading">Boxes</h1>
    <div className="boxes-container">
      <Box text="Small" className="small-box" />
      <Box text="Medium" className="medium-box" />
      <Box text="Large" className="large-box" />
    </div>
  </div>
);

ReactDOM.render(element, document.getElementById("root"));

index.css:

* {
  box-sizing: border-box;
}

body {
  margin: 0px;
}

.boxes-app-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

.heading {
  color: #0f172a;
  font-family: "Roboto";
  font-size: 48px;
  font-weight: 700;
}

.boxes-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

@media screen and (min-width: 768px) {
  .boxes-container {
    flex-direction: row;
    align-items: flex-end;
  }
}

.box {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 12px;
}

@media screen and (min-width: 768px) {
  .box {
    margin-top: 0px;
    margin-bottom: 0px;
    margin-left: 20px;
    margin-right: 20px;
  }
}

@media screen and (min-width: 992px) {
  .box {
    margin-left: 40px;
    margin-right: 40px;
  }
}

.small-box {
  background-color: #fbbf24;
  height: 80px;
  width: 80px;
  margin-top: 24px;
}

@media screen and (min-width: 768px) {
  .small-box {
    height: 100px;
    width: 100px;
  }
}

@media screen and (min-width: 992px) {
  .small-box {
    height: 120px;
    width: 120px;
  }
}

@media screen and (min-width: 1200px) {
  .small-box {
    height: 140px;
    width: 140px;
  }
}

.medium-box {
  background-color: #38bdf8;
  height: 150px;
  width: 150px;
}

@media screen and (min-width: 768px) {
  .medium-box {
    height: 200px;
    width: 200px;
  }
}

@media screen and (min-width: 1200px) {
  .medium-box {
    height: 250px;
    width: 250px;
  }
}

.large-box {
  background-color: #ec4899;
  height: 270px;
  width: 270px;
}

@media screen and (min-width: 768px) {
  .large-box {
    height: 350px;
    width: 350px;
  }
}

@media screen and (min-width: 992px) {
  .large-box {
    height: 400px;
    width: 400px;
  }
}

@media screen and (min-width: 1200px) {
  .large-box {
    height: 450px;
    width: 450px;
  }
}

.box-title {
  color: #ffffff;
  font-family: "Bree Serif";
  font-size: 18px;
}

@media screen and (min-width: 768px) {
  .box-title {
    font-size: 24px;
  }
}

Lists & Keys | Cheat Sheet:
---------------------------------------------------------------------------

# Lists and Keys

- Lists
  - Preparing Data
  - Rendering lists
- Keys
  - Adding Unique Key
  - Key Attribute
  
Concepts in Focus:

Keys:
	Keys as Props
	
Users List Application

1. Keys
Keys help React to identify which items have changed, added, or removed. They should be given to the elements inside the array for a stable identity.

The best way to pick a key is to use a string that uniquely identifies a list item among its siblings. Most often, we would use IDs (uniqueNo) from our data as keys.

Example:

JS:

const userDetails = [
  {
    uniqueNo: 1,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
    name: 'Esther Howard',
    role: 'Software Developer'
  }
]

File: src/App.js

JSX:

import UserProfile from './components/UserProfile/index'
const userDetailsList = [
  {
    uniqueNo: 1,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
    name: 'Esther Howard',
    role: 'Software Developer'
  },
  {
    uniqueNo: 2,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/floyd-miles-img.png',
    name: 'Floyd Miles',
    role: 'Software Developer'
  },
  {
    uniqueNo: 3,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/jacob-jones-img.png',
    name: 'Jacob Jones',
    role: 'Software Developer'
  },
  {
    uniqueNo: 4,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/esther-devon-lane.png',
    name: 'Devon Lane',
    role: 'Software Developer'
  }
]

const App = () => (
  <div className="list-container">
    <h1 className="title">Users List</h1>
    <ul>
      {userDetailsList.map((eachItem) => (
        <UserProfile userDetails={eachItem} />
      ))}
    </ul>
  </div>
)
export default App

The index.js file in the folder is considered to be the main file in it. So, a path like ./components/UserProfile can be used instead of ./components/UserProfile/index.

Note
Keys used within arrays should be unique among their siblings. However, they don't need to be unique in the entire application.

1.1 Keys as Props
Keys don't get passed as a prop to the components.

const UserProfile = props => {
  const {userDetails} = props
  const {imageUrl, name, role, key} = userDetails
  console.log(key)  // undefined

  return (
    <li className="user-card-container">
      <img src={imageUrl} className="avatar" alt="avatar" />
      <div className="user-details-container">
        <h1 className="user-name"> {name} </h1>
        <p className="user-designation"> {role} </p>
      </div>
    </li>
  )
}
export default UserProfile

If we need the same value in the component, pass it explicitly as a prop with a different name.

Example:

const UsersList = userDetailsList.map((userDetails) =>
  <UserProfile
    key={userDetails.uniqueNo}
    uniqueNo={userDetails.uniqueNo}
    name={userDetails.name} />
);

2. Users List Application
File: src/App.js

JSX:

import UserProfile from './components/UserProfile/index'
				(or)
import UserProfile from './components/UserProfile'

import './App.css'

const userDetailsList = [
  {
    uniqueNo: 1,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
    name: 'Esther Howard',
    role: 'Software Developer'
  },
  {
    uniqueNo: 2,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/floyd-miles-img.png',
    name: 'Floyd Miles',
    role: 'Software Developer'
  },
  {
    uniqueNo: 3,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/jacob-jones-img.png',
    name: 'Jacob Jones',
    role: 'Software Developer'
  },
  {
    uniqueNo: 4,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/esther-devon-lane.png',
    name: 'Devon Lane',
    role: 'Software Developer'
  }
]

const App = () => (
  <div className="list-container">
    <h1 className="title">Users List</h1>
    <ul>
      {userDetailsList.map((eachItem) => (
        <UserProfile userDetails={eachItem} />
      ))}
    </ul>
  </div>
)
export default App

File: src/components/UserProfile/index.js

JSX:

import './index.css'

const UserProfile = props => {
  const {userDetails} = props
  const {imageUrl, name, role} = userDetails

  return (
    <li className="user-card-container">
      <img src={imageUrl} className="avatar" alt="avatar" />
      <div className="user-details-container">
        <h1 className="user-name"> {name} </h1>
        <p className="user-designation"> {role} </p>
      </div>
    </li>
  )
}
export default UserProfile

# Users List Application

### Assets

```
https://assets.ccbp.in/frontend/react-js/esther-howard-img.png
https://assets.ccbp.in/frontend/react-js/floyd-miles-img.png
https://assets.ccbp.in/frontend/react-js/jacob-jones-img.png
https://assets.ccbp.in/frontend/react-js/devon-lane-img.png
```

### App.css

```css
.list-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.title {
  font-family: 'Roboto';
  font-size: 32px;
  color: #183b56;
  margin-bottom: 30px;
}
```

### UserProfile/index.css

```css
.user-card-container {
  display: flex;
  align-items: center;
  border-radius: 12px;
  margin-bottom: 30px;
}

.avatar {
  width: 48px;
  height: 48px;
  border-radius: 24px;
}

.user-details-container {
  margin-left: 12px;
}

.user-name {
  font-size: 18px;
  color: #12022f;
  font-family: 'Roboto';
  font-weight: bold;
  margin-top: 0px;
  margin-bottom: 8px;
}

.user-designation {
  font-family: 'Roboto';
  font-size: 14px;
  color: #594d6d;
  margin: 0px;
}
```

Note
React Error - ENOSPC: System limit for the number of file watchers reached

Since create-react-app live-reloads and recompiles files on save, it needs to keep track of all project files.

To fix the error, run the below commands in the terminal:

1.Insert the new value into the system config
echo fs.inotify.max_user_watches=524288 | sudo tee -a /etc/sysctl.conf && sudo sysctl -p

2.Check that the new value was applied
cat /proc/sys/fs/inotify/max_user_watches

3.Config variable name (not runnable)
fs.inotify.max_user_watches=524288

coding pratice-3:
------------------------------------------------------------------

Reusable Banners:
-----------------------------

https://github.com/ManirathnamKuruma/ReactJS-ReusableBannersApp

1.Use these files to complete the implementation:

src/App.js
src/App.css
src/components/BannerCardItem/index.js
src/components/BannerCardItem/index.css

src --> components --> BannerCardItem --> new files --> index.css --> index.js
			|
			App.css
			App.js
			index.js
			setupTests.js
			
index.html:

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <link rel="icon" href="%PUBLIC_URL%/img/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta
      name="description"
      content="Web site created using create-react-app"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;500;600;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&family=Playfair+Display+SC:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;1,100;1,300;1,400;1,500;1,700&display=swap"
      rel="stylesheet"
    />
    <link rel="apple-touch-icon" href="%PUBLIC_URL%/img/logo192.png" />
    <!--
      manifest.json provides metadata used when your web app is installed on a
      user's mobile device or desktop. See https://developers.google.com/web/fundamentals/web-app-manifest/
    -->
    <link rel="manifest" href="%PUBLIC_URL%/manifest.json" />
    <!--
      Notice the use of %PUBLIC_URL% in the tags above.
      It will be replaced with the URL of the `public` folder during the build.
      Only files inside the `public` folder can be referenced from the HTML.

      Unlike "/favicon.ico" or "favicon.ico", "%PUBLIC_URL%/favicon.ico" will
      work correctly both with client-side routing and a non-root public URL.
      Learn how to configure a non-root public URL by running `npm run build`.
    -->
    <title>React App</title>
    <script type="text/javascript">
      // hide HRM logs because they're distracting
      // prettier-ignore
      const log = console.log;
      // prettier-ignore
      console.log = (...args) =>
        args[0]?.includes?.('[HMR]') ? null : log(...args);
    </script>
  </head>
  <body>
    <div id="root"></div>
    <!--
      This HTML file is a template.
      If you open it directly in the browser, you will see an empty page.

      You can add webfonts, meta tags, or analytics to this file.
      The build step will place the bundled scripts into the <body> tag.

      To begin the development, run `npm start` or `yarn start`.
      To create a production bundle, use `npm run build` or `yarn build`.
    -->
  </body>
</html>

			
//src/components/BannerCardItem/index.css:

.card-1 {
  background-image: url('https://assets.ccbp.in/frontend/react-js/reusable-banners-card-1-bg.png');
  background-size: cover;
}

.card-2 {
  display: flex;
  justify-content: flex-end;
  background-image: url('https://assets.ccbp.in/frontend/react-js/reusable-banners-card-2-bg.png');
  background-size: cover;
}

.card-3 {
  display: flex;
  justify-content: center;
  text-align: center;
  background-image: url('https://assets.ccbp.in/frontend/react-js/reusable-banners-card-3-bg.png');
  background-size: cover;
}

/* Write your code here. */

.banner-card-item {
  border: 1px solid #cbced2;
  border-radius: 8px;
  width: 100%;
  margin-top: 10px;
  margin-bottom: 10px;
  padding: 32px;
  max-width: 1140px;
  list-style-type: none;
}

.heading {
  color: #326a9d;
  font-family: 'Roboto';
  font-size: 36px;
  font-weight: bold;
}

.description {
  color: #64748b;
  font-family: 'Roboto';
  font-size: 18px;
  margin-top: 24px;
  margin-bottom: 32px;
}

.show-more-btn {
  color: #326a9d;
  background-color: #ffffff;
  font-family: 'Roboto';
  font-size: 14px;
  font-weight: bold;
  border: 2px solid #326a9d;
  border-radius: 5px;
  padding: 8px;
}

//src/components/BannerCardItem/index.js:

import './index.css'

const BannerCardItem = props => {
  const {bannerDetails} = props
  const {headerText, description, className} = bannerDetails

  return (
    <li className={`${className} banner-card-item`}>
      <div>
        <h1 className="heading">{headerText}</h1>
        <p className="description">{description}</p>
        <button className="show-more-btn" type="button">
          Show More
        </button>
      </div>
    </li>
  )
}

export default BannerCardItem

App.css:

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* Write your code here. */

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

.banner-cards-list {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 90%;
  padding-left: 0px;
}

App.js:

import BannerCardItem from './components/BannerCardItem'

import './App.css'

const bannerCardsList = [
  {
    id: 1,
    headerText: 'The Seasons Latest',
    description: 'Get the seasons all latest designs in a flick of your hand',
    className: 'card-1',
  },
  {
    id: 2,
    headerText: 'Our New Designs',
    description:
      'Get the designs developed by our in-house team all for yourself',
    className: 'card-2',
  },
  {
    id: 3,
    headerText: 'Insiders',
    description: 'Get the top class products for yourself with an extra off',
    className: 'card-3',
  },
]

const App = () => (
  <div className="app-container">
    <ul className="banner-cards-list">
      {bannerCardsList.map(eachBanner => (
        <BannerCardItem bannerDetails={eachBanner} key={eachBanner.id} />
      ))}
    </ul>
  </div>
)

export default App

index.js:

import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root'),
)

setupTests.js:

/* eslint-disable */

import '@testing-library/jest-dom'
import {configure} from '@testing-library/react'

configure({testIdAttribute: 'testid'})

Package.json:

{
  "name": "reusable-banners",
  "private": true,
  "version": "1.0.0",
  "engines": {
    "node": "^10.13 || 12 || 14 || 15",
    "npm": ">=6"
  },
  "dependencies": {
    "@testing-library/jest-dom": "5.11.9",
    "@testing-library/react": "11.2.5",
    "@testing-library/user-event": "12.6.2",
    "chalk": "4.1.0",
    "fs-extra": "9.1.0",
    "react": "17.0.1",
    "react-dom": "17.0.1"
  },
  "devDependencies": {
    "eslint-config-airbnb": "18.2.1",
    "eslint-config-prettier": "8.1.0",
    "eslint-plugin-prettier": "3.3.1",
    "husky": "4.3.8",
    "lint-staged": "10.5.4",
    "npm-run-all": "4.1.5",
    "prettier": "2.2.1",
    "react-scripts": "4.0.3"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "lint": "eslint .",
    "lint:fix": "eslint --fix src/",
    "format": "prettier --write \"./src\"",
    "run-all": "npm-run-all --parallel test lint:fix"
  },
  "lint-staged": {
    "*.js": [
      "npm run lint:fix"
    ],
    "*.{js, jsx, json, html, css}": [
      "npm run format"
    ]
  },
  "husky": {
    "hooks": {
      "pre-commit": "lint-staged"
    }
  },
  "jest": {
    "collectCoverageFrom": [
      "src/**/*.js"
    ]
  },
  "browserslist": {
    "development": [
      "last 2 chrome versions",
      "last 2 firefox versions",
      "last 2 edge versions"
    ],
    "production": [
      ">1%",
      "last 4 versions",
      "Firefox ESR",
      "not ie < 11"
    ]
  }
}

Technology cards:
--------------------------------

1.Click to view:

Download dependencies by running npm install
Start up the app using npm start

2.Implementation Files:

Use these files to complete the implementation:

src/App.js
src/App.css
src/components/CardItem/index.js
src/components/CardItem/index.css

3.Things to Keep in Mind:

All components you implement should go in the src/components directory.
Don't change the component folder names as those are the files being imported into the tests.
Do not remove the pre-filled code
Want to quickly review some of the concepts you’ve been learning? Take a look at the Cheat Sheets.

src --> components --> CardItem --> new files --> index.css --> index.js
			|
			App.css
			App.js
			index.js
			setupTests.js
			
src/components/CardItem/index.css:

.card-item {
  background-color: #ffffff;
  border-radius: 20px;
  padding-left: 24px;
  padding-right: 24px;
  padding-top: 32px;
  padding-bottom: 32px;
  margin-left: 24px;
  margin-right: 24px;
  margin-bottom: 48px;
  max-width: 323px;
  list-style-type: none;
}

.card-1 {
  border-top: 5px solid #ff4f64;
}

.card-2 {
  border-top: 5px solid #00a8e7;
}

.card-3 {
  border-top: 5px solid #44c4a1;
}

.card-4 {
  border-top: 5px solid #fcc200;
}

.card-title {
  color: #171f46;
  font-family: 'Roboto';
  font-size: 18px;
  font-weight: 500;
}

.card-description {
  color: #64748b;
  font-family: 'Roboto';
  font-size: 14px;
}

.img-container {
  display: flex;
  justify-content: flex-end;
}

.card-img {
  width: 80px;
  height: 80px;
}

src/components/CardItem/index.js:

import './index.css'

const CardItem = props => {
  const {cardDetails} = props
  const {title, description, imgUrl, className} = cardDetails

  return (
    <li className={`${className} card-item`}>
      <h1 className="card-title">{title}</h1>
      <p className="card-description">{description}</p>
      <div className="img-container">
        <img className="card-img" src={imgUrl} alt={title} />
      </div>
    </li>
  )
}

export default CardItem

src/App.css:

* {
  box-sizing: border-box;
}
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.cards-app-container {
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f4faff;
  min-height: 100vh;
}

.cards-list-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 80%;
  margin-top: 48px;
}

@media screen and (min-width: 768px) {
  .cards-list-container {
    margin-top: 96px;
  }
}

.heading {
  text-align: center;
  color: #171f46;
  font-family: 'Roboto';
  font-size: 48px;
  font-weight: bold;
}

.description {
  text-align: center;
  color: #64748b;
  font-family: 'Roboto';
  font-size: 18px;
  margin-top: 24px;
  max-width: 625px;
}

.cards-list {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  margin-top: 32px;
  max-width: 1100px;
  padding-left: 0px;
}

src/App.js:

import CardItem from './components/CardItem'

import './App.css'

const cardsList = [
  {
    id: 1,
    title: 'Data Scientist',
    description:
      'Data scientists gather and analyze large sets of structured and unstructured data',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/data-scientist-img.png',
    className: 'card-1',
  },
  {
    id: 2,
    title: 'IOT Developer',
    description:
      'IoT Developers are professionals who can develop, manage, and monitor IoT devices.',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/iot-developer-img.png',
    className: 'card-2',
  },
  {
    id: 3,
    title: 'VR Developer',
    description:
      'A VR developer creates completely new digital environments that people can see.',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/vr-developer-img.png',
    className: 'card-3',
  },
  {
    id: 4,
    title: 'ML Engineer',
    description:
      'Machine learning engineers feed data into models defined by data scientists.',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/ml-engineer-img.png',
    className: 'card-4',
  },
]

const App = () => (
  <div className="cards-app-container">
    <div className="cards-list-container">
      <h1 className="heading">Learn 4.0 Technologies</h1>
      <p className="description">
        Get trained by alumni of IITs and top companies like Amazon, Microsoft,
        Intel, Nvidia, Qualcomm, etc. Learn directly from professionals involved
        in Product Development.
      </p>
      <ul className="cards-list">
        {cardsList.map(eachCard => (
          <CardItem cardDetails={eachCard} key={eachCard.id} />
        ))}
      </ul>
    </div>
  </div>
  
)

export default App

Class Component and State | Cheat Sheet:
-----------------------------------------------------------------------------------------------

Concepts in Focus:

Components:
	Functional Components
	Class Components
	
React Events

State:
	Updating State
	State Updates are Merged
	Functional Components vs Class Components
 
Counter Application

1. Components
There are two ways to write React Components.

They are:

Functional Components
Class Components

1.1 Functional Components
These are JavaScript functions that take props as a parameter if necessary and return react element (JSX).

JSX:

const Welcome = () => <h1>Hello, User</h1>;

export default Welcome;

1.2 Class Components
These components are built using an ES6 class.

To define a React Class Component,

Create an ES6 class that extends React.Component.
Add a single empty method to it called render().

1.2.1 extends
The extends keyword is used to inherit methods and properties from the React.Component.

1.2.2 render()
The render() method is the only required method in a class component. It returns the JSX element.

Syntax:

import { Component } from "react";

class MyComponent extends Component {
  render() {
    return JSX;
  }
}

Use this.props in the render() body to access the props in a class component.

JSX:

class Welcome extends Component {
 render() {
   const { name } = this.props
   return <h1>Hello, {name}</h1>
 }
}

Note
The component name should always be in the pascal case.

2. React Events
Handling events with React elements is very similar to handling events on DOM elements. There are some syntax differences:

React events are named using camelCase, rather than lowercase.

Example:

HTML		JSX
onclick		onClick
onblur		onBlur
onchange	onChange

2.With JSX, you pass a function as the event handler rather than a string.

Example:

HTML:

<button onclick="activateLasers()">Activate Lasers</button>

JSX:

<button onClick={activateLasers}>Activate Lasers</button>

We should not call the function when we add an event in JSX. -- red wrong

JSX:

class MyComponent extends Component {
  handleClick = () => {
    console.log("clicked")
  }
  render() {
    return <button onClick={this.handleClick()}>Click Me</button>
  }
}

In the above function, the handleClick is called instead of passed as a reference.

JSX: -- right

class MyComponent extends Component {
  handleClick = () => {
    console.log("clicked")
  }
  render() {
    return <button onClick={this.handleClick}>Click Me</button>
  }
}

In the above function, the handleClick is passed as a reference. So, the function is not being called every time the component renders.

Providing Arrow Functions
To not change the context of this, we have to pass an arrow function to the event.

JSX: -- wrong

class MyComponent extends Component {
  handleClick() {
    console.log(this)  // undefined
  }
  render() {
    return <button onClick={this.handleClick}>Click Me</button>
  }
}

JSX: -- right

class MyComponent extends Component {
  handleClick = () => {
    console.log(this)  // MyComponent {...}
  }
  render() {
    return <button onClick={this.handleClick}>Click Me</button>
  }
}

3. State
The state is a JS object in which we store the component's data that changes over time.

When the state object changes, the component re-renders.

Intialising State:

JSX:

class Counter extends Component {
  state = { count: 0 }
  render() {
    const { count } = this.state;
    return <p className="count">{count}</p>;
  }
}

3.1 Updating State
We can update the state by using setState(). We can provide function/object as an argument to set the state.

Providing Function as an Argument:

Syntax:

this.setState( prevState => ({... }) )

Here the previous state is sent as a parameter to the callback function.

JS:

onIncrement = () => {
  this.setState((prevState) =>
    console.log(`previous state value ${prevState.count}`)
  )
}

3.2 State Updates are Merged
State updates are merged. It means that when you update only one key-value pair in the state object, it will not affect the other key-value pairs in the state object.

JSX:

// For example let's say your state is as followed:
state = { key1 : value1, key2 : value2 }

// if you use this.setState such as :
this.setState((prevState) => ({ prevState.key1 : value3 }))

// your new state will be :
state = { key1 : value3, key2 : value2 }

3.3 Functional Components vs Class Components

Functional Components				Class Components
Renders the UI based on props		Renders the UI based on props and state

Use Class Components whenever the state is required. Otherwise, use the Functional components.

4. Counter Application

File: src/App.js

JSX:

import Counter from "./components/Counter";

const App = () => {
  return <Counter />
}

export default App;

File: src/components/Counter/index.js

JSX:

import { Component } from "react"

import "./index.css"

class Counter extends Component {
  state = { count: 0 }
  onIncrement = () => {
    this.setState((prevState) => ({ count: prevState.count + 1 }))
  }
  onDecrement = () => {
    this.setState((prevState) => ({ count: prevState.count - 1 }))
  }
  render() {
    const { count } = this.state
    return (
      <div className="container">
        <h1 className="count">Count {count}</h1>
        <button className="button" onClick={this.onIncrement}>
          Increase
        </button>
        <button className="button" onClick={this.onDecrement}>
          Decrease
        </button>
      </div>
    )
  }
}

export default Counter

mcq:
------------------------------------------------

1.Considering the given code snippets, what would be the output logged in the console when we click on the Login button?

JSX:

// src/App.js  

import Authentication from "./components/Authentication";

const App = () => {
  return <Authentication />;
};

export default App;

JSX:

// src/components/Authentication/index.js 

import { Component } from "react";

class Authentication extends Component {
  onClickLogin = () => {
    console.log("Login successful");
  }
  onClickLogOut = () => {
    console.log("Logout successful");
  }
  
  render() {
    return (
      <div>
        <button onClick={this.onClickLogin}>Login</button>
        <button onClick={this.onClickLogOut}>Logout</button>
      </div>
    );
  }
}

export default Authentication;

Output:

Login successful

2.Considering the given code snippets, what would be the output logged in the console when we click on the Withdraw button?

JSX:

// src/App.js  

import ATM from "./components/ATM";

const App = () => {
  return <ATM />;
};

export default App;

JSX:

// src/components/ATM/index.js
 
import { Component } from "react";

class ATM extends Component {
  onWithdraw = () => {
    console.log("Your transaction has been successful");
  };
  
  render() {
    return (
      <div>
        <h1>ATM</h1>
        <button onClick={this.onWithdraw}>Withdraw</button>
      </div>
    );
  }
}

export default ATM;

Output:

Your transaction has been successful

3.Considering the given code snippets, what would be the text displayed on the web page?

JSX:

// src/App.js  

import Technology from "./components/Technology";

const App = () => {
  return <Technology name="Artificial intelligence" />;
};

export default App;

JSX:

// src/components/Technology/index.js 
const Technology = (props) => {
  return (
    <div>
      <h1>{props.name}</h1>
    </div>
  );
};

export default Technology;

Output:

Artificial intelligence

4.Considering the given code snippets, what would be the text displayed on the web page?

// src/App.js
  
import University from "./components/University";

const App = () => {
  return <University />;
};

export default App;

// src/components/University/index.js 

import { Component } from "react";

class University extends Component {
  state = { name: "University of Delhi" };

  render() {
    const { name } = this.state;
    return (
      <div>
        <h1>{name}</h1>
      </div>
    );
  }
}

export default University;

Output:

University of Delhi

5.Considering the given code snippets, what would be the output logged in the console when we click on the Account Balance button?

// src/App.js  

import Account from "./components/Account";

const App = () => {
  return <Account />;
};

export default App;

// src/components/Account/index.js 

import { Component } from "react";

class Account extends Component {
  state = { amount: 100 };
  
  accountBalance = () => {
    console.log(this.state.amount);
  };

  render() {
    return (
      <div>
        <button onClick={this.accountBalance}>Account Balance</button>
      </div>
    );
  }
}

export default Account;

Output:

100

6.Considering the given code snippets, what would be the text displayed on the web page?

// src/App.js  

import Blog from "./components/Blog";

const App = () => {
 return <Blog />;
};

export default App;

// src/components/Blog/index.js 

const Blog = () => {
  return (
    <div>
      <h1>The Innovative Educator</h1>
    </div>
  );
};

export default Blog;

Output:

The Innovative Educator

7.Considering the given code snippets, what would be the text displayed in the HTML heading element on the web page when we click on the Change Channel button?

// src/App.js  

import Radio from "./components/Radio";

const App = () => {
  return <Radio />;
};

export default App;

// src/components/Radio/index.js 

import { Component } from "react";

class Radio extends Component {
  state = { channel: 13 };

  changeChannel = () => {
    this.setState((previousState) => ({ channel: previousState.channel + 1 }));
  };

  render() {
    return (
      <div>
        <h1>Channel: {this.state.channel}</h1>
        <button onClick={this.changeChannel}>Change Channel</button>
      </div>
    );
  }
}

export default Radio;

Output:

 channel:14
 
 8.Considering the given code snippets, what would be the output logged in the console when we click on the Display Status button?
 
 // src/App.js  
 
import Bulb from "./components/Bulb";

const App = () => {
  return <Bulb />;
};

export default App;

// src/components/Bulb/index.js
 
import { Component } from "react";

class Bulb extends Component {
  state = { status: "ON" };

  displayStatus = () => {
    console.log(this.state.status);
  }
  
  render() {
    return (
      <div>
        <h1>{this.state.status}</h1>
        <button onClick={this.displayStatus}>Display Status</button>
      </div>
    );
  }
}

export default Bulb;

Output:

ON

9.Considering the given code snippets, what would be the output logged in the console when we click on the Profit button?

// src/App.js  

import Calculator from "./components/Calculator";

const App = () => {
  return <Calculator />;
};

export default App;

// src/components/Calculator/index.js 

import { Component } from "react";

class Calculator extends Component {
  state = { costPrice: 100, sellingPrice: 113 };

  profit = () => {
    console.log(this.state.sellingPrice - this.state.costPrice);
  };

  render() {
    return (
      <div>
        <button onClick={this.profit}>Profit</button>
      </div>
    );
  }
}

export default Calculator;

Output:

13

coding pratice-4:
----------------------------------------------------------------------------------

click counter:
----------------------

https://github.com/ManirathnamKuruma/ReactJS-ClickCounterApp

1.Set Up Instructions:

Click to view
Download dependencies by running npm install
Start up the app using npm start

2.Completion Instructions:

Functionality to be added

The app must have the following functionalities

Initially the count of the number of clicks should be 0
When Click Me! button is clicked the count of the number of clicks should be incremented by 1

3.Implementation Files:

Use these files to complete the implementation:

src/components/ClickCounter/index.js
src/components/ClickCounter/index.css

4.Quick Tips:

Click to view

You can use the below cursor CSS property for buttons to set the type of mouse cursor, to show when the mouse pointer is over an element,

  cursor: pointer;

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked,

 outline: none;

Things to Keep in Mind:

All components you implement should go in the src/components directory.
Don't change the component folder names as those are the files being imported into the tests.
Do not remove the pre-filled code
Want to quickly review some of the concepts you’ve been learning? Take a look at the Cheat Sheets.

//src/components/ClickCounter/index.js

import {Component} from 'react'

import './index.css'

class ClickCounter extends Component {
  state = {
    count: 0,
  }

  onIncrementCount = () => {
    this.setState(prevState => ({count: prevState.count + 1}))
  }

  render() {
    const {count} = this.state

    return (
      <div className="counter-container">
        <h1 className="counter-heading">
          The Button has been clicked
          <br /> <span className="counter-value">{count}</span> times
        </h1>
        <p className="description">Click the button to increase the count!</p>
        <div className="button-container">
          <button
            type="button"
            className="button"
            onClick={this.onIncrementCount}
          >
            Click Me!
          </button>
        </div>
      </div>
    )
  }
}

export default ClickCounter

//src/components/ClickCounter/index.css

.counter-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  background-color: #f1f5f8;
  height: 100vh;
}

.counter-heading {
  text-align: center;
  color: #2d3a35;
  font-family: 'Roboto';
  font-size: 32px;
  font-weight: 800;
}

@media screen and (min-width: 768px) {
  .counter-heading {
    font-size: 50px;
  }
}

.counter-value {
  color: #c20a72;
  font-weight: 900;
}

.description {
  text-align: center;
  color: #2d3a35;
  font-family: 'Roboto';
  font-size: 16px;
}

@media screen and (min-width: 768px) {
  .description {
    font-size: 20px;
  }
}

.button-container {
  text-align: center;
}

.button {
  color: #ffffff;
  background-color: #007bff;
  font-family: 'Roboto';
  border: none;
  border-radius: 4px;
  padding-left: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-right: 16px;
  outline: none;
  cursor: pointer;
}

// src/App.js  

import ClickCounter from './components/ClickCounter'

import './App.css'

const App = () => <ClickCounter />

export default App

// src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

package.json:

{
  "name": "click-counter",
  "private": true,
  "version": "1.0.0",
  "engines": {
    "node": "^10.13 || 12 || 14 || 15",
    "npm": ">=6"
  },
  "dependencies": {
    "@testing-library/jest-dom": "5.11.9",
    "@testing-library/react": "11.2.5",
    "@testing-library/user-event": "12.6.2",
    "chalk": "4.1.0",
    "react": "17.0.1",
    "react-dom": "17.0.1"
  },
  "devDependencies": {
    "eslint-config-airbnb": "18.2.1",
    "eslint-config-prettier": "8.1.0",
    "eslint-plugin-prettier": "3.3.1",
    "husky": "4.3.8",
    "lint-staged": "10.5.4",
    "npm-run-all": "4.1.5",
    "prettier": "2.2.1",
    "react-scripts": "4.0.3"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "lint": "eslint .",
    "lint:fix": "eslint --fix src/",
    "format": "prettier --write \"./src\"",
    "run-all": "npm-run-all --parallel test lint:fix"
  },
  "lint-staged": {
    "*.js": [
      "npm run lint:fix"
    ],
    "*.{js, jsx, json, html, css}": [
      "npm run format"
    ]
  },
  "husky": {
    "hooks": {
      "pre-commit": "lint-staged"
    }
  },
  "jest": {
    "collectCoverageFrom": [
      "src/**/*.js"
    ]
  },
  "browserslist": {
    "development": [
      "last 2 chrome versions",
      "last 2 firefox versions",
      "last 2 edge versions"
    ],
    "production": [
      ">1%",
      "last 4 versions",
      "Firefox ESR",
      "not ie < 11"
    ]
  }
}

Speedometer:
------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-SpeedometerApp

1.Completion Instructions:

Functionality to be added

The app must have the following functionalities

The speed should initially be 0mph
	Here mph means Miles per hour

When Accelerate button is clicked,
	If the speed is less than 200mph, the speed should be increased by 10mph
	If the speed is equal to 200mph, the speed should not be increased
	
When Apply Brake button is clicked
	If the speed is greater than 0mph, then the speed should be decreased by 10mph
	If the speed is equal to 0mph, the speed should not be decreased
	
2.Implementation Files:

Use these files to complete the implementation:

src/components/Speedometer/index.js
src/components/Speedometer/index.css

//src/components/Speedometer/index.js

import {Component} from 'react'

import './index.css'

class Speedometer extends Component {
  state = {
    speed: 0,
  }

  onClickApplyBrakeButton = () => {
    const {speed} = this.state

    if (speed > 0) {
      this.setState(prevState => ({speed: prevState.speed - 10}))
    }
  }

  onClickAccelerateButton = () => {
    const {speed} = this.state

    if (speed < 200) {
      this.setState(prevState => ({speed: prevState.speed + 10}))
    }
  }

  render() {
    const {speed} = this.state

    return (
      <div className="speedometer-app-container">
        <div className="speedometer-container ">
          <h1 className="heading">SPEEDOMETER</h1>
          <img
            src="https://assets.ccbp.in/frontend/react-js/speedometer-img.png"
            alt="speedometer"
            className="speedometer-image"
          />
          <h1 className="speed-text">Speed is {speed}mph</h1>
          <p className="speed-limits">Min Limit is 0mph, Max Limit is 200mph</p>
          <div className="buttons-container">
            <button
              type="button"
              className="accelerate-button button"
              onClick={this.onClickAccelerateButton}
            >
              Accelerate
            </button>
            <button
              type="button"
              className="apply-brake-button button"
              onClick={this.onClickApplyBrakeButton}
            >
              Apply Brake
            </button>
          </div>
        </div>
      </div>
    )
  }
}

export default Speedometer

//src/components/Speedometer/index.css

.speedometer-app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #07080c;
  height: 100vh;
}

.speedometer-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.heading {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 36px;
  font-style: italic;
  font-weight: 500;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 48px;
  }
}

.speedometer-image {
  width: 300px;
  height: 125px;
}

@media screen and (min-width: 768px) {
  .speedometer-image {
    width: 700px;
    height: 300px;
  }
}

.speed-text {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 500;
}

@media screen and (min-width: 768px) {
  .speed-text {
    font-size: 32px;
  }
}

.speed-limits {
  color: #cbd5e1;
  font-family: 'Roboto';
  font-size: 12px;
  margin-bottom: 48px;
}
@media screen and (min-width: 768px) {
  .speed-limits {
    font-size: 16px;
  }
}

.buttons-container {
  display: flex;
  justify-content: center;
}

.button {
  border-radius: 8px;
  padding-left: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-right: 16px;
  margin-left: 12px;
  margin-right: 12px;
  outline: none;
  cursor: pointer;
}

.accelerate-button {
  color: #ffffff;
  background-color: #0b69ff;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
  border: none;
}

.apply-brake-button {
  color: #94a3b8;
  background-color: transparent;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
  border: 2px solid #94a3b8;
}

//src/App.js

import Speedometer from './components/Speedometer'

import './App.css'

const App = () => <Speedometer />

export default App

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

Fruits counter:
------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-FruitsCounterApp

1.Completion Instructions:

Functionality to be added

The app must have the following functionalities
	Initially, the count of the eaten mangoes and bananas should be 0
	When Eat Mango is clicked the count of the mangoes eaten should be incremented by 1
	When Eat Banana is clicked the count of the bananas eaten should be incremented by 1
	
2.Implementation Files:

Use these files to complete the implementation:

src/components/FruitsCounter/index.js
src/components/FruitsCounter/index.css

3.Quick Tips:

Click to view

State updates are merged. It means that when you update only one key-value pair in the state object, it will not affect the other key-value pairs in the state object.

For example let's say your state is as followed:

state = { key1 : value1, key2 : value2 }

If you use this.setState such as :

this.setState(prevState => ({key1: prevState + valueN}))

Your new state will be :

state = { key1 : value3, key2 : value2 }

You can use the below cursor CSS property for buttons to set the type of mouse cursor, to show when the mouse pointer is over an element,

cursor: pointer;

//src/components/FruitsCounter/index.js

import {Component} from 'react'

import './index.css'

class FruitsCounter extends Component {
  state = {
    mangoesCount: 0,
    bananasCount: 0,
  }

  onClickEatBanana = () => {
    this.setState(prevState => ({bananasCount: prevState.bananasCount + 1}))
  }

  onClickEatMango = () => {
    this.setState(prevState => ({mangoesCount: prevState.mangoesCount + 1}))
  }

  render() {
    const {mangoesCount, bananasCount} = this.state

    return (
      <div className="fruits-counter-container">
        <div className="fruits-counter">
          <h1 className="count-text">
            Bob ate <span className="count">{mangoesCount}</span> mangoes
            <span className="count"> {bananasCount}</span> bananas
          </h1>
          <div className="counters-control-container">
            <div className="counter-control">
              <img
                src="https://assets.ccbp.in/frontend/react-js/mango-img.png"
                alt="mango"
                className="fruit-image"
              />
              <div className="button-container">
                <button
                  type="button"
                  className="button"
                  onClick={this.onClickEatMango}
                >
                  Eat Mango
                </button>
              </div>
            </div>
            <div className="counter-control">
              <img
                src="https://assets.ccbp.in/frontend/react-js/banana-img.png"
                alt="banana"
                className="fruit-image"
              />
              <div className="button-container">
                <button
                  type="button"
                  className="button"
                  onClick={this.onClickEatBanana}
                >
                  Eat Banana
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default FruitsCounter

//src/components/FruitsCounter/index.css

.fruits-counter-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #ffd569;
  height: 100vh;
}

.fruits-counter {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #ffffff;
  border-radius: 16px;
  width: 90%;
  padding: 24px;
  max-width: 1110px;
}

@media screen and (min-width: 768px) {
  .fruits-counter {
    width: 80%;
    padding-top: 96px;
    padding-left: 64px;
    padding-right: 64px;
    padding-bottom: 96px;
  }
}

.count-text {
  text-align: center;
  color: #000000;
  font-family: 'Roboto';
  font-size: 20px;
  font-weight: 700;
}

@media screen and (min-width: 768px) {
  .count-text {
    font-size: 48px;
  }
}

.count {
  color: #ffd569;
}

.counters-control-container {
  display: flex;
  flex-direction: column;
}

@media screen and (min-width: 768px) {
  .counters-control-container {
    flex-direction: row;
  }
}

.counter-control {
  display: flex;
  flex-direction: column;
  margin-top: 32px;
  margin-left: 16px;
  margin-right: 16px;
}

@media screen and (min-width: 768px) {
  .counter-control {
    margin-top: 96px;
    margin-left: 48px;
    margin-right: 48px;
  }
}

.fruit-image {
  width: 200px;
  height: 175px;
}

@media screen and (min-width: 992px) {
  .fruit-image {
    width: 296px;
    height: 275px;
  }
}

.button-container {
  text-align: center;
  margin-top: 24px;
}

@media screen and (min-width: 768px) {
  .button-container {
    margin-top: 48px;
  }
}

.button {
  color: #ffffff;
  background-color: #007bff;
  font-size: 12px;
  font-family: 'Roboto';
  border: none;
  border-radius: 4px;
  padding-left: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-right: 16px;
  outline: none;
  cursor: pointer;
}

@media screen and (min-width: 768px) {
  .button {
    font-size: 16px;
  }
}

//src/App.js

import FruitsCounter from './components/FruitsCounter'

import './App.css'

const App = () => <FruitsCounter />

export default App

Conditional Rendering | Cheat Sheet:
-------------------------------------------------------------------------------

Concepts in Focus:

Conditional Rendering:
	Using an If...Else Statement
	Using Element Variables
	Using Ternary Operators
	Using Logical && Operator
	
Default Props

//src/components/Welcome/index.js

import './index.css'

const Welcome = props => {
  const {name, greeting} = props
  return (
    <h1 className="message">
      {greeting}, {name}
    </h1>
  )
}

export default Welcome

//src/components/Welcome/index.css

.message {
  font-family: 'Roboto';
  font-size: 32px;
}

//src/App.css

* {
  box-sizing: border-box;
}

body {
  padding: 30px;
}

h1 {
  font-size: 30px;
  font-weight: 500;
  text-align: center;
  margin-bottom: 1em;
  margin-right: 1em;
  padding: 0;
  color: #333333;
}

.container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

button {
  background-color: #246bec;
  border: 1px solid #246bec;
  border-radius: 4px;
  box-sizing: border-box;
  color: #ffffff;
  display: block;
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 8px;
  margin-top: 8px;
  padding: 8px;
  width: 100%;
  max-width: 200px;
}

.text-blue {
  color: blue;
}

//src/App.js

import {Component} from 'react'

import Welcome from './components/Welcome'

import './App.css'

class App extends Component {
  state = {
    isLoggedIn: true,
  }

  render() {
    return (
      <div className="container">
        <Welcome greeting="Hello" name="User" />
        <button>Login</button>
        <button>Logout</button>
      </div>
    )
  }
}

export default App

1 . Conditional Rendering
Conditional Rendering allows us to render different elements or components based on a condition.

Different ways to implement Conditional Rendering are:

Using an If...Else Statement
Using Element Variables
Using Ternary Operators
Using Logical && Operator

1.1 Using an If...Else Statement

JSX:

import { Component } from "react"
import './App.css'

class App extends Component {
  state = { isLoggedIn: true }

   renderAuthButton = () => {
    const {isLoggedIn} = this.state
    if (isLoggedIn === true) {
      return <button>Logout</button>
    }
    return <button>Login</button>
  }

  render() {
    return (
     <div className="container">
        {this.renderAuthButton()}
      </div>
    )
  }
}

export default App

1.2 Using Element Variables

import { Component } from "react"
import './App.css'

class App extends Component {
  state = { isLoggedIn: true }

  render() {
    const { isLoggedIn } = this.state
    let authButton
    if (isLoggedIn) {
      authButton = <button>Logout</button>
    } else {
      authButton = <button>Login</button>
    }
    return (
      <div className="container">
        <h1>React JS</h1>
        {authButton}
      </div>
    )
 }
}

export default App

1.3 Using Ternary Operators

import { Component } from "react"
import './App.css'

class App extends Component {

  render() {
    const { isLoggedIn } = this.state
    return (
      <div className="container">
        {isLoggedIn ? <button>Logout</button> : <button>Login</button>}
      </div>
    )
  }
}

export default App

1.4 Using Logical && Operator

import { Component } from "react"
import './App.css'

class App extends Component {

  render() {
    const { isLoggedIn } = this.state
    return (
      <div className="container">
        {isLoggedIn && <button>Logout</button>}
        {!isLoggedIn && <button>Login</button>}
      </div>
    )
  }
}

export default App

Note
Conditional Rendering can be achieved using inline styles or adding classes with CSS display property with value none. However, it is not preferable.

2. Default Props
defaultProps is a property in React Component used to set default values for the props. This is similar to adding default parameters to the function.

Syntax: 

// Component Definition

ComponentName.defaultProps = {
  propName1: "propValue1",
  propName2: "propValue2"
}

// Exporting Component

Example: 

File: src/Welcome/index.js

const Welcome = (props) => {
  const { name, greeting } = props;
  return (
    <h1 className="message">
      {greeting}, {name}
    </h1>
  );
};

Welcome.defaultProps = {
  name: "Rahul",
  greeting: "Hello"
};

export default Welcome;

File: src/App.js

import { Component } from "react";
import Welcome from "./Welcome";

class App extends Component {
  state = { isLoggedIn: true };
  render() {
    const { isLoggedIn } = this.state;
    return (
      <div className="container">
        <Welcome greeting="Hello" />
      </div>
    );
  }
}

export default App;

Note
While accessing the props, the correct prop name should be given.

coding pratice-5:
-----------------------------------------------------------------------------

Welcome App:
--------------------------

https://github.com/ManirathnamKuruma/ReactJS-WelcomeApp

1.Set Up Instructions:

Click to view:
	Download dependencies by running npm install
	Start up the app using npm start
	
2.Completion Instructions:

Functionality to be added

The app must have the following functionalities

When the page is opened, a button should be displayed with text content as Subscribe

When the Subscribe button is clicked
	The text content in the Subscribe button should be changed to Subscribed
	
When the Subscribed button is clicked
	The text content in the Subscribed button should be changed to Subscribe
	
3.Implementation Files:

Use these files to complete the implementation:

src/components/Welcome/index.js
src/components/Welcome/index.css

4.Important Note:
Click to view

The following instructions are required for the tests to pass

	Achieve the given layout using only Conditional Rendering
	
//src/components/Welcome/index.js

import {Component} from 'react'

import './index.css'

class Welcome extends Component {
  state = {
    isSubscribed: false,
  }

  onSubscribe = () => {
    this.setState(prevState => ({isSubscribed: !prevState.isSubscribed}))
  }

  getButtonText = () => {
    const {isSubscribed} = this.state

    return isSubscribed ? 'Subscribed' : 'Subscribe'
  }

  render() {
    const buttonText = this.getButtonText()

    return (
      <div className="app-container">
        <h1 className="heading">Welcome</h1>
        <p className="description">Thank you! Happy Learning</p>
        <button
          type="button"
          className="subscribe-button"
          onClick={this.onSubscribe}
        >
          {buttonText}
        </button>
      </div>
    )
  }
}

export default Welcome


//src/components/Welcome/index.css

.app-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #1e293b;
  height: 100vh;
}

.heading {
  color: #f0bb03;
  font-family: 'Bree Serif';
  font-size: 64px;
  margin-bottom: 16px;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 96px;
  }
}

.description {
  color: #ffffff;
  font-family: 'Bree Serif';
  font-size: 24px;
}

@media screen and (min-width: 768px) {
  .description {
    font-size: 36px;
  }
}

.subscribe-button {
  text-align: center;
  background-color: #ffffff;
  font-family: 'Bree Serif';
  font-size: 16px;
  border-radius: 12px;
  border: none;
  padding-top: 12px;
  padding-bottom: 12px;
  padding-left: 24px;
  padding-right: 24px;
}

@media screen and (min-width: 768px) {
  .subscribe-button {
    font-size: 18px;
  }
}

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

//src/App.js

import Welcome from './components/Welcome'

import './App.css'

const App = () => <Welcome />

export default App

Light Dark Mode:
-------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-LightDarkModeApp

1.Completion Instructions:
Functionality to be added

The app must have the following functionalities

When the app is opened, the UI should be displayed in Dark mode.

When the app is in Dark mode and the Light Mode button is clicked.
	The UI should be displayed in Light mode
	The text content in the button should be changed to Dark Mode
	
When the app is in Light mode and the Dark Mode button is clicked
	The UI should be displayed in Dark mode
	The text content in the button should be changed to Light Mode
	
2.Implementation Files:

Use these files to complete the implementation:

src/components/LightDarkMode/index.js
src/components/LightDarkMode/index.css

3.Important Note:
Click to view

The following instructions are required for the tests to pass
	Achieve the given layout using only Conditional Rendering

//src/components/LightDarkMode/index.js

import {Component} from 'react'

import './index.css'

class LightDarkMode extends Component {
  state = {
    isDarkMode: true,
  }

  onClickButton = () => {
    this.setState(prevState => ({isDarkMode: !prevState.isDarkMode}))
  }

  render() {
    const {isDarkMode} = this.state
    const modeClassName = isDarkMode ? 'dark-mode' : 'light-mode'
    const buttonText = isDarkMode ? 'Light Mode' : 'Dark Mode'

    return (
      <div className="app-container">
        <div className={`container ${modeClassName}`}>
          <h1 className="heading">Click To Change Mode</h1>
          <button type="button" onClick={this.onClickButton} className="button">
            {buttonText}
          </button>
        </div>
      </div>
    )
  }
}

export default LightDarkMode


//src/components/LightDarkMode/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  padding: 24px;
}

.container {
  text-align: center;
  border-radius: 12px;
  padding: 24px;
}

.dark-mode {
  color: #ffffff;
  background-color: #000000;
}

.light-mode {
  color: #000000;
  background-color: #ffffff;
  border: 1px solid #000000;
}

.heading {
  font-family: 'Roboto';
  font-size: 32px;
}

.button {
  font-size: 16px;
  border: none;
  padding: 16px;
  border-radius: 8px;
}

//src/App.js

import LightDarkMode from './components/LightDarkMode'

import './App.css'

const App = () => <LightDarkMode />

export default App

Show/Hide App:
-----------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-ShowHideApp

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

The Firstname and Lastname should be hidden initially

When the Show/Hide Firstname button is clicked,
	If the Firstname is hidden, then it should be displayed
	If the Firstname is displayed, then it should be hidden
	
When the Show/Hide Lastname button is clicked,
	If the Lastname is hidden, then it should be displayed
	If the Lastname is displayed, then it should be hidden
	
2.Implementation Files

Use these files to complete the implementation:

src/components/ShowHide/index.js
src/components/ShowHide/index.css

//src/components/ShowHide/index.js

import {Component} from 'react'

import './index.css'

class ShowHide extends Component {
  state = {
    showFirstName: false,
    showLastName: false,
  }

  onShowLastName = () => {
    this.setState(prevState => ({showLastName: !prevState.showLastName}))
  }

  onShowFirstName = () => {
    this.setState(prevState => ({showFirstName: !prevState.showFirstName}))
  }

  render() {
    const {showFirstName, showLastName} = this.state

    return (
      <div className="app-container">
        <h1 className="heading">Show/Hide</h1>
        <div className="show-hide-container">
          <div className="name-container">
            <button
              type="button"
              className="show-hide-button"
              onClick={this.onShowFirstName}
            >
              Show/Hide Firstname
            </button>
            {showFirstName && <p className="name">Joe</p>}
          </div>
          <div className="name-container">
            <button
              type="button"
              className="show-hide-button"
              onClick={this.onShowLastName}
            >
              Show/Hide Lastname
            </button>
            {showLastName && <p className="name">Jonas</p>}
          </div>
        </div>
      </div>
    )
  }
}

export default ShowHide


//src/components/ShowHide/index.css

.app-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-image: linear-gradient(to right, #fa7257, #fc63a7);
}

.heading {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 48px;
  font-weight: 700;
}

.show-hide-container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
}

.name-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 300px;
  height: 200px;
  margin-left: 32px;
  margin-right: 32px;
}

.show-hide-button {
  color: #dd1264;
  font-family: 'Roboto';
  font-size: 14px;
  font-weight: 500;
  border: none;
  border-radius: 12px;
  padding-left: 24px;
  padding-top: 12px;
  padding-bottom: 12px;
  padding-right: 24px;
}

.name {
  text-align: center;
  background-color: #fddddb;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 500;
  border-radius: 12px;
  padding-top: 48px;
  padding-left: 106px;
  padding-right: 106px;
  padding-bottom: 48px;
}

//src/App.js

import ShowHide from './components/ShowHide'

import './App.css'

const App = () => <ShowHide />

export default App

//src/index.js

import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root'),
)

//src/setupTests.js

/* eslint-disable */

import '@testing-library/jest-dom'
import {configure} from '@testing-library/react'

configure({testIdAttribute: 'testid'})

Even Odd App:
----------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-EvenOddApp

1.Completion Instructions:
Functionality to be added

The app must have the following functionalities

Initially, the count should be 0 and Count is Even text should be displayed

When the Increment button is clicked,
	The count should be increased by a random value between 0 to 100
	If the incremented count is an even number, then the Count is Even text should be displayed
	If the incremented count is an odd number, then the Count is Odd text should be displayed
	
2.Implementation Files:

Use these files to complete the implementation:

src/components/EvenOddApp/index.js
src/components/EvenOddApp/index.css

//src/components/EvenOddApp/index.js

import {Component} from 'react'

import './index.css'

class EvenOddApp extends Component {
  state = {count: 0}

  getRandomNumber = () => Math.ceil(Math.random() * 100)

  onIncrement = () => {
    const randomNumber = this.getRandomNumber()

    this.setState(prevState => ({count: prevState.count + randomNumber}))
  }

  render() {
    const {count} = this.state
    const displayText = count % 2 === 0 ? 'Even' : 'Odd'

    return (
      <div className="app-container">
        <div className="count-container">
          <h1 className="count">Count {count}</h1>
          <p className="number-category">Count is {displayText}</p>
          <button
            type="button"
            className="increment-button"
            onClick={this.onIncrement}
          >
            Increment
          </button>
          <p className="note">*Increase By Random Number Between 0 to 100</p>
        </div>
      </div>
    )
  }
}

export default EvenOddApp


//src/components/EvenOddApp/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.count-container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  height: 350px;
  width: 400px;
  border-radius: 12px;
  background-image: linear-gradient(#ff6e7f, #bfe9ff);
  font-family: 'Roboto';
}

.count {
  color: #0f172a;
  font-size: 32px;
}

.number-category {
  color: #334155;
  font-size: 20px;
}

.increment-button {
  color: #1e293b;
  font-size: 12px;
  background-color: #ffffff;
  border-radius: 8px;
  border: none;
  padding-right: 32px;
  padding-left: 32px;
  padding-top: 8px;
  padding-bottom: 8px;
}

.note {
  color: #334155;
  font-size: 10px;
}

//src/App.js

import EvenOddApp from './components/EvenOddApp'

import './App.css'

const App = () => <EvenOddApp />

export default App

Login App:
---------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-LoginApp

1.Completion Instructions:
Functionality to be added

The app must have the following functionalities

Initially, Please Login message and Login button should be displayed

When the Login button is clicked,
	Welcome User message and Logout button should be displayed
	
When the Logout button is clicked,
	Please Login message and Login button should be displayed
	
2.Implementation Files

Use these files to complete the implementation:

src/components/Home/index.js
src/components/Home/index.css
src/components/Login/index.js
src/components/Login/index.css
src/components/Logout/index.js
src/components/Logout/index.css
src/components/Message/index.js
src/components/Message/index.css

//src/components/Home/index.js

import {Component} from 'react'

import Message from '../Message'
import Login from '../Login'
import Logout from '../Logout'

import './index.css'

class Home extends Component {
  state = {isLoggedIn: false}

  onClickButton = () => {
    this.setState(prevState => ({isLoggedIn: !prevState.isLoggedIn}))
  }

  render() {
    const {isLoggedIn} = this.state

    return (
      <div className="app-container">
        <div className="home-container">
          <Message isLoggedIn={isLoggedIn} />
          {isLoggedIn ? (
            <Logout logout={this.onClickButton} />
          ) : (
            <Login login={this.onClickButton} />
          )}
        </div>
      </div>
    )
  }
}

export default Home

//src/components/Home/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
.home-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 350px;
  width: 400px;
  border-radius: 12px;
  background-image: linear-gradient(#2b2c49, #b5b9ff);
}

//src/components/Login/index.js

import './index.css'

const Login = props => {
  const {login} = props

  return (
    <button type="button" className="login-button" onClick={login}>
      Login
    </button>
  )
}

export default Login

//src/components/Login/index.css

.login-button {
  color: #303150;
  font-family: 'Roboto';
  font-size: 14px;
  border: none;
  border-radius: 12px;
  background-color: #f8fafc;
  padding-top: 12px;
  padding-bottom: 12px;
  padding-left: 32px;
  padding-right: 32px;
}

//src/components/Logout/index.js

import './index.css'

const Logout = props => {
  const {logout} = props

  return (
    <button type="button" className="logout-button" onClick={logout}>
      Logout
    </button>
  )
}

export default Logout

//src/components/Logout/index.css

.logout-button {
  color: #303150;
  font-family: 'Roboto';
  font-size: 14px;
  border: none;
  border-radius: 12px;
  background-color: #f8fafc;
  padding-top: 12px;
  padding-bottom: 12px;
  padding-left: 32px;
  padding-right: 32px;
}

//src/components/Message/index.js

import './index.css'

const Message = props => {
  const {isLoggedIn} = props
  const message = isLoggedIn ? 'Welcome User' : 'Please Login'

  return <h1 className="message">{message}</h1>
}

export default Message

//src/components/Message/index.css

.message {
  color: #ffffff;
  font-size: 32px;
  font-family: 'Roboto';
}

//src/App.js

import Home from './components/Home'

import './App.css'

const App = () => <Home />

export default App

Class Component and State | Part 2 | Cheat Sheet:
-----------------------------------------------------------------------------------------

Searchable Users List
	Searching User
	Deleting User
	
setState()
	Object Syntax
	
Components
	Passing Callbacks
	
Initial code:
----------------------

//src/components/UserProfile/index.css

.user-card-container {
  display: flex;
  align-items: center;
  border-radius: 12px;
  margin-bottom: 30px;
}

.profile-pic {
  width: 48px;
  height: 48px;
  border-radius: 24px;
}

.user-details-container {
  margin-left: 12px;
}

.user-name {
  font-size: 18px;
  color: #12022f;
  font-family: 'Roboto';
  font-weight: bold;
  margin-top: 0px;
  margin-bottom: 8px;
}

.user-designation {
  font-family: 'Roboto';
  font-size: 14px;
  color: #594d6d;
  margin: 0px;
}

.delete-button {
  font-size: 30px;
  font-weight: 500;
  font-family: 'Roboto';
  color: #594d6d;
  padding-top: 6px;
  padding-bottom: 6px;
  padding-right: 12px;
  padding-left: 12px;
  margin-left: 12px;
  background-color: transparent;
  border: none;
  border-radius: 4px;
}

.delete-img {
  width: 15px;
  height: 15px;
}

//src/components/UserProfile/index.js

import './index.css'

const UserProfile = props => {
  const {userDetails} = props
  const {imageUrl, name, role} = userDetails
  return (
    <li className="user-card-container">
      <img src={imageUrl} className="profile-pic" alt="profile-pic" />
      <div className="user-details-container">
        <h1 className="user-name"> {name} </h1>
        <p className="user-designation"> {role} </p>
      </div>
    </li>
  )
}
export default UserProfile

//src/App.css

.app-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.list-container {
  list-style-type: none;
  padding: 0;
}

.title {
  font-family: 'Roboto';
  font-size: 32px;
  color: #183b56;
  margin-bottom: 30px;
}

//src/App.js

import {Component} from 'react'
import UserProfile from './components/UserProfile'

import './App.css'

const userDetailsList = [
  {
    uniqueNo: 1,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
    name: 'Esther Howard',
    role: 'Software Developer',
  },
  {
    uniqueNo: 2,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/floyd-miles-img.png',
    name: 'Floyd Miles',
    role: 'Software Developer',
  },
  {
    uniqueNo: 3,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/jacob-jones-img.png',
    name: 'Jacob Jones',
    role: 'Software Developer',
  },
  {
    uniqueNo: 4,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/devon-lane-img.png',
    name: 'Devon Lane',
    role: 'Software Developer',
  },
]

class App extends Component {
  render() {
    return (
      <div className="app-container">
        <h1 className="title">Users List</h1>
        <ul className="list-container">
          {userDetailsList.map(eachUser => (
            <UserProfile userDetails={eachUser} key={eachUser.uniqueNo} />
          ))}
        </ul>
      </div>
    )
  }
}

export default App

//src/index.js

import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root'),
)

package.json:

{
  "name": "searchable-users-list",
  "private": true,
  "version": "1.0.0",
  "engines": {
    "node": "^10.13 || 12 || 14 || 15",
    "npm": ">=6"
  },
  "dependencies": {
    "@testing-library/jest-dom": "5.11.9",
    "@testing-library/react": "11.2.5",
    "@testing-library/user-event": "12.6.2",
    "chalk": "4.1.0",
    "react": "17.0.1",
    "react-dom": "17.0.1"
  },
  "devDependencies": {
    "eslint-config-airbnb": "18.2.1",
    "eslint-config-prettier": "8.1.0",
    "eslint-plugin-prettier": "3.3.1",
    "husky": "4.3.8",
    "lint-staged": "10.5.4",
    "npm-run-all": "4.1.5",
    "prettier": "2.2.1",
    "react-scripts": "4.0.3"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "lint": "eslint .",
    "lint:fix": "eslint --fix src/",
    "format": "prettier --write \"./src\"",
    "run-all": "npm-run-all --parallel test lint:fix"
  },
  "lint-staged": {
    "*.js": [
      "npm run lint:fix"
    ],
    "*.{js, jsx, json, html, css}": [
      "npm run format"
    ]
  },
  "husky": {
    "hooks": {
      "pre-commit": "lint-staged"
    }
  },
  "jest": {
    "collectCoverageFrom": [
      "src/**/*.js"
    ]
  },
  "browserslist": {
    "development": [
      "last 2 chrome versions",
      "last 2 firefox versions",
      "last 2 edge versions"
    ],
    "production": [
      ">1%",
      "last 4 versions",
      "Firefox ESR",
      "not ie < 11"
    ]
  }
}

1. setState() Object Syntax
The setState() object syntax can be used while updating the state to the value that is independent of the previous state.

Syntax:

JS:

this.setState(
  {propertyName1: propertyValue1},
  {propertyName2: propertyValue2}
  // and many more...
);

1.1 Callback vs Object
Callback:

JS:

this.setState(prevState => {
  return { count: prevState.count + 1 };
});

It is used while updating the state to a value, which is computed based on the previous state.

Object:

JS:

this.setState({ quantity: 2 });

It is used while updating the state to a static value.

2. Sending Function as Callback
We can pass functions as props to child components.

Syntax:

JSX:

<ComponentName functionName={this.functionName} />

3. Input Element
In React, the Input Element value can be handled in two ways:

Controlled Input
Uncontrolled Input

3.1 Controlled Input
If the Input Element value is handled by a React State then it is called Controlled Input. Controlled Inputs are the React Suggested way to handle Input Element value.

Example:

JSX:

import {Component} from 'react'

class App extends Component {
  state = {
    searchInput: '',
  }

  onChangeSearchInput = event => {
    this.setState({
      searchInput: event.target.value,
    })
  }

  render() {
    const {searchInput} = this.state
    return (
      <input
        type="text"
        onChange={this.onChangeSearchInput}
        value={searchInput}
      />
    )
  }
}

export default App

3.2 Uncontrolled Input
If the Input Element value is handled by the browser itself then it is called Uncontrolled Input.

Uncontrolled inputs are like traditional HTML form inputs. Its value can only be set by a user, but not programmatically. However, in controlled input value is programmatically handled using React State.

Example:

JSX:

<input type="text" />

4. Searchable Users List Application

File: src/App.js

JSX:

import {Component} from 'react'
import UserProfile from './components/UserProfile'

import './App.css'

const initialUserDetailsList = [
  {
    uniqueNo: 1,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
    name: 'Esther Howard',
    role: 'Software Developer'
  },
  {
    uniqueNo: 2,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/floyd-miles-img.png',
    name: 'Floyd Miles',
    role: 'Software Developer'
  },
  {
    uniqueNo: 3,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/jacob-jones-img.png',
    name: 'Jacob Jones',
    role: 'Software Developer'
  },
  {
    uniqueNo: 4,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/devon-lane-img.png',
    name: 'Devon Lane',
    role: 'Software Developer'
  }
]

class App extends Component {
  state = {
    searchInput: '',
    usersDetailsList: initialUserDetailsList
  }

  onChangeSearchInput = event => {
    this.setState({
      searchInput: event.target.value
    })
  }

  deleteUser = uniqueNo => {
    const {usersDetailsList} = this.state
    const filteredUsersData = usersDetailsList.filter(
      each => each.uniqueNo !== uniqueNo
    )
    this.setState({
      usersDetailsList: filteredUsersData
    })
  }

  render() {
    const {searchInput, usersDetailsList} = this.state
    const searchResults = usersDetailsList.filter(eachUser =>
      eachUser.name.includes(searchInput)
    )
    return (
      <div className="app-container">
        <h1 className="title">Users List</h1>
        <input
          type="search"
          onChange={this.onChangeSearchInput}
          value={searchInput}
        />
        <ul className="list-container">
          {searchResults.map(eachUser => (
            <UserProfile
              userDetails={eachUser}
              key={eachUser.uniqueNo}
              deleteUser={this.deleteUser}
            />
          ))}
        </ul>
      </div>
    )
  }
}

export default App

File: src/components/UserProfile/index.js

JSX:

import './index.css'

const UserProfile = props => {
  const {userDetails, deleteUser} = props
  const {imageUrl, name, role, uniqueNo} = userDetails
  const onDelete = () => {
    deleteUser(uniqueNo)
  }
  return (
    <li className="user-card-container">
      <img src={imageUrl} className="profile-pic" alt="profile-pic" />
      <div className="user-details-container">
        <h1 className="user-name"> {name} </h1>
        <p className="user-designation"> {role} </p>
      </div>
      <button className="delete-button" onClick={onDelete}>
        <img
          src="https://assets.ccbp.in/frontend/react-js/cross-img.png"
          alt="cross"
          className="delete-img"
        />
      </button>
    </li>
  )
}

export default UserProfile

coding pratice-6:
----------------------------------------------------------

Random Number Generator:
----------------------------------

https://github.com/ManirathnamKuruma/ReactJS-RandomNumberGenerator

1.Completion Instructions:
Functionality to be added

The app must have the following functionalities

Initially, the number displayed should be 0
When Generate button is clicked, a random number should be generated in the range of 0 to 100 and displayed

2.Implementation Files:

Use these files to complete the implementation:

src/components/RandomNumberGenerator/index.js
src/components/RandomNumberGenerator/index.css

3.Quick Tips:
Click to view

You can use Math.random() function to get a random number (float value) in range 0 to less than 1 (0 <= randomNumber < 1)

Math.random()

You can use Math.ceil() function to round a number up to the next largest integer

console.log(Math.ceil(95.906698007537561)); // 96

You can use the box-shadow CSS property to apply the box-shadow effect to containers

box-shadow: 0px 4px 16px 0px #bfbfbf;

You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

cursor: pointer;

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

//src/components/RandomNumberGenerator/index.js

import {Component} from 'react'

import './index.css'

class RandomNumberGenerator extends Component {
  state = {
    randomNumber: 0,
  }

  onGenerateRandomNumber = () => {
    const newRandomNumber = Math.ceil(Math.random() * 100)

    this.setState({randomNumber: newRandomNumber})
  }

  render() {
    const {randomNumber} = this.state

    return (
      <div className="app-container">
        <div className="random-number-generator-container">
          <h1 className="heading">Random Number</h1>
          <p className="description">
            Generate a random number in the range of 0 to 100
          </p>
          <button
            type="button"
            className="generate-button"
            onClick={this.onGenerateRandomNumber}
          >
            Generate
          </button>
          <p className="random-number">{randomNumber}</p>
        </div>
      </div>
    )
  }
}

export default RandomNumberGenerator


//src/components/RandomNumberGenerator/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-image: url('https://assets.ccbp.in/frontend/react-js/random-no-generator-bg.png');
  background-size: cover;
  height: 100vh;
}

.random-number-generator-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #ffffff;
  width: 80%;
  border-radius: 16px;
  border: 1px solid #e4ebf3;
  padding: 36px;
  box-shadow: 0px 4px 16px 0px #eaebed;
}

@media screen and (min-width: 768px) {
  .random-number-generator-container {
    width: 35%;
    max-width: 500px;
  }
}

.heading {
  text-align: center;
  color: #0b69ff;
  font-family: 'Roboto';
  font-size: 20px;
  font-weight: 700;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 24px;
  }
}

.description {
  text-align: center;
  color: #333333;
  font-family: 'Roboto';
  font-size: 14px;
}

@media screen and (min-width: 768px) {
  .description {
    font-size: 18px;
  }
}

.generate-button {
  background-color: #0b69ff;
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
  border-radius: 8px;
  border: none;
  padding-top: 8px;
  padding-left: 16px;
  padding-right: 16px;
  padding-bottom: 8px;
  margin-top: 14px;
  outline: none;
  cursor: pointer;
}

.random-number {
  color: #0b69ff;
  font-family: 'Roboto';
  font-size: 40px;
  font-weight: 700;
  margin-top: 24px;
}

@media screen and (min-width: 768px) {
  .random-number {
    font-size: 48px;
  }
}

//src/App.js

import RandomNumberGenerator from './components/RandomNumberGenerator'

import './App.css'

const App = () => <RandomNumberGenerator />

export default App

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

//src/index.js

import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root'),
)

//src/setupTests.js

/* eslint-disable */

import '@testing-library/jest-dom'
import {configure} from '@testing-library/react'

configure({testIdAttribute: 'testid'})

Destination Search:
----------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-DestinationSearch

1.Completion Instructions:
Functionality to be added

The app must have the following functionalities

Initially, all destinations in the destinationsList should be displayed
When a value is provided in the search input, only the destinations whose names contain the value provided in the search input should be displayed irrespective of the case
The DestinationSearch component receives the destinationsList as a prop. It consists of a list of destination objects with the following properties in each destination object

Key		Data Type
id		Number
name	String
imgUrl	String

2.Implementation Files

Use these files to complete the implementation:

src/components/DestinationSearch/index.js
src/components/DestinationSearch/index.css
src/components/DestinationItem/index.js
src/components/DestinationItem/index.css

3.Important Note
Click to view

The following instructions are required for the tests to pass

The search for the destination should be case insensitive. You can use the toLowerCase method to convert a string into lower case letters.

JAVASCRIPT

const text = 'Learn JavaScript'
console.log(text.toLowerCase()); // learn javascript

Each DestinationItem should have an HTML image element with alt attribute value as the value of the key name in destinationsList

//src/components/DestinationSearch/index.js

import {Component} from 'react'

import DestinationItem from '../DestinationItem'

import './index.css'

class DestinationSearch extends Component {
  state = {
    searchInput: '',
  }

  onChangeSearchInput = event => {
    this.setState({searchInput: event.target.value})
  }

  render() {
    const {searchInput} = this.state
    const {destinationsList} = this.props
    const searchResults = destinationsList.filter(eachDestination =>
      eachDestination.name.toLowerCase().includes(searchInput.toLowerCase()),
    )

    return (
      <div className="app-container">
        <div className="destinations-search-container">
          <h1 className="heading">Destination Search</h1>
          <div className="search-input-container">
            <input
              type="search"
              className="search-input"
              placeholder="Search"
              value={searchInput}
              onChange={this.onChangeSearchInput}
            />
            <img
              src="https://assets.ccbp.in/frontend/react-js/destinations-search-icon-img.png"
              alt="search icon"
              className="search-icon"
            />
          </div>
          <ul className="destinations-list">
            {searchResults.map(eachDestination => (
              <DestinationItem
                key={eachDestination.id}
                destinationDetails={eachDestination}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default DestinationSearch

//src/components/DestinationSearch/index.css

.app-container {
  display: flex;
  justify-content: center;
}

.destinations-search-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 80%;
  max-width: 1140px;
}

@media screen and (min-width: 768px) {
  .destinations-search-container {
    align-items: flex-start;
  }
}

.heading {
  text-align: center;
  color: #252627;
  font-family: 'Roboto';
  font-size: 40px;
  font-weight: 700;
  margin-top: 48px;
  margin-left: 15px;
  margin-bottom: 32px;
}

@media screen and (min-width: 768px) {
  .heading {
    margin-top: 96px;
  }
}

.search-input-container {
  display: flex;
  background-color: #f1f5f9;
  border-radius: 8px;
  padding-top: 8px;
  padding-left: 16px;
  padding-bottom: 8px;
  padding-right: 16px;
  margin-left: 15px;
}

.search-input {
  color: #0f172a;
  background-color: #f1f5f9;
  font-family: 'Open Sans';
  font-size: 14px;
  font-weight: 500;
  border: none;
  outline: none;
}

.search-icon {
  height: 20px;
  width: 20px;
}

.destinations-list {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  padding-left: 0px;
  margin-top: 48px;
}

@media screen and (min-width: 768px) {
  .destinations-list {
    justify-content: flex-start;
  }
}

//src/components/DestinationItem/index.js

import './index.css'

const DestinationItem = props => {
  const {destinationDetails} = props
  const {imgUrl, name} = destinationDetails

  return (
    <li className="destination-item">
      <img src={imgUrl} alt={name} className="destination-image" />
      <p className="name">{name}</p>
    </li>
  )
}

export default DestinationItem

//src/components/DestinationItem/index.css

.destination-item {
  list-style-type: none;
  width: 235px;
  margin-left: 15px;
  margin-right: 15px;
  margin-bottom: 32px;
}

.destination-image {
  width: 235px;
  height: 175px;
}

.name {
  color: #000000;
  font-family: 'Roboto';
  font-size: 16px;
}

@media screen and (min-width: 768px) {
  .name {
    font-size: 20px;
  }
}

//src/App.js

import DestinationSearch from './components/DestinationSearch'

import './App.css'

const destinationsList = [
  {
    id: 1,
    name: 'Melaka Mosque',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/melaka-mosque-img.png',
  },
  {
    id: 2,
    name: 'Shrubland',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/shrubland-img.png',
  },
  {
    id: 3,
    name: 'New York',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/new-york-img.png',
  },
  {
    id: 4,
    name: 'Escarpment',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/escarpment-img.png',
  },
  {
    id: 5,
    name: 'Westminster Abbey',
    imgUrl:
      'https://assets.ccbp.in/frontend/react-js/westminster-abbey-img.png',
  },
  {
    id: 6,
    name: 'South Downs National Park',
    imgUrl:
      'https://assets.ccbp.in/frontend/react-js/south-downs-national-park-img.png',
  },
  {
    id: 7,
    name: 'National Historic Site',
    imgUrl:
      'https://assets.ccbp.in/frontend/react-js/national-historic-site-img.png',
  },
  {
    id: 8,
    name: 'Tower Bridge',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/tower-bridge-img.png',
  },
  {
    id: 9,
    name: 'Arc Here',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/arc-here-img.png',
  },
  {
    id: 10,
    name: 'Steeple',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/steeple-img.png',
  },
  {
    id: 11,
    name: 'Glaciokarst',
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/glaciokarst-img.png',
  },
  {
    id: 12,
    name: 'Parco Nazionale delle Cinque Terre',
    imgUrl:
      'https://assets.ccbp.in/frontend/react-js/parco-nazionale-delle-cinque-terre-img.png',
  },
]

const App = () => <DestinationSearch destinationsList={destinationsList} />

export default App

//App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}


simple todos:
---------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-SimpleTodos

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

Initially, the list of given todos should be displayed with a delete button for each todo
When Delete button of a todo is clicked, then the respective todo should be deleted
The SimpleTodos will consist of the initialTodosList. It consists of a list of todo objects with the following properties in each todo object

Key		Data Type
id		Number
title	String

2.Implementation Files

Use these files to complete the implementation:

src/components/SimpleTodo/index.js
src/components/SimpleTodo/index.css
src/components/TodoItem/index.js
src/components/TodoItem/index.css

3.Quick Tips
Click to view

You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

cursor: pointer;

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

//src/components/SimpleTodo/index.js

import {Component} from 'react'

import TodoItem from '../TodoItem'

import './index.css'

const initialTodosList = [
  {
    id: 1,
    title: 'Book the ticket for today evening',
  },
  {
    id: 2,
    title: 'Rent the movie for tomorrow movie night',
  },
  {
    id: 3,
    title: 'Confirm the slot for the yoga session tomorrow morning',
  },
  {
    id: 4,
    title: 'Drop the parcel at Bloomingdale',
  },
  {
    id: 5,
    title: 'Order fruits on Big Basket',
  },
  {
    id: 6,
    title: 'Fix the production issue',
  },
  {
    id: 7,
    title: 'Confirm my slot for Saturday Night',
  },
  {
    id: 8,
    title: 'Get essentials for Sunday car wash',
  },
]

class SimpleTodos extends Component {
  state = {
    todosList: initialTodosList,
  }

  deleteTodo = id => {
    const {todosList} = this.state
    const updatedTodosList = todosList.filter(eachTodo => eachTodo.id !== id)

    this.setState({
      todosList: updatedTodosList,
    })
  }

  render() {
    const {todosList} = this.state

    return (
      <div className="app-container">
        <div className="simple-todos-container">
          <h1 className="heading">Simple Todos</h1>
          <ul className="todos-list">
            {todosList.map(eachTodo => (
              <TodoItem
                key={eachTodo.id}
                todoDetails={eachTodo}
                deleteTodo={this.deleteTodo}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default SimpleTodos

//src/components/SimpleTodo/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #ffc2a0;
  min-height: 100vh;
}

.simple-todos-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #ffffff;
  border-radius: 16px;
  width: 90%;
  padding: 24px;
  margin-top: 48px;
  margin-bottom: 48px;
  max-width: 1110px;
}

@media screen and (min-width: 768px) {
  .simple-todos-container {
    padding: 48px;
    margin-top: 96px;
    margin-bottom: 96px;
  }
}

.heading {
  color: #ff8542;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 700;
  margin-top: 12px;
  margin-bottom: 16px;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 48px;
    margin-top: 32px;
    margin-bottom: 48px;
  }
}

.todos-list {
  padding-left: 0px;
}

//src/components/TodoItem/index.js

import './index.css'

const TodoItem = props => {
  const {todoDetails, deleteTodo} = props
  const {id, title} = todoDetails

  const onDeleteTodo = () => {
    deleteTodo(id)
  }

  return (
    <li className="todo-item">
      <p className="title">{title}</p>
      <button type="button" className="delete-btn" onClick={onDeleteTodo}>
        Delete
      </button>
    </li>
  )
}

export default TodoItem

//src/components/TodoItem/index.css

.todo-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  list-style-type: none;
}

.title {
  color: #000000;
  font-family: 'Roboto';
  font-size: 16px;
}

@media screen and (min-width: 768px) {
  .title {
    font-size: 24px;
  }
}

.delete-btn {
  background-color: #ffffff;
  color: #ff0b37;
  font-family: 'Roboto';
  font-size: 12px;
  border-radius: 8px;
  border: 1px solid #ff0b37;
  padding-top: 4px;
  padding-left: 8px;
  padding-bottom: 4px;
  padding-right: 8px;
  margin-left: 16px;
  outline: none;
  cursor: pointer;
}

@media screen and (min-width: 768px) {
  .delete-btn {
    font-size: 18px;
    padding-top: 8px;
    padding-left: 16px;
    padding-bottom: 8px;
    padding-right: 16px;
    margin-left: 32px;
  }
}

//src/App.js

import SimpleTodos from './components/SimpleTodos'

import './App.css'

const App = () => <SimpleTodos />

export default App

coding pratice-7:
---------------------------------------------------------------------------------------

Cash Withdrawal:
-------------------------------

https://github.com/ManirathnamKuruma/ReactJS-CashWithdrawal

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

Initially, the balance should be 2000 rupees
When a denomination is clicked, then the respective value should be deducted from the balance available
The CashWithdrawal component receives the denominationsList as a prop. It consists of a list of denomination objects with the following properties in each denomination object

Key		Data Type
id		Number
value	Number

2.Implementation Files

Use these files to complete the implementation:

src/components/CashWithdrawal/index.js
src/components/CashWithdrawal/index.css
src/components/DenominationItem/index.js
src/components/DenominationItem/index.css

3.Quick Tips
Click to view

The string method slice() extracts a section of a string and returns it as a new string, without modifying the original string

const text = "The quick brown fox";
console.log(text.slice(0, 3)); // The
console.log(text.slice(2, 3)); // e

You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

cursor: pointer;

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

//src/components/CashWithdrawal/index.js

import {Component} from 'react'

import DenominationItem from '../DenominationItem'

import './index.css'

class CashWithdrawal extends Component {
  state = {
    balance: 2000,
  }

  updateBalance = value => {
    this.setState(prevState => ({balance: prevState.balance - value}))
  }

  render() {
    const {denominationsList} = this.props
    const {balance} = this.state
    const name = 'Sarah Williams'
    const initial = name.slice(0, 1)

    return (
      <div className="app-container">
        <div className="cash-withdrawal-container">
          <div className="user-details-container">
            <div className="initial-container">
              <p className="initial">{initial}</p>
            </div>
            <p className="name">{name}</p>
          </div>
          <div className="balance-container">
            <p className="your-balance">Your Balance</p>
            <p className="balance">
              {balance}
              <br />
              <span className="currency">In Rupees</span>
            </p>
          </div>
          <p className="withdraw">Withdraw</p>
          <p className="choose-sum">CHOOSE SUM (IN RUPEES)</p>
          <ul className="denominations-list">
            {denominationsList.map(eachDenomination => (
              <DenominationItem
                key={eachDenomination.id}
                denominationDetails={eachDenomination}
                updateBalance={this.updateBalance}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default CashWithdrawal

//src/components/CashWithdrawal/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.cash-withdrawal-container {
  background-color: #150b3e;
  width: 80%;
  border-radius: 16px;
  padding-top: 24px;
  padding-left: 18px;
  padding-bottom: 8px;
  padding-right: 18px;
  max-width: 350px;
}

@media screen and (min-width: 768px) {
  .cash-withdrawal-container {
    width: 50%;
    padding-top: 48px;
    padding-left: 36px;
    padding-bottom: 16px;
    padding-right: 36px;
    max-width: 422px;
  }
}

.user-details-container {
  display: flex;
}

.initial-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #c7d2fe;
  height: 48px;
  width: 48px;
  border-radius: 24px;
}

@media screen and (min-width: 768px) {
  .initial-container {
    height: 64px;
    width: 64px;
    border-radius: 32px;
  }
}

.initial {
  color: #7c3aed;
  font-family: 'Roboto';
  font-size: 14px;
}

.name {
  color: #d4d2db;
  font-family: 'Roboto';
  font-size: 16px;
  margin-left: 8px;
}

@media screen and (min-width: 768px) {
  .name {
    font-size: 20px;
    margin-left: 16px;
  }
}

.balance-container {
  display: flex;
  justify-content: space-between;
  margin-top: 24px;
}

.your-balance {
  color: #585076;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  margin-top: 4px;
}

@media screen and (min-width: 768px) {
  .your-balance {
    font-size: 20px;
    margin-top: 8px;
  }
}

.balance {
  color: #d4d2db;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 500;
  margin: 0;
}

@media screen and (min-width: 768px) {
  .balance {
    font-size: 32px;
  }
}

.currency {
  color: #585076;
  font-size: 12px;
  font-weight: 500;
}

@media screen and (min-width: 768px) {
  .currency {
    font-size: 12px;
  }
}

.withdraw {
  color: #d4d2db;
  font-family: 'Roboto';
  font-size: 20px;
  font-weight: 500;
  margin-top: 16px;
}

@media screen and (min-width: 768px) {
  .withdraw {
    font-size: 24px;
    margin-top: 24px;
  }
}

.choose-sum {
  color: #585076;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
  margin-bottom: 12px;
}

@media screen and (min-width: 768px) {
  .choose-sum {
    font-size: 16px;
    margin-bottom: 24px;
  }
}

.denominations-list {
  padding-left: 0px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

//src/components/DenominationItem/index.js

import './index.css'

const DenominationItem = props => {
  const {denominationDetails, updateBalance} = props
  const {value} = denominationDetails

  const onClickDenomination = () => {
    updateBalance(value)
  }

  return (
    <li className="denomination-item">
      <button
        type="button"
        className="denomination-button"
        onClick={onClickDenomination}
      >
        {value}
      </button>
    </li>
  )
}

export default DenominationItem

//src/components/DenominationItem/index.css

.denomination-item {
  list-style-type: none;
  width: 48%;
  margin-bottom: 16px;
}

.denomination-button {
  background-color: #382f5a;
  color: #d4d2db;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  width: 100%;
  border-radius: 4px;
  border: 1px solid #c4c4c4;
  padding-top: 4px;
  padding-bottom: 4px;
  cursor: pointer;
  outline: none;
}

@media screen and (min-width: 768px) {
  .denomination-button {
    font-size: 24px;
  }
}

//src/App.js

import CashWithdrawal from './components/CashWithdrawal'

import './App.css'

const denominationsList = [
  {
    id: 1,
    value: 50,
  },
  {
    id: 2,
    value: 100,
  },
  {
    id: 3,
    value: 200,
  },
  {
    id: 4,
    value: 500,
  },
]

const App = () => <CashWithdrawal denominationsList={denominationsList} />

export default App

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

Google Search Suggestions:
-----------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-GoogleSearchSuggestions

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

Initially, all suggestions in the suggestionsList should be displayed

When a value is provided in the search input, then display the suggestions which includes the search input irrespective of case
When the arrow of a suggestion is clicked, then the value of the search input should be updated with the respective suggestion clicked
The GoogleSuggestions component receives the suggestionsList as a prop. It consists of a list of suggestion objects with the following properties in each suggestion object

Key			Data Type
id			Number
suggestion	String

2.Implementation Files

Use these files to complete the implementation:

src/components/GoogleSuggestions/index.js
src/components/GoogleSuggestions/index.css
src/components/SuggestionItem/index.js
src/components/SuggestionItem/index.css

3.Quick Tips
Click to view

You can use the box-shadow CSS property to apply the box-shadow effect to containers

box-shadow: 0px 4px 16px 0px #bfbfbf;

You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

cursor: pointer;

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

//src/components/GoogleSuggestions/index.js

import {Component} from 'react'

import SuggestionItem from '../SuggestionItem'

import './index.css'

class GoogleSuggestions extends Component {
  state = {
    searchInput: '',
  }

  updateSearchInput = value => {
    this.setState({
      searchInput: value,
    })
  }

  onChangeSearchInput = event => {
    this.setState({
      searchInput: event.target.value,
    })
  }

  render() {
    const {searchInput} = this.state
    const {suggestionsList} = this.props
    const searchResults = suggestionsList.filter(eachSuggestion =>
      eachSuggestion.suggestion
        .toLowerCase()
        .includes(searchInput.toLowerCase()),
    )

    return (
      <div className="app-container">
        <div className="google-suggestions-container">
          <img
            src="https://assets.ccbp.in/frontend/react-js/google-logo.png"
            alt="google logo"
            className="google-logo"
          />
          <div className="search-input-suggestions-container">
            <div className="search-input-container">
              <img
                alt="search icon"
                className="search-icon"
                src="https://assets.ccbp.in/frontend/react-js/google-search-icon.png"
              />
              <input
                type="search"
                className="search-input"
                placeholder="Search Google"
                onChange={this.onChangeSearchInput}
                value={searchInput}
              />
            </div>
            <ul className="suggestions-list">
              {searchResults.map(eachSuggestion => (
                <SuggestionItem
                  key={eachSuggestion.id}
                  suggestionDetails={eachSuggestion}
                  updateSearchInput={this.updateSearchInput}
                />
              ))}
            </ul>
          </div>
        </div>
      </div>
    )
  }
}

export default GoogleSuggestions

//src/components/GoogleSuggestions/index.css

.app-container {
  display: flex;
  justify-content: center;
}

.google-suggestions-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 125px;
}

@media screen and (min-width: 768px) {
  .google-suggestions-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 250px;
  }
}

.google-logo {
  width: 150px;
  height: 55px;
}

@media screen and (min-width: 768px) {
  .google-logo {
    width: 432px;
    height: 140px;
  }
}

.search-input-suggestions-container {
  width: 300px;
  border-radius: 12px;
  margin-top: 24px;
  box-shadow: 0px 0px 10px 0px #bfbfbf;
}

@media screen and (min-width: 768px) {
  .search-input-suggestions-container {
    width: 600px;
    border-radius: 20px;
    margin-top: 48px;
  }
}

.search-input-container {
  display: flex;
  align-items: center;
  padding-top: 4px;
  padding-left: 8px;
  padding-bottom: 4px;
  padding-right: 8px;
}

@media screen and (min-width: 768px) {
  .search-input-container {
    display: flex;
    align-items: center;
    padding-top: 4px;
    padding-left: 12px;
    padding-bottom: 4px;
    padding-right: 12px;
  }
}

.search-icon {
  width: 16px;
  height: 16px;
}

@media screen and (min-width: 768px) {
  .search-icon {
    width: 24px;
    height: 24px;
  }
}

.search-input {
  color: #64748b;
  font-family: 'Roboto';
  font-size: 16px;
  width: 100%;
  height: 40px;
  border: none;
  margin-left: 16px;
  outline: none;
}

@media screen and (min-width: 768px) {
  .search-input {
    font-size: 20px;
    height: 40px;
    margin-left: 8px;
  }
}

.suggestions-list {
  padding-left: 12px;
  padding-right: 16px;
  padding-bottom: 12px;
  margin: 0;
}

@media screen and (min-width: 768px) {
  .suggestions-list {
    padding-left: 24px;
    padding-right: 32px;
    padding-bottom: 24px;
  }
}

//src/components/SuggestionItem/index.js

import './index.css'

const SuggestionItem = props => {
  const {suggestionDetails, updateSearchInput} = props
  const {suggestion} = suggestionDetails

  const onClickSuggestion = () => {
    updateSearchInput(suggestion)
  }

  return (
    <li className="suggestion-item">
      <p className="suggestion-text">{suggestion}</p>
      <button
        type="button"
        className="arrow-button"
        onClick={onClickSuggestion}
      >
        <img
          src="https://assets.ccbp.in/frontend/react-js/diagonal-arrow-left-up.png"
          alt="arrow"
          className="arrow"
        />
      </button>
    </li>
  )
}

export default SuggestionItem


//src/components/SuggestionItem/index.css

.suggestion-item {
  display: flex;
  justify-content: space-between;
  margin-top: 16px;
  list-style-type: none;
}

.suggestion-text {
  color: #475569;
  font-family: 'Roboto';
  font-size: 16px;
  margin: 0;
}

@media screen and (min-width: 768px) {
  .suggestion-text {
    font-size: 20px;
  }
}

.arrow-button {
  background-color: transparent;
  border: none;
  outline: none;
  cursor: pointer;
}

.arrow {
  height: 16px;
  width: 16px;
}

@media screen and (min-width: 768px) {
  .arrow {
    height: 24px;
    width: 24px;
  }
}

//src/App.js

import GoogleSuggestions from './components/GoogleSuggestions'

import './App.css'

const suggestionsList = [
  {id: 1, suggestion: 'Price of Ethereum'},
  {id: 2, suggestion: 'Oculus Quest 2 specs'},
  {id: 3, suggestion: 'Tesla Share Price'},
  {id: 4, suggestion: 'Price of Ethereum today'},
  {id: 5, suggestion: 'Latest trends in AI'},
  {id: 6, suggestion: 'Latest trends in ML'},
]

const App = () => <GoogleSuggestions suggestionsList={suggestionsList} />

export default App

coding pratice-8:
----------------------------------------------------------------------------------------------------------------------------------------

Letters Calculator:
--------------------------------

https://github.com/ManirathnamKuruma/ReactJS-LettersCalculator

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

When a non-empty value is provided in the input, then the count of letters provided should be displayed

2.Implementation Files

Use these files to complete the implementation:

src/components/LettersCalculator/index.js
src/components/LettersCalculator/index.css

3.Quick Tips
Click to view

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

//src/components/LettersCalculator/index.js

import {Component} from 'react'

import './index.css'

class LettersCalculator extends Component {
  state = {
    inputPhrase: '',
  }

  onChangeInputPhrase = event => {
    const {value} = event.target

    this.setState({inputPhrase: value})
  }

  render() {
    const {inputPhrase} = this.state

    return (
      <div className="app-container">
        <div className="letters-calculator-container">
          <div className="calculator-container">
            <h1 className="heading">Calculate the Letters you enter</h1>
            <div className="input-phrase-container">
              <label className="label" htmlFor="phraseText">
                Enter the phrase
              </label>
              <input
                className="letters-input"
                id="phraseText"
                onChange={this.onChangeInputPhrase}
                placeholder="Enter the phrase"
                type="text"
                value={inputPhrase}
              />
            </div>
            <p className="letters-count">No.of letters: {inputPhrase.length}</p>
          </div>
          <img
            alt="letters calculator"
            className="letters-calculator-image"
            src="https://assets.ccbp.in/frontend/react-js/stop-watch-with-calculator-img.png"
          />
        </div>
      </div>
    )
  }
}

export default LettersCalculator

//src/components/LettersCalculator/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-image: linear-gradient(to right, #1d976c 0%, #93f9b9 107%);
  height: 100vh;
}

.letters-calculator-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 90%;
}

@media screen and (min-width: 992px) {
  .letters-calculator-container {
    flex-direction: row;
  }
}

.calculator-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  order: 1;
}

@media screen and (min-width: 992px) {
  .calculator-container {
    align-items: flex-start;
    order: 0;
  }
}

.heading {
  text-align: center;
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: bold;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 46px;
  }
}

@media screen and (min-width: 992px) {
  .heading {
    text-align: start;
    font-size: 46px;
  }
}

.input-phrase-container {
  display: flex;
  flex-direction: column;
}

.label {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: bold;
}

.letters-input {
  color: #ffffff;
  background-color: transparent;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  border: 1px solid #e4e7eb;
  border-radius: 4px;
  margin-top: 8px;
  padding-top: 8px;
  padding-right: 12px;
  padding-bottom: 8px;
  padding-left: 12px;
  outline: none;
}

@media screen and (min-width: 768px) {
  .letters-input {
    width: 350px;
  }
}

.letters-count {
  align-self: center;
  color: #219a6f;
  background-color: #ffffff;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: bold;
  border-radius: 12px;
  margin-top: 32px;
  padding: 18px;
  padding-right: 24px;
  padding-left: 24px;
}

@media screen and (min-width: 992px) {
  .letters-count {
    align-self: start;
    padding: 24px;
    padding-right: 32px;
    padding-left: 32px;
  }
}

@media screen and (min-width: 1200px) {
  .letters-count {
    padding: 30px;
    padding-right: 38px;
    padding-left: 38px;
  }
}

.letters-calculator-image {
  width: 100%;
  order: 0;
}

@media screen and (min-width: 992px) {
  .letters-calculator-image {
    width: 550px;
    order: 1;
  }
}

@media screen and (min-width: 1200px) {
  .letters-calculator-image {
    width: 700px;
  }
}

//src/App.js

import LettersCalculator from './components/LettersCalculator'

import './App.css'

const App = () => <LettersCalculator />

export default App

Common Mistakes | Cheat Sheet:
----------------------------------------------------------------------------------------------

Concepts in Focus:

Missing Export Statement
Missing Import Statement
Missing Extending the React Component Class
class vs className
onclick vs onClick
Event Listeners inside Class Component
Passing Event Handler
Modifying the State Directly
Calling setState() from render()
Invoking Event Handler
setState() is Asynchronous
React Component should return a single JSX element
	Fragments
Props are Read-only

1. Missing Export Statement
Mistake:

File: src/App.js

JSX:

import Counter from './components/Counter'

const App = () => {
  return <Counter />
}

export default App

File: src/components/Counter/index.js

JSX:

import { Component } from 'react'

import './index.css'

class Counter extends Component {
  render() {
    return (
      <p className="counter">Counter</p>
    )
  }
}

2. Missing Import Statement

Mistake:

File: src/App.js

const App = () => {
  return <Counter />
}

export default App

File: src/components/Counter/index.js

import { Component } from 'react'

import './index.css'

class Counter extends Component {
  render() {
    return (
      <p className="counter">Counter</p>
    )
  }
}

export default Counter

3. Missing Extending the React Component Class

Mistake:

File: src/App.js

import Counter from './components/Counter'

const App = () => {
  return <Counter />
}

export default App

File: src/components/Counter/index.js

import './index.css'

class Counter {
  render() {
    return (
      <p className="counter">Counter</p>
    )
  }
}

export default Counter

4. class vs className

Mistake:

File: src/components/Counter/index.js

import { Component } from 'react'

import './index.css'

class Counter extends Component {
  render() {
    return (
      <p class="counter">Counter</p>
    )
  }
}

export default Counter

5. onclick vs onClick

Mistake:

File: src/components/Counter/index.js

import { Component } from 'react'

import './index.css'

class Counter extends Component {
  onIncrement = () => {
    console.log("on increment called")
  }
  render() {
    return (
      <p className="counter">Counter</p>
      <button onclick={this.onIncrement}>Increase</button>
    )
  }
}

export default Counter

6. Event Listeners inside Class Component
Mistake:

File: src/components/Counter/index.js

import { Component } from 'react'

import './index.css'

class Counter extends Component {
  state = { count: 0 }
  onIncrement() {
    const {count} = this.state
    console.log(count)
  }
  render() {
    return (
      <p className="counter">Counter</p>
      <button onClick={this.onIncrement}>Increase</button>
    )
  }
}

export default Counter

Solution:

onIncrement = () => {
  const {count} = this.state;
  console.log(count);
};

In Arrow functions, this refers to the context in which the code is defined.

7. Passing Event Handler

Mistake:

File: src/components/Counter/index.js

import { Component } from 'react'

import './index.css'

class Counter extends Component {
  state = {count: 0}
  onIncrement = () => {
    this.setState(prevState => ({
      count: prevState.count + 1
    }))
  }
  render() {
    return <button onClick={onIncrement}>Increase</button> 
  }
}

export default Counter

Solution:

<button onClick={this.onIncrement}>Increase</button>

8. Modifying the State Directly

Modifying the state directly won't trigger the render() method.

Mistake:

onIncrement = () => {
  this.state.count = this.state.count + 1;
};

Solution:

onIncrement = () => {
  this.setState(prevState => ({
    count: prevState.count + 1
  }));
};

Updating Object

Mistake:

state = {
  person: {name: "Rahul", age: 30}
}

onUpdateAge = () => {
  const {person} = this.state
  person.age = 29
}

Solution:

state = {
  person: {name: "Rahul", age: 30}
}

onUpdateAge = () => {
  const {person} = this.state
  const newPerson = {...person, age: 29}
  this.setState({person: newPerson})
}

Updating List

Mistake:

state = { numbers: [1, 2, 3] }

onUpdateNumbers = () => {
  const {numbers} = this.state
  numbers.push(4)
}

Solution:

state = {numbers: [1, 2, 3]}

onUpdateNumbers = () => {
  const {numbers} = this.state
  const updatedNumbers = [...numbers, 4]
  this.setState({numbers: updatedNumbers})
}

9. Calling setState() from render()

Mistake:

render() {
  this.setState({ count: 0 })
  return ({...})
}

Specifying a new state with setState() function causes a new render. If we call setState from the render() function, this will cause an infinite loop.

When we call setState from the render() function, it will cause an infinite loop.

10. Invoking Event Handler

Mistake:

import { Component } from 'react'

import './index.css'

class Counter extends Component {
  state = {count: 0}
  onIncrement = () => {
    this.setState(prevState => ({
      count: prevState.count + 1
    }))
  }
  render() {
    return (
      <p className="counter">Counter</p>
      <button onClick={this.onIncrement()}>Increase</button>
    )
  }
}

export default Counter

Solution:

import { Component } from 'react'

import './index.css'

class Counter extends Component {
  state = {count: 0}
  onIncrement = () => {
    this.setState(prevState => ({
      count: prevState.count + 1
    }))
  }
  render() {
    return (
      <p className="counter">Counter</p>
      <button onClick={this.onIncrement}>Increase</button>
    )
  }
}

export default Counter

11. setState() is Asynchronous
setState() does not update state immediately.

Mistake:

import { Component } from 'react'

import './index.css'

class Counter extends Component {
  state = {count: 0}
  onIncrement = () => {
    const {count} = this.state;
    this.setState(prevState => ({
      count: prevState.count + 1
    }))
    console.log(count)
  }
  render() {
    return (
      <p className="counter">Counter</p>
      <button onClick={this.onIncrement}>Increase</button>
    )
  }
}

export default Counter

12. React Component should return a single JSX element
Mistake:

const Welcome = () => (
  <h1>Hello, User</h1>
  <p>You are learning React</p>
)

export default Welcome

import Welcome from'./components/Welcome'
const App = () => <Welcome />
export default App

12.1 Fragments
The fragment is an alternate way to return a single JSX element. It groups a list of children without adding extra nodes to the DOM.

import {Fragment} from 'react'

const Welcome = () => (
  <Fragment>
    <h1>Hello, User</h1>
    <p>You are learning React</p>
  </Fragment>
)

export default Welcome

Short Syntax:

const Welcome = () => (
   <>
     <h1>Hello, User</h1>
     <p>You are learning React</p>
   </>
)

export default Welcome

13. Props are Read-only
Mistake:

File: src/App.js

import Welcome from './components/Welcome'
const App = () => <Welcome name="Rahul" />
export default App

File: src/components/Welcome/index.js

const Welcome = props => {
  props.name = 'Ramu'
  const {name} = props
  return (
    <>
      <h1>Hello, {name}</h1>
      <p>You are learning React</p>
    </>
  )
}

export default Welcome

coding pratice-9:
--------------------------------------------------------------------------------------------------------

Debugging Counter:
---------------------------

1.Set Up Instructions:

Click to view:

Download dependencies by running npm install
Start up the app using npm start

2.Completion Instructions:
Functionality to be fixed

Fix the given code to have the following functionality

Initially, the count should be 0
When the Increase button is clicked, then the count should be incremented by one
When the Decrease button is clicked, then the count should be decremented by one

3.Quick Tips
Click to view

There are 7 bugs to be fixed to achieve the functionality and the UI that is expected

Initial code:
------------------

//src/components/Counter/index.js

import Component from 'react'

import './index.css'

class Counter {
  state = {count: 0}

  onDecrement = () => {
    this.state.count = this.state.count - 1;
  }

  onIncrement = () => {
    this.state.count = this.state.count + 1;
  }

  render() {
    {count} = this.state

    return (
      <div className="app-container">
        <h1 className="count">Count {count}</h1>
        <button className="button" onClick={this.onDecrement()} type="button">
          Increase
        </button>
        <button className="button" onClick={this.onIncrement()} type="button">
          Decrease
        </button>
      </div>
    )
  }
}

export default Counter

Solution:
--------------

//src/components/Counter/index.js

// FIX1: The import statement for Component class should be written like this
import {Component} from 'react'

import './index.css'

// FIX2: To create a class component we need to extend the React "Component" class
class Counter extends Component {
  state = {count: 0}

  onDecrement = () => {
    // FIX3: The state should be updated using "setState" method
    this.setState(prevState => ({count: prevState.count - 1}))
  }

  onIncrement = () => {
    // FIX4: The state should be updated using "setState" method
    this.setState(prevState => ({count: prevState.count + 1}))
  }

  render() {
    // FIX5: We should use const to avoid reassigning a value to the variable
    const {count} = this.state

    return (
      <div className="app-container">
        <h1 className="count">Count {count}</h1>
        {/* FIX6: The event handler onIncrement, should be passed as a reference to the onClick attribute */}
        <button className="button" onClick={this.onIncrement} type="button">
          Increase
        </button>
        {/* FIX7: The event handler onDecrement, should be passed as a reference to the onClick attribute */}
        <button className="button" onClick={this.onDecrement} type="button">
          Decrease
        </button>
      </div>
    )
  }
}

export default Counter

//src/components/Counter/index.css

.app-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
}

.count {
  font-size: 80px;
  font-family: 'Roboto';
  color: #2e3e4e;
  margin-top: 8px;
  margin-bottom: 20px;
}

.button {
  font-size: 16px;
  font-weight: 400;
  font-family: 'Roboto';
  color: #ffffff;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-right: 15px;
  padding-left: 15px;
  margin: 8px;
  background-color: #7c69e9;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  outline: none;
}

//src/App.js

import Counter from './components/Counter'

import './App.css'

const App = () => <Counter />

export default App

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

Debugging Fruits Counter:
-------------------------------

1.Completion Instructions:

Functionality to be fixed

Fix the given code to have the following functionality

Initially, the count of the eaten mangoes should be four and the count of the eaten bananas should be five
When the Eat Mango button is clicked, then the count of the mangoes eaten should be incremented by one
When the Eat Banana button is clicked, then the count of the bananas eaten should be incremented by one

2.Quick Tips
Click to view

There are 8 bugs to be fixed to achieve the functionality and the UI that is expected

Initial code:
--------------------

//src/components/FruitsCounter/index.js

import {Component} from 'react'

import './index.css'

class FruitsCounter extends Component {
  state = {}

  onClickEatBanana() {
    this.setState(prevState => ({bananasCount: prevState.bananasCount + 1}))
  }

  onClickEatMango() {
    this.setState(prevState => ({mangoesCount: prevState.mangoesCount + 1}))
  }

  render() {
    const {mangoesCount, bananasCount} = state

    return (
      <div class="app-container">
        <div class="fruits-counter">
          <h1 class="count-text">
            Bob ate <span class="count">{mangoesCount}</span> mangoes
            <span class="count"> {bananasCount}</span> bananas
          </h1>
          <div class="counters-control-container">
            <div class="counter-control">
              <img
                src="https://assets.ccbp.in/frontend/react-js/mango-img.png"
                alt="banana"
                class="fruit-image"
              />
              <div class="button-container">
                <button
                  type="button"
                  class="button"
                  onclick={this.onClickEatMango()}
                >
                  Eat Mango
                </button>
              </div>
            </div>
            <div class="counter-control">
              <img
                src="https://assets.ccbp.in/frontend/react-js/banana-img.png"
                alt="banana"
                class="fruit-image"
              />
              <div class="button-container">
                <button
                  type="button"
                  class="button"
                  onclick={this.onClickEatBanana()}
                >
                  Eat Banana
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default FruitsCounter

Solution:
-------------------

//src/components/FruitsCounter/index.js

import {Component} from 'react'

import './index.css'

class FruitsCounter extends Component {
  //  FIX1: Initialize the state with values as below
  state = {
    mangoesCount: 4,
    bananasCount: 5,
  }

  //  FIX2: Class methods should be defined using arrow functions
  onClickEatBanana = () => {
    this.setState(prevState => ({bananasCount: prevState.bananasCount + 1}))
  }

  //  FIX3: Class methods should be defined using arrow functions
  onClickEatMango = () => {
    this.setState(prevState => ({mangoesCount: prevState.mangoesCount + 1}))
  }

  render() {
    //  FIX4: The state should be accessed using "this"
    const {mangoesCount, bananasCount} = this.state

    return (
      // FIX5: When assigning css class to HTML element in JSX, we have to use the attribute as "className"
      <div className="app-container">
        <div className="fruits-counter">
          <h1 className="count-text">
            Bob ate <span className="count">{mangoesCount}</span> mangoes
            <span className="count"> {bananasCount}</span> bananas
          </h1>
          <div className="counters-control-container">
            <div className="counter-control">
              <img
                src="https://assets.ccbp.in/frontend/react-js/mango-img.png"
                // FIX6: The alt attribute value of this image should be "mango"
                alt="mango"
                className="fruit-image"
              />
              <div className="button-container">
                <button
                  type="button"
                  className="button"
                  //   FIX7: The event handler should be passed as a reference to the onClick attribute
                  onClick={this.onClickEatMango}
                >
                  Eat Mango
                </button>
              </div>
            </div>
            <div className="counter-control">
              <img
                src="https://assets.ccbp.in/frontend/react-js/banana-img.png"
                alt="banana"
                className="fruit-image"
              />
              <div className="button-container">
                <button
                  type="button"
                  className="button"
                  //   FIX8: The event handler should be passed as a reference to the onClick attribute
                  onClick={this.onClickEatBanana}
                >
                  Eat Banana
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default FruitsCounter

//src/components/FruitsCounter/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #ffd569;
  height: 100vh;
}

.fruits-counter {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #ffffff;
  border-radius: 16px;
  width: 90%;
  padding: 24px;
  max-width: 1110px;
}

@media screen and (min-width: 768px) {
  .fruits-counter {
    width: 80%;
    padding-top: 96px;
    padding-left: 64px;
    padding-right: 64px;
    padding-bottom: 96px;
  }
}

.count-text {
  text-align: center;
  color: #000000;
  font-family: 'Roboto';
  font-size: 20px;
  font-weight: 700;
}

@media screen and (min-width: 768px) {
  .count-text {
    font-size: 48px;
  }
}

.count {
  color: #ffd569;
}

.counters-control-container {
  display: flex;
  flex-direction: column;
}

@media screen and (min-width: 768px) {
  .counters-control-container {
    flex-direction: row;
  }
}

.counter-control {
  display: flex;
  flex-direction: column;
  margin-top: 32px;
  margin-left: 16px;
  margin-right: 16px;
}

@media screen and (min-width: 768px) {
  .counter-control {
    margin-top: 96px;
    margin-left: 48px;
    margin-right: 48px;
  }
}

.fruit-image {
  width: 200px;
  height: 175px;
}

@media screen and (min-width: 992px) {
  .fruit-image {
    width: 296px;
    height: 275px;
  }
}

.button-container {
  text-align: center;
  margin-top: 24px;
}

@media screen and (min-width: 768px) {
  .button-container {
    margin-top: 48px;
  }
}

.button {
  color: #ffffff;
  background-color: #007bff;
  font-size: 12px;
  font-family: 'Roboto';
  border: none;
  border-radius: 4px;
  padding-left: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-right: 16px;
  outline: none;
  cursor: pointer;
}

@media screen and (min-width: 768px) {
  .button {
    font-size: 16px;
  }
}

//src/App.js

import FruitsCounter from './components/FruitsCounter'

import './App.css'

const App = () => <FruitsCounter />

export default App

Debugging Simple Todos:
---------------------------------

1.Completion Instructions:

Functionality to be fixed

Fix the given code to have the following functionality

Initially, the list of given todos should be displayed with a delete button for each todo
When the Delete button of a todo is clicked, then the respective todo should be deleted
The SimpleTodos will consist of the initialTodosList. It consists of a list of todo objects with the following properties in each todo object

Key		Data Type
id		Number
title	String

2.Quick Tips
Click to view

There are 6 bugs to be fixed to achieve the functionality and the UI that is expected

Initial code:
-------------------

//src/components/SimpleTodos/index.js

import {component} from 'react'

import TodoItem from '../TodoItem'

import './index.css'

const initialTodosList = [
  {
    id: 1,
    title: 'Book the ticket for today evening',
  },
  {
    id: 2,
    title: 'Rent the movie for tomorrow movie night',
  },
  {
    id: 3,
    title: 'Confirm the slot for the yoga session tomorrow morning',
  },
  {
    id: 4,
    title: 'Drop the parcel at Bloomingdale',
  },
  {
    id: 5,
    title: 'Order fruits on Big Basket',
  },
  {
    id: 6,
    title: 'Fix the production issue',
  },
  {
    id: 7,
    title: 'Confirm my slot for Saturday Night',
  },
  {
    id: 8,
    title: 'Get essentials for Sunday car wash',
  },
]

class SimpleTodos extends Component {
  state : {
    todosList= initialTodosList,
  }

  const deleteTodo = id => {
    const {todosList} = this.state
    const updatedTodosList = todosList.filter(eachTodo => eachTodo.id !== id)

    this.setState({
      todosList: updatedTodosList,
    })
  }

  render() {
    const {todosList} = this.state

    return (
      <div className="app-container">
        <div className="simple-todos-container">
          <h1 className="heading">Simple Todos</h1>
          <ul className="todos-list">
            {todosList[0].map(eachTodo => (
              <TodoItem
                key={eachTodo.id}
                todoDetails={eachTodo}
                deleteTodo={this.deleteTodo}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default SimpleTodos

//src/components/TodoItem/index.js

import './index.css'

const TodoItem = props => {
  const {todoDetails, deleteTodo} = props
  const {id, title} = todoDetails
  
  const onDeleteTodo = () => {
    deleteTodo()
  }

  return (
      <p className="title">{title}</p>
      <button type="button" className="delete-btn" onClick={onDeleteTodo}>
        Delete
      </button>
  )
}

export default TodoItem

Solution:
---------------

//src/components/SimpleTodos/index.js

// FIX1: The import statement for Component class should be written like this
import {Component} from 'react'

import TodoItem from '../TodoItem'

import './index.css'

const initialTodosList = [
  {
    id: 1,
    title: 'Book the ticket for today evening',
  },
  {
    id: 2,
    title: 'Rent the movie for tomorrow movie night',
  },
  {
    id: 3,
    title: 'Confirm the slot for the yoga session tomorrow morning',
  },
  {
    id: 4,
    title: 'Drop the parcel at Bloomingdale',
  },
  {
    id: 5,
    title: 'Order fruits on Big Basket',
  },
  {
    id: 6,
    title: 'Fix the production issue',
  },
  {
    id: 7,
    title: 'Confirm my slot for Saturday Night',
  },
  {
    id: 8,
    title: 'Get essentials for Sunday car wash',
  },
]

class SimpleTodos extends Component {
  // FIX2: The syntax to assign value to the state should be as mentioned below
  state = {
    todosList: initialTodosList,
  }

  // FIX3: Here, the class method doesn't need keyword "const" for declaration
  deleteTodo = id => {
    const {todosList} = this.state
    const updatedTodosList = todosList.filter(eachTodo => eachTodo.id !== id)

    this.setState({
      todosList: updatedTodosList,
    })
  }

  render() {
    const {todosList} = this.state

    return (
      <div className="app-container">
        <div className="simple-todos-container">
          <h1 className="heading">Simple Todos</h1>
          <ul className="todos-list">
            {/* FIX4: map() is an array method and should be used only on arrays */}
            {todosList.map(eachTodo => (
              <TodoItem
                key={eachTodo.id}
                todoDetails={eachTodo}
                deleteTodo={this.deleteTodo}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default SimpleTodos


//src/components/SimpleTodos/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #ffc2a0;
  min-height: 100vh;
}

.simple-todos-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #ffffff;
  border-radius: 16px;
  width: 90%;
  padding: 24px;
  margin-top: 48px;
  margin-bottom: 48px;
  max-width: 1110px;
}

@media screen and (min-width: 768px) {
  .simple-todos-container {
    padding: 48px;
    margin-top: 96px;
    margin-bottom: 96px;
  }
}

.heading {
  color: #ff8542;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 700;
  margin-top: 12px;
  margin-bottom: 16px;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 48px;
    margin-top: 32px;
    margin-bottom: 48px;
  }
}

.todos-list {
  padding-left: 0px;
}

//src/components/TodoItem/index.js

import './index.css'

const TodoItem = props => {
  const {todoDetails, deleteTodo} = props
  const {id, title} = todoDetails

  const onDeleteTodo = () => {
    // FIX5 :The id of the todo has to be sent as an argument to the callback function
    deleteTodo(id)
  }

  return (
    // FIX6: The HTML elements should be wrapped inside a single element when returning
    <li className="todo-item">
      <p className="title">{title}</p>
      <button type="button" className="delete-btn" onClick={onDeleteTodo}>
        Delete
      </button>
    </li>
  )
}

export default TodoItem

//src/components/TodoItem/index.css

.todo-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  list-style-type: none;
}

.title {
  color: #000000;
  font-family: 'Roboto';
  font-size: 16px;
}

@media screen and (min-width: 768px) {
  .title {
    font-size: 24px;
  }
}

.delete-btn {
  background-color: #ffffff;
  color: #ff0b37;
  font-family: 'Roboto';
  font-size: 12px;
  border-radius: 8px;
  border: 1px solid #ff0b37;
  padding-top: 4px;
  padding-left: 8px;
  padding-bottom: 4px;
  padding-right: 8px;
  margin-left: 16px;
  outline: none;
  cursor: pointer;
}

@media screen and (min-width: 768px) {
  .delete-btn {
    font-size: 18px;
    padding-top: 8px;
    padding-left: 16px;
    padding-bottom: 8px;
    padding-right: 16px;
    margin-left: 32px;
  }
}

//src/App.js

import SimpleTodos from './components/SimpleTodos'

import './App.css'

const App = () => <SimpleTodos />

export default App

coding pratice-10:
-----------------------------------------------

Debugging Google Search Suggestions:
--------------------------------------------


1.Completion Instructions
Functionality to be fixed

Fix the given code to have the following functionality

Initially, all suggestions in the suggestionsList should be displayed

When a value is provided in the search input, then display the suggestions which include the search input irrespective of case

When the arrow of a suggestion is clicked, then the value of the search input should be updated with the respective suggestion clicked

The GoogleSuggestions component receives the suggestionsList as a prop. It consists of a list of suggestion objects with the following properties in each suggestion object

Key			Data Type
id			Number
suggestion	String

2.Quick Tips
Click to view

There are 7 bugs to be fixed to achieve the functionality and the UI that is expected

Initial code:
-------------------

//src/components/GoogleSuggestions/index.js:

import SuggestionItem from '../SuggestionItem'

import './index.css'

class GoogleSuggestions extends Component {
  state = {
    searchInput: '',
  }

  updateSearchInput = value => {
    this.setState(
      searchInput: value,
    )
  }

  onChangeSearchInput = e => {
    this.setState({
      searchInput: event.target.value,
    })
  }

  render() {
    const {searchInput} = this.props
    const {suggestionsList} = this.state
    const searchResults = suggestionsList.filter(eachSuggestion =>
      eachSuggestion.suggestion
        .toLowerCase()
        .includes(searchInput.toLowerCase()),
    )

    return (
      <div className="app-container">
        <div className="google-suggestions-container">
          <img
            src="https://assets.ccbp.in/frontend/react-js/google-logo.png"
            alt="google logo"
            className="google-logo"
          />
          <div className="search-input-suggestions-container">
            <div className="search-input-container">
              <img
                alt="search icon"
                className="search-icon"
                src="https://assets.ccbp.in/frontend/react-js/google-search-icon.png"
              />
              <input
                type="search"
                className="search-input"
                placeholder="Search Google"
                onChange={this.onChangeSearchInput}
                value={searchInput}
              />
            </div>
            <ul className="suggestions-list">
              {searchResults.map(eachSuggestion => (
                <suggestionItem
                  key={eachSuggestion.id}
                  suggestionDetails={eachSuggestion}
                  updateSearchInput={this.updateSearchInput}
                />
              ))}
            </ul>
          </div>
        </div>
      </div>
    )
  }
}

export default GoogleSuggestions

//src/components/SuggestionItem/index.js:

import './index.css'

const SuggestionItem = props => {
  const {suggestionDetails, updateSearchInput} = props
  const {suggestion} = suggestionDetails

  const onClickSuggestion = () => {
    updateSearchInput(suggestion)
  }

  return (
    <li className="suggestion-item">
      <p className="suggestion-text">{suggestion}</p>
      <button
        type="button"
        className="arrow-button"
        onClick={onClickSuggestion}
      >
        <img
          src="https://assets.ccbp.in/frontend/react-js/diagonal-arrow-left-up.png"
          alt="arrow"
          className="arrow"
        />
      </button>
    </li>
  )
}

Solution:
--------------

//src/components/GoogleSuggestions/index.js

// FIX1: The React Component class needs to be imported before using it
import {Component} from 'react'

import SuggestionItem from '../SuggestionItem'

import './index.css'

class GoogleSuggestions extends Component {
  state = {
    searchInput: '',
  }

  updateSearchInput = value => {
    // FIX2: The setState() object syntax should be as the below statement
    this.setState({
      searchInput: value,
    })
  }

  // FIX3: The function receives event as argument and it should be used inside the function
  onChangeSearchInput = event => {
    this.setState({
      searchInput: event.target.value,
    })
  }

  render() {
    // FIX4: searchInput should be accessed from the state
    const {searchInput} = this.state
    // FIX5: suggestionsList is received from props
    const {suggestionsList} = this.props
    const searchResults = suggestionsList.filter(eachSuggestion =>
      eachSuggestion.suggestion
        .toLowerCase()
        .includes(searchInput.toLowerCase()),
    )

    return (
      <div className="app-container">
        <div className="google-suggestions-container">
          <img
            src="https://assets.ccbp.in/frontend/react-js/google-logo.png"
            alt="google logo"
            className="google-logo"
          />
          <div className="search-input-suggestions-container">
            <div className="search-input-container">
              <img
                alt="search icon"
                className="search-icon"
                src="https://assets.ccbp.in/frontend/react-js/google-search-icon.png"
              />
              <input
                type="search"
                className="search-input"
                placeholder="Search Google"
                onChange={this.onChangeSearchInput}
                value={searchInput}
              />
            </div>
            <ul className="suggestions-list">
              {/* FIX6: The component name should start with capital letter */}
              {searchResults.map(eachSuggestion => (
                <SuggestionItem
                  key={eachSuggestion.id}
                  suggestionDetails={eachSuggestion}
                  updateSearchInput={this.updateSearchInput}
                />
              ))}
            </ul>
          </div>
        </div>
      </div>
    )
  }
}

export default GoogleSuggestions

//src/components/SuggestionItem/index.js:

import './index.css'

const SuggestionItem = props => {
  const {suggestionDetails, updateSearchInput} = props
  const {suggestion} = suggestionDetails

  const onClickSuggestion = () => {
    updateSearchInput(suggestion)
  }

  return (
    <li className="suggestion-item">
      <p className="suggestion-text">{suggestion}</p>
      <button
        type="button"
        className="arrow-button"
        onClick={onClickSuggestion}
      >
        <img
          src="https://assets.ccbp.in/frontend/react-js/diagonal-arrow-left-up.png"
          alt="arrow"
          className="arrow"
        />
      </button>
    </li>
  )
}

// FIX7: The component should be exported before using it in other components
export default SuggestionItem

//src/App.js:

import GoogleSuggestions from './components/GoogleSuggestions'

import './App.css'

const suggestionsList = [
  {id: 1, suggestion: 'Price of Ethereum'},
  {id: 2, suggestion: 'Oculus Quest 2 specs'},
  {id: 3, suggestion: 'Tesla Share Price'},
  {id: 4, suggestion: 'Price of Ethereum today'},
  {id: 5, suggestion: 'Latest trends in AI'},
  {id: 6, suggestion: 'Latest trends in ML'},
]

const App = () => <GoogleSuggestions suggestionsList={suggestionsList} />

export default App

Debugging Cash Withdrawal:
---------------------------------------

1.Completion Instructions:

Functionality to be fixed

Fix the given code to have the following functionality

Initially, the balance should be 2000 rupees
When a denomination is clicked, then the respective value should be deducted from the balance available
The CashWithdrawal component receives the denominationsList as a prop. It consists of a list of denomination objects with the following properties in each denomination object

Key		Data Type
id		Number
value	Number

2.Quick Tips
Click to view

There are 9 bugs to be fixed to achieve the functionality and the UI that is expected

Initial code:
-------------------

//src/components/CashWithdrawal/index.js:

import component from 'react'

import DenominationItem from '../DenominationItem'

import './index.css'

const CashWithdrawal extends Component {
  state = {
    balance: 2000,
  }

  updateBalance = value => {
    this.setstate(prevState => ({balance: prevState.balance - value}))
  }

  render() {
    const {denomination} = this.props
    const {balance} = this.state
    const name = 'Sarah Williams'
    const initial = name.slice(0, 1)

    return (
      <div className="app-container">
        <div className="cash-withdrawal-container">
          <div className="user-details-container">
            <div className="initial-container">
              <p className="initial">{initial}</p>
            </div>
            <p className="name">{name}</p>
          </div>
          <div className="balance-container">
            <p className="your-balance">Your Balance</p>
            <p className="balance">
              {balance}
              <br />
              <span className="currency">In Rupees</span>
            </p>
          </div>
          <p className="withdraw">Withdraw</p>
          <p className="choose-sum">CHOOSE SUM (IN RUPEES)</p>
          <ul className="denominations-list">
            {denomination.map(eachDenomination => (
              <DenominationItem
                key={eachDenomination.id}
                denominationDetails={eachDenomination}
                updateBalance={this.updateBalance}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default CashWithdrawal

//src/components/DenominationItem/index.js:

import './index.css'

const DenominationItem = props => {
  const {denominationDetails, updateBalance} = this.props
  const {value} = denominationDetails

  onClickDenomination = () => {
    updateBalance(value)
  }

  return (
    <li className="denomination-item">
      <button
        type="button"
        className="denomination-button"
        onClick={this.onClickDenomination}
      >
        {value}
      </button>
    </li>
  )
}

export default DenominationItem

Solution:
------------

//src/components/CashWithdrawal/index.js:

// FIX2: The import statement for React Component class
import {Component} from 'react'

import DenominationItem from '../DenominationItem'

import './index.css'

// FIX3: class should be declared with keyword class
class CashWithdrawal extends Component {
  state = {
    balance: 2000,
  }

  updateBalance = value => {
    // FIX4: setState spelling should be as mentioned below
    this.setState(prevState => ({balance: prevState.balance - value}))
  }

  render() {
    // FIX5: The prop name here is denominationsList
    const {denominationsList} = this.props
    const {balance} = this.state
    const name = 'Sarah Williams'
    const initial = name.slice(0, 1)

    return (
      <div className="app-container">
        <div className="cash-withdrawal-container">
          <div className="user-details-container">
            <div className="initial-container">
              <p className="initial">{initial}</p>
            </div>
            <p className="name">{name}</p>
          </div>
          <div className="balance-container">
            <p className="your-balance">Your Balance</p>
            <p className="balance">
              {balance}
              <br />
              <span className="currency">In Rupees</span>
            </p>
          </div>
          <p className="withdraw">Withdraw</p>
          <p className="choose-sum">CHOOSE SUM (IN RUPEES)</p>
          <ul className="denominations-list">
            {/* FIX6: The prop name here is denominationsList */}
            {denominationsList.map(eachDenomination => (
              <DenominationItem
                key={eachDenomination.id}
                denominationDetails={eachDenomination}
                updateBalance={this.updateBalance}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default CashWithdrawal

//src/components/DenominationItem/index.js:

import './index.css'

const DenominationItem = props => {
  // FIX7: props in functional component should not be accessed with this
  const {denominationDetails, updateBalance} = props
  const {value} = denominationDetails
  // FIX8: Variable declaration should consist of keyword const
  const onClickDenomination = () => {
    updateBalance(value)
  }

  return (
    <li className="denomination-item">
      <button
        type="button"
        className="denomination-button"
        // FIX9: Functions in functional components should not be accessed with this
        onClick={onClickDenomination}
      >
        {value}
      </button>
    </li>
  )
}

export default DenominationItem

//src/App.js:

import CashWithdrawal from './components/CashWithdrawal'

import './App.css'

const denominationsList = [
  {
    id: 1,
    value: 50,
  },
  {
    id: 2,
    value: 100,
  },
  {
    id: 3,
    value: 200,
  },
  {
    id: 4,
    value: 500,
  },
]

const App = () => <CashWithdrawal denominationsList={denominationsList} />

// FIX1: App should be exported
export default App

Debugging using Developer tools | Cheat Sheet:
-----------------------------------------------------------------------------------------------------

Debugging:
Debugging is the process of finding & fixing the bugs in the code.

We can debug using:

Browser Developer Tools
React Developer Tools

Browser Developer Tools:
These are the tools provided by the browsers to debug the application loaded in the web browser.

Using Browser Developer Tools, we can:

1.View the source code (HTML, CSS, and JS)

2.View and change CSS:
https://developer.chrome.com/docs/devtools/css/

3.View logged messages in the console:
https://developer.chrome.com/docs/devtools/console/log/#javascript

4.Run JavaScript in the console:
https://developer.chrome.com/docs/devtools/console/javascript/

5.Check the responsiveness of an application, etc:
https://developer.chrome.com/docs/devtools/device-mode/#viewport

React Developer Tools
For React Developer Tools, we can install the React Developer Tools Extension for Google Chrome.

https://chrome.google.com/webstore/detail/react-developer-tools/fmkadmapgofadopljbjfkapdkoienihi?hl=en

coding pratice-11:
------------------------------------------------------------------

Feedback App:
-----------------

https://github.com/ManirathnamKuruma/ReactJS-FeedbackApp

1.Set Up Instructions:

Click to view
Download dependencies by running npm install
Start up the app using npm start

2.Completion Instructions:
Functionality to be added

The app must have the following functionalities

When an emoji is clicked, then the thank you screen should be displayed
The Feedback component receives the resources as a prop. It consists of the following properties

Key				Data Type
emojis			Array <object>
loveEmojiUrl	String

emojis consists of list of emoji objects with the following properties in each emoji object

Key			Data Type
id			Number
name		String
imageUrl	String

3.Implementation Files

Use these files to complete the implementation:

src/components/Feedback/index.js
src/components/Feedback/index.css

4.Important Note
Click to view

The following instructions are required for the tests to pass

The love emoji should have the alt as love emoji
The emojis should have the alt equal to name value in each emoji object

//src/components/Feedback/index.js:

import {Component} from 'react'

import './index.css'

class Feedback extends Component {
  state = {
    isFeedbackSelected: false,
  }

  onClickEmoji = () => this.setState({isFeedbackSelected: true})

  renderFeedbackQuestion = () => {
    const {resources} = this.props
    const {emojis} = resources

    return (
      <div className="feedback-question-container">
        <h1 className="feedback-question">
          How satisfied are you with our customer support performance?
        </h1>
        <ul className="emojis-list">
          {emojis.map(emoji => (
            <li key={emoji.id}>
              <button
                type="button"
                className="emoji-btn"
                onClick={this.onClickEmoji}
              >
                <img src={emoji.imageUrl} alt={emoji.name} className="emoji" />
                <br />
                <span className="emoji-name">{emoji.name}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    )
  }

  renderThankYouScreen = () => {
    const {resources} = this.props
    const {loveEmojiUrl} = resources

    return (
      <div className="thank-you-container">
        <img src={loveEmojiUrl} alt="love emoji" className="love-emoji" />
        <h1 className="thank-you-text">Thank You!</h1>
        <p className="description">
          We will use your feedback to improve our customer support performance.
        </p>
      </div>
    )
  }

  render() {
    const {isFeedbackSelected} = this.state

    return (
      <div className="app-container">
        <div className="feedback-card">
          {isFeedbackSelected
            ? this.renderThankYouScreen()
            : this.renderFeedbackQuestion()}
        </div>
      </div>
    )
  }
}

export default Feedback


//src/components/Feedback/index.css:

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-image: linear-gradient(to right, #ffeeee, #ffc0bb);
  height: 100vh;
}

.feedback-card {
  background-color: #ffffff;
  width: 80%;
  border-radius: 12px;
  max-width: 606px;
  padding: 24px;
}

@media screen and (min-width: 768px) {
  .feedback-card {
    padding: 32px;
  }
}

@media screen and (min-width: 992px) {
  .feedback-card {
    padding: 64px;
  }
}

.feedback-question-container {
  display: flex;
  flex-direction: column;
}

.feedback-question {
  text-align: center;
  color: #0f172a;
  font-family: 'Roboto';
  font-size: 18px;
  font-weight: 500;
}

@media screen and (min-width: 992px) {
  .feedback-question {
    font-size: 32px;
  }
}

.emojis-list {
  display: flex;
  justify-content: space-around;
  list-style-type: none;
  margin-top: 32px;
  padding: 0px;
}

.emoji-btn {
  border: none;
  background-color: #ffffff;
  cursor: pointer;
  outline: none;
}

.emoji {
  width: 45px;
  height: 45px;
  margin-bottom: 16px;
}

@media screen and (min-width: 768px) {
  .emoji {
    width: 70px;
    height: 70px;
  }
}

.emoji-name {
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 16px;
}

@media screen and (min-width: 768px) {
  .emoji-name {
    font-size: 12px;
  }
}

.thank-you-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.love-emoji {
  width: 60px;
  height: 54px;
}

.thank-you-text {
  text-align: center;
  color: #0f172a;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 500;
}

.description {
  text-align: center;
  color: #0f172a;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 300;
}

//src/App.js

import Feedback from './components/Feedback'

import './App.css'

const resources = {
  emojis: [
    {
      id: 0,
      name: 'Sad',
      imageUrl: 'https://assets.ccbp.in/frontend/react-js/sad-emoji-img.png',
    },
    {
      id: 1,
      name: 'None',
      imageUrl: 'https://assets.ccbp.in/frontend/react-js/none-emoji-img.png',
    },
    {
      id: 2,
      name: 'Happy',
      imageUrl: 'https://assets.ccbp.in/frontend/react-js/happy-emoji-img.png',
    },
  ],
  loveEmojiUrl: 'https://assets.ccbp.in/frontend/react-js/love-emoji-img.png',
}

const App = () => <Feedback resources={resources} />

export default App

//src/.eslintignore

node_modules
coverage
build

//src/.eslintrc

{
  "env": {
    "browser": true,
    "es2021": true
  },
  "parser": "babel-eslint",
  "extends": ["react-app", "airbnb", "prettier"],
  "parserOptions": {
    "ecmaFeatures": {
      "jsx": true
    },
    "ecmaVersion": 12,
    "sourceType": "module"
  },
  "plugins": ["prettier"],
  "overrides": [
    {
      "files": ["styledComponents.js"],
      "rules": {
        "import/prefer-default-export": "off"
      }
    }
  ],
  "rules": {
    "prettier/prettier": "error",
    "react/jsx-filename-extension": [1, {"extensions": [".js", ".jsx"]}],
    "react/state-in-constructor": "off",
    "react/react-in-jsx-scope": "off",
    "react/jsx-uses-react": "off",
    "no-console": "off",
    "react/prop-types": "off",
    "jsx-a11y/label-has-associated-control": [
      2,
      {
        "labelAttributes": ["htmlFor"]
      }
    ],
    "jsx-a11y/click-events-have-key-events": 0,
    "jsx-a11y/no-noninteractive-element-interactions": [
      "off",
      {
        "handlers": ["onClick"]
      }
    ],
    "react/prefer-stateless-function": [
      0,
      {
        "ignorePureComponents": true
      }
    ],
    "no-unused-vars": "warn",
    "jsx-a11y/alt-text": 1,
    "react/no-unused-state": "warn",
    "react/button-has-type": "warn",
    "react/no-unescaped-entities": "warn",
    "react/jsx-props-no-spreading": "off",
    "operator-assignment": ["warn", "always"],
    "radix": "off"
  }
}

//src/.gitattributes

* text=auto eol=lf

//src/.gitignore

# dependencies
/node_modules
/.pnp
.pnp.js

# testing
/coverage

# production
/build

# misc
.DS_Store
.env.local
.env.development.local
.env.test.local
.env.production.local

npm-debug.log*
yarn-debug.log*
yarn-error.log*

.idea/
.eslintcache
.vscode/
.results

//src/.npmrc

registry=https://registry.npmjs.org/
package-lock=true
save-exact=true

//src/.prettierignore

node_modules
coverage
build

//src/.prettierrc

{
  "arrowParens": "avoid",
  "bracketSpacing": false,
  "endOfLine": "lf",
  "htmlWhitespaceSensitivity": "css",
  "insertPragma": false,
  "jsxBracketSameLine": false,
  "jsxSingleQuote": false,
  "printWidth": 80,
  "overrides": [
    {
      "files": "*.md",
      "options": {
        "printWidth": 1000
      }
    }
  ],
  "proseWrap": "always",
  "quoteProps": "as-needed",
  "requirePragma": false,
  "semi": false,
  "singleQuote": true,
  "tabWidth": 2,
  "trailingComma": "all",
  "useTabs": false
}

//public/manifest.json

{
  "short_name": "app_short_name",
  "name": "App_name",
  "icons": [
    {
      "src": "img/favicon.ico",
      "sizes": "64x64 32x32 24x24 16x16",
      "type": "image/x-icon"
    },
    {
      "src": "img/logo192.png",
      "type": "image/png",
      "sizes": "192x192"
    },
    {
      "src": "img/logo512.png",
      "type": "image/png",
      "sizes": "512x512"
    }
  ],
  "start_url": ".",
  "display": "standalone",
  "theme_color": "#000000",
  "background_color": "#ffffff"
}

Working with Lists > On Demand Session | Cheat Sheet:
----------------------------------------------------------------------------------------------------

Initial code:
------------------

//src/components/TabItem/index.js:

import './index.css'

const TabItem = props => {
  const {tabDetails} = props
  const {displayText} = tabDetails

  return (
    <li className="tab-item-container ">
      <button type="button" className="tab-btn">
        {displayText}
      </button>
    </li>
  )
}

export default TabItem

//src/App.js:

import {Component} from 'react'

import TabItem from './components/TabItem'
import ProjectItem from './components/ProjectItem'
import Header from './components/Header'

import './App.css'

const tabsList = [
  {tabId: 'STATIC', displayText: 'Static'},
  {tabId: 'RESPONSIVE', displayText: 'Responsive'},
  {tabId: 'DYNAMIC', displayText: 'Dynamic'},
]

const projectsList = [
  {
    projectId: 0,
    category: 'STATIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-s3-img.png',
    title: 'Music Page',
    description:
      'The music page enables the users to browse through the images of all-time favorite music albums.',
  },
  {
    projectId: 1,
    category: 'STATIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-s4-img.png',
    title: 'Tourism Website',
    description:
      'A tourism website enables the user to browse through the images of popular destinations.',
  },
  {
    projectId: 2,
    category: 'STATIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-s1-img.png',
    title: 'Advanced Technologies',
    description:
      'A website that gives you a basic understanding of Advanced Technologies.',
  },
  {
    projectId: 4,
    category: 'RESPONSIVE',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-r4-img.png',
    title: 'VR Website',
    description:
      'VR Website enables users to explore AR and VR Products and Industry happenings.',
  },
  {
    projectId: 5,
    category: 'RESPONSIVE',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-r2-img.png',
    title: 'Food Munch',
    description: 'Food Much Website is a user-centric food tech website.',
  },
  {
    projectId: 6,
    category: 'RESPONSIVE',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-r3-img.png',
    title: 'Portfolio',
    description:
      'A portfolio is the best alternative for a resume to showcase your skills to the digital world.',
  },

  {
    projectId: 8,
    category: 'DYNAMIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-d3-img.png',
    title: 'Speed Typing Test',
    description:
      'Speed Typing Test Application is capable of calculating the time to type the randomly generated quote.',
  },
  {
    projectId: 9,
    category: 'DYNAMIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-d1-img.png',
    title: 'Random Joke Page',
    description:
      'Random Joke Page is an API-based dynamic Web Application that generates a new joke.',
  },
  {
    projectId: 10,
    category: 'DYNAMIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-d2-img.png',
    title: 'Sizing An Image',
    description:
      'This is a dynamic web application capable of adjusting the size of an element using DOM manipulations.',
  },
]

class App extends Component {
  render() {
    return (
      <div className="app-container">
        <Header />
        <h1 className="title">Projects</h1>
        <p className="description">
          Your skills and achievements showcase your strengths and abilities.
          Speak about any new skills or software you learnt to perform the
          project responsibilities.
        </p>

        <ul className="tabs-container">
          {tabsList.map(tabDetails => (
            <TabItem key={tabDetails.tabId} tabDetails={tabDetails} />
          ))}
        </ul>

        <ul className="project-list-container">
          {projectsList.map(projectDetails => (
            <ProjectItem
              key={projectDetails.projectId}
              projectDetails={projectDetails}
            />
          ))}
        </ul>
      </div>
    )
  }
}

export default App

Solution:
----------------

1. Projects Example

File: src/App.js

import {Component} from 'react'

import TabItem from './components/TabItem'
import ProjectItem from './components/ProjectItem'
import Header from './components/Header'

import './App.css'

const tabsList = [
  {tabId: 'STATIC', displayText: 'Static'},
  {tabId: 'RESPONSIVE', displayText: 'Responsive'},
  {tabId: 'DYNAMIC', displayText: 'Dynamic'},
]

const projectsList = [
  {
    projectId: 0,
    category: 'STATIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-s3-img.png',
    title: 'Music Page',
    description:
      'The music page enables the users to browse through the images of all-time favorite music albums.',
  },
  {
    projectId: 1,
    category: 'STATIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-s4-img.png',
    title: 'Tourism Website',
    description:
      'A tourism website enables the user to browse through the images of popular destinations.',
  },
  {
    projectId: 2,
    category: 'STATIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-s1-img.png',
    title: 'Advanced Technologies',
    description:
      'A website that gives you a basic understanding of Advanced Technologies.',
  },
     {
       projectId: 3,
       category: 'STATIC',
       imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-s2-img.png',
       title: 'Happy Meals',
       description: 'Discover the best foods in over 1,000 restaurants.',
     },
  {
    projectId: 4,
    category: 'RESPONSIVE',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-r4-img.png',
    title: 'VR Website',
    description:
      'VR Website enables users to explore AR and VR Products and Industry happenings.',
  },
  {
    projectId: 5,
    category: 'RESPONSIVE',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-r2-img.png',
    title: 'Food Munch',
    description: 'Food Much Website is a user-centric food tech website.',
  },
  {
    projectId: 6,
    category: 'RESPONSIVE',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-r3-img.png',
    title: 'Portfolio',
    description:
      'A portfolio is the best alternative for a resume to showcase your skills to the digital world.',
  },
 {
   projectId: 7,
   category: 'RESPONSIVE',
   imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-r1-img.png',
   title: 'Design',
   description:
     'A website to showcase the best features and give more information about the Design tool.',
 },
  {
    projectId: 8,
    category: 'DYNAMIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-d3-img.png',
    title: 'Speed Typing Test',
    description:
      'Speed Typing Test Application is capable of calculating the time to type the randomly generated quote.',
  },
  {
    projectId: 9,
    category: 'DYNAMIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-d1-img.png',
    title: 'Random Joke Page',
    description:
      'Random Joke Page is an API-based dynamic Web Application that generates a new joke.',
  },
  {
    projectId: 10,
    category: 'DYNAMIC',
    imageURL: 'https://assets.ccbp.in/frontend/react-js/projects-d2-img.png',
    title: 'Sizing An Image',
    description:
      'This is a dynamic web application capable of adjusting the size of an element using DOM manipulations.',
  },
]

class App extends Component {
  state = {
    activeTabId: tabsList[0].tabId,
  }

  clickTabItem = tabValue => {
    this.setState({activeTabId: tabValue})
  }

  getFilteredProjects = () => {
    const {activeTabId} = this.state
    const filteredProjects = projectsList.filter(
      eachprojectDetails => eachprojectDetails.category === activeTabId,
    )
    return filteredProjects
  }

  render() {
    const {activeTabId} = this.state
    const filteredProjects = this.getFilteredProjects()
    return (
      <div className="app-container">
        <Header />
        <h1 className="title">Projects</h1>
        <p className="description">
          Your skills and achievements showcase your strengths and abilities.
          Speak about any new skills or software you learnt to perform the
          project responsibilities.
        </p>

        <ul className="tabs-container">
          {tabsList.map(tabDetails => (
            <TabItem
              key={tabDetails.tabId}
              tabDetails={tabDetails}
              clickTabItem={this.clickTabItem}
              isActive={activeTabId === tabDetails.tabId}
            />
          ))}
        </ul>

        <ul className="project-list-container">
          {filteredProjects.map(projectDetails => (
            <ProjectItem
              key={projectDetails.projectId}
              projectDetails={projectDetails}
            />
          ))}
        </ul>
      </div>
    )
  }
}

export default App

File: src/components/TabItem/index.js

import './index.css'

const TabItem = props => {
  const {tabDetails, clickTabItem, isActive} = props
  const {tabId, displayText} = tabDetails
  const onClickTabItem = () => {
    clickTabItem(tabId)
  }

  const activeTabBtnClassName = isActive ? 'active-tab-btn' : ''

  return (
    <li className="tab-item-container ">
      <button
        type="button"
        className={`tab-btn ${activeTabBtnClassName}`}
        onClick={onClickTabItem}
      >
        {displayText}
      </button>
    </li>
  )
}

export default TabItem

Note
In the above code, multiple class names can be added using template literals.

File: src/components/TabItem/index.css

.tab-item-container {
  padding-right: 4px;
}

@media screen and (min-width: 992px) {
  .tab-item-container {
    padding-right: 24px;
  }
}

.tab-btn {
  font-family: 'Roboto';
  color: #9aa5b1;
  font-weight: 500;
  font-size: 16px;
  background-color: transparent;
  outline: none;
  border: none;
  cursor: pointer;
}

@media screen and (min-width: 992px) {
  .tab-btn {
    font-size: 24px;
  }
}

.active-tab-btn {
  border-bottom: 2px solid #0b69ff;
  color: #3e4c59;
}

File: src/components/Header/index.js

import './index.css'

const Header = () => (
  <nav className="nav-header">
    <div className="nav-content">
      <p className="website-logo">RA</p>
      <ul className="nav-menu">
        <li>
          <img
            className="social-network-img"
            src="https://image.flaticon.com/icons/png/512/174/174857.png"
            alt="Linked In"
          />
        </li>
        <li>
          <img
            className="social-network-img"
            src="https://image.flaticon.com/icons/png/512/25/25231.png"
            alt="Git Hub"
          />
        </li>
        <li>
          <img
            className="social-network-img"
            src="https://res.cloudinary.com/dmwrugc6z/image/upload/v1621681890/Background_4x_1_bzyjew.png"
            alt="Twitter"
          />
        </li>
      </ul>
    </div>
  </nav>
)

export default Header

File: src/components/Header/index.css

.nav-header {
  display: flex;
  justify-content: center;
  width: 90%;
  margin: auto;
  height: 60px;
  max-width: 1110px;
}

@media screen and (min-width: 992px) {
  .nav-header {
    width: 100%;
    height: 100px;
  }
}

.nav-content {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 25px;
  padding-bottom: 25px;
}

.website-logo {
  font-size: 20px;
  width: 45px;
  height: 45px;
  border-radius: 12px;
  text-align: center;
  font-weight: 900;
  color: #1d4ed8;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #dbeafe;
}

@media screen and (min-width: 768px) {
  .website-logo {
    font-size: 28px;
    width: 48px;
    height: 48px;
  }
}

.nav-menu {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  align-self: center;
  flex: 1;
  list-style-type: none;
  margin-top: 0;
  margin-bottom: 0;
}

.social-network-img {
  width: 30px;
  margin-left: 15px;
}

@media screen and (min-width: 768px) {
  .social-network-img {
    width: 35px;
    border-radius: 4px;
    margin-left: 32px;
  }
}

File: src/components/ProjectItem/index.js

import './index.css'

const ProjectItem = props => {
  const {projectDetails} = props
  const {projectId, imageURL, description, title} = projectDetails
  return (
    <>
      <li className="project-item-container">
        <img
          className="project-item-image"
          src={imageURL}
          alt={`project-item${projectId}`}
        />
        <div className="project-item-details-container">
          <h1 className="project-item-title">{title}</h1>
          <p className="project-item-description">{description}</p>
        </div>
      </li>
    </>
  )
}

export default ProjectItem

File: src/components/ProjectItem/index.css

.project-item-container {
  width: 339px;
  background: #ffffff;
  box-shadow: 0px 15px 25px rgba(0, 0, 0, 0.06);
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  margin: 15px;
}

.project-item-image {
  width: 100%;
  border: 1px solid transparent;
  border-radius: 5px;
}

.project-item-details-container {
  padding: 32px 24px 32px 24px;
}

.project-item-title {
  font-family: 'Roboto';
  font-weight: 500;
  font-size: 24px;
  line-height: 36px;
  color: #183b56;
  margin: 0;
}

.project-item-description {
  font-family: 'Roboto';
  font-size: 18px;
  line-height: 32px;
  margin-top: 12px;
  margin-bottom: 0;
  color: #7b8794;
}

coding pratice-12:
-------------------------------------------------------

Gallery App:
--------------------

https://github.com/ManirathnamKuruma/ReactJS-GalleryApp

1.Set Up Instructions:

Click to view

Download dependencies by running npm install
Start up the app using npm start

2.Completion Instructions:

Functionality to be added

The app must have the following functionalities

Initially, the first image in the list should be displayed
When the user clicks on a thumbnail, then the corresponding image should be displayed
The Gallery component is provided with imagesList. It consists of a list of image details objects with the following properties in each object

Key					Data Type
id					Number
imageUrl			String
thumbnailUrl		String
imageAltText		String
thumbnailAltText	String

3.Implementation Files

Use these files to complete the implementation:

src/components/Gallery/index.js
src/components/Gallery/index.css
src/components/ThumbnailItem/index.js
src/components/ThumbnailItem/index.css

4.Quick Tips

Click to view

You can use the CSS opacity property to set the degree to which content behind an element is hidden. It accepts a value in the range of 0.0 to 1.0 inclusive

opacity: 0.5;

5.Important Note:

Click to view

The following instructions are required for the tests to pass

The selected image should have the alt as the value of the key imageAltText from each image details object provided
The thumbnail images should have the alt as values of the key thumbnailAltText from each image details object provided

//src/components/Gallery/index.js

import {Component} from 'react'

import ThumbnailItem from '../ThumbnailItem'

import './index.css'

const imagesList = [
  {
    id: 0,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-mountain-with-pond-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-mountain-with-pond-thumbnail-img.png',
    imageAltText: 'nature mountain with pond',
    thumbnailAltText: 'nature mountain with pond thumbnail',
  },
  {
    id: 1,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/nature-sunset-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-sunset-thumbnail-img.png',
    imageAltText: 'nature sunset',
    thumbnailAltText: 'nature sunset thumbnail',
  },
  {
    id: 2,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-mountain-with-ocean-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-mountain-with-ocean-thumbnail-img.png',
    imageAltText: 'nature mountain with ocean',
    thumbnailAltText: 'nature mountain with ocean thumbnail',
  },
  {
    id: 3,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-mountain-with-forest-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-mountain-with-forest-thumbnail-img.png',
    imageAltText: 'nature mountain with forest',
    thumbnailAltText: 'nature mountain with forest thumbnail',
  },
  {
    id: 4,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/nature-leaves-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-leaves-thumbnail-img.png',
    imageAltText: 'nature leaves',
    thumbnailAltText: 'nature leaves thumbnail',
  },
  {
    id: 5,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/nature-tree-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-tree-thumbnail-img.png',
    imageAltText: 'nature tree',
    thumbnailAltText: 'nature tree thumbnail',
  },
  {
    id: 6,
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-waterfall-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-waterfall-thumbnail-img.png',
    imageAltText: 'nature waterfall',
    thumbnailAltText: 'nature waterfall thumbnail',
  },
  {
    id: 7,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/nature-river-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/nature-river-thumbnail-img.png',
    imageAltText: 'nature river',
    thumbnailAltText: 'nature river thumbnail',
  },
]

class Gallery extends Component {
  state = {
    activeThumbnailId: imagesList[0].id,
  }

  setActiveThumbnailId = id => {
    this.setState({
      activeThumbnailId: id,
    })
  }

  render() {
    const {activeThumbnailId} = this.state
    const {imageUrl, imageAltText} = imagesList[activeThumbnailId]

    return (
      <div className="app-container">
        <div className="gallery-container">
          <img src={imageUrl} className="selected-image" alt={imageAltText} />
          <h1 className="heading">Nature Photography</h1>
          <p className="description">Nature Photography by Rahul</p>
          <ul className="thumbnails-list">
            {imagesList.map(eachImage => (
              <ThumbnailItem
                key={eachImage.id}
                imageDetails={eachImage}
                isActive={activeThumbnailId === eachImage.id}
                setActiveThumbnailId={this.setActiveThumbnailId}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default Gallery

//src/components/Gallery/index.css

.app-container {
  display: flex;
  justify-content: center;
}

.gallery-container {
  display: flex;
  flex-direction: column;
  width: 85%;
  margin-top: 34px;
  margin-bottom: 34px;
  max-width: 1140px;
}

.selected-image {
  border-radius: 18px;
}

.heading {
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 500;
  margin-top: 24px;
}

.description {
  color: #64748b;
  font-family: 'Roboto';
  font-weight: 500;
  font-size: 16px;
}

.thumbnails-list {
  display: flex;
  flex-wrap: wrap;
  list-style: none;
  padding: 0px;
}

//src/components/ThumbnailItem/index.js

import './index.css'

const ThumbnailItem = props => {
  const {imageDetails, isActive, setActiveThumbnailId} = props
  const {thumbnailUrl, thumbnailAltText, id} = imageDetails
  const thumbnailClassName = isActive ? `thumbnail active` : `thumbnail`

  const onClickThumbnail = () => {
    setActiveThumbnailId(id)
  }

  return (
    <li className="thumbnail-list-item">
      <button
        type="button"
        className="thumbnail-button"
        onClick={onClickThumbnail}
      >
        <img
          src={thumbnailUrl}
          alt={thumbnailAltText}
          className={thumbnailClassName}
        />
      </button>
    </li>
  )
}

export default ThumbnailItem

//src/components/ThumbnailItem/index.css

.thumbnail-list-item {
  margin-right: 16px;
  margin-bottom: 16px;
}

.thumbnail-button {
  background: transparent;
  border: none;
  padding: 0;
  outline: none;
  cursor: pointer;
}

.thumbnail {
  width: 60px;
  height: 60px;
  opacity: 0.5;
}

.active {
  opacity: 1;
}

//src/App.js:

import Gallery from './components/Gallery'

import './App.css'

const App = () => <Gallery />

export default App

coding pratice-13:
-----------------------------------------------------------------------------------

Capitals App: --> dropdown
-------------------------

https://github.com/ManirathnamKuruma/ReactJS-CapitalsApp

1.Completion Instructions:

Functionality to be added

The app must have the following functionalities

Initially, the first capital in the list should be selected, and its respective country should be displayed
When a capital is selected, then the respective country of the capital should be displayed
The Capitals component is provided with countryAndCapitalsList. It consists of a list of country and capital objects with the following properties in each country and capital object

Key					Data Type
id					String
capitalDisplayText	String
country				String

2.Implementation Files

Use these files to complete the implementation:

src/components/Capitals/index.js
src/components/Capitals/index.css


//src/components/Capitals/index.js

import {Component} from 'react'

import './index.css'

const countryAndCapitalsList = [
  {
    id: 'NEW_DELHI',
    capitalDisplayText: 'New Delhi',
    country: 'India',
  },
  {
    id: 'LONDON',
    capitalDisplayText: 'London',
    country: 'United Kingdom',
  },
  {
    id: 'PARIS',
    capitalDisplayText: 'Paris',
    country: 'France',
  },
  {
    id: 'KATHMANDU',
    capitalDisplayText: 'Kathmandu',
    country: 'Nepal',
  },
  {
    id: 'HELSINKI',
    capitalDisplayText: 'Helsinki',
    country: 'Finland',
  },
]

class Capitals extends Component {
  state = {
    activeCapitalId: countryAndCapitalsList[0].id,
  }

  onChangeCapital = event => {
    this.setState({activeCapitalId: event.target.value})
  }

  getCountry = () => {
    const {activeCapitalId} = this.state

    const activeCountryAndCapital = countryAndCapitalsList.find(
      eachCapital => eachCapital.id === activeCapitalId,
    )

    return activeCountryAndCapital.country
  }

  render() {
    const {activeCapitalId} = this.state
    const country = this.getCountry(activeCapitalId)

    return (
      <div className="app-container">
        <div className="capitals-container">
          <h1 className="heading">Countries And Capitals</h1>
          <div className="question-container">
            <select
              className="capital-select"
              onChange={this.onChangeCapital}
              value={activeCapitalId}
            >
              {countryAndCapitalsList.map(eachCapital => (
                <option
                  key={eachCapital.id}
                  value={eachCapital.id}
                  className="option"
                >
                  {eachCapital.capitalDisplayText}
                </option>
              ))}
            </select>
            <p className="question">is capital of which country?</p>
          </div>
          <p className="country">{country}</p>
        </div>
      </div>
    )
  }
}

export default Capitals

//src/components/Capitals/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #93c5fd;
  height: 100vh;
}

.capitals-container {
  background-color: #f8fafc;
  border-radius: 16px;
  width: 96%;
  padding: 20px;
  max-width: 345px;
}

@media screen and (min-width: 768px) {
  .capitals-container {
    padding-top: 44px;
    padding-left: 64px;
    padding-right: 64px;
    max-width: 520px;
  }
}

.heading {
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 500;
}

@media screen and (min-width: 768px) {
  .heading {
    text-align: left;
    font-size: 32px;
  }
}

.question-container {
  display: flex;
  align-items: center;
}

.capital-select {
  background-color: #f8fafc;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
  width: 100px;
  height: 40px;
  border: 1px solid #cbd2d9;
  border-radius: 4px;
  padding-top: 4px;
  padding-bottom: 4px;
  padding-left: 8px;
  outline: none;
}

@media screen and (min-width: 768px) {
  .capital-select {
    padding-top: 8px;
    padding-bottom: 8px;
    padding-left: 16px;
    width: 180px;
    font-size: 16px;
  }
}

.option {
  color: #323f4b;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
}

@media screen and (min-width: 768px) {
  .option {
    font-size: 14px;
  }
}

.question {
  color: #000000;
  font-family: 'Roboto';
  font-size: 12px;
  margin-left: 8px;
}

@media screen and (min-width: 768px) {
  .question {
    font-size: 16px;
  }
}

.country {
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
}

@media screen and (min-width: 768px) {
  .country {
    font-family: 'Roboto';
    font-size: 24px;
  }
}

//src/App.js

import Capitals from './components/Capitals'

import './App.css'

const App = () => <Capitals />

export default App

App Store --> searchbar
-------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-AppStore

1.Completion Instructions:

Functionality to be added

The app must have the following functionalities

1.1.Initially, the Social tab should be active and the apps with Social as their category should be displayed

1.2.When a value is provided in the search input
	The apps in the active category, that include search input value in their name should be displayed
	When another tab is clicked, the apps in the corresponding category, that include search input value in their name should be displayed
	The search should be case insensitive
	
1.3.When the search input is empty,
	All the apps in the active category should be displayed
	When another tab is clicked, the apps in the corresponding category should be displayed
	
1.4.The AppStore component is provided with tabsList. It consists of a list of tabItem objects with the following properties in each tabItem object

Key	Data 	Type
tabId		String
displayText	String

1.5.The AppStore component is provided with appsList. It consists of a list of app objects with the following properties in each app object

Key	Data 	Type
appId		Number
appName		String
imageUrl	String
category	String

1.6.Implementation Files

Use these files to complete the implementation:

src/components/AppStore/index.js
src/components/AppStore/index.css
src/components/TabItem/index.js
src/components/TabItem/index.css
src/components/AppItem/index.js
src/components/AppItem/index.css

//src/components/AppStore/index.js

import {Component} from 'react'

import AppItem from '../AppItem'
import TabItem from '../TabItem'

import './index.css'

const SEARCH_ICON_URL =
  'https://assets.ccbp.in/frontend/react-js/app-store/app-store-search-img.png'

const tabsList = [
  {tabId: 'SOCIAL', displayText: 'Social'},
  {tabId: 'GAMES', displayText: 'Games'},
  {tabId: 'NEWS', displayText: 'News'},
  {tabId: 'FOOD', displayText: 'Food'},
]

const appsList = [
  {
    appId: 0,
    appName: 'Facebook',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-facebook.png',
    category: 'SOCIAL',
  },
  {
    appId: 1,
    appName: 'Messenger',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-messenger.png',
    category: 'SOCIAL',
  },
  {
    appId: 2,
    appName: 'WhatsApp',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-whatsapp.png',
    category: 'SOCIAL',
  },
  {
    appId: 3,
    appName: 'Instagram',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-instagram.png',
    category: 'SOCIAL',
  },
  {
    appId: 4,
    appName: 'Snapchat',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-snapchat.png',
    category: 'SOCIAL',
  },
  {
    appId: 5,
    appName: 'Twitter',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-twitter.png',
    category: 'SOCIAL',
  },
  {
    appId: 6,
    appName: 'Pinterest',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-pinterest.png',
    category: 'SOCIAL',
  },
  {
    appId: 7,
    appName: 'WeChat',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-wechat.png',
    category: 'SOCIAL',
  },
  {
    appId: 8,
    appName: 'LinkedIn',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-linkedin.png',
    category: 'SOCIAL',
  },
  {
    appId: 9,
    appName: 'Telegram',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/social-telegram.png',
    category: 'SOCIAL',
  },
  {
    appId: 10,
    appName: 'Subway Surfers',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-subway-surfers.png',
    category: 'GAMES',
  },
  {
    appId: 11,
    appName: 'Crossy Road',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-crossy-road.png',
    category: 'GAMES',
  },
  {
    appId: 12,
    appName: 'Super Chef',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-super-chef.png',
    category: 'GAMES',
  },
  {
    appId: 13,
    appName: 'Angry Birds',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-angry-birds.png',
    category: 'GAMES',
  },
  {
    appId: 14,
    appName: 'Hill Climb 2',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-hill-climb-2.png',
    category: 'GAMES',
  },
  {
    appId: 15,
    appName: 'Temple Run',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-temple-run.png',
    category: 'GAMES',
  },
  {
    appId: 16,
    appName: 'Dr. Driving',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-dr-driving.png',
    category: 'GAMES',
  },
  {
    appId: 17,
    appName: 'Smurfs Bubble',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-smurfs-bubble.png',
    category: 'GAMES',
  },
  {
    appId: 18,
    appName: 'Grade Learning',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-grade-learning.png',
    category: 'GAMES',
  },
  {
    appId: 19,
    appName: 'My Talking Tom',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/games-my-talking-tom.png',
    category: 'GAMES',
  },
  {
    appId: 20,
    appName: 'Inshorts',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-inshorts.png',
    category: 'NEWS',
  },
  {
    appId: 21,
    appName: 'Way2News',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-way2news.png',
    category: 'NEWS',
  },
  {
    appId: 22,
    appName: 'Google News',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-google-news.png',
    category: 'NEWS',
  },
  {
    appId: 23,
    appName: 'Flipboard',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-flipboard.png',
    category: 'NEWS',
  },
  {
    appId: 24,
    appName: 'SmartNews',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-smart-news.png',
    category: 'NEWS',
  },
  {
    appId: 25,
    appName: 'BBC News',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-bbc-news.png',
    category: 'NEWS',
  },
  {
    appId: 26,
    appName: 'CNN News',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-cnn-news.png',
    category: 'NEWS',
  },
  {
    appId: 27,
    appName: 'Daily Wire',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-daily-wire.png',
    category: 'NEWS',
  },
  {
    appId: 28,
    appName: 'AP News',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-ap-news.png',
    category: 'NEWS',
  },
  {
    appId: 29,
    appName: 'News Break',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/news-news-break.png',
    category: 'NEWS',
  },
  {
    appId: 30,
    appName: 'Zomato',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/food-zomato.png',
    category: 'FOOD',
  },
  {
    appId: 31,
    appName: 'Swiggy',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/food-swiggy.png',
    category: 'FOOD',
  },
  {
    appId: 32,
    appName: "Domino's Pizza",
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/food-dominos.png',
    category: 'FOOD',
  },
  {
    appId: 33,
    appName: 'All in One',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/food-all-in-one.png',
    category: 'FOOD',
  },
  {
    appId: 34,
    appName: 'Instacart',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/food-insta-cart.png',
    category: 'FOOD',
  },
  {
    appId: 35,
    appName: 'Saucey',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/food-saucey.png',
    category: 'FOOD',
  },
  {
    appId: 36,
    appName: 'Waitr',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/food-waitr.png',
    category: 'FOOD',
  },
  {
    appId: 37,
    appName: 'Grubhub',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/food-grubhub.png',
    category: 'FOOD',
  },
  {
    appId: 38,
    appName: 'Mercato',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/app-store/food-mercato.png',
    category: 'FOOD',
  },
  {
    appId: 39,
    appName: 'DOT',
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/app-store/food-dot.png',
    category: 'FOOD',
  },
]

class AppStore extends Component {
  state = {
    searchInput: '',
    activeTabId: tabsList[0].tabId,
  }

  setActiveTabId = tabId => {
    this.setState({activeTabId: tabId})
  }

  onChangeSearchInput = event => {
    this.setState({searchInput: event.target.value})
  }

  getActiveTabApps = searchedApps => {
    const {activeTabId} = this.state
    const filteredApps = searchedApps.filter(
      eachSearchedApp => eachSearchedApp.category === activeTabId,
    )

    return filteredApps
  }

  getSearchResults = () => {
    const {searchInput} = this.state
    const searchResults = appsList.filter(eachApp =>
      eachApp.appName.toLowerCase().includes(searchInput.toLowerCase()),
    )

    return searchResults
  }

  render() {
    const {searchInput, activeTabId} = this.state
    const searchResults = this.getSearchResults()
    const filteredApps = this.getActiveTabApps(searchResults)

    return (
      <div className="app-container">
        <div className="app-store">
          <h1 className="heading">App Store</h1>
          <div className="search-input-container">
            <input
              type="search"
              placeholder="Search"
              className="search-input"
              value={searchInput}
              onChange={this.onChangeSearchInput}
            />
            <img
              src={SEARCH_ICON_URL}
              alt="search icon"
              className="search-icon"
            />
          </div>
          <ul className="tabs-list">
            {tabsList.map(eachTab => (
              <TabItem
                key={eachTab.tabId}
                tabDetails={eachTab}
                setActiveTabId={this.setActiveTabId}
                isActive={activeTabId === eachTab.tabId}
              />
            ))}
          </ul>
          <ul className="apps-list">
            {filteredApps.map(eachApp => (
              <AppItem key={eachApp.appId} appDetails={eachApp} />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default AppStore

//src/components/AppStore/index.css

.app-container {
  display: flex;
  justify-content: center;
  background-image: linear-gradient(to bottom, #fff1eb, #ace0f9);
  min-height: 100vh;
}

.app-store {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 85%;
  max-width: 1110px;
}

.heading {
  color: #1e293b;
  font-family: 'Bree Serif';
  font-size: 40px;
  margin-top: 64px;
  margin-bottom: 48px;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 48px;
    margin-top: 96px;
  }
}

.search-input-container {
  display: flex;
  align-items: center;
  height: 40px;
  background-color: transparent;
  width: 100%;
  max-width: 250px;
  border-radius: 4px;
  border: 1px solid #7b8794;
  padding-left: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-right: 16px;
}

@media screen and (min-width: 768px) {
  .search-input-container {
    max-width: 480px;
  }
}

.search-input {
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  border: none;
  outline: none;
  background-color: transparent;
  flex-grow: 1;
}

.search-icon {
  width: 24px;
  height: 24px;
}

.tabs-list {
  display: flex;
  align-items: flex-end;
  padding-left: 0px;
  margin-top: 32px;
}

@media screen and (min-width: 768px) {
  .tabs-list {
    margin-top: 48px;
  }
}

.apps-list {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  width: 100%;
  padding-left: 0px;
}

//src/components/TabItem/index.js

import './index.css'

const TabItem = props => {
  const {tabDetails, setActiveTabId, isActive} = props
  const {tabId, displayText} = tabDetails

  const onClickTab = () => {
    setActiveTabId(tabId)
  }

  const tabBtnClassName = isActive ? 'tab-button active' : 'tab-button'

  return (
    <li className="tab-item">
      <button type="button" onClick={onClickTab} className={tabBtnClassName}>
        {displayText}
      </button>
    </li>
  )
}

export default TabItem

//src/components/TabItem/index.css

.tab-item {
  list-style-type: none;
}

.tab-button {
  color: #7b8794;
  font-family: 'Roboto';
  font-size: 14px;
  font-weight: 500;
  border-top: none;
  border-left: none;
  border-right: none;
  border-bottom: 2px solid #dfe2e5;
  padding-left: 16px;
  padding-right: 16px;
  padding-bottom: 4px;
  background-color: transparent;
  outline: none;
  cursor: pointer;
}

@media screen and (min-width: 768px) {
  .tab-button {
    font-size: 16px;
    padding-left: 26px;
    padding-right: 26px;
    padding-bottom: 8px;
  }
}

.active {
  color: #2563eb;
  border-bottom: 2px solid #2563eb;
  padding-bottom: 8px;
}

@media screen and (min-width: 768px) {
  .active {
    padding-bottom: 12px;
  }
}

//src/components/AppItem/index.js

import './index.css'

const AppItem = props => {
  const {appDetails} = props
  const {appName, imageUrl} = appDetails

  return (
    <li className="app-item">
      <img className="app-image" src={imageUrl} alt={appName} />
      <p className="app-name">{appName}</p>
    </li>
  )
}

export default AppItem

//src/components/AppItem/index.css

.app-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  list-style-type: none;
  background-color: #ffffff;
  border-radius: 12px;
  padding-top: 16px;
  margin-left: 5px;
  margin-right: 5px;
  margin-bottom: 10px;
  width: 45%;
  max-width: 128px;
}

@media screen and (min-width: 768px) {
  .app-item {
    max-width: 198px;
    padding-top: 24px;
    margin-left: 10px;
    margin-right: 10px;
    margin-bottom: 20px;
  }
}

.app-image {
  width: 70px;
  height: 70px;
}

@media screen and (min-width: 768px) {
  .app-image {
    width: 102px;
    height: 102px;
  }
}

.app-name {
  color: #1e293b;
  font-family: 'Bree Serif';
  font-size: 16px;
}

@media screen and (min-width: 768px) {
  .app-name {
    font-family: 'Bree Serif';
    font-size: 24px;
  }
}

coding pratice-14:
-----------------------------------------------------------------------

Coin Toss Game:
---------------------

https://github.com/ManirathnamKuruma/ReactJS-CoinTossGame

1.Functionality to be added:

The app must have the following functionalities

1.1.Initially, the app should have heads image and total, heads, tails counts as 0

1.2.When the Toss Coin button is clicked, then the toss result should be generated using the below expression
	const tossResult = Math.floor(Math.random() * 2)
	
1.3.If the number generated from the given expression is 0 then the result should be heads or else the result should be tails

1.4.When the Toss Coin is clicked, and the result is heads then
	The heads image should be displayed
	The heads count should be incremented by one
	The total should be incremented by one
	
1.5.When the Toss Coin is clicked, and the result is tails then
	The tails image should be displayed
	The tails count should be incremented by one
	The total should be incremented by one
	
2.Implementation Files

Use these files to complete the implementation:

src/components/CoinToss/index.js
src/components/CoinToss/index.css

3.Important Note
Click to view

The following instructions are required for the tests to pass

The toss result image should have the alt attribute value as toss result

//src/components/CoinToss/index.js

import {Component} from 'react'

import './index.css'

const HEADS_IMG_URL = 'https://assets.ccbp.in/frontend/react-js/heads-img.png'

const TAILS_IMG_URL = 'https://assets.ccbp.in/frontend/react-js/tails-img.png'

class CoinToss extends Component {
  state = {
    tossResultImage: HEADS_IMG_URL,
    headsCount: 0,
    tailsCount: 0,
  }

  onTossCoin = () => {
    const {headsCount, tailsCount} = this.state
    const toss = Math.floor(Math.random() * 2)
    let tossImage = ''
    let latestHeadsCount = headsCount
    let latestTailsCount = tailsCount

    if (toss === 0) {
      tossImage = HEADS_IMG_URL
      latestHeadsCount += 1
    } else {
      tossImage = TAILS_IMG_URL
      latestTailsCount += 1
    }
    this.setState({
      tossResultImage: tossImage,
      headsCount: latestHeadsCount,
      tailsCount: latestTailsCount,
    })
  }

  render() {
    const {tossResultImage, headsCount, tailsCount} = this.state
    const totalCount = headsCount + tailsCount

    return (
      <div className="app-container">
        <div className="coin-toss-container">
          <h1 className="heading">Coin Toss Game</h1>
          <p className="description">Heads (or) Tails</p>
          <img
            src={tossResultImage}
            alt="toss result"
            className="toss-result-img"
          />
          <button type="button" className="button" onClick={this.onTossCoin}>
            Toss Coin
          </button>
          <div className="counts-container">
            <p className="count">Total: {totalCount}</p>
            <p className="count">Heads: {headsCount}</p>
            <p className="count">Tails: {tailsCount}</p>
          </div>
        </div>
      </div>
    )
  }
}

export default CoinToss

//src/components/CoinToss/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-image: linear-gradient(to left, #e2a139, #f9d423);
  min-height: 100vh;
}

.coin-toss-container {
  background-color: #ffffff;
  display: flex;
  flex-direction: column;
  align-items: center;
  border-radius: 16px;
  padding: 24px;
  width: 80%;
}

@media screen and (min-width: 768px) {
  .coin-toss-container {
    max-width: 500px;
    padding: 64px;
  }
}

.heading {
  text-align: center;
  color: #a35200;
  font-family: 'Roboto';
  font-size: 28px;
  font-weight: 500;
  margin-bottom: 8px;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 48px;
    margin-bottom: 16px;
  }
}

.description {
  color: #334155;
  font-family: 'Roboto';
  font-size: 20px;
  font-weight: 500;
  margin-top: 8px;
}

@media screen and (min-width: 768px) {
  .description {
    font-size: 24px;
    margin-top: 16px;
  }
}

.toss-result-img {
  width: 150px;
  height: 150px;
}

@media screen and (min-width: 768px) {
  .toss-result-img {
    width: 250px;
    height: 250px;
  }
}

.button {
  background-color: #ffda6f;
  color: #a35200;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
  border: none;
  border-radius: 8px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-left: 16px;
  padding-right: 16px;
  margin-top: 16px;
  outline: none;
  cursor: pointer;
}

@media screen and (min-width: 768px) {
  .button {
    margin-top: 32px;
  }
}

.counts-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 16px;
}

@media screen and (min-width: 768px) {
  .counts-container {
    margin-top: 32px;
  }
}

@media screen and (min-width: 768px) {
  .counts-container {
    flex-direction: row;
    justify-content: center;
    align-items: center;
    margin-top: 32px;
  }
}

.count {
  color: #475569;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  margin-left: 24px;
  margin-right: 24px;
}

//src/App.js

import CoinToss from './components/CoinToss'

import './App.css'

const App = () => <CoinToss />

export default App

coding pratice-15:
------------------------------------------------------------------------------------

Reviews App: --> Arrow Button
---------------------

https://github.com/ManirathnamKuruma/ReactJS-ReviewsApp

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

1.1.When the left arrow is clicked, then the previous review details should be displayed

1.2.When the right arrow is clicked, then the next review details should be displayed

1.3.If the review that is being displayed is the first in the list of reviews
	There should not be any state change when the left arrow is clicked
	
1.4.If the review that is being displayed is the last in the list of reviews
	There should not be any state change when the right arrow is clicked
	
1.5.The ReviewsCarousel component receives the reviewsList as a prop. It consists of a list of review objects with the following properties in each review object

Key			Data Type
imgUrl		String
username	String
companyName	String
description	String

2.Implementation Files

Use these files to complete the implementation:

src/components/ReviewsCarousel/index.js
src/components/ReviewsCarousel/index.css

3.Quick Tips
Click to view

You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

  cursor: pointer;
  
You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

  outline: none;
  
4.Important Note
Click to view

The following instructions are required for the tests to pass

The button to check the previous review should have the testid attribute with value as leftArrow
The button to check the next review should have the testid attribute with value as rightArrow
The profile images should have the alt as the value of the key username from each review object provided

//src/components/ReviewsCarousel/index.js

import {Component} from 'react'

import './index.css'

class ReviewsCarousel extends Component {
  state = {
    activeReviewIndex: 0,
  }

  onClickRightArrow = () => {
    const {activeReviewIndex} = this.state
    const {reviewsList} = this.props

    if (activeReviewIndex < reviewsList.length - 1) {
      this.setState(prevState => ({
        activeReviewIndex: prevState.activeReviewIndex + 1,
      }))
    }
  }

  renderActiveReview = review => {
    const {imgUrl, username, companyName, description} = review

    return (
      <div className="review-container">
        <img src={imgUrl} alt={username} />
        <p className="username">{username}</p>
        <p className="company">{companyName}</p>
        <p className="description">{description}</p>
      </div>
    )
  }

  onClickLeftArrow = () => {
    const {activeReviewIndex} = this.state

    if (activeReviewIndex > 0) {
      this.setState(prevState => ({
        activeReviewIndex: prevState.activeReviewIndex - 1,
      }))
    }
  }

  render() {
    const {reviewsList} = this.props
    const {activeReviewIndex} = this.state
    const currentReviewDetails = reviewsList[activeReviewIndex]

    return (
      <div className="app-container">
        <h1 className="heading">Reviews</h1>
        <div className="carousel-container">
          <button
            type="button"
            onClick={this.onClickLeftArrow}
            testid="leftArrow"
            className="arrow-button"
          >
            <img
              src="https://assets.ccbp.in/frontend/react-js/left-arrow-img.png"
              alt="left arrow"
            />
          </button>
          {this.renderActiveReview(currentReviewDetails)}
          <button
            type="button"
            onClick={this.onClickRightArrow}
            testid="rightArrow"
            className="arrow-button"
          >
            <img
              src="https://assets.ccbp.in/frontend/react-js/right-arrow-img.png"
              alt="right arrow"
            />
          </button>
        </div>
      </div>
    )
  }
}

export default ReviewsCarousel

//src/components/ReviewsCarousel/index.css

.app-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-image: url('https://assets.ccbp.in/frontend/react-js/reviews-bg.png');
  background-size: cover;
  height: 100vh;
}

.heading {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 40px;
  font-weight: 500;
  margin-top: 64px;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 48px;
    margin-top: 150px;
  }
}

.carousel-container {
  display: flex;
  align-items: center;
  width: 85%;
}

@media screen and (min-width: 768px) {
  .carousel-container {
    width: 45%;
    min-width: 622px;
  }
}

.arrow-button {
  background-color: transparent;
  border: none;
  cursor: pointer;
  outline: none;
}

.review-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 300px;
}

.username {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 18px;
  font-weight: 700;
}

.company {
  color: #171f46;
  font-family: 'Roboto';
  font-size: 14px;
}

.description {
  text-align: center;
  color: #171f46;
  font-family: 'Roboto';
  font-size: 16px;
}

//src/App.js

import ReviewsCarousel from './components/ReviewsCarousel'

import './App.css'

const reviewsList = [
  {
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/wade-warren-img.png',
    username: 'Wade Warren',
    companyName: 'Rang',
    description:
      'The most important thing I learnt is that nothing is a failure, but what we learn from that is a rich and rewarding experience.',
  },
  {
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/adrian-williams-img.png',
    username: 'Adrian Williams',
    companyName: 'WheelO',
    description:
      'Coming to Startup School is the best thing that has happened to me. I wish every startup in the country should get this opportunity.',
  },
  {
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/sherry-jhonson-img.png',
    username: 'Sherry Johnson',
    companyName: 'MedX',
    description:
      'I am glad to have such experienced mentors guiding us in every step through out the 4 weeks. I have improved personally and developed many interpersonal skills.',
  },
  {
    imgUrl: 'https://assets.ccbp.in/frontend/react-js/ronald-jones-img.png',
    username: 'Ronald Jones',
    companyName: 'Infinos Tech',
    description:
      'I am really loving the way how mentors are taking care of us, the way they are explaining big theories with lots of case studies and innovative methods.',
  },
]

const App = () => <ReviewsCarousel reviewsList={reviewsList} />

export default App

Working with Lists > On-Demand Session | Part 2 | Cheat Sheet:
--------------------------------------------------------------------------------------------------------------------------

Concepts in Focus:

1.Third-Party Packages
	Installing UUID
	Importing of UUID
	
2.Best Practice
	Updating a Property of an Item inside List
	
3.Contacts App Final Code

1. Third-Party Packages
UUID (Universally Unique IDentifier)
Using the UUID package, we can generate a unique id

1.1 Installing UUID

npm install uuid

1.2 Importing of UUID
UUID package provides uuidv4(), which returns a unique id whenever it is called.

import {v4 as uuidv4} from 'uuid'

2. Best Practice
The state should be immutable. We shouldn’t update the array/object directly.
The best practice is to create a new array/object from the array/object in the previous state using the spread operator.

wrong:

this.state.contactsList = initialContactsList

wrong:

this.state.contactsList.push(...)

correct:

this.setState(prevState => ({
  contactsList: [...prevState.contactsList, newContact ],
}))

2.1 Updating a Property of an Item inside List
We should not update the property of a list item directly. To update the property of a list item, we should create a new object and return it to the list.

Syntax:

{...object, newItem}

Exmaple:

File: src/App.js

import {Component} from 'react'
import {v4 as uuidv4} from 'uuid'

import ContactItem from './components/ContactItem'

import './App.css'

const initialContactsList = [
  {
    id: uuidv4(),
    name: 'Ram',
    mobileNo: 9999988888,
    isFavorite: false,
  },
  {
    id: uuidv4(),
    name: 'Pavan',
    mobileNo: 8888866666,
    isFavorite: true,
  },
  {
    id: uuidv4(),
    name: 'Nikhil',
    mobileNo: 9999955555,
    isFavorite: false,
  },
]

class App extends Component {
  state = {
    contactsList: initialContactsList,
    name: '',
    mobileNo: '',
  }

  toggleIsFavorite = id => {
    this.setState(prevState => ({
      contactsList: prevState.contactsList.map(eachContact => {
        if (id === eachContact.id) {
          //   eachContact.isFavorite = !eachContact.isFavorite
          return {...eachContact, isFavorite: !eachContact.isFavorite}
        }
        return eachContact
      }),
    }))
  }

  onAddContact = event => {
    event.preventDefault()
    const {name, mobileNo} = this.state
    const newContact = {
      id: uuidv4(),
      name,
      mobileNo,
      isFavorite: false,
    }

    this.setState(prevState => ({
      contactsList: [...prevState.contactsList, newContact],
      name: '',
      mobileNo: '',
    }))
  }

  onChangeMobileNo = event => {
    this.setState({mobileNo: event.target.value})
  }

  onChangeName = event => {
    this.setState({name: event.target.value})
  }

  render() {
    const {name, mobileNo, contactsList} = this.state
    return (
      <div className="app-container">
        <div className="responsive-container">
          <h1 className="heading">Contacts</h1>
          <form className="contact-form-container" onSubmit={this.onAddContact}>
            <input
              value={name}
              onChange={this.onChangeName}
              className="input"
              placeholder="Name"
            />
            <input
              className="input"
              value={mobileNo}
              onChange={this.onChangeMobileNo}
              placeholder="Mobile Number"
            />
            <button type="submit" className="button">
              Add Contact
            </button>
          </form>
          <ul className="contacts-table">
            <li className="table-header">
              <p className="table-header-cell name-column">Name</p>
              <hr className="separator" />
              <p className="table-header-cell">Mobile Number</p>
            </li>
            {contactsList.map(eachContact => (
              <ContactItem
                key={eachContact.id}
                contactDetails={eachContact}
                toggleIsFavorite={this.toggleIsFavorite}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default App

Initial code:
---------------------------

//src/components/ContactItem/index.js

import './index.css'

const ContactItem = props => {
  const {contactDetails} = props
  const {name, mobileNo, isFavorite} = contactDetails

  const starImgUrl = isFavorite
    ? 'https://assets.ccbp.in/frontend/react-js/star-filled-img.png'
    : 'https://assets.ccbp.in/frontend/react-js/star-outline-img.png'

  return (
    <li className="table-row">
      <div className="table-cell name-column">
        <p>{name}</p>
      </div>
      <hr className="separator" />
      <div className="table-cell mobile-no-column">
        <p className="mobile-no-value">{mobileNo}</p>
        <button type="button" className="favorite-icon-container">
          <img src={starImgUrl} className="favorite-icon" alt="star" />
        </button>
      </div>
    </li>
  )
}

export default ContactItem

//src/components/ContactItem/index.css

.table-row {
  display: flex;
  list-style-type: none;
  border-left: 1px solid #cbd5e1;
  border-bottom: 1px solid #cbd5e1;
  border-right: 1px solid #cbd5e1;
}

.table-cell {
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 16px;
  margin-left: 32px;
  display: flex;
  align-items: center;
}

.name-column {
  width: 33%;
}

.mobile-no-column {
  flex-grow: 1;
}

.mobile-no-value {
  flex-grow: 1;
}

.favorite-icon-container {
  background: transparent;
  outline: none;
  border: none;
  cursor: pointer;
}

.favorite-icon {
  background: transparent;
  margin-right: 24px;
  align-self: center;
  border: none;
  outline: none;
}

//src/App.js

import {Component} from 'react'

import ContactItem from './components/ContactItem'

import './App.css'

const initialContactsList = [
  {
    id: 1,
    name: 'Ram',
    mobileNo: 9999988888,
    isFavorite: false,
  },
  {
    id: 2,
    name: 'Pavan',
    mobileNo: 8888866666,
    isFavorite: true,
  },
  {
    id: 3,
    name: 'Nikhil',
    mobileNo: 9999955555,
    isFavorite: false,
  },
]

class App extends Component {
  state = {
    contactsList: initialContactsList,
    name: '',
    mobileNo: '',
  }

  onAddContact = event => {
    event.preventDefault()
  }

  onChangeMobileNo = event => {
    this.setState({mobileNo: event.target.value})
  }

  onChangeName = event => {
    this.setState({name: event.target.value})
  }

  render() {
    const {name, mobileNo, contactsList} = this.state
    return (
      <div className="app-container">
        <div className="responsive-container">
          <h1 className="heading">Contacts</h1>
          <form className="contact-form-container" onSubmit={this.onAddContact}>
            <input
              value={name}
              onChange={this.onChangeName}
              className="input"
              placeholder="Name"
            />
            <input
              className="input"
              value={mobileNo}
              onChange={this.onChangeMobileNo}
              placeholder="Mobile Number"
            />
            <button type="submit" className="button">
              Add Contact
            </button>
          </form>
          <ul className="contacts-table">
            <li className="table-header">
              <p className="table-header-cell name-column">Name</p>
              <hr className="separator" />
              <p className="table-header-cell">Mobile Number</p>
            </li>
            {contactsList.map(eachContact => (
              <ContactItem key={eachContact.id} contactDetails={eachContact} />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default App

3. Contacts App Final Code

//src/App.js

import {Component} from 'react'
import {v4 as uuidv4} from 'uuid'

import ContactItem from './components/ContactItem'

import './App.css'

const initialContactsList = [
  {
    id: uuidv4(),
    name: 'Ram',
    mobileNo: 9999988888,
    isFavorite: false,
  },
  {
    id: uuidv4(),
    name: 'Pavan',
    mobileNo: 8888866666,
    isFavorite: true,
  },
  {
    id: uuidv4(),
    name: 'Nikhil',
    mobileNo: 9999955555,
    isFavorite: false,
  },
]

class App extends Component {
  state = {
    contactsList: initialContactsList,
    name: '',
    mobileNo: '',
  }

  toggleIsFavorite = id => {
    this.setState(prevState => ({
      contactsList: prevState.contactsList.map(eachContact => {
        if (id === eachContact.id) {
          return {...eachContact, isFavorite: !eachContact.isFavorite}
        }
        return eachContact
      }),
    }))
  }

  onAddContact = event => {
    event.preventDefault()
    const {name, mobileNo} = this.state
    const newContact = {
      id: uuidv4(),
      name,
      mobileNo,
      isFavorite: false,
    }

    this.setState(prevState => ({
      contactsList: [...prevState.contactsList, newContact],
      name: '',
      mobileNo: '',
    }))
  }

  onChangeMobileNo = event => {
    this.setState({mobileNo: event.target.value})
  }

  onChangeName = event => {
    this.setState({name: event.target.value})
  }

  render() {
    const {name, mobileNo, contactsList} = this.state
    return (
      <div className="app-container">
        <div className="responsive-container">
          <h1 className="heading">Contacts</h1>
          <form className="contact-form-container" onSubmit={this.onAddContact}>
            <input
              value={name}
              onChange={this.onChangeName}
              className="input"
              placeholder="Name"
            />
            <input
              className="input"
              value={mobileNo}
              onChange={this.onChangeMobileNo}
              placeholder="Mobile Number"
            />
            <button type="submit" className="button">
              Add Contact
            </button>
          </form>
          <ul className="contacts-table">
            <li className="table-header">
              <p className="table-header-cell name-column">Name</p>
              <hr className="separator" />
              <p className="table-header-cell">Mobile Number</p>
            </li>
            {contactsList.map(eachContact => (
              <ContactItem
                key={eachContact.id}
                contactDetails={eachContact}
                toggleIsFavorite={this.toggleIsFavorite}
              />
            ))}
          </ul>
        </div>
      </div>
    )
  }
}

export default App

//src/components/ContactItem/index.js

import './index.css'

const ContactItem = props => {
  const {contactDetails, toggleIsFavorite} = props
  const {name, mobileNo, isFavorite, id} = contactDetails

  const starImgUrl = isFavorite
    ? 'https://assets.ccbp.in/frontend/react-js/star-filled-img.png'
    : 'https://assets.ccbp.in/frontend/react-js/star-outline-img.png'

  const onClickFavoriteIcon = () => {
    toggleIsFavorite(id)
  }

  return (
    <li className="table-row">
      <div className="table-cell name-column">
        <p>{name}</p>
      </div>
      <hr className="separator" />
      <div className="table-cell mobile-no-column">
        <p className="mobile-no-value">{mobileNo}</p>
        <button
          type="button"
          className="favorite-icon-container"
          onClick={onClickFavoriteIcon}
        >
          <img src={starImgUrl} className="favorite-icon" alt="star" />
        </button>
      </div>
    </li>
  )
}

export default ContactItem

mcq:
----------------

1.Considering the given code snippets, 
which of the following options will update the fruitsList state variable and the component is re-rendered when the Add Banana button is clicked?

// ---------------------------->> src/App.js <<-------------------------------
import {Component} from 'react'

class App extends Component {
  state = {
    fruitsList: ['Apple', 'Orange'],
  }

  onAddBanana = () => {
    // Your code
	
	this.setState(previousState => ({
      fruitsList: [...previousState.fruitsList, 'Banana'],
    }))
  }

  render() {
    const {fruitsList} = this.state
    return (
      <>
        <ul>
          {fruitsList.map(eachFruit => (
            <li key={eachFruit}>{eachFruit}</li>
          ))}
        </ul>
        <button type="button" onClick={this.onAddBanana}>
          Add Banana
        </button>
      </>
    )
  }
}

export default App

2.Considering the given code snippets, which of the following outputs is displayed on the web page when the Add Red and Orange button is clicked?

// ---------------------------->> src/App.js <<-------------------------------
import {Component} from 'react'

class App extends Component {
  state = {
    colorsList: ['blue', 'green'],
  }

  onAddRedAndOrangeColors = () => {
    this.setState(previousState => ({
      colorsList: [...previousState.colorsList, 'red', 'orange'],
    }))
  }

  render() {
    const {colorsList} = this.state
    return (
      <>
        <ul>
          {colorsList.map(eachColor => (
            <li key={eachColor}>{eachColor}</li>
          ))}
        </ul>
        <button type="button" onClick={this.onAddRedAndOrangeColors}>
          Add Red and Orange
        </button>
      </>
    )
  }
}

export default App

Output:

blue
green
red
orange

coding pratice-16:
-----------------------------------------

Comments App:
----------------------------

https://github.com/ManirathnamKuruma/ReactJS-CommentsApp

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

1.1.Initially, the list of comments should be zero and the inputs fields should be empty

1.2.When non-empty values are provided and Add Comment button is clicked,
	A new comment should be added to the list of comments
	The comments count should be incremented by one
	The value of the input fields for name and comment should be updated to their initial values
	
1.3.When the Like button of a comment is clicked, if the image for Like is
	Like image, then it should be changed to the Liked image
	Liked image, then it should be changed to the Like image
	
1.4.When the Delete button of a comment is clicked, the comment should be deleted from the list of comments and the comments count should be decremented by one

2.Implementation Files

Use these files to complete the implementation:

src/components/Comments/index.js
src/components/Comments/index.css
src/components/CommentItem/index.js
src/components/CommentItem/index.css

3.Quick Tips
Click to view

The formatDistanceToNow function in the date-fns package is used to return the gap between the given date and now in words.

import {formatDistanceToNow} from 'date-fns'

console.log(formatDistanceToNow(new Date())); // less than a minute

4.Important Note
Click to view

The following instructions are required for the tests to pass

HTML input element for name should have the placeholder as Your Name

HTML textarea element for comment should have the placeholder as Your Comment

The Like image for each comment should have the alt as like

The Delete button for each comment should have the testid as delete

To display how much time ago the comment was posted, we will use formatDistanceToNow function from date-fns package

//src/components/Comments/index.js

import {Component} from 'react'
import {v4} from 'uuid'

import CommentItem from '../CommentItem'

import './index.css'

const initialContainerBackgroundClassNames = [
  'amber',
  'blue',
  'orange',
  'emerald',
  'teal',
  'red',
  'light-blue',
]

class Comments extends Component {
  state = {
    nameInput: '',
    commentInput: '',
    commentsList: [],
  }

  deleteComment = commentId => {
    const {commentsList} = this.state

    this.setState({
      commentsList: commentsList.filter(comment => comment.id !== commentId),
    })
  }

  toggleIsLiked = id => {
    this.setState(prevState => ({
      commentsList: prevState.commentsList.map(eachComment => {
        if (id === eachComment.id) {
          return {...eachComment, isLiked: !eachComment.isLiked}
        }
        return eachComment
      }),
    }))
  }

  renderCommentsList = () => {
    const {commentsList} = this.state

    return commentsList.map(eachComment => (
      <CommentItem
        key={eachComment.id}
        commentDetails={eachComment}
        toggleIsLiked={this.toggleIsLiked}
        deleteComment={this.deleteComment}
      />
    ))
  }

  onAddComment = event => {
    event.preventDefault()
    const {nameInput, commentInput} = this.state
    const initialBackgroundColorClassName = `initial-container ${
      initialContainerBackgroundClassNames[
        Math.ceil(
          Math.random() * initialContainerBackgroundClassNames.length - 1,
        )
      ]
    }`
    const newComment = {
      id: v4(),
      name: nameInput,
      comment: commentInput,
      date: new Date(),
      isLiked: false,
      initialClassName: initialBackgroundColorClassName,
    }

    this.setState(prevState => ({
      commentsList: [...prevState.commentsList, newComment],
      nameInput: '',
      commentInput: '',
    }))
  }

  onChangeCommentInput = event => {
    this.setState({
      commentInput: event.target.value,
    })
  }

  onChangeNameInput = event => {
    this.setState({
      nameInput: event.target.value,
    })
  }

  render() {
    const {nameInput, commentInput, commentsList} = this.state

    return (
      <div className="app-container">
        <div className="comments-container">
          <h1 className="app-heading">Comments</h1>
          <div className="comments-inputs">
            <form className="form" onSubmit={this.onAddComment}>
              <p className="form-description">
                Say something about 4.0 Technologies
              </p>
              <input
                type="text"
                className="name-input"
                placeholder="Your Name"
                value={nameInput}
                onChange={this.onChangeNameInput}
              />
              <textarea
                placeholder="Your Comment"
                className="comment-input"
                value={commentInput}
                onChange={this.onChangeCommentInput}
                rows="6"
              />
              <button type="submit" className="add-button">
                Add Comment
              </button>
            </form>
            <img
              className="image"
              src="https://assets.ccbp.in/frontend/react-js/comments-app/comments-img.png"
              alt="comments"
            />
          </div>
          <hr className="line" />
          <p className="heading">
            <span className="comments-count">{commentsList.length}</span>
            Comments
          </p>
          <ul className="comments-list">{this.renderCommentsList()}</ul>
        </div>
      </div>
    )
  }
}

export default Comments

//src/components/Comments/index.css

.app-container {
  display: flex;
  justify-content: center;
  margin-top: 48px;
}

@media screen and (min-width: 768px) {
  .comments-app-container {
    margin-top: 96px;
  }
}

.comments-container {
  display: flex;
  flex-direction: column;
  width: 90%;
  max-width: 550px;
}

@media screen and (min-width: 768px) {
  .comments-container {
    width: 80%;
    max-width: 1140px;
  }
}

.line {
  border: 1px solid #dee0e3;
  width: 100%;
  margin-top: 16px;
}

.comments-inputs {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
}

@media screen and (min-width: 768px) {
  .comments-inputs {
    flex-direction: row;
  }
}

.app-heading {
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 48px;
  margin-bottom: 12px;
}

@media screen and (min-width: 768px) {
  .app-heading {
    font-size: 56px;
    margin-top: 0px;
    margin-bottom: 24px;
  }
}

.form-description {
  color: #475569;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  margin-top: 24px;
}

.form {
  display: flex;
  flex-direction: column;
  width: 100%;
  order: 1;
}

@media screen and (min-width: 768px) {
  .form {
    width: 28%;
    min-width: 300px;
    order: 0;
  }
}

.name-input {
  font-family: 'Roboto';
  font-size: 16px;
  height: 40px;
  border: 1px solid #cbd2d9;
  border-radius: 4px;
  margin-bottom: 12px;
  padding-left: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  outline: none;
}

.comment-input {
  font-family: 'Roboto';
  font-size: 16px;
  border: 1px solid #cbd2d9;
  border-radius: 4px;
  padding-left: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  outline: none;
}

.add-button {
  background-color: #0284c7;
  color: #ffffff;
  font-size: 14px;
  font-family: 'Roboto';
  border-radius: 4px;
  border: none;
  padding-left: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-right: 16px;
  margin-top: 16px;
  min-width: 60px;
  align-self: flex-start;
  outline: none;
  cursor: pointer;
}

.image {
  width: 280px;
  height: 200px;
}

@media screen and (min-width: 768px) {
  .image {
    width: 380px;
    height: 300px;
  }
}

.heading {
  color: #475569;
  font-family: 'Roboto';
  font-size: 14px;
  font-weight: 500;
  margin-left: 8px;
}

.comments-count {
  text-align: center;
  color: #ffffff;
  background-color: #0284c7;
  font-size: 12px;
  font-family: 'Roboto';
  border-radius: 4px;
  padding-left: 8px;
  padding-top: 4px;
  padding-bottom: 4px;
  padding-right: 8px;
  margin-right: 4px;
}

.comments-list {
  padding-left: 0;
  margin-top: 0;
}

//src/components/CommentItem/index.js

import {formatDistanceToNow} from 'date-fns'

import './index.css'

const CommentItem = props => {
  const {commentDetails} = props
  const {id, name, comment, isLiked, initialClassName, date} = commentDetails
  const initial = name ? name[0].toUpperCase() : ''
  const likeTextClassName = isLiked ? 'button active' : 'button'
  const likeImageUrl = isLiked
    ? 'https://assets.ccbp.in/frontend/react-js/comments-app/liked-img.png'
    : 'https://assets.ccbp.in/frontend/react-js/comments-app/like-img.png'
  const postedTime = formatDistanceToNow(date)

  const onClickLike = () => {
    const {toggleIsLiked} = props
    toggleIsLiked(id)
  }

  const onDeleteComment = () => {
    const {deleteComment} = props
    deleteComment(id)
  }

  return (
    <li className="comment-item">
      <div className="comment-container">
        <div className={initialClassName}>
          <p className="initial">{initial}</p>
        </div>
        <div>
          <div className="username-time-container">
            <p className="username">{name}</p>
            <p className="time">{postedTime} ago</p>
          </div>
          <p className="comment">{comment}</p>
        </div>
      </div>
      <div className="buttons-container">
        <div className="like-container">
          <img src={likeImageUrl} alt="like" className="like-image" />
          <button
            className={likeTextClassName}
            type="button"
            onClick={onClickLike}
          >
            Like
          </button>
        </div>
        <button
          className="button"
          type="button"
          onClick={onDeleteComment}
          testid="delete"
        >
          <img
            className="delete"
            src="https://assets.ccbp.in/frontend/react-js/comments-app/delete-img.png"
            alt="delete"
          />
        </button>
      </div>
      <hr className="comment-line" />
    </li>
  )
}

export default CommentItem

//src/components/CommentItem/index.css

.comment-item {
  list-style-type: none;
}

.comment-container {
  display: flex;
}

.initial-container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 32px;
  height: 32px;
  border-radius: 16px;
  margin-top: 18px;
  margin-right: 8px;
  flex-shrink: 0;
}

.amber {
  background-color: #f59e0b;
}

.blue {
  background-color: #0b69ff;
}

.orange {
  background-color: #f97316;
}

.emerald {
  background-color: #10b981;
}

.teal {
  background-color: #14b8a6;
}

.red {
  background-color: #b91c1c;
}

.light-blue {
  background-color: #0ea5e9;
}

.initial {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 16px;
  margin: 0;
}

.username-time-container {
  display: flex;
  align-items: center;
  margin-top: 20px;
  margin-bottom: 12px;
}

.username {
  color: #334155;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  margin-top: 0;
  margin-bottom: 0;
}

.time {
  color: #94a3b8;
  font-family: 'Roboto';
  font-size: 12px;
  margin-left: 18px;
  margin-top: 0;
  margin-bottom: 0;
}

.comment {
  color: #64748b;
  font-family: 'Roboto';
  font-size: 14px;
}

.buttons-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.like-container {
  display: flex;
  align-items: center;
}

.button {
  background-color: transparent;
  color: #7e858e;
  font-family: 'Roboto';
  font-size: 14px;
  font-weight: 500;
  border: none;
  outline: none;
  cursor: pointer;
}

.like-image {
  height: 20px;
  width: 20px;
  margin-right: 8px;
}

.active {
  color: #0ea5e9;
}

.delete {
  height: 20px;
  width: 20px;
}

.comment-line {
  width: 100%;
  border: 1px solid #dee0e3;
}

//src/App.js

import Comments from './components/Comments'

import './App.css'

const App = () => <Comments />

export default App

Appointments App:
----------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-AppointmentsApp

1.Completion Instructions:
Functionality to be added

The app must have the following functionalities

1.1.Initially, the list of appointments should be empty and the title input and date input should be empty

1.2.When non-empty values are provided for title and date and the Add button is clicked,
	A new appointment should be added to the list of appointments
	The value inside the input elements for title and date should be updated to their initial values
	
1.3.When the Star on an appointment is clicked, the appointment should be starred

1.4.The status of the Starred filter is updated by clicking on it

1.5.When the Starred filter is active, all the starred appointments should be filtered and displayed

1.6.When the Starred filter is inactive, the list of all appointments should be displayed

2.Implementation Files

Use these files to complete the implementation:

src/components/Appointments/index.js
src/components/Appointments/index.css
src/components/AppointmentItem/index.js
src/components/AppointmentItem/index.css

3.Quick Tips
Click to view

The HTML input element with the type date is designed for the user to select the date from a date picker

<input type="date" />

The format function in the date-fns package can be used to get the formatted date string in the given format

import {format} from 'date-fns'

console.log(format(new Date(2021, 19, 07), 'dd MMMM yyyy, EEEE')) // 19 July 2021, Monday

4.Important Note
Click to view

The following instructions are required for the tests to pass

For the format function, pass the format string dd MMMM yyyy, EEEE as the second argument
The star button in each appointment should have the testid as star
The star image in each appointment should have alt as star

//src/components/AppointmentItem/index.js

import './index.css'

const AppointmentIem = props => {
  const {appointmentDetails, toggleIsStarred} = props
  const {id, title, date, isStarred} = appointmentDetails
  const starImgUrl = isStarred
    ? 'https://assets.ccbp.in/frontend/react-js/appointments-app/filled-star-img.png'
    : 'https://assets.ccbp.in/frontend/react-js/appointments-app/star-img.png'

  const onClickStar = () => {
    toggleIsStarred(id)
  }

  return (
    <li className="appointment-item">
      <div className="header-container">
        <p className="title">{title}</p>
        <button
          type="button"
          testid="star"
          className="star-button"
          onClick={onClickStar}
        >
          <img src={starImgUrl} className="star" alt="star" />
        </button>
      </div>
      <p className="date">Date: {date}</p>
    </li>
  )
}

export default AppointmentIem

//src/components/AppointmentItem/index.css

.appointment-item {
  list-style-type: none;
  border: 1px solid #b5b7c4;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 16px;
}

@media screen and (min-width: 768px) {
  .appointment-item {
    margin-left: 12px;
    margin-right: 12px;
    margin-bottom: 32px;
    min-width: 297px;
  }
}

.header-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  margin-bottom: 10px;
}

.title {
  color: #171f46;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  margin: 0px;
}

@media screen and (min-width: 768px) {
  .list-title-heading {
    font-size: 18px;
  }
}

.star-button {
  background: transparent;
  padding: 0;
  border: none;
  outline: none;
  cursor: pointer;
}

.star {
  width: 20px;
  height: 20px;
  background: transparent;
  align-self: center;
  border: none;
  outline: none;
}

@media screen and (min-width: 768px) {
  .star {
    width: 24px;
    height: 24px;
  }
}

.date {
  color: #7e858e;
  font-family: 'Roboto';
  font-size: 12px;
  margin: 0px;
}

@media screen and (min-width: 768px) {
  .date {
    font-size: 16px;
  }
}

//src/components/Appointments/index.js

import {Component} from 'react'
import {v4} from 'uuid'
import {format} from 'date-fns'

import AppointmentItem from '../AppointmentItem'

import './index.css'

class Appointments extends Component {
  state = {
    appointmentsList: [],
    titleInput: '',
    dateInput: '',
    isFilterActive: false,
  }

  toggleIsStarred = id => {
    this.setState(prevState => ({
      appointmentsList: prevState.appointmentsList.map(eachAppointment => {
        if (id === eachAppointment.id) {
          return {...eachAppointment, isStarred: !eachAppointment.isStarred}
        }
        return eachAppointment
      }),
    }))
  }

  onFilter = () => {
    const {isFilterActive} = this.state

    this.setState({
      isFilterActive: !isFilterActive,
    })
  }

  onChangeDateInput = event => {
    this.setState({dateInput: event.target.value})
  }

  onChangeTitleInput = event => {
    this.setState({titleInput: event.target.value})
  }

  onAddAppointment = event => {
    event.preventDefault()
    const {titleInput, dateInput} = this.state
    const formattedDate = dateInput
      ? format(new Date(dateInput), 'dd MMMM yyyy, EEEE')
      : ''
    const newAppointment = {
      id: v4(),
      title: titleInput,
      date: formattedDate,
      isStarred: false,
    }
    console.log('addbuttonclicked', JSON.stringify(this.state))

    this.setState(prevState => ({
      appointmentsList: [...prevState.appointmentsList, newAppointment],
      titleInput: '',
      dateInput: '',
    }))
    console.log('addbuttonclicked', JSON.stringify(this.state))
  }

  getFilteredAppointmentsList = () => {
    const {appointmentsList, isFilterActive} = this.state

    if (isFilterActive) {
      return appointmentsList.filter(
        eachTransaction => eachTransaction.isStarred === true,
      )
    }
    return appointmentsList
  }

  render() {
    const {titleInput, dateInput, isFilterActive} = this.state
    const filterClassName = isFilterActive ? 'filter-filled' : 'filter-empty'
    const filteredAppointmentsList = this.getFilteredAppointmentsList()

    return (
      <div className="app-container">
        <div className="responsive-container">
          <div className="appointments-container">
            <div className="add-appointment-container">
              <form className="form" onSubmit={this.onAddAppointment}>
                <h1 className="add-appointment-heading">Add Appointment</h1>
                <label htmlFor="title" className="label">
                  TITLE
                </label>
                <input
                  type="text"
                  id="title"
                  value={titleInput}
                  onChange={this.onChangeTitleInput}
                  className="input"
                  placeholder="Title"
                />
                <label htmlFor="date" className="label">
                  DATE
                </label>
                <input
                  type="date"
                  id="date"
                  value={dateInput}
                  onChange={this.onChangeDateInput}
                  className="input"
                />
                <button type="submit" className="add-button">
                  Add
                </button>
              </form>
              <img
                src="https://assets.ccbp.in/frontend/react-js/appointments-app/appointments-img.png"
                alt="appointments"
                className="appointments-img"
              />
            </div>
            <hr className="hr" />
            <div className="header-with-filter-container">
              <h1 className="appointments-heading">Appointments</h1>
              <button
                type="button"
                className={`filter-style ${filterClassName}`}
                onClick={this.onFilter}
              >
                Starred
              </button>
            </div>
            <ul className="appointments-list">
              {filteredAppointmentsList.map(eachAppointment => (
                <AppointmentItem
                  key={eachAppointment.id}
                  appointmentDetails={eachAppointment}
                  toggleIsStarred={this.toggleIsStarred}
                />
              ))}
            </ul>
          </div>
        </div>
      </div>
    )
  }
}

export default Appointments

//src/components/Appointments/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-image: linear-gradient(to top, #9796f0, #fbc7d4);
  min-height: 100vh;
}

.responsive-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #ffffff;
  width: 85%;
  border-radius: 12px;
  max-width: 550px;
}

@media screen and (min-width: 768px) {
  .responsive-container {
    width: 78%;
    max-width: 1120px;
  }
}

.appointments-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 86%;
  max-width: 972px;
}

.add-appointment-container {
  display: flex;
  justify-content: space-between;
  width: 100%;
  margin-top: 64px;
}

.add-appointment-heading {
  color: #171f46;
  font-family: 'Roboto';
  font-size: 22px;
  font-weight: 500;
  margin-top: 0;
  margin-bottom: 24px;
}

@media screen and (min-width: 768px) {
  .add-appointment-heading {
    font-size: 32px;
    margin-bottom: 48px;
  }
}

.form {
  display: flex;
  flex-direction: column;
  width: 100%;
}

@media screen and (min-width: 768px) {
  .form {
    width: 45%;
    max-width: 320px;
  }
}

.label {
  color: #7e858e;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
  margin-bottom: 8px;
}

.input {
  color: #131415;
  font-family: 'Roboto';
  font-size: 12px;
  border: 1px solid #7e858e;
  border-radius: 4px;
  height: 40px;
  padding-left: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  margin-bottom: 24px;
  outline: none;
}

@media screen and (min-width: 768px) {
  .input {
    font-size: 14px;
  }
}

.add-button {
  align-self: flex-start;
  background-color: #8b5cf6;
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
  border: none;
  border-radius: 8px;
  padding-left: 16px;
  padding-right: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  outline: none;
}

.appointments-img {
  display: none;
}

@media screen and (min-width: 768px) {
  .appointments-img {
    display: block;
    width: 49%;
  }
}

.hr {
  border: 1px solid #b5b7c4;
  width: 100%;
  margin-top: 25px;
  margin-bottom: 32px;
}

.header-with-filter-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  align-self: stretch;
}

@media screen and (min-width: 768px) {
  .header-with-filter-container {
    padding-left: 12px;
    padding-right: 12px;
  }
}

.appointments-heading {
  color: #171f46;
  font-family: 'Roboto';
  font-size: 20px;
  font-weight: 500;
  margin: 0;
}

@media screen and (min-width: 768px) {
  .appointments-heading {
    font-size: 24px;
  }
}

.filter-style {
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 600;
  border-radius: 25px;
  padding-left: 16px;
  padding-top: 4px;
  padding-bottom: 4px;
  padding-right: 16px;
  border: none;
  outline: none;
}

.filter-filled {
  color: #ffffff;
  background-color: #9897f0;
}

.filter-empty {
  color: #9897f0;
  background-color: white;
  border: 1px solid #9897f0;
}

.appointments-list {
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 0px;
  margin-top: 24px;
}

@media screen and (min-width: 768px) {
  .appointments-list {
    flex-direction: row;
    flex-wrap: wrap;
  }
}

//src/App.js

import Appointments from './components/Appointments'

import './App.css'

const App = () => <Appointments />

export default App

coding pratice-17:
-----------------------------------------------------

Money Manager: --> Form
--------------------

https://github.com/ManirathnamKuruma/ReactJS-MoneyManager

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

1.1.Initially, Balance Amount, Income Amount, and Expenses Amount should be 0

1.2.Balance Amount should be calculated by removing the Expenses Amount from the Income Amount in the list of transactions

1.3.Income Amount should be calculated by removing the Expenses Amount in the list of transactions

1.4.Expenses Amount should be calculated by adding only Expenses Amount in the list of transactions

1.5.The MoneyManager component is provided with transactionTypeOptions. It consists of a list of transaction type objects with the following properties in each object

Key	Data 	Type
optionId	String
displayText	String

1.6.Initially, the value of the titleInput should be empty

1.7.Initially, the value of the amountInput should be empty

1.8.Initially, the first option in the list should be selected

1.9.hen a transaction is added, by providing the values in the titleInput, amountInput and optionId and Add button is clicked,
	A new transaction should be added to the transaction history list
	totalBalance, totalIncome and totalExpenses should be updated accordingly
	totalBalance = totalIncome - totalExpenses
	After updating, the values in the titleInput,amountInput and optionId will be updated to their initial values

1.10.When the delete button in the transaction history is clicked,
	The respective transaction should be deleted from the transaction history list
	totalBalance, totalIncome and totalExpenses should be updated accordingly\
	
2.Implementation Files

Use these files to complete the implementation:

src/App.js
src/components/MoneyManager/index.js
src/components/MoneyManager/index.css
src/components/MoneyDetails/index.js
src/components/MoneyDetails/index.css
src/components/TransactionItem/index.js
src/components/TransactionItem/index.css

3.Important Note
Click to view

The following instructions are required for the tests to pass

The Balance Amount should have the testid as balanceAmount
The Income Amount should have the testid as incomeAmount
The Expenses Amount should have the testid as expensesAmount
The Delete button for each transaction should have the testid as delete

//src/components/MoneyManager/index.js

import {Component} from 'react'
import {v4} from 'uuid'

import TransactionItem from '../TransactionItem'
import MoneyDetails from '../MoneyDetails'

import './index.css'

const transactionTypeOptions = [
  {
    optionId: 'INCOME',
    displayText: 'Income',
  },
  {
    optionId: 'EXPENSES',
    displayText: 'Expenses',
  },
]

class MoneyManager extends Component {
  state = {
    transactionsList: [],
    titleInput: '',
    amountInput: '',
    optionId: transactionTypeOptions[0].optionId,
  }

  deleteTransaction = id => {
    const {transactionsList} = this.state
    const updatedTransactionList = transactionsList.filter(
      eachTransaction => id !== eachTransaction.id,
    )

    this.setState({
      transactionsList: updatedTransactionList,
    })
  }

  onAddTransaction = event => {
    event.preventDefault()
    const {titleInput, amountInput, optionId} = this.state
    const typeOption = transactionTypeOptions.find(
      eachTransaction => eachTransaction.optionId === optionId,
    )
    const {displayText} = typeOption
    const newTransaction = {
      id: v4(),
      title: titleInput,
      amount: parseInt(amountInput),
      type: displayText,
    }

    this.setState(prevState => ({
      transactionsList: [...prevState.transactionsList, newTransaction],
      titleInput: '',
      amountInput: '',
      optionId: transactionTypeOptions[0].optionId,
    }))
  }

  onChangeOptionId = event => {
    this.setState({optionId: event.target.value})
  }

  onChangeAmountInput = event => {
    this.setState({amountInput: event.target.value})
  }

  onChangeTitleInput = event => {
    this.setState({titleInput: event.target.value})
  }

  getExpenses = () => {
    const {transactionsList} = this.state
    let expensesAmount = 0

    transactionsList.forEach(eachTransaction => {
      if (eachTransaction.type === transactionTypeOptions[1].displayText) {
        expensesAmount += eachTransaction.amount
      }
    })

    return expensesAmount
  }

  getIncome = () => {
    const {transactionsList} = this.state
    let incomeAmount = 0
    transactionsList.forEach(eachTransaction => {
      if (eachTransaction.type === transactionTypeOptions[0].displayText) {
        incomeAmount += eachTransaction.amount
      }
    })

    return incomeAmount
  }

  getBalance = () => {
    const {transactionsList} = this.state
    let balanceAmount = 0
    let incomeAmount = 0
    let expensesAmount = 0

    transactionsList.forEach(eachTransaction => {
      if (eachTransaction.type === transactionTypeOptions[0].displayText) {
        incomeAmount += eachTransaction.amount
      } else {
        expensesAmount += eachTransaction.amount
      }
    })

    balanceAmount = incomeAmount - expensesAmount

    return balanceAmount
  }

  render() {
    const {titleInput, amountInput, optionId, transactionsList} = this.state
    const balanceAmount = this.getBalance()
    const incomeAmount = this.getIncome()
    const expensesAmount = this.getExpenses()

    return (
      <div className="app-container">
        <div className="responsive-container">
          <div className="header-container">
            <h1 className="heading">Hi, Richard</h1>
            <p className="header-content">
              Welcome back to your
              <span className="money-manager-text"> Money Manager</span>
            </p>
          </div>
          <MoneyDetails
            balanceAmount={balanceAmount}
            incomeAmount={incomeAmount}
            expensesAmount={expensesAmount}
          />
          <div className="transaction-details">
            <form className="transaction-form" onSubmit={this.onAddTransaction}>
              <h1 className="transaction-header">Add Transaction</h1>
              <label className="input-label" htmlFor="title">
                TITLE
              </label>
              <input
                type="text"
                id="title"
                value={titleInput}
                onChange={this.onChangeTitleInput}
                className="input"
                placeholder="TITLE"
              />
              <label className="input-label" htmlFor="amount">
                AMOUNT
              </label>
              <input
                type="text"
                id="amount"
                className="input"
                value={amountInput}
                onChange={this.onChangeAmountInput}
                placeholder="AMOUNT"
              />
              <label className="input-label" htmlFor="select">
                TYPE
              </label>
              <select
                id="select"
                className="input"
                value={optionId}
                onChange={this.onChangeOptionId}
              >
                {transactionTypeOptions.map(eachOption => (
                  <option key={eachOption.optionId} value={eachOption.optionId}>
                    {eachOption.displayText}
                  </option>
                ))}
              </select>
              <button type="submit" className="button">
                Add
              </button>
            </form>
            <div className="history-transactions">
              <h1 className="transaction-header">History</h1>
              <div className="transactions-table-container">
                <ul className="transactions-table">
                  <li className="table-header">
                    <p className="table-header-cell">Title</p>
                    <p className="table-header-cell">Amount</p>
                    <p className="table-header-cell">Type</p>
                  </li>
                  {transactionsList.map(eachTransaction => (
                    <TransactionItem
                      key={eachTransaction.id}
                      transactionDetails={eachTransaction}
                      deleteTransaction={this.deleteTransaction}
                    />
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default MoneyManager

//src/components/MoneyManager/index.css

.app-container {
  display: flex;
  justify-content: center;
  min-height: 100vh;
}

.responsive-container {
  width: 80%;
  max-width: 550px;
}

@media screen and (min-width: 768px) {
  .responsive-container {
    max-width: 1140px;
  }
}

.header-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  background-image: url('https://res.cloudinary.com/do4qwwms8/image/upload/v1626263091/Money%20Manager/money-manager-header_rxlcrn.png');
  background-size: cover;
  height: 172px;
  border-radius: 16px;
  margin-top: 64px;
}

@media screen and (min-width: 768px) {
  .header-container {
    align-items: flex-start;
    padding: 48px;
  }
}

.heading {
  color: #475569;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 500;
  margin-bottom: 16px;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 30px;
  }
}

.header-content {
  color: #475569;
  font-family: 'Roboto';
  font-size: 14px;
  margin: 0px;
}

@media screen and (min-width: 768px) {
  .header-content {
    font-size: 18px;
  }
}

.money-manager-text {
  color: #0b69ff;
  font-weight: 500;
}

.transaction-details {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 100%;
  margin-bottom: 24px;
}

@media screen and (min-width: 768px) {
  .transaction-details {
    flex-direction: row;
  }
}

.transaction-form {
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: flex-start;
  height: 424px;
  width: 100%;
  border: 1px solid #cbd5e1;
  border-radius: 12px;
  padding-top: 24px;
  padding-right: 24px;
  padding-left: 24px;
  padding-bottom: 32px;
}

@media screen and (min-width: 768px) {
  .transaction-form {
    width: 40%;
    padding-right: 43px;
    padding-left: 48px;
  }
}

.transaction-header {
  color: #475569;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  line-height: 1.6;
}

@media screen and (min-width: 768px) {
  .transaction-header {
    font-size: 20px;
  }
}

.input-label {
  color: #7e858e;
  font-family: 'Roboto';
  font-weight: 500;
  font-size: 12px;
  line-height: 1.4;
  margin-bottom: 0px;
}

.input {
  color: #1e293b;
  background-color: #ffffff;
  font-family: 'Roboto';
  border: 1px solid #d7dfe9;
  border-radius: 2px;
  width: 100%;
  height: 40px;
  outline: none;
  padding: 10px;
  margin-bottom: 10px;
  min-width: 157px;
}

.button {
  background-color: #0b69ff;
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 14px;
  font-weight: 600;
  min-width: 25px;
  border-radius: 6px;
  border: none;
  padding-left: 24px;
  padding-top: 12px;
  padding-bottom: 12px;
  padding-right: 24px;
  outline: none;
  cursor: pointer;
  margin-bottom: 10px;
}

.history-transactions {
  width: 100%;
  min-height: 326px;
  border: 1px solid #cbd5e1;
  border-radius: 12px;
  padding-left: 24px;
  padding-top: 12px;
  padding-bottom: 12px;
  padding-right: 24px;
  margin-top: 32px;
}

@media screen and (min-width: 768px) {
  .history-transactions {
    width: 55%;
    min-height: 424px;
    padding-top: 24px;
    padding-left: 28px;
    padding-right: 41px;
    padding-bottom: 40px;
    margin-top: 0px;
    margin-left: 32px;
  }
}

.transactions-table-container {
  height: 100%;
  border-radius: 8px;
}

.transactions-table {
  padding-left: 0;
  margin: 0px;
}

.table-header {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  height: 48px;
  list-style-type: none;
  border: 1px solid #cbd5e1;
  padding-left: 10px;
  padding-right: 10px;
}

@media screen and (min-width: 768px) {
  .table-header {
    padding-left: 24px;
    padding-right: 24px;
  }
}

.table-header-cell {
  color: #334155;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
  width: 30%;
  border-right: none;
}

@media screen and (min-width: 768px) {
  .table-header-cell {
    font-size: 16px;
  }
}

//src/components/MoneyDetails/index.js

import './index.css'

const MoneyDetails = props => {
  const {balanceAmount, incomeAmount, expensesAmount} = props

  return (
    <div className="money-details-container">
      <div className="balance-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/money-manager/balance-image.png"
          alt="balance"
          className="details-img"
        />
        <div>
          <p className="details-text">Your Balance</p>
          <p className="details-money" testid="balanceAmount">
            Rs {balanceAmount}
          </p>
        </div>
      </div>
      <div className="income-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/money-manager/income-image.png"
          alt="income"
          className="details-img"
        />
        <div>
          <p className="details-text">Your Income</p>
          <p className="details-money" testid="incomeAmount">
            Rs {incomeAmount}
          </p>
        </div>
      </div>
      <div className="expenses-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/money-manager/expenses-image.png"
          alt="expenses"
          className="details-img"
        />
        <div>
          <p className="details-text">Your Expenses</p>
          <p className="details-money" testid="expensesAmount">
            Rs {expensesAmount}
          </p>
        </div>
      </div>
    </div>
  )
}

export default MoneyDetails

//src/components/MoneyDetails/index.css

.money-details-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  margin-bottom: 32px;
  margin-top: 32px;
}

@media screen and (min-width: 768px) {
  .money-details-container {
    flex-direction: row;
    justify-content: space-between;
  }
}

.balance-container {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  background-color: #ecfccb;
  width: 100%;
  border: 1px solid #84cc16;
  border-radius: 16px;
  margin-bottom: 16px;
}

@media screen and (min-width: 768px) {
  .balance-container {
    width: 30%;
    margin-right: 0px;
  }
}

.details-img {
  width: 64px;
  height: 64px;
  margin: 24px;
}

.details-text {
  color: #475569;
  font-size: 12px;
  font-family: 'Roboto';
  line-height: 1.7;
  margin: 0px;
  margin-bottom: 8px;
}

@media screen and (min-width: 768px) {
  .details-text {
    font-size: 14px;
  }
}

.details-money {
  color: #475569;
  font-size: 18px;
  font-family: 'Roboto';
  line-height: 1.3;
  margin: 0px;
}

@media screen and (min-width: 768px) {
  .details-money {
    font-size: 24px;
  }
}

.income-container {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  background-color: #cffafe;
  width: 100%;
  border: 1px solid #06b6d4;
  border-radius: 16px;
  margin-bottom: 16px;
}

@media screen and (min-width: 768px) {
  .income-container {
    width: 30%;
    margin-right: 0px;
  }
}

.expenses-container {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  background-color: #ede9fe;
  width: 100%;
  min-width: 200px;
  border: 1px solid #7c3aed;
  border-radius: 16px;
  margin-bottom: 16px;
}

@media screen and (min-width: 768px) {
  .expenses-container {
    width: 30%;
    margin-right: 0px;
  }
}

//src/components/TransactionItem/index.js

import './index.css'

const TransactionItem = props => {
  const {transactionDetails, deleteTransaction} = props
  const {id, title, amount, type} = transactionDetails

  const onDeleteTransaction = () => {
    deleteTransaction(id)
  }

  return (
    <li className="table-row">
      <p className="transaction-text">{title}</p>
      <p className="transaction-text">Rs {amount}</p>
      <p className="transaction-text">{type}</p>
      <div className="delete-container">
        <button
          className="delete-button"
          type="button"
          onClick={onDeleteTransaction}
          testid="delete"
        >
          <img
            className="delete-img"
            src="https://assets.ccbp.in/frontend/react-js/money-manager/delete.png"
            alt="delete"
          />
        </button>
      </div>
    </li>
  )
}

export default TransactionItem

//src/components/TransactionItem/index.css

.table-row {
  display: flex;
  justify-content: space-between;
  list-style-type: none;
  border-bottom: 1px solid #cbd5e1;
  border-right: 1px solid #cbd5e1;
  border-left: 1px solid #cbd5e1;
  padding-left: 10px;
  padding-right: 10px;
}

@media screen and (min-width: 768px) {
  .table-row {
    padding-left: 24px;
    padding-right: 24px;
  }
}

.transaction-text {
  color: #475569;
  font-family: 'Roboto';
  font-size: 12px;
  width: 30%;
}

@media screen and (min-width: 768px) {
  .transaction-text {
    font-size: 14px;
  }
}

.delete-container {
  display: flex;
  width: 10%;
}

.delete-button {
  background: transparent;
  outline: none;
  border: none;
  cursor: pointer;
}

.delete-img {
  background: transparent;
  width: 20px;
  height: 20px;
  align-self: center;
  border: none;
  outline: none;
}

@media screen and (min-width: 768px) {
  .delete-img {
    margin-right: 24px;
  }
}

//src/App.js

import MoneyManager from './components/MoneyManager'

import './App.css'

const App = () => <MoneyManager />

export default App

coding practice-18:
------------------------------------------------------------------------------------------------

Emoji Game: --> Navbar,card
------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-EmojiGame

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

1.1.Initially, the Score and Total Score for the current game should be 0

1.2.When an Emoji is clicked,
	If it is not the same as any of the previously clicked emojis, then the Score should be incremented by one
	
	If all the emojis are clicked exactly once
		Won Game view should be displayed
		
	If it is the same as any of the previously clicked emojis
		Lose Game view should be displayed
		
	If the score achieved in the current game is higher than the previous scores then the Top Score should be updated accordingly
	
1.3.When the Play Again button is clicked, then we should be able to play the game again
	The Score value should be reset but not the Top Score value
	
1.4.The EmojiGame component receives the emojisList as a prop. It consists of a list of emoji objects with the following properties in each emoji object

Key			Data Type
id			Number
emojiName	String
emojiUrl	String

2.Implementation Files

Use these files to complete the implementation:

src/components/EmojiGame/index.js
src/components/EmojiGame/index.css
src/components/NavBar/index.js
src/components/NavBar/index.css
src/components/EmojiCard/index.js
src/components/EmojiCard/index.css
src/components/WinOrLoseCard/index.js
src/components/WinOrLoseCard/index.css

3.Quick Tips
Click to view

You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

cursor: pointer;

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

4.Important Note
Click to view

The following instructions are required for the tests to pass

The emojis should have the alt as the value of the key emojiName from each emoji object

//src/components/EmojiCard/index.js

import './index.css'

const EmojiCard = props => {
  const {emojiDetails, clickEmoji} = props
  const {id, emojiName, emojiUrl} = emojiDetails

  const onClickEmojiCard = () => {
    clickEmoji(id)
  }

  return (
    <li className="emoji-item">
      <button type="button" className="emoji-btn" onClick={onClickEmojiCard}>
        <img className="emoji-icon" src={emojiUrl} alt={emojiName} />
      </button>
    </li>
  )
}

export default EmojiCard

//src/components/EmojiCard/index.css

.emoji-item {
  width: 32%;
  list-style-type: none;
  margin-top: 8px;
  margin-bottom: 8px;
}

@media screen and (min-width: 992px) {
  .emoji-item {
    width: 24%;
  }
}

.emoji-btn {
  background-color: #ffffff33;
  cursor: pointer;
  outline: none;
  width: 100%;
  height: 100px;
  border: 3px solid #ffffff30;
  border-radius: 24px;
}

@media screen and (min-width: 768px) {
  .emoji-btn {
    height: 200px;
  }
}

.emoji-icon {
  width: 50px;
}

@media screen and (min-width: 768px) {
  .emoji-icon {
    width: 100px;
  }
}

//src/components/NavBar/index.js

import './index.css'

const NavBar = props => {
  const {currentScore, isGameInProgress, topScore} = props

  return (
    <nav className="nav-bar-container">
      <div className="title-with-score-container">
        <div className="logo-and-title-container">
          <img
            className="emoji-logo"
            src="https://assets.ccbp.in/frontend/react-js/game-logo-img.png"
            alt="emoji logo"
          />
          <h1 className="title">Emoji Game</h1>
        </div>
        {isGameInProgress && (
          <div className="scores-container">
            <p className="score">Score: {currentScore}</p>
            <p className="score">Top Score: {topScore}</p>
          </div>
        )}
      </div>
    </nav>
  )
}

export default NavBar

//src/components/NavBar/index.css

.nav-bar-container {
  display: flex;
  justify-content: center;
  background-color: #ffffff33;
  padding: 8px;
}

.title-with-score-container {
  display: flex;
  justify-content: space-between;
  flex-basis: 80%;
  max-width: 1000px;
}

.logo-and-title-container {
  display: flex;
  align-items: center;
}

.emoji-logo {
  width: 24px;
}

@media screen and (min-width: 768px) {
  .emoji-logo {
    width: 48px;
  }
}

.title {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: bold;
}

@media screen and (min-width: 768px) {
  .title {
    font-size: 24px;
  }
}

.scores-container {
  display: flex;
}

.score {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
  margin-left: 16px;
}

@media screen and (min-width: 768px) {
  .score {
    font-size: 24px;
    margin-left: 32px;
  }
}

//src/components/WinOrLoseCard/index.js

import './index.css'

const LOSE_IMAGE = 'https://assets.ccbp.in/frontend/react-js/lose-game-img.png'
const WON_IMAGE = 'https://assets.ccbp.in/frontend/react-js/won-game-img.png'

const WinOrLoseCard = props => {
  const {isWon, onClickPlayAgain, score} = props
  const imageUrl = isWon ? WON_IMAGE : LOSE_IMAGE
  const gameStatus = isWon ? 'You Won' : 'You Lose'
  const scoreLabel = isWon ? 'Best Score' : 'Score'

  return (
    <div className="win-or-lose-card">
      <div className="details-section">
        <h1 className="game-status">{gameStatus}</h1>
        <p className="current-score-label">{scoreLabel}</p>
        <p className="current-score-value">{score}/12</p>
        <button
          type="button"
          className="play-again-button"
          onClick={onClickPlayAgain}
        >
          Play Again
        </button>
      </div>
      <div className="image-section">
        <img className="win-or-lose-image" src={imageUrl} alt="win or lose" />
      </div>
    </div>
  )
}

export default WinOrLoseCard

//src/components/WinOrLoseCard/index.css

.win-or-lose-card {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  background-color: #ffffff33;
  width: 85%;
  border: 3px solid #ffffff30;
  border-radius: 24px;
  margin: auto;
  padding: 16px;
}

@media screen and (min-width: 768px) {
  .win-or-lose-card {
    width: 80%;
    padding: 32px;
  }
}

@media screen and (min-width: 992px) {
  .win-or-lose-card {
    flex-direction: row;
    width: 70%;
  }
}

@media screen and (min-width: 1200px) {
  .win-or-lose-card {
    width: 60%;
  }
}

.details-section {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  order: 1;
}

@media screen and (min-width: 992px) {
  .details-section {
    order: 0;
  }
}

.game-status {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 32px;
  font-weight: bold;
}

@media screen and (min-width: 992px) {
  .game-status {
    font-size: 64px;
  }
}

.current-score-label {
  text-align: center;
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 18px;
  font-weight: bold;
  margin: 0px;
}

@media screen and (min-width: 992px) {
  .current-score-label {
    font-size: 36px;
  }
}

.current-score-value {
  text-align: center;
  color: #6a59ff;
  font-family: 'Roboto';
  font-size: 32px;
  font-weight: bold;
  margin: 0px;
}

@media screen and (min-width: 768px) {
  .current-score-value {
    font-size: 48px;
  }
}

.play-again-button {
  color: #3d3d3d;
  background-color: #ffce27;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: bold;
  border: none;
  border-radius: 20px;
  margin: 16px;
  padding: 16px;
  padding-right: 24px;
  padding-left: 24px;
  cursor: pointer;
  outline: none;
}

.image-section {
  display: flex;
  justify-content: center;
  order: 0;
}

@media screen and (min-width: 992px) {
  .image-section {
    order: 1;
  }
}

.win-or-lose-image {
  width: 150px;
  height: 200px;
}

@media screen and (min-width: 992px) {
  .win-or-lose-image {
    width: 350px;
    height: 450px;
  }
}

//src/components/EmojiGame/index.js

/* 
Quick Tip 

- Use the below function in the EmojiGame Component to shuffle the emojisList every time when an emoji is clicked.

const shuffledEmojisList = () => {
  const {emojisList} = this.props
  return emojisList.sort(() => Math.random() - 0.5)
}

*/

import {Component} from 'react'

import EmojiCard from '../EmojiCard'
import NavBar from '../NavBar'
import WinOrLoseCard from '../WinOrLoseCard'

import './index.css'

class EmojiGame extends Component {
  state = {
    clickedEmojisList: [],
    isGameInProgress: true,
    topScore: 0,
  }

  resetGame = () => {
    this.setState({clickedEmojisList: [], isGameInProgress: true})
  }

  renderScoreCard = () => {
    const {emojisList} = this.props
    const {clickedEmojisList} = this.state
    const isWon = clickedEmojisList.length === emojisList.length

    return (
      <WinOrLoseCard
        isWon={isWon}
        onClickPlayAgain={this.resetGame}
        score={clickedEmojisList.length}
      />
    )
  }

  finishGameAndSetTopScore = currentScore => {
    const {topScore} = this.state
    let newTopScore = topScore

    if (currentScore > topScore) {
      newTopScore = currentScore
    }

    this.setState({topScore: newTopScore, isGameInProgress: false})
  }

  clickEmoji = id => {
    const {emojisList} = this.props
    const {clickedEmojisList} = this.state
    const isEmojiPresent = clickedEmojisList.includes(id)
    const clickedEmojisLength = clickedEmojisList.length

    if (isEmojiPresent) {
      this.finishGameAndSetTopScore(clickedEmojisLength)
    } else {
      if (emojisList.length - 1 === clickedEmojisLength) {
        this.finishGameAndSetTopScore(emojisList.length)
      }
      this.setState(previousState => ({
        clickedEmojisList: [...previousState.clickedEmojisList, id],
      }))
    }
  }

  getShuffledEmojisList = () => {
    const {emojisList} = this.props

    return emojisList.sort(() => Math.random() - 0.5)
  }

  renderEmojisList = () => {
    const shuffledEmojisList = this.getShuffledEmojisList()

    return (
      <ul className="emojis-list-container">
        {shuffledEmojisList.map(emojiObject => (
          <EmojiCard
            key={emojiObject.id}
            emojiDetails={emojiObject}
            clickEmoji={this.clickEmoji}
          />
        ))}
      </ul>
    )
  }

  render() {
    const {clickedEmojisList, isGameInProgress, topScore} = this.state

    return (
      <div className="app-container">
        <NavBar
          currentScore={clickedEmojisList.length}
          isGameInProgress={isGameInProgress}
          topScore={topScore}
        />
        <div className="emoji-game-body">
          {isGameInProgress ? this.renderEmojisList() : this.renderScoreCard()}
        </div>
      </div>
    )
  }
}

export default EmojiGame

//src/components/EmojiGame/index.css

.app-container {
  display: flex;
  flex-direction: column;
  background-image: linear-gradient(
    to bottom right,
    #9796f0 0.5%,
    #fbc7d4 150%
  );
  min-height: 100vh;
}

.emoji-game-body {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 1;
}

.emojis-list-container {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  width: 80%;
  margin: auto;
  padding: 0px;
  max-width: 1000px;
}

//src/App.js

import EmojiGame from './components/EmojiGame'

import './App.css'

const emojisList = [
  {
    id: 0,
    emojiName: 'Face with stuck out tongue',
    emojiUrl:
      'https://assets.ccbp.in/frontend/react-js/face-with-stuck-out-tongue-img.png',
  },
  {
    id: 1,
    emojiName: 'Face with head bandage',
    emojiUrl:
      'https://assets.ccbp.in/frontend/react-js/face-with-head-bandage-img.png',
  },
  {
    id: 2,
    emojiName: 'Face with hugs',
    emojiUrl: 'https://assets.ccbp.in/frontend/react-js/face-with-hugs-img.png',
  },
  {
    id: 3,
    emojiName: 'Face with laughing',
    emojiUrl:
      'https://assets.ccbp.in/frontend/react-js/face-with-laughing-img.png',
  },
  {
    id: 4,
    emojiName: 'Laughing face with hand in front of mouth',
    emojiUrl:
      'https://assets.ccbp.in/frontend/react-js/face-with-laughing-with-hand-infront-mouth-img.png',
  },
  {
    id: 5,
    emojiName: 'Face with mask',
    emojiUrl: 'https://assets.ccbp.in/frontend/react-js/face-with-mask-img.png',
  },
  {
    id: 6,
    emojiName: 'Face with silence',
    emojiUrl:
      'https://assets.ccbp.in/frontend/react-js/face-with-silence-img.png',
  },
  {
    id: 7,
    emojiName: 'Face with stuck out tongue and winked eye',
    emojiUrl:
      'https://assets.ccbp.in/frontend/react-js/face-with-stuck-out-tongue-and-winking-eye-img.png',
  },
  {
    id: 8,
    emojiName: 'Grinning face with sweat',
    emojiUrl:
      'https://assets.ccbp.in/frontend/react-js/grinning-face-with-sweat-img.png',
  },
  {
    id: 9,
    emojiName: 'Smiling face with heart eyes',
    emojiUrl:
      'https://assets.ccbp.in/frontend/react-js/smiling-face-with-heart-eyes-img.png',
  },
  {
    id: 10,
    emojiName: 'Grinning face',
    emojiUrl: 'https://assets.ccbp.in/frontend/react-js/grinning-face-img.png',
  },
  {
    id: 11,
    emojiName: 'Smiling face with star eyes',
    emojiUrl:
      'https://assets.ccbp.in/frontend/react-js/smiling-face-with-star-eyes-img.png',
  },
]

const App = () => <EmojiGame emojisList={emojisList} />

export default App

Component Life Cycle | Cheat Sheet:
----------------------------------------------------------

Concepts in Focus:

Component Life Cycle Phases:

1.Mounting Phase
	constructor()
	render()
	componentDidMount()
	
2.Updating Phase
	render()
	
3.Unmounting Phase
	componentWillUnmount()

Behind the scenes
	Virtual DOM
	
Clock Example

1. Component Life Cycle Phases
Every React Component goes through three phases throughout its lifetime:

Mounting Phase
Updating Phase
Unmounting phase

2. Mounting Phase
In this phase, the instance of a component is created and inserted into the DOM.

2.1 Methods
We mainly use the three methods. The three methods are called in the given order:

constructor()
render()
componentDidMount()

2.1.1 constructor()
The constructor() method is used to set up the initial state and class variables.

Syntax:

constructor(props) {
  super(props)
  //state and class variables
}

We must call the super(props) method before any other statement. Calling super(props) makes sure that 
constructor() of the React.Component gets called and initializes the instance.

Initialising State through props

constructor(props) {
  super(props)
  this.state = { date: props.date }
}

2.1.2 render()
The render() method is used to return the JSX that is displayed in the UI.

2.1.3 componentDidMount()
The componentDidMount() method is used to run statements that require that the component is already placed in the DOM.

Example: set timers, initiate API calls, etc.

3. Updating Phase
In this phase, the component is updated whenever there is a change in the component's state.

3.1 Methods

3.1.1 render()
The render() method is called whenever there is a change in the component's state.

4. Unmounting Phase
In this phase, the component instance is removed from the DOM.

4.1 Methods

4.1.1 componentWillUnmount()
The componentWillUnmount() method is used to cleanup activities performed.

Example: clearing timers, cancelling API calls, etc.

5. Clock Example

File: src/App.js

import {Component} from 'react'
import Clock from './components/Clock'

import './App.css'

class App extends Component {
  state = {
    showClock: false
  }
  onToggleClock = () => {
    this.setState( prevState => {
      const { showClock } = prevState
      return {
        showClock: !showClock
      }
    })
  }
  render() {
    const { showClock } = this.state
    return (
      <div className="app-container">
        <button onClick={ this.onToggleClock } type="button" className="toggle-button">
          {showClock ? 'Show Clock' : 'Hide Clock'}
        </button>
        {showClock && <Clock />}
      </div>
    )
  }
}

export default App

Note
The logical && operator can be handy for conditionally including an element or component.

File: src/components/Clock/index.js

import {Component} from 'react'
import './index.css'

class Clock extends Component {
  constructor(props) {
    super(props)
    this.state = { date: new Date() }
  }
  componentDidMount() {
    this.timerID = setInterval(this.tick, 1000)
  }
  componentWillUnmount() {
    clearInterval(this.timerID)
  }
  tick = () => {
    this.setState({
      date: new Date()
    })
  }
  render() {
    const { date } = this.state
    return (
      <div className="clock-container">
        <h1 className="heading">Clock</h1>
        <p className="time">{date.toLocaleTimeString()}</p>
      </div>
    )
  }
}

export default Clock

File: src/components/Clock/index.css

.clock-container {
  background-color: #ffffff15;
  border-radius: 16px;
  padding: 30px 50px 40px 50px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.heading {
  color: white;
  font-size: 40px;
  margin-bottom: 20px;
  font-family: 'Roboto';
  font-weight: 400;
}

.time {
  color: white;
  font-size: 60px;
  margin: 20px;
  font-family: 'Roboto';
}

coding practice-19:
----------------------------------------------------------------------------

Digital Timer App:
-------------------------

https://github.com/ManirathnamKuruma/ReactJS-DigitalTimerApp

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

1.1.The default timer limit value should be 25 minutes

1.2.When the Start button is clicked,
	The Start text should change to Pause text
	The play icon should be replaced by pause icon
	The Timer status should change to Running
	The Timer should start running backwards from the timer limit value set
	If the Timer has been paused after starting, it should resume from where it was paused
	Both the Plus and Minus buttons should be disabled
	
1.3.When the Pause button is clicked,
	The Pause text should change to Start text
	The pause icon should be replaced by play icon
	The Timer should stop running backwards
	The Timer status should change to Paused
	Both the Plus and Minus buttons should be disabled
	
1.4.When the button with the Plus symbol is clicked,
	The timer limit value should be incremented by one minute
	The Timer should display time with the increased timer limit value
	
1.5.When the button with the Minus symbol is clicked,
	The timer limit value should be decremented by one minute
	The Timer should display time with the decreased timer limit value
	
1.6.When the timer limit value is modified by clicking the Plus or Minus button and the Start button is clicked, then the Timer should start with the modified timer value

1.7.When the Timer ends (displays 00:00)
	The Pause text should change to Start text
	The pause icon should be replaced by play icon
	The Timer should stop running backwards
	The Timer status should change to Paused
	
1.8.After completion of Timer, when the Start button is clicked,
	The Start text should change to Pause text
	The play icon should be replaced by pause icon
	The Timer should start running backwards from the current timer limit value.
	The Timer status should change to Running
	
1.9.When the Reset button is clicked, then
	The Pause text should change to Start text
	The pause icon should be replaced by play icon
	The Timer should stop running backwards
	The Timer status should change to Paused
	Initial Timer limit value should be displayed
	Both the Plus and Minus buttons should be enabled
	
2.Implementation Files

Use these files to complete the implementation:

src/components/DigitalTimer/index.js
src/components/DigitalTimer/index.css

3.Quick Tips
Click to view

You can use the box-shadow CSS property to apply the box-shadow effect to containers

box-shadow: 0px 4px 16px 0px #bfbfbf;

You can use Math.floor() function that returns the largest integer less than or equal to a given number
console.log(Math.floor(5.95)); // output: 5

You can use the background-position CSS property to set the starting position of a background image
background-position: center;

//src/components/DigitalTimer/index.js

import {Component} from 'react'

import './index.css'

const initialState = {
  isTimerRunning: false,
  timeElapsedInSeconds: 0,
  timerLimitInMinutes: 25,
}

class DigitalTimer extends Component {
  state = initialState

  componentWillUnmount() {
    this.clearTimerInterval()
  }

  clearTimerInterval = () => clearInterval(this.intervalId)

  onDecreaseTimerLimitInMinutes = () => {
    const {timerLimitInMinutes} = this.state

    if (timerLimitInMinutes > 1) {
      this.setState(prevState => ({
        timerLimitInMinutes: prevState.timerLimitInMinutes - 1,
      }))
    }
  }

  onIncreaseTimerLimitInMinutes = () =>
    this.setState(prevState => ({
      timerLimitInMinutes: prevState.timerLimitInMinutes + 1,
    }))

  renderTimerLimitController = () => {
    const {timerLimitInMinutes, timeElapsedInSeconds} = this.state
    const isButtonsDisabled = timeElapsedInSeconds > 0

    return (
      <div className="timer-limit-controller-container">
        <p className="limit-label">Set Timer limit</p>
        <div className="timer-limit-controller">
          <button
            className="limit-controller-button"
            disabled={isButtonsDisabled}
            onClick={this.onDecreaseTimerLimitInMinutes}
            type="button"
          >
            -
          </button>
          <div className="limit-label-and-value-container">
            <p className="limit-value">{timerLimitInMinutes}</p>
          </div>
          <button
            className="limit-controller-button"
            disabled={isButtonsDisabled}
            onClick={this.onIncreaseTimerLimitInMinutes}
            type="button"
          >
            +
          </button>
        </div>
      </div>
    )
  }

  onResetTimer = () => {
    this.clearTimerInterval()
    this.setState(initialState)
  }

  incrementTimeElapsedInSeconds = () => {
    const {timerLimitInMinutes, timeElapsedInSeconds} = this.state
    const isTimerCompleted = timeElapsedInSeconds === timerLimitInMinutes * 60

    if (isTimerCompleted) {
      this.clearTimerInterval()
      this.setState({isTimerRunning: false})
    } else {
      this.setState(prevState => ({
        timeElapsedInSeconds: prevState.timeElapsedInSeconds + 1,
      }))
    }
  }

  onStartOrPauseTimer = () => {
    const {
      isTimerRunning,
      timeElapsedInSeconds,
      timerLimitInMinutes,
    } = this.state
    const isTimerCompleted = timeElapsedInSeconds === timerLimitInMinutes * 60

    if (isTimerCompleted) {
      this.setState({timeElapsedInSeconds: 0})
    }
    if (isTimerRunning) {
      this.clearTimerInterval()
    } else {
      this.intervalId = setInterval(this.incrementTimeElapsedInSeconds, 1000)
    }
    this.setState(prevState => ({isTimerRunning: !prevState.isTimerRunning}))
  }

  renderTimerController = () => {
    const {isTimerRunning} = this.state
    const startOrPauseImageUrl = isTimerRunning
      ? 'https://assets.ccbp.in/frontend/react-js/pause-icon-img.png'
      : 'https://assets.ccbp.in/frontend/react-js/play-icon-img.png'
    const startOrPauseAltText = isTimerRunning ? 'pause icon' : 'play icon'

    return (
      <div className="timer-controller-container">
        <button
          className="timer-controller-btn"
          onClick={this.onStartOrPauseTimer}
          type="button"
        >
          <img
            alt={startOrPauseAltText}
            className="timer-controller-icon"
            src={startOrPauseImageUrl}
          />
          <p className="timer-controller-label">
            {isTimerRunning ? 'Pause' : 'Start'}
          </p>
        </button>
        <button
          className="timer-controller-btn"
          onClick={this.onResetTimer}
          type="button"
        >
          <img
            alt="reset icon"
            className="timer-controller-icon"
            src="https://assets.ccbp.in/frontend/react-js/reset-icon-img.png"
          />
          <p className="timer-controller-label">Reset</p>
        </button>
      </div>
    )
  }

  getElapsedSecondsInTimeFormat = () => {
    const {timerLimitInMinutes, timeElapsedInSeconds} = this.state
    const totalRemainingSeconds =
      timerLimitInMinutes * 60 - timeElapsedInSeconds
    const minutes = Math.floor(totalRemainingSeconds / 60)
    const seconds = Math.floor(totalRemainingSeconds % 60)
    const stringifiedMinutes = minutes > 9 ? minutes : `0${minutes}`
    const stringifiedSeconds = seconds > 9 ? seconds : `0${seconds}`

    return `${stringifiedMinutes}:${stringifiedSeconds}`
  }

  render() {
    const {isTimerRunning} = this.state
    const labelText = isTimerRunning ? 'Running' : 'Paused'

    return (
      <div className="app-container">
        <h1 className="heading">Digital Timer</h1>
        <div className="digital-timer-container">
          <div className="timer-display-container">
            <div className="elapsed-time-container">
              <h1 className="elapsed-time">
                {this.getElapsedSecondsInTimeFormat()}
              </h1>
              <p className="timer-state">{labelText}</p>
            </div>
          </div>
          <div className="controls-container">
            {this.renderTimerController()}
            {this.renderTimerLimitController()}
          </div>
        </div>
      </div>
    )
  }
}

export default DigitalTimer

//src/components/DigitalTimer/index.css

.app-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-image: linear-gradient(
    to bottom,
    #ffffff,
    #cffcf1,
    #cffcf1,
    #defafe
  );
}

@media screen and (min-width: 768px) {
  .app-container {
    background-image: linear-gradient(
      to right,
      #ffffff,
      #cffcf1,
      #cffcf1,
      #defafe
    );
  }
}

.heading {
  color: #0f172a;
  font-family: 'Roboto';
  font-size: 32px;
  font-weight: 500;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 48px;
  }
}

.digital-timer-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 90%;
}

@media screen and (min-width: 768px) {
  .digital-timer-container {
    flex-direction: row;
    max-width: 1140px;
  }
}

.timer-display-container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 320px;
  height: 250px;
  background-image: url('https://assets.ccbp.in/frontend/react-js/digital-timer-elapsed-bg.png');
  background-size: cover;
  background-position: center;
}

@media (min-width: 576px) {
  .timer-display-container {
    width: 450px;
    height: 320px;
  }
}

@media screen and (min-width: 768px) {
  .timer-display-container {
    width: 600px;
    height: 450px;
  }
}

@media (min-width: 992px) {
  .timer-display-container {
    width: 600px;
    height: 600px;
  }
}

.elapsed-time-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #ffffff;
  width: 100px;
  height: 100px;
  border-radius: 100%;
}

@media (min-width: 576px) {
  .elapsed-time-container {
    width: 150px;
    height: 150px;
  }
}

@media screen and (min-width: 768px) {
  .elapsed-time-container {
    width: 200px;
    height: 200px;
  }
}

.elapsed-time {
  color: #00d9f5;
  font-family: 'Roboto';
  font-size: 28px;
  font-weight: bold;
  margin: 0px;
}

@media screen and (min-width: 768px) {
  .elapsed-time {
    font-size: 48px;
  }
}

.timer-state {
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 14px;
  font-weight: bold;
  margin: 0px;
}

@media screen and (min-width: 768px) {
  .timer-state {
    font-size: 24px;
  }
}

.controls-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  flex-grow: 1;
}

.timer-controller-container {
  display: flex;
  align-items: center;
}

.timer-controller-btn {
  display: flex;
  align-items: center;
  background-color: transparent;
  border: none;
  margin-right: 16px;
  margin-left: 16px;
  padding: 0px;
  cursor: pointer;
  outline: none;
}

.timer-controller-icon {
  width: 24px;
  height: 24px;
  margin-right: 8px;
}

@media (min-width: 576px) {
  .timer-controller-icon {
    width: 36px;
    height: 36px;
    margin-right: 12px;
  }
}

.timer-controller-label {
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 500;
}

@media (min-width: 576px) {
  .timer-controller-label {
    font-size: 32px;
  }
}

.timer-limit-controller-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.limit-label {
  color: #1e293b;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: 500;
}

.timer-limit-controller {
  display: flex;
  align-items: center;
}

.limit-controller-button {
  color: #1e293b;
  background-color: transparent;
  font-family: 'Roboto';
  font-size: 40px;
  font-weight: 500;
  border: none;
  margin: 8px;
  cursor: pointer;
  outline: none;
}

.limit-label-and-value-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 8px;
}

.limit-value {
  text-align: center;
  color: #1e293b;
  background-image: linear-gradient(to right, #00f5a0, #00d9f5);
  font-family: 'Roboto';
  font-size: 32px;
  font-weight: 500;
  width: 100px;
  border-radius: 8px;
  margin: 0px;
  padding: 8px;
}

//src/App.js

import DigitalTimer from './components/DigitalTimer'

import './App.css'

const App = () => <DigitalTimer />

export default App

coding practice-20:
----------------------------------------------------------------------------------------------

Stopwatch:
-----------------

In this project, let's build a Stopwatch by applying the concepts we have learned till now.

https://github.com/ManirathnamKuruma/ReactJS-StopWatch

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

When the Start button is clicked, then the Stopwatch should start running
When the Stop button is clicked, then the Stopwatch should stop running
When the Reset button is clicked, then the Stopwatch should be reset to zero

2.Implementation Files

Use these files to complete the implementation:

src/components/Stopwatch/index.js
src/components/Stopwatch/index.css

3.Quick Tips
Click to view

You can use the box-shadow CSS property to apply the box-shadow effect to containers

box-shadow: 0px 4px 16px 0px #bfbfbf;

You can use Math.floor() function that returns the largest integer less than or equal to a given number

console.log(Math.floor(5.95)); // output: 5

//src/components/Stopwatch/index.js

import {Component} from 'react'

import './index.css'

class Stopwatch extends Component {
  state = {
    isTimerRunning: false,
    timeElapsedInSeconds: 0,
  }

  componentWillUnmount() {
    clearInterval(this.timeInterval)
  }

  onResetTimer = () => {
    clearInterval(this.timeInterval)
    this.setState({isTimerRunning: false, timeElapsedInSeconds: 0})
  }

  onStopTimer = () => {
    clearInterval(this.timeInterval)
    this.setState({isTimerRunning: false})
  }

  updateTime = () => {
    this.setState(prevState => ({
      timeElapsedInSeconds: prevState.timeElapsedInSeconds + 1,
    }))
  }

  onStartTimer = () => {
    this.timeInterval = setInterval(this.updateTime, 1000)
    this.setState({isTimerRunning: true})
  }

  renderSeconds = () => {
    const {timeElapsedInSeconds} = this.state
    const seconds = Math.floor(timeElapsedInSeconds % 60)

    if (seconds < 10) {
      return `0${seconds}`
    }
    return seconds
  }

  renderMinutes = () => {
    const {timeElapsedInSeconds} = this.state
    const minutes = Math.floor(timeElapsedInSeconds / 60)

    if (minutes < 10) {
      return `0${minutes}`
    }
    return minutes
  }

  render() {
    const {isTimerRunning} = this.state
    const time = `${this.renderMinutes()}:${this.renderSeconds()}`

    return (
      <div className="app-container">
        <div className="stopwatch-container">
          <h1 className="stopwatch">Stopwatch</h1>
          <div className="timer-container">
            <div className="timer">
              <img
                className="timer-image"
                src="https://assets.ccbp.in/frontend/react-js/stopwatch-timer.png"
                alt="stopwatch"
              />
              <p className="heading">Timer</p>
            </div>
            <h1 className="stopwatch-timer">{time}</h1>
            <div className="timer-buttons">
              <button
                type="button"
                className="start-button button"
                onClick={this.onStartTimer}
                disabled={isTimerRunning}
              >
                Start
              </button>
              <button
                type="button"
                className="stop-button button"
                onClick={this.onStopTimer}
              >
                Stop
              </button>
              <button
                type="button"
                className="reset-button button"
                onClick={this.onResetTimer}
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default Stopwatch

//src/components/Stopwatch/index.css

.app-container {
  background-image: url('https://assets.ccbp.in/frontend/react-js/stopwatch-sm-bg.png');
  background-size: cover;
  height: 100vh;
}

@media screen and (min-width: 768px) {
  .app-container {
    background-image: url('https://assets.ccbp.in/frontend/react-js/stopwatch-lg-bg.png');
  }
}

.stopwatch-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 64px;
}

@media screen and (min-width: 992px) {
  .stopwatch-container {
    align-items: flex-start;
    margin-left: 160px;
  }
}

.stopwatch {
  color: #333333;
  font-family: 'Roboto';
  font-size: 36px;
  font-weight: 500;
}

@media screen and (min-width: 992px) {
  .stopwatch {
    font-size: 64px;
  }
}

.timer-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #ffffff;
  width: 310px;
  border-radius: 12px;
  padding: 32px;
  box-shadow: 0px 4px 40px rgba(23, 31, 70, 0.16);
}

.timer {
  display: flex;
  align-items: center;
}

.timer-image {
  margin-right: 8px;
}

.heading {
  color: #333333;
  font-family: 'Roboto';
  font-size: 24px;
  font-weight: 500;
}

.stopwatch-timer {
  color: #333333;
  font-family: 'Roboto';
  font-size: 36px;
  font-weight: 500;
  margin-top: 0px;
}

@media screen and (min-width: 768px) {
  .stopwatch-timer {
    font-size: 64px;
  }
}

.timer-buttons {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.button {
  color: #ffffff;
  font-family: 'Roboto';
  font-size: 14px;
  font-weight: 600;
  border-radius: 4px;
  padding-top: 4px;
  padding-bottom: 4px;
  padding-left: 20px;
  padding-right: 20px;
  cursor: pointer;
  border: none;
  outline: none;
}

@media screen and (min-width: 768px) {
  .button {
    padding-top: 8px;
    padding-bottom: 8px;
  }
}

.start-button {
  background-color: #1db05f;
  margin-right: 24px;
}

.stop-button {
  background-color: #ef0d36;
  margin-right: 24px;
}

.reset-button {
  background-color: #eaa800;
}

//src/App.js

import Stopwatch from './components/Stopwatch'

import './App.css'

const App = () => <Stopwatch />

export default App

//src/index.js

import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root'),
)

Assignment-2:
---------------------------------------------------------

Password Manager:
---------------------------

https://reactjsexample.com/password-manager-app-for-react/
https://github.com/Pavan-Kiran-Chidirala/reactpasswordmanagerappjs

//src/App.js

import {Component} from 'react'

import {v4 as uuidv4} from 'uuid'

import './App.css'

const colorList = ['yellow', 'green', 'orange', 'brown', 'blue']

class App extends Component {
  state = {
    isTrue: false,
    latestList: [],
    website: '',
    username: '',
    password: '',
    isShow: false,
  }

  listenWebsite = e => {
    this.setState({website: e.target.value})
  }

  listenUsername = e => {
    this.setState({username: e.target.value})
  }

  listenPassword = e => {
    this.setState({password: e.target.value})
  }

  addContent = e => {
    e.preventDefault()
    const {username, website, password} = this.state
    const initial = website.slice(0, 1).toUpperCase()
    const classValue = colorList[Math.floor(Math.random() * 5)]
    const newValues = {
      id: uuidv4(),
      initialValue: initial,
      websiteName: website,
      userName: username,
      Password: password,
      classAdd: classValue,
    }
    this.setState(prevState => ({
      latestList: [...prevState.latestList, newValues],
      website: '',
      username: '',
      password: '',
      isTrue: true,
      searchInput: '',
    }))
  }

  showPassword = e => {
    if (e.target.checked) {
      this.setState({isShow: true})
    } else {
      this.setState({isShow: false})
    }
  }

  searchList = e => {
    this.setState({searchInput: e.target.value})
  }

  deleteItem = id => {
    const {latestList} = this.state
    const newList = latestList.filter(eachValue => eachValue.id !== id)
    const caseOf = newList.length !== 0
    this.setState({latestList: newList, isTrue: caseOf})
  }

  render() {
    const {
      website,
      username,
      password,
      latestList,
      isShow,
      searchInput,
    } = this.state
    let {isTrue} = this.state
    const newList = latestList.filter(eachValue =>
      eachValue.websiteName.toLowerCase().includes(searchInput.toLowerCase()),
    )
    if (newList.length === 0) {
      isTrue = false
    } else {
      isTrue = true
    }
    return (
      <div className="main-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/password-manager-logo-img.png"
          className="app-logo"
          alt="app logo"
        />
        <div className="sub-div1">
          <img
            src="https://assets.ccbp.in/frontend/react-js/password-manager-sm-img.png"
            className="sub-div1-image2"
            alt="password manager"
          />
          <form className="add-details" onSubmit={this.addContent}>
            <h1 className="detail-heading">Add New Password</h1>
            <div className="input-holder">
              <img
                src="https://assets.ccbp.in/frontend/react-js/password-manager-website-img.png"
                className="input-image"
                alt="website"
              />
              <input
                type="text"
                className="input-element"
                placeholder="Enter Website"
                onChange={this.listenWebsite}
                value={website}
              />
            </div>

            <div className="input-holder">
              <img
                src="https://assets.ccbp.in/frontend/react-js/password-manager-username-img.png"
                className="input-image"
                alt="username"
              />
              <input
                type="text"
                className="input-element"
                placeholder="Enter Username"
                onChange={this.listenUsername}
                value={username}
              />
            </div>
            <div className="input-holder">
              <img
                src="https://assets.ccbp.in/frontend/react-js/password-manager-password-img.png"
                className="input-image"
                alt="password"
              />
              <input
                type="password"
                className="input-element"
                placeholder="Enter Password"
                onChange={this.listenPassword}
                value={password}
              />
            </div>
            <button type="submit" className="add-btn">
              Add
            </button>
          </form>
          <img
            src="https://assets.ccbp.in/frontend/react-js/password-manager-lg-img.png"
            className="sub-div1-image1"
            alt="password manager"
          />
        </div>
        <div className="sub-div2">
          <div className="first-div">
            <div className="your-password">
              <h1 className="heading-name">Your Passwords</h1>
              <p className="colored-text">{newList.length}</p>
            </div>
            <div className="search-holder">
              <img
                src="https://assets.ccbp.in/frontend/react-js/password-manager-search-img.png"
                className="input-image"
                alt="search"
              />
              <input
                type="search"
                className="input-element"
                placeholder="Search"
                onChange={this.searchList}
                value={searchInput}
              />
            </div>
          </div>
          <hr />
          <div className="show-passwords">
            <input
              type="checkbox"
              className="check-box"
              id="check"
              onChange={this.showPassword}
            />
            <label htmlFor="check" className="label-password">
              Show Passwords
            </label>
          </div>
          {!isTrue && (
            <div className="empty-state">
              <img
                src="https://assets.ccbp.in/frontend/react-js/no-passwords-img.png"
                className="empty-image"
                alt="no passwords"
              />
              <p className="no-passwords">No Passwords</p>
            </div>
          )}
          {isTrue && (
            <ul className="result-container">
              {newList.map(eachValue => (
                <li className="item-list" id={eachValue.id} key={eachValue.id}>
                  <p className={`initial ${eachValue.classAdd}`}>
                    {eachValue.initialValue}
                  </p>
                  <div className="list-content">
                    <p className="website">{eachValue.websiteName}</p>
                    <p className="website">{eachValue.userName}</p>
                    {!isShow && (
                      <img
                        src="https://assets.ccbp.in/frontend/react-js/password-manager-stars-img.png"
                        className="stars-image"
                        alt="stars"
                      />
                    )}
                    {isShow && <p className="website">{eachValue.Password}</p>}
                  </div>
                  <button
                    type="button"
                    className="del-btn"
                    onClick={() => this.deleteItem(eachValue.id)}
                    testid="delete"
                  >
                    <img
                      src="https://assets.ccbp.in/frontend/react-js/password-manager-delete-img.png"
                      className="del-image"
                      alt="delete"
                    />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    )
  }
}

export default App

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.main-container {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  padding: 20px;
  min-height: 100vh;
  max-height: 100%;
  background-color: #9ba9eb;
  padding-left: 100px;
  padding-right: 100px;
  font-family: 'Roboto';
}

.app-logo {
  width: 150px;
  height: 45px;
  margin-bottom: 30px;
}

.sub-div1 {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: flex-start;
  width: 100%;
  height: 50vh;
  background-color: #5763a5;
  padding: 40px;
  border-radius: 5px;
  margin-bottom: 20px;
}

.add-details {
  display: flex;
  flex-direction: column;
  padding: 20px;
  justify-content: flex-start;
  align-items: flex-start;
  width: 350px;
  height: auto;
  background-color: #454f84;
  border-radius: 5px;
  color: #f8fafc;
}

.detail-heading {
  font-size: 16px;
  font-weight: normal;
}

.input-holder {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  background-color: #f8fafc;
  width: 100%;
  height: 35px;
  border-radius: 2px;
  margin-bottom: 20px;
}

.input-image {
  width: 14px;
  height: 14px;
  margin: 10px;
}

.input-element {
  width: 100%;
  height: 100%;
  background-color: transparent;
  border-style: none;
  outline: none;
  border-left-style: solid;
  border-left-color: #94a3b8;
  border-left-width: 1px;
  font-size: 10px;
  padding: 5px;
}

.add-btn {
  background-color: #0b69ff;
  color: white;
  font-size: 10px;
  width: 60px;
  padding: 5px;
  border-style: none;
  outline: none;
  border-radius: 2px;
  align-self: flex-end;
}

.sub-div1-image1 {
  width: 25%;
  height: 100%;
}
.sub-div1-image2 {
  display: none;
}

.sub-div2 {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  width: 100%;
  min-height: 50vh;
  max-height: 100%;
  background-color: #5763a5;
  padding: 20px;
  border-radius: 5px;
}

.first-div {
  display: flex;
  flex-direction: row;
  width: 100%;
  justify-content: space-between;
  align-items: center;
}

.your-password {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
}

.heading-name {
  color: #f8fafc;
  font-size: 16px;
  margin-right: 5px;
}
.colored-text {
  border-style: solid;
  border-color: #9ba9eb;
  border-width: 1px;
  border-radius: 8px;
  width: 20px;
  text-align: center;
  color: #f8fafc;
  font-size: 10px;
}

.search-holder {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  background-color: #f8fafc;
  width: 180px;
  height: 22px;
  border-radius: 2px;
  margin-bottom: 20px;
}

hr {
  background-color: #9ba9eb;
  border-style: none;
  height: 1px;
  width: 100%;
}

.show-passwords {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
  align-self: flex-end;
}

.check-box {
  width: 15px;
  height: 15px;
  border-style: none;
  outline: none;
  margin-right: 10px;
}

.label-password {
  color: #f8fafc;
  font-size: 12px;
}

.empty-state {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
}

.empty-image {
  width: 220px;
  height: 170px;
}

.no-passwords {
  color: #f8fafc;
  font-size: 14px;
}

.result-container {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: flex-start;
  width: 100%;
  flex-wrap: wrap;
}

.item-list {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  width: 200px;
  height: 80px;
  background-color: transparent;
  border-style: solid;
  border-color: #9ba9eb;
  border-width: 1px;
  border-radius: 2px;
  padding: 10px;
  margin-right: 18px;
  margin-bottom: 18px;
}

.initial {
  font-size: 16px;
  color: white;
  background-color: green;
  width: 35px;
  border-radius: 25px;
  text-align: center;
  padding: 8px;
  margin-right: 10px;
}

.list-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  color: #f8fafc;
  height: 100%;
}

.website {
  font-size: 12px;
  margin: 2px;
}

.stars-image {
  width: 80px;
  height: 10px;
  margin-top: 8px;
  margin-left: 2px;
}

.del-btn {
  width: 20px;
  height: 20px;
  background-color: transparent;
  border-style: none;
  outline: none;
  margin-left: auto;
}

.del-image {
  width: 20px;
  height: 20px;
}

.yellow {
  background-color: #f59e0b;
}

.green {
  background-color: #10b981;
}

.orange {
  background-color: #f97316;
}

.brown {
  background-color: #b91c1c;
}

.blue {
  background-color: #0ea5e9;
}

@media screen and (max-width: 768px) {
  .sub-div1 {
    flex-wrap: wrap;
    justify-content: center;
    height: auto;
  }
  .sub-div1-image1 {
    display: none;
  }
  .sub-div1-image2 {
    display: block;
    width: 300px;
    height: 200px;
    margin-bottom: 18px;
  }
  .sub-div2 {
    min-height: 50vh;
  }
  .result-container {
    justify-content: center;
  }
}

Assignment-3:
---------------------------------------------------------------------------------------------

Match Game:
-------------------

https://reactjsexample.com/a-match-game-built-with-react-js/
https://github.com/Pavan-Kiran-Chidirala/reactmatchgameappjs

//src/App.js

import {Component} from 'react'

import './App.css'

// These are the lists used in the application. You can move them to any component needed.
const tabsList = [
  {tabId: 'FRUIT', displayText: 'Fruits'},
  {tabId: 'ANIMAL', displayText: 'Animals'},
  {tabId: 'PLACE', displayText: 'Places'},
]
const imagesList = [
  {
    id: 'b11ec8ce-35c9-4d67-a7f7-07516d0d8186',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/orange-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/orange-thumbnail-img.png',
    category: 'FRUIT',
  },
  {
    id: '04ac6b9f-b7e7-45f7-a8fc-fd48f3f72526',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/panda-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/panda-thumbnail-img.png',
    category: 'ANIMAL',
  },
  {
    id: 'a132f546-5b2b-4c0d-b9e4-e524bdf904cc',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/zebra-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/zebra-thumbnail-img.png',
    category: 'ANIMAL',
  },
  {
    id: 'd89386da-94db-4275-9cb5-249c6e071a19',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/paris-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/paris-thumbnail-img.png',
    category: 'PLACE',
  },
  {
    id: 'd810bbb0-1683-407a-8db6-898fe7b75782',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/giraffe-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/giraffe-thumbnail-img.png',
    category: 'ANIMAL',
  },
  {
    id: '176aab62-e86a-4ccd-8b89-5b83c3f02506',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/taj-mahal-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/taj-mahal-thumbnail-img.png',
    category: 'PLACE',
  },
  {
    id: '0e8daf1b-45b0-4eb0-9dde-383fede78a9b',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/monkey-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/monkey-thumbnail-img.png',
    category: 'ANIMAL',
  },
  {
    id: '1a38bf4a-659d-4470-956c-56c1bedd26ac',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/cheetah-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/cheetah-thumbnail-img.png',
    category: 'ANIMAL',
  },
  {
    id: '8f2ebd70-4fdd-47a0-b4f9-a6c654b519ab',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/ooti-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/ooti-thumbnail-img.png',
    category: 'PLACE',
  },
  {
    id: '7a72c38e-a83d-48eb-b9ce-ae3c0361cc49',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/pineapple-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/pineapple-thumbnail-img.png',
    category: 'FRUIT',
  },
  {
    id: '97a33ed5-98ed-4c95-a8f0-1595880b3b69',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/strawberry-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/strawberry-thumbnail-img.png',
    category: 'FRUIT',
  },
  {
    id: '07e20159-a950-4c22-9ca8-5ed71563ae24',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/maldives-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/maldives-thumbnail-img.png',
    category: 'PLACE',
  },
  {
    id: '43883239-8a28-47dc-9e93-43ef31654c17',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/emerald-lake-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/emerald-thumbnail-lake-img.png',
    category: 'PLACE',
  },
  {
    id: '49865ac4-b5e8-4d04-893b-d69ad6004da8',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/watermelon-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/watermelon-thumbnail-img.png',
    category: 'FRUIT',
  },
  {
    id: '649ab251-7fd6-4d65-aa0f-39020ce25932',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/elephant-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/elephant-thumbnail-img.png',
    category: 'ANIMAL',
  },
  {
    id: '1d0d1c41-e05e-4820-8614-34ee5ada20e0',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/jammu-hills-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/jammu-thumbnail-hills-img.png',
    category: 'PLACE',
  },
  {
    id: '88b4ab36-a0c1-4c56-9ce5-3b80dd8c7669',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/fierce-coyote-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/fierce-thumbnail-coyote-img.png',
    category: 'ANIMAL',
  },
  {
    id: '8a841bf8-3222-44da-b0fb-4c60190402d7',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/lidder-valley-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/lidder-thumbnail-valley-img.png',
    category: 'PLACE',
  },
  {
    id: 'd406e63c-eaaf-49ea-88a6-ed6a1572eb97',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/kivi-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/kivi-thumbnail-img.png',
    category: 'FRUIT',
  },
  {
    id: 'e997ebf9-9a47-4b7e-9035-01ae372d73dc',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/dragon-fruit-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/dragon-thumbnail-fruit-img.png',
    category: 'FRUIT',
  },
  {
    id: 'c7fbe10e-3282-4fca-815b-91b75d5228cb',
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/match-game/goa-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/goa-thumbnail-img.png',
    category: 'PLACE',
  },
  {
    id: '4210274c-7304-44d6-8690-c5251252cd10',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/papaya-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/papaya-thumbnail-img.png',
    category: 'FRUIT',
  },
  {
    id: '057b6193-a80d-4036-9e6e-fe847c99fbb6',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/mixed-fruits-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/mixed-thumbnail-fruits-img.png',
    category: 'FRUIT',
  },
  {
    id: '4e56c59b-835b-4802-87fe-77aaaa5b9526',
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/match-game/fox-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/fox-thumbnail-img.png',
    category: 'ANIMAL',
  },
  {
    id: 'ad75a7b1-0875-4700-977b-2c45924509aa',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/lotus-temple-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/lotus-thumbnail-temple-img.png',
    category: 'PLACE',
  },
  {
    id: '525aba17-ed5c-4f09-ad1c-b6bff222c97a',
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/match-game/dog-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/dog-thumbnail-img.png',
    category: 'ANIMAL',
  },
  {
    id: 'c6c66b00-c130-47d2-9d3a-1c3378d08aba',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/apple-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/apple-thumbnail-img.png',
    category: 'FRUIT',
  },
  {
    id: '6078b408-4f10-46d3-8815-db14403dbd73',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/bhadrinath-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/bhadrinath-thumbnail-img.png',
    category: 'PLACE',
  },
  {
    id: 'a2baca84-3beb-49d1-bced-f9a88c161bec',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/camel-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/camel-thumbnail-img.png',
    category: 'ANIMAL',
  },
  {
    id: '1edac278-8390-4da9-b914-5f41fb49283c',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/cherry-img.png',
    thumbnailUrl:
      'https://assets.ccbp.in/frontend/react-js/match-game/cherry-thumbnail-img.png',
    category: 'FRUIT',
  },
]

// Replace your code here
class App extends Component {
  state = {
    isTrue: false,
    category: 'FRUIT',
    score: 0,
    time: 60,
    imgUrl: imagesList[0].imageUrl,
  }

  componentDidMount() {
    this.timerId = setInterval(this.statusChange, 1000)
  }

  statusChange = () => {
    const {time} = this.state
    if (time !== 0) {
      this.setState(prevState => ({time: prevState.time - 1}))
    } else {
      clearInterval(this.timerId)
      this.setState({isTrue: true})
    }
  }

  clickTab = tabId => {
    this.setState({category: tabId})
  }

  imageClick = thumbnailUrl => {
    const {imgUrl} = this.state
    const imageValue = imagesList.filter(
      eachValue => eachValue.thumbnailUrl === thumbnailUrl,
    )
    const {imageUrl} = imageValue[0]
    if (imageUrl === imgUrl) {
      const newImgUrl =
        imagesList[Math.floor(Math.random() * imagesList.length)].imageUrl
      console.log(newImgUrl)
      this.setState(prevState => ({
        score: prevState.score + 1,
        imgUrl: newImgUrl,
      }))
    } else {
      clearInterval(this.timerId)
      this.setState({isTrue: true})
    }
  }

  playAgain = () => {
    this.setState({
      score: 0,
      imgUrl: imagesList[0].imageUrl,
      category: 'FRUIT',
      isTrue: false,
      time: 60,
    })
    this.timerId = setInterval(this.statusChange, 1000)
  }

  render() {
    const {isTrue, category, score, time, imgUrl} = this.state
    const thumbnailList = imagesList.filter(
      eachValue => eachValue.category === category,
    )
    return (
      <div className="main-container">
        <nav className="nav-bar">
          <img
            src="https://assets.ccbp.in/frontend/react-js/match-game-website-logo.png"
            className="top-image"
            alt="website logo"
          />
          <ul className="score-div">
            <li className="score-name">
              <p>
                Score: <span className="score">{score}</span>
              </p>
            </li>
            <li className="score-div">
              <img
                src="https://assets.ccbp.in/frontend/react-js/match-game-timer-img.png"
                alt="timer"
                className="timer-img"
              />
              <p className="time">{time} sec</p>
            </li>
          </ul>
        </nav>
        <div className="content-div">
          {!isTrue && (
            <div className="first-div">
              <img src={imgUrl} className="big-image" alt="match" />
              <ul className="tab-elements">
                {tabsList.map(eachValue => (
                  <li key={eachValue.tabId}>
                    <button
                      type="button"
                      className={`tab-button ${
                        category === eachValue.tabId ? 'highlight-text' : ''
                      }`}
                      onClick={() => this.clickTab(eachValue.tabId)}
                    >
                      {eachValue.displayText}
                    </button>
                  </li>
                ))}
              </ul>
              <ul className="thumbnail-images">
                {thumbnailList.map(eachObject => (
                  <li key={eachObject.id}>
                    <button
                      type="button"
                      className="image-button"
                      onClick={() => this.imageClick(eachObject.thumbnailUrl)}
                    >
                      <img
                        src={eachObject.thumbnailUrl}
                        className="thumbnail-image"
                        alt="thumbnail"
                      />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {isTrue && (
            <div className="second-div">
              <img
                src="https://assets.ccbp.in/frontend/react-js/match-game-trophy.png"
                className="trophy-image"
                alt="trophy"
              />
              <p className="main-heading">YOUR SCORE</p>
              <p className="your-score">{score}</p>
              <button
                type="button"
                className="play-button"
                onClick={this.playAgain}
              >
                <img
                  src="https://assets.ccbp.in/frontend/react-js/match-game-play-again-img.png"
                  className="restart"
                  alt="reset"
                />
                PLAY AGAIN
              </button>
            </div>
          )}
        </div>
      </div>
    )
  }
}

export default App

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  overflow-x: hidden;
}

.main-container {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  font-family: 'Roboto';
  min-height: 100vh;
  max-height: 100%;
  width: 100vw;
}

.nav-bar {
  width: 100vw;
  height: 70px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  background-color: #2c0e3a;
  padding: 20px;
}

.top-image {
  width: 130px;
  height: 30px;
}

.score-div {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  list-style-type: none;
}

.score-name {
  color: #ffffff;
  font-size: 12px;
  margin-right: 5px;
}

.score {
  color: #fec653;
  font-size: 18px;
  margin-right: 20px;
}

.timer-img {
  width: 15px;
  height: 15px;
  margin-right: 5px;
}

.time {
  color: #fec653;
  font-size: 18px;
  margin-right: 20px;
}

.content-div {
  width: 100vw;
  height: 100%;
  background-image: url('https://assets.ccbp.in/frontend/react-js/match-game-bg.png');
  background-size: cover;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  padding: 40px;
}

.first-div {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
}

.big-image {
  width: 500px;
  height: 300px;
}

.tab-elements {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  list-style-type: none;
}

.tab-button {
  background-color: transparent;
  margin-top: 10px;
  margin-bottom: 10px;
  border-style: none;
  color: #ffffff;
  font-size: 20px;
  outline: none;
  min-width: 60px;
  height: 40px;
  margin-right: 20px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.highlight-text {
  color: #fec653;
  border-bottom: solid;
  border-bottom-color: #fec653;
}

.thumbnail-images {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: wrap;
  width: 500px;
  list-style-type: none;
  padding: 0px;
}

.image-button {
  width: 86px;
  height: 86px;
  background-color: transparent;
  border-style: none;
  outline: none;
  margin-right: 14px;
  margin-bottom: 14px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.thumbnail-image {
  width: 86px;
  height: 86px;
}

.second-div {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  width: 480px;
  height: 600px;
  background-image: url('https://assets.ccbp.in/frontend/react-js/match-game-score-card-lg-bg.png');
  background-size: cover;
}

.trophy-image {
  width: 280px;
  height: 220px;
  margin-top: 180px;
}

.main-heading {
  color: #ffffff;
  font-size: 18px;
  margin: 0px;
}

.your-score {
  color: white;
  font-size: 34px;
  margin: 10px;
  margin-bottom: 25px;
}

.play-button {
  width: 160px;
  padding: 5px;
  border-style: none;
  outline: none;
  background-color: #cf60c8;
  border-radius: 10px;
  font-size: 16px;
  color: white;
  padding: 10px;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
}

.restart {
  width: 15px;
  height: 15px;
  margin-right: 10px;
}

@media screen and (max-width: 576px) {
  body {
    overflow-x: hidden;
    overflow-y: hidden;
  }
  .nav-bar {
    height: 45px;
  }
  .top-image {
    width: 100;
    height: 25px;
  }
  .score-name {
    font-size: 12px;
  }
  .score {
    font-size: 14px;
  }
  .timer-img {
    width: 12px;
    height: 12px;
  }
  .time {
    font-size: 14px;
    margin-right: 10px;
  }
  .big-image {
    width: 300px;
    height: 200px;
  }
  .content-div {
    padding: 20px;
    height: 95vh;
    min-height: 100%;
    overflow-y: hidden;
  }
  .tab-button {
    min-width: 40px;
    height: 30;
    font-size: 14px;
  }
  .thumbnail-images {
    width: 300px;
    height: auto;
    justify-content: center;
  }
  .image-button {
    width: 60px;
    height: 60px;
  }
  .thumbnail-image {
    width: 60px;
    height: 60px;
  }
  .second-div {
    background-image: url('https://assets.ccbp.in/frontend/react-js/match-game-score-card-sm-bg.png');
    width: 95%;
    height: 70%;
    padding: 40px;
    margin-top: 40px;
  }
  .trophy-image {
    margin-top: 82px;
    width: 220px;
    height: 180px;
  }
  .main-heading {
    font-size: 14px;
  }
  .your-score {
    font-size: 32px;
  }
  .play-button {
    width: 120px;
    font-size: 12px;
  }
}

Browsing history:
-----------------------------------------------------

https://github.com/pradeep-coding/browser_history

coding pratice-21:
-------------------------------------------------------------------------------------------------------------------------------

Faqs App:
--------------------------------------

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

1.1.When the plus icon is clicked in a FAQ
	The answer to the FAQ should be visible to the user
	The plus icon should change to a minus icon
	
1.2.When the minus icon is clicked in a FAQ
	The answer to the FAQ should be hidden to the user
	The minus icon should change to a plus icon
	
1.3.The Faqs component receives the faqsList as a prop. It consists of a list of faq objects with the following properties in each faq object

Key				Data Type
id				Number
questionText	String
answerText		String

2.Implementation Files

Use these files to complete the implementation:

src/components/Faqs/index.js
src/components/Faqs/index.css
src/components/FaqItem/index.js
src/components/FaqItem/index.css

3.Quick Tips
Click to view

3.1.You can use the box-shadow CSS property to apply the box-shadow effect to containers

box-shadow: 0px 4px 16px 0px #bfbfbf;

3.2.You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

cursor: pointer;

3.3.You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

//src/components/Faqs/index.js

import FaqItem from '../FaqItem'

import './index.css'

const Faqs = props => {
  const {faqsList} = props

  return (
    <div className="app-container">
      <div className="faqs-container">
        <h1 className="heading">FAQs</h1>
        <ul className="faqs-list">
          {faqsList.map(eachFaq => (
            <FaqItem key={eachFaq.id} faqDetails={eachFaq} />
          ))}
        </ul>
      </div>
    </div>
  )
}

export default Faqs

//src/components/Faqs/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f1f5f8;
  min-height: 100vh;
}

.faqs-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 87%;
  background-color: #ffffff;
  border-radius: 16px;
  padding-top: 32px;
  padding-right: 12px;
  padding-bottom: 32px;
  padding-left: 12px;
  max-width: 550px;
}

@media screen and (min-width: 768px) {
  .faqs-container {
    width: 90%;
    max-width: 1140px;
    padding: 32px;
  }
}

.faqs-list {
  width: 100%;
  list-style-type: none;
  padding: 0px;
}

@media screen and (min-width: 768px) {
  .faqs-list {
    width: 90%;
  }
}

@media screen and (min-width: 1200px) {
  .faqs-list {
    width: 80%;
  }
}

.heading {
  color: #cb8805;
  font-family: 'Roboto';
  font-size: 32px;
  font-weight: 700;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 64px;
  }
}

//src/components/FaqItem/index.js

import {Component} from 'react'

import './index.css'

const PLUS_IMAGE =
  'https://assets.ccbp.in/frontend/react-js/faqs-plus-icon-img.png'
const MINUS_IMAGE =
  'https://assets.ccbp.in/frontend/react-js/faqs-minus-icon-img.png'

class FaqItem extends Component {
  state = {
    isActive: false,
  }

  renderAnswer = () => {
    const {faqDetails} = this.props
    const {answerText} = faqDetails
    const {isActive} = this.state

    if (isActive) {
      return (
        <div>
          <hr className="horizontal-line" />
          <p className="answer">{answerText}</p>
        </div>
      )
    }
    return null
  }

  onToggleIsActive = () => {
    this.setState(prevState => ({
      isActive: !prevState.isActive,
    }))
  }

  renderActiveImage = () => {
    const {isActive} = this.state
    const image = isActive ? MINUS_IMAGE : PLUS_IMAGE
    const altText = isActive ? 'minus' : 'plus'

    return (
      <button className="button" type="button" onClick={this.onToggleIsActive}>
        <img className="image" src={image} alt={altText} />
      </button>
    )
  }

  render() {
    const {faqDetails} = this.props
    const {questionText} = faqDetails

    return (
      <li className="faq-item">
        <div className="question-container">
          <h1 className="question">{questionText}</h1>
          {this.renderActiveImage()}
        </div>
        {this.renderAnswer()}
      </li>
    )
  }
}

export default FaqItem

//src/components/FaqItem/index.css

.faq-item {
  width: 100%;
  border: 1px solid #d7dae6;
  border-radius: 16px;
  margin-bottom: 24px;
  padding: 16px;
}

.question-container {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
}

.question {
  color: #52606d;
  font-family: 'Roboto';
  font-size: 12px;
  font-weight: 500;
}

@media screen and (min-width: 768px) {
  .question {
    font-size: 24px;
  }
}

.answer {
  color: #9aa5b1;
  font-family: 'Roboto';
  font-size: 16px;
}

@media (max-width: 576px) {
  .answer {
    font-size: 12px;
  }
}

.button {
  background-color: transparent;
  border: none;
  outline: none;
  cursor: pointer;
}

@media (max-width: 576px) {
  .image {
    width: 15px;
    height: 15px;
  }
}

.horizontal-line {
  border: 1px solid #e4e7eb;
}

//src/App.js

import Faqs from './components/Faqs'

import './App.css'

const faqsList = [
  {
    id: 0,
    questionText: 'What is IRC?',
    answerText:
      'IRC is an Industry Ready Certification that represents your readiness for a job with the necessary skills.',
  },
  {
    id: 1,
    questionText: 'What is the medium of instruction?',
    answerText:
      'The courses would be delivered in English and Telugu. The program will be available in more vernacular languages soon.',
  },
  {
    id: 2,
    questionText:
      'Is there an EMI option to pay the fee for CCBP Tech 4.0 Intensive?',
    answerText:
      'Yes, EMI support is available for credit cards. Please select EMI option while making payment for more information.',
  },
  {
    id: 3,
    questionText: 'How will my doubts be cleared? What is the mechanism?',
    answerText:
      'You can ask your doubts in the discussions section and course mentor will answer them. You can also see the doubts asked by other students.',
  },
]

const App = () => <Faqs faqsList={faqsList} />

export default App

React Router > Routing using React Router | Cheat Sheet:
----------------------------------------------------------------------------------------------

- Web Apps
  - Single Page Apps
  - Multiple Page Apps
- Routing
  - react-router-dom
- react-router-dom
  - BrowserRouter
  - Link
  - Route
  - Switch
  
1. Web Apps
Web Apps are of two types, based on how we get content:

Multi-page application (MPA)
Single-page application (SPA)

1.1 Multi-page application (MPA)
Every URL is associated with corresponding resources (HTML, CSS, JS).
The browser downloads these resources when you access them or navigate between URLs.

1.2 Single-page application (SPA)
All URLs are associated with a single HTML page.
On navigating we only get the additional content (Component - HTML, CSS, JS).

1.2.1 Advantages of using Single-page application (SPA)
Faster Page loading - since they load only necessary Component (HTML, CSS, JS) resources on subsequent requests.
React is mainly used to build Single-page applications.

2. React Router
In React, we build Single-page applications using React Router.

To implement routing, React Router provides various components:

BrowserRouter
Link
Route
Switch

2.1 BrowserRouter
To add routing wrap all the Components with BrowserRouter.

Syntax:

<BrowserRouter>
  <Component 1>
  <Component 2>
  ... 
</BrowserRouter>

2.2 Link
Link Component creates hyperlinks that allows to navigate around in application.

Syntax:

<Link to="Path"> Display Text</Link>

The to prop specifies absolute path.

2.3 Route
The Route component renders specific UI component when path matches current URL.

<Route path="Path" component={Component} />

2.3.1 Exact
Renders the route if path matches exactly the current url

<Route exact path="Path1" component={Component1} />

Note
If user enters undefined Path, the Component won’t be rendered

2.3 Switch
The Switch component will only render the first route that matches the path. If no path matches, it renders the Not Found component.

<Switch>
  <Route path="Path1" component={Component1} />
  <Route path="Path2" component={Component2} />
 <Route component={NotFound} />
</Switch>

3. Routing Example

//src/components/About/index.js

import './index.css'

const About = () => (
  <div className="about-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/about-blog-img.png"
      alt="about"
      className="about-img"
    />
    <h1 className="about-heading">About</h1>
    <p className="about-paragraph">
      I love to create! I am a front-end web developer
    </p>
  </div>
)

export default About

//src/components/About/index.css

.about-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}
.about-img {
  width: 150px;
}
.about-heading {
  font-family: 'Roboto';
  font-weight: 500;
  color: #3d3d3d;
}
.about-paragraph {
  font-family: 'Roboto';
  font-size: 20px;
  text-align: center;
  color: #555555;
}

//src/components/Contact/index.js

import './index.css'

const Contact = () => (
  <div className="contact-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/contact-blog-img.png"
      alt="contact"
      className="contact-img"
    />
    <h1 className="contact-heading">Contact</h1>
  </div>
)

export default Contact

//src/components/Contact/index.css

.contact-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}
.contact-img {
  width: 150px;
}
.contact-heading {
  font-family: 'Roboto';
  font-weight: 500;
  color: #3d3d3d;
}

//src/components/Header/index.js

import { Link } from "react-router-dom";
...
const Header = () => (
  ...
     <ul className="nav-menu">
       <li>
         <Link className="nav-link" to="/">Home</Link>
       </li>
       <li>
         <Link className="nav-link" to="/about">About</Link>
       </li>
       <li>
         <Link className="nav-link" to="/contact">Contact</Link>
       </li>
     </ul>
  ...
)

------------

import './index.css'

const Header = () => (
  <nav className="nav-header">
    <div className="blog-container">
      <h1 className="blog-title">My Blog</h1>
      <ul className="nav-menu">
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
      </ul>
    </div>
  </nav>
)

export default Header

//src/components/Header/index.css

.nav-header {
  height: 25vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background: url('https://assets.ccbp.in/frontend/react-js/books-blog-bg.png');
}
.nav-menu {
  list-style-type: none;
  display: flex;
  margin-left: -40px;
}

.nav-link {
  text-decoration: none;
  margin: 10px;
  color: white;
  font-family: 'Roboto';
}

.blog-container {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}
.blog-title {
  font-family: 'Roboto';
  color: white;
  font-size: 16px;
}
.sub-title {
  color: white;
  font-family: 'Roboto';
  margin-top: 0px;
}

li {
  list-style-type: none;
  text-decoration: none;
  margin: 10px;
  color: white;
  font-family: 'Roboto';
  cursor: pointer;
}

@media screen and (min-width: 575px) {
  .blog-title {
    font-family: 'Roboto';
    color: white;
    font-size: 34px;
  }
}

//src/components/Home/index.js

import './index.css'

const Home = () => (
  <div className="home-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/home-blog-img.png"
      alt="home"
      className="home-img"
    />
    <h1 className="home-heading">Home</h1>
  </div>
)

export default Home

//src/components/Home/index.css

.home-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}
.home-img {
  width: 150px;
}
.home-heading {
  font-family: 'Roboto';
  font-weight: 500;
  line-height: 56px;
  color: #3d3d3d;
}

//src/components/NotFound/index.js

import './index.css'

const NotFound = () => (
  <div className="not-found-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/not-found-blog-img.png"
      alt="not-found"
      className="not-found-img"
    />
  </div>
)

export default NotFound

//src/components/NotFound/index.css

.not-found-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}
.not-found-img {
  width: 400px;
}

//src/App.js

import { BrowserRouter, Route, Switch } from "react-router-dom"
import NotFound from "./components/NotFound";
...
const App = () => (
  <BrowserRouter>
    <Header />
      <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/about" component={About} />
        <Route exact path="/contact" component={Contact} />
        <Route component={NotFound} />
      </Switch>
 </BrowserRouter>
)

export default App

--------

import Header from './components/Header'
import Home from './components/Home'
import About from './components/About'
import Contact from './components/Contact'

const App = () => (
  <>
    <Header />
    <Home />
    <About />
    <Contact />
  </>
)

export default App

coding pratice-22:
----------------------------------------------------------------

Routing pratice:
-----------------------------

1.Completion Instructions:

Functionality to be added

The app must have the following functionalities

When the About link in the header is clicked, then the page should navigate to the AboutRoute
When the Contact link in the header is clicked, then the page should navigate to the ContactRoute
When the Home link in the header is clicked, then the page should navigate back to the HomeRoute
When an undefined path is provided in the URL, then the page should navigate to the NotFoundRoute

2.Implementation Files

Use these files to complete the implementation:

src/components/App.js
src/components/App.css
src/components/Header/index.js
src/components/Header/index.css
src/components/Home/index.js
src/components/Home/index.css
src/components/About/index.js
src/components/About/index.css
src/components/Contact/index.js
src/components/Contact/index.css
src/components/NotFound/index.js
src/components/NotFound/index.css

3.Important Note
Click to view

The following instructions are required for the tests to pass

HomeRoute should consist of "/" in the URL path
AboutRoute should consist of "/about" in the URL path
ContactRoute should consist of "/contact" in the URL path
No need to use the BrowserRouter in App.js as we have already included in index.js file

//src/components/About/index.js

import './index.css'

const About = () => (
  <div className="about-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/about-blog-img.png"
      alt="about"
      className="about-img"
    />
    <h1 className="about-heading">About</h1>
    <p className="about-paragraph">
      I love to create! I am a frontend web developer
    </p>
  </div>
)

export default About

//src/components/About/index.css

.about-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}

.about-img {
  width: 150px;
}

.about-heading {
  font-family: 'Roboto';
  font-weight: 500;
  color: #6d396b;
  font-size: 24px;
}

@media (min-width: 576px) {
  .about-heading {
    font-size: 48px;
  }
}

.about-paragraph {
  font-family: 'Roboto';
  font-size: 20px;
  text-align: center;
  color: #555555;
}

//src/components/Contact/index.js

import './index.css'

const Contact = () => (
  <div className="contact-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/contact-blog-img.png"
      alt="contact"
      className="contact-img"
    />
    <h1 className="contact-heading">Contact</h1>
  </div>
)

export default Contact

//src/components/Contact/index.css

.contact-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}

.contact-img {
  width: 150px;
}

.contact-heading {
  font-family: 'Roboto';
  font-weight: 500;
  color: #6d396b;
}

@media (min-width: 576px) {
  .contact-heading {
    font-size: 48px;
  }
}

//src/components/Header/index.js

import {Link} from 'react-router-dom'

import './index.css'

const Header = () => (
  <nav className="header-container">
    <div className="logo-and-title-container">
      <img
        alt="wave"
        className="logo"
        src="https://assets.ccbp.in/frontend/react-js/wave-logo-img.png"
      />
      <h1 className="title">Wave</h1>
    </div>

    <ul className="nav-items-list">
      <li className="link-item">
        <Link className="route-link" to="/">
          Home
        </Link>
      </li>
      <li className="link-item">
        <Link className="route-link" to="/about">
          About
        </Link>
      </li>
      <li className="link-item">
        <Link className="route-link" to="/contact">
          Contact
        </Link>
      </li>
    </ul>
  </nav>
)

export default Header

//src/components/Header/index.css

.header-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 32px;
}

@media (max-width: 575px) {
  .header-container {
    padding: 15px;
  }
}

.logo-and-title-container {
  display: flex;
  align-items: center;
}

.logo {
  width: 24px;
  height: 24px;
  margin-right: 8px;
}

.title {
  color: #12022f;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: bold;
}

.nav-items-list {
  display: flex;
  padding-left: 0px;
}

.link-item {
  list-style-type: none;
}

.route-link {
  color: #12022f;
  font-family: 'Roboto';
  font-size: 16px;
  font-weight: bold;
  text-decoration: none;
  margin-left: 16px;
}

//src/components/Home/index.js

import './index.css'

const Home = () => (
  <div className="home-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/home-blog-img.png"
      alt="home"
      className="home-img"
    />
    <h1 className="home-heading">Home</h1>
  </div>
)

export default Home

//src/components/Home/index.css

.home-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}

.home-img {
  width: 150px;
}

.home-heading {
  font-family: 'Roboto';
  font-weight: 500;
  line-height: 56px;
  color: #6d396b;
}

@media (min-width: 576px) {
  .home-heading {
    font-size: 48px;
  }
}

//src/components/NotFound/index.js

import './index.css'

const NotFound = () => (
  <div className="not-found-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/not-found-blog-img.png"
      alt="not found"
      className="not-found-img"
    />
    <h1 className="not-found-heading">Not Found</h1>
  </div>
)

export default NotFound

//src/components/NotFound/index.css

.not-found-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}
.not-found-img {
  width: 250px;
}
.not-found-heading {
  font-family: 'Roboto';
  font-weight: 500;
  line-height: 56px;
  color: #6d396b;
}

@media (min-width: 576px) {
  .not-found-heading {
    font-size: 48px;
  }
}

.not-found-heading {
  font-family: 'Roboto';
  font-weight: 500;
  line-height: 56px;
  color: #6d396b;
}

@media (min-width: 576px) {
  .not-found-heading {
    font-size: 48px;
  }
}

//src/App.js

import {Route, Switch} from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Home from './components/Home'
import Contact from './components/Contact'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <div className="app-container">
    <div className="responsive-container">
      <Header />
      <div className="app-body">
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/about" component={About} />
          <Route exact path="/contact" component={Contact} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  </div>
)

export default App

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.responsive-container {
  display: flex;
  flex-direction: column;
  width: 80%;
  height: 80vh;
  border: 4px solid #551e53;
  border-radius: 12px;
}

@media (max-width: 576px) {
  .responsive-container {
    width: 85%;
  }
}

.app-body {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-grow: 1;
}

Blog List:
----------------------------------

In this project, let's build a Blog List by applying the concepts we have learned till now.

https://github.com/ManirathnamKuruma/ReactJS-BlogList

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

In the Home Route, user info and blog list should be displayed
The Home component is provided with blogsList. It consists of a list of blog details objects with the following properties in each object

Key				Data Type
id				Number
title			String
description		String
publishedDate	String

2.Implementation Files

Use these files to complete the implementation:

src/components/Home/index.js
src/components/BlogList/index.js
src/components/BlogList/index.css
src/components/BlogItem/index.js
src/components/BlogItem/index.css
src/components/UserInfo/index.js
src/components/UserInfo/index.css

3.Important Note
Click to view

The following instructions are required for the tests to pass

Home route should consist of / in the URL path
About route should consist of /about in the URL path
Contact route should consist of /contact in the URL path
No need to use the BrowserRouter in App.js as we have already included in index.js file

//src/components/Home/index.js

import BlogList from '../BlogList'
import UserInfo from '../UserInfo'

import './index.css'

const blogsList = [
  {
    id: 1,
    title: 'My first post',
    description: 'A high quality solution beautifully designed for startups',
    publishedDate: 'Aug 2nd',
  },
  {
    id: 2,
    title: 'My second post',
    description:
      'A high quality solution beautifully designed for startups and Bussiness schools',
    publishedDate: 'Mar 1st',
  },
  {
    id: 3,
    title: 'My third post',
    description: 'A high quality solution beautifully designed for startups',
    publishedDate: 'Jan 2nd',
  },
  {
    id: 4,
    title: 'My fourth post',
    description:
      'A high quality solution beautifully designed for startups and Bussiness schools. ',
    publishedDate: 'Dec 24th',
  },
  {
    id: 5,
    title: 'My fifth post',
    description: 'A high quality solution beautifully designed for startups',
    publishedDate: 'Nov 10th',
  },
]
const Home = () => (
  <div className="home-container">
    <UserInfo />
    <BlogList blogsList={blogsList} />
  </div>
)

export default Home

//src/components/BlogList/index.js

import BlogItem from '../BlogItem'

import './index.css'

const BlogList = props => {
  const {blogsList} = props

  return (
    <ul className="blog-list">
      {blogsList.map(eachBlog => (
        <BlogItem key={eachBlog.id} blogDetails={eachBlog} />
      ))}
    </ul>
  )
}

export default BlogList

//src/components/BlogList/index.css

.blog-list {
  width: 70%;
  margin: auto;
  padding-left: 0px;
}

@media (max-width: 1024px) {
  .blog-list {
    width: 95%;
  }
}

//src/components/BlogItem/index.js

import './index.css'

const BlogItem = props => {
  const {blogDetails} = props
  const {title, description, publishedDate} = blogDetails

  return (
    <li className="blog-item">
      <div className="blog-details-container">
        <h1 className="blog-title">{title}</h1>
        <p className="blog-published-date">{publishedDate}</p>
      </div>
      <p className="blog-description">{description}</p>
    </li>
  )
}

export default BlogItem

//src/components/BlogItem/index.css

.blog-item {
  width: 100%;
  border-bottom: 1px solid #e7e5ea;
  list-style-type: none;
}

.blog-details-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.blog-title {
  font-family: Roboto;
  font-style: normal;
  font-weight: bold;
  font-size: 18px;
  color: #12022f;
}

.blog-published-date {
  font-family: Roboto;
  font-style: normal;
  font-weight: normal;
  font-size: 16px;
  line-height: 26px;
  color: #9aa5b1;
}

.blog-description {
  font-family: Roboto;
  font-style: normal;
  font-weight: normal;
  font-size: 16px;
  line-height: 26px;
  color: #9aa5b1;
}

//src/components/UserInfo/index.js

import './index.css'

const UserInfo = () => (
  <div className="user-info-container">
    <img
      className="profile-img"
      src="https://assets.ccbp.in/frontend/react-js/profile-img.png"
      alt="profile"
    />
    <h1 className="user-name">Wade Warren</h1>
    <p className="user-designation">Software developer at UK</p>
  </div>
)

export default UserInfo

//src/components/UserInfo/index.css

.user-info-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.profile-img {
  background-color: #ffffff;
  width: 100px;
  margin-top: 31px;
}

.user-name {
  font-family: 'Roboto';
  font-weight: bold;
  font-size: 18px;
  color: #12022f;
  margin-top: 20px;
  margin-bottom: 8px;
}

.user-designation {
  font-family: 'Roboto';
  font-weight: normal;
  font-size: 14px;
  text-align: center;
  color: #616e7c;
}

React Router > Routing using React Router | Part 2 & 3 | Cheat Sheet:
---------------------------------------------------------------------------------------------------------------------

Concepts in Focus:

API Calls
	Fetch
	
Route Props
	Match
	
BlogsList Example

1 . API Calls
In General we make API Calls inside componentDidMount(). So that it doesn’t block render().

1.1 Fetch
fetch is a promise-based API which returns a response object. In the backend, we use snake_case for naming conventions.

2. Route Props
When a component is rendered by the Route, some additional props are passed

match
location
history

2.1 Match
The match object contains the information about the path from which the component is rendered.

3. BlogsList Example

//src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

//App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

//src/components/Header/index.js

import { Link } from 'react-router-dom'

import './index.css'

const Header = () => (
  <nav className="nav-header">
    <div className="blog-container">
      <h1 className="blog-title">Dev Blog</h1>
      <ul className="nav-menu">
        <Link className="nav-link" to="/">
          <li>Home</li>
        </Link>
        <Link className="nav-link" to="/about">
          <li>About</li>
        </Link>
        <Link className="nav-link" to="/contact">
          <li>Contact</li>
        </Link>
      </ul>
    </div>
  </nav>
)

export default Header

//src/components/Header/index.css

.nav-header {
  height: 30vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background: url('https://assets.ccbp.in/frontend/react-js/books-blog-bg.png');
}
.nav-menu {
  list-style-type: none;
  display: flex;
  margin-left: -40px;
}

.nav-link {
  text-decoration: none;
  margin: 8px;
  color: white;
  font-family: 'Roboto';
}

.blog-container {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}
.blog-title {
  font-family: 'Roboto';
  color: white;
  font-size: 16px;
}
.sub-title {
  color: white;
  font-family: 'Roboto';
  margin-top: 0px;
}

@media screen and (min-width: 575px) {
  .blog-title {
    font-family: 'Roboto';
    color: white;
    font-size: 34px;
  }
}

//src/components/BlogsList/index.js

import { Component } from 'react'
import Loader from 'react-loader-spinner'

import 'react-loader-spinner/dist/loader/css/react-spinner-loader.css'

import BlogItem from '../BlogItem'

import './index.css'

class BlogsList extends Component {
  state = { isLoading: true, blogsData: [] }

  componentDidMount() {
    this.getBlogsData()
  }

  getBlogsData = async () => {
    const response = await fetch('https://apis.ccbp.in/blogs')
    const statusCode = await response.statusCode
    console.log(statusCode)
    const data = await response.json()

    const formattedData = data.map(eachItem => ({
      id: eachItem.id,
      title: eachItem.title,
      imageUrl: eachItem.image_url,
      avatarUrl: eachItem.avatar_url,
      author: eachItem.author,
      topic: eachItem.topic,
    }))
    this.setState({ blogsData: formattedData, isLoading: false })
  }

  render() {
    const { blogsData, isLoading } = this.state
    console.log(isLoading)

    return (
      <div className="blog-list-container">
        {isLoading ? (
          <Loader type="TailSpin" color="#00BFFF" height={50} width={50} />
        ) : (
          blogsData.map(item => <BlogItem blogData={item} key={item.id} />)
        )}
      </div>
    )
  }
}

export default BlogsList

//src/components/BlogsList/index.css

.blog-list-container {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  margin-top: 40px;
}

//src/components/BlogItem/index.js

import { Link } from 'react-router-dom'

import './index.css'

const BlogItem = props => {
  const { blogData } = props
  const { id, imageUrl, topic, title, avatarUrl, author } = blogData

  return (
    <Link to={`/blogs/${id}`} className="item-link">
      <div className="item-container">
        <img className="item-image" src={imageUrl} alt={`item${id}`} />
        <div className="item-info">
          <p className="item-topic">{topic}</p>
          <p className="item-title">{title}</p>
          <div className="author-info">
            <img className="avatar" src={avatarUrl} alt={`avatar${id}`} />
            <p className="author-name">{author}</p>
          </div>
        </div>
      </div>
    </Link>
  )
}

export default BlogItem

//src/components/BlogItem/index.css

.blog-item-link {
  color: black;
  text-decoration: none;
  border: 1px solid lightgray;
  border-radius: 5px;
  margin: 15px;
}

.item-container {
  display: flex;
  flex-direction: column;
  margin: 15px;
}
@media screen and (min-width: 575px) {
  .item-container {
    flex-direction: row;
    width: 660px;
    height: 170px;
    margin: 15px;
  }
}

.item-image {
  width: 100%;
  border: 1px solid transparent;
  border-radius: 5px;
  height: 170px;
}

@media screen and (min-width: 575px) {
  .item-image {
    width: 40%;
    border: 1px solid transparent;
    border-radius: 5px;
    margin-right: 15px;
  }
}

.item-info {
  font-family: 'Roboto';
  width: 100%;
}

@media screen and (min-width: 575px) {
  .item-info {
    width: 60%;
  }
}

.item-topic {
  color: #8e8e8e;
  font-size: 14px;
}

.item-title {
  font-size: 18px;
}

.author-info {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}

.avatar {
  height: 30px;
  width: 30px;
  margin-right: 10px;
  border-radius: 50%;
}
.author-name {
  color: #8e8e8e;
  font-size: 14px;
}

//src/components/About/index.js

import './index.css'

const About = () => (
  <div className="about-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/about-blog-img.png"
      alt="about"
      className="about-img"
    />
    <h1 className="about-heading">About</h1>
    <p className="about-paragraph">All about Blogs of frontend developers</p>
  </div>
)

export default About

//src/components/About/index.css

.about-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}
.about-img {
  width: 150px;
}
.about-heading {
  font-family: 'Roboto';
  font-weight: 500;
  color: #3d3d3d;
}
.about-paragraph {
  font-family: 'Roboto';
  font-size: 20px;
  text-align: center;
  color: #555555;
}

//src/components/Contact/index.js

import './index.css'

const Contact = () => (
  <div className="contact-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/contact-blog-img.png"
      alt="contact"
      className="contact-img"
    />
    <h1 className="contact-heading">Contact</h1>
  </div>
)

export default Contact

//src/components/Contact/index.css

.contact-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}
.contact-img {
  width: 150px;
}
.contact-heading {
  font-family: 'Roboto';
  font-weight: 500;
  color: #3d3d3d;
}

//src/components/BlogItemDetails/index.js

import { Component } from 'react'
import Loader from 'react-loader-spinner'

import 'react-loader-spinner/dist/loader/css/react-spinner-loader.css'
import './index.css'

class BlogItemDetails extends Component {
  state = { blogData: {}, isLoading: true }

  componentDidMount() {
    this.getBlogItemData()
  }

  getBlogItemData = async () => {
    const { match } = this.props
    const { params } = match
    const { id } = params

    const response = await fetch(`https://apis.ccbp.in/blogs/${id}`)
    const data = await response.json()

    const updatedData = {
      title: data.title,
      imageUrl: data.image_url,
      content: data.content,
      avatarUrl: data.avatar_url,
      author: data.author,
    }
    this.setState({ blogData: updatedData, isLoading: false })
  }

  renderBlogItemDetails = () => {
    const { blogData } = this.state
    const { title, imageUrl, content, avatarUrl, author } = blogData

    return (
      <div className="blog-info">
        <h2 className="blog-details-title">{title}</h2>
        <div className="author-details">
          <img className="author-pic" src={avatarUrl} alt={author} />
          <p className="details-author-name">{author}</p>
        </div>
        <img className="blog-image" src={imageUrl} alt={title} />
        <p className="blog-content">{content}</p>
      </div>
    )
  }

  render() {
    const { isLoading } = this.state

    return (
      <div className="blog-container">
        {isLoading ? (
          <Loader type="TailSpin" color="#00BFFF" height={50} width={50} />
        ) : (
          this.renderBlogItemDetails()
        )}
      </div>
    )
  }
}

export default BlogItemDetails

//src/components/BlogItemDetails/index.css

.blog-container {
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  padding: 15px;
}
@media screen and (min-width: 575px) {
  .blog-container {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
  }
}

.blog-info {
  width: 100%;
}
@media screen and (min-width: 575px) {
  .blog-info {
    width: 660px;
  }
}

.blog-details-title {
  font-size: 14px;
  text-align: center;
  font-weight: bold;
  font-family: 'Roboto';
}
@media screen and (min-width: 575px) {
  .blog-details-title {
    font-size: 28px;
    text-align: center;
    font-family: 'Roboto';
  }
}

.author-details {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}

.author-pic {
  height: 30px;
  width: 30px;
  margin-right: 10px;
  border-radius: 50%;
}
.blog-author-name {
  color: #8e8e8e;
  font-size: 14px;
}

.blog-image {
  width: 100%;
  height: 180px;
  border-radius: 8px;
  object-fit: cover;
}
@media screen and (min-width: 575px) {
  .blog-image {
    width: 660px;
    height: 300px;
    border-radius: 8px;
    object-fit: cover;
  }
}

.blog-content {
  margin-top: 15px;
  font-family: 'Roboto';
  line-height: 24px;
  color: darkslategrey;
}

//src/components/NotFound/index.js

import './index.css'

const NotFound = () => (
  <div className="not-found-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/not-found-blog-img.png"
      alt="not-found"
      className="not-found-img"
    />
  </div>
)

export default NotFound

//src/components/NotFound/index.css

.not-found-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 70vh;
}
.not-found-img {
  width: 400px;
}

coding pratice-23:
--------------------------------------------------------------------------------------------------------------------

Fetch And Routing Practice:
-------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-FetchAndRoutingPractice

In this project, let's perform Fetch and Routing by applying the concepts we have learned till now.

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

1.1.When the app is opened, Home Route should be displayed

1.2.When the Home Route is opened,
	Make HTTP GET request to the blogsApiUrl
	loader should be displayed while fetching the data
	After fetching the data, the list of blogs should be displayed
	
1.3.When a blog item in Home Route is clicked,
	Page should be navigated to the Blog Item Details Route with the URL /blogs/:id
	
1.4.When the Blog Item Details Route is opened,
	Make HTTP GET request to the blogItemDetailsApiUrl with the blog id to get the details of the blog
	Example: https://apis.ccbp.in/blogs/2
	loader should be displayed while fetching the data
	After fetching the data, the details of the blog should be displayed
	
2.API Requests & Responses

blogsApiUrl

API: https://apis.ccbp.in/blogs
Method: GET
Description:
Returns a response containing the list of all blogs

Response

[
  {
    "id": 1,
    "title": "React v16.9.0 and the Roadmap Update",
    "image_url": "https://miro.medium.com/max/1050/1*i3hzpSEiEEMTuWIYviYweQ.png",
    "avatar_url": "https://miro.medium.com/max/4096/1*wiOSfPd2sY0gXSNK9vv6bg.jpeg",
    "author": "Dan Abramov,",
    "topic": "React.js"
  },
  ...
]

2.1.blogItemDetailsApiUrl

API: https://apis.ccbp.in/blogs/:id
Example: https://apis.ccbp.in/blogs/2
Method: GET
Description:
Returns a response containing the details of the specific blog

Response

{
  "id": 2,
  "title": "React v16.7: No, This Is Not the One With Hooks",
  "image_url": "https://miro.medium.com/max/3158/1*kEPCQNY4dwVyaFuLEwJcNQ.png",
  "avatar_url": "https://avatars.githubusercontent.com/u/3624098?v=4",
  "author": "Andrew Clark",
  "content": "React follows semantic versioning. Typically, this means that we use patch versions for bugfixes, and minors for new (non-breaking) features. However, we reserve the option to release minor versions even if they do not include new features. The motivation is to reserve patches for changes that have a very low chance of breaking. Patches are the most important type of release because they sometimes contain critical bugfixes.",
  "topic": "React.js"
}

3.Implementation Files

Use these files to complete the implementation:

src/App.js
src/components/Home/index.js
src/components/BlogList/index.js
src/components/BlogList/index.css
src/components/BlogItem/index.js
src/components/BlogItem/index.css
src/components/BlogItemDetails/index.js
src/components/BlogItemDetails/index.css

4.Important Note
Click to view

The following instructions are required for the tests to pass

Home route should consist of / in the URL path
About route should consist of /about in the URL path
Contact route should consist of /contact in the URL path
BlogItemDetails route should consist of /blogs/:id in the URL path
No need to use the BrowserRouter in App.js as we have already included in index.js file
Wrap the Loader component with an HTML container element and add the testid attribute value as loader to it as shown below

<div testid="loader">
  <Loader type="TailSpin" color="#00bfff" height={50} width={50} />
</div>

//src/App.js

import {Route, Switch} from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Home from './components/Home'
import Contact from './components/Contact'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <div className="app-container">
    <div className="responsive-container">
      <Header />
      <div className="app-body">
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/about" component={About} />
          <Route exact path="/contact" component={Contact} />
          <Route path="/blogs/:id" component={BlogItemDetails} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  </div>
)

export default App

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 50px;
  margin-top: 50px;
}

.responsive-container {
  display: flex;
  flex-direction: column;
  width: 80%;
  border: 4px solid #551e53;
  border-radius: 12px;
}

@media (max-width: 576px) {
  .responsive-container {
    width: 85%;
  }
}

.app-body {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-grow: 1;
}

//src/components/Home/index.js

import BlogList from '../BlogList'
import UserInfo from '../UserInfo'

import './index.css'

const Home = () => (
  <div className="home-container">
    <UserInfo />
    <BlogList />
  </div>
)

export default Home

//src/components/Home/index.css

.home-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
}

//src/components/BlogList/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'
import 'react-loader-spinner/dist/loader/css/react-spinner-loader.css'

import BlogItem from '../BlogItem'

import './index.css'

class BlogList extends Component {
  state = {isLoading: true, blogsData: []}

  componentDidMount() {
    this.getBlogsData()
  }

  getBlogsData = async () => {
    const response = await fetch('https://apis.ccbp.in/blogs')
    const data = await response.json()
    const formattedData = data.map(eachItem => ({
      id: eachItem.id,
      title: eachItem.title,
      imageUrl: eachItem.image_url,
      avatarUrl: eachItem.avatar_url,
      author: eachItem.author,
      topic: eachItem.topic,
    }))

    this.setState({blogsData: formattedData, isLoading: false})
  }

  render() {
    const {blogsData, isLoading} = this.state

    return (
      <div className="blogs-list-container">
        {isLoading ? (
          <div testid="loader">
            <Loader type="TailSpin" color="#00bfff" height={50} width={50} />
          </div>
        ) : (
          <ul className="blogs-list">
            {blogsData.map(eachBlogItem => (
              <BlogItem key={eachBlogItem.id} blogItemDetails={eachBlogItem} />
            ))}
          </ul>
        )}
      </div>
    )
  }
}

export default BlogList

//src/components/BlogList/index.css

.blogs-list-container {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  margin-top: 40px;
}

.blogs-list {
  padding-left: 0px;
}

//src/components/BlogItem/index.js

import {Link} from 'react-router-dom'

import './index.css'

const BlogItem = props => {
  const {blogItemDetails} = props
  const {id, imageUrl, topic, title, avatarUrl, author} = blogItemDetails

  return (
    <li className="blog-item">
      <Link to={`/blogs/${id}`} className="blog-item-link">
        <div className="blog-item-container">
          <img className="blog-item-image" src={imageUrl} alt={`item${id}`} />
          <div className="blog-item-info">
            <p className="blog-item-topic">{topic}</p>
            <h1 className="blog-item-title">{title}</h1>
            <div className="author-info">
              <img className="avatar" src={avatarUrl} alt={`avatar${id}`} />
              <p className="author-name">{author}</p>
            </div>
          </div>
        </div>
      </Link>
    </li>
  )
}

export default BlogItem

//src/components/BlogItem/index.css

.blog-item {
  border: 1px solid #d3d3d3;
  border-radius: 5px;
  margin: 15px;
  list-style-type: none;
}

.blog-item-link {
  color: #000000;
  text-decoration: none;
}

.blog-item-container {
  display: flex;
  flex-direction: column;
  margin: 15px;
}
@media screen and (min-width: 575px) {
  .blog-item-container {
    flex-direction: row;
    max-width: 660px;
    height: 170px;
    margin: 15px;
  }
}

.blog-item-image {
  width: 100%;
  border: 1px solid transparent;
  border-radius: 5px;
  height: 170px;
}

@media screen and (min-width: 575px) {
  .blog-item-image {
    width: 40%;
    border: 1px solid transparent;
    border-radius: 5px;
    margin-right: 15px;
  }
}

.blog-item-info {
  font-family: roboto;
  width: 100%;
}

@media screen and (min-width: 575px) {
  .blog-item-info {
    width: 60%;
  }
}

.blog-item-topic {
  color: #8e8e8e;
  font-size: 14px;
}

.blog-item-title {
  font-size: 18px;
  font-weight: 400;
}

.author-info {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}

.avatar {
  height: 30px;
  width: 30px;
  margin-right: 10px;
  border-radius: 50%;
}
.author-name {
  color: #8e8e8e;
  font-size: 14px;
}

//src/components/BlogItemDetails/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'
import 'react-loader-spinner/dist/loader/css/react-spinner-loader.css'

import './index.css'

class BlogItemDetails extends Component {
  state = {blogData: {}, isLoading: true}

  componentDidMount() {
    this.getBlogItemData()
  }

  getBlogItemData = async () => {
    const {match} = this.props
    const {params} = match
    const {id} = params
    const response = await fetch(`https://apis.ccbp.in/blogs/${id}`)
    const data = await response.json()
    const updatedData = {
      title: data.title,
      imageUrl: data.image_url,
      content: data.content,
      avatarUrl: data.avatar_url,
      author: data.author,
    }

    this.setState({blogData: updatedData, isLoading: false})
  }

  renderBlogItemDetails = () => {
    const {blogData} = this.state
    const {title, imageUrl, content, avatarUrl, author} = blogData

    return (
      <div className="blog-info">
        <h1 className="blog-details-title">{title}</h1>

        <div className="author-details">
          <img className="author-pic" src={avatarUrl} alt={author} />
          <p className="details-author-name">{author}</p>
        </div>

        <img className="blog-image" src={imageUrl} alt={title} />
        <p className="blog-content">{content}</p>
      </div>
    )
  }

  render() {
    const {isLoading} = this.state

    return (
      <div className="blog-container">
        {isLoading ? (
          <div testid="loader">
            <Loader type="TailSpin" color="#00bfff" height={50} width={50} />
          </div>
        ) : (
          this.renderBlogItemDetails()
        )}
      </div>
    )
  }
}

export default BlogItemDetails

//src/components/BlogItemDetails/index.css

.blog-container {
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  padding: 15px;
}

@media screen and (min-width: 575px) {
  .blog-container {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
  }
}

.blog-info {
  width: 100%;
}

@media screen and (min-width: 575px) {
  .blog-info {
    max-width: 660px;
  }
}

.blog-details-title {
  font-size: 14px;
  text-align: center;
  font-weight: bold;
  font-family: roboto;
}

@media screen and (min-width: 575px) {
  .blog-details-title {
    font-size: 28px;
    text-align: center;
    font-family: roboto;
  }
}

.author-details {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}

.author-pic {
  height: 30px;
  width: 30px;
  margin-right: 10px;
  border-radius: 50%;
}

.blog-author-name {
  color: #8e8e8e;
  font-size: 14px;
}

.blog-image {
  width: 100%;
  height: 180px;
  border-radius: 8px;
  object-fit: cover;
}

@media screen and (min-width: 575px) {
  .blog-image {
    max-width: 660px;
    height: 300px;
  }
}

.blog-content {
  margin-top: 15px;
  font-family: 'Roboto';
  line-height: 24px;
  color: #2f4f4f;
}

//src/components/UserInfo/index.js

import './index.css'

const UserInfo = () => (
  <div className="user-info-container">
    <img
      className="profile-img"
      src="https://assets.ccbp.in/frontend/react-js/profile-img.png"
      alt="profile"
    />
    <h1 className="user-name">Wade Warren</h1>
    <p className="user-designation">Software developer at UK</p>
  </div>
)

export default UserInfo

//src/components/UserInfo/index.css

.user-info-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.profile-img { 
  background-color: #ffffff;
  width: 100px;
  margin-top: 31px;
}

.user-name {
  font-family: 'Roboto';
  font-weight: bold;
  font-size: 18px;
  color: #12022f;
  margin-top: 20px;
  margin-bottom: 8px;
}

.user-designation {
  font-family: 'Roboto';
  font-weight: normal;
  font-size: 14px;
  text-align: center;
  color: #616e7c;
}

coding pratice-24:
--------------------------------------------------------------------

Cryptocurrency Tracker: --> Loader
-----------------------------------------

In this project, let's build a Cryptocurrency Tracker by applying the concepts we have learned till now.

https://github.com/ManirathnamKuruma/ReactJS-CryptocurrencyTracker

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

When the page is opened,
	Make HTTP GET request to the cryptocurrenciesApiUrl
	loader should be displayed while fetching the data
	After fetching the data, the updated list of cryptocurrencies should be displayed
	
2.API Requests & Responses

cryptocurrenciesApiUrl

API: https://apis.ccbp.in/crypto-currency-converter
Method: GET
Description:
Returns a response containing the list of cryptocurrencies

Response

[
  {
    "currency_name": "Bitcoin",
    "usd_value": "46750.63",
    "euro_value": "39596.07",
    "id": "6e937df9-1345-4c2f-8ace-babff0e5108f",
    "currency_logo": "https://www.cryptocompare.com/media/19633/btc.png"
  },
  ...
]

3.Quick Tips
Click to view

To display the animated loader, we need to import the Loader component using the below statement

import Loader from 'react-loader-spinner'

In order to display the given animated loader, pass the type and color props to the Loader component with values as Rings and #ffffff, respectively

<Loader type="Rings" color="#ffffff" height={80} width={80} />

4.Important Note
Click to view

The following instructions are required for the tests to pass

The cryptocurrencies should have the alt as the value of the key currency_name from each cryptocurrency object received in response
Wrap the Loader component with an HTML container element and add the testid attribute value as loader to it as shown below

<div testid="loader">
  <Loader type="Rings" color="#ffffff" height={80} width={80} />
</div>

//src/components/CryptocurrencyItem/index.js

import './index.css'

const CryptocurrencyItem = props => {
  const {cryptocurrencyDetails} = props
  const {
    currencyLogoUrl,
    currencyName,
    usdValue,
    euroValue,
  } = cryptocurrencyDetails

  return (
    <li className="cryptocurrency-item">
      <div className="logo-and-title-container">
        <img
          className="currency-logo"
          src={currencyLogoUrl}
          alt={currencyName}
        />
        <p className="currency-name">{currencyName}</p>
      </div>
      <div className="usd-and-euro-values-container">
        <p className="currency-value">{usdValue}</p>
        <p className="currency-value">{euroValue}</p>
      </div>
    </li>
  )
}

export default CryptocurrencyItem

//src/components/CryptocurrencyItem/index.css

.cryptocurrency-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo-and-title-container {
  display: flex;
  align-items: center;
}

.currency-logo {
  width: 16px;
  height: 16px;
  margin-right: 8px;
}

@media (min-width: 576px) {
  .currency-logo {
    width: 32px;
    height: 32px;
    margin-right: 16px;
  }
}

.currency-name {
  color: #ffffff;
  font-size: 12px;
  font-weight: 500;
}

@media (min-width: 576px) {
  .currency-name {
    font-size: 16px;
  }
}

.usd-and-euro-values-container {
  display: flex;
  align-items: center;
}

.currency-value {
  text-align: right;
  color: #ffffff;
  font-size: 12px;
  font-weight: 500;
  width: 52px;
  margin-left: 8px;
}

@media (min-width: 576px) {
  .currency-value {
    font-size: 16px;
    width: 72px;
    margin-left: 48px;
  }
}

//src/components/CryptocurrencyTracker/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'

import CryptocurrenciesList from '../CryptocurrenciesList'

import './index.css'

const apiUrl = 'https://apis.ccbp.in/crypto-currency-converter'

class CryptocurrencyTracker extends Component {
  state = {
    cryptocurrenciesData: [],
    isLoading: true,
  }

  componentDidMount() {
    this.getCryptocurrencies()
  }

  getCryptocurrencies = async () => {
    const response = await fetch(apiUrl)
    const fetchedData = await response.json()

    this.setState({
      cryptocurrenciesData: fetchedData.map(eachCryptocurrency => ({
        id: eachCryptocurrency.id,
        currencyLogoUrl: eachCryptocurrency.currency_logo,
        currencyName: eachCryptocurrency.currency_name,
        usdValue: eachCryptocurrency.usd_value,
        euroValue: eachCryptocurrency.euro_value,
      })),
      isLoading: false,
    })
  }

  renderCryptocurrenciesList = () => {
    const {cryptocurrenciesData} = this.state

    return <CryptocurrenciesList cryptocurrenciesData={cryptocurrenciesData} />
  }

  renderLoader = () => (
    <div testid="loader">
      <Loader type="Rings" color="#ffffff" height={80} width={80} />
    </div>
  )

  render() {
    const {isLoading} = this.state

    return (
      <div className="app-container">
        {isLoading ? this.renderLoader() : this.renderCryptocurrenciesList()}
      </div>
    )
  }
}

export default CryptocurrencyTracker

//src/components/CryptocurrencyTracker/index.css

.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #000000;
  font-family: 'Roboto';
  min-height: 100vh;
}

.error-message {
  text-align: center;
  color: #00e7ff;
  font-size: 28px;
  font-weight: bold;
  margin: 4px;
}

@media (min-width: 576px) {
  .error-message {
    font-size: 48px;
  }
}

//src/components/CryptocurrenciesList/index.js

import {Component} from 'react'

import CryptocurrencyItem from '../CryptocurrencyItem'

import './index.css'

class CryptocurrenciesList extends Component {
  renderCryptocurrenciesHeader = () => (
    <div className="list-header">
      <p className="list-coin-type-heading">Coin Type</p>
      <div className="usd-and-euro-values-container">
        <p className="list-coin-value-heading">USD</p>
        <p className="list-coin-value-heading">EURO</p>
      </div>
    </div>
  )

  renderCryptocurrenciesView = () => {
    const {cryptocurrenciesData} = this.props

    return (
      <div className="cryptocurrencies-list-container">
        {this.renderCryptocurrenciesHeader()}
        <ul className="cryptocurrencies-list">
          {cryptocurrenciesData.map(eachCryptocurrency => (
            <CryptocurrencyItem
              key={eachCryptocurrency.id}
              cryptocurrencyDetails={eachCryptocurrency}
            />
          ))}
        </ul>
      </div>
    )
  }

  render() {
    return (
      <div className="cryptocurrencies-container">
        <h1 className="heading">Cryptocurrency Tracker</h1>
        <img
          className="cryptocurrency-img"
          src="https://assets.ccbp.in/frontend/react-js/cryptocurrency-bg.png"
          alt="cryptocurrency"
        />
        {this.renderCryptocurrenciesView()}
      </div>
    )
  }
}

export default CryptocurrenciesList

//src/components/CryptocurrenciesList/index.css

.cryptocurrencies-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 80%;
}

.heading {
  text-align: center;
  color: #00e7ff;
  font-size: 28px;
  font-weight: bold;
  margin: 4px;
}

@media (min-width: 576px) {
  .heading {
    font-size: 48px;
  }
}

.cryptocurrency-img {
  width: 330px;
}

@media (min-width: 992px) {
  .cryptocurrency-img {
    width: 950px;
  }
}

.cryptocurrencies-list-container {
  display: flex;
  flex-direction: column;
  align-self: stretch;
  border: 4px solid #00e7ff;
  border-radius: 8px;
  margin-top: 48px;
}

.list-header {
  display: flex;
  justify-content: space-between;
  background-color: #092e33;
  padding: 8px;
  padding-left: 24px;
  padding-right: 24px;
}

@media (min-width: 576px) {
  .list-header {
    padding: 16px;
    padding-left: 48px;
    padding-right: 48px;
  }
}

.list-coin-type-heading {
  color: #ffffff;
  font-size: 16px;
  font-weight: 500;
  margin: 0px;
}

@media (min-width: 576px) {
  .list-coin-type-heading {
    font-size: 24px;
  }
}

.usd-and-euro-values-container {
  display: flex;
  align-items: center;
}

.list-coin-value-heading {
  text-align: right;
  color: #ffffff;
  font-size: 16px;
  font-weight: 500;
  width: 52px;
  margin: 0px;
  margin-left: 8px;
}

@media (min-width: 576px) {
  .list-coin-value-heading {
    font-size: 24px;
    width: 72px;
    margin-left: 48px;
  }
}

.cryptocurrencies-list {
  padding-left: 24px;
  padding-right: 24px;
}

@media (min-width: 576px) {
  .cryptocurrencies-list {
    padding-left: 48px;
    padding-right: 48px;
  }
}

//src/App.js

import CryptocurrencyTracker from './components/CryptocurrencyTracker'

import './App.css'

const App = () => <CryptocurrencyTracker />

export default App

Assignment-4:
-----------------------------------------------------------

IPL Dashboard App:
-----------------------------

In this project, let's build an IPL Dashboard App by applying the concepts we have learned till now.

https://github.com/ManirathnamKuruma/ReactJS-IPL_DashboardApp

Common Mistakes | Part 2 | Cheat Sheet:
--------------------------------------------------------------

Concepts in Focus:

Rendering Promise Object
Using Link and Route Components without BrowserRouter
Providing Wrong Route Path
Missing exact keyword
Missing Switch
Placing Common component inside Switch
Providing the same PATH for multiple Routes
Missing Colon(:) while providing Path Parameters
Accessing Promise Object
Ordering of Routes inside Switch

1. Rendering Promise Object

Mistake:
--------------------------

Async Function returns a Promise Object But, React cannot render this Promise Object.
The best way to make API call is in the componentDidMount().

File: src/components/BlogsList/index.js

import { Component } from 'react'
import Loader from 'react-loader-spinner'

import 'react-loader-spinner/dist/loader/css/react-spinner-loader.css'

import BlogItem from '../BlogItem'

import './index.css'

class BlogsList extends Component {
  state = { isLoading: true, blogsData: [] }

  getBlogsData = async () => {
    const response = await fetch('https://apis.ccbp.in/blogs')
    const statusCode = await response.statusCode
    console.log(statusCode)
    const data = await response.json()

    const formattedData = data.map(eachItem => ({
      id: eachItem.id,
      title: eachItem.title,
      imageUrl: eachItem.image_url,
      avatarUrl: eachItem.avatar_url,
      author: eachItem.author,
      topic: eachItem.topic,
    }))
  }

  render() {
    const { blogsData, isLoading } = this.state
    console.log(isLoading)

    return (
      <div className="blog-list-container">
       {this.getBlogsData()}
      </div>
    )
  }
}

export default BlogsList

Solution:
------------------

File: src/components/BlogsList/index.js

import { Component } from 'react'
import Loader from 'react-loader-spinner'

import 'react-loader-spinner/dist/loader/css/react-spinner-loader.css'

import BlogItem from '../BlogItem'

import './index.css'

class BlogsList extends Component {
  state = { isLoading: true, blogsData: [] }

  componentDidMount() {
    this.getBlogsData()
  }

  getBlogsData = async () => {
    const response = await fetch('https://apis.ccbp.in/blogs')
    const statusCode = await response.statusCode
    console.log(statusCode)
    const data = await response.json()

    const formattedData = data.map(eachItem => ({
      id: eachItem.id,
      title: eachItem.title,
      imageUrl: eachItem.image_url,
      avatarUrl: eachItem.avatar_url,
      author: eachItem.author,
      topic: eachItem.topic,
    }))
    this.setState({ blogsData: formattedData, isLoading: false })
  }

  render() {
    const { blogsData, isLoading } = this.state
    console.log(isLoading)

    return (
      <div className="blog-list-container">
        {isLoading ? (
          <Loader type="TailSpin" color="#00BFFF" height={50} width={50} />
        ) : (
          blogsData.map(item => <BlogItem blogData={item} key={item.id} />)
        )}
      </div>
    )
  }
}

export default BlogsList

2. Using Link and Route Components without BrowserRouter

Mistake:
-----------------------------

File: src/App.js

import {Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
)

export default App

Solution:
--------------------------

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

File: src/components/Header/index.js

import { Link } from 'react-router-dom'

import './index.css'

const Header = () => (
  <nav className="nav-header">
    <div className="blog-container">
      <h1 className="blog-title">Dev Blog</h1>
      <ul className="nav-menu">
        <Link className="nav-link" to="/">
          <li>Home</li>
        </Link>
        <Link className="nav-link" to="/about">
          <li>About</li>
        </Link>
        <Link className="nav-link" to="/contact">
          <li>Contact</li>
        </Link>
      </ul>
    </div>
  </nav>
)

export default Header

3. Providing Wrong Route Path

Mistake:
------------------

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/abot" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

Solution:
-------------------

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

File: src/components/Header/index.js

import { Link } from 'react-router-dom'

import './index.css'

const Header = () => (
  <nav className="nav-header">
    <div className="blog-container">
      <h1 className="blog-title">Dev Blog</h1>
      <ul className="nav-menu">
        <Link className="nav-link" to="/">
          <li>Home</li>
        </Link>
        <Link className="nav-link" to="/about">
          <li>About</li>
        </Link>
        <Link className="nav-link" to="/contact">
          <li>Contact</li>
        </Link>
      </ul>
    </div>
  </nav>
)

export default Header

4. Missing exact keyword

Mistake:
--------------------------

Switch renders a Route that matches the path.
If Switch is missed, Browser will render Multiple Routes in the single path.

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route  path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

Solution:
----------------------

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route exact path="/about" component={About} />
      <Route exact path="/contact" component={Contact} />
      <Route exact path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

5. Missing Switch

Mistake:
------------------------

File: src/App.js

import { BrowserRouter, Route} from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
      <Header />
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
  </BrowserRouter>
)

export default App

Solution:
-----------------------------

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
      <Header />
      <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
       </Switch>
  </BrowserRouter>
)

export default App

6. Placing Common component inside Switch

Mistake:
--------------------------

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
      <Switch>
      <Header />
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
       </Switch>
  </BrowserRouter>
)

export default App

Solution:
-------------------------

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
      <Header />
      <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
       </Switch>
  </BrowserRouter>
)

export default App

7. Providing the same PATH for multiple Routes

Mistake:
-------------------

If same path is given for multiple Routes, the Switch renders the first matched Component.

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
      <Header />
      <Switch>
      <Route exact path="/about" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
       </Switch>
  </BrowserRouter>
)

export default App

Solution:

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
      <Header />
      <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
       </Switch>
  </BrowserRouter>
)

export default App

8. Missing Colon(:) while providing Path Parameters

Mistake:

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

Solution:

File: src/App.jsimport { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

9. Accessing Promise Object

Mistake:

In the Promise Object response, we got an error message with key error_msg but in the below code snippet,
 we are trying to access the promise object with the wrong key errorText so undefined will be logged in the console.
 
File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.errorText)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

Solution:

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.error_msg)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

10. Ordering of Routes inside Switch

Mistake:

In the below code snippet NotFound Component is placed first in the Switch Component.
If the path is not mentioned and route (NotFound Route) is placed first inside Switch, Browser will render it in all the paths.

File: src/App.js

import {Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
)

export default App

Solution:

File: src/App.js

import { BrowserRouter, Route, Switch } from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Contact from './components/Contact'
import BlogsList from './components/BlogsList'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Header />
    <Switch>
      <Route exact path="/" component={BlogsList} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/blogs/:id" component={BlogItemDetails} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

coding pratice-25:
-------------------------------------------------------------------------------------------------------

Debugging Stopwatch:
----------------------------------------

In this project, let's fix the Stopwatch by applying the concepts we have learned till now.

https://github.com/ManirathnamKuruma/ReactJS-DebuggingStopWatch

//src/components/stopwatch/index.js

import {Component} from 'react'

import './index.css'

class Stopwatch extends Component {
  state = {
    isTimerRunning: false,
    timeElapsedInSeconds: 0,
  }

  // FIX 1: The spelling of this lifecycle method should be componentWillUnmount
  componentWillUnmount() {
    // FIX2: When the setInterval method is used, it is best practice to use clearInterval method to clear the scheduler
    clearInterval(this.timeInterval)
  }

  onResetTimer = () => {
    // FIX3: class variables should be accessed using "this" keyword
    clearInterval(this.timeInterval)
    // FIX4: The timer should be reset to 0 when the "Reset" button is clicked
    this.setState({isTimerRunning: false, timeElapsedInSeconds: 0})
  }

  onStopTimer = () => {
    clearInterval(this.timeInterval)
    this.setState({isTimerRunning: false})
  }

  updateTime = () => {
    this.setState(prevState => ({
      // FIX5: The key timeElapsedInSeconds in prevState should be used to update the state
      timeElapsedInSeconds: prevState.timeElapsedInSeconds + 1,
    }))
  }

  onStartTimer = () => {
    // FIX6: Here to update the timeElapsedInSeconds value for every 1000 milliseconds setInterval method should be used
    // FIX7: The id returned by setInterval should be stored in class variable to access it across other methods in the class using "this" keyword
    // FIX8: class methods should be accessed using "this" keyword
    this.timeInterval = setInterval(this.updateTime, 1000)
    this.setState({isTimerRunning: true})
  }

  renderSeconds = () => {
    const {timeElapsedInSeconds} = this.state
    const seconds = Math.floor(timeElapsedInSeconds % 60)

    if (seconds < 10) {
      return `0${seconds}`
    }
    return seconds
  }

  renderMinutes = () => {
    const {timeElapsedInSeconds} = this.state
    const minutes = Math.floor(timeElapsedInSeconds / 60)

    if (minutes < 10) {
      return `0${minutes}`
    }
    return minutes
  }

  render() {
    const {isTimerRunning} = this.state
    // FIX9: class methods should be accessed using "this" keyword
    const time = `${this.renderMinutes()}:${this.renderSeconds()}`

    return (
      <div className="app-container">
        <div className="stopwatch-container">
          <h1 className="stopwatch">Stopwatch</h1>
          <div className="timer-container">
            <div className="timer">
              <img
                className="timer-image"
                src="https://assets.ccbp.in/frontend/react-js/stopwatch-timer.png"
                alt="stopwatch"
              />
              <p className="timer-text">Timer</p>
            </div>
            <h1 className="stopwatch-timer">{time}</h1>
            <div className="timer-buttons">
              <button
                type="button"
                className="start-button button"
                onClick={this.onStartTimer}
                disabled={isTimerRunning}
              >
                Start
              </button>
              <button
                type="button"
                className="stop-button button"
                onClick={this.onStopTimer}
              >
                Stop
              </button>
              <button
                type="button"
                className="reset-button button"
                onClick={this.onResetTimer}
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

// FIX10: The syntax for default export should be written like this
export default Stopwatch

Debugging Fetch And Routing:
-------------------------------------------------

In this project, let's fix the Fetch And Routing practice app by applying the concepts we have learned till now.

https://github.com/ManirathnamKuruma/ReactJS-DebuggingFetchAndRouting/

//src/App.js

// FIX1: Switch component should be imported from react-router-dom before using it
import {Route, Switch} from 'react-router-dom'

import Header from './components/Header'
import About from './components/About'
import Home from './components/Home'
import Contact from './components/Contact'
import BlogItemDetails from './components/BlogItemDetails'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <div className="app-container">
    <div className="responsive-container">
      {/* FIX2: Header should be placed outside the Switch component */}
      <Header />
      <div className="app-body">
        <Switch>
          {/* FIX3: When "/" is provided in URL path, then the Home component should be displayed */}
          <Route exact path="/" component={Home} />
          {/* FIX4: About Route should consist of "/about" in URL path */}
          <Route exact path="/about" component={About} />
          {/* FIX5: When "/contact" is provided in URL path, then the Contact component should be displayed */}
          <Route exact path="/contact" component={Contact} />
          {/* FIX6: When mentioning path parameters for a route we need to use ":" before the variable */}
          <Route path="/blogs/:id" component={BlogItemDetails} />
          {/* FIX7: NotFound component should be at last  */}
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  </div>
)

export default App

//src/components/Header/index.js

import {Link} from 'react-router-dom'

import './index.css'

const Header = () => (
  <nav className="header-container">
    <div className="logo-and-title-container">
      <img
        alt="wave"
        className="logo"
        src="https://assets.ccbp.in/frontend/react-js/wave-logo-img.png"
      />
      <h1 className="title">Wave</h1>
    </div>
    <ul className="nav-items-list">
      <li className="link-item">
        <Link className="route-link" to="/">
          {/* FIX8: The text for the path "/" should be Home */}
          Home
        </Link>
      </li>
      <li className="link-item">
        <Link className="route-link" to="/about">
          {/* FIX9: The text for the path "/about" should be About */}
          About
        </Link>
      </li>
      <li className="link-item">
        <Link className="route-link" to="/contact">
          {/* FIX10: The text for the path "/contact" should be Contact */}
          Contact
        </Link>
      </li>
    </ul>
  </nav>
)

export default Header

//src/components/BlogList/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'
import 'react-loader-spinner/dist/loader/css/react-spinner-loader.css'

import BlogItem from '../BlogItem'

import './index.css'

class BlogList extends Component {
  state = {isLoading: true, blogsData: []}

  componentDidMount() {
    this.getBlogsData()
  }

  // FIX11: await should always be used inside async function
  getBlogsData = async () => {
    // FIX12: Spelling of fetch
    const response = await fetch('https://apis.ccbp.in/blogs')
    // FIX13: To get the response in json format we need to call response.json() method
    const data = await response.json()
    const formattedData = data.map(eachItem => ({
      id: eachItem.id,
      title: eachItem.title,
      imageUrl: eachItem.image_url,
      avatarUrl: eachItem.avatar_url,
      author: eachItem.author,
      topic: eachItem.topic,
    }))
    // FIX14: Response received for blogsData should be updated in the state
    this.setState({blogsData: formattedData, isLoading: false})
  }

  render() {
    const {blogsData, isLoading} = this.state
    // FIX15: Fetching of data and updating the state should not be done in the render method as it leads to infinite loops

    return (
      <div className="blogs-list-container">
        {/* FIX16: The testid attribute value should be "loader" */}
        {isLoading ? (
          <div testid="loader">
            <Loader type="TailSpin" color="#00bfff" height={50} width={50} />
          </div>
        ) : (
          <ul className="blogs-list">
            {blogsData.map(eachBlogItem => (
              <BlogItem key={eachBlogItem.id} blogItemDetails={eachBlogItem} />
            ))}
            {/* FIX17: When rendering a list of items we need to use "key" prop */}
          </ul>
        )}
      </div>
    )
  }
}

export default BlogList

//src/components/BlogItemDetails/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'
import 'react-loader-spinner/dist/loader/css/react-spinner-loader.css'

import './index.css'

class BlogItemDetails extends Component {
  state = {blogData: {}, isLoading: true}

  componentDidMount() {
    this.getBlogItemData()
  }

  getBlogItemData = async () => {
    const {match} = this.props
    const {params} = match
    const {id} = params

    // FIX18: The API call for the individual blog details should be done using the blog id as a path parameter in the apiUrl
    const response = await fetch(`https://apis.ccbp.in/blogs/${id}`)
    const data = await response.json()
    const updatedData = {
      title: data.title,
      imageUrl: data.image_url,
      content: data.content,
      avatarUrl: data.avatar_url,
      author: data.author,
    }
    this.setState({blogData: updatedData, isLoading: false})
  }

  renderBlogItemDetails = () => {
    const {blogData} = this.state
    const {title, imageUrl, content, avatarUrl, author} = blogData
    return (
      <div className="blog-info">
        <h1 className="blog-details-title">{title}</h1>

        <div className="author-details">
          <img className="author-img" src={avatarUrl} alt={author} />
          <p className="details-author-name">{author}</p>
        </div>

        <img className="blog-image" src={imageUrl} alt={title} />
        <p className="blog-content">{content}</p>
      </div>
    )
  }

  render() {
    const {isLoading} = this.state

    return (
      <div className="blog-container">
        {isLoading ? (
          <div testid="loader">
            <Loader type="TailSpin" color="#00bfff" height={50} width={50} />
          </div>
        ) : (
          this.renderBlogItemDetails()
        )}
      </div>
    )
  }
}

export default BlogItemDetails

coding pratice-26:
-----------------------------------------------------

Debugging IPL Dashboard

https://github.com/ManirathnamKuruma/ReactJS-DebuggingIPLDashboard

//src/App.js

// FIX1: To use Switch component, it should be imported
import {Route, Switch} from 'react-router-dom'

import Home from './components/Home'
import NotFound from './components/NotFound'
import TeamMatches from './components/TeamMatches'

import './App.css'

const App = () => (
  // FIX2: Routes should be wrapped with Switch component from react-router-dom
  <Switch>
    {/* FIX3: "exact" keyword should be added */}
    <Route exact path="/" component={Home} />
    {/* FIX4: The Route component should be given the prop "component" */}
    {/* FIX5:  When mentioning path parameters for a route we need to use ":" before the variable */}
    <Route path="/team-matches/:id" component={TeamMatches} />
    <Route component={NotFound} />
  </Switch>
)

export default App

//src/components/Home/index.js 

import {Component} from 'react'
import Loader from 'react-loader-spinner'

import TeamCard from '../TeamCard'

import './index.css'

const teamsApiUrl = 'https://apis.ccbp.in/ipl'

class Home extends Component {
  state = {
    isLoading: true,
    teamsData: [],
  }

  componentDidMount() {
    this.getTeams()
  }

  getTeams = async () => {
    const response = await fetch(teamsApiUrl)
    const fetchedData = await response.json()
    const formattedData = fetchedData.teams.map(team => ({
      name: team.name,
      id: team.id,
      teamImageURL: team.team_image_url,
    }))

    this.setState({
      teamsData: formattedData,
      isLoading: false,
    })
  }

  renderTeamsList = () => {
    const {teamsData} = this.state

    return (
      <ul className="teams-list">
        {/* FIX6: The list of team cards should be rendered using Array.map() method */}
        {teamsData.map(team => (
          <TeamCard teamDetails={team} key={team.id} />
        ))}
      </ul>
    )
  }

  renderLoader = () => (
    // FIX7: For the purpose of testing here testid attribute should be added with the value "loader"
    <div testid="loader" className="loader-container">
      <Loader type="Oval" color="#ffffff" height={50} />
    </div>
  )

  render() {
    const {isLoading} = this.state

    return (
      <div className="home-route-container">
        <div className="teams-list-container">
          <div className="ipl-dashboard-heading-container">
            <img
              src="https://assets.ccbp.in/frontend/react-js/ipl-logo-img.png"
              alt="ipl logo"
              className="ipl-logo"
            />
            <h1 className="ipl-dashboard-heading">IPL Dashboard</h1>
          </div>
          {isLoading ? this.renderLoader() : this.renderTeamsList()}
        </div>
      </div>
    )
  }
}

export default Home

//src/components/TeamCard/index.js

// FIX8: To use Link component, it should be imported
import {Link} from 'react-router-dom'

import './index.css'

const TeamCard = props => {
  const {teamDetails} = props
  const {name, id, teamImageURL} = teamDetails

  return (
    // FIX9: When clicked on TeamCard, page should be navigated to the URL '/team-matches/${id}'
    // FIX10: "exact" and "path" props are used in Route component to match routes
    // FIX11: "to" is the prop used to give the URL for navigation to Link component
    <li className="team-item">
      <Link to={`/team-matches/${id}`} className="link">
        <img src={teamImageURL} alt={name} className="team-logo" />
        <p className="team-name">{name}</p>
      </Link>
    </li>
  )
}

export default TeamCard

//src/components/TeamMatches/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'

import LatestMatch from '../LatestMatch'
import MatchCard from '../MatchCard'

import './index.css'

const teamMatchesApiUrl = 'https://apis.ccbp.in/ipl/'

class TeamMatches extends Component {
  state = {
    isLoading: true,
    teamMatchesData: {},
  }

  componentDidMount() {
    // FIX12: The method to get data should be called to get data from API
    this.getTeamMatches()
  }

  getFormattedData = data => ({
    umpires: data.umpires,
    result: data.result,
    manOfTheMatch: data.man_of_the_match,
    id: data.id,
    date: data.date,
    venue: data.venue,
    competingTeam: data.competing_team,
    competingTeamLogo: data.competing_team_logo,
    firstInnings: data.first_innings,
    secondInnings: data.second_innings,
    matchStatus: data.match_status,
  })

  getTeamMatches = async () => {
    const {match} = this.props
    const {params} = match
    const {id} = params

    const response = await fetch(`${teamMatchesApiUrl}${id}`)
    const fetchedData = await response.json()
    const formattedData = {
      teamBannerURL: fetchedData.team_banner_url,
      latestMatch: this.getFormattedData(fetchedData.latest_match_details),
      recentMatches: fetchedData.recent_matches.map(eachMatch =>
        this.getFormattedData(eachMatch),
      ),
    }
    // FIX13: The state value of isLoading should be set to false to display the response
    this.setState({teamMatchesData: formattedData, isLoading: false})
  }

  renderRecentMatchesList = () => {
    const {teamMatchesData} = this.state
    const {recentMatches} = teamMatchesData

    return (
      <ul className="recent-matches-list">
        {recentMatches.map(recentMatch => (
          <MatchCard matchDetails={recentMatch} key={recentMatch.id} />
        ))}
      </ul>
    )
  }

  renderTeamMatches = () => {
    const {teamMatchesData} = this.state
    const {teamBannerURL, latestMatch} = teamMatchesData

    return (
      <div className="responsive-container">
        <img src={teamBannerURL} alt="team banner" className="team-banner" />
        <LatestMatch latestMatchData={latestMatch} />
        {this.renderRecentMatchesList()}
      </div>
    )
  }

  renderLoader = () => (
    <div testid="loader" className="loader-container">
      <Loader type="Oval" color="#ffffff" height={50} />
    </div>
  )

  getRouteClassName = () => {
    const {match} = this.props
    const {params} = match
    const {id} = params

    switch (id) {
      case 'RCB':
        return 'rcb'
      case 'KKR':
        return 'kkr'
      case 'KXP':
        return 'kxp'
      case 'CSK':
        return 'csk'
      case 'RR':
        return 'rr'
      case 'MI':
        return 'mi'
      case 'SH':
        return 'srh'
      case 'DC':
        return 'dc'
      default:
        return ''
    }
  }

  render() {
    const {isLoading} = this.state
    const className = `team-matches-container ${this.getRouteClassName()}`

    return (
      <div className={className}>
        {isLoading ? this.renderLoader() : this.renderTeamMatches()}
      </div>
    )
  }
}

export default TeamMatches

Authentication & Authorization | Cheat Sheet:
----------------------------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-AuthenticationAuthorizationPart1

Concepts in Focus:

Client-Server Communication
	Authentication
	Authorization
	
Authentication Flow

Route Parameters
	History
	
E-Commerce Application

1. Client-Server Communication

1.1 Authentication
Authentication is the process of verifying a user's identity.

1.2 Authorization
Authorization is the process of verifying whether the user is authenticated and permitted to perform some actions like accessing resources, etc.

Example:

After successful authentication, employees are only allowed to access certain resources based on their roles.

Admin can Read, Create, Delete, and Update the Resources
User can only Read and Create the Resources

3. Route Parameters
When a component is rendered by the Route, some additional props are passed.

They are:

match
history
location

3.1 History
The history object has some methods to control the navigation in the browser, and it also maintains the history of the routes we navigated.

It has the following methods to control the navigation in the browser:

push()
replace()
go()
goBack()
goForward(), etc.

The history.push() and history.replace() methods are used to navigate to other routes programmatically.

3.1.1 history.push()
With the history.push() method, the user can go forward and backwards in the browser, and the URL will change.

Syntax:

history.push("PATH");

3.1.2 history.replace()
The history.replace() method replaces the current URL with new one. The user can't go backwards to the previous URL.

Syntax:

history.replace("PATH");

4. E-Commerce Application

Make an Authentication Request to Login API

Handle Login API Response
	On Login Success
	On Login Failure

Store the JWT Token

Authenticated Credentials:

Username: henry
password: henry_the_developer

Username: david
password: the_miller@23

Username: robert
password: WilsonRobert45

Username: mosh
password: DevMosh22

Username: rahul
password: rahul@2021

File: src/App.js

import {BrowserRouter, Route, Switch} from 'react-router-dom'

import LoginForm from './components/LoginForm'
import Home from './components/Home'
import Products from './components/Products'
import Cart from './components/Cart'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Switch>
      <Route exact path="/login" component={LoginForm} />
      <Route exact path="/" component={Home} />
      <Route exact path="/products" component={Products} />
      <Route exact path="/cart" component={Cart} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

File: src/components/LoginForm/index.js

import {Component} from 'react'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
  }

  onSubmitSuccess = () => {
    const {history} = this.props
    history.replace('/')
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    if (response.ok === true) {
      this.onSubmitSuccess()
    }
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
        />
      </>
    )
  }

  render() {
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
        </form>
      </div>
    )
  }
}

export default LoginForm

When the history.push() is triggered, the path will change. The switch inside App.js will trigger again, and the corresponding component will render.

Note
If the Response status code is 2XX, then response.ok will be true else it is false.
Whenever the route changes, the switch in the App.js will trigger again, and the corresponding component will render.

File: src/components/Home/index.js

import Header from '../Header'
import './index.css'

const Home = () => (
  <>
    <Header />
    <div className="home-container">
      <div className="home-content">
        <h1 className="home-heading">Clothes That Get YOU Noticed</h1>
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
          alt="dresses to be noticed"
          className="home-mobile-img"
        />
        <p className="home-description">
          Fashion is part of the daily air and it does not quite help that it
          changes all the time. Clothes have always been a marker of the era and
          we are in a revolution. Your fashion makes you been seen and heard
          that way you are. So, celebrate the seasons new and exciting fashion
          in your own way.
        </p>
        <button type="button" className="shop-now-button">
          Shop Now
        </button>
      </div>
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
        alt="dresses to be noticed"
        className="home-desktop-img"
      />
    </div>
  </>
)

export default Home

File: src/components/Cart/index.js

import Header from '../Header'
import './index.css'

const Cart = () => (
  <>
    <Header />
    <div className="cart-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-img.png"
        alt="cart"
        className="cart-img"
      />
    </div>
  </>
)

export default Cart

File: src/components/Header/index.js

import {Link} from 'react-router-dom'
import './index.css'

const Header = () => (
  <nav className="nav-header">
    <div className="nav-content">
      <img
        className="website-logo"
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
        alt="website logo"
      />
      <ul className="nav-menu">
        <Link to="/" className="nav-link">
          <li>Home</li>
        </Link>
        <Link to="/products" className="nav-link">
          <li>Products</li>
        </Link>
        <Link to="/cart" className="nav-link">
          <li>Cart</li>
        </Link>
      </ul>
      <button type="button" className="logout-desktop-btn">
        Logout
      </button>
      <button type="button" className="logout-mobile-btn">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
          alt="logout icon"
          className="logout-icon"
        />
      </button>
    </div>
  </nav>
)
export default Header

File: src/components/Products/index.js

import Header from '../Header'

import './index.css'

const Products = () => (
  <>
    <Header />
    <div className="products-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-img.png"
        alt="products"
        className="products-img"
      />
    </div>
  </>
)

export default Products

File: src/components/NotFound/index.js

import "./index.css";

const NotFound = () => (
  <div className="not-found-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/not-found-blog-img.png"
      alt="not-found"
      className="not-found-img"
    />
  </div>
);

export default NotFound;

coding pratice-27:
------------------------------------------------------

Nxt Trendz Authentication:
-----------------------------------

https://github.com/ManirathnamKuruma/ReactJS-NxtTrendzAuthentication

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

When invalid credentials are provided in the login form and Login button is clicked, then the respective error message from the response should be displayed
When the username and password are provided correctly and Login button is clicked, then the page should navigate to Home Route

2.API Requests & Responses

loginApiUrl

API: https://apis.ccbp.in/login
Method: POST
Description:
Returns a response based on the credentials provided

Sample Success Response

{
  "jwt_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6InJhaHVsIiwicm9sZSI6IlBSSU1FX1VTRVIiLCJpYXQiOjE2MTk2Mjg2MTN9.nZDlFsnSWArLKKeF0QbmdVfLgzUbx1BGJsqa2kc_21Y"
}

Sample Failure Response

{
  "status_code": 404,
  "error_msg": "Username is not found"
}

3.Implementation Files

Use these files to complete the implementation:

src/App.js
src/components/LoginForm/index.js
src/components/LoginForm/index.css
src/components/Home/index.js
src/components/Home/index.css
src/components/Header/index.js
src/components/Header/index.css

4.Important Note
Click to view

The following instructions are required for the tests to pass

Home route should consist of / in the URL path
Login route should consist of /login in the URL path
No need to use the BrowserRouter in App.js as we have already included in index.js

User credentials

 username: rahul
 password: rahul@2021
 
5.Quick Tips
Click to view

You can use the box-shadow CSS property to apply the box-shadow effect to containers

box-shadow: 0px 4px 16px 0px #bfbfbf;

You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

cursor: pointer;

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

//src/App.js

import {Route, Switch} from 'react-router-dom'

import LoginForm from './components/LoginForm'
import Home from './components/Home'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <Switch>
    <Route exact path="/login" component={LoginForm} />
    <Route exact path="/" component={Home} />
    <Route component={NotFound} />
  </Switch>
)

export default App

//src/components/Home/index.js

import Header from '../Header'

import './index.css'

const Home = () => (
  <>
    <Header />
    <div className="home-container">
      <div className="home-content">
        <h1 className="home-heading">Clothes That Get YOU Noticed</h1>
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
          alt="clothes that get you noticed"
          className="home-mobile-img"
        />
        <p className="home-description">
          Fashion is part of the daily air and it does not quite help that it
          changes all the time. Clothes have always been a marker of the era and
          we are in a revolution. Your fashion makes you been seen and heard
          that way you are. So, celebrate the seasons new and exciting fashion
          in your own way.
        </p>
        <button type="button" className="shop-now-button">
          Shop Now
        </button>
      </div>
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
        alt="clothes that get you noticed"
        className="home-desktop-img"
      />
    </div>
  </>
)

export default Home

//src/components/Header/index.js

import './index.css'

const Header = () => (
  <nav className="nav-header">
    <div className="nav-content">
      <div className="nav-bar-mobile-logo-container">
        <img
          className="website-logo"
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          alt="website logo"
        />

        <button type="button" className="nav-mobile-btn">
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
            alt="nav logout"
            className="nav-bar-img"
          />
        </button>
      </div>

      <div className="nav-content nav-bar-large-container">
        <img
          className="website-logo"
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          alt="website logo"
        />
        <ul className="nav-menu">
          <li className="nav-menu-item">Home</li>
          <li className="nav-menu-item">Products</li>
          <li className="nav-menu-item">Cart</li>
        </ul>
        <button type="button" className="logout-desktop-btn">
          Logout
        </button>
      </div>
    </div>
    <div className="nav-menu-mobile">
      <ul className="nav-menu-list-mobile">
        <li className="nav-menu-item-mobile">
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
            alt="nav home"
            className="nav-bar-img"
          />
        </li>

        <li className="nav-menu-item-mobile">
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
            alt="nav products"
            className="nav-bar-img"
          />
        </li>

        <li className="nav-menu-item-mobile">
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
            alt="nav cart"
            className="nav-bar-img"
          />
        </li>
      </ul>
    </div>
  </nav>
)
export default Header

//src/components/LoginForm/index.js

import {Component} from 'react'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = () => {
    const {history} = this.props

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    if (response.ok === true) {
      this.onSubmitSuccess()
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state

    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-field"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state

    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-field"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-img"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-img"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-img"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">*{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

Registration Form:
---------------------------

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

Display an error message with the text Required for an empty field on blur

When the Submit button is clicked, display an error message with the text Required,
	if only the first name is provided
	if only the last name is provided
	if both first name and last name are not provided
	
Display the Registration Success View on successful submit

When Submit Another Response button is clicked, then the form should be displayed

2.Implementation Files

Use these files to complete the implementation:

src/components/RegistrationForm/index.js
src/components/RegistrationForm/index.css

3.Quick Tips
Click to view

The blur event happens when an HTML element has lost focus

<input onBlur={eventHandler} />

You can use the box-shadow CSS property to apply the box-shadow effect to containers

box-shadow: 0px 4px 16px 0px #bfbfbf;

You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

cursor: pointer;

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

//src/components/RegistrationForm/index.js

// Write your JS code here
import {Component} from 'react'
import './index.css'

class RegistrationForm extends Component {
  state = {
    firstName: '',
    lastName: '',
    showFirstNameError: false,
    showLastNameError: false,
    isFormSubmitted: false,
  }

  validateFirstName = () => {
    const {firstName} = this.state

    return firstName !== ''
  }

  validateLastName = () => {
    const {lastName} = this.state

    return lastName !== ''
  }

  onBlurFirstName = () => {
    const isValidFirstName = this.validateFirstName()

    this.setState({showFirstNameError: !isValidFirstName})
  }

  onBlurLastName = () => {
    const isValidLastName = this.validateLastName()

    this.setState({showLastNameError: !isValidLastName})
  }

  onChangeFirstName = event => {
    const {target} = event
    const {value} = target

    this.setState({
      firstName: value,
    })
  }

  onChangeLastName = event => {
    const {target} = event
    const {value} = target

    this.setState({
      lastName: value,
    })
  }

  onClickSubmitAnotherResponse = () => {
    this.setState(prevState => ({
      isFormSubmitted: !prevState.isFormSubmitted,
      firstName: '',
      lastName: '',
    }))
  }

  submitForm = event => {
    event.preventDefault()
    const isValidFirstName = this.validateFirstName()
    const isValidLastName = this.validateLastName()

    if (isValidFirstName && isValidLastName) {
      this.setState({isFormSubmitted: true})
    } else {
      this.setState({
        showFirstNameError: !isValidFirstName,
        showLastNameError: !isValidLastName,
        isFormSubmitted: false,
      })
    }
  }

  renderFirstNameField = () => {
    const {firstName, showFirstNameError} = this.state
    const errorHighlight = showFirstNameError ? 'error-field' : ''

    return (
      <>
        <label className="input-label" htmlFor="firstName">
          FIRST NAME
        </label>
        <input
          type="text"
          id="firstName"
          className={`first-name-input-field ${errorHighlight}`}
          value={firstName}
          placeholder="First name"
          onChange={this.onChangeFirstName}
          onBlur={this.onBlurFirstName}
        />
      </>
    )
  }

  renderLastNameField = () => {
    const {lastName, showLastNameError} = this.state
    const errorHighlight = showLastNameError ? 'error-field' : ''

    return (
      <>
        <label className="input-label" htmlFor="lastName">
          LAST NAME
        </label>
        <input
          type="text"
          id="lastName"
          className={`last-name-input-field ${errorHighlight}`}
          value={lastName}
          placeholder="Last name"
          onChange={this.onChangeLastName}
          onBlur={this.onBlurLastName}
        />
      </>
    )
  }

  renderSubmissionReport = () => (
    <>
      <img
        src="https://assets.ccbp.in/frontend/react-js/success-icon-img.png"
        alt="success"
        className="success-image"
      />
      <p>Submitted Successfully</p>
      <button
        type="button"
        className="submit-button"
        onClick={this.onClickSubmitAnotherResponse}
      >
        Submit Another Response
      </button>
    </>
  )

  renderRegistrationForm = () => {
    const {showFirstNameError, showLastNameError} = this.state

    return (
      <form className="form-container" onSubmit={this.submitForm}>
        <div className="input-container">{this.renderFirstNameField()}</div>
        {showFirstNameError && <p className="error-message">Required</p>}
        <div className="input-container">{this.renderLastNameField()}</div>
        {showLastNameError && <p className="error-message">Required</p>}
        <button type="submit" className="submit-button">
          Submit
        </button>
      </form>
    )
  }

  render() {
    const {isFormSubmitted} = this.state

    return (
      <div className="registration-form-container">
        <h1 className="form-title">Registration</h1>
        <div className="container">
          {isFormSubmitted
            ? this.renderSubmissionReport()
            : this.renderRegistrationForm()}
        </div>
      </div>
    )
  }
}

export default RegistrationForm

//src/components/RegistrationForm/index.css

/* Write your CSS code here */
.registration-form-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

@media screen and (max-width: 767px) {
  .registration-form-container {
    flex-direction: column;
    justify-content: start;
    padding-top: 50px;
  }
}

.container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  max-width: 350px;
  padding: 20px;
  border-radius: 16px;
  min-height: 310px;
}
@media screen and (min-width: 768px) {
  .container {
    max-width: 450px;
    flex-shrink: 0;
    box-shadow: 0px 4px 16px rgba(126, 133, 142, 0.16);
    padding: 48px 64px 48px 64px;
  }
}
.form-title {
  font-size: 48px;
  color: #ea580c;
  font-weight: 500;
}

@media screen and (max-width: 767px) {
  .form-title {
    font-size: 36px;
  }
}

.form-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
}

.input-container {
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  width: 100%;
}

.input-label {
  margin-bottom: 0px;
  font-family: 'Roboto';
  font-weight: bold;
  font-size: 12px;
  line-height: 16px;
  color: #475569;
}

.first-name-input-field {
  font-size: 16px;
  line-height: 16px;
  font-weight: 500;
  border: 1px solid #cbd2d9;
  color: #9aa5b1;
  border-radius: 4px;
  margin-top: 5px;
  padding: 8px 16px 8px 16px;
  outline: none;
}

.last-name-input-field {
  font-size: 16px;
  line-height: 16px;
  font-weight: 500;
  border: 1px solid #cbd2d9;
  color: #9aa5b1;
  border-radius: 4px;
  margin-top: 5px;
  padding: 8px 16px 8px 16px;
  outline: none;
}

.submit-button {
  font-family: 'Roboto';
  font-size: 12px;
  color: #ffffff;
  padding: 8px 16px;
  margin-top: 20px;
  margin-bottom: 2px;
  background-color: #ea580c;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  outline: none;
}

@media screen and (max-width: 768px) {
  .submit-button {
    width: 100%;
  }
}
.success-image {
  width: 72px;
}

.error-message {
  align-self: start;
  font-size: 12px;
  margin-top: 3px;
  margin-bottom: 0px;
  font-family: 'Roboto';
  font-size: 12px;
  line-height: 16px;
  color: #ff0b37;
}

.error-field {
  border: 1px solid #ff0b37;
  background-color: #fef2f4;
}

Authentication & Authorization | Part 2 | Cheat Sheet:
-------------------------------------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-AuthenticationAuthorizationPart2

Concepts in Focus:

JWT Token

Storage Mechanisms

Cookies
	Why Cookies?
	Cookies vs Local Storage
	Third Party Package js-cookie
	
Redirect Component

withRouter

E-Commerce Application

1. JWT Token
JSON Web Token is a standard used to create Access Tokens. These access tokens are also called JWT Tokens.

The client uses these access tokens on every subsequent request to communicate with the Server.

Note
While making HTTP Request, we have to send an access token in the HTTP Headers with the key Authorization.

Example:

Authorization: Bearer jwt_token

1.1 Storing JWT Token in State
When we store the JWT Token in the state,

On page refresh, the JWT token won't be available
It is difficult to pass state information to every component

2. Storage Mechanisms

Client-Side Data Storage
	Storing Data on the Client
	
Server-Side Data Storage
	Storing Data on the Server using some kind of Database
	
Different types of Client-Side data storage mechanisms are:

Local Storage
Cookies
Session Storage
IndexedDB, etc.

3. Cookies
A cookie is a piece of data that is stored on the user's computer by the web browser.

A cookie is made up of:

Name & Value
Expires − The date the cookie will expire. If this is blank, the cookie will expire when the visitor quits the browser.
Domain − The domain name of your site.
Path − The path to the directory or web page that set the cookie. This may be blank if you want to retrieve the cookie from any directory or page.
Secure − If this field contains the word "secure", then the cookie may only be retrieved with a secure server. If this field is blank, no such restriction exists, etc.

3.1 Why Cookies?
With cookies, we can set the expiry duration.

Examples:

Banking Applications - Cookies get expired in minutes
Facebook - Cookies get expired in months or years

3.2 Cookies vs Local Storage
Cookies													Local Storage
We can set an expiration for Cookies		Local storage data never expires
Cookies can store up to 4KB of data			Local Storage can store up to 5 to 10 MB of data

3.3 Third Party Package - js-cookie
JavaScript can read, create, modify, and delete the cookies.

NPM contains a js-cookie, a third-party package to manipulate cookies easily.

Installation Command:

npm install js-cookie --save

js-cookie methods are:

Cookies.set()- It is used to set the cookie
Cookies.get()- It is used to get the cookie
Cookies.remove()- It is used to remove the cookie

3.3.1 Cookies.set()

Syntax:

Cookies.set('CookieName', 'CookieValue', {expires: DAYS});

Example:

Cookies.set('ACCESS_TOKEN', 'Us1L90PXl...', {expires: 1});

3.3.2 Cookies.get()
It returns undefined if the cookie expires or does not exist.

Syntax:

Cookies.get('CookieName');

Example:

Cookies.get('ACCESS_TOKEN');

3.3.3 Cookies.remove()
Syntax:

Cookies.remove('CookieName');

Example:

Cookies.remove('ACCESS_TOKEN');

4. Redirect Component
The react-router-dom provides the Redirect component. It can be used whenever we want to redirect to another path.

Syntax:

<Redirect to="PATH" />

Example:

<Redirect to="/login" />

4.1 Redirect Component vs history Methods
Use the Redirect Component when you have to stop displaying UI and navigate to a route. Ex: Inside Class Component - render()
In all other cases, use history.push() or history.replace() syntax Ex: onSubmit, onClick event callback functions

Note
The Redirect component uses the history push and replace methods behinds the scene.

5. withRouter
The history prop will be available for only components which are directly given for Route.

To provide history prop to other components, we can wrap it with the withRouter function while exporting it.

Example:

import { withRouter} from 'react-router-dom'
...
export default withRouter(ComponentName)

6. E-Commerce Application:

Make an Authentication Request to Login API
Handle Login API Response
	On Login Success
	On Login Failure
Store the JWT Token

File: src/App.js:

import {BrowserRouter, Route, Switch} from 'react-router-dom'

import LoginForm from './components/LoginForm'
import Home from './components/Home'
import Products from './components/Products'
import Cart from './components/Cart'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Switch>
      <Route exact path="/login" component={LoginForm} />
      <Route exact path="/" component={Home} />
      <Route exact path="/products" component={Products} />
      <Route exact path="/cart" component={Cart} />
      <Route component={NotFound} />
    </Switch>
  </BrowserRouter>
)

export default App

File: src/components/Cart/index.js

import Header from '../Header'
import './index.css'

const Cart = () => (
  <>
    <Header />
    <div className="cart-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-img.png"
        alt="cart"
        className="cart-img"
      />
    </div>
  </>
)

export default Cart

File: src/components/Header/index.js

import {Link, withRouter} from 'react-router-dom'

import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const {history} = props
  const onClickLogout = () => {
    Cookies.remove('jwt_token')
    history.replace('/login')
  }
  return (
    <nav className="nav-header">
      <div className="nav-content">
        <img
          className="website-logo"
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          alt="website logo"
        />
        <ul className="nav-menu">
          <Link to="/" className="nav-link">
            <li>Home</li>
          </Link>
          <Link to="/products" className="nav-link">
            <li>Products</li>
          </Link>
          <Link to="/cart" className="nav-link">
            <li>Cart</li>
          </Link>
        </ul>
        <button
          type="button"
          className="logout-desktop-btn"
          onClick={onClickLogout}
        >
          Logout
        </button>
        <button
          type="button"
          className="logout-mobile-btn"
          onClick={onClickLogout}
        >
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
            alt="logout icon"
            className="logout-icon"
          />
        </button>
      </div>
    </nav>
  )
}
export default withRouter(Header)

File: src/components/Home/index.js

import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'
import Header from '../Header'

import './index.css'

const Home = () => {
  const jwtToken = Cookies.get('jwt_token')
  if (jwtToken === undefined) {
    return <Redirect to="/login" />
  }

  return (
    <>
      <Header />
      <div className="home-container">
        <div className="home-content">
          <h1 className="home-heading">Clothes That Get YOU Noticed</h1>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
            alt="dresses to be noticed"
            className="home-mobile-img"
          />
          <p className="home-description">
            Fashion is part of the daily air and it does not quite help that it
            changes all the time. Clothes have always been a marker of the era
            and we are in a revolution. Your fashion makes you been seen and
            heard that way you are. So, celebrate the seasons new and exciting
            fashion in your own way.
          </p>
          <button type="button" className="shop-now-button">
            Shop Now
          </button>
        </div>
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
          alt="dresses to be noticed"
          className="home-desktop-img"
        />
      </div>
    </>
  )
}

export default Home

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

    Cookies.set('jwt_token', jwtToken, {expires: 30})
    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">*{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

File: src/components/NotFound/index.js

import './index.css'

const NotFound = () => (
  <div className="not-found-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/not-found-blog-img.png"
      alt="not-found"
      className="not-found-img"
    />
  </div>
)

export default NotFound

File: src/components/Products/index.js

import Header from '../Header'

import './index.css'

const Products = () => (
  <>
    <Header />
    <div className="products-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-img.png"
        alt="products"
        className="products-img"
      />
    </div>
  </>
)

export default Products

coding pratice-28:
---------------------------------------------------------------------------------

Nxt Trendz Authentication 2:
--------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-NxtTrendzAuthentication2-

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

When an unauthenticated user tries to access the Home Route, Products Route or Cart Route, then the page should be redirected to the Login Route
When an authenticated user tries to access the Home Route, Products Route or Cart Route, then the page should be navigated to the respective route
When an authenticated user tries to access the Login Route, then the page should be redirected to the Home Route
When the Logout button is clicked, then the page should be navigated to the Login Route

2.API Requests & Responses

loginApiUrl

API: https://apis.ccbp.in/login
Method: POST
Description:
Returns a response based on the credentials provided

Sample Success Response

{
  "jwt_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6InJhaHVsIiwicm9sZSI6IlBSSU1FX1VTRVIiLCJpYXQiOjE2MTk2Mjg2MTN9.nZDlFsnSWArLKKeF0QbmdVfLgzUbx1BGJsqa2kc_21Y"
}

Sample Failure Response

{
  "status_code": 404,
  "error_msg": "Username is not found"
}

3.Implementation Files

Use these files to complete the implementation:

src/App.js
src/components/LoginForm/index.js
src/components/Header/index.js
src/components/Header/index.css
src/components/Products/index.js
src/components/Products/index.css
src/components/Cart/index.js
src/components/Cart/index.css

4.Quick Tips
Click to view

You can use the box-shadow CSS property to apply the box-shadow effect to containers

box-shadow: 0px 4px 16px 0px #bfbfbf;

You can use the cursor CSS property to specify the mouse cursor to be displayed when pointing over an element

cursor: pointer;

You can use the below outline CSS property for buttons and input elements to remove the highlighting when the elements are clicked

outline: none;

5.Important Note
Click to view

The following instructions are required for the tests to pass

Home route should consist of / in the URL path
Login route should consist of /login in the URL path
Products route should consist of /products in the URL path
Cart route should consist of /cart in the URL path
No need to use the BrowserRouter in App.js as we have already included in index.js

User credentials

 username: rahul
 password: rahul@2021
 
//src/App.js

import {Switch, Route} from 'react-router-dom'

import LoginForm from './components/LoginForm'
import Home from './components/Home'
import Products from './components/Products'
import Cart from './components/Cart'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <Switch>
    <Route exact path="/login" component={LoginForm} />
    <Route exact path="/" component={Home} />
    <Route exact path="/products" component={Products} />
    <Route exact path="/cart" component={Cart} />
    <Route component={NotFound} />
  </Switch>
)

export default App

//src/components/LoginForm/index.js

import {Component} from 'react'
import {Redirect} from 'react-router-dom'
import Cookies from 'js-cookie'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })
    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()

    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state

    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-field"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state

    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-field"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')

    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }

    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-img"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-img"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-img"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">*{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

//src/components/Header/index.js

import {Link, withRouter} from 'react-router-dom'

import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const onClickLogout = () => {
    const {history} = props

    Cookies.remove('jwt_token')
    history.replace('/login')
  }

  return (
    <nav className="nav-header">
      <div className="nav-content">
        <div className="nav-bar-mobile-logo-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />

          <button
            type="button"
            className="nav-mobile-btn"
            onClick={onClickLogout}
          >
            <img
              src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
              alt="nav logout"
              className="nav-bar-img"
            />
          </button>
        </div>

        <div className="nav-content nav-bar-large-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />
          <ul className="nav-menu">
            <li className="nav-menu-item">
              <Link to="/" className="nav-link">
                Home
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/products" className="nav-link">
                Products
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/cart" className="nav-link">
                Cart
              </Link>
            </li>
          </ul>
          <button
            type="button"
            className="logout-desktop-btn"
            onClick={onClickLogout}
          >
            Logout
          </button>
        </div>
      </div>
      <div className="nav-menu-mobile">
        <ul className="nav-menu-list-mobile">
          <li className="nav-menu-item-mobile">
            <Link to="/" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
                alt="nav home"
                className="nav-bar-img"
              />
            </Link>
          </li>

          <li className="nav-menu-item-mobile">
            <Link to="/products" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
                alt="nav products"
                className="nav-bar-img"
              />
            </Link>
          </li>
          <li className="nav-menu-item-mobile">
            <Link to="/cart" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
                alt="nav cart"
                className="nav-bar-img"
              />
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default withRouter(Header)

//src/components/Products/index.js

import {Redirect} from 'react-router-dom'
import Cookies from 'js-cookie'

import Header from '../Header'

import './index.css'

const Products = () => {
  const accessToken = Cookies.get('jwt_token')

  if (accessToken === undefined) {
    return <Redirect to="/login" />
  }

  return (
    <>
      <Header />
      <div className="products-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-img.png"
          alt="products"
          className="products-img"
        />
      </div>
    </>
  )
}

export default Products

//src/components/Cart/index.js

import {Redirect} from 'react-router-dom'
import Cookies from 'js-cookie'

import Header from '../Header'

import './index.css'

const Cart = () => {
  const accessToken = Cookies.get('jwt_token')

  if (accessToken === undefined) {
    return <Redirect to="/login" />
  }

  return (
    <>
      <Header />
      <div className="cart-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-img.png"
          alt="cart"
          className="cart-img"
        />
      </div>
    </>
  )
}

export default Cart

Authentication & Authorization | Part 3 | Cheat Sheet:
----------------------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-AuthenticationAuthorizationPart3

Concepts in Focus:

Router Switch

Wrapper Component
	Protected Route
	
E-Commerce Application

1.Router Switch
Switch can have any React Component inside it

Route
User defined Component
Redirect

2. Wrapper Component
Redirection Logic can be reused by separating out into a React Component called Wrapper Component. Each route will be wrapped with it.

2.1 Protected Route
ProtectedRoute is the Wrapper Component which returns Home Route Component.

File: src/components/ProtectedRoute/index.js

import { Route, Redirect } from "react-router-dom";
import Cookies from "js-cookie";

const ProtectedRoute = (props) => {
  const token = Cookies.get("jwt_token");
  if (token === undefined) {
    return <Redirect to="/login" />;
  }
  return <Route {...props} />;
};

export default ProtectedRoute;

3. E-Commerce Application

File: src/App.js

import { BrowserRouter, Route, Switch, Redirect } from "react-router-dom";

import LoginForm from "./components/LoginForm";
import Home from "./components/Home";
import Products from "./components/Products";
import Cart from "./components/Cart";
import NotFound from "./components/NotFound";
import ProtectedRoute from "./components/ProtectedRoute";

import "./App.css";

const App = () => (
  <BrowserRouter>
    <Switch>
      <Route exact path="/login" component={LoginForm} />
      <ProtectedRoute exact path="/" component={Home} />
      <ProtectedRoute exact path="/products" component={Products} />
      <ProtectedRoute exact path="/cart" component={Cart} />
      <Route path="/not-found" component={NotFound} />
      <Redirect to="not-found" />
    </Switch>
  </BrowserRouter>
);

export default App;

File: src/components/AllProductsSection/index.js

import { Component } from "react";
import Cookies from "js-cookie";

import ProductCard from "../ProductCard";
import "./index.css";

class AllProductsSection extends Component {
  state = {
    productsList: [],
  };

  componentDidMount() {
    this.getProducts();
  }

  getProducts = async () => {
    const apiUrl = "https://apis.ccbp.in/products";
    const jwtToken = Cookies.get("jwt_token");
    const options = {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
      method: "GET",
    };
    const response = await fetch(apiUrl, options);
    if (response.ok === true) {
      const fetchedData = await response.json();
      const updatedData = fetchedData.products.map((product) => ({
        title: product.title,
        brand: product.brand,
        price: product.price,
        id: product.id,
        imageUrl: product.image_url,
        rating: product.rating,
      }));
      this.setState({
        productsList: updatedData,
      });
    }
  };

  renderProductsList = () => {
    const { productsList } = this.state;
    return (
      <div>
        <h1 className="products-list-heading">All Products</h1>
        <ul className="products-list">
          {productsList.map((product) => (
            <ProductCard productData={product} key={product.id} />
          ))}
        </ul>
      </div>
    );
  };

  render() {
    return <>{this.renderProductsList()}</>;
  }
}

export default AllProductsSection;

File: src/components/Cart/index.js

import Header from "../Header";
import "./index.css";

const Cart = () => (
  <>
    <Header />
    <div className="cart-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-img.png"
        alt="cart"
        className="cart-img"
      />
    </div>
  </>
);

export default Cart;

File: src/components/Header/index.js

import { Link, withRouter } from "react-router-dom";

import Cookie from "js-cookie";

import "./index.css";

const Header = (props) => {
  const onClickLogout = () => {
    Cookie.remove("jwt_token");
    const { history } = props;
    history.replace("/login");
  };
  return (
    <nav className="nav-header">
      <div className="nav-content">
        <img
          className="website-logo"
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          alt="website logo"
        />
        <ul className="nav-menu">
          <Link to="/" className="nav-link">
            <li>Home</li>
          </Link>
          <Link to="/products" className="nav-link">
            <li>Products</li>
          </Link>
          <Link to="/cart" className="nav-link">
            <li>Cart</li>
          </Link>
        </ul>
        <button
          type="button"
          className="logout-desktop-btn"
          onClick={onClickLogout}
        >
          Logout
        </button>
        <button
          type="button"
          className="logout-mobile-btn"
          onClick={onClickLogout}
        >
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
            alt="logout icon"
            className="logout-icon"
          />
        </button>
      </div>
    </nav>
  );
};
export default withRouter(Header);

File: src/components/Home/index.js

import Header from "../Header";
import "./index.css";

const Home = () => (
  <>
    <Header />
    <div className="home-container">
      <div className="home-content">
        <h1 className="home-heading">Clothes That Get YOU Noticed</h1>
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
          alt="dresses to be noticed"
          className="home-mobile-img"
        />
        <p className="home-description">
          Fashion is part of the daily air and it does not quite help that it
          changes all the time. Clothes have always been a marker of the era and
          we are in a revolution. Your fashion makes you been seen and heard
          that way you are. So, celebrate the seasons new and exciting fashion
          in your own way.
        </p>
        <button type="button" className="shop-now-button">
          Shop Now
        </button>
      </div>
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
        alt="dresses to be noticed"
        className="home-desktop-img"
      />
    </div>
  </>
);

export default Home;

File: src/components/LoginForm/index.js

import { Component } from "react";
import Cookies from "js-cookie";
import { Redirect } from "react-router-dom";

import "./index.css";

class LoginForm extends Component {
  state = {
    username: "",
    password: "",
    showSubmitError: false,
    errorMsg: "",
  };

  onChangeUsername = (event) => {
    this.setState({ username: event.target.value });
  };

  onChangePassword = (event) => {
    this.setState({ password: event.target.value });
  };

  onSubmitSuccess = (jwtTkoken) => {
    const { history } = this.props;

    Cookies.set("jwt_token", jwtTkoken, {
      expires: 30,
      path: "/",
    });
    history.replace("/");
  };

  onSubmitFailure = (errorMsg) => {
    console.log(errorMsg);
    this.setState({ showSubmitError: true, errorMsg });
  };

  submitForm = async (event) => {
    event.preventDefault();
    const { username, password } = this.state;
    const userDetails = { username, password };
    const url = "https://apis.ccbp.in/login";
    const options = {
      method: "POST",
      body: JSON.stringify(userDetails),
    };
    const response = await fetch(url, options);
    const data = await response.json();
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token);
    } else {
      this.onSubmitFailure(data.error_msg);
    }
  };

  renderPasswordField = () => {
    const { password } = this.state;
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
        />
      </>
    );
  };

  renderUsernameField = () => {
    const { username } = this.state;
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
        />
      </>
    );
  };

  render() {
    const { showSubmitError, errorMsg } = this.state;
    const jwtToken = Cookies.get("jwt_token");
    if (jwtToken !== undefined) {
      return <Redirect to="/" />;
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">*{errorMsg}</p>}
        </form>
      </div>
    );
  }
}

export default LoginForm;

File: src/components/NotFound/index.js

import "./index.css";

const NotFound = () => (
  <div className="not-found-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/not-found-blog-img.png"
      alt="not-found"
      className="not-found-img"
    />
  </div>
);

export default NotFound;

File: src/components/ProductCard/index.js

import "./index.css";

const ProductCard = (props) => {
  const { productData } = props;
  const { title, brand, imageUrl, rating, price } = productData;

  return (
    <li className="product-item">
      <img src={imageUrl} alt="product" className="thumbnail" />
      <h1 className="title">{title}</h1>
      <p className="brand">by {brand}</p>
      <div className="product-details">
        <p className="price">Rs {price}/-</p>
        <div className="rating-container">
          <p className="rating">{rating}</p>
          <img
            src="https://assets.ccbp.in/frontend/react-js/star-img.png"
            alt="star"
            className="star"
          />
        </div>
      </div>
    </li>
  );
};
export default ProductCard;

File: src/components/Products/index.js

import AllProductsSection from "../AllProductsSection";

import Header from "../Header";

import "./index.css";

const Products = () => (
  <>
    <Header />
    <div className="product-sections">
      <AllProductsSection />
    </div>
  </>
);

export default Products;

File: src/components/ProtectedRoute/index.js

import { Route, Redirect } from "react-router-dom";
import Cookies from "js-cookie";

const ProtectedRoute = (props) => {
  const token = Cookies.get("jwt_token");
  if (token === undefined) {
    return <Redirect to="/login" />;
  }
  return <Route {...props} />;
};

export default ProtectedRoute;

coding pratice-29:
------------------------------------------------------------------------------

Nxt Trendz Protected Route:
---------------------------------------

In this project, let's build Nxt Trendz app with Protected Route by applying the concepts we have learned till now.

https://github.com/ManirathnamKuruma/ReactJS-NxtTrendzProtectedRoute

1.Implementation Files

Use these files to complete the implementation:

src/App.js
src/components/ProtectedRoute/index.js

//src/App.js

import {Route, Switch} from 'react-router-dom'

import LoginForm from './components/LoginForm'
import Home from './components/Home'
import Products from './components/Products'
import Cart from './components/Cart'
import NotFound from './components/NotFound'
import ProtectedRoute from './components/ProtectedRoute'

import './App.css'

const App = () => (
  <Switch>
    <Route exact path="/login" component={LoginForm} />
    <ProtectedRoute exact path="/" component={Home} />
    <ProtectedRoute exact path="/products" component={Products} />
    <ProtectedRoute exact path="/cart" component={Cart} />
    <Route component={NotFound} />
  </Switch>
)

export default App

//src/components/ProtectedRoute/index.js

// Write your JS code here
import {Route, Redirect} from 'react-router-dom'
import Cookies from 'js-cookie'

const ProtectedRoute = props => {
  const token = Cookies.get('jwt_token')
  if (token === undefined) {
    return <Redirect to="/login" />
  }
  return <Route {...props} />
}

export default ProtectedRoute

Authentication Functionality:
---------------------------------------------

In this project, let's build Authentication Functionality by applying the concepts we have learned till now.

https://github.com/ManirathnamKuruma/ReactJS-AuthenticationFunctionality

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

When an unauthenticated user tries to access the Home Route or About Route, then the page should be navigated to the Login Route
When an authenticated user tries to access the Home Route, or About Route, then the page should be navigated to the respective route
When an authenticated user tries to access the Login Route, then the page should be redirected to Home Route
When the Logout button is clicked then the page should be navigated to the Login Route
When a random path is provided in the URL then the page should be navigated to the Not Found Route

2.Implementation Files

Use these files to complete the implementation:

src/App.js
src/components/Login/index.js
src/components/Login/index.css
src/components/Header/index.js
src/components/Header/index.css
src/components/Home/index.js
src/components/Home/index.css
src/components/About/index.js
src/components/About/index.css
src/components/LogoutButton/index.js
src/components/LogoutButton/index.css
src/components/NotFound/index.js
src/components/NotFound/index.css
src/components/ProtectedRoute/index.js

//src/App.js

import {Route, Switch} from 'react-router-dom'

import Home from './components/Home'
import About from './components/About'
import Login from './components/Login'
import NotFound from './components/NotFound'
import ProtectedRoute from './components/ProtectedRoute'

import './App.css'

const App = () => (
  <Switch>
    <Route exact path="/login" component={Login} />
    <ProtectedRoute exact path="/" component={Home} />
    <ProtectedRoute exact path="/about" component={About} />
    <Route component={NotFound} />
  </Switch>
)

export default App

//src/components/About/index.js

import LogoutButton from '../LogoutButton'
import Header from '../Header'

import './index.css'

const About = () => (
  <>
    <Header />
    <div className="about">
      <h1>About Route</h1>
      <LogoutButton />
    </div>
  </>
)

export default About

//src/components/About/index.css

/* Write your CSS code here */
.about {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-family: 'Roboto';
}

//src/components/Header/index.js

import {Link} from 'react-router-dom'

import './index.css'

const Header = () => (
  <div className="header">
    <ul className="nav-menu">
      <li>
        <Link to="/" className="nav-link">
          Home
        </Link>
      </li>
      <li>
        <Link to="/about" className="nav-link">
          About
        </Link>
      </li>
    </ul>
  </div>
)

export default Header


//src/components/Header/index.css

/* Write your CSS code here */
.header {
  font-family: 'Roboto';
}

.nav-menu {
  display: flex;
  justify-content: center;
  list-style-type: none;
}

.nav-link {
  margin-right: 10px;
}

//src/components/Login/index.js

import Cookies from 'js-cookie'
import {Redirect, withRouter} from 'react-router-dom'

import './index.css'

const Login = props => {
  const jwtToken = Cookies.get('jwt_token')

  const setCookiesAndNavigateToHome = token => {
    const {history} = props

    Cookies.set('jwt_token', token, {
      expires: 30,
    })
    history.replace('/')
  }

  const onClickLogin = async () => {
    const userDetails = {username: 'rahul', password: 'rahul@2021'}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()

    if (response.ok === true) {
      setCookiesAndNavigateToHome(data.jwt_token)
    }
  }

  if (jwtToken !== undefined) {
    return <Redirect to="/" />
  }

  return (
    <div className="login">
      <h1>Please Login</h1>
      <button type="button" onClick={onClickLogin}>
        Login with Sample Creds
      </button>
    </div>
  )
}

export default withRouter(Login)

//src/components/Login/index.css

/* Write your CSS code here */
.login {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-family: 'Roboto';
}

//src/components/LogoutButton/index.js

import {withRouter} from 'react-router-dom'
import Cookies from 'js-cookie'

import './index.css'

const LogoutButton = props => {
  const onClickLogout = () => {
    const {history} = props

    Cookies.remove('jwt_token')
    history.replace('/login')
  }

  return (
    <button type="button" className="logout-button" onClick={onClickLogout}>
      Logout
    </button>
  )
}

export default withRouter(LogoutButton)

//src/components/LogoutButton/index.css

/* Write your CSS code here */
.logout-button {
  font-family: 'Roboto';
}

//src/components/NotFound/index.js

// Write your JS code here
import './index.css'

const NotFound = () => (
  <div className="not-found">
    <h1>Not Found</h1>
  </div>
)

export default NotFound

//src/components/NotFound/index.css

/* Write your CSS code here */
.not-found {
  text-align: center;
  font-family: 'Roboto';
}

//src/components/ProtectedRoute/index.js

// Write your JS code here
import {Route, Redirect} from 'react-router-dom'
import Cookies from 'js-cookie'

const ProtectedRoute = props => {
  const token = Cookies.get('jwt_token')
  if (token === undefined) {
    return <Redirect to="/login" />
  }
  return <Route {...props} />
}

export default ProtectedRoute

//src/components/Home/index.js

import LogoutButton from '../LogoutButton'
import Header from '../Header'

import './index.css'

const Home = () => (
  <>
    <Header />
    <div className="home">
      <h1>Home Route</h1>
      <LogoutButton />
    </div>
  </>
)

export default Home

Authentication & Authorization > Common Mistakes | Part 3 | Cheat Sheet:
------------------------------------------------------------------------------------------------------------------------

Concepts in Focus:

User defined functions should be in the arrow function syntax
Using Redirect Component in Callbacks or Event Listeners
Using history.replace() in render() instead of Redirect Component
Missing withRouter() to have history prop
When request object keys are incorrect
Not Updating the State when required

1. User defined functions should be in arrow function syntax

Mistake

In the below code snippet, we have defined the onChangeUsername function as a function definition instead of an arrow function.

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername(event){
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.error_msg)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

Explanation: 

In Class Component, the function definition will execute in the browser context, so the value of this will be null.
Component Life Cycle Methods(componentDidMount,render,constructor,componentWillUnmount) are extended from React Component. 
As they run in React Context, there is no need to write them in arrow functions.

Solution:

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.error_msg)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

2. Using Redirect Component in Callbacks or Event Listeners

Mistake:

As the Redirect Component returns JSX, it should not be used in event handlers. 

File: src/components/Header/index.js

import {Link, withRouter} from 'react-router-dom'

import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const onClickLogout = () => {
    Cookies.remove('jwt_token')
    return <Redirect to="/login" />
  }

  return (
    <nav className="nav-header">
      <div className="nav-content">
        <div className="nav-bar-mobile-logo-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />

          <button type="button" className="nav-mobile-btn">
            <img
              src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
              alt="nav logout"
              className="nav-bar-image"
              onClick={onClickLogout}
            />
          </button>
        </div>

        <div className="nav-bar-large-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />
          <ul className="nav-menu">
            <li className="nav-menu-item">
              <Link to="/" className="nav-link">
                Home
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/products" className="nav-link">
                Products
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/cart" className="nav-link">
                Cart
              </Link>
            </li>
          </ul>
          <button
            type="button"
            className="logout-desktop-btn"
            onClick={onClickLogout}
          >
            Logout
          </button>
        </div>
      </div>
      <div className="nav-menu-mobile">
        <ul className="nav-menu-list-mobile">
          <li className="nav-menu-item-mobile">
            <Link to="/" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
                alt="nav home"
                className="nav-bar-image"
              />
            </Link>
          </li>

          <li className="nav-menu-item-mobile">
            <Link to="/products" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
                alt="nav products"
                className="nav-bar-image"
              />
            </Link>
          </li>
          <li className="nav-menu-item-mobile">
            <Link to="/cart" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
                alt="nav cart"
                className="nav-bar-image"
              />
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default withRouter(Header)

Explanation:

Redirect Component returns JSX and it is used to render the UI in the specific Route.
To navigate to the specific Routes in event handlers or callbacks used the history object.

Solution:

File: src/components/Header/index.js

import {Link, withRouter} from 'react-router-dom'

import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const onClickLogout = () => {
    const {history} = props
    Cookies.remove('jwt_token')
    history.replace('/login')
  }

  return (
    <nav className="nav-header">
      <div className="nav-content">
        <div className="nav-bar-mobile-logo-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />

          <button type="button" className="nav-mobile-btn">
            <img
              src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
              alt="nav logout"
              className="nav-bar-image"
              onClick={onClickLogout}
            />
          </button>
        </div>

        <div className="nav-bar-large-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />
          <ul className="nav-menu">
            <li className="nav-menu-item">
              <Link to="/" className="nav-link">
                Home
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/products" className="nav-link">
                Products
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/cart" className="nav-link">
                Cart
              </Link>
            </li>
          </ul>
          <button
            type="button"
            className="logout-desktop-btn"
            onClick={onClickLogout}
          >
            Logout
          </button>
        </div>
      </div>
      <div className="nav-menu-mobile">
        <ul className="nav-menu-list-mobile">
          <li className="nav-menu-item-mobile">
            <Link to="/" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
                alt="nav home"
                className="nav-bar-image"
              />
            </Link>
          </li>

          <li className="nav-menu-item-mobile">
            <Link to="/products" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
                alt="nav products"
                className="nav-bar-image"
              />
            </Link>
          </li>
          <li className="nav-menu-item-mobile">
            <Link to="/cart" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
                alt="nav cart"
                className="nav-bar-image"
              />
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default withRouter(Header)

3. Using history.replace() in render() instead of Redirect Component

Mistake:

In the render method, we have used history.replace() instead of Redirect Component and history prop is used in event handlers or callbacks to navigate to specific routes.

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.error_msg)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    const {history} = this.props
    if (jwtToken !== undefined) {
      history.replace('/')
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

Explanation:

In render() JSX is displayed and Redirect Component returns JSX. So it’s a best practice to use Redirect Component while navigating in render().

Solution:

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.error_msg)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
     return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

4. Missing withRouter() to have history prop

Mistake:

The history prop will be available for only Route Components. To use the history prop in other components, it should be 
wrapped with withRouter().

File: src/components/Header/index.js

import {Link} from 'react-router-dom'

import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const onClickLogout = () => {
    const {history} = props
    Cookies.remove('jwt_token')
    history.replace('/login')
  }

  return (
    <nav className="nav-header">
      <div className="nav-content">
        <div className="nav-bar-mobile-logo-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />

          <button type="button" className="nav-mobile-btn">
            <img
              src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
              alt="nav logout"
              className="nav-bar-image"
              onClick={onClickLogout}
            />
          </button>
        </div>

        <div className="nav-bar-large-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />
          <ul className="nav-menu">
            <li className="nav-menu-item">
              <Link to="/" className="nav-link">
                Home
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/products" className="nav-link">
                Products
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/cart" className="nav-link">
                Cart
              </Link>
            </li>
          </ul>
          <button
            type="button"
            className="logout-desktop-btn"
            onClick={onClickLogout}
          >
            Logout
          </button>
        </div>
      </div>
      <div className="nav-menu-mobile">
        <ul className="nav-menu-list-mobile">
          <li className="nav-menu-item-mobile">
            <Link to="/" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
                alt="nav home"
                className="nav-bar-image"
              />
            </Link>
          </li>

          <li className="nav-menu-item-mobile">
            <Link to="/products" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
                alt="nav products"
                className="nav-bar-image"
              />
            </Link>
          </li>
          <li className="nav-menu-item-mobile">
            <Link to="/cart" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
                alt="nav cart"
                className="nav-bar-image"
              />
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default Header

Solution:

File: src/components/Header/index.js

import {Link, withRouter} from 'react-router-dom'

import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const onClickLogout = () => {
    const {history} = props
    Cookies.remove('jwt_token')
    history.replace('/login')
  }

  return (
    <nav className="nav-header">
      <div className="nav-content">
        <div className="nav-bar-mobile-logo-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />

          <button type="button" className="nav-mobile-btn">
            <img
              src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
              alt="nav logout"
              className="nav-bar-image"
              onClick={onClickLogout}
            />
          </button>
        </div>

        <div className="nav-bar-large-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />
          <ul className="nav-menu">
            <li className="nav-menu-item">
              <Link to="/" className="nav-link">
                Home
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/products" className="nav-link">
                Products
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/cart" className="nav-link">
                Cart
              </Link>
            </li>
          </ul>
          <button
            type="button"
            className="logout-desktop-btn"
            onClick={onClickLogout}
          >
            Logout
          </button>
        </div>
      </div>
      <div className="nav-menu-mobile">
        <ul className="nav-menu-list-mobile">
          <li className="nav-menu-item-mobile">
            <Link to="/" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
                alt="nav home"
                className="nav-bar-image"
              />
            </Link>
          </li>

          <li className="nav-menu-item-mobile">
            <Link to="/products" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
                alt="nav products"
                className="nav-bar-image"
              />
            </Link>
          </li>
          <li className="nav-menu-item-mobile">
            <Link to="/cart" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
                alt="nav cart"
                className="nav-bar-image"
              />
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default withRouter(Header)

5. When request object keys are incorrect

Mistake:

For example below in the request object, we need to send username and password but userName is sent instead of the username.

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    userName: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {userName, password} = this.state
    const userDetails = {userName, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.error_msg)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

Solution:

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.error_msg)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

6. Not Updating the State when required
Mistake:

On login failure, the showSubmitError state should be updated to display the error message 

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    userName: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {userName, password} = this.state
    const userDetails = {userName, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.error_msg)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

Solution:

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

 
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })

    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    console.log(data.error_msg)
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-filed"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-filed"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

coding pratice-30:
--------------------------------------------------

Debugging Nxt Trendz Authentication 2:
-----------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-DebuggingNxtTrendzAuthentication2

1.Completion Instructions
Functionality to be fixed

Fix the given code to have the following functionality

When an unauthenticated user tries to access the Home Route, Products Route or Cart Route, then the page should be navigated to the Login Route
When an authenticated user tries to access the Home Route, Products Route or Cart Route, then the page should be navigated to the respective route
When an authenticated user tries to access the Login Route, then the page should be navigated to the Home Route
When the Logout button is clicked, then the page should be navigated to the Login Route
When a random path is provided in the URL, then the page should be navigated to the Not Found Route

2.Quick Tips
Click to view

There are 8 bugs to be fixed to achieve the functionality and the UI that is expected

3.Important Note
Click to view

The following instructions are required for the tests to pass

User credentials

 username: rahul
 password: rahul@2021
 
//src/components/LoginForm/index.js
 
import {Component} from 'react'
import {Redirect} from 'react-router-dom'
import Cookies from 'js-cookie'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })
    // FIX1: history.replace should be used to navigate to the Home Route here
    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()

    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state

    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-field"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state

    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-field"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')

    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }

    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-img"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-img"
          alt="website login"
        />

        {/* FIX2: The attribute that should be used to capture the submit event triggered while submitting the form is "onSubmit" */}
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-img"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          {/* FIX3: The button type should be "submit" */}
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">*{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

//src/components/Header/index.js

import {Link, withRouter} from 'react-router-dom'
import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const onClickLogout = () => {
    // FIX4: To use history we should destruct it from props received
    const {history} = props

    Cookies.remove('jwt_token')
    // FIX5: When logging out history.replace should be used to prevent navigating to authenticated routes when the back button is clicked in browser
    // FIX6: Path to Login Route should be as given below
    history.replace('/login')
  }

  return (
    <nav className="nav-header">
      <div className="nav-content">
        <div className="nav-bar-mobile-logo-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />

          <button
            type="button"
            className="nav-mobile-btn"
            onClick={onClickLogout}
          >
            <img
              src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
              alt="nav logout"
              className="nav-bar-img"
            />
          </button>
        </div>

        <div className="nav-content nav-bar-large-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />
          <ul className="nav-menu">
            <li className="nav-menu-item">
              <Link to="/" className="nav-link">
                Home
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/products" className="nav-link">
                Products
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/cart" className="nav-link">
                Cart
              </Link>
            </li>
          </ul>
          <button
            type="button"
            className="logout-desktop-btn"
            onClick={onClickLogout}
          >
            Logout
          </button>
        </div>
      </div>
      <div className="nav-menu-mobile">
        <ul className="nav-menu-list-mobile">
          <li className="nav-menu-item-mobile">
            <Link to="/" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
                alt="nav home"
                className="nav-bar-img"
              />
            </Link>
          </li>

          <li className="nav-menu-item-mobile">
            <Link to="/products" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
                alt="nav products"
                className="nav-bar-img"
              />
            </Link>
          </li>
          <li className="nav-menu-item-mobile">
            <Link to="/cart" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
                alt="nav cart"
                className="nav-bar-img"
              />
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}

export default withRouter(Header)

//src/components/Home/index.js

import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import Header from '../Header'

import './index.css'

const Home = () => {
  // FIX7: Cookies.get() method should be used to get the accessToken stored in Cookies
  const accessToken = Cookies.get('jwt_token')

  if (accessToken === undefined) {
    return <Redirect to="/login" />
  }

  return (
    <>
      <Header />
      <div className="home-container">
        <div className="home-content">
          <h1 className="home-heading">Clothes That Get YOU Noticed</h1>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
            // FIX8: alt attribute value should be given here as mentioned in the instructions
            alt="clothes that get you noticed"
            className="home-mobile-img"
          />
          <p className="home-description">
            Fashion is part of the daily air and it does not quite help that it
            changes all the time. Clothes have always been a marker of the era
            and we are in a revolution. Your fashion makes you been seen and
            heard that way you are. So, celebrate the seasons new and exciting
            fashion in your own way.
          </p>
          <button type="button" className="shop-now-button">
            Shop Now
          </button>
        </div>
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
          alt="clothes that get you noticed"
          className="home-desktop-img"
        />
      </div>
    </>
  )
}

export default Home

Debugging Nxt Trendz Protected Route:
-------------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-Debugging-NxtTrendzProtectedRoute

1.Completion Instructions
Functionality to be fixed

Fix the given code to have the following functionality

When an unauthenticated user tries to access the Home Route, Products Route or Cart Route, then the page should be navigated to the Login Route using the protected route
When an authenticated user tries to access the Home Route, Products Route or Cart Route, then the page should be navigated to the respective route using the protected route

2.Quick Tips
Click to view

There are 8 bugs to be fixed to achieve the functionality and the UI that is expected

//src/components/ProtectedRoute/index.js

import {Route, Redirect} from 'react-router-dom'
import Cookies from 'js-cookie'

const ProtectedRoute = props => {
  const token = Cookies.get('jwt_token')

  if (token === undefined) {
    return <Redirect to="/login" />
  }

  // FIX1: The spread operator should be used while sending the props
  return <Route {...props} />
}

export default ProtectedRoute

//src/components/LoginForm/index.js

import {Component} from 'react'
import {Redirect} from 'react-router-dom'
// FIX2: Cookies should be imported before using them
import Cookies from 'js-cookie'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

    // FIX3: The jwt_token should be stored in Cookies to authenticate the user
    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
    })
    // FIX4: history.replace() should be used here
    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      // FIX5: The key to send data in the request is "body"
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()

    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state

    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-field"
          value={password}
          onChange={this.onChangePassword}
          placeholder="Password"
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state

    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-field"
          value={username}
          onChange={this.onChangeUsername}
          placeholder="Username"
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')

    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }

    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-img"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-img"
          alt="website login"
        />
        {/* FIX6: onSubmit event spelling */}
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-img"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">*{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

//src/components/Header/index.js

import {Link, withRouter} from 'react-router-dom'
import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const onClickLogout = () => {
    const {history} = props
    // FIX7: The Cookie is set with the key "jwt_token" so it should be removed using the same key
    Cookies.remove('jwt_token')
    history.replace('/login')
  }

  return (
    <nav className="nav-header">
      <div className="nav-content">
        <div className="nav-bar-mobile-logo-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />

          <button
            type="button"
            className="nav-mobile-btn"
            onClick={onClickLogout}
          >
            <img
              src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
              alt="nav logout"
              className="nav-bar-img"
            />
          </button>
        </div>

        <div className="nav-bar-large-container">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />
          <ul className="nav-menu">
            <li className="nav-menu-item">
              <Link to="/" className="nav-link">
                Home
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/products" className="nav-link">
                Products
              </Link>
            </li>

            <li className="nav-menu-item">
              <Link to="/cart" className="nav-link">
                Cart
              </Link>
            </li>
          </ul>
          <button
            type="button"
            className="logout-desktop-btn"
            onClick={onClickLogout}
          >
            Logout
          </button>
        </div>
      </div>
      <div className="nav-menu-mobile">
        <ul className="nav-menu-list-mobile">
          <li className="nav-menu-item-mobile">
            <Link to="/" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
                alt="nav home"
                className="nav-bar-img"
              />
            </Link>
          </li>

          <li className="nav-menu-item-mobile">
            <Link to="/products" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
                alt="nav products"
                className="nav-bar-img"
              />
            </Link>
          </li>
          <li className="nav-menu-item-mobile">
            <Link to="/cart" className="nav-link">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
                alt="nav cart"
                className="nav-bar-img"
              />
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}

// FIX8: Header component should be wrapped with withRouter() to access history
export default withRouter(Header)

Authentication & Authorization 2 > Authentication & Authorization | Part 4:
--------------------------------------------------------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-AuthenticationAuthorizationPart4

Authentication & Authorisation | Part 4 | Cheat Sheet:
---------------------------------------------------------------------------

Concepts in Focus Get Exclusive Prime Deals:

Integrating APIs
	Get Exclusive Prime Deals

API Call Possible Views
	Success View
	Failure View
	Loading View
	
E-Commerce Application

Best Practices
	State Variable-isLoading
	State Variable-apiStatus
	Adding Initial State
	
1. Integrating APIs

1.1 Get Exclusive Prime Deals
Exclusive Prime deals are for Prime Users.
All Products are for both Prime and Non-Prime users.

2. API Call Possible Views

2.1 Success View
When the Prime User is logged in and accessed Prime Deals Section then we should show the Exclusive Prime Deals section.

2.2 Failure View
When the Non-prime User is logged in and accessed Prime Deals Section then we should show the Get Exclusive Deals section.

Reasons for API Call Failure :
	Sending UnAuthorized User credentials
	Not specifying Authorization header
	Using the wrong HTTP method
	
2.3 Loading View
When the Prime or Non-prime User is logged in and accessed Prime Deals Section, we should show the Loading view until data is in progress.

3. E-Commerce Application

File: src/App.js

import {BrowserRouter, Route, Switch, Redirect} from 'react-router-dom'

import LoginForm from './components/LoginForm'
import Home from './components/Home'
import Products from './components/Products'
import Cart from './components/Cart'
import NotFound from './components/NotFound'
import ProtectedRoute from './components/ProtectedRoute'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Switch>
      <Route exact path="/login" component={LoginForm} />
      <ProtectedRoute exact path="/" component={Home} />
      <ProtectedRoute exact path="/products" component={Products} />
      <ProtectedRoute exact path="/cart" component={Cart} />
      <Route path="/not-found" component={NotFound} />
      <Redirect to="not-found" />
    </Switch>
  </BrowserRouter>
)

export default App

File: src/components/AllProductsSection/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'
import Cookies from 'js-cookie'

import ProductCard from '../ProductCard'
import './index.css'

class AllProductsSection extends Component {
  state = {
    productsList: [],
    isLoading: false,
  }

  componentDidMount() {
    this.getProducts()
  }

  getProducts = async () => {
    this.setState({
      isLoading: true,
    })
    const jwtToken = Cookies.get('jwt_token')
    const apiUrl = 'https://apis.ccbp.in/products'
    const options = {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
      method: 'GET',
    }
    const response = await fetch(apiUrl, options)
    if (response.ok) {
      const fetchedData = await response.json()
      const updatedData = fetchedData.products.map(product => ({
        title: product.title,
        brand: product.brand,
        price: product.price,
        id: product.id,
        imageUrl: product.image_url,
        rating: product.rating,
      }))
      this.setState({
        productsList: updatedData,
        isLoading: false,
      })
    }
  }

  renderProductsList = () => {
    const {productsList} = this.state
    return (
      <>
        <h1 className="products-list-heading">All Products</h1>
        <ul className="products-list">
          {productsList.map(product => (
            <ProductCard productData={product} key={product.id} />
          ))}
        </ul>
      </>
    )
  }

  renderLoader = () => (
    <div className="products-loader-container">
      <Loader type="ThreeDots" color="#0b69ff" height="50" width="50" />
    </div>
  )

  render() {
    const {isLoading} = this.state
    return isLoading ? this.renderLoader() : this.renderProductsList()
  }
}

export default AllProductsSection

File: src/components/Cart/index.js

import Header from '../Header'
import './index.css'

const Cart = () => (
  <>
    <Header />
    <div className="cart-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-img.png"
        alt="cart"
        className="cart-img"
      />
    </div>
  </>
)

export default Cart

File: src/components/Header/index.js

import {Link, withRouter} from 'react-router-dom'

import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const onClickLogout = () => {
    Cookies.remove('jwt_token')
    const {history} = props
    history.replace('/login')
  }
  return (
    <nav className="nav-header">
      <div className="nav-content">
        <Link to="/">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />
        </Link>
        <ul className="nav-menu">
          <Link to="/" className="nav-link">
            <li>Home</li>
          </Link>
          <Link to="/products" className="nav-link">
            <li>Products</li>
          </Link>
          <Link to="/cart" className="nav-link">
            <li>Cart</li>
          </Link>
        </ul>
        <button
          type="button"
          className="logout-desktop-btn"
          onClick={onClickLogout}
        >
          Logout
        </button>
        <button
          type="button"
          className="logout-mobile-btn"
          onClick={onClickLogout}
        >
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
            alt="logout icon"
            className="logout-icon"
          />
        </button>
      </div>
      <div className="nav-menu-mobile">
        <ul className="nav-menu-list-mobile">
          <Link to="/">
            <li className="nav-menu-item-mobile">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
                alt="nav home"
                className="nav-bar-image"
              />
            </li>
          </Link>
          <Link to="/products">
            <li className="nav-menu-item-mobile">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
                alt="nav products"
                className="nav-bar-image"
              />
            </li>
          </Link>
          <Link to="/cart">
            <li className="nav-menu-item-mobile">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
                alt="nav cart"
                className="nav-bar-image"
              />
            </li>
          </Link>
        </ul>
      </div>
    </nav>
  )
}
export default withRouter(Header)

File: src/components/Home/index.js

import Cookies from 'js-cookie'
import {Redirect, Link} from 'react-router-dom'

import Header from '../Header'
import './index.css'

const Home = () => {
  const jwtToken = Cookies.get('jwt_token')
  if (jwtToken === undefined) {
    return <Redirect to="/login" />
  }

  return (
    <>
      <Header />
      <div className="home-container">
        <div className="home-content">
          <h1 className="home-heading">Clothes That Get YOU Noticed</h1>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
            alt="clothes to be noticed"
            className="home-mobile-img"
          />
          <p className="home-description">
            Fashion is part of the daily air and it does not quite help that it
            changes all the time. Clothes have always been a marker of the era
            and we are in a revolution. Your fashion makes you been seen and
            heard that way you are. So, celebrate the seasons new and exciting
            fashion in your own way.
          </p>
          <Link to="/products">
            <button type="button" className="shop-now-button">
              Shop Now
            </button>
          </Link>
        </div>
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
          alt="dresses to be noticed"
          className="home-desktop-img"
        />
      </div>
    </>
  )
}

export default Home

File: src/components/LoginForm/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
      path: '/',
    })
    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    console.log(errorMsg)
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-field"
          value={password}
          onChange={this.onChangePassword}
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-field"
          value={username}
          onChange={this.onChangeUsername}
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">*{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

File: src/components/NotFound/index.js

import './index.css'

const NotFound = () => (
  <div className="not-found-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/not-found-blog-img.png"
      alt="not-found"
      className="not-found-img"
    />
  </div>
)

export default NotFound

File: src/components/PrimeDealsSection/index.js

import {Component} from 'react'
import Cookies from 'js-cookie'
import Loader from 'react-loader-spinner'

import ProductCard from '../ProductCard'
import './index.css'

const apiStatusConstants = {
  initial: 'INITIAL',
  success: 'SUCCESS',
  failure: 'FAILURE',
  inProgress: 'IN_PROGRESS',
}

class PrimeDealsSection extends Component {
  state = {
    primeDeals: [],
    apiStatus: apiStatusConstants.initial,
  }

  componentDidMount() {
    this.getPrimeDeals()
  }

  getPrimeDeals = async () => {
    this.setState({
      apiStatus: apiStatusConstants.inProgress,
    })

    const jwtToken = Cookies.get('jwt_token')

    const apiUrl = 'https://apis.ccbp.in/prime-deals'
    const options = {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
      method: 'GET',
    }
    const response = await fetch(apiUrl, options)
    if (response.ok === true) {
      const fetchedData = await response.json()
      const updatedData = fetchedData.prime_deals.map(product => ({
        title: product.title,
        brand: product.brand,
        price: product.price,
        id: product.id,
        imageUrl: product.image_url,
        rating: product.rating,
      }))
      this.setState({
        primeDeals: updatedData,
        apiStatus: apiStatusConstants.success,
      })
    }
    if (response.status === 401) {
      this.setState({
        apiStatus: apiStatusConstants.failure,
      })
    }
  }

  renderPrimeDealsList = () => {
    const {primeDeals} = this.state
    return (
      <div>
        <h1 className="primedeals-list-heading">Exclusive Prime Deals</h1>
        <ul className="products-list">
          {primeDeals.map(product => (
            <ProductCard productData={product} key={product.id} />
          ))}
        </ul>
      </div>
    )
  }

  renderPrimeDealsFailureView = () => (
    <img
      src="https://assets.ccbp.in/frontend/react-js/exclusive-deals-banner-img.png"
      alt="Register Prime"
      className="register-prime-image"
    />
  )

  renderLoadingView = () => (
    <div className="products-loader-container">
      <Loader type="ThreeDots" color="#0b69ff" height="50" width="50" />
    </div>
  )

  render() {
    const {apiStatus} = this.state
    switch (apiStatus) {
      case apiStatusConstants.success:
        return this.renderPrimeDealsList()
      case apiStatusConstants.failure:
        return this.renderPrimeDealsFailureView()
      case apiStatusConstants.inProgress:
        return this.renderLoadingView()
      default:
        return null
    }
  }
}

export default PrimeDealsSection

File: src/components/ProductCard/index.js

import './index.css'

const ProductCard = props => {
  const {productData} = props
  const {title, brand, imageUrl, rating, price} = productData

  return (
    <li className="product-item">
      <img src={imageUrl} alt="product" className="thumbnail" />
      <h1 className="title">{title}</h1>
      <p className="brand">by {brand}</p>
      <div className="product-details">
        <p className="price">Rs {price}/-</p>
        <div className="rating-container">
          <p className="rating">{rating}</p>
          <img
            src="https://assets.ccbp.in/frontend/react-js/star-img.png"
            alt="star"
            className="star"
          />
        </div>
      </div>
    </li>
  )
}
export default ProductCard

File: src/components/Products/index.js

import AllProductsSection from '../AllProductsSection'
import PrimeDealsSection from '../PrimeDealsSection'

import Header from '../Header'

import './index.css'

const Products = () => (
  <>
    <Header />
    <div className="product-sections">
      <PrimeDealsSection />
      <AllProductsSection />
    </div>
  </>
)

export default Products

File: src/components/ProtectedRoute/index.js

import {Redirect, Route} from 'react-router-dom'
import Cookie from 'js-cookie'

const ProtectedRoute = props => {
  const token = Cookie.get('jwt_token')
  if (token === undefined) {
    return <Redirect to="/login" />
  }
  return <Route {...props} />
}

export default ProtectedRoute

4. Best Practices
4.1 State Variable-isLoading
isLoading is used to handle Success View, Loading View only. 

render() {
   const {isLoading} = this.state
   return <>
   { isLoading ? this.renderLoader() : this.renderProductsList() }
   </>
 }
 
4.2 State Variable-apiStatus
apiStatus is used to handle Success, Failure and Loading Views.

switch (apiStatus) {
  case apiStatusConstants.success:
    return this.renderPrimeDealsList()
  ...
  ...
  default:
    return null
}

4.3 Adding Initial State
Instead of adding empty strings in initial state we can add initial in apiStatusConstants.

File: src/components/PrimeDealsSection/index.js

...
const apiStatusConstants = {
  initial: "INITIAL",
  inProgress: "IN_PROGRESS",
  success: "SUCCESS",
  failure: "FAILURE",
};
class PrimeDealsSection extends Component {
  state = {
    primeDeals: [],
    apiStatus: apiStatusConstants.initial,
  }

  renderPrimeDeals = () => {
    const { apiStatus } = this.state;
    switch (apiStatus) {
      case apiStatusConstants.success:
        return this.renderPrimeDealsSuccessView();
      case apiStatusConstants.failure:
        return this.renderPrimeDealsFailureView();
      case apiStatusConstants.inProgress:
        return this.renderLoader();
      default:
        return null;
    }
  };
  
  render() { 
      return <>{this.renderPrimeDeals()}</>
  }
 } 

export default PrimeDealsSection

coding pratice-32:
------------------------------------------------------------------------------------------------------------------------------------

Events
In this project, let's build an Events app by applying the concepts we have learned till now.

https://github.com/ManirathnamKuruma/ReactJS-EventsApp

1.Completion Instructions
Functionality to be added

The app must have the following functionalities

Initially, the page should have the No Active Event View
When the image of an event item with registrationStatus as YET_TO_REGISTER is clicked, then the Yet To Register View should be displayed
When the image of an event item with registrationStatus as REGISTERED is clicked, then the Registered View should be displayed
When the image of an event item with registrationStatus as REGISTRATIONS_CLOSED is clicked, then the Registrations Closed View should be displayed

The Events component is provided with eventsList. It consists of a list of event objects with the following properties in each event object

Key			Data Type
id			String
imageUrl	String
name		String
location	String
registrationStatus	String

2.Implementation Files

Use these files to complete the implementation:

src/components/Events/index.js
src/components/Events/index.css
src/components/EventItem/index.js
src/components/EventItem/index.css
src/components/ActiveEventRegistrationDetails/index.js
src/components/ActiveEventRegistrationDetails/index.css

//src/components/Events/index.js

import {Component} from 'react'

import ActiveEventRegistrationDetails from '../ActiveEventRegistrationDetails'
import EventItem from '../EventItem'

import './index.css'

const eventsList = [
  {
    id: 'f9bb2373-b80e-46b8-8219-f07217b9f3ce',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/event-canada-dance-festival-img.png',
    name: 'Canada Dance Festival',
    location: 'Canada, America',
    registrationStatus: 'YET_TO_REGISTER',
  },
  {
    id: 'c0040497-e9cb-4873-baa9-ef5b994abfff',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/events-kathakali-img.png',
    name: 'Puthanalkkal Kalavela',
    location: 'Karnataka, India',
    registrationStatus: 'REGISTERED',
  },
  {
    id: '0037d5e4-4005-4030-987b-ce41b691b92a',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/events-kuchipudi-img.png',
    name: 'Nithyopahara',
    location: 'Kerala, India',
    registrationStatus: 'REGISTRATIONS_CLOSED',
  },
  {
    id: 'c9ff08cb-610c-4382-9939-78e5e50a72b2',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/events-bharatanatyam-img.png',
    name: 'Shivam',
    location: 'Andhra Pradesh, India',
    registrationStatus: 'YET_TO_REGISTER',
  },
  {
    id: 'd1153723-5b6e-4628-9a1a-ccd8f84f1273',
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/events-kolatam-img.png',
    name: 'Janapada Kolatam',
    location: 'Tamil Nadu, India',
    registrationStatus: 'REGISTERED',
  },
  {
    id: '7d6ec013-d0ae-4d84-b776-14b733a9174f',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/event-colonial-fest-img.png',
    name: 'Colonial Fest',
    location: 'Washington, America',
    registrationStatus: 'REGISTRATIONS_CLOSED',
  },
]

class Events extends Component {
  state = {
    activeEventId: '',
  }

  getActiveEventRegistrationStatus = () => {
    const {activeEventId} = this.state
    const activeEventDetails = eventsList.find(
      event => event.id === activeEventId,
    )
    if (activeEventDetails) {
      return activeEventDetails.registrationStatus
    }
    return ''
  }

  setActiveEventId = id => {
    this.setState({activeEventId: id})
  }

  renderEventsList = () => {
    const {activeEventId} = this.state
    return (
      <ul className="events-list">
        {eventsList.map(eachEvent => (
          <EventItem
            key={eachEvent.id}
            eventDetails={eachEvent}
            setActiveEventId={this.setActiveEventId}
            isActive={eachEvent.id === activeEventId}
          />
        ))}
      </ul>
    )
  }

  render() {
    return (
      <div className="events-container">
        <div className="events-content">
          <h1 className="heading">Events</h1>
          {this.renderEventsList()}
        </div>
        <ActiveEventRegistrationDetails
          activeEventRegistrationStatus={this.getActiveEventRegistrationStatus()}
        />
      </div>
    )
  }
}

export default Events

//src/components/EventItem/index.js

import './index.css'

const EventItem = props => {
  const {eventDetails, setActiveEventId, isActive} = props
  const {imageUrl, name, location, id} = eventDetails
  const eventImageClassName = isActive ? 'event-image active' : 'event-image'

  const onClickEvent = () => {
    setActiveEventId(id)
  }

  return (
    <li className="event-item">
      <button type="button" className="event-button" onClick={onClickEvent}>
        <img src={imageUrl} alt="event" className={eventImageClassName} />
      </button>
      <p className="name">{name}</p>
      <p className="location">{location}</p>
    </li>
  )
}

export default EventItem

//src/components/ActiveEventRegistrationDetails/index.js

import './index.css'

const registrationStatus = {
  yetToRegister: 'YET_TO_REGISTER',
  registered: 'REGISTERED',
  registrationsClosed: 'REGISTRATIONS_CLOSED',
}

const ActiveEventRegistrationDetails = props => {
  const {activeEventRegistrationStatus} = props

  const renderNoActiveEventView = () => (
    <p className="no-active-event-description">
      Click on an event, to view its registration details
    </p>
  )

  const renderRegistrationsClosedView = () => (
    <div className="view-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/events-registrations-closed-img.png"
        alt="registrations closed"
        className="registrations-closed-image"
      />
      <h1 className="registrations-closed-heading">
        Registrations Are Closed Now!
      </h1>
      <p className="registrations-closed-description">
        Stay tuned. We will reopen the registrations soon!
      </p>
    </div>
  )

  const renderRegisteredView = () => (
    <div className="view-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/events-regestered-img.png"
        alt="registered"
        className="registered-img"
      />
      <h1 className="registered-heading">
        You have already registered for the event
      </h1>
    </div>
  )

  const renderYetToRegisterView = () => (
    <div className="view-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/events-register-img.png"
        alt="yet to register"
        className="yet-to-register-image"
      />
      <p className="register-description">
        A live performance brings so much to your relationship with dance.
        Seeing dance live can often make you fall totally in love with this
        beautiful art form.
      </p>
      <button type="button" className="register-here-button">
        Register Here
      </button>
    </div>
  )

  const renderActiveEventRegistrationDetails = () => {
    switch (activeEventRegistrationStatus) {
      case registrationStatus.yetToRegister:
        return renderYetToRegisterView()
      case registrationStatus.registered:
        return renderRegisteredView()
      case registrationStatus.registrationsClosed:
        return renderRegistrationsClosedView()
      default:
        return renderNoActiveEventView()
    }
  }

  return (
    <div className="registration-status-container">
      {renderActiveEventRegistrationDetails()}
    </div>
  )
}

export default ActiveEventRegistrationDetails

//src/App.js

import Events from './components/Events'

import './App.css'

const App = () => <Events />

export default App


Authentication & Authorization 2 > Sorting Products | Cheat Sheet:
------------------------------------------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-SortingProducts

Concepts in Focus:

setState() Callback Function

React Icons
	Installing React Icons
	Searching React Icons
	Importing React Icons
	
Sorting Products

1. setState() - Callback Function
The setState() is asynchronous, it takes an optional callback parameter that can be used to make updates after the state is changed.

Syntax

this.setState({property1: value1,...}, callbackFunction)

2. React Icons
react-icons is a third-party package contains bundle of icons like bootstrap, font awesome, material icons etc..,

Check react-icons website here .

2.1 Installing React Icons
This below command installs all the react-icons library in your React project.

npm install react-icons

2.2 Searching React Icons
Click on the Icon to copy the Icon Name.

2.3 Importing React Icons
The First letters of the icon indicates the category of the Icon.

Each category of Icons have import statements separately, go to the category and copy the import statement.

Example:

import { BsFilterRight } from "react-icons/bs";
import { FaFacebookF } from "react-icons/fa";
import { MdDelete } from "react-icons/md";

const ReactIcon = (props) => {
  return (
    <div>
      <BsFilterRight />
      <FaFacebookF />
      <MdDelete />
    </div>
  );
};

export default ReactIcon;

3. Sorting Products

File: src/components/AllProductsSection

import {Component} from 'react'
import Loader from 'react-loader-spinner'
import Cookies from 'js-cookie'

import ProductCard from '../ProductCard'
import ProductsHeader from '../ProductsHeader'
import './index.css'

const sortbyOptions = [
  {
    optionId: 'PRICE_HIGH',
    displayText: 'Price (High-Low)',
  },
  {
    optionId: 'PRICE_LOW',
    displayText: 'Price (Low-High)',
  },
]

class AllProductsSection extends Component {
  state = {
    productsList: [],
    isLoading: false,
    activeOptionId: sortbyOptions[0].optionId,
  }

  componentDidMount() {
    this.getProducts()
  }

  getProducts = async () => {
    this.setState({
      isLoading: true,
    })
    const jwtToken = Cookies.get('jwt_token')
    const {activeOptionId} = this.state
    const apiUrl = `https://apis.ccbp.in/products?sort_by=${activeOptionId}`
    const options = {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
      method: 'GET',
    }
    const response = await fetch(apiUrl, options)
    if (response.ok) {
      const fetchedData = await response.json()
      const updatedData = fetchedData.products.map(product => ({
        title: product.title,
        brand: product.brand,
        price: product.price,
        id: product.id,
        imageUrl: product.image_url,
        rating: product.rating,
      }))
      this.setState({
        productsList: updatedData,
        isLoading: false,
      })
    }
  }

  updateActiveOptionId = activeOptionId => {
    this.setState({activeOptionId}, this.getProducts)
  }

  renderProductsList = () => {
    const {productsList, activeOptionId} = this.state
    return (
      <>
        <ProductsHeader
          activeOptionId={activeOptionId}
          sortbyOptions={sortbyOptions}
          updateActiveOptionId={this.updateActiveOptionId}
        />
        <ul className="products-list">
          {productsList.map(product => (
            <ProductCard productData={product} key={product.id} />
          ))}
        </ul>
      </>
    )
  }

  renderLoader = () => (
    <div className="products-loader-container">
      <Loader type="ThreeDots" color="#0b69ff" height="50" width="50" />
    </div>
  )

  render() {
    const {isLoading} = this.state
    return isLoading ? this.renderLoader() : this.renderProductsList()
  }
}

export default AllProductsSection

File: src/components/Cart

import Header from '../Header'
import './index.css'

const Cart = () => (
  <>
    <Header />
    <div className="cart-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-img.png"
        alt="cart"
        className="cart-img"
      />
    </div>
  </>
)

export default Cart

File: src/components/Header

import {Link, withRouter} from 'react-router-dom'

import Cookies from 'js-cookie'

import './index.css'

const Header = props => {
  const onClickLogout = () => {
    Cookies.remove('jwt_token')
    const {history} = props
    history.replace('/login')
  }
  return (
    <nav className="nav-header">
      <div className="nav-content">
        <Link to="/">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            alt="website logo"
          />
        </Link>
        <ul className="nav-menu">
          <Link to="/" className="nav-link">
            <li>Home</li>
          </Link>
          <Link to="/products" className="nav-link">
            <li>Products</li>
          </Link>
          <Link to="/cart" className="nav-link">
            <li>Cart</li>
          </Link>
        </ul>
        <button
          type="button"
          className="logout-desktop-btn"
          onClick={onClickLogout}
        >
          Logout
        </button>
        <button
          type="button"
          className="logout-mobile-btn"
          onClick={onClickLogout}
        >
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-log-out-img.png"
            alt="logout icon"
            className="logout-icon"
          />
        </button>
      </div>
      <div className="nav-menu-mobile">
        <ul className="nav-menu-list-mobile">
          <Link to="/">
            <li className="nav-menu-item-mobile">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-icon.png"
                alt="nav home"
                className="nav-bar-image"
              />
            </li>
          </Link>
          <Link to="/products">
            <li className="nav-menu-item-mobile">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-products-icon.png"
                alt="nav products"
                className="nav-bar-image"
              />
            </li>
          </Link>
          <Link to="/cart">
            <li className="nav-menu-item-mobile">
              <img
                src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-cart-icon.png"
                alt="nav cart"
                className="nav-bar-image"
              />
            </li>
          </Link>
        </ul>
      </div>
    </nav>
  )
}
export default withRouter(Header)

File: src/components/Home

import Cookies from 'js-cookie'
import {Redirect, Link} from 'react-router-dom'

import Header from '../Header'
import './index.css'

const Home = () => {
  const jwtToken = Cookies.get('jwt_token')
  if (jwtToken === undefined) {
    return <Redirect to="/login" />
  }

  return (
    <>
      <Header />
      <div className="home-container">
        <div className="home-content">
          <h1 className="home-heading">Clothes That Get YOU Noticed</h1>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
            alt="dresses to be noticed"
            className="home-mobile-img"
          />
          <p className="home-description">
            Fashion is part of the daily air and it does not quite help that it
            changes all the time. Clothes have always been a marker of the era
            and we are in a revolution. Your fashion makes you been seen and
            heard that way you are. So, celebrate the seasons new and exciting
            fashion in your own way.
          </p>

          <Link to="/products">
            <button type="button" className="shop-now-button">
              Shop Now
            </button>
          </Link>
        </div>
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-home-img.png"
          alt="dresses to be noticed"
          className="home-desktop-img"
        />
      </div>
    </>
  )
}

export default Home

File: src/components/LoginForm

import {Component} from 'react'
import Cookies from 'js-cookie'
import {Redirect} from 'react-router-dom'

import './index.css'

class LoginForm extends Component {
  state = {
    username: '',
    password: '',
    showSubmitError: false,
    errorMsg: '',
  }

  onChangeUsername = event => {
    this.setState({username: event.target.value})
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onSubmitSuccess = jwtToken => {
    const {history} = this.props

    Cookies.set('jwt_token', jwtToken, {
      expires: 30,
      path: '/',
    })
    history.replace('/')
  }

  onSubmitFailure = errorMsg => {
    console.log(errorMsg)
    this.setState({showSubmitError: true, errorMsg})
  }

  submitForm = async event => {
    event.preventDefault()
    const {username, password} = this.state
    const userDetails = {username, password}
    const url = 'https://apis.ccbp.in/login'
    const options = {
      method: 'POST',
      body: JSON.stringify(userDetails),
    }
    const response = await fetch(url, options)
    const data = await response.json()
    if (response.ok === true) {
      this.onSubmitSuccess(data.jwt_token)
    } else {
      this.onSubmitFailure(data.error_msg)
    }
  }

  renderPasswordField = () => {
    const {password} = this.state
    return (
      <>
        <label className="input-label" htmlFor="password">
          PASSWORD
        </label>
        <input
          type="password"
          id="password"
          className="password-input-field"
          value={password}
          onChange={this.onChangePassword}
        />
      </>
    )
  }

  renderUsernameField = () => {
    const {username} = this.state
    return (
      <>
        <label className="input-label" htmlFor="username">
          USERNAME
        </label>
        <input
          type="text"
          id="username"
          className="username-input-field"
          value={username}
          onChange={this.onChangeUsername}
        />
      </>
    )
  }

  render() {
    const {showSubmitError, errorMsg} = this.state
    const jwtToken = Cookies.get('jwt_token')
    if (jwtToken !== undefined) {
      return <Redirect to="/" />
    }
    return (
      <div className="login-form-container">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
          className="login-website-logo-mobile-image"
          alt="website logo"
        />
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
          className="login-image"
          alt="website login"
        />
        <form className="form-container" onSubmit={this.submitForm}>
          <img
            src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-logo-img.png"
            className="login-website-logo-desktop-image"
            alt="website logo"
          />
          <div className="input-container">{this.renderUsernameField()}</div>
          <div className="input-container">{this.renderPasswordField()}</div>
          <button type="submit" className="login-button">
            Login
          </button>
          {showSubmitError && <p className="error-message">*{errorMsg}</p>}
        </form>
      </div>
    )
  }
}

export default LoginForm

File: src/components/NotFound

import './index.css'

const NotFound = () => (
  <div className="not-found-container">
    <img
      src="https://assets.ccbp.in/frontend/react-js/not-found-blog-img.png"
      alt="not-found"
      className="not-found-img"
    />
  </div>
)

export default NotFound

File: src/components/PrimeDealsSection

import {Component} from 'react'
import Cookies from 'js-cookie'
import Loader from 'react-loader-spinner'

import ProductCard from '../ProductCard'
import './index.css'

const apiStatusConstants = {
  initial: 'INITIAL',
  success: 'SUCCESS',
  failure: 'FAILURE',
  inProgress: 'IN_PROGRESS',
}

class PrimeDealsSection extends Component {
  state = {
    primeDeals: [],
    apiStatus: apiStatusConstants.initial,
  }

  componentDidMount() {
    this.getPrimeDeals()
  }

  getPrimeDeals = async () => {
    this.setState({
      apiStatus: apiStatusConstants.inProgress,
    })

    const jwtToken = Cookies.get('jwt_token')

    const apiUrl = 'https://apis.ccbp.in/prime-deals'
    const options = {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
      method: 'GET',
    }
    const response = await fetch(apiUrl, options)
    if (response.ok === true) {
      const fetchedData = await response.json()
      const updatedData = fetchedData.prime_deals.map(product => ({
        title: product.title,
        brand: product.brand,
        price: product.price,
        id: product.id,
        imageUrl: product.image_url,
        rating: product.rating,
      }))
      this.setState({
        primeDeals: updatedData,
        apiStatus: apiStatusConstants.success,
      })
    } else if (response.status === 401) {
      this.setState({
        apiStatus: apiStatusConstants.failure,
      })
    }
  }

  renderPrimeDealsList = () => {
    const {primeDeals} = this.state
    return (
      <div>
        <h1 className="primedeals-list-heading">Exclusive Prime Deals</h1>
        <ul className="products-list">
          {primeDeals.map(product => (
            <ProductCard productData={product} key={product.id} />
          ))}
        </ul>
      </div>
    )
  }

  renderPrimeDealsFailureView = () => (
    <img
      src="https://assets.ccbp.in/frontend/react-js/exclusive-deals-banner-img.png"
      alt="Register Prime"
      className="register-prime-image"
    />
  )

  renderLoadingView = () => (
    <div className="products-loader-container">
      <Loader type="ThreeDots" color="#0b69ff" height="50" width="50" />
    </div>
  )

  render() {
    const {apiStatus} = this.state
    switch (apiStatus) {
      case apiStatusConstants.success:
        return this.renderPrimeDealsList()
      case apiStatusConstants.failure:
        return this.renderPrimeDealsFailureView()
      case apiStatusConstants.inProgress:
        return this.renderLoadingView()
      default:
        return null
    }
  }
}

export default PrimeDealsSection

File: src/components/ProductCard

import './index.css'

const ProductCard = props => {
  const {productData} = props
  const {title, brand, imageUrl, rating, price} = productData

  return (
    <li className="product-item">
      <img src={imageUrl} alt="product" className="thumbnail" />
      <h1 className="title">{title}</h1>
      <p className="brand">by {brand}</p>
      <div className="product-details">
        <p className="price">Rs {price}/-</p>
        <div className="rating-container">
          <p className="rating">{rating}</p>
          <img
            src="https://assets.ccbp.in/frontend/react-js/star-img.png"
            alt="star"
            className="star"
          />
        </div>
      </div>
    </li>
  )
}
export default ProductCard

File: src/components/Products

import AllProductsSection from '../AllProductsSection'
import PrimeDealsSection from '../PrimeDealsSection'

import Header from '../Header'

import './index.css'

const Products = () => (
  <>
    <Header />
    <div className="product-sections">
      <PrimeDealsSection />
      <AllProductsSection />
    </div>
  </>
)

export default Products

File: src/components/ProductsHeader

import {BsFilterRight} from 'react-icons/bs'

import './index.css'

const ProductsHeader = props => {
  const {sortbyOptions, activeOptionId, updateActiveOptionId} = props
  const onChangeSortby = event => {
    updateActiveOptionId(event.target.value)
  }

  return (
    <div className="products-header">
      <h1 className="products-list-heading">All Products</h1>
      <div className="sort-by-container">
        <BsFilterRight className="sort-by-icon" />
        <h1 className="sort-by">Sort by</h1>
        <select
          className="sort-by-select"
          value={activeOptionId}
          onChange={onChangeSortby}
        >
          {sortbyOptions.map(eachOption => (
            <option
              key={eachOption.optionId}
              value={eachOption.optionId}
              className="select-option"
            >
              {eachOption.displayText}
            </option>
          ))}
        </select>
      </div>
    </div>
  )
}

export default ProductsHeader

File: src/components/ProtectedRoute

import {Redirect, Route} from 'react-router-dom'
import Cookie from 'js-cookie'

const ProtectedRoute = props => {
  const token = Cookie.get('jwt_token')
  if (token === undefined) {
    return <Redirect to="/login" />
  }
  return <Route {...props} />
}

export default ProtectedRoute

File: src/App.js

import {BrowserRouter, Route, Switch, Redirect} from 'react-router-dom'

import LoginForm from './components/LoginForm'
import Home from './components/Home'
import Products from './components/Products'
import Cart from './components/Cart'
import NotFound from './components/NotFound'
import ProtectedRoute from './components/ProtectedRoute'

import './App.css'

const App = () => (
  <BrowserRouter>
    <Switch>
      <Route exact path="/login" component={LoginForm} />
      <ProtectedRoute exact path="/" component={Home} />
      <ProtectedRoute exact path="/products" component={Products} />
      <ProtectedRoute exact path="/cart" component={Cart} />
      <Route path="/not-found" component={NotFound} />
      <Redirect to="not-found" />
    </Switch>
  </BrowserRouter>
)

export default App

coding pratice-33:
------------------------------------------------------------------------------------------------

Github Popular Repos:
-------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-GithubPopularRepos

In this project, let's build a Github Popular Repos by applying the concepts we have learned till now.

1.Functionality to be added

The app must have the following functionalities

When the app is opened initially,
	An HTTP GET request should be made to githubReposApiUrl with query parameter as language and its initial value as ALL
	loader should be displayed while fetching the data
	After the data is fetched successfully, display the repositories list received from the response

When a language filter is active
	An HTTP GET request should be made to the above-mentioned URL with the id of the active language
	loader should be displayed while fetching the data
	After the data is fetched successfully, display the repositories list received from the response

The GithubPopularRepos component is provided with languageFiltersData. 
It consists of a list of language filter objects with the following properties in each language filter object

Key			Data Type
id			String
language	String

2.API Requests & Responses

githubReposApiUrl

API: https://apis.ccbp.in/popular-repos
Example: https://apis.ccbp.in/popular-repos?language=ALL
Method: GET
Description:
Returns a response containing the list of repositories

Response

{
  "popular_repos": [
    {
      "name": "freeCodeCamp",
      "id": 28457823,
      "issues_count": 154,
      "forks_count": 26651,
      "stars_count": 331304,
      "avatar_url": "https://avatars.githubusercontent.com/u/9892522?v=4"
    }, 
      ...
  ],
}

3.Implementation Files

Use these files to complete the implementation:

src/components/GithubPopularRepos/index.js
src/components/GithubPopularRepos/index.css
src/components/LanguageFilterItem/index.js
src/components/LanguageFilterItem/index.css
src/components/RepositoryItem/index.js
src/components/RepositoryItem/index.css

4.Quick Tips
Click to view

To display the animated loader, we need to import the Loader component using the below statement

import Loader from 'react-loader-spinner'

In order to display the given animated loader, pass the type and color props to the Loader component with values as ThreeDots and #0284c7, respectively

<Loader type="ThreeDots" color="#0284c7" height={80} width={80} />

5.Important Note
Click to view

The following instructions are required for the tests to pass

Wrap the Loader component with an HTML container element and add the testid attribute value as loader to it

<div testid="loader">
   <Loader type="ThreeDots" color="#0284c7" height={80} width={80} />
</div>

//src/components/GithubPopularRepos/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'

import LanguageFilterItem from '../LanguageFilterItem'
import RepositoryItem from '../RepositoryItem'

import './index.css'

const apiStatusConstants = {
  initial: 'INITIAL',
  success: 'SUCCESS',
  failure: 'FAILURE',
  inProgress: 'IN_PROGRESS',
}

const languageFiltersData = [
  {id: 'ALL', language: 'All'},
  {id: 'JAVASCRIPT', language: 'Javascript'},
  {id: 'RUBY', language: 'Ruby'},
  {id: 'JAVA', language: 'Java'},
  {id: 'CSS', language: 'CSS'},
]

class GithubPopularRepos extends Component {
  state = {
    apiStatus: apiStatusConstants.initial,
    repositoriesData: [],
    activeLanguageFilterId: languageFiltersData[0].id,
  }

  componentDidMount() {
    this.getRepositories()
  }

  getRepositories = async () => {
    const {activeLanguageFilterId} = this.state
    this.setState({
      apiStatus: apiStatusConstants.inProgress,
    })
    const apiUrl = `https://apis.ccbp.in/popular-repos?language=${activeLanguageFilterId}`
    const response = await fetch(apiUrl)
    if (response.ok) {
      const fetchedData = await response.json()
      const updatedData = fetchedData.popular_repos.map(eachRepository => ({
        id: eachRepository.id,
        imageUrl: eachRepository.avatar_url,
        name: eachRepository.name,
        starsCount: eachRepository.stars_count,
        forksCount: eachRepository.forks_count,
        issuesCount: eachRepository.issues_count,
      }))
      this.setState({
        repositoriesData: updatedData,
        apiStatus: apiStatusConstants.success,
      })
    } else {
      this.setState({
        apiStatus: apiStatusConstants.failure,
      })
    }
  }

  renderLoadingView = () => (
    <div testid="loader">
      <Loader color="#0284c7" height={80} type="ThreeDots" width={80} />
    </div>
  )

  renderFailureView = () => (
    <div className="failure-view-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/api-failure-view.png"
        alt="failure view"
        className="failure-view-image"
      />
      <h1 className="error-message">Something Went Wrong</h1>
    </div>
  )

  renderRepositoriesListView = () => {
    const {repositoriesData} = this.state

    return (
      <ul className="repositories-list">
        {repositoriesData.map(eachRepository => (
          <RepositoryItem
            key={eachRepository.id}
            repositoryDetails={eachRepository}
          />
        ))}
      </ul>
    )
  }

  renderRepositories = () => {
    const {apiStatus} = this.state

    switch (apiStatus) {
      case apiStatusConstants.success:
        return this.renderRepositoriesListView()
      case apiStatusConstants.failure:
        return this.renderFailureView()
      case apiStatusConstants.inProgress:
        return this.renderLoadingView()
      default:
        return null
    }
  }

  setActiveLanguageFilterId = newFilterId => {
    this.setState({activeLanguageFilterId: newFilterId}, this.getRepositories)
  }

  renderLanguageFiltersList = () => {
    const {activeLanguageFilterId} = this.state

    return (
      <ul className="filters-list">
        {languageFiltersData.map(eachLanguageFilter => (
          <LanguageFilterItem
            key={eachLanguageFilter.id}
            isActive={eachLanguageFilter.id === activeLanguageFilterId}
            languageFilterDetails={eachLanguageFilter}
            setActiveLanguageFilterId={this.setActiveLanguageFilterId}
          />
        ))}
      </ul>
    )
  }

  render() {
    return (
      <div className="app-container">
        <div className="responsive-container">
          <h1 className="heading">Popular</h1>
          {this.renderLanguageFiltersList()}
          {this.renderRepositories()}
        </div>
      </div>
    )
  }
}

export default GithubPopularRepos

//src/components/LanguageFilterItem/index.js

import './index.css'

const LanguageFilterItem = props => {
  const {isActive, languageFilterDetails, setActiveLanguageFilterId} = props
  const {id, language} = languageFilterDetails
  const btnClassName = isActive
    ? 'language-btn active-language-btn'
    : 'language-btn'
  const onClickLanguageFilter = () => {
    setActiveLanguageFilterId(id)
  }

  return (
    <li>
      <button
        className={btnClassName}
        onClick={onClickLanguageFilter}
        type="button"
      >
        {language}
      </button>
    </li>
  )
}

export default LanguageFilterItem


//src/components/RepositoryItem/index.js

import './index.css'

const RepositoryItem = props => {
  const {repositoryDetails} = props
  const {
    name,
    imageUrl,
    starsCount,
    forksCount,
    issuesCount,
  } = repositoryDetails

  return (
    <li className="repository-item">
      <img className="repository-image" src={imageUrl} alt={name} />
      <h1 className="repository-name">{name}</h1>
      <div className="stats-container">
        <img
          className="stats-icon"
          src="https://assets.ccbp.in/frontend/react-js/stars-count-img.png"
          alt="stars"
        />
        <p className="stats-text">{starsCount} stars</p>
      </div>
      <div className="stats-container">
        <img
          className="stats-icon"
          src="https://assets.ccbp.in/frontend/react-js/forks-count-img.png"
          alt="forks"
        />
        <p className="stats-text">{forksCount} forks</p>
      </div>
      <div className="stats-container">
        <img
          className="stats-icon"
          src="https://assets.ccbp.in/frontend/react-js/issues-count-img.png"
          alt="open issues"
        />
        <p className="stats-text">{issuesCount} open issues</p>
      </div>
    </li>
  )
}

export default RepositoryItem

//src/App.js

import './App.css'

import GithubPopularRepos from './components/GithubPopularRepos'

const App = () => <GithubPopularRepos />

export default App

coding pratice-34:
------------------------------------------------------------------------------------------------------------------------

Nxt Trendz - Products Filters Group:
--------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-NxtTrendzProductsFiltersGroup

In this project, let's build a Nxt Trendz - Products Filters Group app by applying the concepts we have learned till now.

1.Implementation Files

Use these files to complete the implementation:

src/components/AllProductsSection/index.js
src/components/AllProductsSection/index.css
src/components/FiltersGroup/index.js
src/components/FiltersGroup/index.css

//src/components/AllProductsSection/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'
import Cookies from 'js-cookie'

import FiltersGroup from '../FiltersGroup'
import ProductCard from '../ProductCard'
import ProductsHeader from '../ProductsHeader'

import './index.css'

const categoryOptions = [
  {
    name: 'Clothing',
    categoryId: '1',
  },
  {
    name: 'Electronics',
    categoryId: '2',
  },
  {
    name: 'Appliances',
    categoryId: '3',
  },
  {
    name: 'Grocery',
    categoryId: '4',
  },
  {
    name: 'Toys',
    categoryId: '5',
  },
]

const sortbyOptions = [
  {
    optionId: 'PRICE_HIGH',
    displayText: 'Price (High-Low)',
  },
  {
    optionId: 'PRICE_LOW',
    displayText: 'Price (Low-High)',
  },
]

const ratingsList = [
  {
    ratingId: '4',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/rating-four-stars-img.png',
  },
  {
    ratingId: '3',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/rating-three-stars-img.png',
  },
  {
    ratingId: '2',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/rating-two-stars-img.png',
  },
  {
    ratingId: '1',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/rating-one-star-img.png',
  },
]

const apiStatusConstants = {
  initial: 'INITIAL',
  success: 'SUCCESS',
  failure: 'FAILURE',
  inProgress: 'IN_PROGRESS',
}

class AllProductsSection extends Component {
  state = {
    productsList: [],
    apiStatus: apiStatusConstants.initial,
    activeOptionId: sortbyOptions[0].optionId,
    activeCategoryId: '',
    searchInput: '',
    activeRatingId: '',
  }

  componentDidMount() {
    this.getProducts()
  }

  getProducts = async () => {
    this.setState({
      apiStatus: apiStatusConstants.inProgress,
    })
    const jwtToken = Cookies.get('jwt_token')
    const {
      activeOptionId,
      activeCategoryId,
      searchInput,
      activeRatingId,
    } = this.state
    const apiUrl = `https://apis.ccbp.in/products?sort_by=${activeOptionId}&category=${activeCategoryId}&title_search=${searchInput}&rating=${activeRatingId}`
    const options = {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
      method: 'GET',
    }
    const response = await fetch(apiUrl, options)
    if (response.ok) {
      const fetchedData = await response.json()
      const updatedData = fetchedData.products.map(product => ({
        title: product.title,
        brand: product.brand,
        price: product.price,
        id: product.id,
        imageUrl: product.image_url,
        rating: product.rating,
      }))
      this.setState({
        productsList: updatedData,
        apiStatus: apiStatusConstants.success,
      })
    } else {
      this.setState({
        apiStatus: apiStatusConstants.failure,
      })
    }
  }

  renderLoadingView = () => (
    <div className="products-loader-container">
      <Loader type="ThreeDots" color="#0b69ff" height="50" width="50" />
    </div>
  )

  renderFailureView = () => (
    <div className="products-error-view-container">
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz/nxt-trendz-products-error-view.png"
        alt="products failure"
        className="products-failure-img"
      />
      <h1 className="product-failure-heading-text">
        Oops! Something Went Wrong
      </h1>
      <p className="products-failure-description">
        We are having some trouble processing your request. Please try again.
      </p>
    </div>
  )

  changeSortby = activeOptionId => {
    this.setState({activeOptionId}, this.getProducts)
  }

  renderProductsListView = () => {
    const {productsList, activeOptionId} = this.state
    const shouldShowProductsList = productsList.length > 0

    return shouldShowProductsList ? (
      <div className="all-products-container">
        <ProductsHeader
          activeOptionId={activeOptionId}
          sortbyOptions={sortbyOptions}
          changeSortby={this.changeSortby}
        />
        <ul className="products-list">
          {productsList.map(product => (
            <ProductCard productData={product} key={product.id} />
          ))}
        </ul>
      </div>
    ) : (
      <div className="no-products-view">
        <img
          src="https://assets.ccbp.in/frontend/react-js/nxt-trendz/nxt-trendz-no-products-view.png"
          className="no-products-img"
          alt="no products"
        />
        <h1 className="no-products-heading">No Products Found</h1>
        <p className="no-products-description">
          We could not find any products. Try other filters.
        </p>
      </div>
    )
  }

  renderAllProducts = () => {
    const {apiStatus} = this.state

    switch (apiStatus) {
      case apiStatusConstants.success:
        return this.renderProductsListView()
      case apiStatusConstants.failure:
        return this.renderFailureView()
      case apiStatusConstants.inProgress:
        return this.renderLoadingView()
      default:
        return null
    }
  }

  clearFilters = () => {
    this.setState(
      {
        searchInput: '',
        activeCategoryId: '',
        activeRatingId: '',
      },
      this.getProducts,
    )
  }

  changeRating = activeRatingId => {
    this.setState({activeRatingId}, this.getProducts)
  }

  changeCategory = activeCategoryId => {
    this.setState({activeCategoryId}, this.getProducts)
  }

  enterSearchInput = () => {
    this.getProducts()
  }

  changeSearchInput = searchInput => {
    this.setState({searchInput})
  }

  render() {
    const {activeCategoryId, searchInput, activeRatingId} = this.state

    return (
      <div className="all-products-section">
        <FiltersGroup
          searchInput={searchInput}
          categoryOptions={categoryOptions}
          ratingsList={ratingsList}
          changeSearchInput={this.changeSearchInput}
          enterSearchInput={this.enterSearchInput}
          activeCategoryId={activeCategoryId}
          activeRatingId={activeRatingId}
          changeCategory={this.changeCategory}
          changeRating={this.changeRating}
          clearFilters={this.clearFilters}
        />
        {this.renderAllProducts()}
      </div>
    )
  }
}

export default AllProductsSection

//src/components/FiltersGroup/index.js

import {BsSearch} from 'react-icons/bs'

import './index.css'

const FiltersGroup = props => {
  const renderRatingsFiltersList = () => {
    const {ratingsList} = props

    return ratingsList.map(rating => {
      const {changeRating, activeRatingId} = props
      const onClickRatingItem = () => changeRating(rating.ratingId)

      const ratingClassName =
        activeRatingId === rating.ratingId ? `and-up active-rating` : `and-up`

      return (
        <li
          className="rating-item"
          key={rating.ratingId}
          onClick={onClickRatingItem}
        >
          <img
            src={rating.imageUrl}
            alt={`rating ${rating.ratingId}`}
            className="rating-img"
          />
          <p className={ratingClassName}>& up</p>
        </li>
      )
    })
  }

  const renderRatingsFilters = () => (
    <div>
      <h1 className="rating-heading">Rating</h1>
      <ul className="ratings-list">{renderRatingsFiltersList()}</ul>
    </div>
  )

  const renderCategoriesList = () => {
    const {categoryOptions} = props

    return categoryOptions.map(category => {
      const {changeCategory, activeCategoryId} = props
      const onClickCategoryItem = () => changeCategory(category.categoryId)
      const isActive = category.categoryId === activeCategoryId
      const categoryClassName = isActive
        ? `category-name active-category-name`
        : `category-name`

      return (
        <li
          className="category-item"
          key={category.categoryId}
          onClick={onClickCategoryItem}
        >
          <p className={categoryClassName}>{category.name}</p>
        </li>
      )
    })
  }

  const renderProductCategories = () => (
    <>
      <h1 className="category-heading">Category</h1>
      <ul className="categories-list">{renderCategoriesList()}</ul>
    </>
  )

  const onEnterSearchInput = event => {
    const {enterSearchInput} = props
    if (event.key === 'Enter') {
      enterSearchInput()
    }
  }

  const onChangeSearchInput = event => {
    const {changeSearchInput} = props
    changeSearchInput(event.target.value)
  }

  const renderSearchInput = () => {
    const {searchInput} = props

    return (
      <div className="search-input-container">
        <input
          value={searchInput}
          type="search"
          className="search-input"
          placeholder="Search"
          onChange={onChangeSearchInput}
          onKeyDown={onEnterSearchInput}
        />
        <BsSearch className="search-icon" />
      </div>
    )
  }

  const {clearFilters} = props

  return (
    <div className="filters-group-container">
      {renderSearchInput()}
      {renderProductCategories()}
      {renderRatingsFilters()}
      <button
        type="button"
        className="clear-filters-btn"
        onClick={clearFilters}
      >
        Clear Filters
      </button>
    </div>
  )
}

export default FiltersGroup

//src/App.js

import {Route, Switch, Redirect} from 'react-router-dom'

import LoginForm from './components/LoginForm'
import Home from './components/Home'
import Products from './components/Products'
import Cart from './components/Cart'
import NotFound from './components/NotFound'
import ProtectedRoute from './components/ProtectedRoute'

import './App.css'

const App = () => (
  <Switch>
    <Route exact path="/login" component={LoginForm} />
    <ProtectedRoute exact path="/" component={Home} />
    <ProtectedRoute exact path="/products" component={Products} />
    <ProtectedRoute exact path="/cart" component={Cart} />
    <Route path="/not-found" component={NotFound} />
    <Redirect to="not-found" />
  </Switch>
)

export default App

coding pratice-35:
-----------------------------------------------------------------------------------------------------------------------------

Nxt Trendz - Specific Product Details:
-------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-NxtTrendz-SpecificProductDetails

https://github.com/harsha3072/nxtTrendzSpecificProductDetails

In this project, let's build a Nxt Trendz - Specific Product Details app by applying the concepts we have learned till now.

1.API Requests & Responses

productDetailsApiUrl

API: https://apis.ccbp.in/products/:id
Example: http://localhost:3000/products/16
Method: GET
Description:
Returns a response containing the Product details

Sample Success Response

{
  "id":16,
  "image_url":"https://assets.ccbp.in/frontend/react-js/ecommerce/cloths-long-fork.png",
  "title":"Embroidered Net Gown","price":62990,"description":"An Embroidered Net Gown is the clothing worn by a bride during a wedding ceremony. It enhances your beauty wearing this vibrant, gorgeous, and beautiful Wedding Gown. Find your dream wedding dress today. It features foldable, one hoop steel, two layers of tulles, and is elastic in the waist part. ",
  "brand":"Manyavar",
  "total_reviews":879,
  "rating":3,
  "availability":"In Stock",
  "similar_products":[
    {
      "id":1,
      "image_url":"https://assets.ccbp.in/frontend/react-js/ecommerce/clothes-cap.png",
      "title":"Wide Bowknot Hat",
      "style":"Wide Bowknot Hat for Women and Girls (Multicolor)",
      "price":288,
      "description":"This Summer's perfect White Wide Brim Straw Beach hat is perfect for a hot day. It has the Floppy Style which gives you good coverage from the sun's hot rays and is sure to make the right style statement. It is made of high-quality & skin-friendly paper straw material and lightweight. ",
      "brand":"MAJIK",
      "total_reviews":245,
      "rating":3.6,
      "availability":"In Stock"
    },
      ...
  ]
}

Sample Failure Response

{
  "status_code": 404,
  "error_msg": "Product Not Found"
}

2.Quick Tips
Click to view

The line-height CSS property sets the height of a line box. It's commonly used to set the distance between lines of text.

line-height: 1.5;

3.Implementation Files

Use these files to complete the implementation:

src/components/ProductCard/index.js
src/components/ProductCard/index.css
src/components/ProductItemDetails/index.js
src/components/ProductItemDetails/index.css
src/components/SimilarProductItem/index.js
src/components/SimilarProductItem/index.css

//src/components/ProductCard/index.js

import {Link} from 'react-router-dom'

import './index.css'

const ProductCard = props => {
  const {productData} = props
  const {title, brand, imageUrl, rating, price, id} = productData

  return (
    <li className="product-item">
      <Link to={`/products/${id}`} className="link-item">
        <img src={imageUrl} alt="product" className="thumbnail" />
        <h1 className="title">{title}</h1>
        <p className="brand">by {brand}</p>
        <div className="product-details">
          <p className="price">Rs {price}/-</p>
          <div className="rating-container">
            <p className="rating">{rating}</p>
            <img
              src="https://assets.ccbp.in/frontend/react-js/star-img.png"
              alt="star"
              className="star"
            />
          </div>
        </div>
      </Link>
    </li>
  )
}
export default ProductCard

//src/components/ProductItemDetails/index.js

import {Component} from 'react'
import {Link} from 'react-router-dom'
import Cookies from 'js-cookie'
import Loader from 'react-loader-spinner'
import {BsPlusSquare, BsDashSquare} from 'react-icons/bs'

import Header from '../Header'
import SimilarProductItem from '../SimilarProductItem'

import './index.css'

const apiStatusConstants = {
  initial: 'INITIAL',
  success: 'SUCCESS',
  failure: 'FAILURE',
  inProgress: 'IN_PROGRESS',
}

class ProductItemDetails extends Component {
  state = {
    productData: {},
    similarProductsData: [],
    apiStatus: apiStatusConstants.initial,
    quantity: 1,
  }

  componentDidMount() {
    this.getProductData()
  }

  getFormattedData = data => ({
    availability: data.availability,
    brand: data.brand,
    description: data.description,
    id: data.id,
    imageUrl: data.image_url,
    price: data.price,
    rating: data.rating,
    title: data.title,
    totalReviews: data.total_reviews,
  })

  getProductData = async () => {
    const {match} = this.props
    const {params} = match
    const {id} = params

    this.setState({
      apiStatus: apiStatusConstants.inProgress,
    })
    const jwtToken = Cookies.get('jwt_token')
    const apiUrl = `https://apis.ccbp.in/products/${id}`
    const options = {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
      method: 'GET',
    }
    const response = await fetch(apiUrl, options)
    if (response.ok) {
      const fetchedData = await response.json()
      const updatedData = this.getFormattedData(fetchedData)
      const updatedSimilarProductsData = fetchedData.similar_products.map(
        eachSimilarProduct => this.getFormattedData(eachSimilarProduct),
      )
      this.setState({
        productData: updatedData,
        similarProductsData: updatedSimilarProductsData,
        apiStatus: apiStatusConstants.success,
      })
    }
    if (response.status === 404) {
      this.setState({
        apiStatus: apiStatusConstants.failure,
      })
    }
  }

  renderLoadingView = () => (
    <div className="products-details-loader-container" testid="loader">
      <Loader type="ThreeDots" color="#0b69ff" height="50" width="50" />
    </div>
  )

  renderFailureView = () => (
    <div className="product-details-failure-view-container">
      <img
        alt="failure view"
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-error-view-img.png"
        className="failure-view-image"
      />
      <h1 className="product-not-found-heading">Product Not Found</h1>
      <Link to="/products">
        <button type="button" className="button">
          Continue Shopping
        </button>
      </Link>
    </div>
  )

  onDecrementQuantity = () => {
    const {quantity} = this.state
    if (quantity > 1) {
      this.setState(prevState => ({quantity: prevState.quantity - 1}))
    }
  }

  onIncrementQuantity = () => {
    this.setState(prevState => ({quantity: prevState.quantity + 1}))
  }

  renderProductDetailsView = () => {
    const {productData, quantity, similarProductsData} = this.state
    const {
      availability,
      brand,
      description,
      imageUrl,
      price,
      rating,
      title,
      totalReviews,
    } = productData

    return (
      <div className="product-details-success-view">
        <div className="product-details-container">
          <img src={imageUrl} alt="product" className="product-image" />
          <div className="product">
            <h1 className="product-name">{title}</h1>
            <p className="price-details">Rs {price}/-</p>
            <div className="rating-and-reviews-count">
              <div className="rating-container">
                <p className="rating">{rating}</p>
                <img
                  src="https://assets.ccbp.in/frontend/react-js/star-img.png"
                  alt="star"
                  className="star"
                />
              </div>
              <p className="reviews-count">{totalReviews} Reviews</p>
            </div>
            <p className="product-description">{description}</p>
            <div className="label-value-container">
              <p className="label">Available:</p>
              <p className="value">{availability}</p>
            </div>
            <div className="label-value-container">
              <p className="label">Brand:</p>
              <p className="value">{brand}</p>
            </div>
            <hr className="horizontal-line" />
            <div className="quantity-container">
              <button
                type="button"
                className="quantity-controller-button"
                onClick={this.onDecrementQuantity}
                testid="minus"
              >
                <BsDashSquare className="quantity-controller-icon" />
              </button>
              <p className="quantity">{quantity}</p>
              <button
                type="button"
                className="quantity-controller-button"
                onClick={this.onIncrementQuantity}
                testid="plus"
              >
                <BsPlusSquare className="quantity-controller-icon" />
              </button>
            </div>
            <button type="button" className="button add-to-cart-btn">
              ADD TO CART
            </button>
          </div>
        </div>
        <h1 className="similar-products-heading">Similar Products</h1>
        <ul className="similar-products-list">
          {similarProductsData.map(eachSimilarProduct => (
            <SimilarProductItem
              productDetails={eachSimilarProduct}
              key={eachSimilarProduct.id}
            />
          ))}
        </ul>
      </div>
    )
  }

  renderProductDetails = () => {
    const {apiStatus} = this.state

    switch (apiStatus) {
      case apiStatusConstants.success:
        return this.renderProductDetailsView()
      case apiStatusConstants.failure:
        return this.renderFailureView()
      case apiStatusConstants.inProgress:
        return this.renderLoadingView()
      default:
        return null
    }
  }

  render() {
    return (
      <>
        <Header />
        <div className="product-item-details-container">
          {this.renderProductDetails()}
        </div>
      </>
    )
  }
}

export default ProductItemDetails

//src/components/SimilarProductItem/index.js

import './index.css'

const SimilarProductItem = props => {
  const {productDetails} = props
  const {title, brand, imageUrl, rating, price} = productDetails

  return (
    <li className="similar-product-item">
      <img
        src={imageUrl}
        className="similar-product-image"
        alt={`similar product ${title}`}
      />
      <p className="similar-product-title">{title}</p>
      <p className="similar-products-brand">by {brand}</p>
      <div className="similar-product-price-rating-container">
        <p className="similar-product-price">Rs {price}/-</p>
        <div className="similar-product-rating-container">
          <p className="similar-product-rating">{rating}</p>
          <img
            src="https://assets.ccbp.in/frontend/react-js/star-img.png"
            alt="star"
            className="similar-product-star"
          />
        </div>
      </div>
    </li>
  )
}

export default SimilarProductItem

More React Concepts | Cheat Sheet:
---------------------------------------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-MoreReactConcepts

Concepts in Focus:

Reconciliation
	Virtual DOM
	
React Batch Updating

setState() Syntax
	Object Syntax
	Callback Syntax
	Object Syntax vs Callback Syntax
	
Children Prop
	Passing Text as Children
	Accessing Children
	
Controlled vs Uncontrolled Input
	Controlled Input
	Uncontrolled Input
	
Props vs State

State should be minimal

Keys
	Keys in Lists
	
1. Reconciliation

1.1 Virtual DOM
A Virtual DOM is a JS object, which is the virtual representation of an HTML DOM.

Whenever new elements are added to the UI, a virtual DOM is created.

React compares new virtual DOM with current virtual DOM, and the difference will be efficiently updated to HTML DOM. So, the Virtual DOM helps to render the UI more performantly.

React only updates what's necessary. This process is known as Reconciliation.

2. React Batch Updating
React combines multiple setState() calls into single update.

Example:

import { Component } from "react"

class Counter extends Component {
  state = { count: 0 }

  onIncrement = () => {
    this.setState((prevState) => ({ count: prevState.count + 1 }))
    this.setState((prevState) => ({ count: prevState.count + 1 }))
    this.setState((prevState) => ({ count: prevState.count + 1 }))
  }

  render() {
    const { count } = this.state
    console.log("render() called")
    return (
      <>
        <p className="count">Count {count}</p>
        <button onClick={this.onIncrement}>Increase</button>
      </>
    )
  }
}

export default Counter

In the above example, the render is called only once as React combines multiple setState() calls into a single update.

3. setState() Syntax

3.1 Object Syntax
Object Syntax is used while updating the state to a value.

this.setState({
  count: 5,
})

3.2 Callback Syntax
Callback Syntax is used while updating the state to a value that is computed based on the previous state.

this.setState((prevState) => ({ count: prevState.count + 1 }))

3.3 Object Syntax vs Callback Syntax

Object Syntax:

import { Component } from "react"

class Counter extends Component {
  state = { count: 0 }

  onIncrement = () => {
    this.setState({ count: this.state.count + 1 })
    this.setState({ count: this.state.count + 1 })
    this.setState({ count: this.state.count + 1 })
  }

  render() {
    const { count } = this.state
    return (
      <>
        <p className="count">Count {count}</p>
        <button onClick={this.onIncrement}>Increase</button>
      </>
    )
  }
}

export default Counter

When the HTML button element is clicked, the value of the state variable count is 1.

When the Object Syntax is used, this.state.count is same for every setState statement as setState is asynchronous.

Callback Syntax:

import { Component } from "react"

class Counter extends Component {
  state = { count: 0 }

  onIncrement = () => {
    this.setState((prevState) => ({ count: prevState.count + 1 }))
    this.setState((prevState) => ({ count: prevState.count + 1 }))
    this.setState((prevState) => ({ count: prevState.count + 1 }))
  }

  render() {
    const { count } = this.state
    return (
      <>
        <p className="count">Count {count}</p>
        <button onClick={this.onIncrement}>Increase</button>
      </>
    )
  }
}

export default Counter

When the HTML button element is clicked, the value of the state variable count is 3.

The setState callback function receive prevState as an argument. So, it will receive an updated state value when it is executed.

4. Children Prop
The children is a special prop that is automatically passed to every React Component.

The JSX Element/Text included in between the opening and closing tags are considered children.

4.1 Passing Text as Children

File: src/components/Post/index.js

import "./index.css"
import SocialButton from "./SocialButton"

const Post = () => (
  <div className="post-container">
    <p className="paragraph">Hooks are a new addition</p>
    <SocialButton>Like</SocialButton>
  </div>
)

export default Post

4.2 Accessing Children

File: src/components/SocialButton/index.js


import "./index.css"

const SocialButton = (props) => (
  <button className="social-button">{props.children}</button>
)

export default SocialButton

5. Controlled vs Uncontrolled Input
In React, the Input Element value can be handled in two ways:

Controlled Input
Uncontrolled Input

5.1 Controlled Input
If the Input Element value is handled by a React State, then it is called Controlled Input.

It is the React Suggested way to handle the Input Element value.

Example:

import { Component } from "react"

class App extends Component {
  state = {
    searchInput: "",
  }

  onChangeSearchInput = (event) => {
    this.setState({
      searchInput: event.target.value,
    })
  }

  render() {
    const { searchInput } = this.state
    return (
      <>
        <input
          type="text"
          onChange={this.onChangeSearchInput}
          value={searchInput}
        />
        <p>{searchInput}</p>
      </>
    )
  }
}

export default App

5.2 Uncontrolled Input
If the Input Element value is handled by the browser itself, then it is called Uncontrolled Input.

Example:

import { Component } from "react"

class App extends Component {
  state = {
    searchInput: "",
  }

  onChangeSearchInput = (event) => {
    this.setState({
      searchInput: event.target.value,
    })
  }

  render() {
    const { searchInput } = this.state
    return (
      <>
        <input type="text" onChange={this.onChangeSearchInput} />
        <p>{searchInput}</p>
      </>
    )
  }
}

export default App

6. Props vs State

The props and state are plain JS objects.
The props and state changes trigger the render method.

Props																			State
Props get passed to the component, similar to function parameters				State is created and managed within the component, similar to a variable declared within the 
																				function
Props are used to pass data and event handlers down to the child components		State is used to store the component's data that changes over time
Props are immutable. A component cannot change the props						State should be immutable

7. State should be minimal
We need the state to make the applications interactive.

To build the application correctly, you first need to think of the minimal set of the state that the application needs.

Let's take an example application, Projects.

Think of all the pieces of data in the Projects Application. We have:

The original list of projects

The active tab item
	The text decoration of the text - Underline
	The color of the text
	
The filtered list of projects

Let's go through each one and figure out which one is state. Ask three questions about each piece of data:
	Is it passed in from a parent via props? If so, it probably isn't state.
	Does it remain unchanged over time? If so, it probably isn't state.
	Can it be computed based on any other state or props in the component? If so, it isn't state.
	
Let's figure out which one is state in our application:

Data										Is State?				Reason
The original list of projects				No						It is passed as props
The active tab item							Yes						It changes over time and can't be computed from anything
The filtered list of projects				No						It can be computed by combining the original list of projects with the active tab item
The text decoration of the text - Underline	No						It can be derived from the active tab item
The The color of the text					No						It can be derived from the active tab item

So finally, the state is:

The active tab item

state = {
  activeTabId: tabsList[0].tabId,
}

8. Keys
Keys help React identify which items have been changed, added, or removed.

Keys should be given to the elements inside the array to give a stable identity.

const usersList = [
  {
    uniqueNo: 1,
    name: "Rahul",
  },
  {
    uniqueNo: 2,
    name: "Praneetha",
  },
  {
    uniqueNo: 3,
    name: "Varakumar",
  },
]
const listItems = usersList.map((user) => (
  <li key={user.uniqueNo}>{user.name}</li>
))

8.1 Keys in Lists
When the state of a component changes, React updates the virtual DOM tree. Once the virtual DOM has been updated, 
React then compares the new virtual DOM with the current virtual DOM.

Once React knows which virtual DOM objects have changed, then React updates only those objects, in the HTML DOM.

React compares the virtual DOMs if there is a change in the node, node type, or the attributes passed to the node. 
But there is a problematic case by only looking at the node or it's attributes. i.e. Lists.

Lists will have the same node types and attributes. Hence the list items can't be uniquely identified if they have been changed, added, or removed.

coding pratice-36:
-------------------------------------------------------------------------

Alert Notifications:
-----------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-AlertNotifications

In this project, let's build an Alert Notifications app by applying the concepts we have learned till now.

1.Implementation Files

Use these files to complete the implementation:

src/components/Notification/index.js
src/components/Notification/index.css
src/components/AlertNotifications/index.js
src/components/AlertNotifications/index.css

2.Important Note
Click to view

The following instructions are required for the tests to pass

Access the elements passed to the Notification Component using the children prop.
AiFillCheckCircle from react-icons should be used for Success notification.
RiErrorWarningFill from react-icons should be used for Error notification.
MdWarning from react-icons should be used for Warning notification.
MdInfo from react-icons should be used for Info notification.
GrFormClose from react-icons should be used as Close icon in each notification.

//src/components/Notification/index.js

import {GrFormClose} from 'react-icons/gr'

import './index.css'

const Notification = props => {
  const {children} = props

  return (
    <div className="notification">
      <div className="notification-content">{children}</div>
      <GrFormClose className="close-icon" />
    </div>
  )
}

export default Notification

//src/components/AlertNotifications/index.js

import {AiFillCheckCircle} from 'react-icons/ai'
import {RiErrorWarningFill} from 'react-icons/ri'
import {MdWarning, MdInfo} from 'react-icons/md'

import Notification from '../Notification'

import './index.css'

const AlertNotifications = () => {
  const renderInfoNotification = () => (
    <Notification>
      <MdInfo className="info icon" />
      <div className="message-container">
        <h1 className="message-heading info">Info</h1>
        <p className="description">
          Anyone on the internet can view these files
        </p>
      </div>
    </Notification>
  )

  const renderWarningNotification = () => (
    <Notification>
      <MdWarning className="warning icon" />
      <div className="message-container">
        <h1 className="message-heading warning">Warning</h1>
        <p className="description">
          Viewers of this file can see comments and suggestions
        </p>
      </div>
    </Notification>
  )

  const renderErrorNotification = () => (
    <Notification>
      <RiErrorWarningFill className="error icon" />
      <div className="message-container">
        <h1 className=" message-heading error">Error</h1>
        <p className="description">
          Sorry, you are not authorized to have access to delete the file
        </p>
      </div>
    </Notification>
  )

  const renderSuccessNotification = () => (
    <Notification>
      <AiFillCheckCircle className="success icon" />
      <div className="message-container">
        <h1 className="message-heading success">Success</h1>
        <p className="description">
          You can access all the files in the folder
        </p>
      </div>
    </Notification>
  )

  return (
    <div className="app-container">
      <div className="responsive-container">
        <h1 className="heading">Alert Notifications</h1>
        {renderSuccessNotification()}
        {renderErrorNotification()}
        {renderWarningNotification()}
        {renderInfoNotification()}
      </div>
    </div>
  )
}

export default AlertNotifications

//src/App.js

import AlertNotifications from './components/AlertNotifications'

import './App.css'

const App = () => <AlertNotifications />

export default App

Third-Party Packages | Cheat Sheet:
--------------------------------------------------------------------------------------------

Concepts in Focus:

Third-Party Packages
	- Advantages
	- Selecting a Third-Party Package
	
Third-Party Package react-player
	- React Player Props
	
Reference

1. Third-Party Packages
A Third-Party Package is a reusable code developed to perform a specific functionality

1.1 Advantages

Easy integration
Saves Time
More productivity with fewer lines of code
Better Error Handling
More Customisation Options ... many more.
We have used many third-party packages like React Router, React Loader, React Icons, JWT, etc.

Node Package Manager contains Third-Party Packages for React JS, Node JS, Angular JS, and many more libraries and frameworks. 
To know more about npm you can refer to this. -- https://www.npmjs.com/

1.2 Selecting a Third-Party Package

1.2.1 Things to Consider

Users Satisfaction
Popularity (number of stars)
Maintenance
Documentation
Number of unresolved issues

Compare the packages in the above categories and pick one for the application.

2. Third-Party Package - react-player
NPM contains a react-player, a third-party package that provides a React component for playing a variety of URLs, including file paths, YouTube, Facebook, etc. 

Installation Command:

npm install react-player

2.1 React Player Props
We can provide different props to ReactPlayer. Below are some of the most commonly used props.

Prop				Description																				Default Value
playing			Set to true or false to pause or play the media												false
controls		Set to true to display native player controls.												false
light			Set to true to show the video thumbnail, which loads the full player on click. 
				Pass in an image URL to override the preview image											false
width			Set the width of the player																	640px
height			Set the height of the player																360px
className		Add the custom styles to ReactPlayer														-

Example:

File: src/App.js

import VideoPlayer from './components/VideoPlayer'

import './App.css'

const App = () => <VideoPlayer />

export default App

//src/components/VideoPlayer/index.js

import ReactPlayer from 'react-player'

import './index.css'

const videoURL = 'https://youtu.be/YE7VzlLtp-4'
const VideoPlayer = () => (
  <div className="video-container">
    <h1 className="heading">Video Player</h1>
    <div className="responsive-container">
      <ReactPlayer url={videoURL} />
    </div>
  </div>
)

export default VideoPlayer

ReactPlayer Supports different types of URLs.

2.1.1 controls Prop

//src/components/VideoPlayer/index.js

const VideoPlayer = () => (
  <div className="video-container">
    <h1 className="heading">Video Player</h1>
    <div className="responsive-container">
      <ReactPlayer url={videoURL} controls />
    </div>
  </div>
)
export default VideoPlayer

2.1.2 playing Prop

//src/components/VideoPlayer/index.js

import {Component} from 'react'

import ReactPlayer from 'react-player'

import './index.css'

const videoURL = 'https://youtu.be/YE7VzlLtp-4'

class VideoPlayer extends Component {
  state = {
    isPlaying: false,
  }

  onClickPlay = () => {
    this.setState(prevState => ({isPlaying: !prevState.isPlaying}))
  }

  render() {
    const {isPlaying} = this.state
    const btnText = isPlaying ? 'Pause' : 'Play'

    return (
      <div className="video-container">
        <h1 className="heading">Video Player</h1>
        <div className="responsive-container">
          <ReactPlayer url={videoURL} playing={isPlaying} />
        </div>
        <button type="button" className="button" onClick={this.onClickPlay}>
          {btnText}
        </button>
      </div>
    )
  }
}

export default VideoPlayer

Reference
To know more about react-player, you can refer to this. -- https://www.npmjs.com/package/react-player

Recharts | Reading Material Cheat Sheet:
-------------------------------------------------------------------------------------------------------

https://github.com/recharts/recharts

https://recharts.org/en-US/

Concepts in Focus:

Third-Party Package recharts
	- Advantages
	
Bar Chart

Components in Bar Chart
	- ResponsiveContainer
	- XAxis
	- YAxis
	- Legend
	- Bar
	
Pie Chart

Components in Pie Chart
	- Pie
	- Cell
	
Reference

1. Third-Party Package recharts
NPM contains recharts, a third-party package to display charts in your application.

It supports different types of charts like:

Bar Chart
Pie Chart
Area Chart
Composed Chart, etc.
It supports different types of visualization methods like:

Cartesian:

Area
Bar
Line, etc.

Polar:

Pie
Radar
Radial Bar

Installation Command:

npm install recharts

1.1 Advantages
Responsive
Built for React, from scratch
Customizable

2. Bar Chart
The BarChart Component represents the container of the Bar Chart.

Example:

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Legend,
  ResponsiveContainer,
} from "recharts"

const data = [
  {
    group_name: "Group A",
    boys: 200,
    girls: 400,
  },
  {
    group_name: "Group B",
    boys: 3000,
    girls: 500,
  },
  {
    group_name: "Group C",
    boys: 1000,
    girls: 1500,
  },
  {
    group_name: "Group D",
    boys: 700,
    girls: 1200,
  },
]

const App = () => {
  const DataFormatter = (number) => {
    if (number > 1000) {
      return `${(number / 1000).toString()}k`
    }
    return number.toString()
  }

  return (
    <ResponsiveContainer width="100%" height={500}>
      <BarChart
        data={data}
        margin={{
          top: 5,
        }}
      >
        <XAxis
          dataKey="group_name"
          tick={{
            stroke: "gray",
            strokeWidth: 1,
          }}
        />
        <YAxis
          tickFormatter={DataFormatter}
          tick={{
            stroke: "gray",
            strokeWidth: 0,
          }}
        />
        <Legend
          wrapperStyle={{
            padding: 30,
          }}
        />
        <Bar dataKey="boys" name="Boys" fill="#1f77b4" barSize="20%" />
        <Bar dataKey="girls" name="Girls" fill="#fd7f0e" barSize="20%" />
      </BarChart>
    </ResponsiveContainer>
  )
}

export default App

3. Components in Bar Chart
The recharts supports different Components for the Bar Chart. Below are some of the most commonly used Components.

3.1 ResponsiveContainer
It is a container Component to make charts adapt to the size of the parent container.

Props:

We can provide different props to the ReactJS ResponsiveContainer Component. Below are some of the most commonly used props.

Prop	Default Value
width	'100%' (value can be percentage string or number)
height	'100%' (value can be percentage string or number)

Note
One of the props width and height should be a percentage string in the ResponsiveContainer Component.

3.2 XAxis
The XAxis Component represents the X-Axis of a Chart.

Props:

We can provide different props to the ReactJS XAxis Component. Below are some of the most commonly used props.

Prop			Description																	Default Value
dataKey		The key of the object in data that we want to display it's value on the axis	No default value (value can be string or number)
tick		Represents a tick																No default value. If false - 
																							No ticks will be drawn, object - Configuration of ticks, React element - Custom react element for drawing ticks (value can be boolean, object or React element)
tickFormatter	The formatter function of tick												No default value (Function)

Example - tickFormatter:

If we want to show the thousands in the form of k on the tick, the formatter function would be:

const DataFormatter = (number) => {
  if (number > 1000) {
    return `${(number / 1000).toString()}k`
  }
  return number.toString()
}

3.3 YAxis
The YAxis Component represents the Y-Axis of a Chart.

The Props of the YAxis Component are similar to the XAxis Component.

3.4 Legend
The Legend Component represents the legend of a Chart.

By default, the content of the legend is generated by the name of Line, Bar, Area, etc. If no name has been set, the prop dataKey is used to generate the content of the legend.

Props:

We can provide different props to the ReactJS Legend Component. Below are some of the most commonly used props.

Prop			Description												Default Value
iconType		The type of icon in the legend item						No default value (value can be 'line', 'plainline', 'square', 'rect', 'circle', 'cross', 'diamond','star', 'triangle', or 'wye')
layout			The layout of legend items								'horizontal' (value can be 'horizontal' or 'vertical')
verticalAlign	The alignment of legend items in vertical direction		'middle' (value can be 'top', 'middle', or 'bottom')
align			The alignment of legend items in horizontal direction	'center' (value can be 'left', 'center', or 'right')
wrapperStyle	The style of the legend container						No default value (value can be React Inline styles)

3.5 Bar
The Bar Component represents a bar in the Chart.

Props:

We can provide different props to the ReactJS Bar Component. Below are some of the most commonly used props.

Prop	Description															Default Value
dataKey	The key of the object in data that we want to display it's value	No default value (value can be string or number)
name	The name of the bar													No default value (value can be string or number)
fill	The color to fill the rectangle in a bar							(value can be given color in hexCode or string format)
barSize	The width or height of the bar										No default value (value can be number)

Note
The value of the prop name is used in tooltip and legend to represent a bar/pie. If no value was set, the value of dataKey will be used alternatively.

4. PieChart
The PieChart Component represents the container of the Pie Chart.

Example:

import { PieChart, Pie, Legend, Cell, ResponsiveContainer } from "recharts"

const data = [
  {
    count: 809680,
    language: "Telugu",
  },
  {
    count: 4555697,
    language: "Hindi",
  },
  {
    count: 12345657,
    language: "English",
  },
]

const App = () => {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          cx="70%"
          cy="40%"
          data={data}
          startAngle={0}
          endAngle={360}
          innerRadius="40%"
          outerRadius="70%"
          dataKey="count"
        >
          <Cell name="Telugu" fill="#fecba6" />
          <Cell name="Hindi" fill="#b3d23f" />
          <Cell name="English" fill="#a44c9e" />
        </Pie>
        <Legend
          iconType="circle"
          layout="vertical"
          verticalAlign="middle"
          align="right"
        />
      </PieChart>
    </ResponsiveContainer>
  )
}

export default App

5. Components in Pie Chart
The recharts supports different Components for the Bar Chart. Below are some of the most commonly used Components.

5.1 Pie
The Pie Component represents a pie in the Chart.

Props:

We can provide different props to the ReactJS Pie Component. Below are some of the most commonly used props.

Prop				Description											Default Value
cx			The x-axis coordinate of a center point					'50%'.If set a percentage, the final value is obtained by multiplying the percentage of container width (value can be percentage string or number)
cy			The y-axis coordinate of a center point					'50%'.If set a percentage, the final value is obtained by multiplying the percentage of container height (value can be percentage string or number)
data		The source data in which each element is an object		No default value (value can be Array)
startAngle	The start angle of the first sector						0 (value can be number)
endAngle	The end angle of the last sector, which should be unequal to startAngle	360 (value can be number)
innerRadius	The inner radius of all the sectors										0 (value can be percentage or number)
OuterRadius	The outer radius of all the sectors										0 (value can be percentage or number)
dataKey		The key of the object in data that we want to display it's value on the sector	No default value

Note
If a percentage is set to the props innerRadius or outerRadius, 
the final value is obtained by multiplying the percentage of maxRadius which is calculated by the width, height, cx, and cy.

5.2 Cell
The Cell Component represents the cell of a Chart.

It can be wrapped by a Pie, Bar, or RadialBar Components to specify the attributes of each child.

Props:

We can provide different props to the ReactJS Cell Component. Below are some of the most commonly used props.

Prop	Description	Default Value
name	The name of the cell	No default value (can be a string. This value can be taken as the content of the legend)
fill	The color to fill the cell	(value can be any color in hexCode or string format)

Note
The ResponsiveContainer and Legend Components in Pie Chart are similar to the Components in Bar Chart.

6. Reference
To know more about the recharts, you can refer to this. -- https://github.com/recharts/recharts
https://recharts.org/en-US/

coding practice-37:
----------------------------------------------------------------------------------------------

CoWIN Dashboard:
----------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-CowinDashboard

https://github.com/harsha3072/cowinDashboard

In this project, let's build a CoWIN Dashboard by applying the concepts we have learned till now.

1.Implementation Files

Use these files to complete the implementation:

src/components/CowinDashboard/index.js
src/components/CowinDashboard/index.css
src/components/VaccinationCoverage/index.js
src/components/VaccinationCoverage/index.css
src/components/VaccinationByGender/index.js
src/components/VaccinationByGender/index.css
src/components/VaccinationByAge/index.js
src/components/VaccinationByAge/index.css

2.Important Note
Click to view

The following instructions are required for the tests to pass

Wrap the Loader component with an HTML container element and add the testid attribute value as loader to it

<div testid="loader">
  <Loader type="ThreeDots" color="#ffffff" height={80} width={80} />
</div>

Provide width and height to the respective chart component to make the charts visible on the page 
 For example:

<BarChart width={1000} height={300} />

Provide width and height as number

Achieve this CoWIN Dashboard on desktop devices. You can try different charts provided by the recharts package with customized data

//src/components/CowinDashboard/index.js

import {Component} from 'react'
import Loader from 'react-loader-spinner'

import VaccinationCoverage from '../VaccinationCoverage'
import VaccinationByGender from '../VaccinationByGender'
import VaccinationByAge from '../VaccinationByAge'

import './index.css'

const apiStatusConstants = {
  initial: 'INITIAL',
  success: 'SUCCESS',
  failure: 'FAILURE',
  inProgress: 'IN_PROGRESS',
}

class CowinDashboard extends Component {
  state = {
    apiStatus: apiStatusConstants.initial,
    vaccinationData: {},
  }

  componentDidMount() {
    this.getVaccinationData()
  }

  getVaccinationData = async () => {
    this.setState({
      apiStatus: apiStatusConstants.inProgress,
    })

    const covidVaccinationDataApiUrl =
      'https://apis.ccbp.in/covid-vaccination-data'

    const response = await fetch(covidVaccinationDataApiUrl)
    if (response.ok === true) {
      const fetchedData = await response.json()
      const updatedData = {
        last7DaysVaccination: fetchedData.last_7_days_vaccination.map(
          eachDayData => ({
            vaccineDate: eachDayData.vaccine_date,
            dose1: eachDayData.dose_1,
            dose2: eachDayData.dose_2,
          }),
        ),
        vaccinationByAge: fetchedData.vaccination_by_age.map(range => ({
          age: range.age,
          count: range.count,
        })),
        vaccinationByGender: fetchedData.vaccination_by_gender.map(
          genderType => ({
            gender: genderType.gender,
            count: genderType.count,
          }),
        ),
      }
      this.setState({
        vaccinationData: updatedData,
        apiStatus: apiStatusConstants.success,
      })
    } else {
      this.setState({apiStatus: apiStatusConstants.failure})
    }
  }

  renderFailureView = () => (
    <div className="failure-view">
      <img
        className="failure-image"
        src="https://assets.ccbp.in/frontend/react-js/api-failure-view.png"
        alt="failure view"
      />
      <h1 className="failure-text">Something went wrong</h1>
    </div>
  )

  renderVaccinationStats = () => {
    const {vaccinationData} = this.state

    return (
      <>
        <VaccinationCoverage
          vaccinationCoverageDetails={vaccinationData.last7DaysVaccination}
        />
        <VaccinationByGender
          vaccinationByGenderDetails={vaccinationData.vaccinationByGender}
        />
        <VaccinationByAge
          vaccinationByAgeDetails={vaccinationData.vaccinationByAge}
        />
      </>
    )
  }

  renderLoadingView = () => (
    <div className="loading-view" testid="loader">
      <Loader color="#ffffff" height={80} type="ThreeDots" width={80} />
    </div>
  )

  renderViewsBasedOnAPIStatus = () => {
    const {apiStatus} = this.state

    switch (apiStatus) {
      case apiStatusConstants.success:
        return this.renderVaccinationStats()
      case apiStatusConstants.failure:
        return this.renderFailureView()
      case apiStatusConstants.inProgress:
        return this.renderLoadingView()
      default:
        return null
    }
  }

  render() {
    return (
      <div className="app-container">
        <div className="cowin-dashboard-container">
          <div className="logo-container">
            <img
              className="logo"
              src="https://assets.ccbp.in/frontend/react-js/cowin-logo.png"
              alt="website logo"
            />
            <h1 className="logo-heading">Co-WIN</h1>
          </div>
          <h1 className="heading">CoWIN Vaccination in India</h1>
          {this.renderViewsBasedOnAPIStatus()}
        </div>
      </div>
    )
  }
}

export default CowinDashboard

//src/components/VaccinationCoverage/index.js

import {BarChart, Bar, XAxis, YAxis, Legend} from 'recharts'

import './index.css'

const VaccinationCoverage = props => {
  const dataFormatter = number => {
    if (number > 1000) {
      return `${(number / 1000).toString()}k`
    }
    return number.toString()
  }
  const {vaccinationCoverageDetails} = props

  return (
    <div className="vaccination-by-coverage-container">
      <h1 className="vaccination-by-coverage-heading">Vaccination Coverage</h1>
      <BarChart
        width={900}
        height={400}
        data={vaccinationCoverageDetails}
        margin={{
          top: 5,
        }}
      >
        <XAxis
          dataKey="vaccineDate"
          tick={{
            stroke: '#6c757d',
            strokeWidth: 1,
            fontSize: 15,
            fontFamily: 'Roboto',
          }}
        />
        <YAxis
          tickFormatter={dataFormatter}
          tick={{
            stroke: '#6c757d',
            strokeWidth: 0.5,
            fontSize: 15,
            fontFamily: 'Roboto',
          }}
        />
        <Legend
          wrapperStyle={{
            paddingTop: 20,
            textAlign: 'center',
            fontSize: 12,
            fontFamily: 'Roboto',
          }}
        />
        <Bar
          dataKey="dose1"
          name="Dose 1"
          fill="#5a8dee"
          radius={[10, 10, 0, 0]}
          barSize="20%"
        />
        <Bar
          dataKey="dose2"
          name="Dose 2"
          fill="#f54394"
          radius={[5, 5, 0, 0]}
          barSize="20%"
        />
      </BarChart>
    </div>
  )
}

export default VaccinationCoverage

//src/components/VaccinationByGender/index.js

import {PieChart, Pie, Legend, Cell} from 'recharts'

import './index.css'

const VaccinationByGender = props => {
  const {vaccinationByGenderDetails} = props

  return (
    <div className="vaccination-by-gender-container">
      <h1 className="vaccination-by-gender-heading">Vaccination by gender</h1>
      <PieChart width={1000} height={300}>
        <Pie
          cx="50%"
          cy="60%"
          data={vaccinationByGenderDetails}
          startAngle={180}
          endAngle={0}
          innerRadius="30%"
          outerRadius="60%"
          dataKey="count"
        >
          <Cell name="Male" fill="#f54394" />
          <Cell name="Female" fill="#5a8dee" />
          <Cell name="Others" fill="#2cc6c6" />
        </Pie>
        <Legend
          iconType="circle"
          layout="horizontal"
          verticalAlign="bottom"
          align="center"
          wrapperStyle={{fontSize: 12, fontFamily: 'Roboto'}}
        />
      </PieChart>
    </div>
  )
}

export default VaccinationByGender

//src/components/VaccinationByAge/index.js

import {PieChart, Pie, Legend, Cell} from 'recharts'

import './index.css'

const VaccinationByAge = props => {
  const {vaccinationByAgeDetails} = props

  return (
    <div className="vaccination-by-age-container">
      <h1 className="vaccination-by-age-heading">Vaccination by age</h1>
      <PieChart width={1000} height={300}>
        <Pie
          data={vaccinationByAgeDetails}
          cx="50%"
          cy="30%"
          outerRadius="60%"
          dataKey="count"
        >
          <Cell name="18-44" fill="#2d87bb" />
          <Cell name="44-60" fill="#a3df9f" />
          <Cell name="Above 60" fill="#64C2A6" />
        </Pie>

        <Legend
          iconType="circle"
          layout="horizontal"
          verticalAlign="bottom"
          align="center"
          wrapperStyle={{fontSize: 12, fontFamily: 'Roboto'}}
        />
      </PieChart>
    </div>
  )
}

export default VaccinationByAge

//src/App.js

import CowinDashboard from './components/CowinDashboard'

import './App.css'

const App = () => <CowinDashboard />

export default App

React Chrono | Reading Material cheat sheet:
-----------------------------------------------------------------------------------------------------------------------------

https://www.npmjs.com/package/react-chrono

Concepts in Focus:

Third-Party Package react-chrono
	- Advantages
	
Chrono Props
	- mode
	- items
	- theme
	
Rendering Custom Content

Reference

1. Third-Party Package react-chrono
NPM contains a react-chrono, a third-party package to display the timeline in your application.

It provides a React component Chrono to build a timeline that displays events chronologically.

Installation Command:

npm install react-chrono

1.1 Advantages
Can render the timelines in three different modes (horizontal, vertical, and tree).
Can autoplay the timeline with slideshow mode.
Can navigate the timeline via keyboard.

2. Chrono Props
We can provide different props to the ReactJS Chrono component. Below are some of the most commonly used props.

Prop	Description							Default Value
mode	Sets the mode of the component		'HORIZONTAL' (value can be 'HORIZONTAL', 'VERTICAL' or 'VERTICAL_ALTERNATING')
items	Collection of Timeline Item Model		[]
theme	Customises the colors					No default value

2.1 mode
Example:

<Chrono mode="VERTICAL" />

2.2 items
The items prop is used to build the timeline. It is a collection of the Timeline Item Model.

Timeline Item Model is an object consist of the given properties:

Name				Description												Type
title				title of the timeline item								String
cardTitle			title of the timeline card								String
cardSubtitle		text of the timeline card								String
cardDetailedText	detailed text of the timeline card						String or String[]
media				media object to set image or video						Object

Example:

.chrono-container {
  width: 500px;
  height: 400px;
}

import {Chrono} from 'react-chrono'

const items = [
  {
    title: 'May 1940',
    cardTitle: 'Dunkirk',
    cardSubtitle: 'Men of the British Expeditionary Force.',
    cardDetailedText:
      'On 10 May 1940, Hitler began his long-awaited offensive in the west by invading neutral Holland and attacking northern France.',
  },
]

const App = () => (
  <div className="chrono-container">
    <Chrono items={items} />
  </div>
)

export default App

Warning
If any property misses in the Timeline Item Model, the respective value won't be displayed in the timeline item.

Note
The Chrono Component should be wrapped in a container that has a width and height.

2.3 theme
The colors can be customized with the theme prop.

Example:

<Chrono
  theme={{
    primary: "red",
    secondary: "blue",
    cardBgColor: "yellow",
    cardForeColor: "violet",
    titleColor: "red",
  }}
/>

3. Rendering Custom Content
The custom content can be inserted by just passing the elements between the Chrono tags.

Example:

The below example will create two timeline items.

.chrono-container {
  width: 400px;
  height: 600px;
}

.image {
  width: 200px;
  height: 200px;
}

import {Chrono} from 'react-chrono'

const App = () => (
  <div className="chrono-container">
    <Chrono mode="VERTICAL">
      <div>
        <img
          src="https://assets.ccbp.in/frontend/react-js/csk-logo-img.png"
          className="image"
          alt="chennai-super-kings"
        />
      </div>
      <div>
        <h1>Mumbai Indians</h1>
        <p>IPL Team winner for the year 2019 is Mumbai Indians.</p>
      </div>
    </Chrono>
  </div>
)

export default App

Note
The items prop is optional and custom rendering is supported on all three modes.

Example:

The below example will set the title for the custom contents.

.chrono-container {
  width: 400px;
  height: 600px;
}

.image {
  width: 200px;
  height: 200px;
}

JSS:

import {Chrono} from 'react-chrono'

const items = [{title: '2018'}, {title: '2019'}]

const App = () => (
  <div className="chrono-container">
    <Chrono mode="VERTICAL" items={items}>
      <img
        src="https://assets.ccbp.in/frontend/react-js/csk-logo-img.png"
        className="image"
        alt="chennai-super-kings"
      />
      <div>
        <h1>Mumbai Indians</h1>
        <p>IPL Team winner for the year 2019 is Mumbai Indians.</p>
      </div>
    </Chrono>
  </div>
)

export default App

4. Reference
To know more about the react-chrono, you can refer to this. -- https://www.npmjs.com/package/react-chrono

coding practice-38:
-----------------------------------------------------------------------------------------------------------------

CCBP Timeline:
--------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-CCBPTimeline

In this project, let's build a CCBP Timeline by applying the concepts we have learned till now.

1.Implementation Files

Use these files to complete the implementation:

src/components/TimelineView/index.js
src/components/TimelineView/index.css
src/components/CourseTimelineCard/index.js
src/components/CourseTimelineCard/index.css
src/components/ProjectTimelineCard/index.js
src/components/ProjectTimelineCard/index.css

2.Important Note
Click to view

To build this project, take a look at the React Chrono reading material
The following instructions are required for the tests to pass

AiFillClockCircle, AiFillCalendar icons from react-icons should be used for clock and calender icons in card respectively

//src/components/TimelineView/index.js

import {Chrono} from 'react-chrono'

import ProjectTimelineCard from '../ProjectTimelineCard'
import CourseTimelineCard from '../CourseTimelineCard'

import {
  TimelineContainer,
  ResponsiveContainer,
  HeaderContainer,
  Heading,
  CCBPHeading,
} from './styledComponents'

const TimelineView = props => {
  const {timelineItemsList} = props

  const renderTimelineCard = item => {
    if (item.categoryId === 'PROJECT') {
      return <ProjectTimelineCard key={item.id} projectDetails={item} />
    }
    return <CourseTimelineCard key={item.id} courseDetails={item} />
  }

  return (
    <TimelineContainer>
      <ResponsiveContainer>
        <HeaderContainer>
          <Heading>
            MY JOURNEY OF <br />
            <CCBPHeading>CCBP 4.0</CCBPHeading>
          </Heading>
        </HeaderContainer>
        <Chrono
          theme={{
            secondary: 'white',
          }}
          items={timelineItemsList}
          mode="VERTICAL_ALTERNATING"
        >
          {timelineItemsList.map(eachItem => renderTimelineCard(eachItem))}
        </Chrono>
      </ResponsiveContainer>
    </TimelineContainer>
  )
}

export default TimelineView

//src/components/TimelineView/styledComponents.js 

// Style your elements here
import styled from 'styled-components/macro'

export const TimelineContainer = styled.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
  min-height: 100vh;
`

export const ResponsiveContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  max-width: 1110px;
  height: 100vh;
`

export const HeaderContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 30px;
`

export const Heading = styled.h1`
  text-align: center;
  color: #171f46;
  font-family: 'Roboto';
  font-weight: 500;
  font-size: 18px;
  line-height: 2.7;
  margin: 0px;
  @media screen and (min-width: 768px) {
    font-size: 20px;
  }
`

export const CCBPHeading = styled.span`
  color: #2b237c;
  font-family: 'Roboto';
  font-weight: 500;
  font-size: 24px;
  margin: 0px;
  @media screen and (min-width: 768px) {
    font-size: 30px;
  }
`

//src/components/CourseTimelineCard/index.js

import {AiFillClockCircle} from 'react-icons/ai'

import {
  CourseTitleAndDurationContainer,
  CourseTitle,
  DurationContainer,
  Duration,
  CourseDescription,
  CourseTagsList,
  CourseTagItem,
  CourseTag,
} from './styledComponents'

const CourseTimelineCard = props => {
  const {courseDetails} = props
  const {courseTitle, description, duration, tagsList} = courseDetails

  return (
    <>
      <CourseTitleAndDurationContainer>
        <CourseTitle>{courseTitle}</CourseTitle>
        <DurationContainer>
          <AiFillClockCircle color="#171f46" />
          <Duration>{duration}</Duration>
        </DurationContainer>
      </CourseTitleAndDurationContainer>
      <CourseDescription>{description}</CourseDescription>
      <CourseTagsList>
        {tagsList.map(eachTag => (
          <CourseTagItem key={eachTag.id}>
            <CourseTag>{eachTag.name}</CourseTag>
          </CourseTagItem>
        ))}
      </CourseTagsList>
    </>
  )
}

export default CourseTimelineCard

//src/components/ProjectTimelineCard/index.css

import {AiFillCalendar} from 'react-icons/ai'

import {
  ProjectCardContainer,
  ProjectImage,
  ProjectTitleAndDurationContainer,
  ProjectTitle,
  DurationContainer,
  Duration,
  ProjectDescription,
  VisitLink,
} from './styledComponents'

const ProjectTimelineCard = props => {
  const {projectDetails} = props
  const {
    imageUrl,
    projectTitle,
    description,
    projectUrl,
    duration,
  } = projectDetails

  return (
    <ProjectCardContainer>
      <ProjectImage src={imageUrl} alt="project" />
      <ProjectTitleAndDurationContainer>
        <ProjectTitle>{projectTitle}</ProjectTitle>
        <DurationContainer>
          <AiFillCalendar color="#171f46" />
          <Duration>{duration}</Duration>
        </DurationContainer>
      </ProjectTitleAndDurationContainer>
      <ProjectDescription>{description}</ProjectDescription>
      <VisitLink href={projectUrl}>Visit</VisitLink>
    </ProjectCardContainer>
  )
}

export default ProjectTimelineCard

React Slick | Reading Material:
-----------------------------------------------------------------------------------------------------------------------------------

https://react-slick.neostack.com/docs/get-started/

Concepts in Focus:

Third-Party Package react-slick
	- Advantages
	
Slider Props

Reference

1. Third-Party Package - react-slick
NPM contains a react-slick, a third-party package that provides a React component Slider to add a carousel to your application.

Installation Command:

npm install react-slick

Also, install slick-carousel for CSS and font

npm install slick-carousel

1.1 Advantages
Easy to use
Highly customizable
More performant

2. Slider Props
We can provide different props to the Slider component. Below are the most commonly used props.

Prop			Description												Default Value
slidesToShow	Specifies the number of slides to show in one frame			1
dots			If set to false, no dots will display under the carousel	true
slidesToScroll	Specifies the number of slides to scroll at once			1
dotsClass		CSS class for styling dots									"slick-dots"
Example:

//src/components/ReactSlick/index.js

import Slider from 'react-slick'

import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'

import './index.css'

const ReactSlick = () => {
  const settings = {
    dots: true,
    slidesToShow: 1,
    slidesToScroll: 1,
  }
  return (
    <div className="slider-container">
      <Slider {...settings}>
        <div>
          <h3>1</h3>
        </div>
        <div>
          <h3>2</h3>
        </div>
        <div>
          <h3>3</h3>
        </div>
        <div>
          <h3>4</h3>
        </div>
      </Slider>
    </div>
  )
}

export default ReactSlick

//src/components/ReactSlick/index.css

.slider-container {
        background-color: #419be0;
        padding: 40px;
}

//src/App.js

import ReactSlick from './components/ReactSlick'

const App = () => {
  return <ReactSlick />
}
export default App

Reference
To know more about the react-slick, you can refer to this. -- https://react-slick.neostack.com/docs/get-started/

coding practice-39:
-----------------------------------------------------------------------------------------------------

Planets App:
------------------------------------------------

https://github.com/harsha3072/plantsApp

In this project, let's build a Planets App by applying the concepts we have learned till now.

1.Implementation Files

Use these files to complete the implementation:

src/components/PlanetsSlider/index.js
src/components/PlanetsSlider/index.css
src/components/PlanetItem/index.js
src/components/PlanetItem/index.css

2.Important Note
Click to view

To build this project, take a look at the React Slick reading material
The following instructions are required for the tests to pass

The planets should have the alt as the value of the key name from planet objects in the planetsList
The app should consist of an HTML container element with testid as planets

//src/components/PlanetItem/index.js

import './index.css'

const PlanetItem = props => {
  const {planetDetails} = props
  const {name, imageUrl, description} = planetDetails

  return (
    <div className="planet-container">
      <img className="image" src={imageUrl} alt={`planet ${name}`} />
      <h1 className="name">{name}</h1>
      <p className="description">{description}</p>
    </div>
  )
}

export default PlanetItem

//src/components/PlanetsSlider/index.js

import Slider from 'react-slick'

import PlanetItem from '../PlanetItem'

import './index.css'

const PlanetsSlider = props => {
  const {planetsList} = props

  return (
    <div className="planets-app-container" testid="planets">
      <h1 className="heading">PLANETS</h1>
      <Slider>
        {planetsList.map(eachPlanet => (
          <PlanetItem key={eachPlanet.id} planetDetails={eachPlanet} />
        ))}
      </Slider>
    </div>
  )
}

export default PlanetsSlider

//src/App.js

import PlanetsSlider from './components/PlanetsSlider'

import './App.css'

const planetsList = [
  {
    id: 'c22777fe-f72e-11eb-9a03-0242ac130003',
    name: 'Mercury',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/planets-app/mercury-img.png',
    description:
      'Mercury is the smallest planet in the Solar System and the closest to the Sun. Its orbit around the Sun takes 87.97 Earth days, the shortest of all the Sun planets.',
  },
  {
    id: 'c2277a74-f72e-11eb-9a03-0242ac130003',
    name: 'Venus',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/planets-app/venus-img.png',
    description:
      'Venus is the second planet from the Sun and is Earth’s closest planetary neighbor. It’s one of the four inner, terrestrial (or rocky) planets, and it’s often called Earth’s twin because it’s similar in size and density. These are not identical twins, however – there are radical differences between the two worlds.',
  },
  {
    id: 'c2277b64-f72e-11eb-9a03-0242ac130003',
    name: 'Earth',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/planets-app/earth-img.png',
    description:
      'Earth is the third planet from the Sun and the only astronomical object known to harbor and support life. About 29.2% of Earth’s surface is land consisting of continents and islands.',
  },
  {
    id: 'c2277c2c-f72e-11eb-9a03-0242ac130003',
    name: 'Mars',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/planets-app/mars-img.png',
    description:
      'Mars is the fourth planet from the Sun and the second-smallest planet in the Solar System, being larger than only Mercury.',
  },
  {
    id: 'c2277cea-f72e-11eb-9a03-0242ac130003',
    name: 'Jupiter',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/planets-app/jupiter-img.png',
    description:
      'Jupiter has a long history of surprising scientists – all the way back to 1610 when Galileo Galilei found the first moons beyond Earth. That discovery changed the way we see the universe.',
  },
  {
    id: 'c2277d9e-f72e-11eb-9a03-0242ac130003',
    name: 'Saturn',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/planets-app/saturn-img.png',
    description:
      'Saturn is the sixth planet from the Sun and the second-largest planet in our solar system. Adorned with a dazzling system of icy rings, Saturn is unique among the planets. It is not the only planet to have rings, but none are as spectacular or as complex as Saturn’s.',
  },
  {
    id: 'c2277e52-f72e-11eb-9a03-0242ac130003',
    name: 'Uranus',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/planets-app/uranus-img.png',
    description:
      'Uranus is the seventh planet from the Sun and has the third-largest diameter in our solar system. It was the first planet found with the aid of a telescope, Uranus was discovered in 1781 by astronomer William Herschel, although he originally thought it was either a comet or a star.',
  },
  {
    id: 'c2277f06-f72e-11eb-9a03-0242ac130003',
    name: 'Neptune',
    imageUrl:
      'https://assets.ccbp.in/frontend/react-js/planets-app/neptune-img.png',
    description:
      'Dark, cold, and whipped by supersonic winds, ice giant Neptune is the eighth and most distant planet in our solar system.',
  },
]

const App = () => <PlanetsSlider planetsList={planetsList} />

export default App

React Popup | Reading Material:
------------------------------------------------------------------------------------------

https://react-popup.elazizi.com/component-api/

Concepts in Focus:

Third-Party Package reactjs-popup
	- Advantages
	
ReactJS Popup Props

Reference

1. Third-Party Package reactjs-popup
NPM contains a reactjs-popup, a third-party package to display popup in your application.

It provides a React component that helps you create simple and complex Modals, Tooltips, and Menus for your application.

Installation Command:

npm install reactjs-popup

1.1 Advantages
ReactJS provides Modal, Tooltip, and Menu
Provides Support for controlled Modals & Tooltips

2. ReactJS Popup Props
We can provide different props to the ReactJS Popup component. Below are some of the most commonly used props.

Prop			Description																												Default Value
trigger			Represents the element to be rendered in-place where the Popup is defined												JSX element
modal			When set to true, Popup content will be displayed as a modal on the trigger of Popup. If not tooltip will be displayed	false
position		Defines the position of the tooltip. It can be one of 'top left', 'top right', 'bottom right', 'bottom left'			bottom ,center
open			Defines the state of Popup. Whether it is opened or not																	false
overlayStyle	Custom overlay style																									object

2.1 trigger Prop

//src/components/ReactPopup/index.js

import Popup from 'reactjs-popup'

import 'reactjs-popup/dist/index.css'

import './index.css'

const ReactPopUp = () => (
 <div className="popup-container">
   <Popup
     trigger={
       <button className="trigger-button" type="button">
         Trigger
       </button>
     }
   >
     <div>
       <p>React is a popular and widely used programming language</p>
     </div>
   </Popup>
 </div>
)
export default ReactPopUp

//src/components/ReactPopup/index.css

.trigger-button {
 font-size: 16px;
 font-weight: 400;
 font-family: 'Roboto';
 color: white;
 padding: 8px 15px 8px 15px;
 margin: 8px;
 background-color: #7c69e9;
 border: none;
 border-radius: 4px;
 outline: none;
}
.popup-container {
 display: flex;
 align-items: center;
 justify-content: center;
 height: 100vh;
}

//src/App.js

import ReactPopup from './components/ReactPopup'

const App = () => {
 return <ReactPopup />
}
export default App

Note
The value of the trigger prop should be a JSX element.

2.2 modal Prop

//src/components/ReactPopup/index.js

const ReactPopUp = () => (
 <div className="popup-container">
   <Popup
     modal
     trigger={
       <button type="button" className="trigger-button">
         Trigger
       </button>
     }
   >
     <p>React is a popular and widely used programming language</p>
   </Popup>
 </div>
)
export default ReactPopUp

2.3 modal Prop with close button

//src/components/ReactPopup/index.js

const ReactPopUp = () => (
 <div className="popup-container">
   <Popup
     modal
     trigger={
       <button type="button" className="trigger-button">
         Trigger
       </button>
     }
   >
     {close => (
       <>
         <div>
           <p>React is a popular and widely used programming language</p>
         </div>
         <button
           type="button"
           className="trigger-button"
           onClick={() => close()}
         >
           Close
         </button>
       </>
     )}
   </Popup>
 </div>
)
export default ReactPopUp

2.4 position Prop

//src/components/ReactPopup/index.js

const ReactPopUp = () => (
 <div className="popup-container">
   <Popup
     trigger={
       <button type="button" className="trigger-button">
         Trigger
       </button>
     }
     position="bottom left"
   >
     <p>React is a popular and widely used programming language</p>
   </Popup>
 </div>
)
export default ReactPopUp

2.5 overlayStyle Prop

//src/components/ReactPopup/index.js

const overlayStyles = {
 backgroundColor: '#ffff',
}
const ReactPopUp = () => (
 <div className="popup-container">
   <Popup
     modal
     trigger={
       <button type="button" className="trigger-button">
         Trigger
       </button>
     }
     overlayStyle={overlayStyles}
   >
     <p>React is a popular and widely used programming language</p>
   </Popup>
 </div>
)
export default ReactPopUp

Reference
To know more about the reactjs-popup, you can refer to this. -- https://react-popup.elazizi.com/component-api/

coding practice-40:
---------------------------------------------------------------------------------

Hamburger Menu:
----------------------------------------------------

https://github.com/GangadharDevloper/hamburgerMenu

In this project, let's build a Hamburger Menu app by applying the concepts we have learned till now.

1.Implementation Files

Use these files to complete the implementation:

src/App.js
src/components/Header/index.js
src/components/Header/index.css
src/components/Home/index.js
src/components/Home/index.css
src/components/About/index.js
src/components/About/index.css
src/components/NotFound/index.js
src/components/NotFound/index.css

2.Quick Tips
Click to view

To build this project, take a look at the React Popup reading material

To style popup content use .popup-content class

<Popup
  modal
  trigger={
    //write code here
  }
  className="popup-content"
>
  //write code here
</Popup>

//src/components/Header/index.js

import Popup from 'reactjs-popup'
import {withRouter, Link} from 'react-router-dom'
import {GiHamburgerMenu} from 'react-icons/gi'
import {IoMdClose} from 'react-icons/io'
import {AiFillHome} from 'react-icons/ai'
import {BsInfoCircleFill} from 'react-icons/bs'

import './index.css'

const Header = () => (
  <div className="nav-header">
    <div className="nav-content">
      <Link to="/">
        <img
          className="website-logo"
          src="https://assets.ccbp.in/frontend/react-js/hamburger-menu-website-logo.png"
          alt="website logo"
        />
      </Link>
      <Popup
        modal
        trigger={
          <button
            className="hamburger-icon-button"
            type="button"
            testid="hamburgerIconButton"
          >
            <GiHamburgerMenu size="30" />
          </button>
        }
        className="popup-content"
      >
        {close => (
          <div className="modal-container">
            <button
              className="close-button"
              type="button"
              testid="closeButton"
              onClick={() => close()}
            >
              <IoMdClose size="30" color="#616e7c" />
            </button>
            <ul className="nav-links-list">
              <li className="nav-link-item">
                <Link className="nav-link" to="/" onClick={() => close()}>
                  <AiFillHome size="36" />
                  <p className="nav-link-content">Home</p>
                </Link>
              </li>
              <li className="nav-link-item">
                <Link className="nav-link" to="/about" onClick={() => close()}>
                  <BsInfoCircleFill size="32" />
                  <p className="nav-link-content">About</p>
                </Link>
              </li>
            </ul>
          </div>
        )}
      </Popup>
    </div>
  </div>
)

export default withRouter(Header)

//src/components/Home/index.js

import Header from '../Header'

import './index.css'

const Home = () => (
  <div className="home-container">
    <Header />
    <div className="home-image-container">
      <img
        className="mobile-home-image"
        src="https://assets.ccbp.in/frontend/react-js/home-sm-img.png"
        alt="home"
      />
      <img
        className="desktop-home-image"
        src="https://assets.ccbp.in/frontend/react-js/home-lg-img.png"
        alt="home"
      />
    </div>
  </div>
)

export default Home

//src/components/About/index.js

import Header from '../Header'

import './index.css'

const About = () => (
  <div className="about-container">
    <Header />
    <div className="about-image-container">
      <img
        className="mobile-about-image"
        src="https://assets.ccbp.in/frontend/react-js/about-sm-img.png"
        alt="About"
      />
      <img
        className="desktop-about-image"
        src="https://assets.ccbp.in/frontend/react-js/about-lg-img.png"
        alt="About"
      />
    </div>
  </div>
)

export default About

//src/components/NotFound/index.js

import Header from '../Header'

import './index.css'

const NotFound = () => (
  <div className="not-found-container">
    <Header />
    <div className="not-found-content-container">
      <div className="not-found-responsive-container">
        <img
          className="image"
          src="https://assets.ccbp.in/frontend/react-js/not-found-img.png"
          alt="not found"
        />
        <h1 className="heading">Lost Your Way?</h1>
        <p className="description">
          Sorry, we cannot find that page. You will find lots to explore on the
          home page
        </p>
      </div>
    </div>
  </div>
)

export default NotFound

//src/App.js

import {Route, Switch, Redirect} from 'react-router-dom'

import Home from './components/Home'
import About from './components/About'
import NotFound from './components/NotFound'

import './App.css'

const App = () => (
  <Switch>
    <Route exact path="/" component={Home} />
    <Route exact path="/about" component={About} />
    <Route exact path="/not-found" component={NotFound} />
    <Redirect to="not-found" />
  </Switch>
)

export default App

Prime Video:
------------------------------------------------------

In this project, let's build a Prime Video by applying the concepts we have learned till now.

https://github.com/GangadharDevloper/primeVideo

//src/components/PrimeVideo/index.js

import MoviesSlider from '../MoviesSlider'

import './index.css'

const actionMovie = 'ACTION'
const comedyMovie = 'COMEDY'

const PrimeVideo = props => {
  const {moviesList} = props
  const actionMoviesList = moviesList.filter(
    movie => movie.categoryId === actionMovie,
  )

  const comedyMoviesList = moviesList.filter(
    movie => movie.categoryId === comedyMovie,
  )

  return (
    <div className="prime-video-container">
      <img
        className="image"
        src="https://assets.ccbp.in/frontend/react-js/prime-video-img.png"
        alt="prime video"
      />
      <div className="movies-container">
        <h1 className="movies-heading">Action Movies</h1>
        <MoviesSlider moviesList={actionMoviesList} />
        <h1 className="movies-heading">Comedy Movies </h1>
        <MoviesSlider moviesList={comedyMoviesList} />
      </div>
    </div>
  )
}

export default PrimeVideo

//src/components/MoviesSlider/index.js

import Slider from 'react-slick'

import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'

import MovieItem from '../MovieItem'

const MoviesSlider = props => {
  const settings = {
    dots: false,
    slidesToScroll: 1,
    slidesToShow: 4,
  }
  const {moviesList} = props

  return (
    <>
      <Slider {...settings}>
        {moviesList.map(eachMovie => (
          <MovieItem key={eachMovie.id} movieDetails={eachMovie} />
        ))}
      </Slider>
    </>
  )
}

export default MoviesSlider

//src/components/MovieItem/index.js

import Popup from 'reactjs-popup'
import ReactPlayer from 'react-player'
import {IoMdClose} from 'react-icons/io'

import 'reactjs-popup/dist/index.css'

import './index.css'

const MovieItem = props => {
  const {movieDetails} = props
  const {thumbnailUrl, videoUrl} = movieDetails

  return (
    <div>
      <Popup
        modal
        trigger={
          <img className="thumbnail" src={thumbnailUrl} alt="thumbnail" />
        }
        className="popup-content"
      >
        {close => (
          <div className="modal-container">
            <button
              className="close-button"
              type="button"
              testid="closeButton"
              onClick={() => close()}
            >
              <IoMdClose size={20} color="#231f20" />
            </button>
            <div className="movie-player-container">
              <ReactPlayer url={videoUrl} controls />
            </div>
          </div>
        )}
      </Popup>
    </div>
  )
}

export default MovieItem

Assignment-5: -- many concepts
------------------------------------------------------------------------------------

Jobby App:
---------------------------------------
***
https://github.com/ManirathnamKuruma/ReactJS-JobbyApp -- imp

React Context | Cheat Sheet:
------------------------------------------------------------------------------------

Concepts in Focus:

Prop Drilling

React Context
	- Creating Context
	- Context Properties
	- How to Access the Value?
	
Consumer Component
	- Understanding Syntax
	
Windows App Example
	- Initial Code
	- Final Code

Google Translator

1. Prop Drilling
Props are passed from one Component to another Component that does not need the data but only helps in passing it through the tree is called Prop Drilling.

2. React Context
Context is a mechanism that provides different Components and allows us to pass data without doing prop drilling.

2.1 Creating Context

Syntax:

React.createContext(INITIAL_VALUE)

It returns an object with different properties to update and access values from the context.

2.2 Context Properties
The Context object provides two properties.

1. Consumer
2. Provider

2.3 How to Access the Value?
We can access the value in the Context using Consumer Component provided by the Context Object.

3. Consumer Component
Syntax:

<ContextObject.Consumer>
  {/*callback function*/}
</ContextObject.Consumer>

We access the Consumer component using dot notation from the context object.
We will give a callback function as children for Consumer Component.

3.1 Understanding Syntax
 The callback function receives the current context value as an argument and returns a component or a JSX element.
 
4. Windows App Example
4.1 Initial Code
 Run the below command in your IDE to download the initial code.
 
 ccbp start RJSIVWKZP2
 
4.2 Final Code
 Run the below command in your IDE to download the final code.
 
ccbp start RJSIVM06DJ

5. Google Translator
In the Windows App example, we are using three different languages to display the text.
You can translate one language to another language using google translator.
Check google translator website here .

Initial code:
-----------------------------------

//react-context/src/components/FeaturesSection/index.js

import Playtime from '../Playtime'
import NewWaysToConnect from '../NewWaysToConnect'

import './index.css'

const FeaturesSection = props => {
  const {activeLanguage} = props
  return (
    <div className="features-section-container">
      <Playtime activeLanguage={activeLanguage} />
      <NewWaysToConnect activeLanguage={activeLanguage} />
    </div>
  )
}

export default FeaturesSection

//react-context/src/components/FeaturesSection/index.css

.features-section-container {
  max-width: 1110px;
  width: 90%;
  margin: auto;
  display: flex;
  flex-direction: column;
  padding-top: 40px;
  padding-bottom: 40px;
}

@media screen and (min-width: 768px) {
  .features-section-container {
    font-size: 30px;
    justify-content: space-between;
    flex-direction: row;
    line-height: 1.42;
    text-align: left;
  }
}

//src/components/Header/index.js

import './index.css'

const languageOptions = [
  {id: 1, value: 'EN', language: 'English'},
  {id: 2, value: 'HI', language: 'हिंदी'},
  {id: 3, value: 'TE', language: 'తెలుగు'},
]

const Header = props => {
  const {activeLanguage, changeLanguage} = props

  const onChangeLanguage = event => {
    changeLanguage(event.target.value)
  }

  return (
    <nav className="nav-header">
      <img
        className="website-logo"
        src="https://assets.ccbp.in/frontend/react-js/windows-logo-img.png"
        alt="website logo"
      />
      <select
        className="language-dropdown"
        value={activeLanguage}
        onChange={onChangeLanguage}
      >
        {languageOptions.map(eachOption => (
          <option key={eachOption.id} value={eachOption.value}>
            {eachOption.language}
          </option>
        ))}
      </select>
    </nav>
  )
}

export default Header

//src/components/Header/index.css

.nav-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 64px;
  max-width: 1110px;
  width: 90%;
  margin: auto;
}

.website-logo {
  width: 110px;
}

@media screen and (min-width: 768px) {
  .website-logo {
    width: 140px;
  }
}

.language-dropdown {
  font-size: 14px;
  color: #475569;
  font-weight: 500;
  line-height: 1.42;
  padding: 6px 12px 6px 4px;
  background-color: #ffffff;
  border: 1px solid #94a3b8;
  box-sizing: border-box;
  border-radius: 8px;
  cursor: pointer;
  outline: none;
}

@media screen and (min-width: 768px) {
  .language-dropdown {
    padding: 8px 16px 8px 4px;
  }
}

//src/components/LandingSection/index.js

import './index.css'

const landingSectionContent = {
  EN: {
    heading: 'Windows 11',
    description:
      'Windows 11 provides a calm and creative space where you can pursue your passions through a fresh experience. From a rejuvenated Start menu to new ways to connect to your favorite people, news, games, and content. Windows  is the place to think, express, and create in a natural way.',
  },
  HI: {
    heading: 'विंडोज 11',
    description:
      'विंडोज 11 एक शांत और रचनात्मक स्थान प्रदान करता है जहां आप एक नए अनुभव के माध्यम से अपने जुनून को आगे बढ़ा सकते हैं। अपने पसंदीदा लोगों, समाचारों, गेमों और सामग्री से जुड़ने के नए तरीकों से एक नए सिरे से शुरू किए गए स्टार्ट मेनू से विंडोज एक प्राकृतिक तरीके से सोचने, व्यक्त करने और बनाने का स्थान है।',
  },
  TE: {
    heading: 'విండోస్ 11',
    description:
      'విండోస్ 11 ప్రశాంతమైన మరియు సృజనాత్మక స్థలాన్ని అందిస్తుంది, ఇక్కడ మీరు మీ అభిరుచులను తాజా అనుభవం ద్వారా కొనసాగించవచ్చు. పునరుజ్జీవింపబడిన ప్రారంభ మెను నుండి మీకు ఇష్టమైన వ్యక్తులు, వార్తలు, ఆటలు మరియు కంటెంట్‌తో కనెక్ట్ అవ్వడానికి కొత్త మార్గాల వరకు విండోస్ అనేది సహజంగా ఆలోచించే, వ్యక్తీకరించే మరియు సృష్టించే ప్రదేశం.',
  },
}

const LandingSection = props => {
  const getLandingSectionData = activeLanguage => {
    switch (activeLanguage) {
      case 'EN':
        return landingSectionContent.EN
      case 'HI':
        return landingSectionContent.HI
      case 'TE':
        return landingSectionContent.TE
      default:
        return null
    }
  }
  const {activeLanguage} = props
  const {heading, description} = getLandingSectionData(activeLanguage)
  return (
    <div className="bg-container">
      <div className="responsive-container">
        <div className="description-container">
          <h1 className="heading">{heading}</h1>
          <p className="description">{description}</p>
        </div>
        <img
          className="logo-white"
          src="https://assets.ccbp.in/frontend/react-js/windows-logo-white-img.png"
          alt="windows logo"
        />
      </div>
    </div>
  )
}

export default LandingSection

//src/components/LandingSection/index.css

.bg-container {
  display: flex;
  justify-content: center;
  background-color: #0078fc;
}

.responsive-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: 1110px;
  width: 90%;
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #0078fc;
}

@media screen and (min-width: 768px) {
  .responsive-container {
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  }
}

.logo-white {
  width: 150px;
  height: 150px;
  order: -1;
  margin-bottom: 15px;
}

@media screen and (min-width: 768px) {
  .logo-white {
    width: 260px;
    height: 260px;
    order: 1;
    margin-bottom: 0;
    margin-left: 50px;
  }
}

.heading {
  font-family: 'Roboto';
  font-size: 36px;
  font-weight: 500;
  line-height: 1.3;
  color: #ffffff;
  margin: 0;
  text-align: center;
}

@media screen and (min-width: 768px) {
  .heading {
    font-size: 42px;
    text-align: left;
  }
}

.description-container {
  width: 95%;
  max-width: 400px;
  text-align: center;
}

@media screen and (min-width: 768px) {
  .description-container {
    width: 60%;
    max-width: 500px;
    text-align: left;
  }
}

.description {
  font-family: 'Roboto';
  font-size: 16px;
  line-height: 1.42;
  color: #ffffff;
  margin-top: 10px;
}

@media screen and (min-width: 768px) {
  .description {
    font-size: 18px;
    line-height: 1.42;
  }
}


//src/components/NewWaysToConnect/index.js

import './index.css'

const newWaysToConnectContent = {
  EN: {
    heading: 'New ways to connect',
    description:
      'Connect instantly to the people you care about right from your desktop with Microsoft Teams. Call or chat for free, no matter what device they’re on.',
  },
  HI: {
    heading: 'कनेक्ट करने के नए तरीके',
    description:
      'माइक्रोसॉफ्ट टीमों के साथ सीधे अपने डेस्कटॉप से ​​उन लोगों से तुरंत कनेक्ट हों जिनकी आप परवाह करते हैं। कॉल करें या निःशुल्क चैट करें—चाहे वे किसी भी डिवाइस पर हों।',
  },
  TE: {
    heading: 'కనెక్ట్ చేయడానికి కొత్త మార్గాలు',
    description:
      'మైక్రోసాఫ్ట్ బృందాలతో మీ డెస్క్‌టాప్ నుండి మీరు శ్రద్ధ వహించే వ్యక్తులతో తక్షణమే కనెక్ట్ అవ్వండి. అవి ఏ పరికరంలో ఉన్నా సరే ఉచితంగా కాల్ చేయండి లేదా చాట్ చేయండి',
  },
}

const NewWaysToConnect = props => {
  const getNewWaysToConnectData = activeLanguage => {
    switch (activeLanguage) {
      case 'EN':
        return newWaysToConnectContent.EN
      case 'HI':
        return newWaysToConnectContent.HI
      case 'TE':
        return newWaysToConnectContent.TE
      default:
        return null
    }
  }
  const {activeLanguage} = props
  const {heading, description} = getNewWaysToConnectData(activeLanguage)

  return (
    <div className="new-ways-to-connect-container">
      <h1 className="new-ways-to-content-heading">{heading}</h1>
      <p className="new-ways-to-content-description">{description}</p>
    </div>
  )
}

export default NewWaysToConnect

//src/components/NewWaysToConnect/index.css

.new-ways-to-connect-container {
  margin-top: 40px;
  width: 95%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

@media screen and (min-width: 768px) {
  .new-ways-to-connect-container {
    width: 38%;
    margin-top: 0px;
    align-items: flex-start;
  }
}

.new-ways-to-content-heading {
  font-family: 'Roboto';
  font-weight: 500;
  font-size: 24px;
  line-height: 1.42;
  color: #334155;
  margin: 0;
  text-align: center;
}

@media screen and (min-width: 768px) {
  .new-ways-to-content-heading {
    font-size: 30px;
    line-height: 1.42;
    text-align: left;
  }
}

.new-ways-to-content-description {
  font-family: 'Roboto';
  font-size: 16px;
  line-height: 1.42;
  margin-top: 10px;
  width: 95%;
  max-width: 400px;
  text-align: center;
}

@media screen and (min-width: 768px) {
  .new-ways-to-content-description {
    width: 95%;
    font-size: 18px;
    line-height: 1.42;
    margin-top: 15px;
    text-align: left;
  }
}

//src/components/Playtime/index.js

import './index.css'

const playtimeContent = {
  EN: {
    heading: 'Playtime. Anytime',
    description:
      'Windows takes gaming to a whole new level with graphic capabilities that rival reality. Discover your next favorite game with Xbox GamePass, giving you access to over 100 high-quality games.',
  },
  HI: {
    heading: 'विश्राम का समय। किसी भी समय',
    description:
      'विंडोज़ गेमिंग को ग्राफ़िक क्षमताओं के साथ एक नए स्तर पर ले जाता है जो वास्तविकता को टक्कर देता है। एक्सबॉक्स गेम पास के साथ अपना अगला पसंदीदा गेम खोजें, जिससे आपको 100 से अधिक उच्च-गुणवत्ता वाले गेम तक पहुंच मिलती है।',
  },
  TE: {
    heading: 'ఆడూకునే సమయం. ఎప్పుడైనా',
    description:
      'రియాలిటీకి ప్రత్యర్థిగా ఉండే గ్రాఫిక్ సామర్థ్యాలతో విండోస్ గేమింగ్‌ను సరికొత్త స్థాయికి తీసుకువెళుతుంది . మీ తదుపరి ఇష్టమైన ఆటను ఎక్స్‌బాక్స్ గేమ్‌పాస్‌తో కనుగొనండి, మీకు 100 కి పైగా అధిక-నాణ్యత ఆటలకు ప్రాప్యతను ఇస్తుంది.',
  },
}

const Playtime = props => {
  const getPlaytimeData = activeLanguage => {
    switch (activeLanguage) {
      case 'EN':
        return playtimeContent.EN
      case 'HI':
        return playtimeContent.HI
      case 'TE':
        return playtimeContent.TE
      default:
        return null
    }
  }
  const {activeLanguage} = props
  const {heading, description} = getPlaytimeData(activeLanguage)

  return (
    <div className="playtime-container">
      <h1 className="playtime-heading">{heading}</h1>
      <div className="playtime-description-container">
        <p className="playtime-description">{description}</p>
        <img
          className="playtime-games-image"
          src="https://assets.ccbp.in/frontend/react-js/gaming-pad-img.png"
          alt="gaming pad"
        />
      </div>
    </div>
  )
}

export default Playtime

//src/components/Playtime/index.css

.playtime-container {
  flex-grow: 1;
}

.playtime-heading {
  font-family: 'Roboto';
  font-weight: 500;
  font-size: 24px;
  line-height: 1.42;
  color: #334155;
  margin: 0;
  text-align: center;
}

@media screen and (min-width: 768px) {
  .playtime-heading {
    font-size: 30px;
    line-height: 1.42;
    text-align: left;
  }
}

.playtime-description-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

@media screen and (min-width: 768px) {
  .playtime-description-container {
    flex-direction: row;
  }
}

.playtime-description {
  font-family: 'Roboto';
  font-size: 16px;
  line-height: 1.42;
  margin-top: 10px;
  width: 95%;
  max-width: 400px;
  text-align: center;
}

@media screen and (min-width: 768px) {
  .playtime-description {
    width: 60%;
    font-size: 18px;
    line-height: 1.42;
    margin-top: 15px;
    text-align: left;
  }
}

.playtime-games-image {
  width: 120px;
  height: 120px;
  order: -1;
  margin-top: 15px;
  margin-bottom: 15px;
}

@media screen and (min-width: 768px) {
  .playtime-games-image {
    width: 150px;
    height: 150px;
    margin-left: 20px;
    margin-right: 20px;
    order: 1;
  }
}

//src/App.js

import {Component} from 'react'

import Header from './components/Header'
import LandingSection from './components/LandingSection'
import FeaturesSection from './components/FeaturesSection'

class App extends Component {
  state = {activeLanguage: 'EN'}

  changeLanguage = activeLanguage => {
    this.setState({activeLanguage})
  }

  render() {
    const {activeLanguage} = this.state
    return (
      <>
        <Header
          activeLanguage={activeLanguage}
          changeLanguage={this.changeLanguage}
        />
        <LandingSection activeLanguage={activeLanguage} />
        <FeaturesSection activeLanguage={activeLanguage} />
      </>
    )
  }
}

export default App

Final code:
------------------------------------------------------------------

//src/components/FeaturesSection/index.js

import Playtime from '../Playtime'
import NewWaysToConnect from '../NewWaysToConnect'

import './index.css'

const FeaturesSection = () => (
  <div className="features-section-container">
    <Playtime />
    <NewWaysToConnect />
  </div>
)

export default FeaturesSection

//src/components/Header/index.js

import LanguageContext from '../../context/LanguageContext'

import './index.css'

const langOptions = [
  {id: 1, value: 'EN', language: 'English'},
  {id: 2, value: 'HI', language: 'हिंदी'},
  {id: 3, value: 'TE', language: 'తెలుగు'},
]

const Header = () => (
  <LanguageContext.Consumer>
    {value => {
      const {activeLanguage, changeLanguage} = value
      const onChangeLanguage = event => {
        changeLanguage(event.target.value)
      }

      return (
        <nav className="nav-header">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/windows-logo-img.png"
            alt="website logo"
          />
          <select
            className="language-dropdown"
            value={activeLanguage}
            onChange={onChangeLanguage}
          >
            {langOptions.map(eachOption => (
              <option key={eachOption.id} value={eachOption.value}>
                {eachOption.language}
              </option>
            ))}
          </select>
        </nav>
      )
    }}
  </LanguageContext.Consumer>
)

export default Header

//src/components/LandingSection/index.js

import LanguageContext from '../../context/LanguageContext'

import './index.css'

const landingSectionContent = {
  EN: {
    heading: 'Windows 11',
    description:
      'Windows 11 provides a calm and creative space where you can pursue your passions through a fresh experience. From a rejuvenated Start menu to new ways to connect to your favorite people, news, games, and content. Windows  is the place to think, express, and create in a natural way.',
  },
  HI: {
    heading: 'विंडोज 11',
    description:
      'विंडोज 11 एक शांत और रचनात्मक स्थान प्रदान करता है जहां आप एक नए अनुभव के माध्यम से अपने जुनून को आगे बढ़ा सकते हैं। अपने पसंदीदा लोगों, समाचारों, गेमों और सामग्री से जुड़ने के नए तरीकों से एक नए सिरे से शुरू किए गए स्टार्ट मेनू से विंडोज एक प्राकृतिक तरीके से सोचने, व्यक्त करने और बनाने का स्थान है।',
  },
  TE: {
    heading: 'విండోస్ 11',
    description:
      'విండోస్ 11 ప్రశాంతమైన మరియు సృజనాత్మక స్థలాన్ని అందిస్తుంది, ఇక్కడ మీరు మీ అభిరుచులను తాజా అనుభవం ద్వారా కొనసాగించవచ్చు. పునరుజ్జీవింపబడిన ప్రారంభ మెను నుండి మీకు ఇష్టమైన వ్యక్తులు, వార్తలు, ఆటలు మరియు కంటెంట్‌తో కనెక్ట్ అవ్వడానికి కొత్త మార్గాల వరకు విండోస్ అనేది సహజంగా ఆలోచించే, వ్యక్తీకరించే మరియు సృష్టించే ప్రదేశం.',
  },
}

const LandingSection = () => {
  const getLandingSectionData = activeLanguage => {
    switch (activeLanguage) {
      case 'EN':
        return landingSectionContent.EN
      case 'HI':
        return landingSectionContent.HI
      case 'TE':
        return landingSectionContent.TE
      default:
        return null
    }
  }
  return (
    <LanguageContext.Consumer>
      {value => {
        const {activeLanguage} = value
        const {heading, description} = getLandingSectionData(activeLanguage)
        return (
          <div className="bg-container">
            <div className="responsive-container">
              <div className="description-container">
                <h1 className="heading">{heading}</h1>
                <p className="description">{description}</p>
              </div>
              <img
                className="logo-white"
                src="https://assets.ccbp.in/frontend/react-js/windows-logo-white-img.png"
                alt="windows logo"
              />
            </div>
          </div>
        )
      }}
    </LanguageContext.Consumer>
  )
}

export default LandingSection

//src/components/NewWaysToConnect/index.js

import LanguageContext from '../../context/LanguageContext'

import './index.css'

const newWaysToConnectContent = {
  EN: {
    heading: 'New ways to connect',
    description:
      'Connect instantly to the people you care about right from your desktop with Microsoft Teams. Call or chat for free, no matter what device they’re on.',
  },
  HI: {
    heading: 'कनेक्ट करने के नए तरीके',
    description:
      'माइक्रोसॉफ्ट टीमों के साथ सीधे अपने डेस्कटॉप से ​​उन लोगों से तुरंत कनेक्ट हों जिनकी आप परवाह करते हैं। कॉल करें या निःशुल्क चैट करें—चाहे वे किसी भी डिवाइस पर हों।',
  },
  TE: {
    heading: 'కనెక్ట్ చేయడానికి కొత్త మార్గాలు',
    description:
      'మైక్రోసాఫ్ట్ బృందాలతో మీ డెస్క్‌టాప్ నుండి మీరు శ్రద్ధ వహించే వ్యక్తులతో తక్షణమే కనెక్ట్ అవ్వండి. అవి ఏ పరికరంలో ఉన్నా సరే ఉచితంగా కాల్ చేయండి లేదా చాట్ చేయండి',
  },
}

const NewWaysToConnect = () => {
  const getNewWaysToConnectData = activeLanguage => {
    switch (activeLanguage) {
      case 'EN':
        return newWaysToConnectContent.EN
      case 'HI':
        return newWaysToConnectContent.HI
      case 'TE':
        return newWaysToConnectContent.TE
      default:
        return null
    }
  }
  return (
    <LanguageContext.Consumer>
      {value => {
        const {activeLanguage} = value
        const {heading, description} = getNewWaysToConnectData(activeLanguage)
        return (
          <div className="new-ways-to-connect-container">
            <h1 className="new-ways-to-content-heading">{heading}</h1>
            <p className="new-ways-to-content-description">{description}</p>
          </div>
        )
      }}
    </LanguageContext.Consumer>
  )
}

export default NewWaysToConnect

//src/components/Playtime/index.js

import LanguageContext from '../../context/LanguageContext'

import './index.css'

const playtimeContent = {
  EN: {
    heading: 'Playtime. Anytime',
    description:
      'Windows takes gaming to a whole new level with graphic capabilities that rival reality. Discover your next favorite game with Xbox GamePass, giving you access to over 100 high-quality games.',
  },
  HI: {
    heading: 'विश्राम का समय। किसी भी समय',
    description:
      'विंडोज़ गेमिंग को ग्राफ़िक क्षमताओं के साथ एक नए स्तर पर ले जाता है जो वास्तविकता को टक्कर देता है। एक्सबॉक्स गेम पास के साथ अपना अगला पसंदीदा गेम खोजें, जिससे आपको 100 से अधिक उच्च-गुणवत्ता वाले गेम तक पहुंच मिलती है।',
  },
  TE: {
    heading: 'ఆడూకునే సమయం. ఎప్పుడైనా',
    description:
      'రియాలిటీకి ప్రత్యర్థిగా ఉండే గ్రాఫిక్ సామర్థ్యాలతో విండోస్ గేమింగ్‌ను సరికొత్త స్థాయికి తీసుకువెళుతుంది . మీ తదుపరి ఇష్టమైన ఆటను ఎక్స్‌బాక్స్ గేమ్‌పాస్‌తో కనుగొనండి, మీకు 100 కి పైగా అధిక-నాణ్యత ఆటలకు ప్రాప్యతను ఇస్తుంది.',
  },
}

const Playtime = () => {
  const getPlaytimeData = activeLanguage => {
    switch (activeLanguage) {
      case 'EN':
        return playtimeContent.EN
      case 'HI':
        return playtimeContent.HI
      case 'TE':
        return playtimeContent.TE
      default:
        return null
    }
  }
  return (
    <LanguageContext.Consumer>
      {value => {
        const {activeLanguage} = value
        const {heading, description} = getPlaytimeData(activeLanguage)
        return (
          <div className="playtime-container">
            <h1 className="playtime-heading">{heading}</h1>
            <div className="playtime-description-container">
              <p className="playtime-description">{description}</p>
              <img
                className="playtime-games-image"
                src="https://assets.ccbp.in/frontend/react-js/gaming-pad-img.png"
                alt="gaming pad"
              />
            </div>
          </div>
        )
      }}
    </LanguageContext.Consumer>
  )
}

export default Playtime

//src/context/LanguageContext.js

import React from 'react'

const LanguageContext = React.createContext({
  activeLanguage: 'EN',
  changeLanguage: () => {},
})

export default LanguageContext

//src/App.js

import {Component} from 'react'

import Header from './components/Header'
import LandingSection from './components/LandingSection'
import FeaturesSection from './components/FeaturesSection'

class App extends Component {
  state = {activeLanguage: 'EN'}

  changeLanguage = activeLanguage => {
    this.setState({activeLanguage})
  }

  render() {
    return (
      <>
        <Header />
        <LandingSection />
        <FeaturesSection />
      </>
    )
  }
}

export default App

React Context | Part 2 | Cheat Sheet: -- windows app
---------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-WindowsApp

Concepts in Focus:

Provider
	- Syntax
	
Context Flow For Windows App

Best Practice

Final Code

1. Provider
Provider Component updates the value of Context.
When the provider updates context, all the nested consumers of that provider will be re-rendered.
Updated context value can only be accessed by the consumers nested within the provider.

<ContextObject.Provider value={/* some value */}>
   ...
<ContextObject.Provider/>

To update context value, we have to pass it as a prop to the Provider component.

2. Context Flow For Windows App

3. Best Practice
The context value should have the data which the consumers need.
It should also contain the required methods to update that data.

4.Final Code

//src/App.js  

import {Component} from 'react'

import Header from './components/Header'
import LandingSection from './components/LandingSection'
import FeaturesSection from './components/FeaturesSection'

import LanguageContext from './context/LanguageContext'

import './App.css'

class App extends Component {
  state = {activeLanguage: 'EN'}

  changeLanguage = activeLanguage => {
    this.setState({activeLanguage})
  }

  render() {
    const {activeLanguage} = this.state
    return (
      <LanguageContext.Provider
        value={{activeLanguage, changeLanguage: this.changeLanguage}}
      >
        <Header />
        <LandingSection />
        <FeaturesSection />
      </LanguageContext.Provider>
    )
  }
}

export default App

//src/context/LanguageContext.jsx

import React from 'react'

const LanguageContext = React.createContext({
  activeLanguage: 'EN',
  changeLanguage: () => {},
})

export default LanguageContext

//src/components/FeaturesSection/index.js

import Playtime from '../Playtime'
import NewWaysToConnect from '../NewWaysToConnect'

import './index.css'

const FeaturesSection = () => (
  <div className="features-section-container">
    <Playtime />
    <NewWaysToConnect />
  </div>
)

export default FeaturesSection

//src/components/Header/index.js

import LanguageContext from '../../context/LanguageContext'

import './index.css'

const langOptions = [
  {id: 1, value: 'EN', language: 'English'},
  {id: 2, value: 'HI', language: 'हिंदी'},
  {id: 3, value: 'TE', language: 'తెలుగు'},
]

const Header = () => (
  <LanguageContext.Consumer>
    {value => {
      const {activeLanguage, changeLanguage} = value
      const onChangeLanguage = event => {
        changeLanguage(event.target.value)
      }

      return (
        <nav className="nav-header">
          <img
            className="website-logo"
            src="https://assets.ccbp.in/frontend/react-js/windows-logo-img.png"
            alt="website logo"
          />
          <select
            className="language-dropdown"
            value={activeLanguage}
            onChange={onChangeLanguage}
          >
            {langOptions.map(eachOption => (
              <option key={eachOption.id} value={eachOption.value}>
                {eachOption.language}
              </option>
            ))}
          </select>
        </nav>
      )
    }}
  </LanguageContext.Consumer>
)

export default Header

//src/components/LandingSection/index.js

import LanguageContext from '../../context/LanguageContext'

import './index.css'

const landingSectionContent = {
  EN: {
    heading: 'Windows 11',
    description:
      'Windows 11 provides a calm and creative space where you can pursue your passions through a fresh experience. From a rejuvenated Start menu to new ways to connect to your favorite people, news, games, and content. Windows  is the place to think, express, and create in a natural way.',
  },
  HI: {
    heading: 'विंडोज 11',
    description:
      'विंडोज 11 एक शांत और रचनात्मक स्थान प्रदान करता है जहां आप एक नए अनुभव के माध्यम से अपने जुनून को आगे बढ़ा सकते हैं। अपने पसंदीदा लोगों, समाचारों, गेमों और सामग्री से जुड़ने के नए तरीकों से एक नए सिरे से शुरू किए गए स्टार्ट मेनू से विंडोज एक प्राकृतिक तरीके से सोचने, व्यक्त करने और बनाने का स्थान है।',
  },
  TE: {
    heading: 'విండోస్ 11',
    description:
      'విండోస్ 11 ప్రశాంతమైన మరియు సృజనాత్మక స్థలాన్ని అందిస్తుంది, ఇక్కడ మీరు మీ అభిరుచులను తాజా అనుభవం ద్వారా కొనసాగించవచ్చు. పునరుజ్జీవింపబడిన ప్రారంభ మెను నుండి మీకు ఇష్టమైన వ్యక్తులు, వార్తలు, ఆటలు మరియు కంటెంట్‌తో కనెక్ట్ అవ్వడానికి కొత్త మార్గాల వరకు విండోస్ అనేది సహజంగా ఆలోచించే, వ్యక్తీకరించే మరియు సృష్టించే ప్రదేశం.',
  },
}

const LandingSection = () => {
  const getLandingSectionData = activeLanguage => {
    switch (activeLanguage) {
      case 'EN':
        return landingSectionContent.EN
      case 'HI':
        return landingSectionContent.HI
      case 'TE':
        return landingSectionContent.TE
      default:
        return null
    }
  }
  return (
    <LanguageContext.Consumer>
      {value => {
        const {activeLanguage} = value
        const {heading, description} = getLandingSectionData(activeLanguage)
        return (
          <div className="bg-container">
            <div className="responsive-container">
              <div className="description-container">
                <h1 className="heading">{heading}</h1>
                <p className="description">{description}</p>
              </div>
              <img
                className="logo-white"
                src="https://assets.ccbp.in/frontend/react-js/windows-logo-white-img.png"
                alt="windows logo"
              />
            </div>
          </div>
        )
      }}
    </LanguageContext.Consumer>
  )
}

export default LandingSection

//src/components/NewWaysToConnect/index.js

import LanguageContext from '../../context/LanguageContext'

import './index.css'

const newWaysToConnectContent = {
  EN: {
    heading: 'New ways to connect',
    description:
      'Connect instantly to the people you care about right from your desktop with Microsoft Teams. Call or chat for free, no matter what device they’re on.',
  },
  HI: {
    heading: 'कनेक्ट करने के नए तरीके',
    description:
      'माइक्रोसॉफ्ट टीमों के साथ सीधे अपने डेस्कटॉप से ​​उन लोगों से तुरंत कनेक्ट हों जिनकी आप परवाह करते हैं। कॉल करें या निःशुल्क चैट करें—चाहे वे किसी भी डिवाइस पर हों।',
  },
  TE: {
    heading: 'కనెక్ట్ చేయడానికి కొత్త మార్గాలు',
    description:
      'మైక్రోసాఫ్ట్ బృందాలతో మీ డెస్క్‌టాప్ నుండి మీరు శ్రద్ధ వహించే వ్యక్తులతో తక్షణమే కనెక్ట్ అవ్వండి. అవి ఏ పరికరంలో ఉన్నా సరే ఉచితంగా కాల్ చేయండి లేదా చాట్ చేయండి',
  },
}

const NewWaysToConnect = () => {
  const getNewWaysToConnectData = activeLanguage => {
    switch (activeLanguage) {
      case 'EN':
        return newWaysToConnectContent.EN
      case 'HI':
        return newWaysToConnectContent.HI
      case 'TE':
        return newWaysToConnectContent.TE
      default:
        return null
    }
  }
  return (
    <LanguageContext.Consumer>
      {value => {
        const {activeLanguage} = value
        const {heading, description} = getNewWaysToConnectData(activeLanguage)
        return (
          <div className="new-ways-to-connect-container">
            <h1 className="new-ways-to-content-heading">{heading}</h1>
            <p className="new-ways-to-content-description">{description}</p>
          </div>
        )
      }}
    </LanguageContext.Consumer>
  )
}

export default NewWaysToConnect

//src/components/Playtime/index.js

import LanguageContext from '../../context/LanguageContext'

import './index.css'

const playtimeContent = {
  EN: {
    heading: 'Playtime. Anytime',
    description:
      'Windows takes gaming to a whole new level with graphic capabilities that rival reality. Discover your next favorite game with Xbox GamePass, giving you access to over 100 high-quality games.',
  },
  HI: {
    heading: 'विश्राम का समय। किसी भी समय',
    description:
      'विंडोज़ गेमिंग को ग्राफ़िक क्षमताओं के साथ एक नए स्तर पर ले जाता है जो वास्तविकता को टक्कर देता है। एक्सबॉक्स गेम पास के साथ अपना अगला पसंदीदा गेम खोजें, जिससे आपको 100 से अधिक उच्च-गुणवत्ता वाले गेम तक पहुंच मिलती है।',
  },
  TE: {
    heading: 'ఆడూకునే సమయం. ఎప్పుడైనా',
    description:
      'రియాలిటీకి ప్రత్యర్థిగా ఉండే గ్రాఫిక్ సామర్థ్యాలతో విండోస్ గేమింగ్‌ను సరికొత్త స్థాయికి తీసుకువెళుతుంది . మీ తదుపరి ఇష్టమైన ఆటను ఎక్స్‌బాక్స్ గేమ్‌పాస్‌తో కనుగొనండి, మీకు 100 కి పైగా అధిక-నాణ్యత ఆటలకు ప్రాప్యతను ఇస్తుంది.',
  },
}

const Playtime = () => {
  const getPlaytimeData = activeLanguage => {
    switch (activeLanguage) {
      case 'EN':
        return playtimeContent.EN
      case 'HI':
        return playtimeContent.HI
      case 'TE':
        return playtimeContent.TE
      default:
        return null
    }
  }
  return (
    <LanguageContext.Consumer>
      {value => {
        const {activeLanguage} = value
        const {heading, description} = getPlaytimeData(activeLanguage)
        return (
          <div className="playtime-container">
            <h1 className="playtime-heading">{heading}</h1>
            <div className="playtime-description-container">
              <p className="playtime-description">{description}</p>
              <img
                className="playtime-games-image"
                src="https://assets.ccbp.in/frontend/react-js/gaming-pad-img.png"
                alt="gaming pad"
              />
            </div>
          </div>
        )
      }}
    </LanguageContext.Consumer>
  )
}

export default Playtime  

coding pratice-41:
----------------------------------------------------------------------------------------------------------------------

Layout Builder:
--------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-LayoutBuilder

In this project, let's build a Layout Builder App by applying the concepts we have learned till now.

//src/App.css

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.app-container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

//src/App.js

import {Component} from 'react'

import ConfigurationContext from './context/ConfigurationContext'

import ConfigurationController from './components/ConfigurationController'

import Layout from './components/Layout'

import './App.css'

class App extends Component {
  state = {
    showContent: true,
    showLeftNavbar: true,
    showRightNavbar: true,
  }

  onToggleShowContent = () => {
    this.setState(prevState => ({showContent: !prevState.showContent}))
  }

  onToggleShowLeftNavbar = () => {
    this.setState(prevState => ({showLeftNavbar: !prevState.showLeftNavbar}))
  }

  onToggleShowRightNavbar = () => {
    this.setState(prevState => ({showRightNavbar: !prevState.showRightNavbar}))
  }

  render() {
    const {showContent, showLeftNavbar, showRightNavbar} = this.state

    return (
      <ConfigurationContext.Provider
        value={{
          showContent,
          showLeftNavbar,
          showRightNavbar,
          onToggleShowContent: this.onToggleShowContent,
          onToggleShowLeftNavbar: this.onToggleShowLeftNavbar,
          onToggleShowRightNavbar: this.onToggleShowRightNavbar,
        }}
      >
        <div className="app-container">
          <ConfigurationController />
          <Layout />
        </div>
      </ConfigurationContext.Provider>
    )
  }
}

export default App

mcq:
------------------------------------------------

//src/context/FamilyContext.js

import React from 'react'

const FamilyContext = React.createContext({
	motto: 'All Is Well',
})

export default FamilyContext

//src/App.js

import GrandParent from './components/GrandParent'

const App = () => <GrandParent />

export default App

//src/components/GrandParent/index.js

import Parent from '../Parent'

const GrandParent = () => <Parent />

export default GrandParent

//src/components/Parent/index.js

import FamilyContext from '../../context/FamilyContext'

const Parent = () => (

<FamilyContext.Consumer>

{value => <p> {value.motto} </p> }

</FamilyContext.Consumer>

)

export default Parent

React Context | Part 3 | Cheat Sheet: -- E-Commerce
---------------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-EcommerceApplication

Concepts in Focus:

Context

Using Context in methods

Final Code

1. Context
Context can also be used:

When data has to be available between different Routes.
When data has to be available for more number of Components

2. Using Context in methods
We can add consumer or provider in the class method when it returns JSX.

In the below code snippet, we have used Consumer Component in renderProductDetailsView because this method is returning JSX.

Example:

File: src/components/ProductItemDetails

import { Component } from "react";
import Cookies from "js-cookie";
import Loader from "react-loader-spinner";
import { BsPlusSquare, BsDashSquare } from "react-icons/bs";

import CartContext from "../../context/CartContext";

import Header from "../Header";
import SimilarProductItem from "../SimilarProductItem";

import "./index.css";

const apiStatusConstants = {
  initial: "INITIAL",
  success: "SUCCESS",
  failure: "FAILURE",
  inProgress: "IN_PROGRESS",
};

class ProductItemDetails extends Component {
  state = {
    productData: {},
    similarProductsData: [],
    apiStatus: apiStatusConstants.initial,
    quantity: 1,
  };

  componentDidMount() {
    this.getProductData();
  }

  getFormattedData = (data) => ({
    availability: data.availability,
    brand: data.brand,
    description: data.description,
    id: data.id,
    imageUrl: data.image_url,
    price: data.price,
    rating: data.rating,
    title: data.title,
    totalReviews: data.total_reviews,
  });

  getProductData = async () => {
    const { match } = this.props;
    const { params } = match;
    const { id } = params;

    this.setState({
      apiStatus: apiStatusConstants.inProgress,
    });
    const jwtToken = Cookies.get("jwt_token");
    const apiUrl = `https://apis.ccbp.in/products/${id}`;
    const options = {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
      method: "GET",
    };
    const response = await fetch(apiUrl, options);
    if (response.ok) {
      const fetchedData = await response.json();
      const updatedData = this.getFormattedData(fetchedData);
      const updatedSimilarProductsData = fetchedData.similar_products.map(
        (eachSimilarProduct) => this.getFormattedData(eachSimilarProduct)
      );
      this.setState({
        productData: updatedData,
        similarProductsData: updatedSimilarProductsData,
        apiStatus: apiStatusConstants.success,
      });
    }
    if (response.status === 404) {
      this.setState({
        apiStatus: apiStatusConstants.failure,
      });
    }
  };

  renderLoadingView = () => (
    <div className="products-details-loader-container">
      <Loader type="ThreeDots" color="#0b69ff" height="50" width="50" />
    </div>
  );

  renderFailureView = () => (
    <div className="product-details-error-view-container">
      <img
        alt="error view"
        src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-error-view-img.png"
        className="error-view-image"
      />
      <h1 className="product-not-found-heading">Product Not Found</h1>
      <button type="button" className="button">
        Continue Shopping
      </button>
    </div>
  );

  onDecrementQuantity = () => {
    const { quantity } = this.state;
    if (quantity > 1) {
      this.setState((prevState) => ({ quantity: prevState.quantity - 1 }));
    }
  };

  onIncrementQuantity = () => {
    this.setState((prevState) => ({ quantity: prevState.quantity + 1 }));
  };

  renderProductDetailsView = () => (
    <CartContext.Consumer>
      {(value) => {
        const { productData, quantity, similarProductsData } = this.state;
        const {
          availability,
          brand,
          description,
          imageUrl,
          price,
          rating,
          title,
          totalReviews,
        } = productData;
        const { addCartItem } = value;
        const onClickAddToCart = () => {
          addCartItem({ ...productData, quantity });
        };

        return (
          <div className="product-details-success-view">
            <div className="product-details-container">
              <img src={imageUrl} alt="product" className="product-image" />
              <div className="product">
                <h1 className="product-name">{title}</h1>
                <p className="price-details">Rs {price}/-</p>
                <div className="rating-and-reviews-count">
                  <div className="rating-container">
                    <p className="rating">{rating}</p>
                    <img
                      src="https://assets.ccbp.in/frontend/react-js/star-img.png"
                      alt="star"
                      className="star"
                    />
                  </div>
                  <p className="reviews-count">{totalReviews} Reviews</p>
                </div>
                <p className="product-description">{description}</p>
                <div className="label-value-container">
                  <p className="label">Available:</p>
                  <p className="value">{availability}</p>
                </div>
                <div className="label-value-container">
                  <p className="label">Brand:</p>
                  <p className="value">{brand}</p>
                </div>
                <hr className="horizontal-line" />
                <div className="quantity-container">
                  <button
                    type="button"
                    className="quantity-controller-button"
                    onClick={this.onDecrementQuantity}
                  >
                    <BsDashSquare className="quantity-controller-icon" />
                  </button>
                  <p className="quantity">{quantity}</p>
                  <button
                    type="button"
                    className="quantity-controller-button"
                    onClick={this.onIncrementQuantity}
                  >
                    <BsPlusSquare className="quantity-controller-icon" />
                  </button>
                </div>
                <button
                  type="button"
                  className="button add-to-cart-btn"
                  onClick={onClickAddToCart}
                >
                  ADD TO CART
                </button>
              </div>
            </div>
            <h1 className="similar-products-heading">Similar Products</h1>
            <ul className="similar-products-list">
              {similarProductsData.map((eachSimilarProduct) => (
                <SimilarProductItem
                  productDetails={eachSimilarProduct}
                  key={eachSimilarProduct.id}
                />
              ))}
            </ul>
          </div>
        );
      }}
    </CartContext.Consumer>
  );

  renderProductDetails = () => {
    const { apiStatus } = this.state;

    switch (apiStatus) {
      case apiStatusConstants.success:
        return this.renderProductDetailsView();
      case apiStatusConstants.failure:
        return this.renderFailureView();
      case apiStatusConstants.inProgress:
        return this.renderLoadingView();
      default:
        return null;
    }
  };

  render() {
    return (
      <>
        <Header />
        <div className="product-item-details-container">
          {this.renderProductDetails()}
        </div>
      </>
    );
  }
}

export default ProductItemDetails;

3. Final code
Run the below command in your IDE to download the final code.

ccbp start RJSIVIJ1YR

coding pratice-42
-------------------------------------------------------------------------------------

Navbar with Context:
--------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-NavbarWithContext

//src/components/About/index.js

// Write your code here
import Navbar from '../Navbar'

import ThemeContext from '../../context/ThemeContext'

import './index.css'

const About = () => (
  <ThemeContext.Consumer>
    {value => {
      const {isDarkTheme} = value

      const aboutBgClassName = isDarkTheme ? 'about-bg-dark' : 'about-bg-light'

      const aboutImageURL = isDarkTheme
        ? 'https://assets.ccbp.in/frontend/react-js/about-dark-img.png'
        : 'https://assets.ccbp.in/frontend/react-js/about-light-img.png'

      const aboutTextClassName = isDarkTheme
        ? 'about-text-light'
        : 'about-text-dark'

      return (
        <div className={`about-app-container ${aboutBgClassName}`}>
          <Navbar />
          <div className="about-page-container">
            <div className="about-container">
              <img className="about-image" src={aboutImageURL} alt="about" />
              <h1 className={`about-heading ${aboutTextClassName}`}>About</h1>
            </div>
          </div>
        </div>
      )
    }}
  </ThemeContext.Consumer>
)

export default About

//src/components/Home/index.js

// Write your code here
import Navbar from '../Navbar'

import ThemeContext from '../../context/ThemeContext'

import './index.css'

const Home = () => (
  <ThemeContext.Consumer>
    {value => {
      const {isDarkTheme} = value

      const homeBgClassName = isDarkTheme ? 'home-bg-dark' : 'home-bg-light'

      const homeImageURL = isDarkTheme
        ? 'https://assets.ccbp.in/frontend/react-js/home-dark-img.png'
        : 'https://assets.ccbp.in/frontend/react-js/home-light-img.png'

      const homeTextClassName = isDarkTheme
        ? 'home-text-light'
        : 'home-text-dark'

      return (
        <div className={`home-app-container ${homeBgClassName}`}>
          <Navbar />
          <div className="home-responsive-container">
            <div className="home-container">
              <img className="home-image" src={homeImageURL} alt="home" />
              <h1 className={`home-heading ${homeTextClassName}`}>Home</h1>
            </div>
          </div>
        </div>
      )
    }}
  </ThemeContext.Consumer>
)

export default Home

//src/components/Navbar/index.js

// Write your code here
import {Link} from 'react-router-dom'

import ThemeContext from '../../context/ThemeContext'

import './index.css'

const Navbar = () => (
  <ThemeContext.Consumer>
    {value => {
      const {isDarkTheme, toggleTheme} = value

      const onToggleTheme = () => {
        toggleTheme()
      }

      const themeImageURL = isDarkTheme
        ? 'https://assets.ccbp.in/frontend/react-js/light-theme-img.png'
        : 'https://assets.ccbp.in/frontend/react-js/dark-theme-img.png'

      const navbarBgClassName = isDarkTheme
        ? 'navbar-bg-dark'
        : 'navbar-bg-light'

      const websiteLogoImageURL = isDarkTheme
        ? 'https://assets.ccbp.in/frontend/react-js/website-logo-dark-theme-img.png'
        : 'https://assets.ccbp.in/frontend/react-js/website-logo-light-theme-img.png'

      const navItemClassName = isDarkTheme
        ? 'list-text-dark-theme'
        : 'list-text-light-theme'

      return (
        <div className={`navbar ${navbarBgClassName}`}>
          <div className="navbar-content">
            <img
              className="website-logo"
              src={websiteLogoImageURL}
              alt="website logo"
            />
            <ul className="nav-menu">
              <li className="nav-menu-item">
                <Link to="/" className={`nav-link ${navItemClassName}`}>
                  Home
                </Link>
              </li>
              <li className="nav-menu-item">
                <Link to="/about" className={`nav-link ${navItemClassName}`}>
                  About
                </Link>
              </li>
            </ul>
            <button
              testid="theme"
              className="theme-button"
              type="button"
              onClick={onToggleTheme}
            >
              <img className="theme-image" src={themeImageURL} alt="theme" />
            </button>
          </div>
        </div>
      )
    }}
  </ThemeContext.Consumer>
)

export default Navbar

//src/components/NotFound/index.js

// Write your code here
import Navbar from '../Navbar'

import ThemeContext from '../../context/ThemeContext'

import './index.css'

const NotFound = () => (
  <ThemeContext.Consumer>
    {value => {
      const {isDarkTheme} = value

      const notFoundBgClassName = isDarkTheme
        ? 'not-found-bg-dark'
        : 'not-found-bg-light'

      const notFoundHeadingTextClassName = isDarkTheme
        ? 'not-found-heading-text-light'
        : 'not-found-heading-text-dark'

      const notFoundContentTextClassName = isDarkTheme
        ? 'not-found-content-text-light'
        : 'not-found-content-text-dark'

      return (
        <div className={`not-found-app-container ${notFoundBgClassName}`}>
          <Navbar />
          <div className="not-found-responsive-container">
            <div className="not-found-container">
              <img
                src="https://assets.ccbp.in/frontend/react-js/not-found-img.png"
                alt="not found"
                className="not-found-img"
              />
              <h1
                className={`not-found-heading ${notFoundHeadingTextClassName}`}
              >
                Lost Your Way?
              </h1>
              <p
                className={`not-found-content ${notFoundContentTextClassName}`}
              >
                We cannot seem to find the page you are looking for.
              </p>
            </div>
          </div>
        </div>
      )
    }}
  </ThemeContext.Consumer>
)

export default NotFound

//src/context/ThemeContext.js

import React from 'react'

const ThemeContext = React.createContext({
  isDarkTheme: false,
  toggleTheme: () => {},
})

export default ThemeContext


React Context | Part 4 | Cheat Sheet: -- E-Commerce
---------------------------------------------------------------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-EcommerceApplication

Concepts in Focus: -- Header, cart, Empty Cart View

Deploying the Ecommerce Application Code

Ecommerce Application-Final Code

- Empty Cart View
- Displaying Cart Items Count
- Deployment

1. Deploying the Ecommerce Application Code
Run the below command in your IDE to publish the Ecommerce Application Code.

ccbp publish RJSIV4YSTX domain.ccbp.tech
Here the domain is the domain name to be published.

Quick Tip
To look good in your resume, use your name and nxttrendz as the domain name in the domain URL. For example, rahulnxttrendz.ccbp.tech.

Warning
An error will be thrown if you are trying to publish with the already existing URL.

Note
A maximum of only 15 characters is allowed in the domain name.

coding pratice-43:
---------------------------------------------------------------------------------

Nxt Trendz - Cart Features:
--------------------------------------------------

https://github.com/ManirathnamKuruma/ReactJS-EcommerceApplication

In this project, let's build a Nxt Trendz - Cart Features by applying the concepts we have learned till now.

1.Implementation Files

Use these files to complete the implementation:

src/App.js
src/components/Cart/index.js
src/components/Cart/index.css
src/components/CartItem/index.js
src/components/CartItem/index.css
src/components/CartSummary/index.js
src/components/CartSummary/index.css

Styled Components | Cheat Sheet:
-----------------------------------------------------------------------------------------------------

Concepts in Focus:

Styling React Components:
	- Using CSS
	- CSS-in-JS
	
Styled Components:
	- Installation
	- Syntax
	- Importing styled
	- Creating and Exporting Styled Component
	- Importing and Rendering Styled Component
	- Adapting based on props
	- Modularity of Code
	- Conditional Styling using Props
	
Advantages of Styled Components:
	- Unique Class Names
	- Elimination of dead styles
	- Dynamic Styling
	- Can differentiate between the types of props they receive
	- Easier Debugging
	- Global Styling
	
Extending Styles

The "as" prop

Boolean Attribute	

1. Styling React Components
React Components can be styled in different ways:

Using CSS
CSS-in-JS
SASS & SCSS
many more...

1.1 Using CSS
Writing CSS in external CSS files for each component and passing class name as a value to the className attribute.

File: src/App.js

import "./App.css";

const App = () => <h1 className="heading">Hello World</h1>;

export default App;

File: src/App.css

.heading {
  color: #0070c1;
  font-family: 'Roboto';
}

1.2 CSS-in-JS
CSS-in-JS is a styling technique where JavaScript is used to style React Components. It can be implemented using the below third party packages.

Styled Components
Emotion
Radium many more...

2. Styled Components
Styled Components are one of the new ways to use CSS in modern JavaScript. Components are used to reuse code, similarly Styled Components are used to reuse styles.

2.1 Installation

npm install styled-components

2.2 Syntax

const StyledComponentName = styled.tagName`
  property1: value1;
  property2: value2;
  ...
`;

Within the template literals (), we define the styles.

Note
StyledComponentName should always start with a Capital letter.

2.3 Importing styled
In general, styled components are placed inside the styledComponents.js file.

File: src/styledComponents.js

import styled from "styled-components";

styled is an internal utility method that transforms the styling from JavaScript into actual CSS.

2.4 Creating and Exporting Styled Component

File: src/styledComponents.js

import styled from "styled-components";

export const Heading = styled.h1`
  color: #0070c1;
  font-family: "Roboto";
`;

2.5 Importing and Rendering Styled Component

File: src/App.js

import "./App.css";
import { Heading } from "./styledComponents";

const App = () => <Heading>Hello World</Heading>;

export default App;

2.6 Adapting based on props
With styled components we can re-use the styles created.

<StyledComponent propName="propValue">...</StyledComponent>

Syntax:

const StyledComponentName = styled.tagName`
  property1 : value1;
  property2: ${props => /* access prop value */ };
  ...
`

Example:

File: src/App.js

import "./App.css";
import { CustomButton } from "./styledComponents";

const App = () => (
  <>
    <CustomButton type="button" color="#ffffff" bgColor="#0070c1">Click</CustomButton>
    <CustomButton type="button" color="#0070c1" bgColor="#ffffff">Click</CustomButton>
  </>
);
export default App;

File: src/styledComponents.js

import styled from "styled-components";

export const CustomButton = styled.button`
  padding: 10px;
  margin-right: 20px;
  font-size: 15px;
  color: ${(props) => props.color};
  border-radius: 4px;
  border: 2px solid #0070c1;
  background-color: ${(props) => props.bgColor};
`;

Value passed as prop can be accessed as props.propName.

2.7 Modularity of Code

Example:

File: src/App.js

<CustomButton type="button" outline={false}>Click</CustomButton>

The color and bgColor are the part of styling, instead of passing them as props, we can passthe type of button to handle styles in styled components.

2.8 Conditional Styling using Props

Condition ? Expression If True : Expression If False;

const StyledComponentName = styled.tagName`
  property1 : value1;
  property2: ${(props) => (props.name === someValue ? value2 : value3)};
  ...
`;

Example:

File: src/App.js

import "./App.css";
import { CustomButton } from "./styledComponents";

const App = () => (
  <>
    <CustomButton type="button" outline={false}>Click</CustomButton>
    <CustomButton type="button" outline={true}>Click</CustomButton>
  </>
);

export default App;

File: src/styledComponents.js

import styled from "styled-components";

export const CustomButton = styled.button`
  padding: 10px;
  margin-right: 20px;
  font-size: 15px;
  color: ${(props) => (props.outline ? "#0070c1" : "#ffffff")};
  border-radius: 4px;
  border: 2px solid #0070c1;
  background-color: ${(props) => (props.outline ? "#ffffff" : "#0070c1")};
`;

3.Advantages of Styled Components

3.1 Unique Class Names
Styled Components generate a unique class name(s) for your styles.

3.2 Elimination of dead styles
Styled components remove unused styles, even if they’re declared in your code.

3.3 Dynamic Styling
Let’s assume we have two types of buttons on our page, one with a white background, and the other navy blue.
We do not have to create two styled-components for them. We can adapt their styling based on their props.

File:src/styledComponents.js

import styled from "styled-components";

export const CustomButton = styled.button`
  padding: 10px;
  margin-right: 20px;
  font-size: 15px;
  color: ${(props) => (props.outline ? "#0070c1" : "#ffffff")};
  border-radius: 4px;
  border: 2px solid #0070c1;
  background-color: ${(props) => (props.outline ? "#ffffff" : "#0070c1")};
`;

File:src/App.js

import "./App.css";
import { CustomButton } from "./styledComponents";

const App = () => (
  <>
    <CustomButton type="button" outline={false}>Click</CustomButton>
    <CustomButton type="button" outline={true}>Click</CustomButton>
  </>
);

export default App;

3.4 Can differentiate between the types of props they receive

File:src/App.js

import "./App.css";
import { CustomButton } from "./styledComponents";

const App = () => (
  <>
    <CustomButton outline={false}>Click</CustomButton>
    <CustomButton outline={true}>Click</CustomButton>
  </>
);

export default App;

You’ll notice, though, that we haven’t given our button a type in the above code snippet. Let’s do that:

File:src/App.js

import "./App.css";
import { CustomButton } from "./styledComponents";

const App = () => (
  <>
    <CustomButton type="button" outline={false}>Click</CustomButton>
    <CustomButton type="submit" onClick={() => alert("clicked")} outline={true} >Click</CustomButton>
  </>;
);

export default App;

Styled components can differentiate between the types of props they receive. 
They know that type is an HTML attribute, so they render <button type="button">Click</button>, 
while using the outline prop in their own processing. Notice how we attached an event handler, too?

3.5 Easier Debugging

1. babel-plugin-styled-components plugin adds support for a nicer debugging experience.

2. This option enhances the attached CSS class name on each component with richer output to help identify your components 
in the DOM without React DevTools. In your page source you'll see: <button type="button" class="CustomButton-asdfxxx asdfxx" />
 instead of just <button type="button" class="asdfxxx" />.
 
3. It also allows you to see the component's displayName in React DevTools. For example, consider writing a 
styled component that renders a button element, called CustomButton. It will normally show up in DevTools as styled.
button, but with the displayName option enabled, it has the name you gave it CustomButton.

4. This makes it easier to find your components and to figure out where they live in your app.

5. For more info, you can go through this link here.

https://styled-components.com/ -- tooling -- Babel plugin

Note

In order to configure create-react-app with the babel-plugin-styled-components, 
we have to use craco - Create React App Configuration Override is an easy and comprehensible configuration layer for create-react-app.

We’ll need to install craco with npm, and then create a craco.config.js at the root of our application, with the content:

module.exports = {
  babel: {
    plugins: [
      [
        "babel-plugin-styled-components",
        {
          fileName: false,
        },
      ],
    ],
  },
};

3.6 Global Styling

1. We will write global styles in the styledComponents.js file. Inside the GlobalStyle variable is where we define all global styles.

2. We will import GlobalStyle component and place it at the top of React tree. In many react applications, that’s typically the App.js file.

3. createGlobalStyle is a helper function to generate a special StyledComponent that handles global styles.

4. Normally, styled-components are automatically scoped to a local CSS class and therefore isolated from other components. In the case of createGlobalStyle, 
this limitation is removed.

Example:

File: src/styledComponents.js

import { createGlobalStyle } from "styled-components";

export const GlobalStyle = createGlobalStyle`
 body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen",
    "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue",
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
`;

File: src/App.js

import { CustomButton } from "./styledComponents";
import { GlobalStyle } from "./styledComponents";

const App = () => (
  <>
    <GlobalStyle />
    <CustomButton type="button">Click</CustomButton>
    <CustomButton type="button" outline>Click</CustomButton>
  </>
);

export default App;

To know more, you can go through this link. -- > https://styled-components.com/docs/api#helpers

4. Extending Styles

Frequently you might want to use a component, but change it slightly for a single case. Now, you could pass in a function and change them based on some props, 
but that's quite a lot of effort for overriding the styles once.

To easily make a new component that inherits the styling of another, just wrap it in the styled().
 Here we use the CustomButton and create a special one, extending it with some color-related styling.
 
 import styled from "styled-components";

export const CustomButton = styled.button`
  padding: 10px;
  margin-right: 20px;
  font-size: 15px;
  color: #ffffff;
  border-radius: 4px;
  border: 2px solid #0070c1;
  background-color: #0070c1;
`;

Now we need to create another StyledComponent with similar properties of CustomButton except color and border-color property.

import styled from "styled-components";

export const OutlineButton = styled(CustomButton)`
  color: #0070c1;
  background-color: #ffffff;
  font-family: "Open sans";
`;

It’s more or less like how the spread operator works.

To know more, you can go through this link. -- > https://styled-components.com/docs/basics#extending-styles

Note
You will get a HTML button element rendered for OutlineButton.

5. The "as" prop

You can pass the as prop to your styled component with the value of your preferred element.
If you want to keep all the styling you've applied to a component but just switch out what's being ultimately rendered 
(be it a different HTML tag or a different custom component), you can use the "as" prop to do this at runtime.

Example:

File:src/App.js

import "./App.css";
import { CustomButton } from "./styledComponents";

const App = () => (
  <>
    <CustomButton outline={false}>Click</CustomButton>
    <CustomButton as="a" href="#" outline={true}>Click</CustomButton>
  </>
);

export default App;

File:src/styledComponents.js

import styled from "styled-components";

export const CustomButton = styled.button`
  padding: 10px;
  margin-right: 20px;
  font-size: 15px;
  color: ${(props) => (props.outline ? "#0070c1" : "#ffffff")};
  border-radius: 4px;
  border: 2px solid #0070c1;
  background-color: ${(props) => (props.outline ? "#ffffff" : "#0070c1")};
`;

Consider the above code snippet, here the OutlineButton styled component is rendered as a button element,
 but you would prefer an anchor to a button for OutlineButton, you can pass the as a prop to your styled component with the value of your preferred element.
 
This sort of thing is very useful in use cases like a navigation bar where some of the items should be links and some just buttons,
 but all be styled the same way.

6. Boolean Attribute
The Presence of boolean attribute is taken as true no need to specify the value again.
The absence of boolean attribute is taken as false.

import "./App.css";
import { CustomButton } from "./styledComponents";

const App = () => (
  <>
    <CustomButton type="button">Click</CustomButton>
    <CustomButton type="button" outline>Click</CustomButton>
  </>
);

export default App;