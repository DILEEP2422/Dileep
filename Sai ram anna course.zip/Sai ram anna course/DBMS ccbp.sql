1

DBMS:
---------------------------

Introduction to Databases:

Concepts in Focus:
Data
Database
Database Management System(DBMS)
	Advantages
Types of Databases
	Relational Database
	Non-Relational Database

Data:
---------

Any sort of information that is stored is called data.

Examples:
Messages & multimedia on WhatsApp
Products and orders on Amazon
Contact details in telephone directory, etc.

Database:
--------------

An organised collection of data is called a database.

Database Management System (DBMS):
------------------------------------
A software that is used to easily store and access data from the database in a secure way.


Advantages:

Security: Data is stored & maintained securely.
Ease of Use: Provides simpler ways to create & update data at the rate it is generated and updated respectively.
Durability and Availability: Durable and provides access to all the clients at any point in time.
Performance: Quickly accessible to all the clients(applications and stakeholders).

Types of Databases
There are different types of databases based on how we organize the data. 

Relational Database:

In relational databases, the data is organised in the form of tables.

Non-Relational Database:

These four types are commonly referred as non-relational databases.

Note:
Choice of database depends on our requirements.
Relational database is the most commonly used database.
 

Relational DBMS:
ARelational DBMSis a DBMS designed specifically for relational databases. Relational databases organise the data in the form of tables.

Examples: Oracle, PostgreSQL, MySQL, SQLite, SQL Server, IBM DB2, etc.

Non-Relational DBMS:
ANon-relational DBMSis a DBMS designed specifically for non-relational databases. Non-relational databases store the data in a non-tabular form.

Examples: Elasticsearch, CouchDB, DynamoDB, MongoDB, Cassandra, Redis, etc.

Introduction to SQL:

We have already learnt that databases and DBMS are key to organising and analysing data for business uses.
From here on, let’s get busy working around with databases using SQL! 

SQL stands for Structured Query Language
SQL is used to perform operations on Relational DBMS.
SQL is declarative. Hence, easy to learn.
SQL provides multiple clauses (commands) to perform various operations like create, retrieve, update and delete the data.

The first step towards working with the database would be creating a table.

Create Table:
Creates a new table in the database.

Syntax

SQL:

CREATE TABLE table_name (
  column1 type1,
  column2 type2,
  ...
);

Here,type1andtype2 in the syntax are the datatypes of column1 and column2 respectively. 
Datatypes that are supported in SQL are mentioned below.

Example
Create aplayertable to store the following details of players.

column_name		data_type
name			VARCHAR(200)
age				INT/INTEGER
score	        INT/INTEGER

SQL:

CREATE TABLE player (
  name VARCHAR(200),
  age INTEGER,
  score INTEGER
);

We can check the details of the created table at any point in time using thePRAGMAcommand (mentioned below).

Data Types
Following data types are frequently used in SQL.

Data Type	Syntax
Integer		INTEGER / INT
Float		FLOAT
String		VARCHAR
Text		TEXT
Date		DATE
Time		TIME
Datetime	DATETIME
Boolean		BOOLEAN

Note:

Boolean values are stored as integers 0 (FALSE) and 1 (TRUE).
Date object is represented as: ‘YYYY-MM-DD’
Datetime object is represented as: ‘YYYY-MM-DD HH:MM:SS’

PRAGMA:
PRAGMA TABLE_INFOcommand returns the information about a specific table in a database.

Syntax:

PRAGMA TABLE_INFO(table_name);

Example:
Let's find out the information of theemployeetable that's present in the database.

PRAGMA TABLE_INFO(employee);

Note:
If the given table name does not exist,PRAGMA TABLE_INFOdoesn’t give any result.

Inserting Rows:
------------------
INSERTclause is used to insert new rows in a table.

Syntax:

INSERT INTO
    table_name (column1, column2,..., columnN)
VALUES
    (value11, value12,..., value1N),
    (value21, value22,..., value2N),
    ...;

Any number of rows from 1 to n can be inserted into a specified table using the above syntax.

SQL:

INSERT INTO
  player (name, age, score)
VALUES
  ("Rakesh", 39, 35),
  ("Sai", 47, 30);
  
SQL:

SELECT *
FROM player;

SQL:

INSERT INTO
  match_details (team_name, played_with, venue, date, is_won)
VALUES
  ("CSK", "MI", "Chennai", "2020-04-21", true),
  ("SRH", "RR", "Hyderabad", "2020-04-23", true);
  
Note:

Boolean values can be either given as (TRUE or FALSE) or (1 or 0). But in the database, the values are stored as 1 or 0.
Date object is represented as: ‘YYYY-MM-DD’
Datetime object is represented as: ‘YYYY-MM-DD HH:MM:SS’  

Warning
If the datatype of the input value doesn't match with the datatype of column, SQLite doesn't raise an error.

Retrieving Data:
-----------------------

SELECTclause is used to retrieve rows from a table. 

Database
The database consists of aplayertable that stores the details of players who are a part of a tournament.playertable stores the name, age and score of players.

Selecting Specific Columns:

SELECT
  column1,
  column2,
  ...,
  columnN
FROM
  table_name;
  
Example:

SELECT
  name,
  age
FROM
  player;
  
Selecting All Columns:

SELECT *
FROM table_name;

Example:

SELECT *
FROM player;

Selecting Specific Rows:

SELECT * 
FROM table_name
WHERE condition;

Example:

SELECT * 
FROM player 
WHERE name="Sai";

Update Rows:
-----------------

Update All Rows:

UPDATE
  table_name
SET
  column1 = value1;
  
Example:

UPDATE
  player
SET
  score = 100;
  
Update Specific Rows:

UPDATE
  table_name
SET
  column1 = value1
WHERE
  column2 = value2;
  
Example:

UPDATE
  player
SET
  score = 150
WHERE
  name = "Ram";
  
Delete Rows:
----------------------

Delete All Rows:

DELETE FROM
  table_name;
  
Example:

DELETE FROM
  player;
  
Delete Specific Rows:

DELETE FROM
  table_name
WHERE
  column1 = value1;
  
Example:

DELETE FROM
  player
WHERE
  name = "Shyam";
  
Warning
We can not retrieve the data once we delete the data from the table.

Drop Table:
------------------
DROPclause is used to delete a table from the database.

DROP TABLE table_name;

Example:

DROP TABLE player;

Alter Table:
-----------------------

Add Column:

ALTER TABLE
  table_name
ADD
  column_name datatype;
  
Example:

ALTER TABLE
  player
ADD
  jersey_num INT;
  
Note:

Default values for newly added columns in the existing rows will be NULL.

Rename Column:

ALTER TABLE
  table_name RENAME COLUMN c1 TO c2;
  
Example:

ALTER TABLE
  player RENAME COLUMN jersey_num TO jersey_number;
  
Drop Column:

ALTER TABLE
  table_name DROP COLUMN column_name;
  
Example:

ALTER TABLE
  player DROP COLUMN jersey_number;
  
Note:

DROP COLUMN is not supported in some DBMS, including SQLite.

Comparison Operators:
---------------------------

Operator	Description
=			Equal to
<>			Not equal to
<			Less than
<=			Less than or equal to
>			Greater than
>=			Greater than or equal to


Examples:
-----------------

SELECT
  *
FROM
  product
WHERE
  category = "Food";
  
  
SELECT
  *
FROM
  product
WHERE
  category <> "Food";
  
  
LIKE Operator:
-----------------------------

LIKEoperator is used to perform queries on strings. This operator is especially used inWHEREclause to retrieve all the rows that match the given pattern.

We writepatternsusing the followingwildcard characters:

Symbol	Description	Example:

Percent sign (%)	Represents zero or more characters		ch%finds ch, chips, chocolate..
Underscore (_)		Represents a single character			_atfinds mat, hat and bat

Common Patterns:
---------------------
Pattern	Example	Description:

Exact Match		WHERE name LIKE "mobiles"	Retrieves products whose name is exactly equals to "mobiles"
Starts With		WHERE name LIKE "mobiles%"	Retrieves products whose name starts with "mobiles"
Ends With		WHERE name LIKE "%mobiles"	Retrieves products whose name ends with "mobiles"
Contains		WHERE name LIKE "%mobiles%"	Retrieves products whose name contains with "mobiles"
Pattern Matching	WHERE name LIKE "a_%"	Retrieves products whose name starts with "a" and have at least 2 characters in length

syntax:

SELECT
    *
FROM
    table_name
WHERE
    c1 LIKE matching_pattern;
	
SELECT
  *
FROM
  product
WHERE
  category LIKE "Gadgets";
  
2. Get all the products which have exactly 5 characters inbrand from the product table.

SELECT
  *
FROM
  product
WHERE
  brand LIKE "_____";
  
Note:

The percent sign(%) is used when we are not sure of the number of characters present in the string.
If we know the exact length of the string, then the wildcard character underscore(_) comes in handy.

part-2:
--------------

AND, OR, NOT:

Operator	Description
AND			Used to fetch rows that satisfy two or more conditions.
OR			Used to fetch rows that satisfy at least one of the given conditions.
NOT			Used to negate a condition in theWHEREclause.

syntax:

SELECT
  *
FROM
  table_name
WHERE
  condition1
  operator condition2
  operator condition3
  ...;
  
Examples:
-------------------

Get all the details of the products whose
categoryis "Clothing" and
priceless than or equal to 1000 from theproducttable.

SELECT
  *
FROM
  product
WHERE
  category = "Clothing"
  AND price <= 1000;
  
2.Ignore all the products withnamecontaining "Cake" from the list of products.

SELECT
  *
FROM
  product
WHERE
  NOT name LIKE "%Cake%";
  
Order of precedence:
------------------------------

High to Low

NOT
AND
OR


Example:
------------------
Fetch the products that belong to

Redmi brandandratinggreater than 4 or
the products from OnePlus brand

SELECT
  *
FROM
  product
WHERE
  brand = "Redmi"
  AND rating > 4
  OR brand = "OnePlus";
  
In the above query,ANDhas the precedence overOR. So, the above query is equivalent to:

SELECT
    *
FROM
    product
WHERE
    (brand = "Redmi"
    AND rating > 4)
    OR brand = "OnePlus";
	
Quick Tip:
It is suggested to always use parenthesis to ensure correctness while grouping the conditions.

IN and BETWEEN Operators:
----------------------------------

IN Operator:
-----------------
Retrieves the corresponding rows from the table if the value of column(c1) is present in the given values(v1,v2,..).

Syntax:

SELECT
  *
FROM
  table_name
WHERE
  c1 IN (v1, v2,..);
  
Example:

SELECT
  *
FROM
  product
WHERE
  brand IN ( "Puma", "Levi's", "Mufti", "Lee", "Denim");
  
BETWEEN Operator:
----------------------
Retrieves all the rows from table that have cloumn(c1) value present between the given range(v1 and v2).

Syntax:

SELECT
  *
FROM
  table_name
WHERE
  c1 BETWEEN v1
  AND v2;
  
Note:
BETWEENoperator is inclusive, i.e., both the lower and upper limit values of the range are included.

Example:

SELECT
  name,
  price,
  brand
FROM
  product
WHERE
  price BETWEEN 1000
  AND 5000;

ORDER BY and DISTINCT:
------------------------------------

Syntax:

SELECT
  column1,
  column2,
..columnN
FROM
  table_name [WHERE condition]
ORDER BY
  column1 ASC / DESC,
  cloumn2 ASC / DESC;
  
Example:

Get all products in the order of lowestpriceand highestratingin "Puma" brand.

SELECT
  name,
  price,
  rating
FROM
  product
WHERE
  brand = "Puma"
ORDER BY
  price ASC,
  rating DESC;
  
DISTINCT:
------------------

DISTINCTclause is used to return the distinct i.e unique values.

Syntax:

SELECT
  DISTINCT column1, 
  column2,..
  columnN
FROM
  table_name
WHERE
  [condition];
  
Example:

Get all the brands present in theproducttable.

SELECT
  DISTINCT brand
FROM
  product
ORDER BY
  brand;
  
Pagination:
-----------------------

LIMIT:
--------------
LIMITclause is used to specify thenumber of rows(n)we would like to have in result.

Syntax:

SELECT
  column1,
  column2,..
  columnN
FROM
  table_name
LIMIT n;

Example
Get the details of 2 top-rated products from the brand "Puma".

SELECT
  name,
  price,
  rating
FROM
  product
WHERE
  brand = "Puma"
ORDER BY
  rating DESC
LIMIT 2;

OFFSET:
----------------------------
OFFSETclause is used to specify the position (from nth row) from where the chunk of the results are to be selected.

Syntax:

SELECT
  column1,
  column2,..
  columnN
FROM
  table_name 
OFFSET n;

Example
Get the details of 5 top-rated products, starting from 5th row.

SELECT
  name,
  price,
  rating
FROM
  product
ORDER BY
  rating DESC
LIMIT 5
OFFSET 5;


Aggregations:
---------------------------

player_match_details (
  name VARCHAR(250),
  match VARCHAR(10),
  score INTEGER,
  fours INTEGER,
  sixes INTEGER,
  year INTEGER
);

Aggregation Functions:
-------------------------
Combining multiple values into a single value is called aggregation. Following are the functions provided by SQL to perform aggregations on the given data:

Aggregate 	Functions	Description
COUNT		Counts the number of values
SUM			Adds all the values
MIN			Returns the minimum value
MAX			Returns the maximum value
AVG			Calculates the average of the values

Syntax:

SELECT
  aggregate_function(c1), 
  aggregate_function(c2)
FROM
  TABLE;
  
Examples:

SELECT
  SUM(score)
FROM
  player_match_details
WHERE
  name = "Ram";
  
  
Multiple:

SELECT
  MAX(score),
  MIN(score)
FROM
  player_match_details
WHERE
  year = 2011;
  
COUNT Variants:
----------------------------------
Calculate the total number of matches played in the tournament.

Variant 1:

 SELECT COUNT(*)    
 FROM player_match_details;
 
 Variant 2:
 
 SELECT COUNT(1)    
 FROM player_match_details;
 
 Variant 3:
 
 SELECT COUNT()    
 FROM player_match_details;
 
 Output of Variant 1, Variant 2 and Variant 3
All the variants, i.e., Variant 1,Variant 2andVariant 3give the same result: 18

Special Cases:
-----------------------
WhenSUMfunction is applied on non-numeric data types like strings, date, time, datetime etc.,SQLiteDBMS returns 0.0 and PostgreSQLDBMS returnsNone.
Aggregate functions on strings and their outputs

Aggregate Functions		Output
MIN, MAX			Based on lexicographic ordering
SUM, AVG			0 (depends on DBMS)
COUNT				Default behavior

NULLvalues are ignored while computing the aggregation values
When aggregate functions are applied on only NULLvalues:

Aggregate Functions	Output
MIN					NULL
MAX					NULL
SUM					NULL
COUNT				0
AVG					NULL

Alias:
---------------

Using the keywordAS, we can provide alternate temporary names to the columns in the output.

Syntax:

SELECT
  c1 AS a1,
  c2 AS a2,
  ...
FROM
  table_name;
  
Examples:

Get all the names of players with column name as "player_name".

SELECT
  name AS player_name
FROM
  player_match_details;
  
Get the average score of players as "avg_score".

SELECT
  AVG(score) AS avg_score
FROM
  player_match_details;


Group By with Having:
------------------------------------------

Schema:

CREATE TABLE player_match_details (
   name VARCHAR(250),
   match VARCHAR(250),
   score INTEGER,
   fours INTEGER,
   sixes INTEGER,
   year INTEGER
);

GROUP BY
TheGROUP BYclause in SQL is used to group rows which have same values for the mentioned attributes.

Syntax:

SELECT
  c1,
  aggregate_function(c2)
FROM
  table_name
GROUP BY c1;

Example:

Get the total score of each player in the database.

SELECT
  name, SUM(score) as total_score
FROM
  player_match_details
GROUP BY name;

Output:

name	total_score
David	105
Joseph	116
Lokesh	186
...		...

GROUP BY with WHERE:
---------------------------------

We use WHERE clause to filter the data before performing aggregation.

Syntax:

SELECT
  c1,
  aggregate_function(c2)
FROM
  table_name
WHERE 
  c3 = v1
GROUP BY c1;

Example:

Get the number of half-centuries scored by each player

SELECT
 name, COUNT(*) AS half_centuries
FROM 
 player_match_details
WHERE score >= 50
GROUP BY name;

Output:

name	half_centuries
David	1
Joseph	2
Lokesh	3
...		...
 
HAVING:
-------------------------

HAVINGclause is used to filter the resultant rows after the application ofGROUP BYclause.

Syntax:

SELECT
  c1,
  c2,
  aggregate_function(c1)
FROM
  table_name
GROUP BY 
  c1, c2
HAVING 
  condition;
  
  
Example:

Get thenameand number ofhalf_centuriesof players who scored more than one half century.

SELECT
  name,
  count(*) AS half_centuries
FROM
  player_match_details
WHERE
  score >= 50
GROUP BY
  name
HAVING
  half_centuries > 1;

Output:

name	half_centuries
Lokesh	2
Ram		3

Note:
WHERE vs HAVING: 
WHERE is used to filter rows and this operation is performed before grouping. 
HAVING is used to filter groups and this operation is performed after grouping.

Example:

For each player who scored more than 50 in at least 2 matches, get the total number of matches where the players scored more than 50.

Note: Output must contain rows in the ascending order ofnameof the player.

SELECT
  name,
  count(MATCH) AS no_of_matches
FROM
  player_match_details
WHERE
  score > 50
GROUP BY
  name
HAVING
  no_of_matches >= 2
  
Expressions in Querying:
----------------------------------------

We can write expressions in various SQL clauses. Expressions can comprise of various data types like integers, floats, strings, datetime, etc. 

learn more about expressions using the following database.

Database

The IMDb stores various movies, actors and cast information.

Using Expressions in SELECT Clause:
---------------------------------------------------

Get profits of all movies.
Note: Consider profit as the difference between collection and budget.

SELECT 
    id, name, (collection_in_cr-budget_in_cr) as profit
FROM
    movie;
	
Output:

id	name			profit
1	The matrix		40.31
2	Inception		67.68
3	The Dark Knight	82.5
...	...				...

Note:
We use "||" operator to concatenate strings in sqlite3

Get the movienameandgenrein the following format:movie_name - genre.

SELECT
  name || " - " || genre AS movie_genre
FROM
  movie;
  
Output:

movie_genre
The Matrix - Sci-fi
Inception - Action
The Dark Knight - Drama
Toy Story 3 - Animation
...

Using Expressions in WHERE Clause:
--------------------------------------------------

Get all the movies with a profit of at least 50 crores.

SELECT
   *
FROM
   movie
WHERE
   (collection_in_cr - budget_in_cr) >= 50;
   
Using Expressions in UPDATE Clause:
-----------------------------------------------------

Scale down ratings from 10 to 5 in movie table.

UPDATE movie
SET rating = rating/2;

Expressions in HAVING Clause:
--------------------------------------

Get all the genres that have average profit greater than 100 crores.

SELECT
  genre
FROM
  movie
GROUP BY
  genre
HAVING
  AVG(collection_in_cr - budget_in_cr) >= 100;
  
SQL Functions:
-------------------------

 SQL provides many built-in functions to perform various operations over data that is stored in tables.
look at a few most commonly used functions in the industry using the following database.

Database
The IMDb dataset stores the information of movies, actors and cast.

Date Functions:
----------------------
strftime():

strftime() function is used to extract month, year, etc. from a date/datetime field based on a specified format.

Syntax:

strftime(format, field_name)

Example:
Get the movie title and release year for every movie in the database 

SELECT name, strftime('%Y', release_date)
FROM
    movie;
	
In the above query, we extract year from release_date by writing strftime('%Y', release_date) in SELECT clause. 

Let understand various formats in date functions with an example.
Consider the datetime 2021-02-28 08:30:05

format	description		output format	Example
%d	Day of the month	01 - 31			28
%H	Hour				00 - 24			08
%m	Month				01 - 12			02
%j	Day of the year		001 - 365		59
%M	Minute				00-59			30
...	...					...				...

Example:

Get the number of movies released in each month of the year 2010

SELECT 
    strftime('%m', release_date) as month,
    COUNT(*) as total_movies
FROM
    movie
WHERE
    strftime('%Y', release_date) = '2010'
GROUP BY
    strftime('%m', release_date);
	
CAST Function:
------------------------

CAST function is used to typecast a value to a desired data type.

Syntax:

CAST(value AS data_type);

Example:

Get the number of movies released in each month of the year 2010

SELECT strftime('%m', release_date) as month,
        COUNT(*) as total_movies
FROM
    movie
WHERE
    CAST(strftime('%Y', release_date) AS INTEGER) = 2010
GROUP BY
    strftime('%m', release_date);
	
Here,CAST(strftime('%Y', release_date) AS INTEGER) converts the year in string format to integer format. 


Other Common Functions:
----------------------------------

Arithmetic Functions:

SQL Function	Behavior
FLOOR		Rounds a number to the nearest integer below its current value
CEIL		Rounds a number to the nearest integer above its current value
ROUND		Rounds a number to a specified number of decimal places

You can refer the following table to further understand how floor, ceil and round work in general.

		2.3	3.9	4.0	5.5
FLOOR	2	3	4	5
CEIL	3	4	4	6
ROUND	2	4	4	6
Let understand how these functions can be used. 

Examples:

Fetch the ceil, floor and round (to 1 decimal) values of the collections of all movies.

SELECT
    name,
  ROUND(collection_in_cr, 1) AS RoundedValue,
  CEIL(collection_in_cr) AS CeilValue,
  FLOOR(collection_in_cr) AS FloorValue
FROM
  movie;
  
String Functions:
------------------------------

SQL Function	Behavior
UPPER	Converts a string to upper case
LOWER	Converts a string to lower case

When you are not sure about the case (upper/lower) of the movie name, 
you can write a query as below to search for all the avengers movies irrespective of the case. 

SELECT
   name
FROM
  movie
  WHERE UPPER(name) LIKE UPPER("%avengers%");
  
Note:
Usually, UPPER() AND LOWER() functions can help you to perform case-insensitive searches.

CASE Clause:
-------------------------

SQL provides CASE clause to perform conditional operations. This is similar to the switch case / if-else conditions in other programming languages.

Let learn more about the usage of CASE clause using the given database

CASE Clause:

Each condition in the CASE clause is evaluated and results in corresponding value when the first condition is met.

Syntax:

SELECT c1, c2
CASE
    WHEN condition1 THEN value1
    WHEN condition2 THEN value2
    ...
    ELSE value
    END AS cn
FROM table;

Note:

In CASE clause, if no condition is satisfied, it returns the value in the ELSE part. If we do not specify the ELSE part, CASE clause results in NULL

We can use CASE in various clauses like SELECT, WHERE, HAVING, ORDER BY and GROUP BY.

Example:

Calculate the tax amount for all movies based on the profit. Check the following table for tax percentages.

profit				tax_percentage
<=100 crores		10% of profit
100< <=500 crores	15% of profit
> 500 crores		18% of profit

SELECT id, name,
  CASE
    WHEN collection_in_cr - budget_in_cr <= 100 THEN collection_in_cr - budget_in_cr * 0.1
    WHEN (collection_in_cr - budget_in_cr > 100
    AND collection_in_cr - budget_in_cr < 500) THEN collection_in_cr - budget_in_cr * 0.15
    ELSE collection_in_cr - budget_in_cr * 0.18
  END AS tax_amount
FROM
  movie;
  
Output:

id	name		tax_amount
1	The Matrix		45.8
2	Inception		82.08
3	The Dark Knight	98.7
...		...			...

CASE with Aggregates:
---------------------------------

CASE statements can also be used together with aggregate functions

Example:

Get the number of movies with rating greater than or equal to 8, and the movies with rating less than 8, and are released between 2015 and 2020.

SELECT
  count(
    CASE
      WHEN rating >= 8 THEN 1
    END
  ) AS above_eight,
  count(
    CASE
      WHEN rating < 8 THEN 1
    END
  ) AS below_eight
FROM
  movie
WHERE
  CAST(strftime("%Y", release_date) AS INTEGER) BETWEEN 2015
  AND 2020;
  
Output:

above_eight	below_eight
4				2

Common Set Operators:
------------------------------

INTERSECT:

Actors who acted in both Sherlock Holmes and Avengers Endgame

Result: Robert D Jr.

MINUS:

Actors who acted in Sherlock Holmes and not in Avengers Endgame

Result: Jude Law, Mark Strong

UNION:

Unique actors who acted in Sherlock Holmes or in Avengers Endgame

Result: Jude Law, Mark Strong, Robert D Jr, Chris Evans, Mark Ruffalo

UNION ALL:

Doesnt eliminate duplicate results 

Result: Jude Law, Mark Strong, Robert D Jr, Robert D Jr, Chris Evans, Mark Ruffalo

Applying Set Operations:
--------------------------------------

We can apply these set operations on the one or more sql queries to combine their results  

Syntax:

SELECT
    c1, c2
FROM
    table_name
SET_OPERATOR
SELECT
    c1, c2
FROM
    table_name;
	
Basic rules when combining two sql queries using set operations:

Each SELECT statement must have the same number of columns
The columns must have similar data types
The columns in each SELECT statement must be in the same order


Examples:

Get ids of actors who acted in both Sherlock Holmes(id=6) and Avengers Endgame(id=15)?

SELECT actor_id
FROM cast
WHERE movie_id=6
INTERSECT
SELECT actor_id
FROM cast
WHERE movie_id=15;

Output:

actor_id
6

Get ids of actors who acted in Sherlock Holmes(id=6) and not in Avengers Endgame(id=15)?

SELECT actor_id
FROM cast
WHERE movie_id=6
EXCEPT
SELECT actor_id
FROM cast
WHERE movie_id=15;

Output:

actor_id
16

Get distinct ids of actors who acted in Sherlock Holmes(id=6) or Avengers Endgame(id=15).

SELECT actor_id
FROM cast
WHERE movie_id=6
UNION
SELECT actor_id
FROM cast
WHERE movie_id=15;

Output:

actor_id
6
8
16
21
22

Pagination in Set Operations:
---------------------------------------

Similar to ORDER BY clause, LIMIT and OFFSET clauses are used at the end of the list of queries.

Example:

Get the first 5 ids of actors who acted in Sherlock Holmes (id=6) or Avengers Endgame(id=15). Sort ids in the descending order.

SELECT actor_id
FROM cast
WHERE movie_id=6
UNION
SELECT actor_id
FROM cast
WHERE movie_id=15
ORDER BY 1 DESC
LIMIT 5;

coding pratice-common concepts:
---------------------------------------------

1.Calculate overall number of boundaries scored by each batsmen in the tournament

number of boundaries = fours + sixes

Note: Output must contain rows in the descending order ofnumber_of_boundaries and name

SELECT
  name,
  sum(fours + sixes) AS number_of_boundaries
FROM
  player
GROUP BY
  name
ORDER BY
  number_of_boundaries DESC,
  name DESC;
  
name	number_of_boundaries
Ravi	24
Sai		16
Jadhav	11
Manoj	10
Vijay	7
Raghav	3
Karthik	3
Sanjay	2
Madhu	1

SELECT
  name,
  MATCH,
  (CAST(score AS FLOAT) / no_of_balls) * 100 AS strike_rate
FROM
  player
ORDER BY
  strike_rate DESC;
  
4.Lets generate a performance report for all the players who played in the year 2006.

Apply the below logic to grade the players performance.

total score		performance report
>= 150					GOOD
100<= <150				AVERAGE
<100				BELOW AVERAGE
 in the year 2006

Note: Output must be in the descending order of total_score

SELECT
  name,
  SUM(score) AS total_score,
  CASE
    WHEN SUM(score) >= 150 THEN "GOOD"
    WHEN SUM(score) < 150
    AND SUM(score) >= 100 THEN "AVERAGE"
    ELSE "BELOW AVERAGE"
  END AS badge
FROM
  player
WHERE
  CAST(strftime("%Y", match_date) AS INTEGER) = 2006
GROUP BY
  name
ORDER BY
  total_score DESC;
  
name	total_score		badge
Sai		175				GOOD
Jadhav	104				AVERAGE
Ravi	92				BELOW AVERAGE
Manoj	68				BELOW AVERAGE

5.For each player, get the number of matches in which their strike rate is less than 80.0, 
and the number of matches with strike rate greater than or equal to 80.0.

Note: Output must be in the ascending order of name

SELECT
  name,
  COUNT (
    CASE
      WHEN (CAST(score AS FLOAT) / no_of_balls) * 100 < 80.0 THEN 1
      ELSE NULL
    END
  ) AS strike_rate_less_than_80,
  COUNT (
    CASE
      WHEN (CAST(score AS FLOAT) / no_of_balls) * 100 >= 80.0 THEN 1
      ELSE NULL
    END
  ) AS strike_rate_greater_than_or_equal_to_80
FROM
  player
GROUP BY
  name
ORDER BY
  name;
  
name	strike_rate_less_than_80	strike_rate_greater_than_or_equal_to_80
Jadhav		0									2
Karthik		0									1
Madhu		1									0
Manoj		1									1
Raghav		0									1
Ravi		1									3
Sai			0									3
Sanjay		1									0
Vijay		0									1

6.Get all the player/s who played for both CSK and RCB.

Note: Output must be in the ascending order of name

SELECT
  name
FROM
  player
WHERE
  played_for_team = "CSK"
INTERSECT
SELECT
  name
FROM
  player
WHERE
  played_for_team = "RCB"
ORDER BY
  name ASC;
  
7.Get all the player/s who played only for SRH

Note: 

Names in the output must be in capital letters.
Output must be in the ascending order of name

SELECT
  UPPER(name) AS name
FROM
  player
WHERE
  played_for_team = "SRH"
EXCEPT
SELECT
  UPPER(name)
FROM
  player
WHERE
  played_for_team <> "SRH"
ORDER BY
  name
  
8.Get all the player/s who played either for SRH, CSK, or MI.

Note: 
- Get unique players.
- Output must be in the ascending order of name

SELECT
  name
FROM
  player
WHERE
  played_for_team = "CSK"
UNION
SELECT
  name
FROM
  player
WHERE
  played_for_team = "SRH"
UNION
SELECT
  name
FROM
  player
WHERE
  played_for_team = "MI"
ORDER BY
  name ASC;
  
9.Fetch the name, highest and lowest scores of player/s for the matches in which strike rate is greater than 50.0.

SELECT
  name,
  max(score) AS highest_score,
  min(score) AS lowest_score
FROM
  player
WHERE
  (CAST (score AS float) / no_of_balls * 100) > 50
GROUP BY
  name
  
Milestone 1 Cheat Sheet:
----------------------------------------

coding assignment-1:
-----------------------------------

12.Get the number of male and female premium users in the platform.

SELECT
  gender,
  CASE
    WHEN gender = "F" THEN count("F")
    WHEN gender = "M" THEN count("M")
  END AS total_users
FROM
  user
WHERE
  premium_membership = 1
GROUP BY
  gender
  
gender	total_users
F	232
M	249

assignment-2:
----------------------------

4.Get the ids of all the channels that have uploaded at least 50 videos.

Note:
Sort the output in the ascending order of thechannel_id

SELECT
  channel_id
FROM
  video
GROUP BY
  channel_id
HAVING
  count(video_id) >= 50
ORDER BY
  channel_id ASC;
  
channel_id
353
364
365
366

7.Categorise the performance of all the videos released by the “Motivation grid” Channel (id = 350).

Performance of a video is measured based on the number of views of the video.

Categorization
no_of_views						category
<= 10000						poor
10000 < views <= 100000 and		average
> 100000						good
Note
Sort the output in the ascending order ofpublished_datetime

SELECT
  name,
  no_of_views,
  CASE
    WHEN (no_of_views) <= 10000 THEN "poor"
    WHEN (no_of_views) > 10000
    AND (no_of_views) <= 100000 THEN "average"
    ELSE "good"
  END AS category
FROM
  video
WHERE
  channel_id = 350
ORDER BY
  published_datetime ASC
  
9.For Marvel channel (id = 351), get the number of subscribers added in each month in the year 2020.

Note:
You can find the subscribed date of a user for a channel in thechannel_usertable.
For this question, convert themonth_of_yearin string datatype to INT datatype.
Sort the output in the ascending order of the month.

SELECT
  CAST(strftime("%m", subscribed_datetime) AS INTEGER) AS month_of_year,
  count(user_id) AS no_of_subscribers
FROM
  channel_user
WHERE
  channel_id = 351
  AND CAST(strftime("%Y", subscribed_datetime) AS INTEGER) = 2020
GROUP BY
  month_of_year
ORDER BY
  month_of_year ASC
  
month_of_year	no_of_subscribers
3					2
4					3
11					1
12					2

11.Get all the channel_ids that uploaded at least one video in "AI/ML" or "Robotics" technologies between 2018 and 2021. 

Note:
Consider all the videos that have any of the technologies mentioned above in theirname
Sort the output in the ascending order ofchannel_id

SELECT
  channel_id
FROM
  video
WHERE
  name LIKE '%AI/ML%'
  OR name LIKE '%Robotics%'
  AND CAST(strftime("%Y", published_datetime) AS INTEGER) BETWEEN 2018
  AND 2021
GROUP BY
  channel_id
ORDER BY
  channel_id ASC;
  
channel_id
351
353
364
365
377

12.Get all the channel_ids that uploaded at least 20 videos in "AI/ML", "Cyber Security", "Data Science" or "Robotics" technologies between 2018 and 2021.

Example: If a channel publishes 5 videos in AI/ML, 10 videos in Cyber Security and 5 videos in Data Science, consider the channel.

Note:
Consider all the videos that have any of the technologies mentioned above in theirname
Sort the output in the ascending order of channel_id.

SELECT
  channel_id
FROM
  video
WHERE
  name LIKE '%AI/ML%'
  OR name LIKE '%Robotics%'
  OR name LIKE '%Cyber Security%'
  OR name LIKE '%Data Science%'
  AND CAST(strftime("%Y", published_datetime) AS INTEGER) BETWEEN 2018
  AND 2021
GROUP BY
  channel_id
HAVING
  count(name LIKE '%AI/ML%') > 5
  AND count(name LIKE '%Cyber Security%') > 10
  AND count(name LIKE '%Data Science%') > 5
  AND CAST(strftime("%Y", published_datetime) AS INTEGER) BETWEEN 2018
  AND 2021
ORDER BY
  channel_id ASC;
  
channel_id
353
364
365



Modelling Databases: Part 1:
------------------------------------------

Core Concepts in ER Model

Entity:
-------------------------
Real world objects/concepts are called entities in ER Model.

Attributes of an Entity:
----------------------------------
Properties of real world objects/concepts are represented as attributes of an entity in ER model.

Key Attribute:
-------------------
The attribute that uniquely identifies each entity is called key attribute.

Entity Type:
-------------------------
Entity Type is a collection of entities that have the same attributes (not values).

Relationships:
-----------------------
Association among the entities is called a relationship.

Example:

Person has a passport.
Person can have many cars.
Each student can register for many courses, and a course can have many students.

Types of relationships:
-----------------------------

One-to-One Relationship
One-to-Many or Many-to-One Relationship
Many-to-Many Relationship

One-to-One Relationship:
----------------------------------

An entity is related to only one entity, and vice versa.

Example:
A person can have only one passport.
similarly, a passport belongs to one and only one person.

One-to-Many Relationship:
-----------------------------------------------

An entity is related to many other entities.

Example:
A person can have many cars. But a car belongs to only one person.

Many-to-Many Relationship:
---------------------------------------------

Multiple entities are related to multiple entities.

Example:
Each student can register to multiple courses.
similarly each course is taken by multiple students.

Cardinality Ratio:
-------------------------------
Cardinality in DBMS defines the maximum number of times an instance in one entity can relate to instances of another entity.

1:1
1:n
n:1
m:n

Primary Key:
-------------------

Following syntax creates a table withc1as the primary key.

Syntax:

CREATE TABLE table_name (
    c1 t1 NOT NULL PRIMARY KEY, 
...
    cn tn, 
);

Foreign Key:
---------------------------

In case of foreign key, we just create a foreign key constraint.

Syntax:

CREATE TABLE table2(
  c1 t1 NOT NULL PRIMARY KEY,
  c2 t2,
  FOREIGN KEY(c2) REFERENCES table1(c3) ON DELETE CASCADE
);

Understanding:

FOREIGN KEY(c2) REFERENCES table1(c3)

Above part of the foreign key constraint ensure that foreign key can only contain values that are in the referenced primary key.


ON DELETE CASCADE

Ensure that if a row intable1is deleted, then all its related rows intable2will also be deleted.

Note:
To enable foreign key constraints in SQLite, usePRAGMA foreign_keys = ON; By default it is enabled in our platform!

Creating Tables in Relational Database:
---------------------------------------------------

Customer Table:

CREATE TABLE customer (
   id INTEGER NOT NULL PRIMARY KEY,
   name VARCHAR(250),
   age INT
);

Product Table:

CREATE TABLE product (
  id INTEGER NOT NULL PRIMARY KEY,
  name VARCHAR(250),
  price INT,
  brand VARCHAR(250),
  category VARCHAR(250)
);

Address Table:

CREATE TABLE address(
  id INTEGER NOT NULL PRIMARY KEY,
  pin_code INTEGER,
  door_no VARCHAR(250),
  city VARCHAR(250),
  customer_id INTEGER,
  FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE CASCADE
);

Cart Table:

CREATE TABLE cart(
  id INTEGER NOT NULL PRIMARY KEY,
  customer_id INTEGER NOT NULL UNIQUE,
  total_price INTEGER,
  FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE CASCADE
);

Cart Product Table (Junction Table):

CREATE TABLE cart_product(
  id INTEGER NOT NULL PRIMARY KEY,
  cart_id INTEGER,
  product_id INTEGER,
  quantity INTEGER,
  FOREIGN KEY (cart_id) REFERENCES cart(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE CASCADE
);

coding pratice-Modelling Databases:
--------------------------------------------------------

In this practice set, lets build a relational database for a typical social networking site.

In a social networking site, we have user, post, group, and comment entities.

Use Case:

A user can create multiple posts. Each post can have only one user.
A user can make multiple comments to a post. Each comment can have only one user.
A post can have multiple comments. Each comment can have only one post.
A user can be in multiple groups. Each group can have multiple users.

1.Write a query to represent the user entity type in the relational database. Below are the attributes of a user entity type.

attribute			description
id			an integer to uniquely identify a user - key attribute
name		a string of max length 250 characters
gender		a string of max length 50 characters
email_id	a string of max length 500 characters

CREATE TABLE user (
  id int NOT NULL PRIMARY KEY,
  name varchar(250),
  gender varchar(50),
  email_id varchar(500)
)

2.We have created a user table in the database.

Now, lets write a query to represent the post entity type and its relation with user entity type.

Below are the attributes of the post entity type.

attribute	  description
post_id			an integer to uniquely identify a post - key attribute
content			a text field
published_at	datetime field


Note:
Create a table in such a way that if we delete a user from the user table, then the related posts in the post table must be automatically deleted.

CREATE TABLE post(
  post_id INT NOT NULL PRIMARY KEY,
  content TEXT,
  published_at DATETIME,
  user_id INT,
  FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
);

3.We have created user and post tables in the database. Now, users want to comment on the posts. So, lets create a comment table.

Write a query to represent the comment entity type, and its relation with user and post entity types.

Attributes of a comment entity type are given below.
attribute		description
comment_id		an integer to uniquely identify a comment - key attribute
content	a 		text field
commented_at	datetime field
Note:
Create a table in such a way that:
 
If we delete a user from the user table, then the related comments in the comment table must be automatically deleted.
Similarly, if we delete a post, then the comments related to the post must be automatically deleted.

CREATE TABLE COMMENT(
  comment_id INT NOT NULL PRIMARY KEY,
  content TEXT,
  commented_at DATETIME,
  user_id INT,
  post_id int,
  FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
  FOREIGN KEY (post_id) REFERENCES post(post_id) ON DELETE CASCADE
);

4.Any social network application has groups with users of similar interests. 
Now, let’s create a group_details table that stores the information about a group.

Write a query to represent the group_details entity type in the relational database. Below are the attributes of the entity type.

attribute	description
id			an integer to uniquely identify a group - key attribute
name		a string of max length 500 characters

CREATE TABLE group_details(
  id INT NOT NULL PRIMARY KEY,
  name varchar(500)
);

5.A user can be in multiple groups, and a group can contain many users.

Now, let’s create user_group table to capture the many-to-many relationship between user and group entity types.

Below are the attributes of the relationship.

attribute	description
joined_at	a datetime field
is_admin	a boolean field

Note:
Create this junction table in such a way that if we delete a user/group, then the related data in the user_group must be automatically deleted.

CREATE TABLE user_group(
  user_id INT,
  group_id INT,
  joined_at DATETIME,
  is_admin bool,
  FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
  FOREIGN KEY (group_id) REFERENCES group_details(id) ON DELETE CASCADE
);

Joins Cheat Sheet | Part - 1:
----------------------------------------

Natural JOIN:
----------------------------

NATURAL JOINcombines the tables based on the common columns.

Syntax:

SELECT *
FROM table1
   NATURAL JOIN table2;
   
Example:

1.Fetch the details of courses that are being taught by "Alex".

Solving this problem involves querying on data stored in two tables, i.e.,course&instructor. 
Both the tables have common columninstructor_id. Hence, we use Natural Join.

SELECT course.name,
  instructor.full_name
FROM course
  NATURAL JOIN instructor
WHERE instructor.full_name = "Alex";

Output:

name			full_name
Cyber Security	Alex

INNER JOIN:
--------------------------
INNER JOIN combines rows from both the tables if they meet a specified condition.

Syntax:

SELECT *
FROM table1
   INNER JOIN table2
ON table1.c1 = table2.c2;

Note:
We can use any comparison operator in the condition.

Example:
Get the reviews of course “Cyber Security” (course with id=15)

SELECT student.full_name,
   review.content,
   review.created_at
FROM student
   INNER JOIN review 
ON student.id = review.student_id
WHERE review.course_id = 15;

Output:

full_name	content					created_at
Ajay	Good explanation			2021-01-19
Ajay	Cyber Security is awesome	2021-01-20


LEFT JOIN:
--------------------

InLEFT JOIN, for each row in the left table, matched rows from the right table are combined. If there is no match, NULL values are assigned to the right half of the rows in the temporary table.

Syntax:

SELECT *
FROM table1
   LEFT JOIN table2 
ON table1.c1 = tabl2.c2;

Example:
Fetch the full_name of students who have not enrolled for any course

SELECT student.full_name
FROM student
   LEFT JOIN student_course
ON student.id = student_course.student_id
WHERE student_course.id IS NULL;

Output:

full_name
Afrin

coding practice-1:
---------------------------------------

Database:
The database stores the sample data of an e-learning platform. The database consists of instructor, course, review, and student tables.

An instructor can teach many courses. A course is taught by only one instructor.
A student can enroll for multiple courses. A course can have multiple students.
A student can give multiple reviews.
A course can have multiple reviews

1.Perform natural join between course and instructor table.

Note:
Do not apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  *
FROM
  course NATURAL
  JOIN instructor
  
2.Perform inner join between review and student table.

Note:
Do not apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  *
FROM
  review
  INNER JOIN student ON review.student_id = student.id
  
3.Get all the reviews along with the course names.
Every review is associated with a course. So, we can perform an inner join on reviewandcoursetables.

Note:
Do not apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  *
FROM
  review
  INNER JOIN course ON review.course_id = course.id

4.Continuation of question 3.

Get all the reviews on the “Cyber Security” course.

Note:
We can perform inner join onreviewandcoursetable.
Do not apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  *
FROM
  review
  INNER JOIN course ON review.course_id = course.id
WHERE
  course.name LIKE "Cyber Security";
  
5.Get all the courses and corresponding reviews.
For every course, there need not be a review. So, we need to perform a left join between the course and review tables.

Note:
Do not apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem

SELECT
  *
FROM
  course
  LEFT JOIN review ON course.id = review.course_id
  
6.Continuation of question 5.
For the “Cyber Security” course, get all the reviews using the left join between the course and review tables.

Note:
Dont apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem

SELECT
  *
FROM
  course
  LEFT JOIN review ON course.id = review.course_id
WHERE
  course.name LIKE "Cyber Security";
  
7.Continuation of question 5.
For the “Linux” course, get all the reviews using the left join between the course and review tables.

Note:
Dont apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem

SELECT
  *
FROM
  course
  LEFT JOIN review ON course.id = review.course_id
WHERE
  course.name = "Linux";
  
8.In question 7, as the course “Linux” has no reviews, the columns corresponding to review table i.e id, content, etc., in the output has NULL value.
Now, to get all the courses that does not have any reviews, 
We shall perform left join between courseandreviewtables, and then filter the rows for whichreview.id is NULL

Note:
Dont apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem

SELECT
  course.name
FROM
  course
  LEFT JOIN review ON course.id = review.course_id
WHERE
  review.id IS NULL;

9.Get the full_name of students who have not enrolled in any course.

Note:
We can perform left join betweenstudentandstudent_coursetables, and then filter the rows for whichcourse_idis NULL
Dont apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  full_name
FROM
  student
  LEFT JOIN student_course ON student.id = student_course.student_id
WHERE
  course_id IS NULL;
  
10.Get the course names in which no student has registered.

Note:
We can perform left join betweencourseandstudent_coursetables, and then filter the rows for whichstudent_idis NULL
Dont apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  name
FROM
  course
  LEFT JOIN student_course ON course.id = student_course.course_id
WHERE
  student_id IS NULL;



Querying with Joins Cheat Sheet | Part - 2:
---------------------------------------------------------------

Joins on Multiple Tables
We can also perform join on a combined table.

Example:

Fetch all the students who enrolled for the courses taught by the instructor “Arun” (id = 102)

SELECT T.name AS course_name,
   student.full_name
FROM (course
   INNER JOIN student_course
ON course.id = student_course.course_id) AS T
   INNER JOIN student
ON T.student_id = student.id
WHERE course.instructor_id = 102;

Output:

course_name			full_name
Machine Learning	Varun
Machine Learning	Sandya

Note:
Best Practices

Use ALIAS to name the combined table.

Use alias table names to refer the columns in the combined table.

Using joins with other clauses:
---------------------------------------

We can apply WHERE,ORDER BY,HAVING,GROUP BY,LIMIT,OFFSET and other clauses (which are used for retrieving data tables) on the temporary joined table as well.

Example:
Get the name of the student who scored highest in "Machine Learning" course.

SELECT student.full_name
FROM (course
   INNER JOIN student_course
ON course.id = student_course.course_id) AS T
   INNER JOIN student
ON T.student_id = student.id
WHERE course.name = "Machine Learning"
ORDER BY student_course.score DESC
LIMIT 1;

Output:

full_name
Sandhya

Using joins with aggregations:
--------------------------------------------

We can apply WHERE, ORDER BY, HAVING, GROUP BY, LIMIT, OFFSET and other clauses (which are used for retrieving data tables) 
on the temporary joined table as well.

Get the highest score in each course.

SELECT
  course.name AS course_name,
  MAX(score) AS highest_score
FROM
  course
  LEFT JOIN student_course 
ON course.id = student_course.course_id
GROUP BY
  course.id;
  
Output:

course_name			highest_score
Machine Learning	90
Cyber Security		60
Linux	

coding practice-2:
---------------------------------------

1.
Fetch all the courses that are being taught by “Alex”.

Note:
Solving this problem involves joining ofcoursetable andinstructortable. Note that both the tables haveinstructor_idcolumn in common.
As we only want the courses taught by "Alex", we have to apply filter condition.
Dont apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  course.id AS course_id,
  course.name AS course_name,
  instructor.full_name AS instructor_name
FROM
  course NATURAL
  JOIN instructor
WHERE
  instructor.full_name = 'Alex'
  
2.Get all the reviews of “Cyber Security” course .

Note:
Solving this problem involves performing inner join on review and course tables.
Dont apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  course.name AS course_name,
  student_id,
  content
FROM
  review
  INNER JOIN course ON course.id = review.course_id
WHERE
  course.name = "Cyber Security";
  
Output:

course_name		student_id	content
Cyber Security		2		Good explanation
Cyber Security		2		Cyber Security is awesome

3.For a student with student (id = 1), get all the courses and the scores she/he secured in the year 2021.

Note:
Solving this question involves performing inner join onstudent_course and course tables.
You can get the year from the enrollment date.

SELECT
  student_id,
  course.name,
  score
FROM
  student_course
  INNER JOIN course ON course.id = student_course.course_id
WHERE
  student_course.student_id = 1
  AND strftime("%Y", enrollment_date) = '2021';
  
Output:

tudent_id	name			score
1		Machine Learning	80
1		Data Science		98
1		Augmented Reality	40

4.Get all the student details who scored more than 70 in Cyber Security course (course_id = 15) in the year 2020.

Note:
Solving this question involves performing inner join on student_course and student tables.
You can get the year from the enrollment date.

SELECT
  student_id,
  student.full_name AS student_name,
  score,
  course_id,
  enrollment_date
FROM
  student_course
  INNER JOIN student ON student_course.student_id = student.id
WHERE
  student_course.course_id = 15
  AND strftime("%Y", enrollment_date) = '2020'
  AND score > 70;
  
Output:

student_id	student_name	score	course_id	enrollment_date
6				vihu		75		15			2020-01-16
1				Varun		90		15			2020-01-16

5.Get all the student_ids who enrolled for the "Machine Learning" course in 2021.

Note:
Solving this question involves performing inner join on student_course and course tables.
You can get the year from the enrollment date.

SELECT
  student_id,
  course.name AS course_name,
  enrollment_date
FROM
  student_course
  INNER JOIN course ON student_course.course_id = course.id
WHERE
  course.name = "Machine Learning"
  AND strftime("%Y", enrollment_date) = '2021';
  
Output:

student_id	course_name			enrollment_date
1			Machine Learning	2021-01-16
3			Machine Learning	2021-01-19

6.Continuation of question 5.
Get the number of students who enrolled for the "Machine Learning" course in 2021.

Note:
Solving this question involves performing inner join on course and student_course tables.
You can get the year from the enrollment date.
We have to perform the count() aggregation.

SELECT
  course.name AS course_name,
  count() AS no_of_students
FROM
  course
  INNER JOIN student_course ON course.id = student_course.course_id
WHERE
  course.name = "Machine Learning"
  AND CAST(strftime("%Y", enrollment_date) AS integer) = 2021;
  
 Output:
 
course_name			no_of_students
Machine Learning	2

7.Get the number of courses taken by “Ram”.

Note:
You can get the year from the enrollment date
Dont apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  full_name,
  count() AS no_of_courses
FROM
  student
  INNER JOIN student_course ON student.id = student_course.student_id
WHERE
  student.full_name = "Ram";
  
Output:

full_name	no_of_courses
Ram				3

8.For all the students, get the total number of courses taken by each student.

A student need not register for any course as well. So, we need to perform a left join between the student and student_course tables.

Note:
You can get the year from the enrollment date
As we have to calculate the number of courses for each student, we have to GROUP BY the students first and then perform the count() aggregation.
Dont apply ORDER BY, LIMIT, OFFSET clauses as it is not required for this problem.

SELECT
  student.full_name,
  count(student_course.course_id) AS no_of_courses
FROM
  student
  LEFT JOIN student_course ON student.id = student_course.student_id
GROUP BY
  student.id;
  
9.Get the students who have taken at least 2 courses.

Note:
Solving this problem involves performing join operations on student and student_course tables.
You can get the year from the enrollment date
Use HAVING clause to filter the students who have taken at least two courses.

SELECT
  student.full_name,
  count(student_course.course_id) AS no_of_courses
FROM
  student
  INNER JOIN student_course ON student.id = student_course.student_id
GROUP BY
  student.id
HAVING
  no_of_courses >= 2;
  
10.Get all the students details and all the courses for which they have enrolled.

Note:
Here, we have to join student, student_course and course tables.
Performing left join between the student and student_course tables
perform left join on the combined table and course table.

SELECT
  student.id AS student_id,
  student.full_name AS student_name,
  course.id AS course_id,
  course.name AS course_name,
  score,
  enrollment_date
FROM
  student
  LEFT JOIN student_course ON student.id = student_course.student_id
  LEFT JOIN course ON student_course.course_id = course.id;
  
11.Get all the student details who enrolled for the “Machine Learning” course in the year 2021.

Note:
Here, we have to join student, student_course and course tables.
Apply filters on the combined table.
You can get the year from the enrollment date.

SELECT
  student_course.student_id,
  student.full_name,
  course.id AS course_id,
  course.name AS course_name,
  student_course.enrollment_date
FROM
  student
  JOIN student_course ON student.id = student_course.student_id
  JOIN course ON student_course.course_id = course.id
WHERE
  course.name = "Machine Learning"
  AND CAST(strftime("%Y", enrollment_date) AS integer) = 2021;
  
Output:

student_id	full_name	course_id	course_name			enrollment_date
1			Varun			11		Machine Learning	2021-01-16
3			Sandhya			11		Machine Learning	2021-01-19

Joins Cheat Sheet | Part - 3:
-------------------------------------

RIGHT JOIN:
----------------------------

RIGHT JOIN or RIGHT OUTER JOIN is vice versa of LEFT JOIN.
I.e., inRIGHT JOIN, for each row in the right table, matched rows from the left table are combined. If there is no match, NULL values are assigned to the left half of the rows in the temporary table.

Syntax:

SELECT *
FROM table1
   RIGHT JOIN table2
ON table1.c1 = table2.c2;

Which is similar to 

SELECT *
FROM table2
   LEFT JOIN table1
ON table1.c1 = table2.c2;

Example:
Following query performs RIGHT JOIN on course and instructor tables

SELECT course.name,
    instructor.full_name
FROM course
   RIGHT JOIN instructor
ON course.instructor_id = instructor.instructor_id;

Note:
Right Join is not supported in some dbms(SQLite).

FULL JOIN:
---------------------------
FULL JOIN or FULL OUTER  JOIN is the result of both RIGHT JOIN and LEFT JOIN

Syntax:

SELECT *
FROM table1
   FULL JOIN table2
ON c1 = c2;

Example:
Following query performs FULL JOIN ON course and instructor tables

SELECT course.name,
    instructor.full_name
FROM course
   FULL JOIN instructor
ON course.instructor_id = instructor.instructor_id;

Note:
FULL JOIN is not supported in some dbms(SQLite).

CROSS JOIN:
-------------------------------------------

In CROSS JOIN, each row from the first table is combined with all rows in the second table. 
Cross Join is also called as CARTESIAN JOIN

Syntax:

SELECT *
FROM table1
   CROSS JOIN table2;
   
Example
Following query performs CROSS JOIN on course and instructor tables

SELECT course.name AS course_name,
    instructor.full_name AS instructor_name
FROM course
   CROSS JOIN instructor;
   
Output:

course_name			instructor_name
Machine Learning	Alex
Machine Learning	Arun
Machine Learning	Bentlee
Cyber Security		Alex
...					...

SELF JOIN:
-------------------------------
So far, we have learnt to combine different tables. We can also combine a table with itself. This kind of join is called SELF-JOIN.

Syntax:

SELECT t1.c1,
   t2.c2
FROM table1 AS t1
   JOIN table1 AS t2
ON t1.c1 = t2.cn;

Note:
We can use any JOIN clause in self-join.

Example
Get student pairs who registered for common course.

SELECT sc1.student_id AS student_id1,
  sc2.student_id AS student_id2, sc1.course_id
FROM
   student_course AS sc1
   INNER JOIN student_course sc2 ON sc1.course_id = sc2.course_id
WHERE
    sc1.student_id < sc2.student_id;
	
Output:

student_id1	student_id2	course_id
1			3				11

JOINS Summary:
--------------------------

Join Type		Use Case
Natural Join	Joins based on common columns
Inner Join		Joins based on a given condition
Left Join		All rows from left table & matched rows from right table
Right Join		All rows from right table & matched rows from left table
Full Join		All rows from both the tables
Cross Join		All possible combinations

coding practice-3:
--------------------------------

Database:
The database contains user, post, comment and reaction tables.

A user can post many posts. A post is posted by only one user.
A user can react to multiple posts. A post can have many reactions.
A user can comment on multiple posts. A post can have many comments.

Note:

You can assume that a user may or may not post on the social media platform, i.e., a user can have zero or many posts. 
Also, a post can have zero or many comments or reactions. 
So, do take care of this detail while writing various queries on the database, especially, when deciding on INNER JOIN / LEFT JOIN.

1.Fetch all the posts along with user details.

Note:
 Sort the posts in the descending order ofposted_at
 
 SELECT
  user.name,
  user.age,
  post.post_id,
  post.content,
  post.posted_at
FROM
  user
  INNER JOIN post ON user.user_id = post.posted_by
ORDER BY
  posted_at DESC;
  
2.Fetch the 5 recent posts posted by “James Williams”.

Note:
Condiser that the name of the user is “James Williams”
Get the recent posts based onposted_atcolumn in post table

SELECT
  user.name,
  user.age,
  post.post_id,
  post.content,
  post.posted_at
FROM
  user
  INNER JOIN post ON post.posted_by = user.user_id
WHERE
  user.name = "James Williams"
ORDER BY
  posted_at DESC
LIMIT
  5;
  
3.Fetch the total number of posts posted by “James Williams” till date as posts_count

Note:
Condiser that the name of the user is “James Williams”

SELECT
  count() AS posts_count
FROM
  post
  INNER JOIN user ON post.posted_by = user.user_id
WHERE
  user.name = "James Williams";
  
4.For every user, fetch the total number of posts posted so far as posts_count

Note:
If a user does not publish any posts, keep the posts_count as 0.
Sort the output in the descending order of posts_count, and then in the ascending order of user_id.

SELECT
  user.user_id,
  user.name AS user_name,
  count(post_id) AS posts_count
FROM
  user
  LEFT JOIN post ON post.posted_by = user.user_id
GROUP BY
  user.user_id
ORDER BY
  posts_count DESC,
  user.user_id ASC;
  
5.Get all the users details who posted at least 2 posts.

Note:
Sort the output in the descending order of posts_count, and then in the ascending order of user_id.

SELECT
  user.user_id,
  user.name AS user_name,
  user.age,
  user.gender,
  count(post_id) AS posts_count
FROM
  user
  INNER JOIN post ON post.posted_by = user.user_id
GROUP BY
  user.user_id
HAVING
  posts_count >= 2
ORDER BY
  posts_count DESC,
  user.user_id ASC;
  
6.Fetch the active users in January 2021.

Note:
Consider the users as active, if they posted at least 2 posts in January 2021.
Sort the output in the descending order of posts_count, and then in the ascending order of user_id.

SELECT
  user.user_id,
  user.name AS user_name,
  count(post_id) AS posts_count
FROM
  user
  INNER JOIN post ON post.posted_by = user.user_id
WHERE
  strftime("%Y", posted_at) = "2021"
  AND strftime("%m", posted_at) = "01"
GROUP BY
  user.user_id
HAVING
  posts_count >= 2
ORDER BY
  posts_count DESC,
  user.user_id ASC;
  
7.For each post, get the total number of positive reactions as positive_reactions_count

Note:
Consider the reaction_type "LIKE", "LIT", "WOW" and "LOVE" as positive reactions.
If the post does not have any positive reactions, keep thepositive_reactions_count as 0.
Sort the output in the descending order of positive_reactions_count , and then in the ascending order of post_id.

SELECT
  post.post_id AS post_id,
  content,
  posted_by,
  count(
    CASE
      WHEN reaction.reaction_type IN ("LIKE", "LIT", "WOW", "LOVE") THEN 1
      ELSE NULL
    END
  ) AS positive_reactions_count
FROM
  post
  LEFT JOIN reaction ON post.post_id = reaction.post_id
GROUP BY
  post.post_id
ORDER BY
  positive_reactions_count DESC,
  post_id;
  
8.For each post, get the total number of positive reactions and negative reactions aspositive_reactions_count and negative_reactions_count respectively.

Note:
Consider the reaction_type "LIKE", "LIT", "WOW" and "LOVE" as positive reactions, and "DISLIKE" as a negative reaction.
If the post does not have positive_reactions, keep the positive_reactions_count as 0.
If the post does not have any negative_reactions, keep the negative_reactions_count as 0.
Sort the output in the ascending order of post_id.

SELECT
  post.post_id,
  post.content,
  COUNT (
    CASE
      WHEN reaction_type IN ("LIKE", "WOW", "LIT", "LOVE") THEN 1
      ELSE NULL
    END
  ) AS positive_reactions_count,
  COUNT (
    CASE
      WHEN reaction_type IN ("DISLIKE") THEN 1
      ELSE NULL
    END
  ) AS negative_reactions_count
FROM
  post
  LEFT JOIN reaction ON post.post_id = reaction.post_id
GROUP BY
  post.post_id
ORDER BY
  post.post_id ASC;
  
9.A general manager from the social networking site would like to review the content in all the posts that have more negative reactions over positive reactions.

Note:
Consider the reaction_type "LIKE", "LIT", "WOW" and "LOVE" as positive reactions, and "DISLIKE" as a negative reaction.
Output must contain rows in the ascending order of post_id.

SELECT
  post.post_id,
  post.content,
  COUNT (
    CASE
      WHEN reaction_type IN ("LIKE", "WOW", "LIT", "LOVE") THEN 1
      ELSE NULL
    END
  ) AS positive_reactions_count,
  COUNT (
    CASE
      WHEN reaction_type IN ("DISLIKE") THEN 1
      ELSE NULL
    END
  ) AS negative_reactions_count
FROM
  post
  INNER JOIN reaction ON post.post_id = reaction.post_id
GROUP BY
  post.post_id
HAVING
  negative_reactions_count > positive_reactions_count
ORDER BY
  post.post_id ASC;
  
10.Get all the comment details for the post with post_id = 5.

Note:
Output must contain comments in the ascending order of commented_at.

SELECT
  comment_id,
  comment_content,
  commented_by,
  commented_at
FROM
  COMMENT
WHERE
  post_id = 5
ORDER BY
  commented_at ASC;
  
11.Fetch all the posts posted by the user with user_id = 98, along with the comments for the posts.

Note:
Output must contain posts in the ascending order of post_id, and then in the descending order of commented_at.
If there is no comment for a post, keep the comment_id and comment_content as NULL.

SELECT
  post.post_id,
  post.posted_by,
  post.content,
  post.posted_at,
  COMMENT.comment_id,
  COMMENT.comment_content,
  COMMENT.commented_at
FROM
  post
  LEFT JOIN COMMENT ON post.post_id = COMMENT.post_id
WHERE
  post.posted_by = 98
ORDER BY
  post.post_id ASC,
  COMMENT.commented_at DESC;
  
12.Fetch all the posts and their comments count, for the posts posted by the user with user_id = 98.

Note:
Output must contain posts in the ascending order of post_id.
If there is no post for a user, keep the content, posted_at values as NULL.
If there is no comment for a post, keep the comments_count values as 0.

SELECT
  post.post_id,
  post.posted_by,
  post.content,
  post.posted_at,
  count(COMMENT.comment_id) AS comments_count
FROM
  post
  LEFT JOIN COMMENT ON post.post_id = COMMENT.post_id
WHERE
  post.posted_by = 98
GROUP BY
  post.post_id
ORDER BY
  post.post_id;
  
13.For each user, get all the posts posted, and the total comments count for each post, along with user_details. 

Note:
Sort the output in the ascending order of user_id, and then in the ascending order of post_id.
If there is no post for a user, keep the content, posted_at values as NULL
If there is no comment for a post, keep the comments_count value as 0.

SELECT
  user.user_id,
  user.name,
  post.post_id,
  post.content,
  post.posted_at,
  count(COMMENT.comment_id) AS comments_count
FROM
  user
  LEFT JOIN post ON user.user_id = post.posted_by
  LEFT JOIN COMMENT ON post.post_id = COMMENT.post_id
GROUP BY
  user.user_id,
  post.post_id
ORDER BY
  user.user_id ASC,
  post.post_id ASC;
  
14.For each user, get all the posts posted, and the total reactions count for each post, along with user_details. 

Note:
Sort the output in the ascending order of user_id, and then in the ascending order of post_id.
If there is no post for a user, keep the content, posted_at as NULL.
If there is no reaction for a post, keep the reactions_count as 0.

SELECT
  user.user_id,
  user.name,
  post.post_id,
  post.content,
  post.posted_at,
  count(reaction.reaction_id) AS reactions_count
FROM
  user
  LEFT JOIN post ON user.user_id = post.posted_by
  LEFT JOIN reaction ON post.post_id = reaction.post_id
GROUP BY
  user.user_id,
  post.post_id
ORDER BY
  user.user_id ASC,
  post.post_id ASC;
  
 Coding Practice - 4:
 ------------------------------------
 
 Database:
The database given is similar to IMDb, which consists data related to various movies, directors and actors.

The database is designed to cover the below business requirements.
- A movie can have more than one actor casted and vice versa.
- A movie can have more than one director and vice versa.

Junction Tables
movie_cast is a junction table which stores the many-to-many relationship between movie and actor. 
Androleof anactorfor a movie is stored in the table. Similarlymovie_directortable stores the many-to-many relationship between movie and director

SELECT
  movie.name AS movie_name,
  movie_cast.actor_id
FROM
  movie
  INNER JOIN movie_cast ON movie.id = movie_cast.movie_id
ORDER BY
  movie_name ASC,
  actor_id ASC;
  
2.Get the number of movies in which "Daniel Radcliffe" has acted.

SELECT
  count(*) AS no_of_movies
FROM
  actor
  INNER JOIN movie_cast ON actor.id = movie_cast.actor_id
WHERE
  name LIKE "Daniel Radcliffe";
  
3.For each actor, get the number of movies in which they are casted. 

Note:
Sort the output in the ascending order of the actor_name.

SELECT
  actor.name AS actor_name,
  count(movie_cast.movie_id) AS no_of_movies
FROM
  actor
  INNER JOIN movie_cast ON actor.id = movie_cast.actor_id
GROUP BY
  actor.id
ORDER BY
  actor.name ASC;
  
4.Get the actors who acted in at least 5 movies.

Note:
Sort the output in the ascending order of the actor_name.

SELECT
  actor.name AS actor_name,
  count(movie_cast.movie_id) AS no_of_movies
FROM
  actor
  INNER JOIN movie_cast ON actor.id = movie_cast.actor_id
GROUP BY
  actor.id
HAVING
  count(movie_cast.movie_id) >= 5
ORDER BY
  actor_name ASC;
  
5.For each director in the database, get the number of movies they have directed.

Note:
If a director did not direct any movie (in the database), consider the count as 0.
Sort the output in descending order of no_of_movies, and then in the ascending order of director_name.

SELECT
  director.name AS director_name,
  count(movie_director.movie_id) AS no_of_movies
FROM
  director
  LEFT JOIN movie_director ON director.id = movie_director.director_id
GROUP BY
  director.id
ORDER BY
  no_of_movies DESC,
  director_name ASC;
  
6.Get all the ids of directors who directed at least two movies, with rating greater than 6

Sort the output in descending order of no_of_movies, and then in the ascending order of director_id.

SELECT
  movie_director.director_id,
  count(movie.id) AS no_of_movies
FROM
  movie
  INNER JOIN movie_director ON movie.id = movie_director.movie_id
WHERE
  movie.rating > 6
GROUP BY
  movie_director.director_id
HAVING
  count(movie.id) >= 2
ORDER BY
  no_of_movies DESC,
  movie_director.director_id ASC;

7.Get all the director_ids who directed at least two movies that have a profit at least 50 crores.

Note:
Profit is the difference between collection and budget of movies
Sort the output in the descending order ofno_of_movies_with_atleast_profit_50_crand then in the ascending order ofdirector_id.

SELECT
  movie_director.director_id,
  count(movie.id) AS no_of_movies_with_atleast_profit_50_cr
FROM
  movie
  INNER JOIN movie_director ON movie.id = movie_director.movie_id
WHERE
  (collection_in_cr - budget_in_cr) >= 50
GROUP BY
  movie_director.director_id
HAVING
  count(movie.id) >= 2
ORDER BY
  no_of_movies_with_atleast_profit_50_cr DESC,
  movie_director.director_id ASC;
  
  
8.Get all the director_ids who directed at least two movies and have an average profit greater than 50 crores.

Note:
Profit is the difference between collection and budget of movies
Sort the output in the descending order ofno_of_moviesand then in the ascending order of director_id.

SELECT
  movie_director.director_id,
  COUNT(movie.id) AS no_of_movies,
  AVG(collection_in_cr - budget_in_cr) AS avg_profit
FROM
  movie
  INNER JOIN movie_director ON movie.id = movie_director.movie_id
GROUP BY
  movie_director.director_id
HAVING
  count(movie.id) >= 2
  AND AVG(collection_in_cr - budget_in_cr) > 50
ORDER BY
  no_of_movies DESC,
  movie_director.director_id ASC;
  
9.Fetch the directors who directed at least two movies, and has an average rating (for all his/her movies) greater than 8

Note
Sort the output in descending order of no_of_movies, and then in the ascending order of director_id

SELECT
  movie_director.director_id,
  count(movie.id) AS no_of_movies,
  AVG(movie.rating) AS avg_rating
FROM
  movie
  INNER JOIN movie_director ON movie.id = movie_director.movie_id
GROUP BY
  movie_director.director_id
HAVING
  count(movie.id) >= 2
  AND AVG(movie.rating) > 8
ORDER BY
  no_of_movies DESC,
  movie_director.director_id ASC;
  
director_id		no_of_movies	avg_rating
7				3				8.799999999999999

10.Get all the distinct actors who casted in any of the Harry Potter movies.

Note:
Consider the movie names that contain "Harry Potter ".
Sort the output in the ascending order of the actor_name.

SELECT
  DISTINCT(actor.name) AS actor_name
FROM
  actor
  INNER JOIN movie_cast ON actor.id = movie_cast.actor_id
  INNER JOIN movie ON movie_cast.movie_id = movie.id
WHERE
  movie.name LIKE "%Harry Potter%"
ORDER BY
  actor_name ASC;
  
11.Get all the distinct directos who directed any of the Harry Potter movies.

Note:
Consider the movie names that contain "Harry Potter ".
Sort the output in the ascending order of the director_name.

SELECT
  DISTINCT(director.name) AS director_name
FROM
  director
  INNER JOIN movie_director ON director.id = movie_director.director_id
  INNER JOIN movie ON movie_director.movie_id = movie.id
WHERE
  movie.name LIKE "%Harry Potter%"
ORDER BY
  director_name ASC;



Views:
-----------------

Database:
The database stores the sample data of an e-commerce aplication. 
Here, the database consists of user,order_details and product tables that store the information of products, orders placed, and the products on the platform.

View:
A view can simply be considered as a name to a SQL Query

Create View:
To create a view in the database, use the CREATE VIEW statement.

Example:
Createuser_base_detailsview with id, name, age, gender and pincode.

Sql:

CREATE VIEW user_base_details AS 
SELECT id, name, age, gender, pincode
FROM user;

Note:
In general, views are read only.

We cannot perform write operations like updating, deleting & inserting rows in the base tables through views.

Querying Using View:
We can use its name instead of writing the original query to get the data.

Sql:

SELECT *
FROM user_base_details;

Output:

id	name	age		gender	pincode
1	Sai		40		Male	400068
2	Boult	20		Male	30154
3	Sri		20		Female	700009
...	...		...		...		...
We can use same operations which are used on tables like WHERE clause, Ordering results, etc.

If we try to retrive data which is not defined in the view it raises an error.

Example:

SELECT name, address
FROM user_base_details
WHERE gender = "Male";
ORDER BY age ASC;

Output:

Error: no such column:address

List All Available Views:
--------------------------------
In SQLite, to list all the available views, we use the folowing query.

SELECT
  name
FROM
  sqlite_master
WHERE
  TYPE = 'view';
  
Output:

name
order_with_products
user_base_details

Delete View:

To remove a view from a database, use the DROP VIEW statement.

Syntax:

DROP VIEW view_name;

Example:
Deleteuser_base_detailsview from the database.

DROP VIEW user_base_details;

Advantages:
Views are used to write complex queries that involves multiple joins, group by, etc., and can be used whenever needed.
Restrict access to the data such that a user can only see limited data instead of a complete table.

Subqueries:
-------------------------

We can write nested queries, i.e., a query inside another query.
Lets understand the scenarios where subqueries can be used with the following database.

Database:
The database stores the sample data of an e-commerce aplication. 
Here, the database consists of user,order_details and product tables that store the information of products, orders placed, and the products on the platform.

Examples:

Example 1:
Get the rating variance of products in the "WATCH" category. Rating variance is the difference between average rating and rating of a product.

Here, we need to write an  expression to subtract rating of each product from the average rating as following.

SELECT name, 
(average_rating - rating) AS rating_variance
...

Replace average_rating with a query which computes the average.


SELECT
   name,
   (
       SELECT AVG(rating)
       FROM product
       WHERE category = "WATCH"
   ) - rating AS rating_variance
FROM product
WHERE category = "WATCH";

Output:

name			rating_variance
Analog-Digital	-0.766666666666667
Fastfit Watch	-0.366666666666666
Fastrack M01	0.333333333333334
...				...

Example 2:
Fetch all the products whose ratings is greater than average rating of all products.


SELECT *
FROM product
WHERE rating > (
       SELECT AVG(rating)
       FROM product
   );

Example 3:
Fetch all the order_ids in which order consists of mobile (product_ids : 291, 292, 293, 294, 296) and not ear phones (product_ids : 227, 228, 229, 232, 233).

SELECT
  order_id
FROM
  order_details
WHERE
  order_id IN (
    SELECT
      order_id
    FROM
      order_product
    WHERE
      product_id IN (291, 292, 293, 294, 296)
  )
  AND NOT order_id IN (
    SELECT
      order_id
    FROM
      order_product
    WHERE
      product_id IN (227, 228, 229, 232, 233)
  );
  
  
Possible Mistakes:
----------------------------
In SELECT Clause:
A subquery in the SELECT clause can have only one column.

Query:

SELECT name, (
   SELECT AVG(rating), MAX(rating) 
       FROM product
       WHERE category = "WATCH"
   ) - rating AS rating_variance
FROM product
WHERE category = "WATCH";

Output:

Error: 
sub-select returns 2 columns - expected 1

In WHERE Clause:
Query:
 In WHERE clause, a subquery can have only one column.
 
SELECT
   order_id, total_amount
FROM order_details
WHERE total_amount > (
   SELECT total_amount, order_id
   FROM order_details
);

Output:

Error: Row value misused

Views and Subqueries > Coding Practice:
--------------------------------------------------------

2.Create a view user_order_details to store the following information of the users and their orders.

Columns In View:
user_id	 name	age	gender	pincode	 order_id	total_amount

CREATE VIEW user_order_details AS
SELECT
  user.id AS user_id,
  user.name,
  user.age,
  user.gender,
  user.pincode,
  order_details.order_id,
  order_details.total_amount
FROM
  user
  INNER JOIN order_details ON user.id = order_details.customer_id;
  
3.Get the user_id and pincode of the customers who shopped for more than 50,000 rupees from the location_order_details view present in the database.

Data in location_order_details View

user_id		pincode	 order_id	total_amount
...			...			...			...

Expected Output Format:
user_id		pincode		total_amount_spent
...			...				...

SELECT
  user_id,
  pincode,
  SUM(total_amount) AS total_amount_spent
FROM
  location_order_details
GROUP BY
  user_id
HAVING
  total_amount_spent > 50000;
  
5.Lets now calculate the rating variance of products in the "MOBILE" category.

Note:
Rating variance is the difference between average rating and rating of a product 

Expected Output Format:
name	rating_variance

SELECT
  name,
  (
    SELECT
      AVG(rating)
    FROM
      product
    WHERE
      category = "MOBILE"
  ) - rating AS rating_variance
FROM
  product
WHERE
  category = "MOBILE";
	
6.Get all the products from the watch category, where rating is greater than average rating

Expected Output Format:
name	rating

SELECT
  name,
  rating
FROM
  product
WHERE
  category = "WATCH"
  AND rating > (
    SELECT
      AVG(rating)
    FROM
      product
    WHERE
      category = "WATCH"
  );

7.Get the  users where average amount spent by the user is greater than the average amount spent on all the orders on the platform

Expected Output Format:
customer_id	avg_amount_spent

SELECT
  customer_id,
  avg(total_amount) AS avg_amount_spent
FROM
  order_details
GROUP BY
  customer_id
HAVING
  avg(total_amount) > (
    SELECT
      avg(total_amount)
    FROM
      order_details
  );
  
assignment-3:
------------------------------------

Project Contd:
Consider an online video-sharing platform like YouTube which hosts tens of thousands of channels and crores of users.

You have to analyse the data and provide meaningful insights on the type of content that drives engagement, users growth, and many more 
to all the stakeholders. Let’s roll our sleeves up for an insightful analysis!

Database:
The sample database consists of tables that store the information of users, channels, videos, genres and likes/dislikes. 

Note:

channel_user table

channel_id	user_id	subscribed_datetime
100				1	2020-12-10 10:30:45
100				7	2020-10-10 11:30:45
...				...			...

channel_usertable stores the data of the channel_ids and their subscribers user_ids.

First row in the table represents that the user with user_id = 1 is subscribed to the channel with channel_id = 100 at 2020-12-10 10:30:45

user_likes table

user_id	video_id	reaction_type	reacted_at
1			10			LIKE		2020-12-10 10:30:45
7			10			DISLIKE		2020-10-10 11:30:45
...			...			...				...

Similarly, user_likes table stores the data of video_id and the user_ids who reacted to the video.

video_genre table

video_id	genre_id
10			201
10			202
...			...

Similarly,video_genre table stores the data of video_id and the ids of the genres that the corresponding video belongs to.

Let’s dive in to analyze the in and outs of each part of the data. Here we go!

1.Fetch the top 10 videos having more number of views.

Note:
Sort the output in the descending order of no_of_views, and then in the ascending order of name.

Expected Output Format:

name	no_of_views

SELECT
  name,
  no_of_views
FROM
  video
ORDER BY
  no_of_views DESC,
  name
LIMIT
  10;
  
2.Fetch the top 10 videos having more number of views, along with the channel details.

Note:
Sort the output in the descending order of no_of_views, and then in the ascending order of channel_name.

Expected Output Format:

video_name	no_of_views	channel_name

SELECT
  video.name AS video_name,
  video.no_of_views,
  channel.name AS channel_name
FROM
  video
  INNER JOIN channel ON video.channel_id = channel.channel_id
ORDER BY
  no_of_views DESC,
  channel_name ASC
LIMIT
  10
  
3.Get all the music videos released before the year 2016.

Note:
You can consider the videos which contain "music" in name as music videos.
Get the year in the integer format
Sort the output in the descending order of year, and then in the ascending order of name.

Expected Output Format:

name	no_of_views		year
...			...			...

SELECT
  name,
  no_of_views,
  CAST(strftime("%Y", published_datetime) AS INTEGER) AS year
FROM
  video
WHERE
  name LIKE "%music%"
  AND CAST(strftime("%Y", published_datetime) AS INTEGER) < 2016
ORDER BY
  year DESC,
  name ASC
  
4.Get all distinct channels which published music videos before 2016.

Note:
You can consider the videos which contain "music" in name as music videos.
Sort the output in the ascending order of chanel_name.

Expected Output Format:

channel_id	channel_name

SELECT
  channel.channel_id,
  channel.name AS channel_name
FROM
  channel
  LEFT JOIN video ON channel.channel_id = video.channel_id
WHERE
  video.name LIKE "%music%"
  AND CAST(strftime("%Y", published_datetime) AS INTEGER) < 2016
GROUP BY
  channel_name
ORDER BY
  channel_name ASC
  
6.Get all the unique channels that published review videos.

Note:
You can consider the videos which contain "review" in name as review videos.
Sort the output in the ascending order of channel_name.

Expected Output Format:

channel_id	channel_name

SELECT
  channel.channel_id,
  channel.name AS channel_name
FROM
  channel
  LEFT JOIN video ON channel.channel_id = video.channel_id
WHERE
  video.name LIKE "%review%"
GROUP BY
  channel_name
ORDER BY
  channel_name ASC
  
7.Get all the videos that belong to "Action" genre (genre_id = 201) and have more than 1 lakh views.

Note:
Sort the output in the ascending order of video_id.

Expected Output Format:

video_id	name	genre_id

SELECT
  video.video_id AS video_id,
  video.name,
  video_genre.genre_id
FROM
  video
  INNER JOIN video_genre ON video_genre.video_id = video.video_id
WHERE
  video_genre.genre_id = 201
  AND video.no_of_views > 100000
ORDER BY
  video_id
  
8.Get all the Indian users details whose age is below 30 years and liked the video (video_id = 1011) in the year 2020.

Note:
Consider the name of the country as "INDIA"
Consider reaction_type LIKE as liked.
Sort the output in the ascending order of name.

Expected Output Format:

name	gender	age	country	premium_membership

SELECT
  user.name,
  user.gender,
  user.age,
  user.country,
  user.premium_membership
FROM
  user
  INNER JOIN user_likes ON user.user_id = user_likes.user_id
WHERE
  user.country LIKE 'INDIA'
  AND user_likes.reaction_type LIKE 'LIKE'
  AND user.age < 30
  AND user_likes.video_id = 1011
ORDER BY
  user.name ASC
  
9.Find the number of videos published between the years 2010 & 2016.

Note:
Sort the output in the ascending order of the year
Keep the year in the integer format

Expected Output Format:

year	no_of_videos
...			...

SELECT
  CAST(strftime("%Y", published_datetime) AS INTEGER) AS year,
  count(video_id) AS no_of_videos
FROM
  video
WHERE
  CAST(strftime("%Y", published_datetime) AS INTEGER) BETWEEN 2010
  AND 2016
GROUP BY
  year
ORDER BY
  year ASC
  
10.Between 2010 & 2020, find the number of videos released in each of the below genres.

Note:
genre_ids : 201, 202, 204, 205, 206, 207
Sort the output in the descending order of no_of_videos, and then in the ascending order of genre_id.

Expected Output Format:

genre_id	no_of_videos
...				...

SELECT
  video_genre.genre_id,
  count(video.video_id) AS no_of_videos
FROM
  video
  INNER JOIN video_genre ON video.video_id = video_genre.video_id
WHERE
  video_genre.genre_id IN (201, 202, 204, 205, 206, 207)
  AND CAST(strftime("%Y", published_datetime) AS INTEGER) BETWEEN 2010
  AND 2020
GROUP BY
  genre_id
ORDER BY
  no_of_videos DESC,
  genre_id ASC
  
12.Get the total number of users subscribed for the channel "Tyler Oakley" (channel_id = 376) in the year 2018.

Expected Output Format

no_of_subscribers
...

SELECT
  count(user_id) AS no_of_subscribers
FROM
  channel_user
WHERE
  channel_id = 376
  AND CAST(strftime("%Y", subscribed_datetime) AS INTEGER) = 2018
  
14.Get the total number of countries where the subscribers of the Taylor Swift channel (channel_id = 399) are present.

Expected Output Format
country_count
...

SELECT
  count(DISTINCT(user.country)) AS country_count
FROM
  user
  INNER JOIN channel_user ON user.user_id = channel_user.user_id
WHERE
  channel_user.channel_id = 399
  
15.Insights about users:
Get the geographic distribution of Taylor Swift channel (channel_id = 399) subscribers.

Note:
Geographic distribution: Number of Taylor Swift subscribers present in each country. Ignore the countries whereno_of_subscribersis 0.
Order the result in the ascending order of the country name.

Expected Output Format

country	no_of_subscribers
...			...

SELECT
  (((user.country))) AS country,
  count(channel_user.user_id) AS no_of_subscribers
FROM
  user
  INNER JOIN channel_user ON user.user_id = channel_user.user_id
WHERE
  channel_user.channel_id = 399
GROUP BY
  user.country
ORDER BY
  country
  
assignment-4:
-------------------------------

1.Get the top 10 channels for which more number of users are subscribed in the year 2018.

Note:
In case, if the no_of_subscribers are same, then sort the output in the ascending order of channel_name.

Expected Output Format:

channel_id	channel_name	no_of_subscribers
...				...				...

SELECT
  channel.channel_id AS channel_id,
  channel.name AS channel_name,
  count(channel_user.user_id) AS no_of_subscribers
FROM
  channel
  INNER JOIN channel_user ON channel.channel_id = channel_user.channel_id
WHERE
  strftime("%Y", subscribed_datetime) = "2018"
GROUP BY
  channel_name
ORDER BY
  no_of_subscribers DESC,
  channel_name ASC
LIMIT
  10;
  
2.Get the number of users who possitively engaged with at least one video of Disney Channel (channel_id = 352).

Note:
Consider possitive engagement as LIKE for a video uploaded by Disney channel.

Expected Output Format:

no_of_users_reached
...

SELECT
  count(DISTINCT user_likes.user_id) AS no_of_users_reached
FROM
  video
  INNER JOIN user_likes ON user_likes.video_id = video.video_id
WHERE
  video.channel_id = 352
  AND user_likes.reaction_type = "LIKE";
  
3.Get the number of subscribers for each channel.

Note:
Sort the output in the descending order of no_of_subscribers, and then in the ascending order of channel_name.
If there are no subscribers for a channel is 0, then keep the no_of_subscribers as 0.

Expected Output Format:

channel_id	channel_name	no_of_subscribers
...				...				...

SELECT
  channel.channel_id,
  channel.name AS channel_name,
  count(channel_user.user_id) AS no_of_subscribers
FROM
  channel
  LEFT JOIN channel_user ON channel.channel_id = channel_user.channel_id
GROUP BY
  channel.channel_id
ORDER BY
  no_of_subscribers DESC,
  channel_name ASC
  
5.Get the number of users subscribed for the "Taylor Swift" channel in every month in the year 2018.

Note:
Sort the output in the ascending order of month_in_2018.
Ignore the months that have subscribers_per_month as 0.

Expected Output Format

month_in_2018	subscribers_per_month
1						....
2						....

SELECT
  CAST(strftime("%m", subscribed_datetime) AS integer) AS month_in_2018,
  count(user_id) AS subscribers_per_month
FROM
  channel_user
WHERE
  channel_id = 399
  AND strftime("%Y", subscribed_datetime) = "2018"
GROUP BY
  month_in_2018
ORDER BY
  month_in_2018 ASC;
  
6.Get the number of videos published by each channel.

Note:
If a channel did not upload any video, keep the no_of_videos as 0.
Sort the output in the ascending order of channel_name.

Expected Output Format

channel_name	no_of_videos
...					...

SELECT
  channel.name AS channel_name,
  count(video.video_id) AS no_of_videos
FROM
  channel
  LEFT JOIN video ON channel.channel_id = video.channel_id
GROUP BY
  channel.name
ORDER BY
  channel_name ASC
  
7.Get all the channels that published at least 5 videos in the year 2018.

Note:
Sort the output in the ascending order of channel_id.

Expected Output Format

channel_id	channel_name	no_of_videos
...				...				...

SELECT
  channel.channel_id AS channel_id,
  channel.name AS channel_name,
  count(video.video_id) AS no_of_videos
FROM
  channel
  LEFT JOIN video ON channel.channel_id = video.channel_id
WHERE
  CAST(strftime("%Y", published_datetime) AS INTEGER) = 2018
GROUP BY
  channel.name
HAVING
  count(video.video_id) >= 5
ORDER BY
  channel_id ASC
  
8.How many times each user has engaged with the videos of "News for you" channel (id = 366).

Note:
Consider engagement as LIKE or DISLIKE for a video uploaded by News for you channel.
Ignore the users who did not engage with the channel at least once.
Sort the output in the descending order of no_of_reactions, and then in the ascending order of user_id.

Expected Output Format

user_id	no_of_reactions
...			...

SELECT
  user_likes.user_id AS user_id,
  count(user_likes.reaction_type) AS no_of_reactions
FROM
  user_likes
  LEFT JOIN video ON video.video_id = user_likes.video_id
WHERE
  video.channel_id = 366
GROUP BY
  user_likes.user_id
HAVING
  user_likes.reaction_type IN ("LIKE", "DISLIKE")
ORDER BY
  no_of_reactions DESC,
  user_id ASC;
  
9.Get all the videos that have more than the average number of views.

Note:
Sort the output in the ascending order of name.

Expected Output Format

name	no_of_views
...			...

SELECT
  video.name AS name,
  video.no_of_views AS no_of_views
FROM
  video
GROUP BY
  video.video_id
HAVING
  no_of_views > (
    SELECT
      avg(no_of_views)
    FROM
      video
  )
ORDER BY
  name
  
10.Get all the distinct user_ids who liked at least one video uploaded by Android Authority Channel (channel__id = 364) but didnt like the video uploaded 
by Tech savvy channel with video_id = 1005.

Note:
Consider reaction_type LIKE as liked
Sort the output in the ascending order of user_id.

Expected Output Format

user_id
...

SELECT
  DISTINCT (user_likes.user_id) AS user_id
FROM
  user_likes
  INNER JOIN video ON video.video_id = user_likes.video_id
WHERE
  user_id IN(
    SELECT
      user_likes.user_id
    FROM
      user_likes
      INNER JOIN video ON video.video_id = user_likes.video_id
    WHERE
      video.channel_id = 364
      AND user_likes.reaction_type = "LIKE"
  )
  AND NOT user_id IN(
    SELECT
      user_likes.user_id
    FROM
      user_likes
      INNER JOIN video ON video.video_id = user_likes.video_id
    WHERE
      video.video_id = 1005
      AND user_likes.reaction_type = "LIKE"
  )
GROUP BY
  user_id
ORDER BY
  user_id ASC;
  
11.Get to top 5 viewed videos which belong to both the genres "Action" (genre_id = 201 ) and "Comedy" (genre_id = 202).

Note:
In case, if the no_of_views are same, then sort the output in the ascending order of video_name.

Expected Output Format

video_name	no_of_views
...				...

11.Get to top 5 viewed videos which belong to both the genres "Action" (genre_id = 201 ) and "Comedy" (genre_id = 202).

Note:
In case, if the no_of_views are same, then sort the output in the ascending order of video_name.

Expected Output Format

video_name	no_of_views
...				...

SELECT
  DISTINCT (video.name) AS video_name,
  video.no_of_views AS no_of_views
FROM
  video
  INNER JOIN video_genre ON video.video_id = video_genre.video_id
WHERE
  video_genre.video_id IN (
    SELECT
      video_id
    FROM
      video_genre
    WHERE
      genre_id = 201
  )
  AND video_genre.video_id IN(
    SELECT
      video_id
    FROM
      video_genre
    WHERE
      genre_id = "202"
  )
ORDER BY
  no_of_views DESC,
  video_name ASC
LIMIT
  5;
  
12.Get the top 5 viewed videos that belong to the "GAMING" genre_type.

Note:
Sort the output in the descending order of no_of_views, and then in the ascending order of video_name.

Expected Output Format

video_name	no_of_views
...				...

SELECT
  (video.name) AS video_name,
  video.no_of_views AS no_of_views
FROM
  video
  INNER JOIN video_genre ON video.video_id = video_genre.video_id
WHERE
  video_genre.genre_id = 207
ORDER BY
  no_of_views DESC,
  video_name ASC
LIMIT
  5;
  
13.Best time to upload a comedy video:

DunkFest channel is planning to upload a video in the "COMEDY" genre
Give the channel the best suitable hour of the day when users positively engage more with comedy videos.

Note:
Consider positive engagement as LIKE for the videos in the "COMEDY" genre_type.
Consider reaction_type LIKE as liked.
Return the hour in the integer format

Expected Output Format

hour_of_engagement	no_of_likes
5						...

SELECT
  CAST(strftime("%H", reacted_at) AS integer) AS hour_of_engagement,
  count(user_likes.reaction_type) AS no_of_likes
FROM
  user_likes
  INNER JOIN video_genre ON user_likes.video_id = video_genre.video_id
WHERE
  video_genre.genre_id = 202
  AND user_likes.reaction_type = "LIKE"
GROUP BY
  hour_of_engagement
ORDER BY
  no_of_likes DESC
LIMIT
  1;
  
14.Get the active users of the platform. Consider the users who liked at least fifty videos are considered active users.

Note:
Consider reaction_type LIKE as liked.
Sort the output in the ascending order of user_id.

Expected Output Format

active_user_id	no_of_likes
...					...

SELECT
  user_likes.user_id AS active_user_id,
  count(video_id) AS no_of_likes
FROM
  user_likes
WHERE
  reaction_type = "LIKE"
GROUP BY
  active_user_id
HAVING
  no_of_likes >= 50
ORDER BY
  active_user_id ASC;
  
15.Get all the user_ids who liked at least 5 videos published by "Tedx" channel.

Note:
Consider reaction_type LIKE as liked.
Sort the output in the descending order of no_of_likes, and then in the ascending order of active_user_id.

Expected Output Format

active_user_id	no_of_likes
...					...

SELECT
  DISTINCT (user_likes.user_id) AS active_user_id,
  count(user_likes.reaction_type) AS no_of_likes
FROM
  user_likes
  INNER JOIN video ON video.video_id = user_likes.video_id
WHERE
  video.channel_id = 353
  AND user_likes.reaction_type = "LIKE"
GROUP BY
  user_id
HAVING
  count(video.video_id) >= 5
ORDER BY
  no_of_likes DESC,
  active_user_id ASC;
  
16.Get all the potential users. Fetch the user_ids who liked at least 2 videos published by "Disney" channel, and who did not subscribe to the channel (channel_id = 352).

Note:
Consider reaction_type LIKE as liked.
Sort the output in the descending order of no_of_likes, and then in the ascending order of potential_user_id.

Expected Output Format

potential_user_id	no_of_likes
...						...

SELECT
  user_likes.user_id AS potential_user_id,
  count(user_likes.reaction_type) AS no_of_likes
FROM
  (
    user_likes
    INNER JOIN video ON user_likes.video_id = video.video_id
  ) AS T
  INNER JOIN channel ON T.channel_id = channel.channel_id
WHERE
  channel.name = "Disney"
  AND user_likes.reaction_type = "LIKE"
GROUP BY
  user_likes.user_id
HAVING
  count(video.video_id) >= 2
ORDER BY
  no_of_likes DESC,
  potential_user_id ASC;
  
17.Get top 5 genres in the platform with most positive user activity, i.e., the genres with videos having more number of likes.

Note:
Consider the reaction_type LIKE as liked.
If a video belongs to 3 genres, then the likes of the video is counted in all the 3 genres.
Sort the output in the descending order of no_of_likes, and then in the ascending order of the genre_type.

Expected Output Format

genre_id	genre_type	no_of_likes
...				...			...

SELECT
  genre.genre_id AS genre_id,
  genre.genre_type AS genre_type,
  count(user_likes.user_id) AS no_of_likes
FROM
  (
    genre
    INNER JOIN video_genre ON genre.genre_id = video_genre.genre_id
  ) AS T
  INNER JOIN user_likes ON T.video_id = user_likes.video_id
WHERE
  user_likes.reaction_type = "LIKE"
GROUP BY
  video_genre.genre_id
ORDER BY
  no_of_likes DESC,
  genre_type ASC
LIMIT
  5;
  
18.Get the top 3 genre_ids that are liked by the users in India in the year 2018. 

Note:
Consider the name of the country as "INDIA"
Consider reaction_type LIKE as liked. If a video belongs to 3 genres, then the like is counted in all the 3 genres.
Sort the output in the descending order of no_of_likes, and then in the ascending order of the genre_id.

Expected Output Format

genre_id	no_of_likes
...				...

SELECT
  video_genre.genre_id AS genre_id,
  count(user_likes.user_id) AS no_of_likes
FROM
  (
    user
    INNER JOIN user_likes ON user.user_id = user_likes.user_id
  ) AS T
  INNER JOIN video_genre ON T.video_id = video_genre.video_id
WHERE
  user.country = "INDIA"
  AND user_likes.reaction_type = "LIKE"
  AND strftime("%Y", reacted_at) = "2018"
GROUP BY
  genre_id
ORDER BY
  no_of_likes DESC,
  genre_id ASC
LIMIT
  3;
  
MCQ - EXAM - 1:
--------------------------------------

1.What is a Constraint?

Constraints are used to specify rules for the data in a table like primary key, foreign key and unqiue constraints

2.Which of the following is true about unique constraint?

It ensures that all the values in a column are unique.

3.Given aplayertable as below, what is the output of the below query?

name	age	score
Ram		24	10
Suresh	21	9
Rajesh	30	5
Ravi	  19	40
Rupesh	25	20
Sunny	26	29
Shiv	24	20

SELECT * 
FROM player 
LIMIT 10 OFFSET 3;

Gives the following as output:

name	age	score
Ravi	19	40
Rupesh	25	20
Sunny	26	29
Shiv	24	20